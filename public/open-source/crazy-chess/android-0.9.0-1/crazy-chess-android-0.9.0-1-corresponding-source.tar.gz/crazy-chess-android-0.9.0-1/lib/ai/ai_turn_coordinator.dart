import 'dart:async';

import 'package:flutter/foundation.dart';

import '../domain/chess_models.dart';
import '../game/game_controller.dart';
import '../l10n/runtime_game_locale.dart';
import 'chess_engine.dart';
import 'position_codec.dart';

class AiTurnCoordinator extends ChangeNotifier {
  AiTurnCoordinator({
    required this.controller,
    required this.engine,
    this.moveTime = const Duration(milliseconds: 500),
    this.presentationListenable,
    this.isPresentationBusy,
  }) {
    controller.addListener(_handleControllerChanged);
    engine.status.addListener(_handleEngineStatusChanged);
    presentationListenable?.addListener(_handlePresentationChanged);
  }

  final GameController controller;
  final ChessEngine engine;
  final Duration moveTime;
  final Listenable? presentationListenable;
  final bool Function()? isPresentationBusy;

  bool _requestInFlight = false;
  bool _scheduled = false;
  bool _disposed = false;
  int _controllerRevision = 0;
  String? _failureMessage;

  bool get isAiTurn {
    return controller.opponentMode == OpponentMode.stockfish &&
        controller.turn == PieceColor.black &&
        controller.phase == GamePhase.playing;
  }

  bool get inputLocked => isAiTurn;

  bool get isThinking {
    return isAiTurn &&
        (_requestInFlight || engine.status.value == EngineStatus.thinking);
  }

  String? get failureMessage => _failureMessage;
  String? get localizedFailureMessage =>
      _failureMessage == null ? null : RuntimeGameLocale.copy.messageAiFailure;

  EngineStatus get engineStatus => engine.status.value;

  Future<bool> preflight() async {
    _failureMessage = null;
    notifyListeners();
    try {
      await engine.initialize();
      return true;
    } catch (error) {
      _failureMessage = error.toString();
      notifyListeners();
      return false;
    }
  }

  Future<bool> prepareNewGame() async {
    _failureMessage = null;
    notifyListeners();
    try {
      await engine.newGame();
      return true;
    } catch (error) {
      _failureMessage = error.toString();
      notifyListeners();
      return false;
    }
  }

  Future<void> retry() async {
    _failureMessage = null;
    notifyListeners();
    try {
      await engine.initialize();
    } catch (error) {
      _failureMessage = error.toString();
      notifyListeners();
      return;
    }
    _scheduleIfNeeded();
  }

  void clearFailure() {
    if (_failureMessage != null) {
      _failureMessage = null;
      notifyListeners();
    }
  }

  void _handleControllerChanged() {
    _controllerRevision++;
    _scheduleIfNeeded();
    notifyListeners();
  }

  void _handleEngineStatusChanged() {
    notifyListeners();
  }

  void _handlePresentationChanged() {
    _scheduleIfNeeded();
    notifyListeners();
  }

  void _scheduleIfNeeded() {
    if (_disposed ||
        _scheduled ||
        _requestInFlight ||
        _failureMessage != null ||
        (isPresentationBusy?.call() ?? false) ||
        !isAiTurn) {
      return;
    }
    _scheduled = true;
    scheduleMicrotask(() {
      _scheduled = false;
      if (!_disposed &&
          !_requestInFlight &&
          _failureMessage == null &&
          !(isPresentationBusy?.call() ?? false) &&
          isAiTurn) {
        unawaited(_playAiTurn());
      }
    });
  }

  Future<void> _playAiTurn() async {
    _requestInFlight = true;
    notifyListeners();
    final requestedRevision = _controllerRevision;
    final requestedFen = FenCodec.encode(controller.positionSnapshot());
    final requestedLegalMoves = UciMove.legalMoves(controller);
    try {
      final response = await engine.bestMove(
        EngineMoveRequest(
          fen: requestedFen,
          moveTime: moveTime,
          legalMoves: requestedLegalMoves,
        ),
      );
      if (_disposed ||
          _controllerRevision != requestedRevision ||
          !isAiTurn ||
          FenCodec.encode(controller.positionSnapshot()) != requestedFen) {
        return;
      }
      final uciMove = UciMove.parse(response.uci);
      final legalMove = uciMove.resolve(controller);
      controller.makeMove(legalMove);
      if (legalMove.isPromotion &&
          controller.phase == GamePhase.promotion &&
          controller.turn == PieceColor.black) {
        controller.choosePromotion(uciMove.promotion ?? PieceType.queen);
      }
    } catch (error) {
      if (!_disposed) {
        _failureMessage = error.toString();
      }
    } finally {
      _requestInFlight = false;
      if (!_disposed) {
        notifyListeners();
        _scheduleIfNeeded();
      }
    }
  }

  @override
  void dispose() {
    if (_disposed) {
      return;
    }
    _disposed = true;
    controller.removeListener(_handleControllerChanged);
    engine.status.removeListener(_handleEngineStatusChanged);
    presentationListenable?.removeListener(_handlePresentationChanged);
    super.dispose();
  }
}
