import 'chess_engine.dart';
import 'engine_factory_stub.dart'
    if (dart.library.io) 'engine_factory_io.dart'
    if (dart.library.js_interop) 'engine_factory_web.dart'
    as implementation;

ChessEngine createPlatformChessEngine() {
  return implementation.createPlatformChessEngine();
}

bool get isStockfishPlatformSupported {
  return implementation.isStockfishPlatformSupported;
}
