import 'dart:async';
import 'dart:js_interop';

import 'package:web/web.dart' as web;

import 'web_stockfish_engine.dart';

@JS('Worker')
external JSFunction? get _workerConstructor;

@JS('WebAssembly')
external JSObject? get _webAssembly;

bool get browserStockfishSupported {
  return _workerConstructor != null && _webAssembly != null;
}

Uri get browserStockfishWorkerUri {
  return resolveStockfishWorkerUri(web.document.baseURI);
}

Future<StockfishWorkerTransport> startBrowserStockfishWorker(
  Uri workerScriptUri,
) async {
  return BrowserStockfishWorkerTransport(workerScriptUri);
}

class BrowserStockfishWorkerTransport implements StockfishWorkerTransport {
  BrowserStockfishWorkerTransport(Uri workerScriptUri)
    : _worker = web.Worker(workerScriptUri.toString().toJS) {
    _messageHandler = ((web.Event event) {
      final data = (event as web.MessageEvent).data?.dartify();
      if (data is String && !_messages.isClosed) {
        _messages.add(data);
      }
    }).toJS;
    _errorHandler = ((web.Event event) {
      final error = event as web.ErrorEvent;
      if (!_errors.isClosed) {
        _errors.add(
          StateError(
            error.message.isEmpty
                ? 'Unknown Stockfish worker failure.'
                : error.message,
          ),
        );
      }
    }).toJS;
    _messageErrorHandler = ((web.Event _) {
      if (!_errors.isClosed) {
        _errors.add(
          StateError('Stockfish worker returned an unreadable message.'),
        );
      }
    }).toJS;
    _worker.onmessage = _messageHandler;
    _worker.onerror = _errorHandler;
    _worker.onmessageerror = _messageErrorHandler;
  }

  final web.Worker _worker;
  final StreamController<String> _messages = StreamController<String>.broadcast(
    sync: true,
  );
  final StreamController<Object> _errors = StreamController<Object>.broadcast(
    sync: true,
  );
  late final JSFunction _messageHandler;
  late final JSFunction _errorHandler;
  late final JSFunction _messageErrorHandler;
  bool _terminated = false;

  @override
  Stream<Object> get errors => _errors.stream;

  @override
  Stream<String> get messages => _messages.stream;

  @override
  void postMessage(String message) {
    if (_terminated) {
      throw StateError('Stockfish worker is terminated.');
    }
    _worker.postMessage(message.toJS);
  }

  @override
  void terminate() {
    if (_terminated) {
      return;
    }
    _terminated = true;
    _worker.onmessage = null;
    _worker.onerror = null;
    _worker.onmessageerror = null;
    _worker.terminate();
    unawaited(_messages.close());
    unawaited(_errors.close());
  }
}
