import 'package:flutter/foundation.dart';

enum EngineStatus { unavailable, starting, ready, thinking, failed }

const int stockfishMinimumElo = 1320;
const int stockfishMaximumElo = 3190;

class EngineMoveRequest {
  const EngineMoveRequest({
    required this.fen,
    this.moveTime = const Duration(milliseconds: 500),
    this.legalMoves = const <String>[],
    this.targetElo,
  }) : assert(
         targetElo == null ||
             (targetElo >= stockfishMinimumElo &&
                 targetElo <= stockfishMaximumElo),
       );

  final String fen;
  final Duration moveTime;
  final List<String> legalMoves;

  /// A UCI strength limit. `null` preserves unrestricted Skill Level 20.
  final int? targetElo;
}

class EngineMove {
  const EngineMove({required this.uci, this.ponder});

  final String uci;
  final String? ponder;
}

abstract interface class ChessEngine {
  ValueListenable<EngineStatus> get status;

  String? get lastError;

  Stream<String> get logs;

  Future<void> initialize();

  Future<void> newGame();

  Future<EngineMove> bestMove(EngineMoveRequest request);

  Future<void> stop();

  Future<void> shutdown();

  Future<void> dispose();
}

class UnsupportedChessEngine implements ChessEngine {
  UnsupportedChessEngine({
    this.reason = 'Stockfish AI is unavailable on this platform or browser.',
  });

  final String reason;
  final ValueNotifier<EngineStatus> _status = ValueNotifier(
    EngineStatus.unavailable,
  );

  @override
  String? get lastError => reason;

  @override
  Stream<String> get logs => const Stream<String>.empty();

  @override
  ValueListenable<EngineStatus> get status => _status;

  @override
  Future<EngineMove> bestMove(EngineMoveRequest request) {
    return Future<EngineMove>.error(UnsupportedError(reason));
  }

  @override
  Future<void> dispose() async {
    _status.dispose();
  }

  @override
  Future<void> initialize() => Future<void>.error(UnsupportedError(reason));

  @override
  Future<void> newGame() => Future<void>.error(UnsupportedError(reason));

  @override
  Future<void> stop() async {}

  @override
  Future<void> shutdown() async {}
}
