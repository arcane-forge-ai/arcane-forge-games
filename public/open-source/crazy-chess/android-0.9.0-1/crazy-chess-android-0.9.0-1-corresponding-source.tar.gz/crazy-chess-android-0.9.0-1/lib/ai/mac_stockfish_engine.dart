import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'chess_engine.dart';

class NativeStockfishEngine implements ChessEngine {
  NativeStockfishEngine({
    String? executablePath,
    this.requestTimeout = const Duration(seconds: 5),
    StockfishProcessStarter? processStarter,
  }) : executablePath = executablePath ?? bundledStockfishPath(),
       _processStarter = processStarter ?? _startIoProcess,
       _validateExecutable = processStarter == null;

  final String executablePath;
  final Duration requestTimeout;
  final StockfishProcessStarter _processStarter;
  final bool _validateExecutable;
  final ValueNotifier<EngineStatus> _status = ValueNotifier(
    EngineStatus.unavailable,
  );
  final StreamController<String> _logs = StreamController<String>.broadcast();
  final List<_LineWaiter> _waiters = <_LineWaiter>[];
  final Set<int> _expectedExits = <int>{};

  StockfishProcessTransport? _process;
  StreamSubscription<String>? _stdoutSubscription;
  StreamSubscription<String>? _stderrSubscription;
  Future<void>? _initializing;
  bool _disposed = false;
  bool _strengthConfigured = false;
  int? _appliedTargetElo;
  String? _lastError;

  static String bundledStockfishPath() {
    final executable = File(Platform.resolvedExecutable);
    final name = Platform.isWindows ? 'stockfish.exe' : 'stockfish';
    return '${executable.parent.path}${Platform.pathSeparator}$name';
  }

  @override
  String? get lastError => _lastError;

  @override
  Stream<String> get logs => _logs.stream;

  @override
  ValueListenable<EngineStatus> get status => _status;

  @override
  Future<void> initialize() {
    _assertNotDisposed();
    if (_process != null && _status.value == EngineStatus.ready) {
      return Future<void>.value();
    }
    return _initializing ??= _initializeOnce().whenComplete(() {
      _initializing = null;
    });
  }

  Future<void> _initializeOnce() async {
    _setStatus(EngineStatus.starting);
    _lastError = null;
    final binary = File(executablePath);
    if (_validateExecutable && !await binary.exists()) {
      final error = StateError(
        'Bundled Stockfish executable is missing at $executablePath.',
      );
      _fail(error);
      throw error;
    }

    try {
      final process = await _processStarter(executablePath);
      _process = process;
      _stdoutSubscription = process.stdoutLines.listen(
        _handleStdout,
        onError: _handleStreamError,
      );
      _stderrSubscription = process.stderrLines.listen(
        _handleStderr,
        onError: _handleStreamError,
      );
      unawaited(process.exitCode.then((code) => _handleExit(process, code)));

      await _sendAndWait('uci', (line) => line == 'uciok', 'uciok');
      _send('setoption name Threads value 1');
      _send('setoption name Hash value 64');
      _send('setoption name Skill Level value 20');
      _send('setoption name Ponder value false');
      _send('setoption name MultiPV value 1');
      await _sendAndWait('isready', (line) => line == 'readyok', 'readyok');
      _strengthConfigured = true;
      _appliedTargetElo = null;
      _setStatus(EngineStatus.ready);
    } catch (error) {
      await _shutdownProcess();
      _fail(error);
      rethrow;
    }
  }

  @override
  Future<void> newGame() async {
    await initialize();
    await stop();
    _send('ucinewgame');
    await _sendAndWait(
      'isready',
      (line) => line == 'readyok',
      'readyok after ucinewgame',
    );
    _setStatus(EngineStatus.ready);
  }

  @override
  Future<EngineMove> bestMove(EngineMoveRequest request) async {
    await initialize();
    Object? firstError;
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        return await _search(request);
      } catch (error) {
        firstError ??= error;
        if (attempt == 0) {
          await _restart();
          continue;
        }
        await _shutdownProcess();
        _fail(error);
        throw StateError(
          'Stockfish failed after one restart: $error'
          '${firstError == error ? '' : ' (first failure: $firstError)'}',
        );
      }
    }
    throw StateError('Stockfish search failed.');
  }

  Future<EngineMove> _search(EngineMoveRequest request) async {
    if (_status.value == EngineStatus.thinking) {
      throw StateError('Stockfish is already thinking.');
    }
    await _applyStrength(request.targetElo);
    _setStatus(EngineStatus.thinking);
    _send('position fen ${request.fen}');
    final bestMove = _waitForLine(
      (line) => line.startsWith('bestmove '),
      'bestmove',
    );
    final searchMoves = request.legalMoves.isEmpty
        ? ''
        : ' searchmoves ${request.legalMoves.join(' ')}';
    _send('go movetime ${request.moveTime.inMilliseconds}$searchMoves');
    final line = await bestMove;
    final fields = line.split(RegExp(r'\s+'));
    if (fields.length < 2 || fields[1] == '(none)') {
      throw StateError('Stockfish returned no move: $line');
    }
    _setStatus(EngineStatus.ready);
    return EngineMove(
      uci: fields[1],
      ponder: fields.length >= 4 && fields[2] == 'ponder' ? fields[3] : null,
    );
  }

  Future<void> _restart() async {
    await _shutdownProcess();
    _setStatus(EngineStatus.starting);
    await _initializeOnce();
  }

  Future<void> _applyStrength(int? targetElo) async {
    if (_strengthConfigured && _appliedTargetElo == targetElo) {
      return;
    }
    _send('setoption name Skill Level value 20');
    _send(
      'setoption name UCI_LimitStrength value '
      '${targetElo == null ? 'false' : 'true'}',
    );
    if (targetElo != null) {
      _send('setoption name UCI_Elo value $targetElo');
    }
    await _sendAndWait(
      'isready',
      (line) => line == 'readyok',
      'readyok after strength change',
    );
    _strengthConfigured = true;
    _appliedTargetElo = targetElo;
  }

  @override
  Future<void> stop() async {
    if (_process != null && _status.value == EngineStatus.thinking) {
      _send('stop');
    }
  }

  @override
  Future<void> shutdown() async {
    await _shutdownProcess();
    _setStatus(EngineStatus.unavailable);
  }

  @override
  Future<void> dispose() async {
    if (_disposed) {
      return;
    }
    _disposed = true;
    await _shutdownProcess();
    for (final waiter in _waiters.toList()) {
      waiter.fail(StateError('Stockfish engine disposed.'));
    }
    _waiters.clear();
    await _logs.close();
    _status.dispose();
  }

  Future<void> _shutdownProcess() async {
    _strengthConfigured = false;
    _appliedTargetElo = null;
    final process = _process;
    _process = null;
    if (process != null) {
      _expectedExits.add(process.pid);
      try {
        process.writeLine('quit');
        await process.flush();
      } catch (_) {}
      try {
        await process.exitCode.timeout(const Duration(milliseconds: 800));
      } on TimeoutException {
        process.kill();
        try {
          await process.exitCode.timeout(const Duration(milliseconds: 800));
        } catch (_) {}
      }
    }
    await _stdoutSubscription?.cancel();
    await _stderrSubscription?.cancel();
    _stdoutSubscription = null;
    _stderrSubscription = null;
    for (final waiter in _waiters.toList()) {
      waiter.fail(StateError('Stockfish process restarted.'));
    }
    _waiters.clear();
  }

  void _handleStdout(String line) {
    _logs.add('stdout: $line');
    for (final waiter in _waiters.toList()) {
      if (waiter.matches(line)) {
        _waiters.remove(waiter);
        waiter.complete(line);
      }
    }
  }

  void _handleStderr(String line) {
    _logs.add('stderr: $line');
    if (line.trim().isNotEmpty) {
      _lastError = line.trim();
    }
  }

  void _handleStreamError(Object error) {
    _logs.add('stream-error: $error');
    _lastError = error.toString();
  }

  void _handleExit(StockfishProcessTransport process, int code) {
    final expected = _expectedExits.remove(process.pid);
    if (identical(_process, process)) {
      _process = null;
    }
    _logs.add('exit: pid=${process.pid} code=$code expected=$expected');
    if (!expected && !_disposed) {
      final error = StateError(
        'Stockfish exited unexpectedly with code $code.',
      );
      for (final waiter in _waiters.toList()) {
        waiter.fail(error);
      }
      _waiters.clear();
      _fail(error);
    }
  }

  Future<String> _sendAndWait(
    String command,
    bool Function(String line) predicate,
    String description,
  ) {
    final future = _waitForLine(predicate, description);
    _send(command);
    return future;
  }

  Future<String> _waitForLine(
    bool Function(String line) predicate,
    String description,
  ) {
    final waiter = _LineWaiter(
      predicate: predicate,
      description: description,
      timeout: requestTimeout,
      onTimeout: (timedOut) => _waiters.remove(timedOut),
    );
    _waiters.add(waiter);
    return waiter.future;
  }

  void _send(String command) {
    final process = _process;
    if (process == null) {
      throw StateError('Stockfish process is not running.');
    }
    _logs.add('stdin: $command');
    process.writeLine(command);
  }

  void _setStatus(EngineStatus value) {
    if (!_disposed && _status.value != value) {
      _status.value = value;
    }
  }

  void _fail(Object error) {
    _lastError = error.toString();
    _setStatus(EngineStatus.failed);
    if (!_logs.isClosed) {
      _logs.add('failure: $error');
    }
  }

  void _assertNotDisposed() {
    if (_disposed) {
      throw StateError('Stockfish engine is disposed.');
    }
  }
}

/// Compatibility wrapper retained for existing macOS call sites and tests.
class MacStockfishEngine extends NativeStockfishEngine {
  MacStockfishEngine({
    String? executablePath,
    super.requestTimeout,
    super.processStarter,
  }) : super(executablePath: executablePath ?? bundledStockfishPath());

  static String bundledStockfishPath() {
    final executable = File(Platform.resolvedExecutable);
    return '${executable.parent.path}${Platform.pathSeparator}stockfish';
  }
}

typedef StockfishProcessStarter =
    Future<StockfishProcessTransport> Function(String executablePath);

abstract interface class StockfishProcessTransport {
  int get pid;

  Stream<String> get stdoutLines;

  Stream<String> get stderrLines;

  Future<int> get exitCode;

  void writeLine(String line);

  Future<void> flush();

  bool kill();
}

class _IoStockfishProcessTransport implements StockfishProcessTransport {
  _IoStockfishProcessTransport(this.process);

  final Process process;

  @override
  Future<int> get exitCode => process.exitCode;

  @override
  int get pid => process.pid;

  @override
  Stream<String> get stderrLines =>
      process.stderr.transform(utf8.decoder).transform(const LineSplitter());

  @override
  Stream<String> get stdoutLines =>
      process.stdout.transform(utf8.decoder).transform(const LineSplitter());

  @override
  Future<void> flush() => process.stdin.flush();

  @override
  bool kill() => process.kill();

  @override
  void writeLine(String line) => process.stdin.writeln(line);
}

Future<StockfishProcessTransport> _startIoProcess(String executablePath) async {
  final process = await Process.start(
    executablePath,
    const <String>[],
    mode: ProcessStartMode.normal,
    runInShell: false,
  );
  return _IoStockfishProcessTransport(process);
}

class _LineWaiter {
  _LineWaiter({
    required this.predicate,
    required this.description,
    required Duration timeout,
    required this.onTimeout,
  }) {
    _timer = Timer(timeout, () {
      onTimeout(this);
      if (!completer.isCompleted) {
        completer.completeError(
          TimeoutException('Timed out waiting for $description.', timeout),
        );
      }
    });
  }

  final bool Function(String line) predicate;
  final String description;
  final void Function(_LineWaiter waiter) onTimeout;
  final Completer<String> completer = Completer<String>();
  late final Timer _timer;

  Future<String> get future => completer.future;

  bool matches(String line) => predicate(line);

  void complete(String line) {
    _timer.cancel();
    if (!completer.isCompleted) {
      completer.complete(line);
    }
  }

  void fail(Object error) {
    _timer.cancel();
    if (!completer.isCompleted) {
      completer.completeError(error);
    }
  }
}
