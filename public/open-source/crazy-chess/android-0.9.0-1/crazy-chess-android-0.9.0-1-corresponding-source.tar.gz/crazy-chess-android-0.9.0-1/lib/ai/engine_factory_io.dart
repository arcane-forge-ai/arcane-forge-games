import 'dart:io';

import 'chess_engine.dart';
import 'mac_stockfish_engine.dart';
import 'mobile_stockfish_engine.dart';

ChessEngine createPlatformChessEngine() {
  if (Platform.isMacOS) {
    return MacStockfishEngine();
  }
  if (Platform.isWindows) {
    return NativeStockfishEngine();
  }
  if (Platform.isIOS || Platform.isAndroid) {
    return MobileStockfishEngine();
  }
  return UnsupportedChessEngine();
}

bool get isStockfishPlatformSupported =>
    Platform.isMacOS ||
    Platform.isWindows ||
    Platform.isIOS ||
    Platform.isAndroid;
