import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:stockfish/stockfish.dart' as mobile_stockfish;

import 'chess_engine.dart';
import 'web_stockfish_engine.dart' show StockfishLiteFenAdapter;

typedef MobileStockfishTransportStarter =
    Future<MobileStockfishTransport> Function();

abstract interface class MobileStockfishTransport {
  Stream<String> get stdoutLines;

  Stream<Object> get errors;

  void send(String command);

  Future<void> close();
}

class MobileStockfishEngine implements ChessEngine {
  MobileStockfishEngine({
    MobileStockfishTransportStarter? transportStarter,
    this.initializationTimeout = const Duration(seconds: 30),
    this.requestTimeout = const Duration(seconds: 5),
  }) : _transportStarter = transportStarter ?? _startFlutterStockfish;

  final Duration initializationTimeout;
  final Duration requestTimeout;
  final MobileStockfishTransportStarter _transportStarter;
  final ValueNotifier<EngineStatus> _status = ValueNotifier(
    EngineStatus.unavailable,
  );
  final StreamController<String> _logs = StreamController<String>.broadcast();
  final List<_MobileLineWaiter> _waiters = <_MobileLineWaiter>[];

  MobileStockfishTransport? _transport;
  StreamSubscription<String>? _stdoutSubscription;
  StreamSubscription<Object>? _errorSubscription;
  Future<void>? _initializing;
  bool _disposed = false;
  bool _strengthConfigured = false;
  int? _appliedTargetElo;
  String? _lastError;

  @override
  String? get lastError => _lastError;

  @override
  Stream<String> get logs => _logs.stream;

  @override
  ValueListenable<EngineStatus> get status => _status;

  @override
  Future<void> initialize() {
    _assertNotDisposed();
    if (_transport != null && _status.value == EngineStatus.ready) {
      return Future<void>.value();
    }
    return _initializing ??= _initializeOnce().whenComplete(() {
      _initializing = null;
    });
  }

  Future<void> _initializeOnce() async {
    await _shutdownTransport('Mobile Stockfish transport replaced.');
    _setStatus(EngineStatus.starting);
    _lastError = null;
    try {
      final transport = await _transportStarter().timeout(
        initializationTimeout,
        onTimeout: () => throw TimeoutException(
          'Timed out starting mobile Stockfish.',
          initializationTimeout,
        ),
      );
      if (_disposed) {
        await transport.close();
        throw StateError('Stockfish engine was disposed while starting.');
      }
      _transport = transport;
      _stdoutSubscription = transport.stdoutLines.listen(
        _handleStdout,
        onError: _handleTransportError,
      );
      _errorSubscription = transport.errors.listen(_handleTransportError);

      await _sendAndWait(
        'uci',
        (line) => line == 'uciok',
        'uciok',
        initializationTimeout,
      );
      _send('setoption name Threads value 1');
      _send('setoption name Hash value 32');
      _send('setoption name Skill Level value 20');
      _send('setoption name Ponder value false');
      _send('setoption name MultiPV value 1');
      await _sendAndWait(
        'isready',
        (line) => line == 'readyok',
        'readyok',
        initializationTimeout,
      );
      _strengthConfigured = true;
      _appliedTargetElo = null;
      _setStatus(EngineStatus.ready);
    } catch (error) {
      await _shutdownTransport('Mobile Stockfish initialization failed.');
      _fail(error);
      rethrow;
    }
  }

  @override
  Future<void> newGame() async {
    await initialize();
    await stop();
    _send('ucinewgame');
    await _sendAndWait(
      'isready',
      (line) => line == 'readyok',
      'readyok after ucinewgame',
      requestTimeout,
    );
    _setStatus(EngineStatus.ready);
  }

  @override
  Future<EngineMove> bestMove(EngineMoveRequest request) async {
    await initialize();
    Object? firstError;
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        return await _search(request);
      } catch (error) {
        firstError ??= error;
        if (attempt == 0) {
          await _restart();
          continue;
        }
        await _shutdownTransport('Mobile Stockfish search failed.');
        _fail(error);
        throw StateError(
          'Stockfish failed after one mobile restart: $error'
          '${firstError == error ? '' : ' (first failure: $firstError)'}',
        );
      }
    }
    throw StateError('Mobile Stockfish search failed.');
  }

  Future<EngineMove> _search(EngineMoveRequest request) async {
    if (_status.value == EngineStatus.thinking) {
      throw StateError('Stockfish is already thinking.');
    }
    await _applyStrength(request.targetElo);
    _setStatus(EngineStatus.thinking);
    final engineFen = StockfishLiteFenAdapter.project(request.fen);
    if (engineFen != request.fen && !_logs.isClosed) {
      _logs.add('projection: ${request.fen} -> $engineFen');
    }
    _send('position fen $engineFen');
    final bestMove = _waitForLine(
      (line) => line.startsWith('bestmove '),
      'bestmove',
      requestTimeout,
    );
    final searchMoves = request.legalMoves.isEmpty
        ? ''
        : ' searchmoves ${request.legalMoves.join(' ')}';
    _send('go movetime ${request.moveTime.inMilliseconds}$searchMoves');
    final line = await bestMove;
    final fields = line.split(RegExp(r'\s+'));
    if (fields.length < 2 || fields[1] == '(none)') {
      throw StateError('Stockfish returned no move: $line');
    }
    _setStatus(EngineStatus.ready);
    return EngineMove(
      uci: fields[1],
      ponder: fields.length >= 4 && fields[2] == 'ponder' ? fields[3] : null,
    );
  }

  Future<void> _restart() async {
    await _shutdownTransport('Mobile Stockfish restarted.');
    _setStatus(EngineStatus.starting);
    await _initializeOnce();
  }

  Future<void> _applyStrength(int? targetElo) async {
    if (_strengthConfigured && _appliedTargetElo == targetElo) {
      return;
    }
    _send('setoption name Skill Level value 20');
    _send(
      'setoption name UCI_LimitStrength value '
      '${targetElo == null ? 'false' : 'true'}',
    );
    if (targetElo != null) {
      _send('setoption name UCI_Elo value $targetElo');
    }
    await _sendAndWait(
      'isready',
      (line) => line == 'readyok',
      'readyok after strength change',
      requestTimeout,
    );
    _strengthConfigured = true;
    _appliedTargetElo = targetElo;
  }

  @override
  Future<void> stop() async {
    if (_transport != null && _status.value == EngineStatus.thinking) {
      _send('stop');
    }
  }

  @override
  Future<void> shutdown() async {
    await _shutdownTransport('Mobile Stockfish released.');
    _setStatus(EngineStatus.unavailable);
  }

  @override
  Future<void> dispose() async {
    if (_disposed) {
      return;
    }
    _disposed = true;
    await _shutdownTransport('Mobile Stockfish engine disposed.');
    await _logs.close();
    _status.dispose();
  }

  Future<void> _shutdownTransport(String reason) async {
    _strengthConfigured = false;
    _appliedTargetElo = null;
    final transport = _transport;
    _transport = null;
    await _stdoutSubscription?.cancel();
    await _errorSubscription?.cancel();
    _stdoutSubscription = null;
    _errorSubscription = null;
    if (transport != null) {
      try {
        await transport.close();
      } catch (error) {
        if (!_logs.isClosed) {
          _logs.add('close-error: $error');
        }
      }
    }
    _failWaiters(StateError(reason));
  }

  void _handleStdout(String message) {
    for (final line in message.split(RegExp(r'[\r\n]+'))) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) {
        continue;
      }
      if (!_logs.isClosed) {
        _logs.add('stdout: $trimmed');
      }
      for (final waiter in _waiters.toList()) {
        if (waiter.matches(trimmed)) {
          _waiters.remove(waiter);
          waiter.complete(trimmed);
        }
      }
    }
  }

  void _handleTransportError(Object error) {
    if (_disposed) {
      return;
    }
    final failure = StateError('Mobile Stockfish transport error: $error');
    _lastError = failure.toString();
    if (!_logs.isClosed) {
      _logs.add('transport-error: $error');
    }
    _failWaiters(failure);
    _setStatus(EngineStatus.failed);
  }

  Future<String> _sendAndWait(
    String command,
    bool Function(String line) predicate,
    String description,
    Duration timeout,
  ) {
    final future = _waitForLine(predicate, description, timeout);
    _send(command);
    return future;
  }

  Future<String> _waitForLine(
    bool Function(String line) predicate,
    String description,
    Duration timeout,
  ) {
    final waiter = _MobileLineWaiter(
      predicate: predicate,
      description: description,
      timeout: timeout,
      onTimeout: (timedOut) => _waiters.remove(timedOut),
    );
    _waiters.add(waiter);
    return waiter.future;
  }

  void _send(String command) {
    final transport = _transport;
    if (transport == null) {
      throw StateError('Mobile Stockfish is not running.');
    }
    if (!_logs.isClosed) {
      _logs.add('command: $command');
    }
    transport.send(command);
  }

  void _failWaiters(Object error) {
    for (final waiter in _waiters.toList()) {
      waiter.fail(error);
    }
    _waiters.clear();
  }

  void _setStatus(EngineStatus value) {
    if (!_disposed && _status.value != value) {
      _status.value = value;
    }
  }

  void _fail(Object error) {
    _lastError = error.toString();
    _setStatus(EngineStatus.failed);
    if (!_logs.isClosed) {
      _logs.add('failure: $error');
    }
  }

  void _assertNotDisposed() {
    if (_disposed) {
      throw StateError('Stockfish engine is disposed.');
    }
  }
}

class _FlutterStockfishTransport implements MobileStockfishTransport {
  _FlutterStockfishTransport(this._stockfish);

  final mobile_stockfish.Stockfish _stockfish;
  bool _closed = false;

  @override
  Stream<Object> get errors => const Stream<Object>.empty();

  @override
  Stream<String> get stdoutLines => _stockfish.stdout;

  @override
  void send(String command) {
    if (_closed) {
      throw StateError('Mobile Stockfish transport is closed.');
    }
    _stockfish.stdin = command;
  }

  @override
  Future<void> close() async {
    if (_closed) {
      return;
    }
    _closed = true;
    final disposed = Completer<void>();
    void completeWhenReleased() {
      final state = _stockfish.state.value;
      if ((state == mobile_stockfish.StockfishState.disposed ||
              state == mobile_stockfish.StockfishState.error) &&
          !disposed.isCompleted) {
        disposed.complete();
      }
    }

    _stockfish.state.addListener(completeWhenReleased);
    _stockfish.dispose();
    completeWhenReleased();
    try {
      await disposed.future.timeout(const Duration(seconds: 5));
    } finally {
      _stockfish.state.removeListener(completeWhenReleased);
    }
  }
}

Future<MobileStockfishTransport> _startFlutterStockfish() async {
  final stockfish = await mobile_stockfish.stockfishAsync();
  return _FlutterStockfishTransport(stockfish);
}

class _MobileLineWaiter {
  _MobileLineWaiter({
    required this.predicate,
    required this.description,
    required Duration timeout,
    required this.onTimeout,
  }) {
    _timer = Timer(timeout, () {
      onTimeout(this);
      if (!completer.isCompleted) {
        completer.completeError(
          TimeoutException('Timed out waiting for $description.', timeout),
        );
      }
    });
  }

  final bool Function(String line) predicate;
  final String description;
  final void Function(_MobileLineWaiter waiter) onTimeout;
  final Completer<String> completer = Completer<String>();
  late final Timer _timer;

  Future<String> get future => completer.future;

  bool matches(String line) => predicate(line);

  void complete(String line) {
    _timer.cancel();
    if (!completer.isCompleted) {
      completer.complete(line);
    }
  }

  void fail(Object error) {
    _timer.cancel();
    if (!completer.isCompleted) {
      completer.completeError(error);
    }
  }
}
