import 'chess_engine.dart';

ChessEngine createPlatformChessEngine() => UnsupportedChessEngine();

bool get isStockfishPlatformSupported => false;
