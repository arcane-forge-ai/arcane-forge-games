import 'dart:async';

import 'package:flutter/foundation.dart';

import 'chess_engine.dart';

typedef StockfishWorkerStarter =
    Future<StockfishWorkerTransport> Function(Uri workerScriptUri);

abstract interface class StockfishWorkerTransport {
  Stream<String> get messages;

  Stream<Object> get errors;

  void postMessage(String message);

  void terminate();
}

Uri resolveStockfishWorkerUri(
  String baseUri, {
  String relativePath = 'stockfish/stockfish-18-lite-single.js',
}) {
  return Uri.parse(baseUri).resolve(relativePath);
}

class WebStockfishEngine implements ChessEngine {
  WebStockfishEngine({
    required this.workerScriptUri,
    required StockfishWorkerStarter workerStarter,
    this.initializationTimeout = const Duration(seconds: 30),
    this.requestTimeout = const Duration(seconds: 5),
  }) : _workerStarter = workerStarter;

  final Uri workerScriptUri;
  final Duration initializationTimeout;
  final Duration requestTimeout;
  final StockfishWorkerStarter _workerStarter;
  final ValueNotifier<EngineStatus> _status = ValueNotifier(
    EngineStatus.unavailable,
  );
  final StreamController<String> _logs = StreamController<String>.broadcast();
  final List<_WorkerLineWaiter> _waiters = <_WorkerLineWaiter>[];

  StockfishWorkerTransport? _worker;
  StreamSubscription<String>? _messageSubscription;
  StreamSubscription<Object>? _errorSubscription;
  Future<void>? _initializing;
  bool _disposed = false;
  bool _strengthConfigured = false;
  int? _appliedTargetElo;
  String? _lastError;

  @override
  String? get lastError => _lastError;

  @override
  Stream<String> get logs => _logs.stream;

  @override
  ValueListenable<EngineStatus> get status => _status;

  @override
  Future<void> initialize() {
    _assertNotDisposed();
    if (_worker != null && _status.value == EngineStatus.ready) {
      return Future<void>.value();
    }
    return _initializing ??= _initializeOnce().whenComplete(() {
      _initializing = null;
    });
  }

  Future<void> _initializeOnce() async {
    await _shutdownWorker('Stockfish worker replaced.');
    _setStatus(EngineStatus.starting);
    _lastError = null;
    try {
      final worker = await _workerStarter(workerScriptUri);
      if (_disposed) {
        worker.terminate();
        throw StateError('Stockfish engine was disposed while starting.');
      }
      _worker = worker;
      _messageSubscription = worker.messages.listen(
        _handleMessage,
        onError: _handleWorkerError,
      );
      _errorSubscription = worker.errors.listen(_handleWorkerError);

      await _sendAndWait(
        'uci',
        (line) => line == 'uciok',
        'uciok',
        initializationTimeout,
      );
      _send('setoption name Hash value 32');
      _send('setoption name Skill Level value 20');
      _send('setoption name Ponder value false');
      _send('setoption name MultiPV value 1');
      await _sendAndWait(
        'isready',
        (line) => line == 'readyok',
        'readyok',
        initializationTimeout,
      );
      _strengthConfigured = true;
      _appliedTargetElo = null;
      _setStatus(EngineStatus.ready);
    } catch (error) {
      await _shutdownWorker('Stockfish initialization failed.');
      _fail(error);
      rethrow;
    }
  }

  @override
  Future<void> newGame() async {
    await initialize();
    await stop();
    _send('ucinewgame');
    await _sendAndWait(
      'isready',
      (line) => line == 'readyok',
      'readyok after ucinewgame',
      requestTimeout,
    );
    _setStatus(EngineStatus.ready);
  }

  @override
  Future<EngineMove> bestMove(EngineMoveRequest request) async {
    await initialize();
    Object? firstError;
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        return await _search(request);
      } catch (error) {
        firstError ??= error;
        if (attempt == 0) {
          await _restart();
          continue;
        }
        await _shutdownWorker('Stockfish search failed.');
        _fail(error);
        throw StateError(
          'Stockfish failed after one worker restart: $error'
          '${firstError == error ? '' : ' (first failure: $firstError)'}',
        );
      }
    }
    throw StateError('Stockfish search failed.');
  }

  Future<EngineMove> _search(EngineMoveRequest request) async {
    if (_status.value == EngineStatus.thinking) {
      throw StateError('Stockfish is already thinking.');
    }
    await _applyStrength(request.targetElo);
    _setStatus(EngineStatus.thinking);
    final engineFen = StockfishLiteFenAdapter.project(request.fen);
    if (engineFen != request.fen && !_logs.isClosed) {
      _logs.add('projection: ${request.fen} -> $engineFen');
    }
    _send('position fen $engineFen');
    final bestMove = _waitForLine(
      (line) => line.startsWith('bestmove '),
      'bestmove',
      requestTimeout,
    );
    final searchMoves = request.legalMoves.isEmpty
        ? ''
        : ' searchmoves ${request.legalMoves.join(' ')}';
    _send('go movetime ${request.moveTime.inMilliseconds}$searchMoves');
    final line = await bestMove;
    final fields = line.split(RegExp(r'\s+'));
    if (fields.length < 2 || fields[1] == '(none)') {
      throw StateError('Stockfish returned no move: $line');
    }
    _setStatus(EngineStatus.ready);
    return EngineMove(
      uci: fields[1],
      ponder: fields.length >= 4 && fields[2] == 'ponder' ? fields[3] : null,
    );
  }

  Future<void> _restart() async {
    await _shutdownWorker('Stockfish worker restarted.');
    _setStatus(EngineStatus.starting);
    await _initializeOnce();
  }

  Future<void> _applyStrength(int? targetElo) async {
    if (_strengthConfigured && _appliedTargetElo == targetElo) {
      return;
    }
    _send('setoption name Skill Level value 20');
    _send(
      'setoption name UCI_LimitStrength value '
      '${targetElo == null ? 'false' : 'true'}',
    );
    if (targetElo != null) {
      _send('setoption name UCI_Elo value $targetElo');
    }
    await _sendAndWait(
      'isready',
      (line) => line == 'readyok',
      'readyok after strength change',
      requestTimeout,
    );
    _strengthConfigured = true;
    _appliedTargetElo = targetElo;
  }

  @override
  Future<void> stop() async {
    if (_worker != null && _status.value == EngineStatus.thinking) {
      _send('stop');
    }
  }

  @override
  Future<void> shutdown() async {
    await _shutdownWorker('Stockfish worker released.');
    _setStatus(EngineStatus.unavailable);
  }

  @override
  Future<void> dispose() async {
    if (_disposed) {
      return;
    }
    _disposed = true;
    final worker = _worker;
    if (worker != null) {
      try {
        worker.postMessage('quit');
      } catch (_) {}
    }
    await _shutdownWorker('Stockfish engine disposed.');
    await _logs.close();
    _status.dispose();
  }

  Future<void> _shutdownWorker(String reason) async {
    _strengthConfigured = false;
    _appliedTargetElo = null;
    final worker = _worker;
    _worker = null;
    worker?.terminate();
    await _messageSubscription?.cancel();
    await _errorSubscription?.cancel();
    _messageSubscription = null;
    _errorSubscription = null;
    _failWaiters(StateError(reason));
  }

  void _handleMessage(String message) {
    for (final line in message.split(RegExp(r'[\r\n]+'))) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) {
        continue;
      }
      if (!_logs.isClosed) {
        _logs.add('worker: $trimmed');
      }
      for (final waiter in _waiters.toList()) {
        if (waiter.matches(trimmed)) {
          _waiters.remove(waiter);
          waiter.complete(trimmed);
        }
      }
    }
  }

  void _handleWorkerError(Object error) {
    if (_disposed) {
      return;
    }
    final failure = StateError('Stockfish worker error: $error');
    _lastError = failure.toString();
    if (!_logs.isClosed) {
      _logs.add('worker-error: $error');
    }
    _failWaiters(failure);
    _setStatus(EngineStatus.failed);
  }

  Future<String> _sendAndWait(
    String command,
    bool Function(String line) predicate,
    String description,
    Duration timeout,
  ) {
    final future = _waitForLine(predicate, description, timeout);
    _send(command);
    return future;
  }

  Future<String> _waitForLine(
    bool Function(String line) predicate,
    String description,
    Duration timeout,
  ) {
    final waiter = _WorkerLineWaiter(
      predicate: predicate,
      description: description,
      timeout: timeout,
      onTimeout: (timedOut) => _waiters.remove(timedOut),
    );
    _waiters.add(waiter);
    return waiter.future;
  }

  void _send(String command) {
    final worker = _worker;
    if (worker == null) {
      throw StateError('Stockfish worker is not running.');
    }
    if (!_logs.isClosed) {
      _logs.add('command: $command');
    }
    worker.postMessage(command);
  }

  void _failWaiters(Object error) {
    for (final waiter in _waiters.toList()) {
      waiter.fail(error);
    }
    _waiters.clear();
  }

  void _setStatus(EngineStatus value) {
    if (!_disposed && _status.value != value) {
      _status.value = value;
    }
  }

  void _fail(Object error) {
    _lastError = error.toString();
    _setStatus(EngineStatus.failed);
    if (!_logs.isClosed) {
      _logs.add('failure: $error');
    }
  }

  void _assertNotDisposed() {
    if (_disposed) {
      throw StateError('Stockfish engine is disposed.');
    }
  }
}

class StockfishLiteFenAdapter {
  const StockfishLiteFenAdapter._();

  static String project(String fen) {
    final fields = fen.trim().split(RegExp(r'\s+'));
    if (fields.length != 6) {
      throw FormatException('Expected six FEN fields: $fen');
    }
    final board = _parseBoard(fields[0]);
    var changed = false;
    changed = _trimColor(board, white: true) || changed;
    changed = _trimColor(board, white: false) || changed;
    if (!changed) {
      return fen;
    }

    var castling = fields[2];
    if (board[7][4] != 'K') {
      castling = castling.replaceAll('K', '').replaceAll('Q', '');
    }
    if (board[7][7] != 'R') {
      castling = castling.replaceAll('K', '');
    }
    if (board[7][0] != 'R') {
      castling = castling.replaceAll('Q', '');
    }
    if (board[0][4] != 'k') {
      castling = castling.replaceAll('k', '').replaceAll('q', '');
    }
    if (board[0][7] != 'r') {
      castling = castling.replaceAll('k', '');
    }
    if (board[0][0] != 'r') {
      castling = castling.replaceAll('q', '');
    }
    if (castling.isEmpty) {
      castling = '-';
    }

    fields[0] = _encodeBoard(board);
    fields[2] = castling;
    return fields.join(' ');
  }

  static List<List<String?>> _parseBoard(String placement) {
    final ranks = placement.split('/');
    if (ranks.length != 8) {
      throw FormatException('Expected eight FEN ranks: $placement');
    }
    final board = <List<String?>>[];
    for (final rank in ranks) {
      final row = <String?>[];
      for (final symbol in rank.split('')) {
        final empty = int.tryParse(symbol);
        if (empty != null) {
          row.addAll(List<String?>.filled(empty, null));
        } else if ('pnbrqkPNBRQK'.contains(symbol)) {
          row.add(symbol);
        } else {
          throw FormatException('Invalid FEN piece symbol: $symbol');
        }
      }
      if (row.length != 8) {
        throw FormatException('Expected eight files in FEN rank: $rank');
      }
      board.add(row);
    }
    return board;
  }

  static String _encodeBoard(List<List<String?>> board) {
    final ranks = <String>[];
    for (final row in board) {
      final rank = StringBuffer();
      var empty = 0;
      for (final piece in row) {
        if (piece == null) {
          empty++;
          continue;
        }
        if (empty > 0) {
          rank.write(empty);
          empty = 0;
        }
        rank.write(piece);
      }
      if (empty > 0) {
        rank.write(empty);
      }
      ranks.add(rank.toString());
    }
    return ranks.join('/');
  }

  static bool _trimColor(List<List<String?>> board, {required bool white}) {
    final pieces = _piecesForColor(board, white: white);
    final pawnSymbol = white ? 'P' : 'p';
    final pawns = pieces.where((entry) => entry.symbol == pawnSymbol).toList();
    var changed = false;

    final orderedPawns = _removalOrder(pawns, white: white);
    final excessPawns = orderedPawns.length - 8;
    for (var index = 0; index < excessPawns; index++) {
      final pawn = orderedPawns[index];
      board[pawn.row][pawn.col] = null;
      changed = true;
    }

    final remaining = _piecesForColor(board, white: white);
    final excess = remaining.length - 16;
    if (excess <= 0) {
      return changed;
    }
    final removable = remaining
        .where((entry) => entry.symbol.toLowerCase() != 'k')
        .toList();
    final ordered = _removalOrder(removable, white: white);
    for (var index = 0; index < excess && index < ordered.length; index++) {
      final piece = ordered[index];
      board[piece.row][piece.col] = null;
      changed = true;
    }
    return changed;
  }

  static List<_FenPiece> _piecesForColor(
    List<List<String?>> board, {
    required bool white,
  }) {
    final pieces = <_FenPiece>[];
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final symbol = board[row][col];
        if (symbol == null) {
          continue;
        }
        final isWhite = symbol == symbol.toUpperCase();
        if (isWhite == white) {
          pieces.add(_FenPiece(row: row, col: col, symbol: symbol));
        }
      }
    }
    return pieces;
  }

  static List<_FenPiece> _removalOrder(
    List<_FenPiece> pieces, {
    required bool white,
  }) {
    final result = pieces.toList();
    result.sort((a, b) {
      final type = _removalValue(a.symbol).compareTo(_removalValue(b.symbol));
      if (type != 0) {
        return type;
      }
      final homeDepth = white ? b.row.compareTo(a.row) : a.row.compareTo(b.row);
      if (homeDepth != 0) {
        return homeDepth;
      }
      final edgeDistanceA = a.col < 4 ? a.col : 7 - a.col;
      final edgeDistanceB = b.col < 4 ? b.col : 7 - b.col;
      final edge = edgeDistanceA.compareTo(edgeDistanceB);
      if (edge != 0) {
        return edge;
      }
      return a.col.compareTo(b.col);
    });
    return result;
  }

  static int _removalValue(String symbol) {
    return switch (symbol.toLowerCase()) {
      'p' => 1,
      'n' => 3,
      'b' => 3,
      'r' => 5,
      'q' => 9,
      _ => 1000,
    };
  }
}

class _FenPiece {
  const _FenPiece({required this.row, required this.col, required this.symbol});

  final int row;
  final int col;
  final String symbol;
}

class _WorkerLineWaiter {
  _WorkerLineWaiter({
    required this.predicate,
    required this.description,
    required Duration timeout,
    required this.onTimeout,
  }) {
    _timer = Timer(timeout, () {
      if (!_completer.isCompleted) {
        onTimeout(this);
        _completer.completeError(
          TimeoutException('Timed out waiting for $description.', timeout),
        );
      }
    });
  }

  final bool Function(String line) predicate;
  final String description;
  final void Function(_WorkerLineWaiter waiter) onTimeout;
  final Completer<String> _completer = Completer<String>();
  late final Timer _timer;

  Future<String> get future => _completer.future;

  bool matches(String line) => predicate(line);

  void complete(String line) {
    if (!_completer.isCompleted) {
      _timer.cancel();
      _completer.complete(line);
    }
  }

  void fail(Object error) {
    if (!_completer.isCompleted) {
      _timer.cancel();
      _completer.completeError(error);
    }
  }
}
