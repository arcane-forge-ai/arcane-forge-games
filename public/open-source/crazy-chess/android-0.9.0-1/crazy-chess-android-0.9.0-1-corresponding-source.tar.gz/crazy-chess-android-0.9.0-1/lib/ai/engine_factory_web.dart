import 'chess_engine.dart';
import 'web_stockfish_engine.dart';
import 'web_stockfish_transport.dart';

ChessEngine createPlatformChessEngine() {
  if (!browserStockfishSupported) {
    return UnsupportedChessEngine(
      reason:
          'This browser does not provide WebAssembly and Web Worker support.',
    );
  }
  return WebStockfishEngine(
    workerScriptUri: browserStockfishWorkerUri,
    workerStarter: startBrowserStockfishWorker,
  );
}

bool get isStockfishPlatformSupported => browserStockfishSupported;
