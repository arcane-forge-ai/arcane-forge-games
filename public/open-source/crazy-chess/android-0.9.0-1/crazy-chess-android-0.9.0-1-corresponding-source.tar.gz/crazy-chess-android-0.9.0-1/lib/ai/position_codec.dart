import '../domain/chess_models.dart';
import '../domain/game_position_snapshot.dart';
import '../game/game_controller.dart';
import '../game/game_controller_rules.dart';

class FenCodec {
  const FenCodec._();

  static String encode(GamePositionSnapshot snapshot) {
    final ranks = <String>[];
    for (final row in snapshot.board) {
      final rank = StringBuffer();
      var empty = 0;
      for (final piece in row) {
        if (piece == null) {
          empty++;
          continue;
        }
        if (empty > 0) {
          rank.write(empty);
          empty = 0;
        }
        rank.write(_pieceLetter(piece));
      }
      if (empty > 0) {
        rank.write(empty);
      }
      ranks.add(rank.toString());
    }
    final activeColor = snapshot.turn == PieceColor.white ? 'w' : 'b';
    final castling = _castlingRights(snapshot);
    final enPassant = snapshot.enPassantSquare == null
        ? '-'
        : boardSquareName(snapshot.enPassantSquare!);
    final fullmove = ((snapshot.turnCount + 1) ~/ 2).clamp(1, 999999);
    return '${ranks.join('/')} $activeColor $castling $enPassant 0 $fullmove';
  }

  static String _pieceLetter(PositionPiece piece) {
    final letter = switch (piece.type) {
      PieceType.pawn => 'p',
      PieceType.knight => 'n',
      PieceType.bishop => 'b',
      PieceType.rook => 'r',
      PieceType.queen => 'q',
      PieceType.king => 'k',
    };
    return piece.color == PieceColor.white ? letter.toUpperCase() : letter;
  }

  static String _castlingRights(GamePositionSnapshot snapshot) {
    final rights = StringBuffer();
    if (_canCastle(snapshot, PieceColor.white, kingSide: true)) {
      rights.write('K');
    }
    if (_canCastle(snapshot, PieceColor.white, kingSide: false)) {
      rights.write('Q');
    }
    if (_canCastle(snapshot, PieceColor.black, kingSide: true)) {
      rights.write('k');
    }
    if (_canCastle(snapshot, PieceColor.black, kingSide: false)) {
      rights.write('q');
    }
    return rights.isEmpty ? '-' : rights.toString();
  }

  static bool _canCastle(
    GamePositionSnapshot snapshot,
    PieceColor color, {
    required bool kingSide,
  }) {
    final row = color == PieceColor.white ? 7 : 0;
    final king = snapshot.board[row][4];
    final rook = snapshot.board[row][kingSide ? 7 : 0];
    return king != null &&
        king.type == PieceType.king &&
        king.color == color &&
        !king.hasMoved &&
        rook != null &&
        rook.type == PieceType.rook &&
        rook.color == color &&
        !rook.hasMoved;
  }
}

class UciMove {
  const UciMove({required this.from, required this.to, this.promotion});

  final Square from;
  final Square to;
  final PieceType? promotion;

  static List<String> legalMoves(GameController controller) {
    final encoded = <String>[];
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final from = Square(row, col);
        final piece = controller.pieceAt(from);
        if (piece == null || piece.color != controller.turn) {
          continue;
        }
        for (final move in controller.legalMovesFrom(from)) {
          final coordinates =
              '${boardSquareName(move.from)}${boardSquareName(move.to)}';
          if (move.isPromotion) {
            encoded.addAll(<String>[
              '${coordinates}q',
              '${coordinates}r',
              '${coordinates}b',
              '${coordinates}n',
            ]);
          } else {
            encoded.add(coordinates);
          }
        }
      }
    }
    return List<String>.unmodifiable(encoded);
  }

  static UciMove parse(String value) {
    final normalized = value.trim().toLowerCase();
    if (normalized.length != 4 && normalized.length != 5) {
      throw FormatException('Invalid UCI move: $value');
    }
    final from = parseBoardSquare(normalized.substring(0, 2));
    final to = parseBoardSquare(normalized.substring(2, 4));
    if (from == null || to == null) {
      throw FormatException('Invalid UCI squares: $value');
    }
    PieceType? promotion;
    if (normalized.length == 5) {
      promotion = switch (normalized[4]) {
        'q' => PieceType.queen,
        'r' => PieceType.rook,
        'b' => PieceType.bishop,
        'n' => PieceType.knight,
        _ => throw FormatException('Invalid UCI promotion: $value'),
      };
    }
    return UciMove(from: from, to: to, promotion: promotion);
  }

  ChessMove resolve(GameController controller) {
    for (final move in controller.legalMovesFrom(from)) {
      if (move.to == to && (promotion == null || move.isPromotion)) {
        return move;
      }
    }
    throw StateError(
      'Stockfish returned illegal move '
      '${boardSquareName(from)}${boardSquareName(to)}.',
    );
  }
}
