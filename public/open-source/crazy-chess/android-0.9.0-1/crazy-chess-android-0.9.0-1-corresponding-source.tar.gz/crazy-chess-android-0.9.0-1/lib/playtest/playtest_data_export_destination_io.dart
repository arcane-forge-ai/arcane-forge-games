import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'playtest_data_exporter.dart';

PlaytestExportDestination createPlaytestExportDestination() =>
    IoPlaytestExportDestination();

class IoPlaytestExportDestination implements PlaytestExportDestination {
  IoPlaytestExportDestination({
    Future<Directory?> Function()? downloadsDirectoryProvider,
  }) : _downloadsDirectoryProvider =
           downloadsDirectoryProvider ?? getDownloadsDirectory;

  final Future<Directory?> Function() _downloadsDirectoryProvider;

  @override
  Future<String> write({
    required String fileName,
    required Uint8List bytes,
  }) async {
    if (p.basename(fileName) != fileName || !fileName.endsWith('.zip')) {
      throw const PlaytestExportException('The export filename is invalid.');
    }
    final downloads = await _downloadsDirectoryProvider();
    if (downloads == null) {
      throw const PlaytestExportException(
        'The Downloads folder is unavailable on this device.',
      );
    }
    await downloads.create(recursive: true);
    final destination = await _availableDestination(downloads, fileName);
    final temporary = File('${destination.path}.tmp');
    try {
      await temporary.writeAsBytes(bytes, flush: true);
      await temporary.rename(destination.path);
      return destination.path;
    } on FileSystemException catch (error) {
      if (await temporary.exists()) {
        try {
          await temporary.delete();
        } on FileSystemException {
          // Preserve the original write failure.
        }
      }
      throw PlaytestExportException(
        'Could not write the playtest ZIP to Downloads: ${error.message}',
      );
    }
  }

  Future<File> _availableDestination(
    Directory directory,
    String fileName,
  ) async {
    final base = p.basenameWithoutExtension(fileName);
    final extension = p.extension(fileName);
    for (var suffix = 1; suffix <= 999; suffix += 1) {
      final candidateName = suffix == 1 ? fileName : '$base-$suffix$extension';
      final candidate = File(p.join(directory.path, candidateName));
      if (!await candidate.exists()) return candidate;
    }
    throw const PlaytestExportException(
      'Too many playtest ZIPs with the same timestamp are in Downloads.',
    );
  }
}
