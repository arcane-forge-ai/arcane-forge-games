import 'playtest_diagnostics.dart';
import 'playtest_diagnostics_factory_stub.dart'
    if (dart.library.io) 'playtest_diagnostics_factory_io.dart'
    as platform;

PlaytestDiagnostics createPlaytestDiagnostics() =>
    platform.createPlaytestDiagnostics();
