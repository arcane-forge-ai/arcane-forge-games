import 'playtest_diagnostics.dart';

PlaytestDiagnostics createPlaytestDiagnostics() => MemoryPlaytestDiagnostics();
