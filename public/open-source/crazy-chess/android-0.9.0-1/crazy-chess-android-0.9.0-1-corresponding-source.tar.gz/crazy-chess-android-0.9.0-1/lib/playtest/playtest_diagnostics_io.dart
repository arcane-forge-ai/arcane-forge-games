import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'playtest_diagnostics.dart';
import 'playtest_sanitizer.dart';

class IoPlaytestDiagnostics implements PlaytestDiagnostics {
  IoPlaytestDiagnostics({
    Future<Directory> Function()? rootProvider,
    DateTime Function()? now,
    this.maxFiles = 5,
    this.maxFileBytes = 512 * 1024,
  }) : _rootProvider = rootProvider,
       _now = now ?? DateTime.now;

  final Future<Directory> Function()? _rootProvider;
  final DateTime Function() _now;
  final int maxFiles;
  final int maxFileBytes;

  Future<void>? _initializing;
  Future<void> _pending = Future<void>.value();
  Directory? _root;
  File? _sessionFile;
  int _writtenBytes = 0;
  bool _truncated = false;

  @override
  Future<void> initialize() => _initializing ??= _initialize();

  Future<void> _initialize() async {
    final root = _rootProvider == null
        ? Directory(
            p.join(
              (await getApplicationSupportDirectory()).path,
              'crazy_chess',
              'playtest_diagnostics',
            ),
          )
        : await _rootProvider();
    await root.create(recursive: true);
    _root = root;
    await _pruneOldFiles(root);
    final now = _now();
    _sessionFile = File(
      p.join(root.path, 'session-${_fileTimestamp(now)}.jsonl'),
    );
    if (await _sessionFile!.exists()) {
      _writtenBytes = await _sessionFile!.length();
    }
  }

  @override
  void record(
    String event, {
    String? message,
    Map<String, Object?> data = const <String, Object?>{},
  }) {
    final entry = <String, Object?>{
      'timestamp': _now().toUtc().toIso8601String(),
      'event': event,
      if (message != null) 'message': sanitizePlaytestString(message),
      if (data.isNotEmpty) 'data': sanitizePlaytestValue(data),
    };
    _pending = _pending
        .catchError((Object _) {})
        .then((_) => _append(entry))
        .catchError((Object _) {});
  }

  Future<void> _append(Map<String, Object?> entry) async {
    await initialize();
    if (_truncated) return;
    final encoded = utf8.encode('${jsonEncode(entry)}\n');
    if (_writtenBytes + encoded.length > maxFileBytes) {
      _truncated = true;
      final marker = utf8.encode(
        '${jsonEncode(<String, Object?>{
          'timestamp': _now().toUtc().toIso8601String(),
          'event': 'diagnostic_log_truncated',
          'data': <String, Object?>{'maxFileBytes': maxFileBytes},
        })}\n',
      );
      if (_writtenBytes + marker.length <= maxFileBytes) {
        await _sessionFile!.writeAsBytes(
          marker,
          mode: FileMode.append,
          flush: true,
        );
        _writtenBytes += marker.length;
      }
      return;
    }
    await _sessionFile!.writeAsBytes(
      encoded,
      mode: FileMode.append,
      flush: true,
    );
    _writtenBytes += encoded.length;
  }

  @override
  Future<void> flush() => _pending;

  @override
  Future<List<PlaytestDiagnosticFile>> snapshotFiles() async {
    await flush();
    await initialize();
    final files = await _jsonlFiles(_root!);
    final selected = files.length <= maxFiles
        ? files
        : files.sublist(files.length - maxFiles);
    final snapshots = <PlaytestDiagnosticFile>[];
    for (final file in selected) {
      try {
        snapshots.add(
          PlaytestDiagnosticFile(
            name: p.basename(file.path),
            bytes: Uint8List.fromList(await file.readAsBytes()),
          ),
        );
      } on FileSystemException {
        // A changing diagnostic file should not block valid playtest data.
      }
    }
    return List<PlaytestDiagnosticFile>.unmodifiable(snapshots);
  }

  Future<void> _pruneOldFiles(Directory root) async {
    final files = await _jsonlFiles(root);
    final keepBeforeCreating = maxFiles > 0 ? maxFiles - 1 : 0;
    final removeCount = files.length - keepBeforeCreating;
    if (removeCount <= 0) return;
    for (final file in files.take(removeCount)) {
      try {
        await file.delete();
      } on FileSystemException {
        // Retention cleanup is best-effort.
      }
    }
  }

  Future<List<File>> _jsonlFiles(Directory root) async {
    final files = <File>[];
    await for (final entity in root.list()) {
      if (entity is File && p.extension(entity.path) == '.jsonl') {
        files.add(entity);
      }
    }
    files.sort((a, b) => a.path.compareTo(b.path));
    return files;
  }

  String _fileTimestamp(DateTime value) {
    final local = value.toLocal();
    String two(int part) => part.toString().padLeft(2, '0');
    return '${local.year}${two(local.month)}${two(local.day)}-'
        '${two(local.hour)}${two(local.minute)}${two(local.second)}-'
        '${local.microsecond.toString().padLeft(6, '0')}';
  }
}
