import 'dart:typed_data';

import 'playtest_data_exporter.dart';

PlaytestExportDestination createPlaytestExportDestination() =>
    const UnsupportedPlaytestExportDestination();

class UnsupportedPlaytestExportDestination
    implements PlaytestExportDestination {
  const UnsupportedPlaytestExportDestination();

  @override
  Future<String> write({
    required String fileName,
    required Uint8List bytes,
  }) => throw const PlaytestExportException(
    'Playtest-data export is currently available in packaged desktop builds.',
  );
}
