import 'playtest_data_export_destination_stub.dart'
    if (dart.library.io) 'playtest_data_export_destination_io.dart'
    as platform;
import 'playtest_data_exporter.dart';

PlaytestExportDestination createPlaytestExportDestination() =>
    platform.createPlaytestExportDestination();
