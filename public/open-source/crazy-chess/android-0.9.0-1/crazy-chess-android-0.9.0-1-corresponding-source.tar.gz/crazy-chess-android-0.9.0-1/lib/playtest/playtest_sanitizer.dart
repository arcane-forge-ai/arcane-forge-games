const _redacted = '[REDACTED]';

Object? sanitizePlaytestValue(
  Object? value, {
  Iterable<String> secrets = const <String>[],
  String? fieldName,
}) {
  if (fieldName != null && _isSensitiveField(fieldName)) {
    return _redacted;
  }
  if (value is Map) {
    return <String, Object?>{
      for (final entry in value.entries)
        entry.key.toString(): sanitizePlaytestValue(
          entry.value,
          secrets: secrets,
          fieldName: entry.key.toString(),
        ),
    };
  }
  if (value is Iterable) {
    return value
        .map((item) => sanitizePlaytestValue(item, secrets: secrets))
        .toList(growable: false);
  }
  if (value is String) {
    return sanitizePlaytestString(value, secrets: secrets);
  }
  return value;
}

String sanitizePlaytestString(
  String value, {
  Iterable<String> secrets = const <String>[],
}) {
  var safe = value;
  for (final secret in secrets) {
    final trimmed = secret.trim();
    if (trimmed.length >= 4) {
      safe = safe.replaceAll(trimmed, _redacted);
    }
  }
  safe = safe.replaceAll(
    RegExp(r'Bearer\s+[A-Za-z0-9._~+/=-]+', caseSensitive: false),
    'Bearer $_redacted',
  );
  safe = safe.replaceAllMapped(
    RegExp(
      r'((?:api[_-]?key|authorization|access[_-]?token|refresh[_-]?token|password|client[_-]?secret)\s*[:=]\s*)[^\s,;}]+',
      caseSensitive: false,
    ),
    (match) => '${match.group(1)}$_redacted',
  );
  safe = safe.replaceAll(RegExp(r'/Users/[^/\s]+'), '/Users/<redacted>');
  safe = safe.replaceAll(
    RegExp(r'C:\\Users\\[^\\\s]+', caseSensitive: false),
    r'C:\Users\<redacted>',
  );
  return safe;
}

bool _isSensitiveField(String fieldName) {
  final normalized = fieldName.toLowerCase().replaceAll(
    RegExp(r'[^a-z0-9]'),
    '',
  );
  return const <String>{
    'apikey',
    'authorization',
    'accesstoken',
    'refreshtoken',
    'bearertoken',
    'password',
    'secret',
    'clientsecret',
  }.contains(normalized);
}
