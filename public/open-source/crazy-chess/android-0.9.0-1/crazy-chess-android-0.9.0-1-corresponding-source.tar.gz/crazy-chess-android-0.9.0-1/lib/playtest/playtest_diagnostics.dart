import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'playtest_sanitizer.dart';

@immutable
class PlaytestDiagnosticFile {
  const PlaytestDiagnosticFile({required this.name, required this.bytes});

  final String name;
  final Uint8List bytes;
}

abstract interface class PlaytestDiagnostics {
  Future<void> initialize();

  void record(
    String event, {
    String? message,
    Map<String, Object?> data = const <String, Object?>{},
  });

  Future<void> flush();

  Future<List<PlaytestDiagnosticFile>> snapshotFiles();
}

class MemoryPlaytestDiagnostics implements PlaytestDiagnostics {
  MemoryPlaytestDiagnostics({DateTime Function()? now})
    : _now = now ?? DateTime.now;

  final DateTime Function() _now;
  final List<String> _lines = <String>[];

  @override
  Future<void> initialize() async {}

  @override
  void record(
    String event, {
    String? message,
    Map<String, Object?> data = const <String, Object?>{},
  }) {
    _lines.add(
      jsonEncode(<String, Object?>{
        'timestamp': _now().toUtc().toIso8601String(),
        'event': event,
        if (message != null) 'message': sanitizePlaytestString(message),
        if (data.isNotEmpty) 'data': sanitizePlaytestValue(data),
      }),
    );
  }

  @override
  Future<void> flush() async {}

  @override
  Future<List<PlaytestDiagnosticFile>> snapshotFiles() async {
    if (_lines.isEmpty) return const <PlaytestDiagnosticFile>[];
    return <PlaytestDiagnosticFile>[
      PlaytestDiagnosticFile(
        name: 'session-memory.jsonl',
        bytes: Uint8List.fromList(utf8.encode('${_lines.join('\n')}\n')),
      ),
    ];
  }
}
