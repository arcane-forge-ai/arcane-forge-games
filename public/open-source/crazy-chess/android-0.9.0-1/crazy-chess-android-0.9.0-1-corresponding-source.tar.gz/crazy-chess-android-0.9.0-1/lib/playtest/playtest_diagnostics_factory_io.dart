import 'playtest_diagnostics.dart';
import 'playtest_diagnostics_io.dart';

PlaytestDiagnostics createPlaytestDiagnostics() => IoPlaytestDiagnostics();
