import 'dart:convert';

import 'package:archive/archive.dart' as zip;
import 'package:flutter/foundation.dart';

import '../living_campaign/living_campaign_archive_store.dart';
import '../living_campaign/living_campaign_migrations.dart';
import 'playtest_diagnostics.dart';
import 'playtest_sanitizer.dart';

abstract interface class PlaytestExportDestination {
  Future<String> write({required String fileName, required Uint8List bytes});
}

@immutable
class PlaytestDataExportResult {
  const PlaytestDataExportResult({
    required this.fileName,
    required this.filePath,
    required this.byteSize,
    required this.runCount,
    required this.metricsCount,
    required this.diagnosticFileCount,
  });

  final String fileName;
  final String filePath;
  final int byteSize;
  final int runCount;
  final int metricsCount;
  final int diagnosticFileCount;
}

class PlaytestExportException implements Exception {
  const PlaytestExportException(this.message);

  final String message;

  @override
  String toString() => message;
}

class PlaytestDataExporter {
  PlaytestDataExporter({
    required LivingCampaignArchiveStore archive,
    required PlaytestDiagnostics diagnostics,
    required PlaytestExportDestination destination,
    DateTime Function()? now,
    Iterable<String> Function()? secretsProvider,
  }) : _archive = archive,
       _diagnostics = diagnostics,
       _destination = destination,
       _now = now ?? DateTime.now,
       _secretsProvider = secretsProvider ?? _noSecrets;

  final LivingCampaignArchiveStore _archive;
  final PlaytestDiagnostics _diagnostics;
  final PlaytestExportDestination _destination;
  final DateTime Function() _now;
  final Iterable<String> Function() _secretsProvider;

  static Iterable<String> _noSecrets() => const <String>[];

  Future<PlaytestDataExportResult> export() async {
    final generatedAt = _now();
    _diagnostics.record('playtest_export_started');
    try {
      final bundle = await buildBundle(generatedAt: generatedAt);
      final filePath = await _destination.write(
        fileName: bundle.fileName,
        bytes: bundle.bytes,
      );
      _diagnostics.record(
        'playtest_export_completed',
        data: <String, Object?>{
          'fileName': bundle.fileName,
          'byteSize': bundle.bytes.length,
          'runCount': bundle.runCount,
          'metricsCount': bundle.metricsCount,
          'diagnosticFileCount': bundle.diagnosticFileCount,
        },
      );
      return PlaytestDataExportResult(
        fileName: bundle.fileName,
        filePath: filePath,
        byteSize: bundle.bytes.length,
        runCount: bundle.runCount,
        metricsCount: bundle.metricsCount,
        diagnosticFileCount: bundle.diagnosticFileCount,
      );
    } on Object catch (error) {
      _diagnostics.record('playtest_export_failed', message: error.toString());
      rethrow;
    }
  }

  @visibleForTesting
  Future<PlaytestDataBundle> buildBundle({DateTime? generatedAt}) async {
    final createdAt = generatedAt ?? _now();
    final secrets = _secretsProvider()
        .map((value) => value.trim())
        .where((value) => value.isNotEmpty)
        .toList(growable: false);
    await _archive.initialize();
    final summaries = await _archive.listRuns();
    final output = zip.Archive();
    final exportedRunIds = <String>[];
    final metricRunIds = <String>[];
    final skippedRunIds = <String>[];

    for (final summary in summaries) {
      try {
        final run = await _archive.readRun(summary.runId);
        if (run == null) {
          skippedRunIds.add(summary.runId);
          continue;
        }
        final encoded = sanitizePlaytestValue(
          LivingCampaignRunCodec.encode(run),
          secrets: secrets,
        );
        output.add(
          zip.ArchiveFile.string(
            'runs/${summary.runId}.json',
            '${_prettyJson(encoded)}\n',
          ),
        );
        exportedRunIds.add(summary.runId);

        final metrics = await _archive.readTimingMetrics(summary.runId);
        if (metrics != null) {
          output.add(
            zip.ArchiveFile.string(
              'metrics/${summary.runId}.json',
              '${_prettyJson(sanitizePlaytestValue(metrics.toJson(), secrets: secrets))}\n',
            ),
          );
          metricRunIds.add(summary.runId);
        }
      } on Object {
        skippedRunIds.add(summary.runId);
      }
    }

    await _diagnostics.flush();
    final diagnosticFiles = await _diagnostics.snapshotFiles();
    for (final diagnostic in diagnosticFiles) {
      final safeText = sanitizePlaytestString(
        utf8.decode(diagnostic.bytes, allowMalformed: true),
        secrets: secrets,
      );
      output.add(
        zip.ArchiveFile.string('diagnostics/${diagnostic.name}', safeText),
      );
    }

    final manifest = <String, Object?>{
      'format': 'crazy-chess-playtest-data',
      'formatVersion': 1,
      'generatedAt': createdAt.toUtc().toIso8601String(),
      'privacy': <String, Object?>{
        'localOnly': true,
        'automaticUpload': false,
        'campaignScriptsIncluded': true,
        'portraitsIncluded': false,
        'savedSettingsIncluded': false,
        'credentialsIncluded': false,
        'restorableBackup': false,
      },
      'runs': <String, Object?>{
        'count': exportedRunIds.length,
        'ids': exportedRunIds,
        'skippedIds': skippedRunIds,
      },
      'metrics': <String, Object?>{
        'count': metricRunIds.length,
        'runIds': metricRunIds,
      },
      'diagnostics': <String, Object?>{
        'fileCount': diagnosticFiles.length,
        'files': diagnosticFiles.map((file) => file.name).toList(),
        'scope':
            'Bounded local session, navigation, error, and opted-in '
            'Living AI diagnostics.',
      },
    };
    output.add(
      zip.ArchiveFile.string('manifest.json', '${_prettyJson(manifest)}\n'),
    );

    final bytes = zip.ZipEncoder().encodeBytes(
      output,
      modified: createdAt.toUtc(),
    );
    return PlaytestDataBundle(
      fileName: _fileName(createdAt),
      bytes: bytes,
      runCount: exportedRunIds.length,
      metricsCount: metricRunIds.length,
      diagnosticFileCount: diagnosticFiles.length,
    );
  }

  String _prettyJson(Object? value) =>
      const JsonEncoder.withIndent('  ').convert(value);

  String _fileName(DateTime value) {
    final local = value.toLocal();
    String two(int part) => part.toString().padLeft(2, '0');
    return 'crazy-chess-playtest-data-'
        '${local.year}${two(local.month)}${two(local.day)}-'
        '${two(local.hour)}${two(local.minute)}${two(local.second)}.zip';
  }
}

@visibleForTesting
@immutable
class PlaytestDataBundle {
  const PlaytestDataBundle({
    required this.fileName,
    required this.bytes,
    required this.runCount,
    required this.metricsCount,
    required this.diagnosticFileCount,
  });

  final String fileName;
  final Uint8List bytes;
  final int runCount;
  final int metricsCount;
  final int diagnosticFileCount;
}
