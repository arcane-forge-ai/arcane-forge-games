import 'package:flutter/foundation.dart';

import '../domain/chess_models.dart';
import '../l10n/runtime_game_locale.dart';
import '../l10n/localized_message.dart';

enum BattlefieldId {
  classic,
  verdantPastures,
  gildedBazaar,
  ruinedCauseway,
  chaosCrucible,
}

enum BattlefieldSpawnTypeMode { cycle, seededRandom }

enum SpecialTileType {
  knightShrine,
  treasureChest,
  diamondRing,
  visibleTrap,
  mystery,
}

enum BattlefieldEventType {
  tilesSpawned,
  knightPromotion,
  treasureFound,
  diamondRingFound,
  trapTriggered,
  mysteryTreasure,
  mysteryTrap,
  kingGuarded,
}

@immutable
class BattlefieldDefinition {
  const BattlefieldDefinition({
    required this.id,
    required String name,
    required String shortDescription,
    required String longDescription,
    required this.activeCapChoices,
    required this.spawnTypeCycle,
    this.spawnDelayChoices = const <int>[2, 3, 4],
    this.spawnOpeningPair = true,
    this.spawnTypeMode = BattlefieldSpawnTypeMode.cycle,
    required this.backgroundAsset,
    required this.boardAsset,
    required this.thumbnailAsset,
    required this.lightSquareAsset,
    required this.darkSquareAsset,
  }) : englishName = name,
       englishShortDescription = shortDescription,
       englishLongDescription = longDescription;

  final BattlefieldId id;
  final String englishName;
  final String englishShortDescription;
  final String englishLongDescription;
  final List<int> activeCapChoices;
  final List<SpecialTileType> spawnTypeCycle;
  final List<int> spawnDelayChoices;
  final bool spawnOpeningPair;
  final BattlefieldSpawnTypeMode spawnTypeMode;
  final String? backgroundAsset;
  final String? boardAsset;
  final String? thumbnailAsset;
  final String? lightSquareAsset;
  final String? darkSquareAsset;

  String get name => switch (id) {
    BattlefieldId.classic => RuntimeGameLocale.copy.battlefieldClassicCourt,
    BattlefieldId.verdantPastures =>
      RuntimeGameLocale.copy.battlefieldVerdantDominion,
    BattlefieldId.gildedBazaar =>
      RuntimeGameLocale.copy.battlefieldGildedExchange,
    BattlefieldId.ruinedCauseway =>
      RuntimeGameLocale.copy.battlefieldRuinedThrone,
    BattlefieldId.chaosCrucible =>
      RuntimeGameLocale.copy.battlefieldChaosCrucible,
  };

  String get shortDescription => switch (id) {
    BattlefieldId.classic => RuntimeGameLocale.copy.battlefieldClassicShort,
    BattlefieldId.verdantPastures =>
      RuntimeGameLocale.copy.battlefieldVerdantShort,
    BattlefieldId.gildedBazaar => RuntimeGameLocale.copy.battlefieldGildedShort,
    BattlefieldId.ruinedCauseway =>
      RuntimeGameLocale.copy.battlefieldRuinedShort,
    BattlefieldId.chaosCrucible => RuntimeGameLocale.copy.battlefieldChaosShort,
  };

  String get longDescription => switch (id) {
    BattlefieldId.classic => RuntimeGameLocale.copy.battlefieldClassicLong,
    BattlefieldId.verdantPastures =>
      RuntimeGameLocale.copy.battlefieldVerdantLong,
    BattlefieldId.gildedBazaar => RuntimeGameLocale.copy.battlefieldGildedLong,
    BattlefieldId.ruinedCauseway =>
      RuntimeGameLocale.copy.battlefieldRuinedLong,
    BattlefieldId.chaosCrucible => RuntimeGameLocale.copy.battlefieldChaosLong,
  };

  bool get hasMapEffects => spawnTypeCycle.isNotEmpty;

  String get spawnLaw {
    if (!hasMapEffects) {
      return RuntimeGameLocale.copy.battlefieldNoSpecialTiles;
    }
    final delay = spawnDelayChoices.length == 1
        ? RuntimeGameLocale.copy.battlefieldEveryActions(
            spawnDelayChoices.single,
          )
        : RuntimeGameLocale.copy.battlefieldEveryActionRange(
            spawnDelayChoices.reduce((a, b) => a < b ? a : b),
            spawnDelayChoices.reduce((a, b) => a > b ? a : b),
          );
    final opening = spawnOpeningPair
        ? RuntimeGameLocale.copy.battlefieldOpeningPair
        : '';
    final selection = spawnTypeMode == BattlefieldSpawnTypeMode.seededRandom
        ? RuntimeGameLocale.copy.battlefieldSeededRandomEffects
        : RuntimeGameLocale.copy.battlefieldSeededEffectOrder;
    return RuntimeGameLocale.copy.battlefieldSpawnLaw(
      opening,
      delay,
      selection,
    );
  }
}

const Map<BattlefieldId, BattlefieldDefinition>
battlefieldDefinitions = <BattlefieldId, BattlefieldDefinition>{
  BattlefieldId.classic: BattlefieldDefinition(
    id: BattlefieldId.classic,
    name: 'Classic Court',
    shortDescription: 'Pure Crazy Chess with no battlefield effects.',
    longDescription:
        'The familiar court. Only chess, merchants, contracts, and loyalty shape the match.',
    activeCapChoices: <int>[0],
    spawnTypeCycle: <SpecialTileType>[],
    backgroundAsset: null,
    boardAsset: null,
    thumbnailAsset: null,
    lightSquareAsset: null,
    darkSquareAsset: null,
  ),
  BattlefieldId.verdantPastures: BattlefieldDefinition(
    id: BattlefieldId.verdantPastures,
    name: 'Verdant Pastures',
    shortDescription: 'Knight shrines reshape every army.',
    longDescription:
        'Ancient riding stones transform any non-king piece that holds them into a knight.',
    activeCapChoices: <int>[2, 4],
    spawnTypeCycle: <SpecialTileType>[SpecialTileType.knightShrine],
    backgroundAsset: 'assets/runtime/battlefields/verdant/background.webp',
    boardAsset: 'assets/runtime/battlefields/verdant/board.webp',
    thumbnailAsset: 'assets/runtime/battlefields/verdant/thumbnail.webp',
    lightSquareAsset: null,
    darkSquareAsset: null,
  ),
  BattlefieldId.gildedBazaar: BattlefieldDefinition(
    id: BattlefieldId.gildedBazaar,
    name: 'Gilded Bazaar',
    shortDescription: 'Win gold and court-changing jewels.',
    longDescription:
        'Treasure chests swell a court treasury while Diamond Rings empower the next rolled offer to an enemy queen.',
    activeCapChoices: <int>[4, 6],
    spawnTypeCycle: <SpecialTileType>[
      SpecialTileType.treasureChest,
      SpecialTileType.diamondRing,
    ],
    backgroundAsset: 'assets/runtime/battlefields/gilded/background.webp',
    boardAsset: null,
    thumbnailAsset: 'assets/runtime/battlefields/gilded/thumbnail.webp',
    lightSquareAsset: null,
    darkSquareAsset: null,
  ),
  BattlefieldId.ruinedCauseway: BattlefieldDefinition(
    id: BattlefieldId.ruinedCauseway,
    name: 'Ruined Causeway',
    shortDescription: 'Visible hazards and dangerous unknowns.',
    longDescription:
        'Open traps are readable threats. Mystery tiles conceal an even chance of treasure or destruction.',
    activeCapChoices: <int>[6, 8],
    spawnTypeCycle: <SpecialTileType>[
      SpecialTileType.visibleTrap,
      SpecialTileType.mystery,
    ],
    backgroundAsset: 'assets/runtime/battlefields/ruined/background.webp',
    boardAsset: 'assets/runtime/battlefields/ruined/board.webp',
    thumbnailAsset: 'assets/runtime/battlefields/ruined/thumbnail.webp',
    lightSquareAsset: null,
    darkSquareAsset: null,
  ),
  BattlefieldId.chaosCrucible: BattlefieldDefinition(
    id: BattlefieldId.chaosCrucible,
    name: 'Chaos Crucible',
    shortDescription: 'Every special tile can enter the fray.',
    longDescription:
        'The Crucible begins dormant, then tears open every third completed action. Each mirrored eruption draws one seeded-random effect from the full battlefield arsenal.',
    activeCapChoices: <int>[8],
    spawnTypeCycle: <SpecialTileType>[
      SpecialTileType.knightShrine,
      SpecialTileType.treasureChest,
      SpecialTileType.diamondRing,
      SpecialTileType.visibleTrap,
      SpecialTileType.mystery,
    ],
    spawnDelayChoices: <int>[3],
    spawnOpeningPair: false,
    spawnTypeMode: BattlefieldSpawnTypeMode.seededRandom,
    backgroundAsset:
        'assets/runtime/battlefields/chaos_crucible/background.webp',
    boardAsset: 'assets/runtime/battlefields/chaos_crucible/board.webp',
    thumbnailAsset: 'assets/runtime/battlefields/chaos_crucible/thumbnail.webp',
    lightSquareAsset: null,
    darkSquareAsset: null,
  ),
};

int chargeRequiredFor(SpecialTileType type) {
  return switch (type) {
    SpecialTileType.knightShrine => 3,
    SpecialTileType.treasureChest => 2,
    SpecialTileType.diamondRing => 3,
    SpecialTileType.visibleTrap => 2,
    SpecialTileType.mystery => 2,
  };
}

String specialTileLabel(SpecialTileType type) {
  return switch (type) {
    SpecialTileType.knightShrine => RuntimeGameLocale.copy.tileKnightShrine,
    SpecialTileType.treasureChest => RuntimeGameLocale.copy.tileTreasureChest,
    SpecialTileType.diamondRing => RuntimeGameLocale.copy.tileDiamondRing,
    SpecialTileType.visibleTrap => RuntimeGameLocale.copy.tileTrap,
    SpecialTileType.mystery => RuntimeGameLocale.copy.tileMystery,
  };
}

@immutable
class SpecialTileState {
  const SpecialTileState({
    required this.square,
    required this.type,
    required this.pairId,
    this.progress = 0,
    this.occupantPieceId,
    this.occupantTurnMask = 0,
  });

  final Square square;
  final SpecialTileType type;
  final int pairId;
  final int progress;
  final String? occupantPieceId;
  final int occupantTurnMask;

  int get chargeRequired => chargeRequiredFor(type);

  SpecialTileState copyWith({
    int? progress,
    String? occupantPieceId,
    int? occupantTurnMask,
    bool clearOccupant = false,
  }) {
    return SpecialTileState(
      square: square,
      type: type,
      pairId: pairId,
      progress: progress ?? this.progress,
      occupantPieceId: clearOccupant
          ? null
          : occupantPieceId ?? this.occupantPieceId,
      occupantTurnMask: clearOccupant
          ? 0
          : occupantTurnMask ?? this.occupantTurnMask,
    );
  }
}

@immutable
class BattlefieldResolution {
  const BattlefieldResolution({
    required this.square,
    required this.sourceType,
    required this.resolvedType,
    required this.pieceId,
    required this.pieceColor,
    this.goldAmount = 0,
  });

  final Square square;
  final SpecialTileType sourceType;
  final SpecialTileType resolvedType;
  final String pieceId;
  final PieceColor pieceColor;
  final int goldAmount;

  bool get cameFromMystery => sourceType == SpecialTileType.mystery;
}

@immutable
class BattlefieldAdvanceResult {
  const BattlefieldAdvanceResult({
    this.spawnedTiles = const <SpecialTileState>[],
    this.resolutions = const <BattlefieldResolution>[],
  });

  final List<SpecialTileState> spawnedTiles;
  final List<BattlefieldResolution> resolutions;
}

@immutable
class BattlefieldEvent {
  const BattlefieldEvent({
    required this.serial,
    required this.type,
    required this.message,
    this.messageRecord,
    this.square,
    this.tileType,
    this.pieceColor,
    this.pieceId,
    this.goldAmount = 0,
  });

  final int serial;
  final BattlefieldEventType type;
  final String message;
  final LocalizedMessageRecord? messageRecord;
  String get localizedMessage =>
      (messageRecord ?? LocalizedMessageRecord.fromEnglish(message)).resolve();
  final Square? square;
  final SpecialTileType? tileType;
  final PieceColor? pieceColor;
  final String? pieceId;
  final int goldAmount;
}
