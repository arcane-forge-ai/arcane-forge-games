import 'dart:math' as math;

import '../domain/chess_models.dart';
import 'battlefield_models.dart';

class BattlefieldRuntime {
  BattlefieldRuntime({required this.definition, required this.seed})
    : _random = math.Random(seed),
      activeCap =
          definition.activeCapChoices[math.Random(
            seed ^ 0x5f3759df,
          ).nextInt(definition.activeCapChoices.length)];

  final BattlefieldDefinition definition;
  final int seed;
  final int activeCap;
  final math.Random _random;
  final List<SpecialTileState> _tiles = <SpecialTileState>[];

  int _pairSerial = 0;
  int _spawnCycleIndex = 0;
  int _actionsUntilSpawn = 0;

  List<SpecialTileState> get tiles =>
      List<SpecialTileState>.unmodifiable(_tiles);

  List<SpecialTileState> initialize(List<List<ChessPiece?>> board) {
    _tiles.clear();
    _pairSerial = 0;
    _spawnCycleIndex = 0;
    if (!definition.hasMapEffects || activeCap == 0) {
      _actionsUntilSpawn = 0;
      return const <SpecialTileState>[];
    }
    final spawned = definition.spawnOpeningPair
        ? _spawnMirroredPair(board)
        : const <SpecialTileState>[];
    _actionsUntilSpawn = _nextSpawnDelay();
    return List<SpecialTileState>.unmodifiable(spawned);
  }

  BattlefieldAdvanceResult advance(
    List<List<ChessPiece?>> board, {
    PieceColor actingSide = PieceColor.white,
  }) {
    if (!definition.hasMapEffects) {
      return const BattlefieldAdvanceResult();
    }

    final resolutions = <BattlefieldResolution>[];
    final survivors = <SpecialTileState>[];
    for (final tile in _tiles) {
      final piece = board[tile.square.row][tile.square.col];
      if (piece == null) {
        survivors.add(tile.copyWith(progress: 0, clearOccupant: true));
        continue;
      }

      final isSameOccupant = tile.occupantPieceId == piece.id;
      final isRoundTimed =
          tile.type == SpecialTileType.visibleTrap ||
          tile.type == SpecialTileType.mystery;
      var progress = isSameOccupant ? tile.progress : 0;
      var turnMask = isSameOccupant ? tile.occupantTurnMask : 0;
      if (isRoundTimed) {
        turnMask |= actingSide == PieceColor.white ? 1 : 2;
        if (turnMask == 3) {
          progress++;
          turnMask = 0;
        }
      } else {
        progress++;
      }
      if (progress < tile.chargeRequired) {
        survivors.add(
          tile.copyWith(
            progress: progress,
            occupantPieceId: piece.id,
            occupantTurnMask: turnMask,
          ),
        );
        continue;
      }

      var resolvedType = tile.type;
      if (tile.type == SpecialTileType.mystery) {
        resolvedType = _random.nextBool()
            ? SpecialTileType.visibleTrap
            : SpecialTileType.treasureChest;
      }
      final goldAmount = resolvedType == SpecialTileType.treasureChest
          ? 8 + _random.nextInt(43)
          : 0;
      resolutions.add(
        BattlefieldResolution(
          square: tile.square,
          sourceType: tile.type,
          resolvedType: resolvedType,
          pieceId: piece.id,
          pieceColor: piece.color,
          goldAmount: goldAmount,
        ),
      );
    }
    _tiles
      ..clear()
      ..addAll(survivors);

    final spawned = <SpecialTileState>[];
    if (_tiles.length < activeCap) {
      _actionsUntilSpawn--;
      if (_actionsUntilSpawn <= 0) {
        spawned.addAll(_spawnMirroredPair(board));
        _actionsUntilSpawn = spawned.isEmpty ? 1 : _nextSpawnDelay();
      }
    }

    return BattlefieldAdvanceResult(
      spawnedTiles: List<SpecialTileState>.unmodifiable(spawned),
      resolutions: List<BattlefieldResolution>.unmodifiable(resolutions),
    );
  }

  SpecialTileState? tileAt(Square square) {
    for (final tile in _tiles) {
      if (tile.square == square) {
        return tile;
      }
    }
    return null;
  }

  void replaceTiles(Iterable<SpecialTileState> tiles) {
    _tiles
      ..clear()
      ..addAll(tiles);
  }

  List<SpecialTileState> _spawnMirroredPair(List<List<ChessPiece?>> board) {
    if (_tiles.length + 2 > activeCap) {
      return const <SpecialTileState>[];
    }

    final candidates = <Square>[];
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final square = Square(row, col);
        final mirror = mirroredSquare(square);
        if (_compareSquares(square, mirror) >= 0 ||
            board[row][col] != null ||
            board[mirror.row][mirror.col] != null ||
            tileAt(square) != null ||
            tileAt(mirror) != null) {
          continue;
        }
        candidates.add(square);
      }
    }
    if (candidates.isEmpty) {
      return const <SpecialTileState>[];
    }

    final square = candidates[_random.nextInt(candidates.length)];
    final mirror = mirroredSquare(square);
    final type = switch (definition.spawnTypeMode) {
      BattlefieldSpawnTypeMode.cycle =>
        definition.spawnTypeCycle[_spawnCycleIndex %
            definition.spawnTypeCycle.length],
      BattlefieldSpawnTypeMode.seededRandom =>
        definition.spawnTypeCycle[_random.nextInt(
          definition.spawnTypeCycle.length,
        )],
    };
    _spawnCycleIndex++;
    _pairSerial++;
    final pair = <SpecialTileState>[
      SpecialTileState(square: square, type: type, pairId: _pairSerial),
      SpecialTileState(square: mirror, type: type, pairId: _pairSerial),
    ];
    _tiles.addAll(pair);
    return pair;
  }

  int _nextSpawnDelay() {
    final delays = definition.spawnDelayChoices;
    return delays[_random.nextInt(delays.length)];
  }

  int _compareSquares(Square a, Square b) {
    final first = a.row * 8 + a.col;
    final second = b.row * 8 + b.col;
    return first.compareTo(second);
  }
}

Square mirroredSquare(Square square) {
  return Square(7 - square.row, 7 - square.col);
}
