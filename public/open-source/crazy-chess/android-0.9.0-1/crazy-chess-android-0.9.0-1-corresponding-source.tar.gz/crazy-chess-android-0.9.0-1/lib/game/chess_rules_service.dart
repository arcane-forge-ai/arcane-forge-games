import '../domain/chess_models.dart';

/// Pure chess movement and attack geometry shared by duel and arcade modes.
///
/// Castling remains a duel-controller responsibility because it depends on
/// match history and king-check state. En passant can be enabled explicitly
/// for normal matches and is disabled by Last Piece Standing.
class ChessRulesService {
  const ChessRulesService();

  List<ChessMove> pseudoMoves({
    required List<List<ChessPiece?>> board,
    required Square from,
    Square? enPassantSquare,
    bool allowEnPassant = false,
  }) {
    final piece = pieceAt(board, from);
    if (piece == null) {
      return const <ChessMove>[];
    }
    return switch (piece.type) {
      PieceType.pawn => _pawnMoves(
        board,
        from,
        piece,
        enPassantSquare: enPassantSquare,
        allowEnPassant: allowEnPassant,
      ),
      PieceType.knight => _jumpMoves(board, from, piece, _knightOffsets),
      PieceType.bishop => _slideMoves(board, from, piece, _bishopDirections),
      PieceType.rook => _slideMoves(board, from, piece, _rookDirections),
      PieceType.queen => _slideMoves(board, from, piece, _queenDirections),
      PieceType.king => _jumpMoves(board, from, piece, _kingOffsets),
    };
  }

  bool isSquareAttacked({
    required List<List<ChessPiece?>> board,
    required Square square,
    required PieceColor byColor,
  }) {
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final piece = board[row][col];
        if (piece == null || piece.color != byColor) {
          continue;
        }
        if (pieceAttacks(
          board: board,
          from: Square(row, col),
          target: square,
        )) {
          return true;
        }
      }
    }
    return false;
  }

  bool pieceAttacks({
    required List<List<ChessPiece?>> board,
    required Square from,
    required Square target,
  }) {
    final piece = pieceAt(board, from);
    if (piece == null) {
      return false;
    }
    return switch (piece.type) {
      PieceType.pawn =>
        target.row == from.row + (piece.color == PieceColor.white ? -1 : 1) &&
            (target.col - from.col).abs() == 1,
      PieceType.knight => _matchesJump(from, target, _knightOffsets),
      PieceType.king => _matchesJump(from, target, _kingOffsets),
      PieceType.bishop => _slideAttacks(board, from, target, _bishopDirections),
      PieceType.rook => _slideAttacks(board, from, target, _rookDirections),
      PieceType.queen => _slideAttacks(board, from, target, _queenDirections),
    };
  }

  ChessPiece? pieceAt(List<List<ChessPiece?>> board, Square square) {
    if (!isBoardSquare(square)) {
      return null;
    }
    return board[square.row][square.col];
  }

  bool isBoardSquare(Square square) =>
      square.row >= 0 && square.row < 8 && square.col >= 0 && square.col < 8;

  List<ChessMove> _pawnMoves(
    List<List<ChessPiece?>> board,
    Square from,
    ChessPiece piece, {
    required Square? enPassantSquare,
    required bool allowEnPassant,
  }) {
    final moves = <ChessMove>[];
    final direction = piece.color == PieceColor.white ? -1 : 1;
    final startRow = piece.color == PieceColor.white ? 6 : 1;
    final promotionRow = piece.color == PieceColor.white ? 0 : 7;
    final one = Square(from.row + direction, from.col);
    if (isBoardSquare(one) && pieceAt(board, one) == null) {
      moves.add(
        ChessMove(from: from, to: one, isPromotion: one.row == promotionRow),
      );
      final two = Square(from.row + direction * 2, from.col);
      if (from.row == startRow &&
          isBoardSquare(two) &&
          pieceAt(board, two) == null) {
        moves.add(ChessMove(from: from, to: two));
      }
    }
    for (final columnDelta in const <int>[-1, 1]) {
      final target = Square(from.row + direction, from.col + columnDelta);
      if (!isBoardSquare(target)) {
        continue;
      }
      final occupant = pieceAt(board, target);
      if (occupant != null && occupant.color != piece.color) {
        moves.add(
          ChessMove(
            from: from,
            to: target,
            isCapture: true,
            isPromotion: target.row == promotionRow,
          ),
        );
        continue;
      }
      if (!allowEnPassant || enPassantSquare != target) {
        continue;
      }
      final adjacent = pieceAt(board, Square(from.row, target.col));
      if (adjacent != null &&
          adjacent.color != piece.color &&
          adjacent.type == PieceType.pawn) {
        moves.add(
          ChessMove(from: from, to: target, isCapture: true, isEnPassant: true),
        );
      }
    }
    return moves;
  }

  List<ChessMove> _jumpMoves(
    List<List<ChessPiece?>> board,
    Square from,
    ChessPiece piece,
    List<Square> offsets,
  ) {
    final moves = <ChessMove>[];
    for (final offset in offsets) {
      final to = Square(from.row + offset.row, from.col + offset.col);
      if (!isBoardSquare(to)) {
        continue;
      }
      final occupant = pieceAt(board, to);
      if (occupant == null) {
        moves.add(ChessMove(from: from, to: to));
      } else if (occupant.color != piece.color) {
        moves.add(ChessMove(from: from, to: to, isCapture: true));
      }
    }
    return moves;
  }

  List<ChessMove> _slideMoves(
    List<List<ChessPiece?>> board,
    Square from,
    ChessPiece piece,
    List<Square> directions,
  ) {
    final moves = <ChessMove>[];
    for (final direction in directions) {
      var row = from.row + direction.row;
      var col = from.col + direction.col;
      while (isBoardSquare(Square(row, col))) {
        final to = Square(row, col);
        final occupant = pieceAt(board, to);
        if (occupant == null) {
          moves.add(ChessMove(from: from, to: to));
        } else {
          if (occupant.color != piece.color) {
            moves.add(ChessMove(from: from, to: to, isCapture: true));
          }
          break;
        }
        row += direction.row;
        col += direction.col;
      }
    }
    return moves;
  }

  bool _matchesJump(Square from, Square target, List<Square> offsets) {
    return offsets.any(
      (offset) =>
          target.row == from.row + offset.row &&
          target.col == from.col + offset.col,
    );
  }

  bool _slideAttacks(
    List<List<ChessPiece?>> board,
    Square from,
    Square target,
    List<Square> directions,
  ) {
    for (final direction in directions) {
      var row = from.row + direction.row;
      var col = from.col + direction.col;
      while (isBoardSquare(Square(row, col))) {
        final square = Square(row, col);
        if (square == target) {
          return true;
        }
        if (pieceAt(board, square) != null) {
          break;
        }
        row += direction.row;
        col += direction.col;
      }
    }
    return false;
  }

  static const _knightOffsets = <Square>[
    Square(-2, -1),
    Square(-2, 1),
    Square(-1, -2),
    Square(-1, 2),
    Square(1, -2),
    Square(1, 2),
    Square(2, -1),
    Square(2, 1),
  ];
  static const _kingOffsets = <Square>[
    Square(-1, -1),
    Square(-1, 0),
    Square(-1, 1),
    Square(0, -1),
    Square(0, 1),
    Square(1, -1),
    Square(1, 0),
    Square(1, 1),
  ];
  static const _bishopDirections = <Square>[
    Square(-1, -1),
    Square(-1, 1),
    Square(1, -1),
    Square(1, 1),
  ];
  static const _rookDirections = <Square>[
    Square(-1, 0),
    Square(1, 0),
    Square(0, -1),
    Square(0, 1),
  ];
  static const _queenDirections = <Square>[
    ..._bishopDirections,
    ..._rookDirections,
  ];
}
