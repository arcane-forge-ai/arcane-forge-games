import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../battlefield/battlefield_models.dart';
import '../battlefield/battlefield_runtime.dart';
import '../domain/board_presentation.dart';
import '../domain/chess_models.dart';
import '../domain/countries.dart';
import '../domain/economy_config.dart';
import '../domain/game_position_snapshot.dart';
import '../l10n/localized_message.dart';
import 'chess_board_ops.dart';
import 'chess_rules_service.dart';
import 'game_controller_rules.dart';
import 'scenario_setup.dart';

enum AiRedeployResolution {
  noPendingPurchase,
  inPlace,
  normal,
  immediateCheckRelaxed,
  originalSquare,
  cancelledAndRefunded,
}

class GameController extends ChangeNotifier {
  GameController({math.Random? random, int? battlefieldSeed})
    : _random = random ?? math.Random(),
      _fixedBattlefieldSeed = battlefieldSeed {
    _resetBoardStorage();
  }

  final math.Random _random;
  static const ChessBoardOps _boardOps = ChessBoardOps();
  static const ChessRulesService _chessRules = ChessRulesService();
  final int? _fixedBattlefieldSeed;
  late List<List<ChessPiece?>> board;
  GamePhase phase = GamePhase.setup;
  PieceColor turn = PieceColor.white;
  int turnCount = 1;
  int completedActionCount = 0;
  int completedRoundCount = 0;
  String setupWhiteCountryId = 'mercantile';
  String setupBlackCountryId = 'iron';
  OpponentMode setupOpponentMode = OpponentMode.local;
  BattlefieldId setupBattlefieldId = BattlefieldId.classic;
  int setupMerchantSpeed = 4;
  int setupStartingGold = 10;
  int setupMerchantPayout = 8;
  late String whiteCountryId;
  late String blackCountryId;
  OpponentMode opponentMode = OpponentMode.local;
  BattlefieldId battlefieldId = BattlefieldId.classic;
  final Map<PieceColor, int> gold = {PieceColor.white: 0, PieceColor.black: 0};
  final Map<PieceColor, int> diamondRingTokens = {
    PieceColor.white: 0,
    PieceColor.black: 0,
  };
  int merchantPosition = 8;
  int merchantDirection = 1;
  int merchantSpeed = 4;
  int merchantPayout = 8;
  Square? selectedSquare;
  Square? offerTarget;
  int offerGold = 6;
  String? offerError;
  ChessPiece? redeployPiece;
  Square? redeployOriginalSquare;
  Square? pendingRedeploySquare;
  int merchantPayoutPulseSerial = 0;
  PieceColor? lastMerchantPayoutReceiver;
  Square? pendingPromotionSquare;
  PieceColor? winner;
  bool stalemate = false;
  GameEndReason gameEndReason = GameEndReason.none;
  OfferResult? lastOfferResult;
  final List<LocalizedMessageRecord> _eventMessages =
      <LocalizedMessageRecord>[];
  final List<LocalizedMessageRecord> _fullEventMessages =
      <LocalizedMessageRecord>[];
  List<LocalizedMessageRecord> get eventMessages =>
      List.unmodifiable(_eventMessages);
  List<String> get eventLog =>
      List.unmodifiable(_eventMessages.map((message) => message.debugEnglish));
  List<String> get localizedEventLog =>
      List.unmodifiable(_eventMessages.map((message) => message.resolve()));
  List<String> get fullEventLog => List.unmodifiable(
    _fullEventMessages.map((message) => message.debugEnglish),
  );
  final List<String> capturedByWhite = <String>[];
  final List<String> capturedByBlack = <String>[];
  String? sameTurnRevealTargetId;
  bool spyRevealUsedThisTurn = false;
  int purchaseSuccesses = 0;
  int purchaseFailures = 0;
  BattlefieldEvent? lastBattlefieldEvent;
  int battlefieldEventSerial = 0;
  int? activeBattlefieldSeed;
  BoardMotionEvent? lastBoardMotionEvent;
  BetrayalTransformEvent? lastBetrayalTransformEvent;
  AiRedeployResolution? lastAiRedeployResolution;
  String? lastCancelledPurchasePieceId;
  String? activeScenarioId;
  String? lastCapturedCharacterId;
  bool economyEnabled = true;
  bool merchantEnabled = true;
  bool specialTilesEnabled = true;

  Square? _enPassantSquare;
  BattlefieldRuntime? _battlefieldRuntime;
  BetrayalTransformEvent? _pendingBetrayalTransformEvent;
  ChessPiece? _redeployOriginalPiece;
  int _redeployPaidGold = 0;
  PieceColor? _redeployBuyer;
  int _presentationSerial = 0;
  int _completedRoundSideMask = 0;
  final Map<PieceColor, bool> _sunlitBishopCycleArmed = {
    PieceColor.white: false,
    PieceColor.black: false,
  };
  Map<PieceColor, int>? _pendingSunlitBishopCounts;

  CountryConfig get whiteCountry => countries[whiteCountryId]!;
  CountryConfig get blackCountry => countries[blackCountryId]!;
  CountryConfig get activeCountry => countryForColor(turn);
  CountryConfig get inactiveCountry => countryForColor(opponent(turn));
  bool get activeKingInCheck => isKingInCheck(turn);
  Square? get enPassantSquare => _enPassantSquare;
  BattlefieldDefinition get battlefield =>
      battlefieldDefinitions[battlefieldId]!;
  BattlefieldDefinition get setupBattlefield =>
      battlefieldDefinitions[setupBattlefieldId]!;
  List<SpecialTileState> get specialTiles =>
      _battlefieldRuntime?.tiles ?? const <SpecialTileState>[];
  GameEndReason get resolvedGameEndReason {
    if (stalemate) {
      return GameEndReason.stalemate;
    }
    if (gameEndReason != GameEndReason.none) {
      return gameEndReason;
    }
    return winner == null ? GameEndReason.none : GameEndReason.checkmate;
  }

  void setSetupCountry(PieceColor color, String countryId) {
    if (color == PieceColor.white) {
      setupWhiteCountryId = countryId;
    } else {
      setupBlackCountryId = countryId;
    }
    notifyListeners();
  }

  void setMerchantSpeed(int value) {
    setupMerchantSpeed = value.clamp(1, 8);
    notifyListeners();
  }

  void setStartingGold(int value) {
    setupStartingGold = switch (value) {
      6 || 10 || 14 => value,
      _ => 10,
    };
    notifyListeners();
  }

  void setMerchantPayout(int value) {
    setupMerchantPayout = switch (value) {
      4 || 8 || 12 => value,
      _ => 8,
    };
    notifyListeners();
  }

  void setOpponentMode(OpponentMode value) {
    setupOpponentMode = value;
    notifyListeners();
  }

  void setBattlefield(BattlefieldId value) {
    setupBattlefieldId = value;
    notifyListeners();
  }

  void startNewGame() {
    activeScenarioId = null;
    economyEnabled = true;
    merchantEnabled = true;
    specialTilesEnabled = true;
    whiteCountryId = setupWhiteCountryId;
    blackCountryId = setupBlackCountryId;
    opponentMode = setupOpponentMode;
    battlefieldId = setupBattlefieldId;
    merchantSpeed = setupMerchantSpeed;
    merchantPayout = setupMerchantPayout;
    merchantPosition = 8;
    merchantDirection = 1;
    merchantPayoutPulseSerial = 0;
    lastMerchantPayoutReceiver = null;
    turn = PieceColor.white;
    turnCount = 1;
    completedActionCount = 0;
    completedRoundCount = 0;
    _completedRoundSideMask = 0;
    phase = GamePhase.playing;
    selectedSquare = null;
    offerTarget = null;
    redeployPiece = null;
    redeployOriginalSquare = null;
    pendingRedeploySquare = null;
    pendingPromotionSquare = null;
    winner = null;
    stalemate = false;
    gameEndReason = GameEndReason.none;
    lastOfferResult = null;
    sameTurnRevealTargetId = null;
    spyRevealUsedThisTurn = false;
    purchaseSuccesses = 0;
    purchaseFailures = 0;
    lastBattlefieldEvent = null;
    battlefieldEventSerial = 0;
    lastBoardMotionEvent = null;
    lastBetrayalTransformEvent = null;
    lastAiRedeployResolution = null;
    lastCancelledPurchasePieceId = null;
    _pendingBetrayalTransformEvent = null;
    _redeployOriginalPiece = null;
    _redeployPaidGold = 0;
    _redeployBuyer = null;
    _pendingSunlitBishopCounts = null;
    capturedByWhite.clear();
    capturedByBlack.clear();
    _eventMessages.clear();
    _fullEventMessages.clear();
    gold[PieceColor.white] = math.max(
      0,
      setupStartingGold + whiteCountry.startingGoldModifier,
    );
    gold[PieceColor.black] = math.max(
      0,
      setupStartingGold + blackCountry.startingGoldModifier,
    );
    diamondRingTokens[PieceColor.white] = 0;
    diamondRingTokens[PieceColor.black] = 0;
    _enPassantSquare = null;
    _resetBoardStorage();
    _setupSide(PieceColor.black, 0, 1, blackCountryId);
    _setupSide(PieceColor.white, 7, 6, whiteCountryId);
    _initializeSunlitBishopCycles();
    activeBattlefieldSeed =
        _fixedBattlefieldSeed ?? _random.nextInt(0x7fffffff);
    _battlefieldRuntime = BattlefieldRuntime(
      definition: battlefield,
      seed: activeBattlefieldSeed!,
    );
    final openingTiles = _battlefieldRuntime!.initialize(board);
    _log(
      'Match started: ${whiteCountry.name} vs ${blackCountry.name} on ${battlefield.name}. Merchant speed $merchantSpeed.',
    );
    if (openingTiles.isNotEmpty) {
      _recordBattlefieldEvent(
        BattlefieldEventType.tilesSpawned,
        '${battlefield.name} awakened with ${openingTiles.length} special tiles.',
      );
    }
    notifyListeners();
  }

  /// Starts a deterministic authored position without changing ordinary duel
  /// setup. Story Mode owns progression and objective evaluation separately.
  void startScenario(ScenarioGameSetup setup) {
    activeScenarioId = setup.id;
    whiteCountryId = setup.whiteCountryId;
    blackCountryId = setup.blackCountryId;
    opponentMode = OpponentMode.local;
    battlefieldId = setup.battlefieldId;
    merchantSpeed = setup.merchantSpeed;
    merchantPayout = setup.merchantPayout;
    merchantPosition = 8;
    merchantDirection = 1;
    merchantPayoutPulseSerial = 0;
    lastMerchantPayoutReceiver = null;
    turn = setup.turn;
    turnCount = 1;
    completedActionCount = 0;
    completedRoundCount = 0;
    _completedRoundSideMask = 0;
    phase = GamePhase.playing;
    selectedSquare = null;
    offerTarget = null;
    redeployPiece = null;
    redeployOriginalSquare = null;
    pendingRedeploySquare = null;
    pendingPromotionSquare = null;
    winner = null;
    stalemate = false;
    gameEndReason = GameEndReason.none;
    lastOfferResult = null;
    sameTurnRevealTargetId = null;
    spyRevealUsedThisTurn = false;
    purchaseSuccesses = 0;
    purchaseFailures = 0;
    lastBattlefieldEvent = null;
    battlefieldEventSerial = 0;
    lastBoardMotionEvent = null;
    lastBetrayalTransformEvent = null;
    lastAiRedeployResolution = null;
    lastCancelledPurchasePieceId = null;
    lastCapturedCharacterId = null;
    _pendingBetrayalTransformEvent = null;
    _redeployOriginalPiece = null;
    _redeployPaidGold = 0;
    _redeployBuyer = null;
    _pendingSunlitBishopCounts = null;
    capturedByWhite.clear();
    capturedByBlack.clear();
    _eventMessages.clear();
    _fullEventMessages.clear();
    economyEnabled = setup.economyEnabled;
    merchantEnabled = setup.merchantEnabled;
    specialTilesEnabled = setup.specialTilesEnabled;
    gold[PieceColor.white] = setup.whiteGold;
    gold[PieceColor.black] = setup.blackGold;
    diamondRingTokens[PieceColor.white] = 0;
    diamondRingTokens[PieceColor.black] = 0;
    _enPassantSquare = null;
    _resetBoardStorage();
    for (final placement in setup.pieces) {
      board[placement.square.row][placement.square.col] = placement.piece
          .copy();
    }
    _initializeSunlitBishopCycles();
    activeBattlefieldSeed = setup.battlefieldSeed;
    _battlefieldRuntime = BattlefieldRuntime(
      definition: battlefield,
      seed: activeBattlefieldSeed!,
    );
    final openingTiles = specialTilesEnabled
        ? _battlefieldRuntime!.initialize(board)
        : const <SpecialTileState>[];
    if (setup.authoredTiles.isNotEmpty) {
      _battlefieldRuntime!.replaceTiles(setup.authoredTiles);
    }
    _log(
      'Scenario ${setup.id} started on ${battlefield.name}. '
      '${setup.pieces.length} authored pieces loaded.',
    );
    if (openingTiles.isNotEmpty || setup.authoredTiles.isNotEmpty) {
      _recordBattlefieldEvent(
        BattlefieldEventType.tilesSpawned,
        '${battlefield.name} awakened with ${specialTiles.length} special tiles.',
      );
    }
    notifyListeners();
  }

  void returnToSetup() {
    phase = GamePhase.setup;
    notifyListeners();
  }

  void dismissLastOfferResult() {
    if (lastOfferResult?.success == true &&
        _pendingBetrayalTransformEvent != null) {
      lastBetrayalTransformEvent = _pendingBetrayalTransformEvent!.withSerial(
        ++_presentationSerial,
      );
      _pendingBetrayalTransformEvent = null;
    }
    lastOfferResult = null;
    notifyListeners();
  }

  void _resetBoardStorage() {
    board = List<List<ChessPiece?>>.generate(
      8,
      (_) => List<ChessPiece?>.filled(8, null),
    );
  }

  void _setupSide(
    PieceColor color,
    int backRank,
    int pawnRank,
    String countryId,
  ) {
    const order = <PieceType>[
      PieceType.rook,
      PieceType.knight,
      PieceType.bishop,
      PieceType.queen,
      PieceType.king,
      PieceType.bishop,
      PieceType.knight,
      PieceType.rook,
    ];
    for (var col = 0; col < 8; col++) {
      board[backRank][col] = _createPiece(
        order[col],
        color,
        countryId,
        '$countryId-${color.name}-back-$col',
      );
      board[pawnRank][col] = _createPiece(
        PieceType.pawn,
        color,
        countryId,
        '$countryId-${color.name}-pawn-$col',
      );
    }
  }

  ChessPiece _createPiece(
    PieceType type,
    PieceColor color,
    String countryId,
    String seed,
  ) {
    return ChessPiece(
      id: '$seed-${_random.nextInt(999999)}',
      type: type,
      color: color,
      countryId: countryId,
      loyalty: randomStartingLoyalty(countryId, type, _random),
      fairPrice: randomFairPrice(type, _random),
    );
  }

  CountryConfig countryForColor(PieceColor color) {
    return countries[color == PieceColor.white
        ? whiteCountryId
        : blackCountryId]!;
  }

  PieceColor opponent(PieceColor color) {
    return color == PieceColor.white ? PieceColor.black : PieceColor.white;
  }

  ChessPiece? pieceAt(Square square) => board[square.row][square.col];

  SpecialTileState? specialTileAt(Square square) {
    return _battlefieldRuntime?.tileAt(square);
  }

  bool isSpecialTile(Square square) => specialTileAt(square) != null;

  @visibleForTesting
  void replaceSpecialTilesForTesting(Iterable<SpecialTileState> tiles) {
    _battlefieldRuntime?.replaceTiles(tiles);
  }

  GamePositionSnapshot positionSnapshot() {
    return GamePositionSnapshot(
      board: [
        for (final row in board)
          [
            for (final piece in row)
              if (piece == null)
                null
              else
                PositionPiece(
                  type: piece.type,
                  color: piece.color,
                  hasMoved: piece.hasMoved,
                ),
          ],
      ],
      turn: turn,
      turnCount: turnCount,
      enPassantSquare: _enPassantSquare,
    );
  }

  void tapSquare(Square square) {
    if (phase == GamePhase.redeploy) {
      previewRedeploy(square);
      return;
    }
    if (phase != GamePhase.playing) {
      return;
    }

    final legal = selectedLegalMoves;
    for (final move in legal) {
      if (move.to == square) {
        makeMove(move);
        return;
      }
    }

    final piece = pieceAt(square);
    if (piece == null) {
      selectedSquare = null;
      offerTarget = null;
    } else {
      selectedSquare = square;
      offerTarget = null;
    }
    notifyListeners();
  }

  List<ChessMove> get selectedLegalMoves {
    final square = selectedSquare;
    if (square == null || phase != GamePhase.playing) {
      return const <ChessMove>[];
    }
    final piece = pieceAt(square);
    if (piece == null || piece.color != turn) {
      return const <ChessMove>[];
    }
    return legalMovesFrom(square);
  }

  void openOfferForSelected() {
    if (!economyEnabled) {
      return;
    }
    final square = selectedSquare;
    if (square == null || phase != GamePhase.playing) {
      return;
    }
    final piece = pieceAt(square);
    if (piece == null || piece.color == turn || piece.type == PieceType.king) {
      offerError = 'Select an enemy pawn, knight, bishop, rook, or queen.';
      notifyListeners();
      return;
    }
    if (activeKingInCheck) {
      offerError =
          'King safety wins: answer check with a legal chess move before making an offer.';
      notifyListeners();
      return;
    }
    offerTarget = square;
    offerGold = math.min(gold[turn]!, fairPriceAnchors[piece.type]!);
    if (offerGold <= 0) {
      offerGold = 1;
    }
    offerError = null;
    sameTurnRevealTargetId = null;
    phase = GamePhase.offer;
    notifyListeners();
  }

  void cancelOffer() {
    phase = GamePhase.playing;
    offerTarget = null;
    offerError = null;
    sameTurnRevealTargetId = null;
    notifyListeners();
  }

  void adjustOfferGold(int delta) {
    offerGold = (offerGold + delta).clamp(1, math.max(1, gold[turn]!));
    offerError = null;
    notifyListeners();
  }

  void setOfferGold(int value) {
    offerGold = value.clamp(1, math.max(1, gold[turn]!));
    offerError = null;
    notifyListeners();
  }

  void revealOfferChance() {
    final target = offerTarget;
    if (target == null) {
      return;
    }
    final piece = pieceAt(target);
    if (piece == null) {
      return;
    }
    if (activeCountry.id != 'spy') {
      offerError = 'Only Spy Court can reveal exact loyalty intelligence.';
      notifyListeners();
      return;
    }
    if (spyRevealUsedThisTurn && sameTurnRevealTargetId != piece.id) {
      offerError = 'Spy Court reveal is limited to one target per turn.';
      notifyListeners();
      return;
    }
    sameTurnRevealTargetId = piece.id;
    spyRevealUsedThisTurn = true;
    offerError =
        'Reveal complete: exact loyalty and chance are visible for this offer.';
    notifyListeners();
  }

  bool canActiveCourtSeeFairPrice(ChessPiece piece) {
    return activeCountry.id == 'spy' &&
        piece.color != turn &&
        piece.type != PieceType.king &&
        piece.fairPrice != null;
  }

  int? visibleFairPriceForActiveCourt(ChessPiece piece) {
    return canActiveCourtSeeFairPrice(piece) ? piece.fairPrice : null;
  }

  LoyaltyIntelligence loyaltyIntelligenceFor(ChessPiece piece) {
    if (piece.loyalty == null ||
        phase == GamePhase.setup ||
        phase == GamePhase.gameOver) {
      return LoyaltyIntelligence.hidden;
    }
    if (activeCountry.id == 'spy') {
      return isPieceRevealed(piece)
          ? LoyaltyIntelligence.exact
          : LoyaltyIntelligence.coarse;
    }
    if (isPieceExposedByActiveSunlit(piece)) {
      return LoyaltyIntelligence.exact;
    }
    return LoyaltyIntelligence.hidden;
  }

  bool isPieceExposedByActiveSunlit(ChessPiece piece) {
    if (activeCountry.id != 'sunlit' ||
        piece.color == turn ||
        piece.type == PieceType.king) {
      return false;
    }
    final target = _squareForPieceId(piece.id);
    if (target == null) {
      return false;
    }
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final attacker = board[row][col];
        if (attacker == null ||
            attacker.color != turn ||
            attacker.type != PieceType.bishop) {
          continue;
        }
        if (_pieceAttacks(board, Square(row, col), target)) {
          return true;
        }
      }
    }
    return false;
  }

  LoyaltyBand? visibleLoyaltyBandForActiveCourt(ChessPiece piece) {
    return loyaltyBandWithAccess(piece, loyaltyIntelligenceFor(piece));
  }

  int? visibleExactLoyaltyForActiveCourt(ChessPiece piece) {
    return exactLoyaltyWithAccess(piece, loyaltyIntelligenceFor(piece));
  }

  LoyaltyBand? loyaltyBandWithAccess(
    ChessPiece piece,
    LoyaltyIntelligence access,
  ) {
    if (piece.loyalty == null || access == LoyaltyIntelligence.hidden) {
      return null;
    }
    return loyaltyBandFor(piece.loyalty!);
  }

  int? exactLoyaltyWithAccess(ChessPiece piece, LoyaltyIntelligence access) {
    return piece.loyalty != null && access == LoyaltyIntelligence.exact
        ? piece.loyalty
        : null;
  }

  void confirmOffer() {
    final target = offerTarget;
    if (target == null || phase != GamePhase.offer) {
      return;
    }
    final piece = pieceAt(target);
    if (piece == null) {
      offerError = 'Target no longer exists.';
      notifyListeners();
      return;
    }
    final preview = calculateChance(includeHidden: true);
    if (!preview.valid) {
      offerError = preview.reason;
      notifyListeners();
      return;
    }
    if (offerGold > gold[turn]!) {
      offerError = 'Not enough gold for this contract.';
      notifyListeners();
      return;
    }

    final buyer = turn;
    final targetType = piece.type;
    final targetCountryId = piece.countryId;
    final targetColor = piece.color;
    final targetName =
        '${_colorLabel(piece.color)} ${_pieceTypeLabel(piece.type)}';
    final loyaltyBefore = piece.loyalty;
    final buyerHadExactIntel =
        loyaltyIntelligenceFor(piece) == LoyaltyIntelligence.exact;
    final automatic = loyaltyBefore == 0;
    final fairPrice = piece.fairPrice ?? fairPriceAnchors[piece.type]!;
    final loyaltyProfile = loyaltyProfileFor(piece.countryId, piece.type);
    final humiliated =
        !automatic &&
        isHumiliatingOffer(
          offer: offerGold,
          fairPrice: fairPrice,
          profile: loyaltyProfile,
        );
    final ringTokenConsumed = preview.ringTokenApplied;
    if (ringTokenConsumed) {
      diamondRingTokens[buyer] = math.max(0, diamondRingTokens[buyer]! - 1);
      _log(
        '${_colorLabel(buyer)} spent a Diamond Ring on the queen offer (+${preview.treasureModifier} chance).',
      );
    }
    gold[buyer] = gold[buyer]! - offerGold;
    var refund = 0;
    if (humiliated) {
      purchaseFailures++;
      piece.loyalty = math.min(
        100,
        loyaltyBefore! + loyaltyProfile.rallyAmount,
      );
      refund = _failedOfferRefund(buyer);
      lastOfferResult = OfferResult(
        success: false,
        roll: null,
        chance: preview.finalChance,
        paid: offerGold,
        refund: refund,
        targetName: targetName,
        targetType: targetType,
        targetCountryId: targetCountryId,
        targetColor: targetColor,
        resolutionKind: OfferResolutionKind.humiliated,
        publicReaction: OfferReaction.humiliated,
        loyaltyBefore: loyaltyBefore,
        loyaltyAfter: piece.loyalty,
        buyerHadExactIntel: buyerHadExactIntel,
        treasureModifier: preview.treasureModifier,
        ringTokenConsumed: ringTokenConsumed,
      );
      _log(
        'HUMILIATED: $targetName rejected the insulting offer. Loyalty strengthened. Paid $offerGold${refund > 0 ? ', refund $refund' : ''}.',
      );
      phase = GamePhase.playing;
      offerTarget = null;
      selectedSquare = null;
      sameTurnRevealTargetId = null;
      _completeMainAction();
      notifyListeners();
      return;
    }

    final roll = automatic ? null : _random.nextInt(100) + 1;
    final success = automatic || roll! <= preview.finalChance;
    if (success) {
      purchaseSuccesses++;
      lastAiRedeployResolution = null;
      lastCancelledPurchasePieceId = null;
      final boughtPiece = piece;
      _pendingSunlitBishopCounts = _sunlitBishopCounts();
      _redeployOriginalPiece = piece.copy();
      _redeployPaidGold = offerGold;
      _redeployBuyer = buyer;
      final betrayalBefore = _presentedPiece(boughtPiece);
      board[target.row][target.col] = null;
      boughtPiece.color = buyer;
      boughtPiece.countryId = countryForColor(buyer).id;
      boughtPiece.loyalty = randomStartingLoyalty(
        boughtPiece.countryId,
        boughtPiece.type,
        _random,
      );
      boughtPiece.hasMoved = true;
      boughtPiece.newlyPurchased = true;
      _pendingBetrayalTransformEvent = BetrayalTransformEvent(
        serial: 0,
        square: target,
        before: betrayalBefore,
        after: _presentedPiece(boughtPiece),
      );
      redeployPiece = boughtPiece;
      redeployOriginalSquare = target;
      pendingRedeploySquare = null;
      phase = GamePhase.redeploy;
      lastOfferResult = OfferResult(
        success: true,
        roll: roll,
        chance: preview.finalChance,
        paid: offerGold,
        refund: 0,
        targetName: targetName,
        targetType: targetType,
        targetCountryId: targetCountryId,
        targetColor: targetColor,
        resolutionKind: automatic
            ? OfferResolutionKind.automatic
            : OfferResolutionKind.rolled,
        publicReaction: OfferReaction.accepted,
        loyaltyBefore: loyaltyBefore,
        loyaltyAfter: boughtPiece.loyalty,
        buyerHadExactIntel: buyerHadExactIntel,
        treasureModifier: preview.treasureModifier,
        ringTokenConsumed: ringTokenConsumed,
      );
      _log(
        'SUCCESS: $targetName accepted ${_colorLabel(buyer)} contract. Placement pending.',
      );
      offerTarget = null;
      selectedSquare = null;
      sameTurnRevealTargetId = null;
    } else {
      purchaseFailures++;
      final failedMargin = roll - preview.finalChance;
      final pressure =
          failedOfferBasePressure(offer: offerGold, fairPrice: fairPrice) +
          nearMissPressureBonus(failedMargin);
      piece.loyalty = math.max(0, loyaltyBefore! - pressure);
      refund = _failedOfferRefund(buyer);
      lastOfferResult = OfferResult(
        success: false,
        roll: roll,
        chance: preview.finalChance,
        paid: offerGold,
        refund: refund,
        targetName: targetName,
        targetType: targetType,
        targetCountryId: targetCountryId,
        targetColor: targetColor,
        resolutionKind: OfferResolutionKind.rolled,
        publicReaction: OfferReaction.tempted,
        loyaltyBefore: loyaltyBefore,
        loyaltyAfter: piece.loyalty,
        buyerHadExactIntel: buyerHadExactIntel,
        treasureModifier: preview.treasureModifier,
        ringTokenConsumed: ringTokenConsumed,
      );
      _log(
        'FAILED: $targetName rejected the contract. Tempted — loyalty weakened. Paid $offerGold${refund > 0 ? ', refund $refund' : ''}.',
      );
      phase = GamePhase.playing;
      offerTarget = null;
      selectedSquare = null;
      sameTurnRevealTargetId = null;
      _completeMainAction();
    }
    notifyListeners();
  }

  ChancePreview calculateChance({required bool includeHidden}) {
    final target = offerTarget;
    if (target == null) {
      return const ChancePreview(
        valid: false,
        reason: 'No target selected.',
        finalChance: 0,
        baseChance: 0,
        goldModifier: 0,
        contractModifier: 0,
        attackerModifier: 0,
        loyalty: null,
        loyaltyModifier: 0,
        floor: 0,
        cap: 0,
      );
    }
    final piece = pieceAt(target);
    if (piece == null) {
      return const ChancePreview(
        valid: false,
        reason: 'Target no longer exists.',
        finalChance: 0,
        baseChance: 0,
        goldModifier: 0,
        contractModifier: 0,
        attackerModifier: 0,
        loyalty: null,
        loyaltyModifier: 0,
        floor: 0,
        cap: 0,
      );
    }
    if (piece.type == PieceType.king) {
      return const ChancePreview(
        valid: false,
        reason: 'Kings cannot be purchased.',
        finalChance: 0,
        baseChance: 0,
        goldModifier: 0,
        contractModifier: 0,
        attackerModifier: 0,
        loyalty: null,
        loyaltyModifier: 0,
        floor: 0,
        cap: 0,
      );
    }
    if (piece.color == turn) {
      return ChancePreview(
        valid: false,
        reason: 'You cannot purchase a piece from your own court.',
        finalChance: 0,
        baseChance: baseChances[piece.type]!,
        goldModifier: 0,
        contractModifier: 0,
        attackerModifier: activeCountry.offenseModifier,
        loyalty: includeHidden ? piece.loyalty : null,
        loyaltyModifier: 0,
        floor: chanceFloors[piece.type]!,
        cap: chanceCaps[piece.type]!,
      );
    }
    if (activeKingInCheck) {
      return ChancePreview(
        valid: false,
        reason:
            'King safety wins: answer check with a legal chess move before making an offer.',
        finalChance: 0,
        baseChance: baseChances[piece.type]!,
        goldModifier: 0,
        contractModifier: 0,
        attackerModifier: activeCountry.offenseModifier,
        loyalty: includeHidden ? piece.loyalty : null,
        loyaltyModifier: 0,
        floor: chanceFloors[piece.type]!,
        cap: chanceCaps[piece.type]!,
      );
    }
    if (offerGold < 1 || offerGold > gold[turn]!) {
      return ChancePreview(
        valid: false,
        reason: offerGold < 1 ? 'Offer at least one gold.' : 'Not enough gold.',
        finalChance: 0,
        baseChance: baseChances[piece.type]!,
        goldModifier: 0,
        contractModifier: 0,
        attackerModifier: activeCountry.offenseModifier,
        loyalty: includeHidden ? piece.loyalty : null,
        loyaltyModifier: 0,
        floor: chanceFloors[piece.type]!,
        cap: chanceCaps[piece.type]!,
      );
    }

    final currentLoyalty = piece.loyalty;
    if (currentLoyalty == 0) {
      return ChancePreview(
        valid: true,
        reason: 'Broken loyalty guarantees acceptance.',
        finalChance: 100,
        baseChance: baseChances[piece.type]!,
        goldModifier: 0,
        contractModifier: 0,
        attackerModifier: activeCountry.offenseModifier,
        loyalty: includeHidden ? currentLoyalty : null,
        loyaltyModifier: includeHidden
            ? loyaltyChanceModifier(currentLoyalty!)
            : 0,
        floor: chanceFloors[piece.type]!,
        cap: chanceCaps[piece.type]!,
        automatic: true,
      );
    }

    var contractModifier = 0;
    if (sameTurnRevealTargetId == piece.id && activeCountry.id == 'spy') {
      contractModifier += activeCountry.spyRevealBonus;
    }

    final fairPrice = piece.fairPrice ?? fairPriceAnchors[piece.type]!;
    var countryOfferPriceAdjustment = 0;
    if (piece.type == PieceType.knight && activeCountry.id == 'horse') {
      countryOfferPriceAdjustment +=
          (fairPrice * activeCountry.horseKnightPricePercent / 100).round();
    }
    if (piece.type == PieceType.knight && piece.countryId == 'horse') {
      countryOfferPriceAdjustment -=
          (fairPrice * countries['horse']!.horseKnightPricePercent / 100)
              .round();
    }
    if (piece.countryId == 'iron') {
      countryOfferPriceAdjustment -=
          countries['iron']!.ironEffectiveOfferPenalty;
    }
    final effectiveOfferGold = offerGold + countryOfferPriceAdjustment;
    final goldModifier = (30 * (effectiveOfferGold / fairPrice - 1)).round();
    final currentLoyaltyModifier = loyaltyChanceModifier(piece.loyalty!);
    final targetExposed = isPieceExposedByActiveSunlit(piece);
    final countryChanceModifier = targetExposed
        ? activeCountry.sunlitExposedChanceBonus
        : 0;
    final ringTokenApplied =
        piece.type == PieceType.queen &&
        diamondRingTokens[turn]! > 0 &&
        !isHumiliatingOffer(
          offer: offerGold,
          fairPrice: fairPrice,
          profile: loyaltyProfileFor(piece.countryId, piece.type),
        );
    final treasureModifier = ringTokenApplied ? 50 : 0;
    var cap = chanceCaps[piece.type]!;
    if (activeCountry.id == 'horse' && piece.type == PieceType.knight) {
      cap = math.max(cap, activeCountry.horseKnightOfferCap);
    }
    if (ringTokenApplied) {
      cap = math.max(cap, 90);
    }
    final floor = chanceFloors[piece.type]!;
    final raw =
        baseChances[piece.type]! +
        goldModifier +
        contractModifier +
        activeCountry.offenseModifier +
        currentLoyaltyModifier +
        countryChanceModifier +
        treasureModifier;
    final finalChance = raw.clamp(floor, cap);
    return ChancePreview(
      valid: true,
      reason: 'Offer can resolve.',
      finalChance: finalChance,
      baseChance: baseChances[piece.type]!,
      goldModifier: goldModifier,
      contractModifier: contractModifier,
      attackerModifier: activeCountry.offenseModifier,
      loyalty: includeHidden ? piece.loyalty : null,
      loyaltyModifier: includeHidden ? currentLoyaltyModifier : 0,
      floor: floor,
      cap: cap,
      treasureModifier: treasureModifier,
      ringTokenApplied: ringTokenApplied,
      actualOfferGold: offerGold,
      effectiveOfferGold: effectiveOfferGold,
      countryOfferPriceAdjustment: countryOfferPriceAdjustment,
      countryChanceModifier: countryChanceModifier,
      targetExposed: targetExposed,
    );
  }

  int _failedOfferRefund(PieceColor buyer) {
    final attacker = countryForColor(buyer);
    if (attacker.failedRefundPercent <= 0) {
      return 0;
    }
    final refund = math.min(
      attacker.failedRefundCap,
      (offerGold * attacker.failedRefundPercent / 100).round(),
    );
    gold[buyer] = gold[buyer]! + refund;
    return refund;
  }

  bool isPieceRevealed(ChessPiece piece) {
    final target = offerTarget;
    return phase == GamePhase.offer &&
        target != null &&
        pieceAt(target)?.id == piece.id &&
        sameTurnRevealTargetId == piece.id &&
        activeCountry.id == 'spy';
  }

  void makeMove(ChessMove move) {
    if (phase != GamePhase.playing) {
      return;
    }
    final moving = pieceAt(move.from);
    if (moving == null || moving.color != turn) {
      return;
    }
    final captured = move.isEnPassant
        ? board[move.from.row][move.to.col]
        : board[move.to.row][move.to.col];
    lastCapturedCharacterId = captured?.characterId;
    final capturedSquare = captured == null
        ? null
        : move.isEnPassant
        ? Square(move.from.row, move.to.col)
        : move.to;
    final motions = <PieceMotion>[
      PieceMotion(piece: _presentedPiece(moving), from: move.from, to: move.to),
    ];
    if (move.isCastle) {
      final rookFrom = Square(move.from.row, move.to.col == 6 ? 7 : 0);
      final rookTo = Square(move.from.row, move.to.col == 6 ? 5 : 3);
      final rook = pieceAt(rookFrom);
      if (rook != null) {
        motions.add(
          PieceMotion(piece: _presentedPiece(rook), from: rookFrom, to: rookTo),
        );
      }
    }
    final movingTypeBefore = moving.type;
    final sunlitBishopCountsBefore = _sunlitBishopCounts();
    final fromName = squareName(move.from);
    final toName = squareName(move.to);
    _boardOps.applyMove(board, move);
    lastBoardMotionEvent = BoardMotionEvent(
      serial: ++_presentationSerial,
      kind: move.isCastle ? BoardMotionKind.castle : BoardMotionKind.chessMove,
      motions: List<PieceMotion>.unmodifiable(motions),
      capturedPiece: captured == null ? null : _presentedPiece(captured),
      capturedSquare: capturedSquare,
    );
    if (captured != null) {
      _capturedListFor(turn).add(
        '${countryForColor(captured.color).shortName} ${_pieceTypeLabel(captured.type)}',
      );
      _log(
        '${_colorLabel(turn)} ${_pieceTypeLabel(movingTypeBefore)} captured ${_pieceTypeLabel(captured.type)} on $toName.',
      );
      _resolveCaptureCountryEffects(
        capturer: turn,
        movingType: movingTypeBefore,
      );
    } else if (move.isCastle) {
      _log(
        '${_colorLabel(turn)} castled ${move.to.col == 6 ? 'king side' : 'queen side'}.',
      );
    } else {
      _log(
        '${_colorLabel(turn)} ${_pieceTypeLabel(movingTypeBefore)} moved $fromName to $toName.',
      );
    }
    _applySunlitBishopTransitions(sunlitBishopCountsBefore);

    if (movingTypeBefore == PieceType.pawn &&
        (move.from.row - move.to.row).abs() == 2) {
      final between = (move.from.row + move.to.row) ~/ 2;
      _enPassantSquare = Square(between, move.from.col);
    } else {
      _enPassantSquare = null;
    }

    selectedSquare = null;
    offerTarget = null;
    if (move.isPromotion) {
      pendingPromotionSquare = move.to;
      phase = GamePhase.promotion;
      notifyListeners();
      return;
    }
    _completeMainAction(
      preserveEnPassant:
          movingTypeBefore == PieceType.pawn &&
          (move.from.row - move.to.row).abs() == 2,
    );
    notifyListeners();
  }

  void choosePromotion(PieceType type) {
    final square = pendingPromotionSquare;
    if (square == null || phase != GamePhase.promotion) {
      return;
    }
    final piece = pieceAt(square);
    final sunlitBishopCountsBefore = _sunlitBishopCounts();
    if (piece != null && piece.type == PieceType.pawn) {
      piece.type = type;
      _log(
        '${_colorLabel(piece.color)} pawn promoted to ${_pieceTypeLabel(type)} on ${squareName(square)}.',
      );
    }
    _applySunlitBishopTransitions(sunlitBishopCountsBefore);
    pendingPromotionSquare = null;
    phase = GamePhase.playing;
    _completeMainAction();
    notifyListeners();
  }

  List<String> _capturedListFor(PieceColor color) {
    return color == PieceColor.white ? capturedByWhite : capturedByBlack;
  }

  List<ChessMove> legalMovesFrom(Square from) {
    final piece = pieceAt(from);
    if (piece == null) {
      return const <ChessMove>[];
    }
    final pseudo = _pseudoMoves(board, from, piece, includeCastling: true);
    return pseudo
        .where((move) => !_wouldLeaveKingInCheck(move, piece.color))
        .toList();
  }

  bool hasAnyLegalMove(PieceColor color) {
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final piece = board[row][col];
        if (piece != null &&
            piece.color == color &&
            legalMovesFrom(Square(row, col)).isNotEmpty) {
          return true;
        }
      }
    }
    return false;
  }

  /// Continues a variant match by passing a side that has no legal move but is
  /// not in check.
  ///
  /// Standard duel flows never call this method, so orthodox stalemate remains
  /// a draw there. Story Campaign uses it to keep authored battles moving.
  /// Returns the skipped side when the pass was valid, otherwise `null`.
  PieceColor? skipTurnIfNoLegalMove() {
    final mayContinue =
        phase == GamePhase.playing ||
        (phase == GamePhase.gameOver &&
            resolvedGameEndReason == GameEndReason.stalemate);
    if (!mayContinue || isKingInCheck(turn) || hasAnyLegalMove(turn)) {
      return null;
    }

    final skipped = turn;
    winner = null;
    stalemate = false;
    gameEndReason = GameEndReason.none;
    phase = GamePhase.playing;
    turn = opponent(turn);
    turnCount++;
    completedActionCount++;
    _recordCompletedSide(skipped);
    _advanceBattlefield(actingSide: skipped);
    if (phase == GamePhase.gameOver) {
      sameTurnRevealTargetId = null;
      spyRevealUsedThisTurn = false;
      notifyListeners();
      return skipped;
    }
    sameTurnRevealTargetId = null;
    spyRevealUsedThisTurn = false;
    for (final row in board) {
      for (final piece in row) {
        if (piece != null && piece.color == turn) {
          piece.newlyPurchased = false;
        }
      }
    }
    _log(
      '${_colorLabel(skipped)} has no legal move. Turn skipped; '
      '${_colorLabel(turn)} continues.',
    );
    notifyListeners();
    return skipped;
  }

  bool isKingInCheck(PieceColor color) {
    return _isKingInCheckOnBoard(board, color);
  }

  /// Board squares currently attacking [color]'s king.
  ///
  /// This is intentionally public presentation data: the board uses it to
  /// draw the canonical threat line without duplicating chess rules in UI
  /// paint code.
  List<Square> checkingAttackers(PieceColor color) {
    final king = _boardOps.kingSquare(board, color);
    if (king == null) {
      return const <Square>[];
    }
    final attackers = <Square>[];
    final enemy = opponent(color);
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final piece = board[row][col];
        if (piece == null || piece.color != enemy) {
          continue;
        }
        final from = Square(row, col);
        if (_pieceAttacks(board, from, king)) {
          attackers.add(from);
        }
      }
    }
    return attackers;
  }

  Square? kingSquare(PieceColor color) => _boardOps.kingSquare(board, color);

  bool _wouldLeaveKingInCheck(ChessMove move, PieceColor color) {
    final copy = _boardOps.clone(board);
    _boardOps.applyMove(copy, move, promotionOverride: PieceType.queen);
    return _isKingInCheckOnBoard(copy, color);
  }

  bool _isKingInCheckOnBoard(List<List<ChessPiece?>> state, PieceColor color) {
    final king = _boardOps.kingSquare(state, color);
    if (king == null) {
      return false;
    }
    return _isSquareAttacked(state, king, opponent(color));
  }

  List<ChessMove> _pseudoMoves(
    List<List<ChessPiece?>> state,
    Square from,
    ChessPiece piece, {
    required bool includeCastling,
  }) {
    final moves = _chessRules.pseudoMoves(
      board: state,
      from: from,
      enPassantSquare: _enPassantSquare,
      allowEnPassant: true,
    );
    if (piece.type == PieceType.king && includeCastling) {
      moves.addAll(_castleMoves(state, from, piece));
    }
    return moves;
  }

  List<ChessMove> _castleMoves(
    List<List<ChessPiece?>> state,
    Square from,
    ChessPiece king,
  ) {
    if (king.hasMoved || _isKingInCheckOnBoard(state, king.color)) {
      return const <ChessMove>[];
    }
    final row = king.color == PieceColor.white ? 7 : 0;
    if (from.row != row || from.col != 4) {
      return const <ChessMove>[];
    }
    final moves = <ChessMove>[];
    final enemy = opponent(king.color);
    final kingSideRook = state[row][7];
    if (kingSideRook != null &&
        kingSideRook.type == PieceType.rook &&
        kingSideRook.color == king.color &&
        !kingSideRook.hasMoved &&
        state[row][5] == null &&
        state[row][6] == null &&
        !_isSquareAttacked(state, Square(row, 5), enemy) &&
        !_isSquareAttacked(state, Square(row, 6), enemy)) {
      moves.add(ChessMove(from: from, to: Square(row, 6), isCastle: true));
    }
    final queenSideRook = state[row][0];
    if (queenSideRook != null &&
        queenSideRook.type == PieceType.rook &&
        queenSideRook.color == king.color &&
        !queenSideRook.hasMoved &&
        state[row][1] == null &&
        state[row][2] == null &&
        state[row][3] == null &&
        !_isSquareAttacked(state, Square(row, 3), enemy) &&
        !_isSquareAttacked(state, Square(row, 2), enemy)) {
      moves.add(ChessMove(from: from, to: Square(row, 2), isCastle: true));
    }
    return moves;
  }

  bool _isSquareAttacked(
    List<List<ChessPiece?>> state,
    Square square,
    PieceColor byColor,
  ) {
    return _chessRules.isSquareAttacked(
      board: state,
      square: square,
      byColor: byColor,
    );
  }

  bool _pieceAttacks(
    List<List<ChessPiece?>> state,
    Square from,
    Square target,
  ) {
    return _chessRules.pieceAttacks(board: state, from: from, target: target);
  }

  bool isLegalRedeploy(Square square) => _isLegalRedeployWithPolicy(square);

  bool _isLegalRedeployWithPolicy(
    Square square, {
    bool allowImmediateCheck = false,
    bool allowOutsideOwnHalf = false,
    bool allowOriginalSquare = false,
  }) {
    if (phase != GamePhase.redeploy || redeployPiece == null) {
      return false;
    }
    if (!isBoardSquare(square) || board[square.row][square.col] != null) {
      return false;
    }
    if (isSpecialTile(square) &&
        !(allowOriginalSquare && redeployOriginalSquare == square)) {
      return false;
    }
    if (!allowOriginalSquare && redeployOriginalSquare == square) {
      return false;
    }
    final color = redeployPiece!.color;
    final ownHalf = color == PieceColor.white
        ? square.row >= 4
        : square.row <= 3;
    if (!allowOutsideOwnHalf && !ownHalf) {
      return false;
    }
    final copy = _boardOps.clone(board);
    copy[square.row][square.col] = redeployPiece!.copy();
    if (_isKingInCheckOnBoard(copy, color)) {
      return false;
    }
    return allowImmediateCheck || !_isKingInCheckOnBoard(copy, opponent(color));
  }

  List<Square> legalRedeploySquares() {
    final result = <Square>[];
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final square = Square(row, col);
        if (isLegalRedeploy(square)) {
          result.add(square);
        }
      }
    }
    return result;
  }

  void previewRedeploy(Square square) {
    if (phase != GamePhase.redeploy || redeployPiece == null) {
      return;
    }
    if (!isLegalRedeploy(square)) {
      return;
    }
    pendingRedeploySquare = square;
    notifyListeners();
  }

  void confirmRedeploy() {
    final square = pendingRedeploySquare;
    if (square == null || phase != GamePhase.redeploy) {
      return;
    }
    placeRedeploy(square);
  }

  void placeRedeploy(Square square) {
    if (!isLegalRedeploy(square) || redeployPiece == null) {
      _log(
        'Invalid redeploy square. Use an empty square in your own half that does not give immediate check.',
      );
      notifyListeners();
      return;
    }
    _placeRedeployUnchecked(square);
  }

  /// Settles a successful purchase on the exact square it just vacated.
  ///
  /// Living Campaign uses this only for Black purchases after the player has
  /// acknowledged the result. It deliberately emits a betrayal transform but
  /// no redeploy motion and does not resolve the underlying special tile again.
  AiRedeployResolution resolvePendingPurchaseInPlace() {
    if (phase != GamePhase.redeploy || redeployPiece == null) {
      return lastAiRedeployResolution = AiRedeployResolution.noPendingPurchase;
    }
    final originalSquare = redeployOriginalSquare;
    if (originalSquare == null ||
        board[originalSquare.row][originalSquare.col] != null) {
      _cancelAiPurchaseAndRefund();
      return lastAiRedeployResolution =
          AiRedeployResolution.cancelledAndRefunded;
    }

    // Publish the transform while the action count still represents the turn
    // before settlement so Living Campaign records the correct action number.
    if (lastOfferResult != null) {
      dismissLastOfferResult();
    }

    final piece = redeployPiece!;
    board[originalSquare.row][originalSquare.col] = piece;
    final sunlitBishopCountsBefore = _pendingSunlitBishopCounts;
    _log(
      '${_colorLabel(piece.color)} transformed purchased '
      '${_pieceTypeLabel(piece.type)} in place at ${squareName(originalSquare)}.',
    );
    redeployPiece = null;
    redeployOriginalSquare = null;
    pendingRedeploySquare = null;
    _redeployOriginalPiece = null;
    _redeployPaidGold = 0;
    _redeployBuyer = null;
    _pendingSunlitBishopCounts = null;
    if (sunlitBishopCountsBefore != null) {
      _applySunlitBishopTransitions(sunlitBishopCountsBefore);
    }
    lastAiRedeployResolution = AiRedeployResolution.inPlace;
    phase = GamePhase.playing;
    _completeMainAction();
    notifyListeners();
    return AiRedeployResolution.inPlace;
  }

  AiRedeployResolution resolveAiPurchaseRedeploy({Square? preferredSquare}) {
    if (phase != GamePhase.redeploy || redeployPiece == null) {
      return lastAiRedeployResolution = AiRedeployResolution.noPendingPurchase;
    }
    if (preferredSquare != null && isLegalRedeploy(preferredSquare)) {
      _placeRedeployUnchecked(preferredSquare);
      return lastAiRedeployResolution = AiRedeployResolution.normal;
    }
    final ordinary = legalRedeploySquares();
    if (ordinary.isNotEmpty) {
      _placeRedeployUnchecked(ordinary.first);
      return lastAiRedeployResolution = AiRedeployResolution.normal;
    }
    final relaxed = _firstRedeploySquare(allowImmediateCheck: true);
    if (relaxed != null) {
      _placeRedeployUnchecked(
        relaxed,
        resolutionNote:
            'AI redeployment relaxed only the immediate-check restriction.',
      );
      return lastAiRedeployResolution =
          AiRedeployResolution.immediateCheckRelaxed;
    }
    final original = redeployOriginalSquare;
    if (original != null &&
        _isLegalRedeployWithPolicy(
          original,
          allowImmediateCheck: true,
          allowOutsideOwnHalf: true,
          allowOriginalSquare: true,
        )) {
      _placeRedeployUnchecked(
        original,
        resolutionNote:
            'AI redeployment used the purchased piece’s vacated square.',
      );
      return lastAiRedeployResolution = AiRedeployResolution.originalSquare;
    }
    _cancelAiPurchaseAndRefund();
    return lastAiRedeployResolution = AiRedeployResolution.cancelledAndRefunded;
  }

  Square? _firstRedeploySquare({required bool allowImmediateCheck}) {
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final square = Square(row, col);
        if (_isLegalRedeployWithPolicy(
          square,
          allowImmediateCheck: allowImmediateCheck,
        )) {
          return square;
        }
      }
    }
    return null;
  }

  void _placeRedeployUnchecked(Square square, {String? resolutionNote}) {
    final piece = redeployPiece!;
    final originalSquare = redeployOriginalSquare;
    board[square.row][square.col] = piece;
    final sunlitBishopCountsBefore = _pendingSunlitBishopCounts;
    if (originalSquare != null) {
      lastBoardMotionEvent = BoardMotionEvent(
        serial: ++_presentationSerial,
        kind: BoardMotionKind.redeploy,
        motions: <PieceMotion>[
          PieceMotion(
            piece: _presentedPiece(piece),
            from: originalSquare,
            to: square,
          ),
        ],
      );
    }
    _log(
      '${_colorLabel(piece.color)} redeployed purchased ${_pieceTypeLabel(piece.type)} to ${squareName(square)}.',
    );
    if (resolutionNote != null) {
      _log(resolutionNote);
    }
    redeployPiece = null;
    redeployOriginalSquare = null;
    pendingRedeploySquare = null;
    _redeployOriginalPiece = null;
    _redeployPaidGold = 0;
    _redeployBuyer = null;
    _pendingSunlitBishopCounts = null;
    if (sunlitBishopCountsBefore != null) {
      _applySunlitBishopTransitions(sunlitBishopCountsBefore);
    }
    phase = GamePhase.playing;
    _completeMainAction();
    notifyListeners();
  }

  void _cancelAiPurchaseAndRefund() {
    final cancelledPieceId = redeployPiece?.id;
    final originalSquare = redeployOriginalSquare;
    final originalPiece = _redeployOriginalPiece;
    final buyer = _redeployBuyer;
    final priorResult = lastOfferResult;
    if (originalSquare != null && originalPiece != null) {
      board[originalSquare.row][originalSquare.col] = originalPiece;
    }
    if (buyer != null && _redeployPaidGold > 0) {
      gold[buyer] = gold[buyer]! + _redeployPaidGold;
    }
    purchaseSuccesses = math.max(0, purchaseSuccesses - 1);
    if (priorResult != null) {
      lastOfferResult = OfferResult(
        success: false,
        roll: priorResult.roll,
        chance: priorResult.chance,
        paid: priorResult.paid,
        refund: _redeployPaidGold,
        targetName: priorResult.targetName,
        targetType: priorResult.targetType,
        targetCountryId: priorResult.targetCountryId,
        targetColor: priorResult.targetColor,
        resolutionKind: priorResult.resolutionKind,
        publicReaction: OfferReaction.tempted,
        loyaltyBefore: priorResult.loyaltyBefore,
        loyaltyAfter: priorResult.loyaltyBefore,
        buyerHadExactIntel: priorResult.buyerHadExactIntel,
        treasureModifier: priorResult.treasureModifier,
        ringTokenConsumed: priorResult.ringTokenConsumed,
      );
    }
    _pendingBetrayalTransformEvent = null;
    if (lastBetrayalTransformEvent?.after.id == cancelledPieceId) {
      lastBetrayalTransformEvent = null;
    }
    lastCancelledPurchasePieceId = cancelledPieceId;
    redeployPiece = null;
    redeployOriginalSquare = null;
    pendingRedeploySquare = null;
    _redeployOriginalPiece = null;
    _redeployPaidGold = 0;
    _redeployBuyer = null;
    _pendingSunlitBishopCounts = null;
    phase = GamePhase.playing;
    _log(
      'AI purchase was cancelled because no safe redeployment remained. The contract was refunded and the piece returned.',
    );
    _completeMainAction();
    notifyListeners();
  }

  PresentedPiece _presentedPiece(ChessPiece piece) {
    return PresentedPiece.fromPiece(
      piece,
      loyaltyBand: visibleLoyaltyBandForActiveCourt(piece),
    );
  }

  String squareName(Square square) => boardSquareName(square);

  Square? parseSquare(String text) => parseBoardSquare(text);

  void _completeMainAction({bool preserveEnPassant = false}) {
    final actingSide = turn;
    completedActionCount++;
    _recordCompletedSide(actingSide);
    if (!preserveEnPassant) {
      _enPassantSquare = null;
    }
    _advanceMerchant();
    _advanceBattlefield(actingSide: actingSide);
    if (phase == GamePhase.gameOver) {
      sameTurnRevealTargetId = null;
      spyRevealUsedThisTurn = false;
      return;
    }
    turn = opponent(turn);
    turnCount++;
    sameTurnRevealTargetId = null;
    spyRevealUsedThisTurn = false;
    for (final row in board) {
      for (final piece in row) {
        if (piece != null && piece.color == turn) {
          piece.newlyPurchased = false;
        }
      }
    }
    if (isKingInCheck(turn) && !hasAnyLegalMove(turn)) {
      phase = GamePhase.gameOver;
      winner = opponent(turn);
      stalemate = false;
      gameEndReason = GameEndReason.checkmate;
      _log('CHECKMATE: ${_colorLabel(winner!)} wins.');
    } else if (!isKingInCheck(turn) && !hasAnyLegalMove(turn)) {
      phase = GamePhase.gameOver;
      winner = null;
      stalemate = true;
      gameEndReason = GameEndReason.stalemate;
      _log('Stalemate: no legal moves remain.');
    } else {
      phase = GamePhase.playing;
      if (isKingInCheck(turn)) {
        _log('${_colorLabel(turn)} king is in check.');
      }
    }
  }

  void _recordCompletedSide(PieceColor side) {
    _completedRoundSideMask |= side == PieceColor.white ? 1 : 2;
    if (_completedRoundSideMask == 3) {
      completedRoundCount++;
      _completedRoundSideMask = 0;
    }
  }

  void _advanceBattlefield({required PieceColor actingSide}) {
    final runtime = _battlefieldRuntime;
    if (!specialTilesEnabled || runtime == null || !battlefield.hasMapEffects) {
      return;
    }
    final sunlitBishopCountsBefore = _sunlitBishopCounts();
    final advance = runtime.advance(board, actingSide: actingSide);
    for (final resolution in advance.resolutions) {
      final piece = pieceAt(resolution.square);
      if (piece == null || piece.id != resolution.pieceId) {
        continue;
      }
      final square = squareName(resolution.square);
      switch (resolution.resolvedType) {
        case SpecialTileType.knightShrine:
          if (piece.type == PieceType.king) {
            _recordBattlefieldEvent(
              BattlefieldEventType.kingGuarded,
              '$square: the Knight Shrine bowed to the King. The King was not transformed.',
              square: resolution.square,
              tileType: resolution.sourceType,
              pieceColor: piece.color,
              pieceId: piece.id,
            );
          } else {
            final formerType = piece.type;
            piece.type = PieceType.knight;
            piece.personalityId = null;
            _recordBattlefieldEvent(
              BattlefieldEventType.knightPromotion,
              '$square: ${_colorLabel(piece.color)} ${_pieceTypeLabel(formerType)} became a Knight.',
              square: resolution.square,
              tileType: resolution.sourceType,
              pieceColor: piece.color,
              pieceId: piece.id,
            );
          }
        case SpecialTileType.treasureChest:
          gold[piece.color] = gold[piece.color]! + resolution.goldAmount;
          _recordBattlefieldEvent(
            resolution.cameFromMystery
                ? BattlefieldEventType.mysteryTreasure
                : BattlefieldEventType.treasureFound,
            '$square: ${_colorLabel(piece.color)} found ${resolution.goldAmount} gold.',
            square: resolution.square,
            tileType: resolution.sourceType,
            pieceColor: piece.color,
            pieceId: piece.id,
            goldAmount: resolution.goldAmount,
          );
        case SpecialTileType.diamondRing:
          diamondRingTokens[piece.color] = diamondRingTokens[piece.color]! + 1;
          _recordBattlefieldEvent(
            BattlefieldEventType.diamondRingFound,
            '$square: ${_colorLabel(piece.color)} claimed a Diamond Ring.',
            square: resolution.square,
            tileType: resolution.sourceType,
            pieceColor: piece.color,
            pieceId: piece.id,
          );
        case SpecialTileType.visibleTrap:
          board[resolution.square.row][resolution.square.col] = null;
          final wasKing = piece.type == PieceType.king;
          _recordBattlefieldEvent(
            resolution.cameFromMystery
                ? BattlefieldEventType.mysteryTrap
                : BattlefieldEventType.trapTriggered,
            '$square: ${_colorLabel(piece.color)} ${_pieceTypeLabel(piece.type)} was destroyed by ${resolution.cameFromMystery ? 'a mystery trap' : 'a trap'}.',
            square: resolution.square,
            tileType: resolution.sourceType,
            pieceColor: piece.color,
            pieceId: piece.id,
          );
          if (wasKing) {
            phase = GamePhase.gameOver;
            winner = opponent(piece.color);
            stalemate = false;
            gameEndReason = GameEndReason.kingTrapfall;
            _log(
              'KING TRAPFALL: ${_colorLabel(piece.color)} King was destroyed; ${_colorLabel(winner!)} wins immediately.',
            );
            _applySunlitBishopTransitions(sunlitBishopCountsBefore);
            return;
          }
        case SpecialTileType.mystery:
          throw StateError('Mystery tiles must resolve before application.');
      }
    }
    if (advance.spawnedTiles.isNotEmpty) {
      _recordBattlefieldEvent(
        BattlefieldEventType.tilesSpawned,
        '${advance.spawnedTiles.length} new ${specialTileLabel(advance.spawnedTiles.first.type)} tiles emerged.',
        tileType: advance.spawnedTiles.first.type,
      );
    }
    _applySunlitBishopTransitions(sunlitBishopCountsBefore);
  }

  void _recordBattlefieldEvent(
    BattlefieldEventType type,
    String message, {
    Square? square,
    SpecialTileType? tileType,
    PieceColor? pieceColor,
    String? pieceId,
    int goldAmount = 0,
  }) {
    battlefieldEventSerial++;
    final messageRecord = LocalizedMessageRecord.fromEnglish(message);
    lastBattlefieldEvent = BattlefieldEvent(
      serial: battlefieldEventSerial,
      type: type,
      message: message,
      messageRecord: messageRecord,
      square: square,
      tileType: tileType,
      pieceColor: pieceColor,
      pieceId: pieceId,
      goldAmount: goldAmount,
    );
    _log(message);
  }

  void _advanceMerchant() {
    if (!merchantEnabled) {
      return;
    }
    merchantPosition += merchantDirection * merchantSpeed;
    if (merchantPosition >= 16) {
      merchantPosition = 16;
      final payout = _merchantPayoutFor(PieceColor.black);
      gold[PieceColor.black] = gold[PieceColor.black]! + payout;
      lastMerchantPayoutReceiver = PieceColor.black;
      merchantPayoutPulseSerial++;
      merchantDirection = -1;
      _log(
        'Merchant reached Black Court. ${blackCountry.shortName} gained $payout gold.',
      );
    } else if (merchantPosition <= 0) {
      merchantPosition = 0;
      final payout = _merchantPayoutFor(PieceColor.white);
      gold[PieceColor.white] = gold[PieceColor.white]! + payout;
      lastMerchantPayoutReceiver = PieceColor.white;
      merchantPayoutPulseSerial++;
      merchantDirection = 1;
      _log(
        'Merchant reached White Court. ${whiteCountry.shortName} gained $payout gold.',
      );
    }
  }

  int _merchantPayoutFor(PieceColor receiver) {
    final receiverCountry = countryForColor(receiver);
    final opponentCountry = countryForColor(opponent(receiver));
    return math.max(
      0,
      merchantPayout +
          receiverCountry.merchantPayoutModifier -
          opponentCountry.opponentMerchantPayoutPenalty,
    );
  }

  void _resolveCaptureCountryEffects({
    required PieceColor capturer,
    required PieceType movingType,
  }) {
    final country = countryForColor(capturer);
    final enemy = opponent(capturer);
    if (country.horseKnightCaptureLoyaltyDamage > 0 &&
        movingType == PieceType.knight) {
      var affected = 0;
      for (final row in board) {
        for (final piece in row) {
          if (piece == null ||
              piece.color != enemy ||
              piece.type == PieceType.king ||
              piece.loyalty == null) {
            continue;
          }
          piece.loyalty = math.max(
            0,
            piece.loyalty! - country.horseKnightCaptureLoyaltyDamage,
          );
          affected++;
        }
      }
      _log(
        '${country.shortName} cavalry shock reduced $affected surviving enemy loyalties by ${country.horseKnightCaptureLoyaltyDamage}.',
      );
    }
    if (economyEnabled && country.captureGoldSteal > 0) {
      final stolen = math.min(country.captureGoldSteal, gold[enemy]!);
      gold[enemy] = gold[enemy]! - stolen;
      gold[capturer] = gold[capturer]! + stolen;
      _log(
        '${country.shortName} plunder transferred $stolen gold from ${_colorLabel(enemy)}.',
      );
    }
  }

  Square? _squareForPieceId(String id) {
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        if (board[row][col]?.id == id) {
          return Square(row, col);
        }
      }
    }
    return null;
  }

  Map<PieceColor, int> _sunlitBishopCounts() => {
    PieceColor.white: _bishopCount(PieceColor.white),
    PieceColor.black: _bishopCount(PieceColor.black),
  };

  int _bishopCount(PieceColor color) {
    var count = 0;
    for (final row in board) {
      for (final piece in row) {
        if (piece != null &&
            piece.color == color &&
            piece.type == PieceType.bishop) {
          count++;
        }
      }
    }
    return count;
  }

  void _initializeSunlitBishopCycles() {
    for (final color in PieceColor.values) {
      _sunlitBishopCycleArmed[color] =
          countryForColor(color).id == 'sunlit' && _bishopCount(color) > 0;
    }
  }

  void _applySunlitBishopTransitions(Map<PieceColor, int> before) {
    for (final color in PieceColor.values) {
      if (countryForColor(color).id != 'sunlit') {
        continue;
      }
      final previous = before[color] ?? 0;
      final current = _bishopCount(color);
      if (previous > 0 && current == 0) {
        _sunlitBishopCycleArmed[color] = true;
        final affected = _scaleCourtLoyalty(color, doubleLoyalty: false);
        _log(
          'Sunlit eclipse: the final Bishop fell and $affected allied loyalties were halved.',
        );
      } else if (previous == 0 && current > 0) {
        if (_sunlitBishopCycleArmed[color] == true) {
          final affected = _scaleCourtLoyalty(color, doubleLoyalty: true);
          _log(
            'Sunlit restoration: a Bishop returned and $affected allied loyalties doubled.',
          );
        } else {
          _sunlitBishopCycleArmed[color] = true;
        }
      }
    }
  }

  int _scaleCourtLoyalty(PieceColor color, {required bool doubleLoyalty}) {
    var affected = 0;
    for (final row in board) {
      for (final piece in row) {
        if (piece == null ||
            piece.color != color ||
            piece.type == PieceType.king ||
            piece.loyalty == null) {
          continue;
        }
        piece.loyalty = doubleLoyalty
            ? math.min(100, piece.loyalty! * 2)
            : (piece.loyalty! / 2).round();
        affected++;
      }
    }
    return affected;
  }

  void _log(String message) {
    final record = LocalizedMessageRecord.fromEnglish(message);
    _fullEventMessages.add(record);
    _eventMessages.insert(0, record);
    if (_eventMessages.length > 18) {
      _eventMessages.removeLast();
    }
  }
}

String _colorLabel(PieceColor color) =>
    color == PieceColor.white ? 'White' : 'Black';

String _pieceTypeLabel(PieceType type) {
  switch (type) {
    case PieceType.pawn:
      return 'Pawn';
    case PieceType.knight:
      return 'Knight';
    case PieceType.bishop:
      return 'Bishop';
    case PieceType.rook:
      return 'Rook';
    case PieceType.queen:
      return 'Queen';
    case PieceType.king:
      return 'King';
  }
}
