import '../domain/chess_models.dart';

/// Small, state-free board mutations shared by game-mode controllers.
///
/// Rules and move generation remain owned by [ChessRulesService]. This helper
/// only centralizes the safe copying and geometry of an already-selected move.
class ChessBoardOps {
  const ChessBoardOps();

  List<List<ChessPiece?>> clone(List<List<ChessPiece?>> source) {
    return List<List<ChessPiece?>>.generate(
      source.length,
      (row) => List<ChessPiece?>.generate(
        source[row].length,
        (col) => source[row][col]?.copy(),
      ),
    );
  }

  void applyMove(
    List<List<ChessPiece?>> board,
    ChessMove move, {
    PieceType? promotionOverride,
    bool markMoved = true,
  }) {
    final moving = board[move.from.row][move.from.col];
    if (moving == null) {
      return;
    }

    board[move.from.row][move.from.col] = null;
    if (move.isEnPassant) {
      board[move.from.row][move.to.col] = null;
    }
    if (move.isCastle) {
      final rookFrom = Square(move.from.row, move.to.col == 6 ? 7 : 0);
      final rookTo = Square(move.from.row, move.to.col == 6 ? 5 : 3);
      final rook = board[rookFrom.row][rookFrom.col];
      board[rookFrom.row][rookFrom.col] = null;
      if (rook != null) {
        if (markMoved) {
          rook.hasMoved = true;
        }
        board[rookTo.row][rookTo.col] = rook;
      }
    }
    if (markMoved) {
      moving.hasMoved = true;
    }
    if (move.isPromotion && promotionOverride != null) {
      moving.type = promotionOverride;
    }
    board[move.to.row][move.to.col] = moving;
  }

  Square? kingSquare(List<List<ChessPiece?>> board, PieceColor color) {
    for (var row = 0; row < board.length; row++) {
      for (var col = 0; col < board[row].length; col++) {
        final piece = board[row][col];
        if (piece?.color == color && piece?.type == PieceType.king) {
          return Square(row, col);
        }
      }
    }
    return null;
  }
}
