import 'package:flutter/foundation.dart';

import '../battlefield/battlefield_models.dart';
import '../domain/chess_models.dart';

@immutable
class ScenarioPiecePlacement {
  const ScenarioPiecePlacement({required this.square, required this.piece});

  final Square square;
  final ChessPiece piece;
}

@immutable
class ScenarioGameSetup {
  const ScenarioGameSetup({
    required this.id,
    required this.whiteCountryId,
    required this.blackCountryId,
    required this.turn,
    required this.battlefieldId,
    required this.battlefieldSeed,
    required this.whiteGold,
    required this.blackGold,
    required this.merchantSpeed,
    this.merchantPayout = 8,
    required this.economyEnabled,
    required this.merchantEnabled,
    required this.specialTilesEnabled,
    required this.pieces,
    this.authoredTiles = const <SpecialTileState>[],
  });

  final String id;
  final String whiteCountryId;
  final String blackCountryId;
  final PieceColor turn;
  final BattlefieldId battlefieldId;
  final int battlefieldSeed;
  final int whiteGold;
  final int blackGold;
  final int merchantSpeed;
  final int merchantPayout;
  final bool economyEnabled;
  final bool merchantEnabled;
  final bool specialTilesEnabled;
  final List<ScenarioPiecePlacement> pieces;
  final List<SpecialTileState> authoredTiles;
}
