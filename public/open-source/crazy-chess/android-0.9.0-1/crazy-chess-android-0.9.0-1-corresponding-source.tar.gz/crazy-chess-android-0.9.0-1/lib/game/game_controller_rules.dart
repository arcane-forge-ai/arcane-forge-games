import '../domain/chess_models.dart';

const chessFiles = 'abcdefgh';

bool isBoardSquare(Square square) {
  return square.row >= 0 && square.row < 8 && square.col >= 0 && square.col < 8;
}

String boardSquareName(Square square) {
  return '${chessFiles[square.col]}${8 - square.row}';
}

Square? parseBoardSquare(String text) {
  if (text.length != 2) {
    return null;
  }
  final col = chessFiles.indexOf(text[0].toLowerCase());
  final rank = int.tryParse(text[1]);
  if (col < 0 || rank == null || rank < 1 || rank > 8) {
    return null;
  }
  return Square(8 - rank, col);
}
