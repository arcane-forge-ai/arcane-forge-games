import 'package:flutter/foundation.dart';

import '../battlefield/battlefield_models.dart';
import '../domain/chess_models.dart';
import '../game/scenario_setup.dart';
import '../last_piece/last_piece_models.dart';
import '../l10n/runtime_game_locale.dart';

enum StoryCampaignPhase { loading, map, dialogue, battle, results }

enum StoryObjectiveType { reachSquare, checkmate }

enum StoryDialogueSide { left, right }

enum StoryTriggerType {
  turnThreshold,
  actionThreshold,
  namedPieceCapture,
  check,
  treasureResolution,
  objectiveProgress,
}

@immutable
class CampaignPortraitDefinition {
  const CampaignPortraitDefinition({
    required this.stage,
    required this.expression,
    required this.asset,
  });

  final String stage;
  final String expression;
  final String asset;

  factory CampaignPortraitDefinition.fromJson(Map<String, Object?> json) {
    return CampaignPortraitDefinition(
      stage: json['stage']! as String,
      expression: json['expression']! as String,
      asset: json['asset']! as String,
    );
  }
}

@immutable
class CampaignCharacterDefinition {
  const CampaignCharacterDefinition({
    required this.id,
    required this.displayName,
    required this.role,
    required this.storyRole,
    required this.portraits,
  });

  final String id;
  final String displayName;
  final PieceType role;
  final String storyRole;
  final List<CampaignPortraitDefinition> portraits;

  factory CampaignCharacterDefinition.fromJson(Map<String, Object?> json) {
    return CampaignCharacterDefinition(
      id: json['id']! as String,
      displayName: json['displayName']! as String,
      role: PieceType.values.byName(json['role']! as String),
      storyRole: json['storyRole']! as String,
      portraits: List<CampaignPortraitDefinition>.unmodifiable(
        (json['portraits']! as List<Object?>).map(
          (value) => CampaignPortraitDefinition.fromJson(
            value! as Map<String, Object?>,
          ),
        ),
      ),
    );
  }

  String portraitAsset(String stage, String expression) {
    for (final portrait in portraits) {
      if (portrait.stage == stage && portrait.expression == expression) {
        return portrait.asset;
      }
    }
    for (final portrait in portraits) {
      if (portrait.stage == stage && portrait.expression == 'neutral') {
        return portrait.asset;
      }
    }
    return portraits.first.asset;
  }
}

@immutable
class CampaignDialogueLine {
  const CampaignDialogueLine({
    required this.id,
    required this.speakerId,
    required this.portraitStage,
    required this.expression,
    required this.side,
    required this.text,
    this.musicCue,
    this.sfxCue,
  });

  final String id;
  final String speakerId;
  final String portraitStage;
  final String expression;
  final StoryDialogueSide side;
  final String text;
  final String? musicCue;
  final String? sfxCue;

  factory CampaignDialogueLine.fromJson(Map<String, Object?> json) {
    return CampaignDialogueLine(
      id: json['id']! as String,
      speakerId: json['speakerId']! as String,
      portraitStage: json['portraitStage']! as String,
      expression: json['expression']! as String,
      side: StoryDialogueSide.values.byName(json['side']! as String),
      text: json['text']! as String,
      musicCue: json['musicCue'] as String?,
      sfxCue: json['sfxCue'] as String?,
    );
  }
}

@immutable
class CampaignSceneDefinition {
  const CampaignSceneDefinition({
    required this.id,
    required this.lines,
    required this.blocking,
  });

  final String id;
  final List<CampaignDialogueLine> lines;
  final bool blocking;

  factory CampaignSceneDefinition.fromJson(Map<String, Object?> json) {
    return CampaignSceneDefinition(
      id: json['id']! as String,
      lines: List<CampaignDialogueLine>.unmodifiable(
        (json['lines']! as List<Object?>).map(
          (value) =>
              CampaignDialogueLine.fromJson(value! as Map<String, Object?>),
        ),
      ),
      blocking: json['blocking'] as bool? ?? true,
    );
  }
}

@immutable
class MissionObjective {
  const MissionObjective({required this.type, this.targetSquare});

  final StoryObjectiveType type;
  final Square? targetSquare;

  factory MissionObjective.fromJson(Map<String, Object?> json) {
    final type = StoryObjectiveType.values.byName(json['type']! as String);
    return MissionObjective(
      type: type,
      targetSquare: json['targetSquare'] == null
          ? null
          : squareFromName(json['targetSquare']! as String),
    );
  }
}

@immutable
class CampaignTrigger {
  const CampaignTrigger({
    required this.id,
    required this.type,
    required this.sceneId,
    this.threshold,
    this.characterId,
  });

  final String id;
  final StoryTriggerType type;
  final String sceneId;
  final int? threshold;
  final String? characterId;

  factory CampaignTrigger.fromJson(Map<String, Object?> json) {
    return CampaignTrigger(
      id: json['id']! as String,
      type: StoryTriggerType.values.byName(json['type']! as String),
      sceneId: json['sceneId']! as String,
      threshold: (json['threshold'] as num?)?.toInt(),
      characterId: json['characterId'] as String?,
    );
  }
}

@immutable
class CampaignAiProfile {
  const CampaignAiProfile({
    required this.aggression,
    required this.defense,
    required this.objectivePressure,
    required this.tileAppetite,
  });

  final double aggression;
  final double defense;
  final double objectivePressure;
  final double tileAppetite;

  factory CampaignAiProfile.fromJson(Map<String, Object?> json) {
    return CampaignAiProfile(
      aggression: (json['aggression']! as num).toDouble(),
      defense: (json['defense']! as num).toDouble(),
      objectivePressure: (json['objectivePressure']! as num).toDouble(),
      tileAppetite: (json['tileAppetite']! as num).toDouble(),
    );
  }
}

@immutable
class CampaignPieceDefinition {
  const CampaignPieceDefinition({
    required this.id,
    required this.type,
    required this.color,
    required this.square,
    required this.countryId,
    required this.loyalty,
    required this.fairPrice,
    this.characterId,
    this.personalityId,
    this.hasMoved = false,
  });

  final String id;
  final PieceType type;
  final PieceColor color;
  final Square square;
  final String countryId;
  final int? loyalty;
  final int? fairPrice;
  final String? characterId;
  final String? personalityId;
  final bool hasMoved;

  factory CampaignPieceDefinition.fromJson(Map<String, Object?> json) {
    return CampaignPieceDefinition(
      id: json['id']! as String,
      type: PieceType.values.byName(json['type']! as String),
      color: PieceColor.values.byName(json['color']! as String),
      square: squareFromName(json['square']! as String),
      countryId: json['countryId']! as String,
      loyalty: (json['loyalty'] as num?)?.toInt(),
      fairPrice: (json['fairPrice'] as num?)?.toInt(),
      characterId: json['characterId'] as String?,
      personalityId: json['personalityId'] as String?,
      hasMoved: json['hasMoved'] as bool? ?? false,
    );
  }

  ScenarioPiecePlacement toPlacement() {
    return ScenarioPiecePlacement(
      square: square,
      piece: ChessPiece(
        id: id,
        type: type,
        color: color,
        countryId: countryId,
        loyalty: loyalty,
        fairPrice: fairPrice,
        characterId: characterId,
        personalityId: personalityId,
        hasMoved: hasMoved,
      ),
    );
  }
}

@immutable
class CampaignMissionDefinition {
  const CampaignMissionDefinition({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.prerequisiteId,
    required this.mapX,
    required this.mapY,
    required this.kingPortraitStage,
    required this.objective,
    required this.whiteCountryId,
    required this.blackCountryId,
    required this.startingTurn,
    required this.battlefieldId,
    required this.seed,
    required this.economyEnabled,
    required this.merchantEnabled,
    required this.specialTilesEnabled,
    required this.whiteGold,
    required this.blackGold,
    required this.merchantSpeed,
    required this.pieces,
    required this.preBattleSceneId,
    required this.victorySceneId,
    required this.defeatSceneId,
    required this.triggers,
    required this.recruitRewards,
    required this.aiProfile,
  });

  final String id;
  final String title;
  final String subtitle;
  final String? prerequisiteId;
  final double mapX;
  final double mapY;
  final String kingPortraitStage;
  final MissionObjective objective;
  final String whiteCountryId;
  final String blackCountryId;
  final PieceColor startingTurn;
  final BattlefieldId battlefieldId;
  final int seed;
  final bool economyEnabled;
  final bool merchantEnabled;
  final bool specialTilesEnabled;
  final int whiteGold;
  final int blackGold;
  final int merchantSpeed;
  final List<CampaignPieceDefinition> pieces;
  final String preBattleSceneId;
  final String victorySceneId;
  final String defeatSceneId;
  final List<CampaignTrigger> triggers;
  final List<String> recruitRewards;
  final CampaignAiProfile aiProfile;

  String get primaryVictoryCondition => switch (objective.type) {
    StoryObjectiveType.reachSquare =>
      RuntimeGameLocale.copy.storyReachSquareWithKing(
        lastPieceSquareName(objective.targetSquare!),
        RuntimeGameLocale.copy.storyKingRowan,
      ),
    StoryObjectiveType.checkmate =>
      RuntimeGameLocale.copy.storyCheckmateEnemyKing,
  };

  String? get alternateVictoryCondition => switch (objective.type) {
    StoryObjectiveType.reachSquare =>
      RuntimeGameLocale.copy.storyCheckmateEnemyKing,
    StoryObjectiveType.checkmate => null,
  };

  List<String> get victoryConditions => <String>[
    primaryVictoryCondition,
    ?alternateVictoryCondition,
  ];

  String get victoryConditionsInline =>
      victoryConditions.join(RuntimeGameLocale.copy.storyOrSeparator);

  String get objectiveLabel => primaryVictoryCondition;

  factory CampaignMissionDefinition.fromJson(Map<String, Object?> json) {
    final mapNode = json['mapNode']! as Map<String, Object?>;
    final mechanics = json['mechanics']! as Map<String, Object?>;
    final gold = json['gold']! as Map<String, Object?>;
    final scenes = json['scenes']! as Map<String, Object?>;
    return CampaignMissionDefinition(
      id: json['id']! as String,
      title: json['title']! as String,
      subtitle: json['subtitle']! as String,
      prerequisiteId: json['prerequisiteId'] as String?,
      mapX: (mapNode['x']! as num).toDouble(),
      mapY: (mapNode['y']! as num).toDouble(),
      kingPortraitStage: json['kingPortraitStage']! as String,
      objective: MissionObjective.fromJson(
        json['objective']! as Map<String, Object?>,
      ),
      whiteCountryId: json['whiteCountryId']! as String,
      blackCountryId: json['blackCountryId']! as String,
      startingTurn: PieceColor.values.byName(json['startingTurn']! as String),
      battlefieldId: BattlefieldId.values.byName(
        json['battlefieldId']! as String,
      ),
      seed: (json['seed']! as num).toInt(),
      economyEnabled: mechanics['economy']! as bool,
      merchantEnabled: mechanics['merchant']! as bool,
      specialTilesEnabled: mechanics['specialTiles']! as bool,
      whiteGold: (gold['white']! as num).toInt(),
      blackGold: (gold['black']! as num).toInt(),
      merchantSpeed: (json['merchantSpeed']! as num).toInt(),
      pieces: List<CampaignPieceDefinition>.unmodifiable(
        (json['pieces']! as List<Object?>).map(
          (value) =>
              CampaignPieceDefinition.fromJson(value! as Map<String, Object?>),
        ),
      ),
      preBattleSceneId: scenes['preBattle']! as String,
      victorySceneId: scenes['victory']! as String,
      defeatSceneId: scenes['defeat']! as String,
      triggers: List<CampaignTrigger>.unmodifiable(
        (json['triggers'] as List<Object?>? ?? const []).map(
          (value) => CampaignTrigger.fromJson(value! as Map<String, Object?>),
        ),
      ),
      recruitRewards: (json['recruitRewards'] as List<Object?>? ?? const [])
          .cast<String>(),
      aiProfile: CampaignAiProfile.fromJson(
        json['aiProfile']! as Map<String, Object?>,
      ),
    );
  }

  ScenarioGameSetup toScenarioSetup() {
    return ScenarioGameSetup(
      id: id,
      whiteCountryId: whiteCountryId,
      blackCountryId: blackCountryId,
      turn: startingTurn,
      battlefieldId: battlefieldId,
      battlefieldSeed: seed,
      whiteGold: whiteGold,
      blackGold: blackGold,
      merchantSpeed: merchantSpeed,
      economyEnabled: economyEnabled,
      merchantEnabled: merchantEnabled,
      specialTilesEnabled: specialTilesEnabled,
      pieces: pieces.map((piece) => piece.toPlacement()).toList(),
    );
  }
}

@immutable
class CampaignDefinition {
  const CampaignDefinition({
    required this.schemaVersion,
    required this.id,
    required this.title,
    required this.theme,
    required this.characters,
    required this.scenes,
    required this.missions,
  });

  final int schemaVersion;
  final String id;
  final String title;
  final String theme;
  final List<CampaignCharacterDefinition> characters;
  final List<CampaignSceneDefinition> scenes;
  final List<CampaignMissionDefinition> missions;

  CampaignCharacterDefinition characterById(String id) =>
      characters.firstWhere((character) => character.id == id);

  CampaignSceneDefinition sceneById(String id) =>
      scenes.firstWhere((scene) => scene.id == id);

  CampaignMissionDefinition missionById(String id) =>
      missions.firstWhere((mission) => mission.id == id);

  CampaignMissionDefinition? nextAfter(String id) {
    final index = missions.indexWhere((mission) => mission.id == id);
    return index >= 0 && index + 1 < missions.length
        ? missions[index + 1]
        : null;
  }
}
