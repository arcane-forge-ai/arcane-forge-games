import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

abstract interface class CampaignProfileStore {
  Future<String?> read();

  Future<void> write(String value);
}

class SharedPreferencesCampaignProfileStore implements CampaignProfileStore {
  SharedPreferencesCampaignProfileStore({SharedPreferencesAsync? preferences})
    : _preferences = preferences;

  static const storageKey = 'story_campaign.profile.v1';

  SharedPreferencesAsync? _preferences;
  String? _testFallback;

  @override
  Future<String?> read() async {
    try {
      _preferences ??= SharedPreferencesAsync();
      return await _preferences!.getString(storageKey);
    } on StateError {
      return _testFallback;
    }
  }

  @override
  Future<void> write(String value) async {
    try {
      _preferences ??= SharedPreferencesAsync();
      await _preferences!.setString(storageKey, value);
    } on StateError {
      _testFallback = value;
    }
  }
}

class CampaignProfile {
  CampaignProfile({
    required this.schemaVersion,
    required this.unlockedMissionIds,
    required this.completedMissionIds,
    required this.recruitedCharacterIds,
    required this.seenSceneIds,
    required this.lastSelectedNode,
  });

  static const currentSchemaVersion = 1;

  int schemaVersion;
  final Set<String> unlockedMissionIds;
  final Set<String> completedMissionIds;
  final Set<String> recruitedCharacterIds;
  final Set<String> seenSceneIds;
  String lastSelectedNode;

  factory CampaignProfile.fresh() {
    return CampaignProfile(
      schemaVersion: currentSchemaVersion,
      unlockedMissionIds: <String>{'m01'},
      completedMissionIds: <String>{},
      recruitedCharacterIds: <String>{'king_rowan'},
      seenSceneIds: <String>{},
      lastSelectedNode: 'm01',
    );
  }

  factory CampaignProfile.fromJson(Map<String, Object?> json) {
    final profile = CampaignProfile(
      schemaVersion: (json['schemaVersion'] as num?)?.toInt() ?? 0,
      unlockedMissionIds:
          (json['unlockedMissionIds'] as List<Object?>? ?? const [])
              .whereType<String>()
              .toSet(),
      completedMissionIds:
          (json['completedMissionIds'] as List<Object?>? ?? const [])
              .whereType<String>()
              .toSet(),
      recruitedCharacterIds:
          (json['recruitedCharacterIds'] as List<Object?>? ?? const [])
              .whereType<String>()
              .toSet(),
      seenSceneIds: (json['seenSceneIds'] as List<Object?>? ?? const [])
          .whereType<String>()
          .toSet(),
      lastSelectedNode: json['lastSelectedNode'] as String? ?? 'm01',
    );
    profile._migrate();
    return profile;
  }

  void _migrate() {
    schemaVersion = currentSchemaVersion;
    unlockedMissionIds.add('m01');
    recruitedCharacterIds.add('king_rowan');
    if (!unlockedMissionIds.contains(lastSelectedNode)) {
      lastSelectedNode = 'm01';
    }
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': currentSchemaVersion,
    'unlockedMissionIds': unlockedMissionIds.toList()..sort(),
    'completedMissionIds': completedMissionIds.toList()..sort(),
    'recruitedCharacterIds': recruitedCharacterIds.toList()..sort(),
    'seenSceneIds': seenSceneIds.toList()..sort(),
    'lastSelectedNode': lastSelectedNode,
  };
}

class CampaignProfileRepository {
  CampaignProfileRepository({required CampaignProfileStore store})
    : _store = store;

  final CampaignProfileStore _store;

  Future<CampaignProfile> load() async {
    final source = await _store.read();
    if (source == null || source.isEmpty) {
      return CampaignProfile.fresh();
    }
    try {
      final decoded = jsonDecode(source);
      if (decoded is! Map<String, Object?>) {
        return CampaignProfile.fresh();
      }
      return CampaignProfile.fromJson(decoded);
    } on FormatException {
      return CampaignProfile.fresh();
    } on TypeError {
      return CampaignProfile.fresh();
    }
  }

  Future<void> save(CampaignProfile profile) {
    return _store.write(jsonEncode(profile.toJson()));
  }
}
