import 'dart:async';

import 'package:audioplayers/audioplayers.dart';

abstract interface class StoryAudioPort {
  void playMusic(String cue);

  void playSfx(String cue);

  Future<void> dispose();
}

class StoryAudioController implements StoryAudioPort {
  StoryAudioController({AudioPlayer? musicPlayer, AudioPlayer? sfxPlayer})
    : _musicPlayer = musicPlayer ?? AudioPlayer(),
      _sfxPlayer = sfxPlayer ?? AudioPlayer();

  static const _musicAssets = <String, String>{
    'campaign_map': 'runtime/audio/story/music/campaign_map.mp3',
    'battle_tension': 'runtime/audio/story/music/battle_tension.mp3',
    'emotional_finale': 'runtime/audio/story/music/emotional_finale.mp3',
  };

  static const _sfxAssets = <String, String>{
    'node_unlock': 'runtime/audio/story/sfx/node_unlock.mp3',
    'mission_start': 'runtime/audio/story/sfx/mission_start.mp3',
    'warning': 'runtime/audio/story/sfx/warning.mp3',
    'treasure': 'runtime/audio/story/sfx/treasure.mp3',
    'victory': 'runtime/audio/story/sfx/victory.mp3',
    'defeat': 'runtime/audio/story/sfx/defeat.mp3',
  };

  final AudioPlayer _musicPlayer;
  final AudioPlayer _sfxPlayer;
  String? _activeMusicCue;
  bool _disposed = false;

  @override
  void playMusic(String cue) {
    if (_disposed || cue == _activeMusicCue || !_musicAssets.containsKey(cue)) {
      return;
    }
    _activeMusicCue = cue;
    unawaited(_playMusic(cue));
  }

  Future<void> _playMusic(String cue) async {
    try {
      await _musicPlayer.setReleaseMode(ReleaseMode.loop);
      await _musicPlayer.play(AssetSource(_musicAssets[cue]!), volume: .38);
    } on Object {
      // Browser autoplay policy and unavailable platform plugins must never
      // block campaign navigation. A later user action retries a new cue.
      _activeMusicCue = null;
    }
  }

  @override
  void playSfx(String cue) {
    if (_disposed || !_sfxAssets.containsKey(cue)) {
      return;
    }
    unawaited(_playSfx(cue));
  }

  Future<void> _playSfx(String cue) async {
    try {
      await _sfxPlayer.setReleaseMode(ReleaseMode.stop);
      await _sfxPlayer.play(AssetSource(_sfxAssets[cue]!), volume: .72);
    } on Object {
      // SFX is presentational. Missing playback support must not alter rules,
      // input gating, saves, or mission progression.
    }
  }

  @override
  Future<void> dispose() async {
    if (_disposed) {
      return;
    }
    _disposed = true;
    await Future.wait<void>([_musicPlayer.dispose(), _sfxPlayer.dispose()]);
  }
}

class SilentStoryAudio implements StoryAudioPort {
  const SilentStoryAudio();

  @override
  Future<void> dispose() async {}

  @override
  void playMusic(String cue) {}

  @override
  void playSfx(String cue) {}
}
