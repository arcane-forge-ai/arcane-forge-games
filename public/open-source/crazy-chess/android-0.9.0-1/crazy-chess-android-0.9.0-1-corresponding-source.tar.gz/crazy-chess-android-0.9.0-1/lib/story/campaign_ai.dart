import 'dart:math' as math;

import '../battlefield/battlefield_models.dart';
import '../domain/chess_models.dart';
import '../domain/economy_config.dart';
import '../game/chess_board_ops.dart';
import '../game/chess_rules_service.dart';
import '../game/game_controller.dart';
import 'story_models.dart';

class CampaignAi {
  CampaignAi({required this.seed, math.Random? random})
    : _random = random ?? math.Random(seed);

  final int seed;
  final math.Random _random;
  int _lastOfferAction = -1000;
  static const ChessBoardOps _boardOps = ChessBoardOps();
  static const ChessRulesService _rules = ChessRulesService();

  ChessMove? chooseMove({
    required GameController controller,
    required CampaignMissionDefinition mission,
  }) => chooseConfiguredMove(
    controller: controller,
    aiProfile: mission.aiProfile,
    targetSquare: mission.objective.targetSquare,
  );

  ChessMove? chooseConfiguredMove({
    required GameController controller,
    required CampaignAiProfile aiProfile,
    Square? targetSquare,
  }) {
    final color = controller.turn;
    final candidates = <_ScoredMove>[];
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final from = Square(row, col);
        final piece = controller.pieceAt(from);
        if (piece == null || piece.color != color) {
          continue;
        }
        for (final move in controller.legalMovesFrom(from)) {
          candidates.add(
            _ScoredMove(
              move,
              _scoreMove(
                controller: controller,
                aiProfile: aiProfile,
                targetSquare: targetSquare,
                move: move,
                mover: piece,
              ),
            ),
          );
        }
      }
    }
    if (candidates.isEmpty) {
      return null;
    }
    candidates.sort((a, b) => b.score.compareTo(a.score));
    final best = candidates.first.score;
    final tied = candidates
        .where((candidate) => (candidate.score - best).abs() < 0.001)
        .toList();
    return tied[_random.nextInt(tied.length)].move;
  }

  /// Chooses an offer using only board-visible identity, piece type, the
  /// public fair-price anchors, public gold, and the configured AI profile.
  /// Hidden Loyalty and per-piece fairPrice are deliberately never read.
  CampaignAiOfferPlan? chooseConfiguredOffer({
    required GameController controller,
    required CampaignAiProfile aiProfile,
    String? objectiveTargetPieceId,
  }) {
    if (!controller.economyEnabled ||
        controller.phase != GamePhase.playing ||
        controller.activeKingInCheck ||
        controller.gold[controller.turn]! <= 0 ||
        controller.completedActionCount < 3 ||
        controller.completedActionCount - _lastOfferAction < 4) {
      return null;
    }

    final interest = aiProfile.aggression + aiProfile.objectivePressure;
    final interval = interest >= 1.25
        ? 3
        : interest >= .7
        ? 4
        : 5;
    if ((controller.completedActionCount + seed) % interval != 0) {
      return null;
    }

    final candidates = _offerCandidates(
      controller: controller,
      aiProfile: aiProfile,
      objectiveTargetPieceId: objectiveTargetPieceId,
    );
    if (candidates.isEmpty) return null;
    _lastOfferAction = controller.completedActionCount;
    return _selectOffer(candidates);
  }

  /// Living Campaign checks for an affordable public-information plan first,
  /// then independently consumes its seeded attempt roll. Unlike the authored
  /// Story Campaign policy, this has no opening delay or action cooldown.
  CampaignAiOfferPlan? chooseLivingOffer({
    required GameController controller,
    required CampaignAiProfile aiProfile,
    required double attemptChance,
    String? objectiveTargetPieceId,
  }) {
    assert(attemptChance >= 0 && attemptChance <= 1);
    if (!controller.economyEnabled ||
        controller.phase != GamePhase.playing ||
        controller.activeKingInCheck ||
        controller.gold[controller.turn]! <= 0) {
      return null;
    }
    final candidates = _offerCandidates(
      controller: controller,
      aiProfile: aiProfile,
      objectiveTargetPieceId: objectiveTargetPieceId,
    );
    if (candidates.isEmpty || _random.nextDouble() >= attemptChance) {
      return null;
    }
    return _selectOffer(candidates);
  }

  Square? chooseConfiguredRedeploy({
    required GameController controller,
    required CampaignAiProfile aiProfile,
    Square? targetSquare,
  }) {
    final candidates = controller.legalRedeploySquares();
    if (candidates.isEmpty) return null;
    final scored = candidates.map((square) {
      final centerDistance =
          (square.row - 3.5).abs() + (square.col - 3.5).abs();
      var score = -centerDistance * aiProfile.defense;
      if (targetSquare != null) {
        final targetDistance =
            (square.row - targetSquare.row).abs() +
            (square.col - targetSquare.col).abs();
        score -= targetDistance * aiProfile.objectivePressure;
      }
      return _ScoredSquare(square, score);
    }).toList()..sort((a, b) => b.score.compareTo(a.score));
    final best = scored.first.score;
    final tied = scored
        .where((candidate) => (candidate.score - best).abs() < .001)
        .toList();
    return tied[_random.nextInt(tied.length)].square;
  }

  double _scoreMove({
    required GameController controller,
    required CampaignAiProfile aiProfile,
    required Square? targetSquare,
    required ChessMove move,
    required ChessPiece mover,
  }) {
    final board = _boardOps.clone(controller.board);
    final captured = move.isEnPassant
        ? board[move.from.row][move.to.col]
        : board[move.to.row][move.to.col];
    _boardOps.applyMove(board, move, promotionOverride: PieceType.queen);
    final enemy = mover.color == PieceColor.white
        ? PieceColor.black
        : PieceColor.white;
    final enemyKing = _boardOps.kingSquare(board, enemy);
    final givesCheck =
        enemyKing != null &&
        _rules.isSquareAttacked(
          board: board,
          square: enemyKing,
          byColor: mover.color,
        );
    final mate = givesCheck && !_hasLegalReply(board, enemy);
    if (mate) {
      return 100000;
    }

    var score =
        (captured == null ? 0 : _pieceValue(captured.type) * 12) *
        aiProfile.aggression;
    if (givesCheck) {
      score += 90 * aiProfile.aggression;
    }
    final ownKing = _boardOps.kingSquare(board, mover.color);
    if (ownKing != null) {
      final distanceFromCenter =
          (ownKing.row - 3.5).abs() + (ownKing.col - 3.5).abs();
      score += distanceFromCenter * aiProfile.defense;
    }
    final target = targetSquare;
    if (target != null && mover.color == PieceColor.black) {
      final playerKing = _boardOps.kingSquare(board, PieceColor.white);
      if (playerKing != null) {
        final distance =
            (playerKing.row - target.row).abs() +
            (playerKing.col - target.col).abs();
        score -= distance * aiProfile.objectivePressure;
      }
    }
    final tile = controller.specialTileAt(move.to);
    if (tile != null) {
      score += _tileScore(tile.type, mover.type) * aiProfile.tileAppetite;
    }
    score += _developmentScore(move, mover.type);
    return score;
  }

  List<_ScoredOffer> _offerCandidates({
    required GameController controller,
    required CampaignAiProfile aiProfile,
    required String? objectiveTargetPieceId,
  }) {
    final candidates = <_ScoredOffer>[];
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final square = Square(row, col);
        final piece = controller.pieceAt(square);
        if (piece == null ||
            piece.color == controller.turn ||
            piece.type == PieceType.king) {
          continue;
        }
        final anchor = fairPriceAnchors[piece.type]!;
        final budget = controller.gold[controller.turn]!;
        final offer = math.min(anchor, budget);
        if (offer < 1) continue;
        var score = _pieceValue(piece.type) * (1 + aiProfile.aggression);
        if (piece.id == objectiveTargetPieceId) {
          score += 20 * aiProfile.objectivePressure;
        }
        candidates.add(
          _ScoredOffer(CampaignAiOfferPlan(target: square, gold: offer), score),
        );
      }
    }
    return candidates;
  }

  CampaignAiOfferPlan _selectOffer(List<_ScoredOffer> candidates) {
    candidates.sort((a, b) => b.score.compareTo(a.score));
    final best = candidates.first.score;
    final tied = candidates
        .where((candidate) => (candidate.score - best).abs() < .001)
        .toList();
    return tied[_random.nextInt(tied.length)].plan;
  }

  bool _hasLegalReply(List<List<ChessPiece?>> board, PieceColor color) {
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final from = Square(row, col);
        final piece = board[row][col];
        if (piece == null || piece.color != color) {
          continue;
        }
        for (final move in _rules.pseudoMoves(board: board, from: from)) {
          final simulated = _boardOps.clone(board);
          _boardOps.applyMove(
            simulated,
            move,
            promotionOverride: PieceType.queen,
          );
          final king = _boardOps.kingSquare(simulated, color);
          if (king != null &&
              !_rules.isSquareAttacked(
                board: simulated,
                square: king,
                byColor: color == PieceColor.white
                    ? PieceColor.black
                    : PieceColor.white,
              )) {
            return true;
          }
        }
      }
    }
    return false;
  }

  double _developmentScore(ChessMove move, PieceType type) {
    final centerDistance =
        (move.to.row - 3.5).abs() + (move.to.col - 3.5).abs();
    return switch (type) {
      PieceType.knight || PieceType.bishop => 7 - centerDistance,
      PieceType.pawn => (move.to.row - move.from.row).abs() * 2,
      _ => 0,
    };
  }

  double _tileScore(SpecialTileType tile, PieceType mover) {
    return switch (tile) {
      SpecialTileType.treasureChest => 35,
      SpecialTileType.diamondRing => mover == PieceType.queen ? 50 : 25,
      SpecialTileType.knightShrine => mover == PieceType.king ? 0 : 12,
      SpecialTileType.visibleTrap => -1000,
      SpecialTileType.mystery => -35,
    };
  }

  int _pieceValue(PieceType type) => switch (type) {
    PieceType.pawn => 1,
    PieceType.knight || PieceType.bishop => 3,
    PieceType.rook => 5,
    PieceType.queen => 9,
    PieceType.king => 100,
  };
}

class CampaignAiOfferPlan {
  const CampaignAiOfferPlan({required this.target, required this.gold});

  final Square target;
  final int gold;
}

class _ScoredMove {
  const _ScoredMove(this.move, this.score);

  final ChessMove move;
  final double score;
}

class _ScoredOffer {
  const _ScoredOffer(this.plan, this.score);

  final CampaignAiOfferPlan plan;
  final double score;
}

class _ScoredSquare {
  const _ScoredSquare(this.square, this.score);

  final Square square;
  final double score;
}
