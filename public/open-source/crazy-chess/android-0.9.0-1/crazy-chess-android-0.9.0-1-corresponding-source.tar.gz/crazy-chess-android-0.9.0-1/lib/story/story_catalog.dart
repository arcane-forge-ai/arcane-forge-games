import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

import '../domain/chess_models.dart';
import '../game/chess_rules_service.dart';
import 'story_models.dart';

class StoryCatalogException implements Exception {
  const StoryCatalogException(this.issues);

  final List<String> issues;

  @override
  String toString() => 'Invalid story campaign:\n${issues.join('\n')}';
}

class StoryCatalog {
  const StoryCatalog(this.campaign);

  static const assetPath = 'assets/data/story/story_campaign.v1.json';
  static const simplifiedChineseOverlayAssetPath =
      'assets/data/story/story_campaign.zh-Hans.v1.json';
  static const ChessRulesService _rules = ChessRulesService();

  final CampaignDefinition campaign;

  static Future<StoryCatalog> loadBundled({
    Locale locale = const Locale('en'),
    AssetBundle? bundle,
  }) async {
    final assets = bundle ?? rootBundle;
    final source = await assets.loadString(assetPath);
    final overlaySource = locale.languageCode == 'zh'
        ? await assets.loadString(simplifiedChineseOverlayAssetPath)
        : null;
    return StoryCatalog.fromJsonString(source, overlaySource: overlaySource);
  }

  factory StoryCatalog.fromJsonString(String source, {String? overlaySource}) {
    final decoded = jsonDecode(source);
    if (decoded is! Map<String, Object?>) {
      throw const StoryCatalogException(<String>['Root must be an object.']);
    }
    if (overlaySource != null) {
      final overlay = jsonDecode(overlaySource);
      if (overlay is! Map<String, Object?>) {
        throw const StoryCatalogException(<String>[
          'Story localization overlay root must be an object.',
        ]);
      }
      _applyLocalizationOverlay(decoded, overlay);
    }
    final characters = (decoded['characters']! as List<Object?>)
        .map(
          (value) => CampaignCharacterDefinition.fromJson(
            value! as Map<String, Object?>,
          ),
        )
        .toList();
    final scenes = (decoded['scenes']! as List<Object?>)
        .map(
          (value) =>
              CampaignSceneDefinition.fromJson(value! as Map<String, Object?>),
        )
        .toList();
    final missions = (decoded['missions']! as List<Object?>)
        .map(
          (value) => CampaignMissionDefinition.fromJson(
            value! as Map<String, Object?>,
          ),
        )
        .toList();
    final catalog = StoryCatalog(
      CampaignDefinition(
        schemaVersion: (decoded['schemaVersion']! as num).toInt(),
        id: decoded['id']! as String,
        title: decoded['title']! as String,
        theme: decoded['theme']! as String,
        characters: List<CampaignCharacterDefinition>.unmodifiable(characters),
        scenes: List<CampaignSceneDefinition>.unmodifiable(scenes),
        missions: List<CampaignMissionDefinition>.unmodifiable(missions),
      ),
    );
    final issues = catalog.validate();
    if (issues.isNotEmpty) {
      throw StoryCatalogException(issues);
    }
    return catalog;
  }

  static void _applyLocalizationOverlay(
    Map<String, Object?> source,
    Map<String, Object?> overlay,
  ) {
    final issues = <String>[];
    final campaign = overlay['campaign'];
    final characters = overlay['characters'];
    final missions = overlay['missions'];
    final dialogue = overlay['dialogue'];
    if (campaign is! Map<String, Object?> ||
        characters is! Map<String, Object?> ||
        missions is! Map<String, Object?> ||
        dialogue is! Map<String, Object?>) {
      throw const StoryCatalogException(<String>[
        'Story localization overlay is missing required maps.',
      ]);
    }

    void requireExactIds(
      String label,
      Set<String> expected,
      Set<String> found,
    ) {
      final missing = expected.difference(found).toList()..sort();
      final extra = found.difference(expected).toList()..sort();
      if (missing.isNotEmpty) {
        issues.add('$label overlay missing IDs: ${missing.join(', ')}.');
      }
      if (extra.isNotEmpty) {
        issues.add('$label overlay has unknown IDs: ${extra.join(', ')}.');
      }
    }

    final sourceCharacters = (source['characters']! as List<Object?>)
        .cast<Map<String, Object?>>();
    requireExactIds(
      'Character',
      sourceCharacters.map((item) => item['id']! as String).toSet(),
      characters.keys.toSet(),
    );
    final sourceMissions = (source['missions']! as List<Object?>)
        .cast<Map<String, Object?>>();
    requireExactIds(
      'Mission',
      sourceMissions.map((item) => item['id']! as String).toSet(),
      missions.keys.toSet(),
    );
    final sourceLines = (source['scenes']! as List<Object?>)
        .cast<Map<String, Object?>>()
        .expand(
          (scene) =>
              (scene['lines']! as List<Object?>).cast<Map<String, Object?>>(),
        )
        .toList();
    requireExactIds(
      'Dialogue',
      sourceLines.map((item) => item['id']! as String).toSet(),
      dialogue.keys.toSet(),
    );
    if (issues.isNotEmpty) {
      throw StoryCatalogException(issues);
    }

    source['title'] = campaign['title']! as String;
    source['theme'] = campaign['theme']! as String;
    for (final character in sourceCharacters) {
      final copy = characters[character['id']]! as Map<String, Object?>;
      character['displayName'] = copy['displayName']! as String;
      character['storyRole'] = copy['storyRole']! as String;
    }
    for (final mission in sourceMissions) {
      final copy = missions[mission['id']]! as Map<String, Object?>;
      mission['title'] = copy['title']! as String;
      mission['subtitle'] = copy['subtitle']! as String;
    }
    for (final line in sourceLines) {
      line['text'] = dialogue[line['id']]! as String;
    }
  }

  List<String> validate() {
    final issues = <String>[];
    final characterIds = <String>{};
    for (final character in campaign.characters) {
      if (!characterIds.add(character.id)) {
        issues.add('Duplicate character id: ${character.id}.');
      }
      if (character.portraits.isEmpty ||
          character.portraits.any((portrait) => portrait.asset.isEmpty)) {
        issues.add('Character ${character.id} has a missing portrait.');
      }
    }

    final sceneIds = <String>{};
    final lineIds = <String>{};
    for (final scene in campaign.scenes) {
      if (!sceneIds.add(scene.id)) {
        issues.add('Duplicate scene id: ${scene.id}.');
      }
      if (scene.lines.isEmpty) {
        issues.add('Scene ${scene.id} has no dialogue lines.');
      }
      for (final line in scene.lines) {
        if (!lineIds.add(line.id)) {
          issues.add('Duplicate dialogue line id: ${line.id}.');
        }
        if (!characterIds.contains(line.speakerId)) {
          issues.add('Line ${line.id} references missing ${line.speakerId}.');
        }
      }
    }

    final missionIds = <String>{};
    for (final mission in campaign.missions) {
      if (!missionIds.add(mission.id)) {
        issues.add('Duplicate mission id: ${mission.id}.');
      }
    }
    if (campaign.missions.length != 7) {
      issues.add('Campaign must contain exactly seven missions.');
    }

    for (var index = 0; index < campaign.missions.length; index++) {
      final mission = campaign.missions[index];
      final expectedPrerequisite = index == 0
          ? null
          : campaign.missions[index - 1].id;
      if (mission.prerequisiteId != expectedPrerequisite) {
        issues.add('${mission.id} has an invalid prerequisite.');
      }
      for (final sceneId in <String>[
        mission.preBattleSceneId,
        mission.victorySceneId,
        mission.defeatSceneId,
        ...mission.triggers.map((trigger) => trigger.sceneId),
      ]) {
        if (!sceneIds.contains(sceneId)) {
          issues.add('${mission.id} references missing scene $sceneId.');
        }
      }
      for (final reward in mission.recruitRewards) {
        if (!characterIds.contains(reward)) {
          issues.add('${mission.id} recruits missing character $reward.');
        }
      }
      final squares = <Square>{};
      final pieceIds = <String>{};
      for (final piece in mission.pieces) {
        if (!squares.add(piece.square)) {
          issues.add('${mission.id} has duplicate square ${piece.square}.');
        }
        if (!pieceIds.add(piece.id)) {
          issues.add('${mission.id} has duplicate piece id ${piece.id}.');
        }
        if (piece.characterId != null &&
            !characterIds.contains(piece.characterId)) {
          issues.add(
            '${mission.id} piece ${piece.id} references missing character.',
          );
        }
      }
      final playerKings = mission.pieces
          .where(
            (piece) =>
                piece.color == PieceColor.white && piece.type == PieceType.king,
          )
          .toList();
      if (playerKings.length != 1 ||
          playerKings.singleOrNull?.characterId != 'king_rowan') {
        issues.add('${mission.id} must contain exactly one King Rowan.');
      }
      final enemyKings = mission.pieces.where(
        (piece) =>
            piece.color == PieceColor.black && piece.type == PieceType.king,
      );
      if (mission.objective.type == StoryObjectiveType.checkmate &&
          enemyKings.length != 1) {
        issues.add('${mission.id} must contain one enemy checkmate target.');
      }
      if (mission.objective.type == StoryObjectiveType.reachSquare &&
          mission.objective.targetSquare == null) {
        issues.add('${mission.id} reachSquare objective has no target.');
      }
      final board = List<List<ChessPiece?>>.generate(
        8,
        (_) => List<ChessPiece?>.filled(8, null),
      );
      for (final piece in mission.pieces) {
        board[piece.square.row][piece.square.col] = piece.toPlacement().piece;
      }
      for (final color in PieceColor.values) {
        final king = mission.pieces
            .where(
              (piece) => piece.color == color && piece.type == PieceType.king,
            )
            .firstOrNull;
        if (king != null &&
            _rules.isSquareAttacked(
              board: board,
              square: king.square,
              byColor: color == PieceColor.white
                  ? PieceColor.black
                  : PieceColor.white,
            )) {
          issues.add('${mission.id} begins with ${color.name} in check.');
        }
      }
    }
    return issues;
  }
}
