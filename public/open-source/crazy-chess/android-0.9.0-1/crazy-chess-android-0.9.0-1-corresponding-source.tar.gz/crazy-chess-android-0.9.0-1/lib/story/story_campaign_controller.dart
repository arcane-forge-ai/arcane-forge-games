import 'dart:async';

import 'package:flutter/widgets.dart';

import '../battlefield/battlefield_models.dart';
import '../domain/chess_models.dart';
import '../game/game_controller.dart';
import 'campaign_ai.dart';
import 'story_audio_controller.dart';
import 'story_catalog.dart';
import 'story_models.dart';
import 'story_profile.dart';

class StoryCampaignController extends ChangeNotifier {
  StoryCampaignController({
    required this.gameController,
    StoryCatalog? catalog,
    CampaignProfileRepository? profileRepository,
    StoryAudioPort? audio,
    this.contentLocale = const Locale('en'),
    this.turnSkipNoticeDuration = const Duration(milliseconds: 1400),
  }) : _catalog = catalog,
       _catalogWasInjected = catalog != null,
       _audio = audio ?? const SilentStoryAudio(),
       profileRepository =
           profileRepository ??
           CampaignProfileRepository(
             store: SharedPreferencesCampaignProfileStore(),
           ) {
    gameController.addListener(_onGameChanged);
  }

  final GameController gameController;
  final CampaignProfileRepository profileRepository;
  final StoryAudioPort _audio;
  final Duration turnSkipNoticeDuration;
  Locale contentLocale;
  final bool _catalogWasInjected;
  StoryCatalog? _catalog;
  CampaignProfile profile = CampaignProfile.fresh();
  StoryCampaignPhase phase = StoryCampaignPhase.loading;
  String selectedMissionId = 'm01';
  CampaignSceneDefinition? activeScene;
  int activeLineIndex = 0;
  bool backlogOpen = false;
  bool missionSucceeded = false;
  bool isAiThinking = false;
  String? turnSkipNotice;
  PieceColor? lastSkippedTurnColor;
  bool noMovePositionLocked = false;
  String? loadError;
  final List<CampaignDialogueLine> backlog = <CampaignDialogueLine>[];
  final Set<String> firedTriggerIds = <String>{};
  final Set<String> capturedNamedCharacterIds = <String>{};
  StoryCampaignPhase _dialogueReturnPhase = StoryCampaignPhase.battle;
  CampaignAi? _campaignAi;
  int _lastProcessedMotionSerial = 0;
  bool _finishingAttempt = false;
  bool _disposed = false;
  Timer? _turnSkipNoticeTimer;
  int _consecutiveNoMoveSkips = 0;

  StoryCatalog get catalog {
    final value = _catalog;
    if (value == null) {
      throw StateError('Story catalog has not loaded.');
    }
    return value;
  }

  CampaignDefinition get campaign => catalog.campaign;

  CampaignMissionDefinition get selectedMission =>
      campaign.missionById(selectedMissionId);

  CampaignMissionDefinition get activeMission => selectedMission;

  CampaignDialogueLine? get activeLine {
    final scene = activeScene;
    if (scene == null || activeLineIndex >= scene.lines.length) {
      return null;
    }
    return scene.lines[activeLineIndex];
  }

  bool get canSkipActiveScene =>
      activeScene != null && profile.seenSceneIds.contains(activeScene!.id);

  bool get playerInputLocked =>
      phase != StoryCampaignPhase.battle ||
      backlogOpen ||
      isAiThinking ||
      turnSkipNotice != null ||
      gameController.turn != PieceColor.white;

  bool get campaignComplete =>
      profile.completedMissionIds.contains(campaign.missions.last.id);

  Future<void> initialize() async {
    phase = StoryCampaignPhase.loading;
    loadError = null;
    notifyListeners();
    try {
      profile = await profileRepository.load();
      _catalog ??= await StoryCatalog.loadBundled(locale: contentLocale);
      if (!profile.unlockedMissionIds.contains(profile.lastSelectedNode) ||
          !campaign.missions.any(
            (mission) => mission.id == profile.lastSelectedNode,
          )) {
        profile.lastSelectedNode = 'm01';
      }
      selectedMissionId = profile.lastSelectedNode;
      phase = StoryCampaignPhase.map;
    } on Object catch (error) {
      loadError = error.toString();
      phase = StoryCampaignPhase.loading;
    }
    notifyListeners();
  }

  Future<void> setContentLocale(Locale locale) async {
    final normalized = locale.languageCode == 'zh'
        ? const Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hans')
        : const Locale('en');
    if (contentLocale == normalized || _catalogWasInjected) {
      contentLocale = normalized;
      return;
    }
    contentLocale = normalized;
    try {
      _catalog = await StoryCatalog.loadBundled(locale: normalized);
      loadError = null;
    } on Object catch (error) {
      loadError = error.toString();
    }
    notifyListeners();
  }

  bool isMissionUnlocked(String id) => profile.unlockedMissionIds.contains(id);

  bool isMissionCompleted(String id) =>
      profile.completedMissionIds.contains(id);

  void enterCampaignMap() {
    _audio.playMusic('campaign_map');
  }

  void selectMission(String id) {
    if (!isMissionUnlocked(id) ||
        !campaign.missions.any((mission) => mission.id == id)) {
      return;
    }
    selectedMissionId = id;
    profile.lastSelectedNode = id;
    unawaited(profileRepository.save(profile));
    notifyListeners();
  }

  void startSelectedMission() {
    if (!isMissionUnlocked(selectedMissionId)) {
      return;
    }
    final mission = selectedMission;
    missionSucceeded = false;
    _finishingAttempt = false;
    firedTriggerIds.clear();
    capturedNamedCharacterIds.clear();
    backlog.clear();
    backlogOpen = false;
    noMovePositionLocked = false;
    _consecutiveNoMoveSkips = 0;
    _clearTurnSkipNotice();
    activeScene = null;
    activeLineIndex = 0;
    _lastProcessedMotionSerial = 0;
    gameController.startScenario(mission.toScenarioSetup());
    _campaignAi = CampaignAi(seed: mission.seed);
    _audio
      ..playSfx('mission_start')
      ..playMusic('battle_tension');
    _showScene(
      mission.preBattleSceneId,
      returnPhase: StoryCampaignPhase.battle,
    );
  }

  void advanceDialogue() {
    final scene = activeScene;
    final line = activeLine;
    if (scene == null || line == null || backlogOpen) {
      return;
    }
    _audio.playSfx('dialogue_advance');
    backlog.add(line);
    if (activeLineIndex + 1 < scene.lines.length) {
      activeLineIndex++;
      _playActiveLineCues();
      notifyListeners();
      return;
    }
    _completeActiveScene();
  }

  void skipActiveScene() {
    final scene = activeScene;
    if (scene == null || !profile.seenSceneIds.contains(scene.id)) {
      return;
    }
    backlog.addAll(scene.lines.skip(activeLineIndex));
    _completeActiveScene();
  }

  void toggleBacklog() {
    if (phase != StoryCampaignPhase.dialogue) {
      return;
    }
    backlogOpen = !backlogOpen;
    notifyListeners();
  }

  void evaluateAfterPresentation() {
    if (phase != StoryCampaignPhase.battle ||
        _finishingAttempt ||
        turnSkipNotice != null) {
      return;
    }
    _recordLatestNamedCapture();

    final objective = activeMission.objective;
    if (objective.type == StoryObjectiveType.reachSquare &&
        gameController.kingSquare(PieceColor.white) == objective.targetSquare) {
      _finishAttempt(success: true);
      return;
    }
    if (gameController.phase == GamePhase.gameOver) {
      final reason = gameController.resolvedGameEndReason;
      if (reason == GameEndReason.stalemate && _skipBlockedTurn()) {
        return;
      }
      // Checkmate is a universal alternate Story victory, including M01's
      // escape scenario. The authored objective is still evaluated first.
      final success =
          reason == GameEndReason.checkmate &&
          gameController.winner == PieceColor.white;
      _finishAttempt(success: success);
      return;
    }
    if (!gameController.activeKingInCheck &&
        !gameController.hasAnyLegalMove(gameController.turn) &&
        _skipBlockedTurn()) {
      return;
    }

    final trigger = _nextSatisfiedTrigger();
    if (trigger != null) {
      firedTriggerIds.add(trigger.id);
      _showScene(trigger.sceneId, returnPhase: StoryCampaignPhase.battle);
    }
  }

  Future<void> makeEnemyMove() async {
    if (phase != StoryCampaignPhase.battle ||
        gameController.phase != GamePhase.playing ||
        gameController.turn != PieceColor.black ||
        turnSkipNotice != null ||
        isAiThinking) {
      return;
    }
    isAiThinking = true;
    notifyListeners();
    await Future<void>.delayed(const Duration(milliseconds: 260));
    if (_disposed ||
        phase != StoryCampaignPhase.battle ||
        gameController.turn != PieceColor.black) {
      isAiThinking = false;
      if (!_disposed) {
        notifyListeners();
      }
      return;
    }
    final move = _campaignAi?.chooseMove(
      controller: gameController,
      mission: activeMission,
    );
    if (move != null) {
      gameController.makeMove(move);
      if (gameController.phase == GamePhase.promotion) {
        gameController.choosePromotion(PieceType.queen);
      }
    }
    isAiThinking = false;
    if (move == null &&
        !gameController.activeKingInCheck &&
        !gameController.hasAnyLegalMove(gameController.turn) &&
        _skipBlockedTurn()) {
      return;
    }
    notifyListeners();
  }

  void retryMission() => startSelectedMission();

  void returnToMap() {
    activeScene = null;
    backlogOpen = false;
    isAiThinking = false;
    noMovePositionLocked = false;
    _consecutiveNoMoveSkips = 0;
    _clearTurnSkipNotice();
    phase = StoryCampaignPhase.map;
    gameController.returnToSetup();
    _audio.playMusic('campaign_map');
    notifyListeners();
  }

  void _showScene(String sceneId, {required StoryCampaignPhase returnPhase}) {
    activeScene = campaign.sceneById(sceneId);
    activeLineIndex = 0;
    backlogOpen = false;
    _dialogueReturnPhase = returnPhase;
    phase = StoryCampaignPhase.dialogue;
    _playActiveLineCues();
    notifyListeners();
  }

  void _completeActiveScene() {
    final scene = activeScene;
    if (scene == null) {
      return;
    }
    profile.seenSceneIds.add(scene.id);
    unawaited(profileRepository.save(profile));
    activeScene = null;
    activeLineIndex = 0;
    backlogOpen = false;
    if (_dialogueReturnPhase == StoryCampaignPhase.results &&
        missionSucceeded) {
      _commitMissionVictory();
    }
    phase = _dialogueReturnPhase;
    notifyListeners();
  }

  void _finishAttempt({required bool success}) {
    if (_finishingAttempt) {
      return;
    }
    _finishingAttempt = true;
    _clearTurnSkipNotice();
    missionSucceeded = success;
    _audio.playSfx(success ? 'victory' : 'defeat');
    if (success && activeMission.id == campaign.missions.last.id) {
      _audio.playMusic('emotional_finale');
    }
    _showScene(
      success ? activeMission.victorySceneId : activeMission.defeatSceneId,
      returnPhase: StoryCampaignPhase.results,
    );
  }

  void _commitMissionVictory() {
    final mission = activeMission;
    profile.completedMissionIds.add(mission.id);
    profile.recruitedCharacterIds.addAll(mission.recruitRewards);
    final next = campaign.nextAfter(mission.id);
    if (next != null) {
      profile.unlockedMissionIds.add(next.id);
      _audio.playSfx('node_unlock');
    }
    unawaited(profileRepository.save(profile));
  }

  void _recordLatestNamedCapture() {
    final motion = gameController.lastBoardMotionEvent;
    if (motion == null || motion.serial <= _lastProcessedMotionSerial) {
      return;
    }
    _lastProcessedMotionSerial = motion.serial;
    _consecutiveNoMoveSkips = 0;
    final characterId = gameController.lastCapturedCharacterId;
    if (characterId != null) {
      capturedNamedCharacterIds.add(characterId);
    }
  }

  bool _skipBlockedTurn() {
    if (_consecutiveNoMoveSkips >= 2) {
      noMovePositionLocked = true;
      lastSkippedTurnColor = null;
      turnSkipNotice =
          'Both courts have no legal move. Return to the Campaign Map and retry.';
      _turnSkipNoticeTimer?.cancel();
      _turnSkipNoticeTimer = null;
      notifyListeners();
      return true;
    }
    final skipped = gameController.skipTurnIfNoLegalMove();
    if (skipped == null) {
      return false;
    }
    _consecutiveNoMoveSkips++;
    lastSkippedTurnColor = skipped;
    final courtName = gameController.countryForColor(skipped).name;
    turnSkipNotice = '$courtName has no legal move. Turn skipped.';
    _turnSkipNoticeTimer?.cancel();
    _turnSkipNoticeTimer = Timer(turnSkipNoticeDuration, () {
      if (_disposed) {
        return;
      }
      turnSkipNotice = null;
      notifyListeners();
    });
    notifyListeners();
    return true;
  }

  void _clearTurnSkipNotice() {
    _turnSkipNoticeTimer?.cancel();
    _turnSkipNoticeTimer = null;
    turnSkipNotice = null;
    lastSkippedTurnColor = null;
  }

  CampaignTrigger? _nextSatisfiedTrigger() {
    for (final trigger in activeMission.triggers) {
      if (firedTriggerIds.contains(trigger.id)) {
        continue;
      }
      final satisfied = switch (trigger.type) {
        StoryTriggerType.turnThreshold || StoryTriggerType.actionThreshold =>
          gameController.turnCount >= (trigger.threshold ?? 0),
        StoryTriggerType.namedPieceCapture =>
          trigger.characterId != null &&
              capturedNamedCharacterIds.contains(trigger.characterId),
        StoryTriggerType.check => gameController.activeKingInCheck,
        StoryTriggerType.treasureResolution =>
          gameController.lastBattlefieldEvent?.type ==
                  BattlefieldEventType.treasureFound ||
              gameController.lastBattlefieldEvent?.type ==
                  BattlefieldEventType.diamondRingFound,
        StoryTriggerType.objectiveProgress =>
          activeMission.objective.targetSquare != null &&
              gameController.kingSquare(PieceColor.white) != null,
      };
      if (satisfied) {
        if (trigger.type == StoryTriggerType.treasureResolution) {
          _audio.playSfx('treasure');
        } else if (trigger.type == StoryTriggerType.check) {
          _audio.playSfx('warning');
        }
        return trigger;
      }
    }
    return null;
  }

  void _onGameChanged() {
    if (!_disposed && phase == StoryCampaignPhase.battle) {
      notifyListeners();
    }
  }

  void _playActiveLineCues() {
    final line = activeLine;
    if (line == null) {
      return;
    }
    if (line.musicCue case final cue?) {
      _audio.playMusic(cue);
    }
    if (line.sfxCue case final cue?) {
      _audio.playSfx(cue);
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _turnSkipNoticeTimer?.cancel();
    gameController.removeListener(_onGameChanged);
    unawaited(_audio.dispose());
    super.dispose();
  }
}
