import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../domain/board_presentation.dart';
import '../domain/chess_models.dart';
import '../game/chess_board_ops.dart';
import '../game/chess_rules_service.dart';
import '../l10n/localized_message.dart';
import 'last_piece_catalog.dart';
import 'last_piece_models.dart';
import 'last_piece_profile.dart';

class LastPieceSessionController extends ChangeNotifier {
  LastPieceSessionController({
    LastPieceLevelCatalog? catalog,
    LastPieceProfileRepository? profileRepository,
    math.Random? random,
  }) : catalog = catalog ?? LastPieceLevelCatalog.defaults,
       profileRepository =
           profileRepository ??
           LastPieceProfileRepository(
             store: SharedPreferencesLastPieceProfileStore(),
           ),
       _random = random ?? math.Random();

  final LastPieceProfileRepository profileRepository;
  static const ChessBoardOps _boardOps = ChessBoardOps();
  final ChessRulesService rules = const ChessRulesService();
  math.Random _random;

  LastPieceLevelCatalog catalog;
  LastPieceProfile profile = LastPieceProfile.fresh();
  LastPieceRunPhase phase = LastPieceRunPhase.idle;
  String selectedCountryId = 'mercantile';
  String selectedLevelId = '001';
  late LastPieceLevelDefinition activeLevel;
  late LastPieceUnit player;
  final List<LastPieceUnit> enemies = <LastPieceUnit>[];
  final List<LastPieceRewardTile> rewardTiles = <LastPieceRewardTile>[];
  final Map<PieceType, int> captureCounts = <PieceType, int>{};
  final List<LocalizedMessageRecord> _eventMessages =
      <LocalizedMessageRecord>[];
  List<LocalizedMessageRecord> get eventMessages =>
      List.unmodifiable(_eventMessages);
  List<String> get eventLog =>
      List.unmodifiable(_eventMessages.map((message) => message.debugEnglish));
  List<String> get localizedEventLog =>
      List.unmodifiable(_eventMessages.map((message) => message.resolve()));
  int seed = 0;
  int score = 0;
  int survivedPhases = 0;
  int capturePoints = 0;
  int tilePoints = 0;
  int transformations = 0;
  int _phasesSinceSpawn = 0;
  int _enemySerial = 0;
  int _tileSerial = 0;
  int _highestAnnouncedStars = 0;
  LastPieceEnemyAction? lastEnemyAction;
  String? milestoneBanner;
  LastPieceRunResult? result;
  bool profileLoaded = false;
  int presentationSequenceSerial = 0;
  List<LastPiecePresentationStep> presentationSteps =
      const <LastPiecePresentationStep>[];
  final List<LastPiecePresentationStep> _pendingPresentationSteps =
      <LastPiecePresentationStep>[];
  int _presentationStepSerial = 0;

  int get stars {
    if (phase == LastPieceRunPhase.idle) {
      return 0;
    }
    return activeLevel.scoreMilestones
        .where((milestone) => score >= milestone)
        .length;
  }

  int get nextMilestone {
    if (phase == LastPieceRunPhase.idle) {
      return 300;
    }
    return activeLevel.scoreMilestones.firstWhere(
      (milestone) => score < milestone,
      orElse: () => activeLevel.scoreMilestones.last,
    );
  }

  int get currentSpawnBatchSize {
    if (phase == LastPieceRunPhase.idle) {
      return 1;
    }
    final milestones = activeLevel.scoreMilestones;
    if (score < milestones[0]) {
      return 1;
    }
    if (score < milestones[1]) {
      return 2;
    }
    final postThreeStarSteps = score <= milestones[2]
        ? 0
        : (score - milestones[2]) ~/ 100;
    return 3 + postThreeStarSteps;
  }

  int familiarityFor(String countryId) =>
      profile.countryFamiliarity[countryId] ?? 0;

  bool isLevelUnlocked(String levelId) =>
      profile.unlockedLevelIds.contains(levelId);

  bool hasReward(String countryId, String reward) =>
      profile.rewardUnlockIds.contains('$countryId:$reward');

  Future<void> loadProfile() async {
    profile = await profileRepository.load();
    profileLoaded = true;
    if (!isLevelUnlocked(selectedLevelId)) {
      selectedLevelId = catalog.levels.first.id;
    }
    notifyListeners();
  }

  Future<void> loadBundledCatalog() async {
    final loaded = await LastPieceLevelCatalog.loadBundled();
    replaceCatalog(loaded);
  }

  void replaceCatalog(LastPieceLevelCatalog value) {
    catalog = value;
    if (!catalog.levels.any((level) => level.id == selectedLevelId)) {
      selectedLevelId = catalog.levels.first.id;
    }
    notifyListeners();
  }

  void selectCountry(String countryId) {
    selectedCountryId = countryId;
    notifyListeners();
  }

  void selectLevel(String levelId) {
    if (!isLevelUnlocked(levelId)) {
      return;
    }
    selectedLevelId = levelId;
    notifyListeners();
  }

  void startRun({String? levelId, String? countryId, int? runSeed}) {
    if (levelId != null && isLevelUnlocked(levelId)) {
      selectedLevelId = levelId;
    }
    if (countryId != null) {
      selectedCountryId = countryId;
    }
    activeLevel = catalog.byId(selectedLevelId);
    seed = runSeed ?? math.Random().nextInt(0x7fffffff);
    _random = math.Random(seed);
    player = LastPieceUnit(
      id: 'player',
      type: activeLevel.startingPiece,
      square: activeLevel.startingSquare,
    );
    enemies.clear();
    rewardTiles.clear();
    captureCounts.clear();
    _eventMessages.clear();
    score = 0;
    survivedPhases = 0;
    capturePoints = 0;
    tilePoints = 0;
    transformations = 0;
    _phasesSinceSpawn = 0;
    _enemySerial = 0;
    _tileSerial = 0;
    _highestAnnouncedStars = 0;
    lastEnemyAction = null;
    milestoneBanner = null;
    result = null;
    presentationSteps = const <LastPiecePresentationStep>[];
    _pendingPresentationSteps.clear();
    presentationSequenceSerial = 0;
    _presentationStepSerial = 0;
    phase = LastPieceRunPhase.playing;
    _log(
      'Level ${activeLevel.id} began with a '
      '${activeLevel.startingPiece.name} on '
      '${lastPieceSquareName(activeLevel.startingSquare)}. Seed $seed.',
    );
    for (var index = 0; index < activeLevel.initialEnemies; index++) {
      if (!_spawnEnemy()) {
        break;
      }
    }
    notifyListeners();
  }

  List<ChessMove> legalPlayerMoves() {
    if (phase != LastPieceRunPhase.playing) {
      return const <ChessMove>[];
    }
    final board = _buildBoard();
    final moves = rules.pseudoMoves(board: board, from: player.square);
    if (player.type != PieceType.king) {
      return moves;
    }
    return moves.where((move) {
      final simulated = _boardOps.clone(board);
      _boardOps.applyMove(simulated, move, markMoved: false);
      return !rules.isSquareAttacked(
        board: simulated,
        square: move.to,
        byColor: PieceColor.black,
      );
    }).toList();
  }

  Future<bool> movePlayer(Square destination) async {
    if (phase != LastPieceRunPhase.playing) {
      return false;
    }
    final move = legalPlayerMoves()
        .where((candidate) => candidate.to == destination)
        .firstOrNull;
    if (move == null) {
      return false;
    }

    _beginPresentationSequence();
    final playerMotionFrame = _snapshotFrame();
    final playerBeforeMove = player;
    final capturedIndex = enemies.indexWhere(
      (enemy) => enemy.square == destination,
    );
    LastPieceUnit? captured;
    if (capturedIndex >= 0) {
      captured = enemies.removeAt(capturedIndex);
      final points = lastPieceCaptureValue(captured.type);
      captureCounts[captured.type] = (captureCounts[captured.type] ?? 0) + 1;
      capturePoints += points;
      score += points;
      _log(
        'Captured ${captured.type.name} on '
        '${lastPieceSquareName(destination)} for $points.',
      );
    }

    player = player.copyWith(square: destination);
    _recordMotion(
      frame: playerMotionFrame,
      moving: playerBeforeMove,
      from: move.from,
      to: destination,
      playerPiece: true,
      captured: captured,
    );
    _activateRewardAt(destination);
    await _checkMilestones();

    if (player.type == PieceType.pawn && destination.row == 0) {
      phase = LastPieceRunPhase.promotion;
      _log('Pawn reached the back rank. Choose a standard promotion.');
      _commitPresentationSequence();
      notifyListeners();
      return true;
    }

    await _runEnemyPhase();
    _commitPresentationSequence();
    notifyListeners();
    return true;
  }

  Future<void> choosePromotion(PieceType type) async {
    if (phase != LastPieceRunPhase.promotion ||
        !const <PieceType>[
          PieceType.queen,
          PieceType.rook,
          PieceType.bishop,
          PieceType.knight,
        ].contains(type)) {
      return;
    }
    _beginPresentationSequence();
    final frame = _snapshotFrame();
    final before = player;
    player = player.copyWith(type: type);
    _recordTransformation(frame: frame, before: before, after: player);
    phase = LastPieceRunPhase.playing;
    _log('Pawn promoted to ${type.name}.');
    await _runEnemyPhase();
    _commitPresentationSequence();
    notifyListeners();
  }

  Future<void> retire() async {
    if (phase != LastPieceRunPhase.playing &&
        phase != LastPieceRunPhase.promotion) {
      return;
    }
    _log('The player retired with $score points.');
    await _finish(LastPieceEndReason.retired);
    notifyListeners();
  }

  void clearMilestoneBanner() {
    milestoneBanner = null;
    notifyListeners();
  }

  Future<void> _runEnemyPhase() async {
    if (phase != LastPieceRunPhase.playing) {
      return;
    }
    final captor = _capturingEnemy();
    if (captor != null) {
      final frame = _snapshotFrame();
      _recordMotion(
        frame: frame,
        moving: captor,
        from: captor.square,
        to: player.square,
        playerPiece: false,
        captured: player,
      );
      lastEnemyAction = LastPieceEnemyAction.capture;
      _log(
        '${captor.type.name} captured the player on '
        '${lastPieceSquareName(player.square)}.',
      );
      await _finish(LastPieceEndReason.captured);
      return;
    }

    _phasesSinceSpawn += 1;
    if (enemies.isEmpty) {
      final spawned = _spawnEnemyBatch();
      _phasesSinceSpawn = 0;
      if (spawned.isNotEmpty) {
        lastEnemyAction = LastPieceEnemyAction.spawn;
        _log(
          'No enemies remained; the tide spawned '
          '${spawned.length} replacement${spawned.length == 1 ? '' : 's'}.',
        );
      } else {
        final frame = _snapshotFrame();
        _recordHunt(frame, _hunt());
        lastEnemyAction = LastPieceEnemyAction.hunt;
        _log('No fair replacement spawn existed; the enemy hunted instead.');
      }
    } else if (_phasesSinceSpawn >= activeLevel.spawnInterval) {
      final spawned = _spawnEnemyBatch();
      _phasesSinceSpawn = 0;
      if (spawned.isNotEmpty) {
        lastEnemyAction = LastPieceEnemyAction.spawn;
      } else {
        final frame = _snapshotFrame();
        _recordHunt(frame, _hunt());
        lastEnemyAction = LastPieceEnemyAction.hunt;
        _log('No fair spawn existed; the enemy hunted instead.');
      }
    } else {
      final frame = _snapshotFrame();
      _recordHunt(frame, _hunt());
      lastEnemyAction = LastPieceEnemyAction.hunt;
    }

    survivedPhases += 1;
    score += 5;
    _log('Survived enemy phase $survivedPhases for 5 points.');
    if (survivedPhases % activeLevel.rewardTileInterval == 0) {
      _attemptRewardTile();
    }
    await _checkMilestones();
  }

  LastPieceUnit? _capturingEnemy() {
    final board = _buildBoard();
    for (final enemy in enemies) {
      if (rules.pieceAttacks(
        board: board,
        from: enemy.square,
        target: player.square,
      )) {
        return enemy;
      }
    }
    return null;
  }

  List<LastPieceUnit> _spawnEnemyBatch() {
    final requested = currentSpawnBatchSize;
    final spawned = <LastPieceUnit>[];
    for (var index = 0; index < requested; index++) {
      final frame = _snapshotFrame();
      if (!_spawnEnemy()) {
        break;
      }
      final unit = enemies.last;
      spawned.add(unit);
      _recordSpawn(frame: frame, spawned: unit);
    }
    if (spawned.isNotEmpty) {
      _log(
        'Spawn batch added ${spawned.length} of $requested requested '
        'at $score points.',
      );
    }
    return spawned;
  }

  bool _spawnEnemy() {
    final type = _weightedEnemyType();
    final candidates = <Square>[
      for (var row = 0; row < 8; row++)
        for (var col = 0; col < 8; col++) Square(row, col),
    ]..shuffle(_random);
    for (final square in candidates) {
      if (square == player.square ||
          enemies.any((enemy) => enemy.square == square)) {
        continue;
      }
      final candidate = LastPieceUnit(
        id: 'enemy-${++_enemySerial}',
        type: type,
        square: square,
      );
      enemies.add(candidate);
      if (_hasSurvivablePlayerResponse()) {
        _log(
          'Spawned ${type.name} on ${lastPieceSquareName(square)}. '
          'Population ${enemies.length}.',
        );
        return true;
      }
      enemies.removeLast();
    }
    return false;
  }

  PieceType _weightedEnemyType() {
    final total = activeLevel.enemyWeights.values.fold<int>(
      0,
      (sum, value) => sum + value,
    );
    var roll = _random.nextInt(total);
    for (final entry in activeLevel.enemyWeights.entries) {
      if (roll < entry.value) {
        return entry.key;
      }
      roll -= entry.value;
    }
    return activeLevel.enemyWeights.keys.last;
  }

  bool _hasSurvivablePlayerResponse() {
    final board = _buildBoard();
    final responses = rules.pseudoMoves(board: board, from: player.square);
    for (final response in responses) {
      final simulated = _boardOps.clone(board);
      _boardOps.applyMove(simulated, response, markMoved: false);
      if (!rules.isSquareAttacked(
        board: simulated,
        square: response.to,
        byColor: PieceColor.black,
      )) {
        return true;
      }
    }
    return false;
  }

  _LastPieceHuntMotion? _hunt() {
    final board = _buildBoard();
    final candidates = <_HuntCandidate>[];
    for (var index = 0; index < enemies.length; index++) {
      final enemy = enemies[index];
      for (final move in rules.pseudoMoves(board: board, from: enemy.square)) {
        if (move.to == player.square) {
          continue;
        }
        final simulated = _boardOps.clone(board);
        _boardOps.applyMove(simulated, move, markMoved: false);
        final threatens = rules.pieceAttacks(
          board: simulated,
          from: move.to,
          target: player.square,
        );
        candidates.add(
          _HuntCandidate(
            enemyIndex: index,
            move: move,
            threatens: threatens,
            distance: _estimatedCaptureDistance(
              enemy.type,
              move.to,
              player.square,
            ),
            value: lastPieceCaptureValue(enemy.type),
            tieBreak: _random.nextInt(0x7fffffff),
          ),
        );
      }
    }
    if (candidates.isEmpty) {
      _log('The enemy phase had no legal hunt move.');
      return null;
    }
    candidates.sort(_compareHuntCandidates);
    final chosen = candidates.first;
    final enemy = enemies[chosen.enemyIndex];
    final moved = enemy.copyWith(square: chosen.move.to);
    enemies[chosen.enemyIndex] = moved;
    _log(
      '${enemy.type.name} hunted from '
      '${lastPieceSquareName(enemy.square)} to '
      '${lastPieceSquareName(chosen.move.to)}.',
    );
    return _LastPieceHuntMotion(before: enemy, after: moved);
  }

  int _compareHuntCandidates(_HuntCandidate a, _HuntCandidate b) {
    if (a.threatens != b.threatens) {
      return a.threatens ? -1 : 1;
    }
    final distance = a.distance.compareTo(b.distance);
    if (distance != 0) {
      return distance;
    }
    final value = b.value.compareTo(a.value);
    if (value != 0) {
      return value;
    }
    return a.tieBreak.compareTo(b.tieBreak);
  }

  int _estimatedCaptureDistance(PieceType type, Square from, Square target) {
    final row = (from.row - target.row).abs();
    final col = (from.col - target.col).abs();
    return switch (type) {
      PieceType.queen => row == col || row == 0 || col == 0 ? 1 : 2,
      PieceType.rook => row == 0 || col == 0 ? 1 : 2,
      PieceType.bishop => row == col ? 1 : 2 + ((row - col).abs() ~/ 2),
      PieceType.knight => math.max(1, ((row + col) / 3).ceil()),
      PieceType.king => math.max(row, col),
      PieceType.pawn => row + col,
    };
  }

  void _attemptRewardTile() {
    if (rewardTiles.length >= activeLevel.maxRewardTiles) {
      return;
    }
    final candidates = <Square>[
      for (var row = 0; row < 8; row++)
        for (var col = 0; col < 8; col++)
          if (Square(row, col) != player.square &&
              !enemies.any((enemy) => enemy.square == Square(row, col)) &&
              !rewardTiles.any((tile) => tile.square == Square(row, col)))
            Square(row, col),
    ]..shuffle(_random);
    if (candidates.isEmpty) {
      return;
    }

    final wantsScore = _random.nextInt(100) < 60;
    if (wantsScore) {
      final roll = _random.nextInt(100);
      final value = roll < 60
          ? 25
          : roll < 90
          ? 50
          : 100;
      final square = candidates.first;
      rewardTiles.add(
        LastPieceRewardTile.score(
          id: 'reward-${++_tileSerial}',
          square: square,
          scoreValue: value,
        ),
      );
      _log('A $value Score Tile appeared on ${lastPieceSquareName(square)}.');
      return;
    }

    final roles = PieceType.values.where((role) => role != player.type).toList()
      ..shuffle(_random);
    for (final role in roles) {
      final validSquares = role == PieceType.pawn
          ? candidates.where((square) => square.row != 0).toList()
          : candidates;
      if (validSquares.isEmpty) {
        continue;
      }
      final square = validSquares.first;
      rewardTiles.add(
        LastPieceRewardTile.transformation(
          id: 'reward-${++_tileSerial}',
          square: square,
          targetRole: role,
        ),
      );
      _log(
        'A ${role.name} Transformation Tile appeared on '
        '${lastPieceSquareName(square)}.',
      );
      return;
    }
  }

  void _activateRewardAt(Square square) {
    final index = rewardTiles.indexWhere((tile) => tile.square == square);
    if (index < 0) {
      return;
    }
    final tile = rewardTiles[index];
    if (tile.kind == LastPieceRewardKind.score) {
      rewardTiles.removeAt(index);
      final value = tile.scoreValue!;
      score += value;
      tilePoints += value;
      _log('Collected a $value Score Tile.');
      return;
    }
    final frame = _snapshotFrame();
    final before = player;
    rewardTiles.removeAt(index);
    final target = tile.targetRole!;
    player = player.copyWith(type: target);
    _recordTransformation(frame: frame, before: before, after: player);
    transformations += 1;
    _log('Transformed into ${target.name}.');
  }

  void _beginPresentationSequence() {
    _pendingPresentationSteps.clear();
  }

  void _commitPresentationSequence() {
    if (_pendingPresentationSteps.isEmpty) {
      presentationSteps = const <LastPiecePresentationStep>[];
      return;
    }
    presentationSteps = List<LastPiecePresentationStep>.unmodifiable(
      _pendingPresentationSteps,
    );
    presentationSequenceSerial += 1;
  }

  LastPieceBoardFrame _snapshotFrame() {
    return LastPieceBoardFrame(
      player: player,
      enemies: List<LastPieceUnit>.unmodifiable(enemies),
      rewardTiles: List<LastPieceRewardTile>.unmodifiable(rewardTiles),
    );
  }

  PresentedPiece _presentedPiece(
    LastPieceUnit unit, {
    required bool playerPiece,
  }) {
    return PresentedPiece(
      id: unit.id,
      type: unit.type,
      color: playerPiece ? PieceColor.white : PieceColor.black,
      countryId: playerPiece ? selectedCountryId : 'iron',
      loyalty: null,
      fairPrice: null,
      hasMoved: true,
      personalityId: null,
      newlyPurchased: false,
      loyaltyBand: null,
    );
  }

  void _recordMotion({
    required LastPieceBoardFrame frame,
    required LastPieceUnit moving,
    required Square from,
    required Square to,
    required bool playerPiece,
    LastPieceUnit? captured,
  }) {
    final serial = ++_presentationStepSerial;
    final event = BoardMotionEvent(
      serial: serial,
      kind: BoardMotionKind.chessMove,
      motions: [
        PieceMotion(
          piece: _presentedPiece(moving, playerPiece: playerPiece),
          from: from,
          to: to,
        ),
      ],
      capturedPiece: captured == null
          ? null
          : _presentedPiece(captured, playerPiece: captured.id == player.id),
      capturedSquare: captured?.square,
    );
    _pendingPresentationSteps.add(
      LastPiecePresentationStep.motion(
        serial: serial,
        frame: frame,
        motion: event,
      ),
    );
  }

  void _recordTransformation({
    required LastPieceBoardFrame frame,
    required LastPieceUnit before,
    required LastPieceUnit after,
  }) {
    final serial = ++_presentationStepSerial;
    _pendingPresentationSteps.add(
      LastPiecePresentationStep.transformation(
        serial: serial,
        frame: frame,
        square: before.square,
        before: _presentedPiece(before, playerPiece: true),
        after: _presentedPiece(after, playerPiece: true),
      ),
    );
  }

  void _recordSpawn({
    required LastPieceBoardFrame frame,
    required LastPieceUnit spawned,
  }) {
    final serial = ++_presentationStepSerial;
    _pendingPresentationSteps.add(
      LastPiecePresentationStep.spawn(
        serial: serial,
        frame: frame,
        square: spawned.square,
        spawnedPiece: _presentedPiece(spawned, playerPiece: false),
      ),
    );
  }

  void _recordHunt(LastPieceBoardFrame frame, _LastPieceHuntMotion? hunt) {
    if (hunt == null) {
      return;
    }
    _recordMotion(
      frame: frame,
      moving: hunt.before,
      from: hunt.before.square,
      to: hunt.after.square,
      playerPiece: false,
    );
  }

  Future<void> _checkMilestones() async {
    final newStars = stars;
    if (newStars <= _highestAnnouncedStars) {
      return;
    }
    for (var star = _highestAnnouncedStars + 1; star <= newStars; star++) {
      final threshold = activeLevel.scoreMilestones[star - 1];
      milestoneBanner = star == 1
          ? '1 STAR · LEVEL PASSED · NEXT LEVEL UNLOCKED'
          : '$star STARS · $threshold POINTS';
      _log('Reached star $star at $threshold points. The run continues.');
      if (star == 1) {
        await profileRepository.persistPassUnlock(
          profile: profile,
          catalog: catalog,
          levelId: activeLevel.id,
        );
      }
    }
    _highestAnnouncedStars = newStars;
  }

  Future<void> _finish(LastPieceEndReason endReason) async {
    phase = LastPieceRunPhase.gameOver;
    final update = await profileRepository.recordRun(
      profile: profile,
      catalog: catalog,
      level: activeLevel,
      countryId: selectedCountryId,
      score: score,
      stars: stars,
      survivedPhases: survivedPhases,
      capturePoints: capturePoints,
      tilePoints: tilePoints,
    );
    result = LastPieceRunResult(
      levelId: activeLevel.id,
      countryId: selectedCountryId,
      score: score,
      stars: stars,
      survivedPhases: survivedPhases,
      captureCounts: Map<PieceType, int>.unmodifiable(captureCounts),
      capturePoints: capturePoints,
      tilePoints: tilePoints,
      transformations: transformations,
      seed: seed,
      endReason: endReason,
      personalBest: update.personalBest,
      familiarityGained: update.familiarityGained,
      totalFamiliarity: update.totalFamiliarity,
      firstPassBonusAwarded: update.firstPassBonusAwarded,
      newRewardIds: update.newRewardIds,
    );
  }

  List<List<ChessPiece?>> _buildBoard() {
    final board = List<List<ChessPiece?>>.generate(
      8,
      (_) => List<ChessPiece?>.filled(8, null),
    );
    board[player.square.row][player.square.col] = ChessPiece(
      id: player.id,
      type: player.type,
      color: PieceColor.white,
      countryId: selectedCountryId,
      loyalty: null,
      fairPrice: null,
    );
    for (final enemy in enemies) {
      board[enemy.square.row][enemy.square.col] = ChessPiece(
        id: enemy.id,
        type: enemy.type,
        color: PieceColor.black,
        countryId: 'iron',
        loyalty: null,
        fairPrice: null,
      );
    }
    return board;
  }

  void _log(String message) {
    _eventMessages.insert(0, LocalizedMessageRecord.fromEnglish(message));
    if (_eventMessages.length > 40) {
      _eventMessages.removeLast();
    }
  }

  @visibleForTesting
  void debugReplaceBoard({
    required LastPieceUnit playerUnit,
    required List<LastPieceUnit> enemyUnits,
    int phasesSinceSpawn = 0,
    int? forcedScore,
    int? forcedSurvivedPhases,
  }) {
    player = playerUnit;
    enemies
      ..clear()
      ..addAll(enemyUnits);
    _phasesSinceSpawn = phasesSinceSpawn;
    if (forcedScore != null) {
      score = forcedScore;
    }
    if (forcedSurvivedPhases != null) {
      survivedPhases = forcedSurvivedPhases;
    }
    presentationSteps = const <LastPiecePresentationStep>[];
    _pendingPresentationSteps.clear();
    notifyListeners();
  }

  @visibleForTesting
  bool debugAttemptSpawn() => _spawnEnemy();

  @visibleForTesting
  void debugAddRewardTile(LastPieceRewardTile tile) {
    rewardTiles.add(tile);
    notifyListeners();
  }

  @visibleForTesting
  void debugAttemptRewardTile() => _attemptRewardTile();

  @visibleForTesting
  Future<void> debugRunEnemyPhase() async {
    _beginPresentationSequence();
    await _runEnemyPhase();
    _commitPresentationSequence();
    notifyListeners();
  }
}

class _LastPieceHuntMotion {
  const _LastPieceHuntMotion({required this.before, required this.after});

  final LastPieceUnit before;
  final LastPieceUnit after;
}

class _HuntCandidate {
  const _HuntCandidate({
    required this.enemyIndex,
    required this.move,
    required this.threatens,
    required this.distance,
    required this.value,
    required this.tieBreak,
  });

  final int enemyIndex;
  final ChessMove move;
  final bool threatens;
  final int distance;
  final int value;
  final int tieBreak;
}
