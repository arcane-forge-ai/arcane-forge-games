import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

import '../l10n/runtime_game_locale.dart';
import 'last_piece_models.dart';

class LastPieceLevelCatalog {
  LastPieceLevelCatalog({
    required this.version,
    required List<LastPieceLevelDefinition> levels,
  }) : levels = List<LastPieceLevelDefinition>.unmodifiable(levels) {
    if (levels.isEmpty) {
      throw const FormatException('Last Piece catalog must contain levels.');
    }
    final ids = <String>{};
    for (final level in levels) {
      if (!ids.add(level.id)) {
        throw FormatException('Duplicate Last Piece level ID: ${level.id}');
      }
      if (level.prerequisiteId != null && !ids.contains(level.prerequisiteId)) {
        throw FormatException(
          'Level ${level.id} must follow its prerequisite '
          '${level.prerequisiteId}.',
        );
      }
      if (level.scoreMilestones.length != 3) {
        throw FormatException(
          'Level ${level.id} must define exactly three star milestones.',
        );
      }
    }
  }

  final int version;
  final List<LastPieceLevelDefinition> levels;

  LastPieceLevelDefinition byId(String id) =>
      levels.firstWhere((level) => level.id == id);

  LastPieceLevelDefinition? nextAfter(String id) {
    final index = levels.indexWhere((level) => level.id == id);
    if (index < 0 || index + 1 >= levels.length) {
      return null;
    }
    return levels[index + 1];
  }

  factory LastPieceLevelCatalog.fromJsonString(
    String source, {
    String? overlaySource,
  }) {
    final json = jsonDecode(source) as Map<String, Object?>;
    if (overlaySource != null) {
      _applyLocalizationOverlay(
        json,
        jsonDecode(overlaySource) as Map<String, Object?>,
      );
    }
    return LastPieceLevelCatalog(
      version: json['version']! as int,
      levels: (json['levels']! as List<Object?>)
          .cast<Map<String, Object?>>()
          .map(LastPieceLevelDefinition.fromJson)
          .toList(),
    );
  }

  static Future<LastPieceLevelCatalog> loadBundled({
    AssetBundle? bundle,
    Locale? locale,
  }) async {
    final assets = bundle ?? rootBundle;
    final source = await assets.loadString(
      'assets/data/last_piece_levels.v1.json',
    );
    final effectiveLocale = locale ?? RuntimeGameLocale.locale;
    final overlaySource = effectiveLocale.languageCode == 'zh'
        ? await assets.loadString(
            'assets/data/last_piece_levels.zh-Hans.v1.json',
          )
        : null;
    return LastPieceLevelCatalog.fromJsonString(
      source,
      overlaySource: overlaySource,
    );
  }

  static void _applyLocalizationOverlay(
    Map<String, Object?> source,
    Map<String, Object?> overlay,
  ) {
    final levels = (source['levels']! as List<Object?>)
        .cast<Map<String, Object?>>();
    final localized = overlay['levels'];
    if (localized is! Map<String, Object?>) {
      throw const FormatException(
        'Last Piece localization overlay is missing levels.',
      );
    }
    final expected = levels.map((level) => level['id']! as String).toSet();
    final found = localized.keys.toSet();
    if (!setEquals(expected, found)) {
      throw FormatException(
        'Last Piece localization IDs differ. Expected $expected, found $found.',
      );
    }
    for (final level in levels) {
      final copy = localized[level['id']]! as Map<String, Object?>;
      level['title'] = copy['title']! as String;
    }
  }

  static final LastPieceLevelCatalog defaults =
      LastPieceLevelCatalog.fromJsonString(_defaultSource);

  static const _defaultSource = '''
{
  "version": 1,
  "levels": [
    {
      "id": "001",
      "title": "The First Encirclement",
      "prerequisiteId": null,
      "startingState": {"piece": "queen", "square": "d4"},
      "initialEnemies": 1,
      "spawnInterval": 3,
      "enemyWeights": {"pawn": 55, "knight": 25, "bishop": 20},
      "scoreMilestones": [300, 700, 1200],
      "rewardTileInterval": 4,
      "maxRewardTiles": 2,
      "firstPassBonus": 20,
      "presentationTag": "jade-court"
    },
    {
      "id": "002",
      "title": "Fork The Tide",
      "prerequisiteId": "001",
      "startingState": {"piece": "knight", "square": "d4"},
      "initialEnemies": 2,
      "spawnInterval": 2,
      "enemyWeights": {"pawn": 45, "knight": 20, "bishop": 20, "rook": 15},
      "scoreMilestones": [300, 700, 1200],
      "rewardTileInterval": 4,
      "maxRewardTiles": 2,
      "firstPassBonus": 30,
      "presentationTag": "moonlit-court"
    },
    {
      "id": "003",
      "title": "The Last King",
      "prerequisiteId": "002",
      "startingState": {"piece": "king", "square": "d4"},
      "initialEnemies": 2,
      "spawnInterval": 2,
      "enemyWeights": {"pawn": 35, "knight": 20, "bishop": 20, "rook": 15, "queen": 10},
      "scoreMilestones": [300, 700, 1200],
      "rewardTileInterval": 4,
      "maxRewardTiles": 2,
      "firstPassBonus": 50,
      "presentationTag": "last-king"
    }
  ]
}
''';
}
