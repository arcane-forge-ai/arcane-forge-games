import 'package:flutter/foundation.dart';

import '../domain/board_presentation.dart';
import '../domain/chess_models.dart';

enum LastPieceRunPhase { idle, playing, promotion, gameOver }

enum LastPieceEndReason { captured, retired }

enum LastPieceEnemyAction { capture, spawn, hunt }

enum LastPieceRewardKind { score, transformation }

@immutable
class LastPieceLevelDefinition {
  const LastPieceLevelDefinition({
    required this.id,
    required this.title,
    required this.prerequisiteId,
    required this.startingPiece,
    required this.startingSquare,
    required this.initialEnemies,
    required this.spawnInterval,
    required this.enemyWeights,
    required this.scoreMilestones,
    required this.rewardTileInterval,
    required this.maxRewardTiles,
    required this.firstPassBonus,
    required this.presentationTag,
  });

  final String id;
  final String title;
  final String? prerequisiteId;
  final PieceType startingPiece;
  final Square startingSquare;
  final int initialEnemies;
  final int spawnInterval;
  final Map<PieceType, int> enemyWeights;
  final List<int> scoreMilestones;
  final int rewardTileInterval;
  final int maxRewardTiles;
  final int firstPassBonus;
  final String presentationTag;

  factory LastPieceLevelDefinition.fromJson(Map<String, Object?> json) {
    final starting = json['startingState']! as Map<String, Object?>;
    final weights = json['enemyWeights']! as Map<String, Object?>;
    return LastPieceLevelDefinition(
      id: json['id']! as String,
      title: json['title']! as String,
      prerequisiteId: json['prerequisiteId'] as String?,
      startingPiece: PieceType.values.byName(starting['piece']! as String),
      startingSquare: squareFromName(starting['square']! as String),
      initialEnemies: json['initialEnemies']! as int,
      spawnInterval: json['spawnInterval']! as int,
      enemyWeights: Map<PieceType, int>.unmodifiable({
        for (final entry in weights.entries)
          PieceType.values.byName(entry.key): entry.value! as int,
      }),
      scoreMilestones: List<int>.unmodifiable(
        (json['scoreMilestones']! as List<Object?>).cast<int>(),
      ),
      rewardTileInterval: json['rewardTileInterval']! as int,
      maxRewardTiles: json['maxRewardTiles']! as int,
      firstPassBonus: json['firstPassBonus']! as int,
      presentationTag: json['presentationTag']! as String,
    );
  }
}

@immutable
class LastPieceUnit {
  const LastPieceUnit({
    required this.id,
    required this.type,
    required this.square,
  });

  final String id;
  final PieceType type;
  final Square square;

  LastPieceUnit copyWith({PieceType? type, Square? square}) {
    return LastPieceUnit(
      id: id,
      type: type ?? this.type,
      square: square ?? this.square,
    );
  }
}

@immutable
class LastPieceRewardTile {
  const LastPieceRewardTile.score({
    required this.id,
    required this.square,
    required this.scoreValue,
  }) : kind = LastPieceRewardKind.score,
       targetRole = null;

  const LastPieceRewardTile.transformation({
    required this.id,
    required this.square,
    required this.targetRole,
  }) : kind = LastPieceRewardKind.transformation,
       scoreValue = null;

  final String id;
  final Square square;
  final LastPieceRewardKind kind;
  final int? scoreValue;
  final PieceType? targetRole;
}

@immutable
class LastPieceRunResult {
  const LastPieceRunResult({
    required this.levelId,
    required this.countryId,
    required this.score,
    required this.stars,
    required this.survivedPhases,
    required this.captureCounts,
    required this.capturePoints,
    required this.tilePoints,
    required this.transformations,
    required this.seed,
    required this.endReason,
    required this.personalBest,
    required this.familiarityGained,
    required this.totalFamiliarity,
    required this.firstPassBonusAwarded,
    required this.newRewardIds,
  });

  final String levelId;
  final String countryId;
  final int score;
  final int stars;
  final int survivedPhases;
  final Map<PieceType, int> captureCounts;
  final int capturePoints;
  final int tilePoints;
  final int transformations;
  final int seed;
  final LastPieceEndReason endReason;
  final int personalBest;
  final int familiarityGained;
  final int totalFamiliarity;
  final int firstPassBonusAwarded;
  final Set<String> newRewardIds;
}

enum LastPiecePresentationKind { motion, transformation, spawn }

@immutable
class LastPieceBoardFrame {
  const LastPieceBoardFrame({
    required this.player,
    required this.enemies,
    required this.rewardTiles,
  });

  final LastPieceUnit player;
  final List<LastPieceUnit> enemies;
  final List<LastPieceRewardTile> rewardTiles;
}

@immutable
class LastPiecePresentationStep {
  const LastPiecePresentationStep.motion({
    required this.serial,
    required this.frame,
    required this.motion,
  }) : kind = LastPiecePresentationKind.motion,
       before = null,
       after = null,
       square = null,
       spawnedPiece = null;

  const LastPiecePresentationStep.transformation({
    required this.serial,
    required this.frame,
    required this.square,
    required this.before,
    required this.after,
  }) : kind = LastPiecePresentationKind.transformation,
       motion = null,
       spawnedPiece = null;

  const LastPiecePresentationStep.spawn({
    required this.serial,
    required this.frame,
    required this.square,
    required this.spawnedPiece,
  }) : kind = LastPiecePresentationKind.spawn,
       motion = null,
       before = null,
       after = null;

  final int serial;
  final LastPiecePresentationKind kind;
  final LastPieceBoardFrame frame;
  final BoardMotionEvent? motion;
  final PresentedPiece? before;
  final PresentedPiece? after;
  final Square? square;
  final PresentedPiece? spawnedPiece;
}

Square squareFromName(String name) {
  if (name.length != 2) {
    throw FormatException('Invalid square: $name');
  }
  final col = name.codeUnitAt(0) - 'a'.codeUnitAt(0);
  final rank = int.tryParse(name[1]);
  if (col < 0 || col > 7 || rank == null || rank < 1 || rank > 8) {
    throw FormatException('Invalid square: $name');
  }
  return Square(8 - rank, col);
}

String lastPieceSquareName(Square square) {
  return '${String.fromCharCode('a'.codeUnitAt(0) + square.col)}${8 - square.row}';
}

int lastPieceCaptureValue(PieceType type) => switch (type) {
  PieceType.pawn => 10,
  PieceType.knight || PieceType.bishop => 30,
  PieceType.rook => 50,
  PieceType.queen => 90,
  PieceType.king => 0,
};
