import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'last_piece_catalog.dart';
import 'last_piece_models.dart';

abstract interface class LastPieceProfileStore {
  Future<String?> read();

  Future<void> write(String value);
}

class SharedPreferencesLastPieceProfileStore implements LastPieceProfileStore {
  SharedPreferencesLastPieceProfileStore({SharedPreferencesAsync? preferences})
    : _preferences = preferences;

  static const storageKey = 'last_piece_standing.profile.v1';

  SharedPreferencesAsync? _preferences;
  String? _testFallback;

  @override
  Future<String?> read() async {
    try {
      _preferences ??= SharedPreferencesAsync();
      return await _preferences!.getString(storageKey);
    } on StateError {
      return _testFallback;
    }
  }

  @override
  Future<void> write(String value) async {
    try {
      _preferences ??= SharedPreferencesAsync();
      await _preferences!.setString(storageKey, value);
    } on StateError {
      _testFallback = value;
    }
  }
}

class LastPieceLevelRecord {
  const LastPieceLevelRecord({
    required this.bestScore,
    required this.bestStars,
  });

  final int bestScore;
  final int bestStars;

  Map<String, Object?> toJson() => {
    'bestScore': bestScore,
    'bestStars': bestStars,
  };

  factory LastPieceLevelRecord.fromJson(Map<String, Object?> json) {
    return LastPieceLevelRecord(
      bestScore: (json['bestScore'] as num?)?.toInt() ?? 0,
      bestStars: (json['bestStars'] as num?)?.toInt() ?? 0,
    );
  }
}

class LastPieceProfile {
  LastPieceProfile({
    required this.schemaVersion,
    required this.unlockedLevelIds,
    required this.levelRecords,
    required this.countryFamiliarity,
    required this.firstPassedLevelIds,
    required this.rewardUnlockIds,
  });

  static const currentSchemaVersion = 2;

  int schemaVersion;
  final Set<String> unlockedLevelIds;
  final Map<String, LastPieceLevelRecord> levelRecords;
  final Map<String, int> countryFamiliarity;
  final Set<String> firstPassedLevelIds;
  final Set<String> rewardUnlockIds;

  factory LastPieceProfile.fresh() {
    return LastPieceProfile(
      schemaVersion: currentSchemaVersion,
      unlockedLevelIds: {'001'},
      levelRecords: {},
      countryFamiliarity: {},
      firstPassedLevelIds: {},
      rewardUnlockIds: {},
    );
  }

  factory LastPieceProfile.fromJson(Map<String, Object?> json) {
    final records = json['levelRecords'] as Map<String, Object?>? ?? {};
    final familiarity =
        json['countryFamiliarity'] as Map<String, Object?>? ?? {};
    final profile = LastPieceProfile(
      schemaVersion: (json['schemaVersion'] as num?)?.toInt() ?? 0,
      unlockedLevelIds: (json['unlockedLevelIds'] as List<Object?>? ?? const [])
          .whereType<String>()
          .toSet(),
      levelRecords: {
        for (final entry in records.entries)
          if (entry.value is Map<String, Object?>)
            entry.key: LastPieceLevelRecord.fromJson(
              entry.value! as Map<String, Object?>,
            ),
      },
      countryFamiliarity: {
        for (final entry in familiarity.entries)
          if (entry.value is num) entry.key: (entry.value! as num).toInt(),
      },
      firstPassedLevelIds:
          (json['firstPassedLevelIds'] as List<Object?>? ?? const [])
              .whereType<String>()
              .toSet(),
      rewardUnlockIds: (json['rewardUnlockIds'] as List<Object?>? ?? const [])
          .whereType<String>()
          .toSet(),
    );
    profile._migrate();
    return profile;
  }

  void _migrate() {
    unlockedLevelIds.add('001');
    for (final entry in countryFamiliarity.entries) {
      _grantFamiliarityRewards(
        rewardUnlockIds: rewardUnlockIds,
        countryId: entry.key,
        familiarity: entry.value,
      );
    }
    schemaVersion = currentSchemaVersion;
  }

  Map<String, Object?> toJson() => {
    'schemaVersion': currentSchemaVersion,
    'unlockedLevelIds': unlockedLevelIds.toList()..sort(),
    'levelRecords': {
      for (final entry in levelRecords.entries) entry.key: entry.value.toJson(),
    },
    'countryFamiliarity': countryFamiliarity,
    'firstPassedLevelIds': firstPassedLevelIds.toList()..sort(),
    'rewardUnlockIds': rewardUnlockIds.toList()..sort(),
  };
}

class LastPieceProfileUpdate {
  const LastPieceProfileUpdate({
    required this.personalBest,
    required this.familiarityGained,
    required this.totalFamiliarity,
    required this.firstPassBonusAwarded,
    required this.newRewardIds,
  });

  final int personalBest;
  final int familiarityGained;
  final int totalFamiliarity;
  final int firstPassBonusAwarded;
  final Set<String> newRewardIds;
}

class LastPieceProfileRepository {
  LastPieceProfileRepository({required LastPieceProfileStore store})
    : _store = store;

  final LastPieceProfileStore _store;

  Future<LastPieceProfile> load() async {
    final source = await _store.read();
    if (source == null || source.isEmpty) {
      return LastPieceProfile.fresh();
    }
    try {
      final json = jsonDecode(source);
      if (json is! Map<String, Object?>) {
        return LastPieceProfile.fresh();
      }
      final sourceVersion = (json['schemaVersion'] as num?)?.toInt() ?? 0;
      final sourceRewards =
          (json['rewardUnlockIds'] as List<Object?>? ?? const [])
              .whereType<String>()
              .toSet();
      final profile = LastPieceProfile.fromJson(json);
      if (sourceVersion != LastPieceProfile.currentSchemaVersion ||
          !sourceRewards.containsAll(profile.rewardUnlockIds)) {
        await save(profile);
      }
      return profile;
    } on FormatException {
      return LastPieceProfile.fresh();
    } on TypeError {
      return LastPieceProfile.fresh();
    }
  }

  Future<void> save(LastPieceProfile profile) {
    return _store.write(jsonEncode(profile.toJson()));
  }

  Future<void> persistPassUnlock({
    required LastPieceProfile profile,
    required LastPieceLevelCatalog catalog,
    required String levelId,
  }) async {
    final next = catalog.nextAfter(levelId);
    if (next != null) {
      profile.unlockedLevelIds.add(next.id);
    }
    await save(profile);
  }

  Future<LastPieceProfileUpdate> recordRun({
    required LastPieceProfile profile,
    required LastPieceLevelCatalog catalog,
    required LastPieceLevelDefinition level,
    required String countryId,
    required int score,
    required int stars,
    required int survivedPhases,
    required int capturePoints,
    required int tilePoints,
  }) async {
    final previous = profile.levelRecords[level.id];
    final personalBest = score > (previous?.bestScore ?? 0)
        ? score
        : previous?.bestScore ?? score;
    profile.levelRecords[level.id] = LastPieceLevelRecord(
      bestScore: personalBest,
      bestStars: stars > (previous?.bestStars ?? 0)
          ? stars
          : previous?.bestStars ?? stars,
    );

    final passed = score >= level.scoreMilestones.first;
    final firstPass = passed && profile.firstPassedLevelIds.add(level.id);
    if (passed) {
      final next = catalog.nextAfter(level.id);
      if (next != null) {
        profile.unlockedLevelIds.add(next.id);
      }
    }

    final performance = survivedPhases + (capturePoints + tilePoints) ~/ 20;
    final firstPassBonus = firstPass ? level.firstPassBonus : 0;
    final familiarityGained = passed
        ? performance + firstPassBonus
        : performance ~/ 2;
    final totalFamiliarity =
        (profile.countryFamiliarity[countryId] ?? 0) + familiarityGained;
    profile.countryFamiliarity[countryId] = totalFamiliarity;

    final newRewards = _grantFamiliarityRewards(
      rewardUnlockIds: profile.rewardUnlockIds,
      countryId: countryId,
      familiarity: totalFamiliarity,
    );

    await save(profile);
    return LastPieceProfileUpdate(
      personalBest: personalBest,
      familiarityGained: familiarityGained,
      totalFamiliarity: totalFamiliarity,
      firstPassBonusAwarded: firstPassBonus,
      newRewardIds: Set<String>.unmodifiable(newRewards),
    );
  }
}

Set<String> _grantFamiliarityRewards({
  required Set<String> rewardUnlockIds,
  required String countryId,
  required int familiarity,
}) {
  final granted = <String>{};
  void grant(String rewardId) {
    final id = '$countryId:$rewardId';
    if (rewardUnlockIds.add(id)) {
      granted.add(id);
    }
  }

  if (familiarity >= 25) {
    grant('chronicle1');
    grant('music_court');
  }
  if (familiarity >= 100) {
    grant('gallery1');
    grant('music_battle');
  }
  return granted;
}
