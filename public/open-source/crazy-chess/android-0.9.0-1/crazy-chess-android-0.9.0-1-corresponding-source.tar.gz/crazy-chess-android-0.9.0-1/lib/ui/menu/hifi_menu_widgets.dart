import 'package:flutter/material.dart';

import '../../l10n/ui_copy.dart';
import '../shared/nine_slice_image.dart';

const hifiInk = Color(0xFFf3dfb8);
const hifiMuted = Color(0xFFc7b590);
const hifiGold = Color(0xFFd7ad5a);
const hifiGoldDark = Color(0xFF6a4b1f);
const hifiEmerald = Color(0xFF103d36);
const hifiPanel = Color(0xEE111820);
const hifiPanelSoft = Color(0xCC17212a);
const hifiBurgundy = Color(0xFF5a1718);
const productionAssetRoot = 'assets/runtime/scenes/legacy';
const runtimeAssetRoot = 'assets/runtime';

class HifiScaffold extends StatelessWidget {
  const HifiScaffold({
    required this.child,
    this.backdropAsset,
    this.heroAsset,
    this.heroAlignment = Alignment.centerRight,
    this.heroWidth = 760,
    this.backdropOpacity = 0.34,
    this.showDefaultScrims = true,
    super.key,
  });

  final Widget child;
  final String? backdropAsset;
  final String? heroAsset;
  final Alignment heroAlignment;
  final double heroWidth;
  final double backdropOpacity;
  final bool showDefaultScrims;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF0b1014), Color(0xFF18201f), Color(0xFF090b0d)],
            ),
          ),
        ),
        if (backdropAsset != null)
          Positioned.fill(
            child: Opacity(
              opacity: backdropOpacity,
              child: Image.asset(backdropAsset!, fit: BoxFit.cover),
            ),
          ),
        if (heroAsset != null)
          Align(
            alignment: heroAlignment,
            child: SizedBox(
              width: heroWidth,
              height: double.infinity,
              child: Image.asset(heroAsset!, fit: BoxFit.cover),
            ),
          ),
        if (showDefaultScrims) ...[
          const Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [
                    Color(0xF2090B0D),
                    Color(0xB80B1014),
                    Color(0x7A0B1014),
                    Color(0xE6090B0D),
                  ],
                ),
              ),
            ),
          ),
          const Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0x99000000),
                    Color(0x00000000),
                    Color(0xCC000000),
                  ],
                ),
              ),
            ),
          ),
        ],
        child,
      ],
    );
  }
}

class HifiTopBar extends StatelessWidget {
  const HifiTopBar({
    required this.screenCode,
    required this.title,
    this.onBack,
    this.trailing,
    super.key,
  });

  final String screenCode;
  final String title;
  final VoidCallback? onBack;
  final List<Widget>? trailing;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 84,
      child: Row(
        children: [
          if (onBack != null) ...[
            HifiIconSquare(
              icon: Icons.arrow_back,
              label: 'Back',
              onPressed: onBack,
              tooltip: 'Back',
            ),
            const SizedBox(width: 18),
          ],
          const Icon(Icons.workspace_premium, color: hifiGold, size: 42),
          const SizedBox(width: 12),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Crazy Chess',
                style: TextStyle(
                  color: hifiInk,
                  fontFamily: 'Georgia',
                  fontSize: 38,
                  fontWeight: FontWeight.w800,
                  height: 1,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '$screenCode  ${localizedUiCopy(context, title)}',
                style: const TextStyle(
                  color: hifiGold,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const Spacer(),
          ...?trailing,
        ],
      ),
    );
  }
}

class HifiAssetSurface extends StatelessWidget {
  const HifiAssetSurface({
    required this.asset,
    required this.child,
    this.padding = EdgeInsets.zero,
    this.centerSlice,
    this.fit = BoxFit.fill,
    this.imageScale = 1,
    this.backgroundImageOutset = EdgeInsets.zero,
    super.key,
  });

  final String asset;
  final Widget child;
  final EdgeInsets padding;
  final Rect? centerSlice;
  final BoxFit fit;
  final double imageScale;
  final EdgeInsets backgroundImageOutset;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.passthrough,
      clipBehavior: Clip.hardEdge,
      children: [
        Positioned(
          left: -backgroundImageOutset.left,
          top: -backgroundImageOutset.top,
          right: -backgroundImageOutset.right,
          bottom: -backgroundImageOutset.bottom,
          child: centerSlice == null
              ? Image.asset(
                  asset,
                  scale: imageScale,
                  fit: fit,
                  filterQuality: FilterQuality.high,
                  excludeFromSemantics: true,
                )
              : ExcludeSemantics(
                  child: NineSliceAssetImage(
                    asset: asset,
                    centerSlice: centerSlice!,
                    scale: imageScale,
                    filterQuality: FilterQuality.high,
                  ),
                ),
        ),
        Padding(padding: padding, child: child),
      ],
    );
  }
}

class HifiPanel extends StatelessWidget {
  const HifiPanel({
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.color = hifiPanel,
    this.borderColor = hifiGoldDark,
    this.backgroundAsset,
    this.backgroundCenterSlice,
    this.backgroundImageScale = 1,
    super.key,
  });

  final Widget child;
  final EdgeInsets padding;
  final Color color;
  final Color borderColor;
  final String? backgroundAsset;
  final Rect? backgroundCenterSlice;
  final double backgroundImageScale;

  @override
  Widget build(BuildContext context) {
    final asset =
        backgroundAsset ?? '$productionAssetRoot/ui_panel_9slice.webp';
    return HifiAssetSurface(
      asset: asset,
      centerSlice: backgroundCenterSlice,
      imageScale: backgroundImageScale,
      padding: padding,
      child: child,
    );
  }
}

class HifiSectionTitle extends StatelessWidget {
  const HifiSectionTitle(this.text, {this.subtitle, super.key});

  final String text;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          localizedUiCopy(context, text),
          style: const TextStyle(
            color: hifiInk,
            fontFamily: 'Georgia',
            fontSize: 42,
            fontWeight: FontWeight.w800,
            height: 1,
          ),
        ),
        if (subtitle != null) ...[
          const SizedBox(height: 8),
          Text(
            localizedUiCopy(context, subtitle!),
            style: const TextStyle(
              color: hifiMuted,
              fontSize: 15,
              height: 1.35,
            ),
          ),
        ],
      ],
    );
  }
}

class HifiPrimaryButton extends StatelessWidget {
  const HifiPrimaryButton({
    required this.label,
    required this.onPressed,
    this.icon,
    this.large = false,
    this.variant = HifiButtonVariant.emerald,
    this.backgroundAsset,
    this.backgroundCenterSlice,
    this.backgroundImageScale = 1,
    this.disabledOpacity = 0.48,
    super.key,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool large;
  final HifiButtonVariant variant;
  final String? backgroundAsset;
  final Rect? backgroundCenterSlice;
  final double backgroundImageScale;
  final double disabledOpacity;

  @override
  Widget build(BuildContext context) {
    final disabled = onPressed == null;
    final asset =
        backgroundAsset ?? '$productionAssetRoot/ui_button_9slice.webp';
    final centerSlice = backgroundCenterSlice;
    return Opacity(
      opacity: disabled ? disabledOpacity : 1,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: onPressed,
          child: HifiAssetSurface(
            asset: asset,
            imageScale: backgroundImageScale,
            centerSlice: centerSlice,
            padding: EdgeInsets.symmetric(
              horizontal: large ? 34 : 20,
              vertical: large ? 20 : 13,
            ),
            child: _HifiButtonContent(
              label: label,
              icon: icon,
              large: large,
              variant: variant,
            ),
          ),
        ),
      ),
    );
  }
}

class _HifiButtonContent extends StatelessWidget {
  const _HifiButtonContent({
    required this.label,
    required this.icon,
    required this.large,
    required this.variant,
  });

  final String label;
  final IconData? icon;
  final bool large;
  final HifiButtonVariant variant;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final bounded = constraints.maxWidth.isFinite;
        final text = Text(
          localizedUiCopy(context, label),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: variant == HifiButtonVariant.gold
                ? const Color(0xFF1e1207)
                : hifiInk,
            fontFamily: 'Georgia',
            fontSize: large ? 28 : 17,
            fontWeight: FontWeight.w800,
            height: 1,
          ),
        );
        return Row(
          mainAxisSize: bounded ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(
                icon,
                color: variant == HifiButtonVariant.gold
                    ? const Color(0xFF1e1207)
                    : hifiInk,
                size: large ? 26 : 19,
              ),
              SizedBox(width: large ? 10 : 7),
            ],
            if (bounded)
              Flexible(
                child: FittedBox(fit: BoxFit.scaleDown, child: text),
              )
            else
              text,
          ],
        );
      },
    );
  }
}

enum HifiButtonVariant { emerald, gold, burgundy, dark }

class HifiIconSquare extends StatelessWidget {
  const HifiIconSquare({
    required this.icon,
    required this.label,
    this.onPressed,
    this.tooltip,
    this.frameAsset,
    this.frameCenterSlice,
    super.key,
  });

  final IconData icon;
  final String label;
  final VoidCallback? onPressed;
  final String? tooltip;
  final String? frameAsset;
  final Rect? frameCenterSlice;

  @override
  Widget build(BuildContext context) {
    final button = SizedBox(
      width: 72,
      height: 64,
      child: HifiPrimaryButton(
        label: '',
        icon: icon,
        onPressed: onPressed,
        variant: HifiButtonVariant.dark,
        backgroundAsset:
            frameAsset ?? '$productionAssetRoot/ui_icon_square.webp',
        backgroundCenterSlice: frameCenterSlice,
        disabledOpacity: frameAsset == null ? 0.48 : 0.82,
      ),
    );
    return Tooltip(
      message: localizedUiCopy(context, tooltip ?? label),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          button,
          const SizedBox(height: 4),
          Text(
            localizedUiCopy(context, label),
            style: const TextStyle(
              color: hifiGold,
              fontSize: 11,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class HifiPlaque extends StatelessWidget {
  const HifiPlaque({
    required this.title,
    required this.subtitle,
    required this.icon,
    this.onPressed,
    this.selected = false,
    this.locked = false,
    this.height = 132,
    this.backgroundAsset,
    this.backgroundCenterSlice,
    this.backgroundImageScale = 1,
    this.foregroundColor = hifiInk,
    this.secondaryColor = hifiMuted,
    this.iconColor = hifiGold,
    this.contentPadding = const EdgeInsets.symmetric(
      horizontal: 24,
      vertical: 18,
    ),
    super.key,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback? onPressed;
  final bool selected;
  final bool locked;
  final double height;
  final String? backgroundAsset;
  final Rect? backgroundCenterSlice;
  final double backgroundImageScale;
  final Color foregroundColor;
  final Color secondaryColor;
  final Color iconColor;
  final EdgeInsets contentPadding;

  @override
  Widget build(BuildContext context) {
    final content = Row(
      children: [
        Icon(icon, color: iconColor, size: 54),
        const SizedBox(width: 18),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      localizedUiCopy(context, title),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: foregroundColor,
                        fontFamily: 'Georgia',
                        fontSize: 32,
                        fontWeight: FontWeight.w800,
                        height: 1,
                      ),
                    ),
                  ),
                  if (locked) ...[
                    const SizedBox(width: 10),
                    const LockedBadge(),
                  ],
                ],
              ),
              const SizedBox(height: 10),
              Text(
                localizedUiCopy(context, subtitle),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: secondaryColor,
                  fontSize: 15,
                  height: 1.25,
                ),
              ),
            ],
          ),
        ),
      ],
    );
    final paddedContent = Padding(padding: contentPadding, child: content);
    return Opacity(
      opacity: locked ? 0.58 : 1,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: locked ? null : onPressed,
          child: Ink(
            height: height,
            decoration: backgroundAsset == null
                ? BoxDecoration(
                    color: selected
                        ? const Color(0xDD263329)
                        : const Color(0xE61b232a),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: selected ? hifiGold : hifiGoldDark,
                      width: selected ? 2 : 1.4,
                    ),
                    gradient: LinearGradient(
                      colors: selected
                          ? const [Color(0xFF24584f), Color(0xFF132622)]
                          : const [Color(0xFF202932), Color(0xFF11171c)],
                    ),
                  )
                : null,
            child: backgroundAsset == null
                ? paddedContent
                : HifiAssetSurface(
                    asset: backgroundAsset!,
                    centerSlice: backgroundCenterSlice,
                    imageScale: backgroundImageScale,
                    padding: contentPadding,
                    child: content,
                  ),
          ),
        ),
      ),
    );
  }
}

class LockedBadge extends StatelessWidget {
  const LockedBadge({super.key});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xFF3d2320),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: hifiGoldDark),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lock, size: 14, color: hifiGold),
            const SizedBox(width: 4),
            Text(
              localizedUiCopy(context, 'Future'),
              style: const TextStyle(
                color: hifiGold,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HifiBottomNav extends StatelessWidget {
  const HifiBottomNav({required this.active, required this.items, super.key});

  final HifiNavigationDestination active;
  final List<HifiNavItem> items;

  @override
  Widget build(BuildContext context) {
    return HifiPanel(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      color: const Color(0xE60b1015),
      child: Row(
        children: [
          for (final item in items)
            Expanded(
              child: Opacity(
                opacity: item.enabled ? 1 : 0.5,
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(6),
                    onTap: item.enabled ? item.onPressed : null,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            item.icon,
                            color: item.id == active ? hifiGold : hifiMuted,
                            size: 28,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            item.label,
                            style: TextStyle(
                              color: item.id == active ? hifiGold : hifiMuted,
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class HifiNavItem {
  const HifiNavItem(
    this.id,
    this.label,
    this.icon, {
    this.enabled = false,
    this.onPressed,
  });

  final HifiNavigationDestination id;
  final String label;
  final IconData icon;
  final bool enabled;
  final VoidCallback? onPressed;
}

enum HifiNavigationDestination {
  lobby,
  country,
  roster,
  loadout,
  records,
  rules,
  settings,
}

class HifiStatLine extends StatelessWidget {
  const HifiStatLine({
    required this.icon,
    required this.label,
    required this.value,
    this.iconColor = hifiGold,
    this.labelColor = hifiInk,
    this.valueColor = hifiMuted,
    this.iconSize = 24,
    this.labelFontSize = 16,
    this.valueFontSize,
    this.verticalPadding = 8,
    this.iconGap = 12,
    super.key,
  });

  final IconData icon;
  final String label;
  final String value;
  final Color iconColor;
  final Color labelColor;
  final Color valueColor;
  final double iconSize;
  final double labelFontSize;
  final double? valueFontSize;
  final double verticalPadding;
  final double iconGap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: verticalPadding),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: iconColor, size: iconSize),
          SizedBox(width: iconGap),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  localizedUiCopy(context, label),
                  style: TextStyle(
                    color: labelColor,
                    fontSize: labelFontSize,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  localizedUiCopy(context, value),
                  style: TextStyle(
                    color: valueColor,
                    fontSize: valueFontSize,
                    height: 1.25,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
