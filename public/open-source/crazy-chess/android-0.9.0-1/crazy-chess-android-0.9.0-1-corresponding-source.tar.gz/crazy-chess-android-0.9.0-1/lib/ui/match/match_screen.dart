import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../battlefield/battlefield_models.dart';
import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../game/game_controller.dart';
import '../../living_campaign/living_campaign_models.dart';
import '../../l10n/ui_copy.dart';
import '../board/board_stage.dart';
import '../board/board_presentation_coordinator.dart';
import '../effects/production_board_effects.dart';
import '../menu/hifi_menu_widgets.dart';
import '../menu/reference_layout.dart';
import '../overlays/game_over_overlay.dart';
import '../panels/action_panel.dart';
import '../panels/info_panel.dart';
import '../panels/offer_composer.dart';
import '../shared/formatters.dart';
import '../shared/piece_art.dart';
import '../shared/reference_first_match_art.dart';
import '../shared/special_tile_art.dart';
import 'match_header.dart';
import 'merchant_track.dart';

class MatchReferenceGeometry {
  const MatchReferenceGeometry._();

  static const header = Rect.fromLTWH(14, 12, 1644, 92);
  static const eventLog = Rect.fromLTWH(14, 116, 284, 806);
  static const board = Rect.fromLTWH(306, 112, 770, 770);
  static const merchant = Rect.fromLTWH(1082, 116, 104, 766);
  static const inspector = Rect.fromLTWH(1194, 116, 464, 806);
}

enum PurchasePlacementPolicy { redeploy, blackInPlace }

class MatchScreen extends StatelessWidget {
  const MatchScreen({
    required this.controller,
    this.presentationCoordinator,
    this.purchaseResultDelay = const Duration(milliseconds: 620),
    this.onLobby,
    this.onRematch,
    this.onTutorial,
    this.onSettings,
    this.aiThinking = false,
    this.aiInputLocked = false,
    this.aiFailureMessage,
    this.onRetryAi,
    this.storyDirectorStatus,
    this.showGameOverOverlay = true,
    this.purchasePlacementPolicy = PurchasePlacementPolicy.redeploy,
    this.piecePresentationResolver,
    super.key,
  });

  final GameController controller;
  final BoardPresentationCoordinator? presentationCoordinator;
  final Duration purchaseResultDelay;
  final VoidCallback? onLobby;
  final VoidCallback? onRematch;
  final VoidCallback? onTutorial;
  final VoidCallback? onSettings;
  final bool aiThinking;
  final bool aiInputLocked;
  final String? aiFailureMessage;
  final Future<void> Function()? onRetryAi;
  final Widget? storyDirectorStatus;
  final bool showGameOverOverlay;
  final PurchasePlacementPolicy purchasePlacementPolicy;
  final Future<LivingPiecePresentation?> Function(ChessPiece piece)?
  piecePresentationResolver;

  @override
  Widget build(BuildContext context) {
    final presentationBusy = presentationCoordinator?.isBusy ?? false;
    final merchantConsequencesReleased =
        presentationCoordinator?.merchantConsequencesReleased ?? true;
    final battlefieldEvent = controller.lastBattlefieldEvent;
    final battlefieldConsequencesReleased =
        battlefieldEvent == null ||
        (presentationCoordinator?.battlefieldConsequencesReleased(
              battlefieldEvent.serial,
            ) ??
            true);
    final pendingBlackInPlacePurchase =
        purchasePlacementPolicy == PurchasePlacementPolicy.blackInPlace &&
        controller.lastOfferResult?.success == true &&
        controller.phase == GamePhase.redeploy &&
        controller.redeployPiece?.color == PieceColor.black;
    return Stack(
      children: [
        Stack(
          fit: StackFit.expand,
          children: [
            _MatchEnvironment(controller: controller),
            ReferencePositioned(
              sourceBounds: MatchReferenceGeometry.header,
              child: _MatchTopChrome(
                controller: controller,
                onTutorial: onTutorial,
                onSettings: onSettings,
                storyDirectorStatus: storyDirectorStatus,
              ),
            ),
            ReferencePositioned(
              sourceBounds: MatchReferenceGeometry.eventLog,
              child: InfoPanel(controller: controller),
            ),
            ReferencePositioned(
              sourceBounds: MatchReferenceGeometry.board,
              child: AbsorbPointer(
                absorbing: aiInputLocked || presentationBusy,
                child: Center(
                  child: BoardStage(
                    controller: controller,
                    presentationCoordinator: presentationCoordinator,
                    maxSize: 742,
                    showGameOverOverlay: false,
                    showRedeployBanner: !pendingBlackInPlacePurchase,
                  ),
                ),
              ),
            ),
            ReferencePositioned(
              sourceBounds: MatchReferenceGeometry.merchant,
              child: controller.merchantEnabled
                  ? MerchantTrack(controller: controller)
                  : const SizedBox.shrink(),
            ),
            ReferencePositioned(
              sourceBounds: MatchReferenceGeometry.inspector,
              child: pendingBlackInPlacePurchase
                  ? const SizedBox.shrink()
                  : AbsorbPointer(
                      absorbing: aiInputLocked || presentationBusy,
                      child: ActionPanel(
                        controller: controller,
                        piecePresentationResolver: piecePresentationResolver,
                      ),
                    ),
            ),
          ],
        ),
        if (controller.merchantEnabled &&
            merchantConsequencesReleased &&
            controller.merchantPayoutPulseSerial > 0 &&
            controller.lastMerchantPayoutReceiver != null)
          ProductionMerchantPayoutCoinBurst(
            key: ValueKey(
              'merchant-payout-${controller.merchantPayoutPulseSerial}',
            ),
            toRight: controller.lastMerchantPayoutReceiver == PieceColor.white,
          ),
        if (!presentationBusy && controller.activeKingInCheck)
          ProductionRedAlertFlash(
            key: ValueKey(
              'red-alert-${controller.turnCount}-${controller.phase.name}',
            ),
          ),
        if (!presentationBusy &&
            controller.activeKingInCheck &&
            controller.phase == GamePhase.playing)
          const _CheckAlertBanner(),
        if (aiThinking) const _AiThinkingBanner(),
        if (battlefieldEvent != null && battlefieldConsequencesReleased)
          _BattlefieldEventToast(
            key: ValueKey('battlefield-event-${battlefieldEvent.serial}'),
            event: battlefieldEvent,
          ),
        if (controller.phase == GamePhase.offer) ...[
          const Positioned.fill(child: ColoredBox(color: Color(0x9906090b))),
          Positioned(
            left: 360,
            top: 116,
            width: 880,
            height: 668,
            child: OfferComposer(controller: controller),
          ),
        ],
        if (controller.lastOfferResult != null &&
            controller.phase != GamePhase.offer &&
            controller.phase != GamePhase.gameOver)
          _PurchaseResultOverlay(
            controller: controller,
            resolveDelay: purchaseResultDelay,
            placementPolicy: purchasePlacementPolicy,
          ),
        if (showGameOverOverlay &&
            !presentationBusy &&
            controller.phase == GamePhase.gameOver)
          GameOverOverlay(
            controller: controller,
            onLobby: onLobby,
            onRematch: onRematch,
          ),
        if (aiFailureMessage != null && controller.phase != GamePhase.gameOver)
          _AiFailureOverlay(
            message: aiFailureMessage!,
            onRetry: onRetryAi,
            onLobby: onLobby,
          ),
      ],
    );
  }
}

class _MatchEnvironment extends StatelessWidget {
  const _MatchEnvironment({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.topCenter,
              radius: 1.18,
              colors: [Color(0xFF24333A), Color(0xFF14191E), Color(0xFF090B0D)],
            ),
          ),
        ),
        Image.asset(
          controller.battlefield.backgroundAsset ?? matchEnvironmentAsset,
          key: ValueKey(
            's20-match-environment-${controller.battlefieldId.name}',
          ),
          fit: BoxFit.cover,
          filterQuality: FilterQuality.high,
          excludeFromSemantics: true,
          errorBuilder: (context, error, stackTrace) => const SizedBox.shrink(),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0x22000000), Color(0x00000000), Color(0x77000000)],
            ),
          ),
        ),
      ],
    );
  }
}

class _MatchTopChrome extends StatelessWidget {
  const _MatchTopChrome({
    required this.controller,
    required this.onTutorial,
    required this.onSettings,
    required this.storyDirectorStatus,
  });

  final GameController controller;
  final VoidCallback? onTutorial;
  final VoidCallback? onSettings;
  final Widget? storyDirectorStatus;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      key: const ValueKey('s20-match-hud'),
      decoration: BoxDecoration(
        color: const Color(0xEE0d1318),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: hifiGoldDark),
      ),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            SizedBox(
              width: 174,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    localizedDisplayCase(context, 'Live Match'),
                    style: const TextStyle(
                      color: hifiGold,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      height: 1,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    Localizations.localeOf(context).languageCode == 'zh'
                        ? '第 ${controller.turnCount} 回合'
                        : 'TURN ${controller.turnCount}',
                    style: const TextStyle(
                      color: hifiInk,
                      fontFamily: 'Cinzel',
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      height: 1,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    localizedDisplayCase(context, controller.battlefield.name),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: hifiMuted,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: .4,
                      height: 1,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(child: MatchHeader(controller: controller)),
            const SizedBox(width: 12),
            if (storyDirectorStatus != null) ...[
              storyDirectorStatus!,
              const SizedBox(width: 10),
            ],
            _MatchToolButton(
              icon: Icons.menu_book,
              label: 'Rules',
              onPressed: onTutorial,
            ),
            const SizedBox(width: 10),
            _MatchToolButton(
              icon: Icons.settings,
              label: 'Settings',
              onPressed: onSettings,
            ),
          ],
        ),
      ),
    );
  }
}

class _MatchToolButton extends StatelessWidget {
  const _MatchToolButton({
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  final IconData icon;
  final String label;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: localizedUiCopy(context, label),
      child: SizedBox(
        width: 70,
        height: 58,
        child: HifiPrimaryButton(
          label: '',
          icon: icon,
          onPressed: onPressed,
          variant: HifiButtonVariant.dark,
          backgroundAsset: matchButtonDarkAsset,
          backgroundImageScale: matchButtonImageScale,
        ),
      ),
    );
  }
}

class _CheckAlertBanner extends StatelessWidget {
  const _CheckAlertBanner();

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 104,
      left: 0,
      right: 0,
      child: Center(
        child: HifiAssetSurface(
          asset: '$productionAssetRoot/check_alert_banner.webp',
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.warning_amber,
                color: Color(0xFFffd08a),
                size: 28,
              ),
              const SizedBox(width: 10),
              Text(
                localizedUiCopy(context, 'Check Alert'),
                style: const TextStyle(
                  color: hifiInk,
                  fontFamily: 'Georgia',
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AiThinkingBanner extends StatelessWidget {
  const _AiThinkingBanner();

  @override
  Widget build(BuildContext context) {
    return Positioned(
      key: const ValueKey('stockfish-thinking'),
      top: 106,
      left: 0,
      right: 0,
      child: Center(
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: const Color(0xF013191E),
            border: Border.all(color: hifiGoldDark),
            borderRadius: BorderRadius.circular(6),
            boxShadow: const [BoxShadow(color: Colors.black87, blurRadius: 12)],
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    color: hifiGold,
                    strokeWidth: 2.2,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  localizedUiCopy(context, 'Stockfish is thinking…'),
                  style: const TextStyle(
                    color: hifiInk,
                    fontFamily: 'Cinzel',
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BattlefieldEventToast extends StatefulWidget {
  const _BattlefieldEventToast({required this.event, super.key});

  final BattlefieldEvent event;

  @override
  State<_BattlefieldEventToast> createState() => _BattlefieldEventToastState();
}

class _BattlefieldEventToastState extends State<_BattlefieldEventToast> {
  Timer? _timer;
  var _visible = true;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(milliseconds: 2600), () {
      if (mounted) {
        setState(() => _visible = false);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_visible) {
      return const SizedBox.shrink();
    }
    final dangerous =
        widget.event.type == BattlefieldEventType.trapTriggered ||
        widget.event.type == BattlefieldEventType.mysteryTrap;
    final accent = dangerous
        ? const Color(0xFFFF756B)
        : const Color(0xFFF2C96F);
    final tileType = specialTileTypeForEvent(widget.event.type);
    return Positioned(
      key: const ValueKey('battlefield-event-toast'),
      top: 166,
      left: 0,
      right: 0,
      child: IgnorePointer(
        child: Center(
          child: AnimatedOpacity(
            opacity: _visible ? 1 : 0,
            duration: const Duration(milliseconds: 180),
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xF212171B),
                border: Border.all(color: accent, width: 1.5),
                borderRadius: BorderRadius.circular(5),
                boxShadow: const [
                  BoxShadow(color: Colors.black87, blurRadius: 16),
                ],
              ),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 540),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 18,
                    vertical: 10,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (tileType == null)
                        Icon(
                          _battlefieldEventIcon(widget.event.type),
                          color: accent,
                          size: 24,
                        )
                      else
                        DecoratedBox(
                          decoration: BoxDecoration(
                            color: specialTileDeepColor(
                              tileType,
                            ).withValues(alpha: .75),
                            border: Border.all(
                              color: specialTileAccent(tileType),
                            ),
                            borderRadius: BorderRadius.circular(7),
                          ),
                          child: SpecialTileArt(
                            type: tileType,
                            size: 34,
                            scale: 1.28,
                          ),
                        ),
                      const SizedBox(width: 10),
                      Flexible(
                        child: Text(
                          widget.event.localizedMessage,
                          key: const ValueKey('battlefield-event-message'),
                          style: const TextStyle(
                            color: hifiInk,
                            fontFamily: 'Cinzel',
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            height: 1.25,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

IconData _battlefieldEventIcon(BattlefieldEventType type) {
  return switch (type) {
    BattlefieldEventType.tilesSpawned => Icons.auto_awesome,
    BattlefieldEventType.kingGuarded => Icons.shield_outlined,
    _ => Icons.auto_awesome,
  };
}

class _AiFailureOverlay extends StatelessWidget {
  const _AiFailureOverlay({
    required this.message,
    required this.onRetry,
    required this.onLobby,
  });

  final String message;
  final Future<void> Function()? onRetry;
  final VoidCallback? onLobby;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      key: const ValueKey('stockfish-failure'),
      child: ColoredBox(
        color: const Color(0xC9000000),
        child: Center(
          child: HifiPanel(
            padding: const EdgeInsets.fromLTRB(34, 30, 34, 28),
            color: const Color(0xF2141A1F),
            child: SizedBox(
              width: 470,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.warning_amber_rounded,
                    color: Color(0xFFFFC567),
                    size: 48,
                  ),
                  const SizedBox(height: 14),
                  Text(
                    localizedDisplayCase(context, 'Stockfish Paused'),
                    style: const TextStyle(
                      color: hifiInk,
                      fontFamily: 'Cinzel',
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    message,
                    textAlign: TextAlign.center,
                    maxLines: 5,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: hifiMuted, height: 1.35),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: HifiPrimaryButton(
                          key: const ValueKey('stockfish-return-lobby'),
                          label: 'Return to Lobby',
                          icon: Icons.home,
                          onPressed: onLobby,
                          variant: HifiButtonVariant.dark,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: HifiPrimaryButton(
                          key: const ValueKey('stockfish-retry'),
                          label: 'Retry',
                          icon: Icons.refresh,
                          onPressed: onRetry == null
                              ? null
                              : () => unawaited(onRetry!()),
                          variant: HifiButtonVariant.emerald,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _PurchaseResultOverlay extends StatefulWidget {
  const _PurchaseResultOverlay({
    required this.controller,
    required this.resolveDelay,
    required this.placementPolicy,
  });

  final GameController controller;
  final Duration resolveDelay;
  final PurchasePlacementPolicy placementPolicy;

  @override
  State<_PurchaseResultOverlay> createState() => _PurchaseResultOverlayState();
}

class _PurchaseResultOverlayState extends State<_PurchaseResultOverlay> {
  Timer? _resolveTimer;
  var _showResult = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (widget.controller.lastOfferResult!.resolutionKind !=
        OfferResolutionKind.rolled) {
      _showResult = true;
      return;
    }
    _resolveTimer ??= Timer(widget.resolveDelay, () {
      if (mounted) {
        setState(() => _showResult = true);
      }
    });
  }

  @override
  void dispose() {
    _resolveTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final result = widget.controller.lastOfferResult!;
    if (!_showResult && result.resolutionKind == OfferResolutionKind.rolled) {
      return _PurchaseRollOverlay(
        result: result,
        duration: widget.resolveDelay,
      );
    }
    return _PurchaseOutcomeOverlay(
      controller: widget.controller,
      result: result,
      placementPolicy: widget.placementPolicy,
    );
  }
}

class _PurchaseRollOverlay extends StatelessWidget {
  const _PurchaseRollOverlay({required this.result, required this.duration});

  final OfferResult result;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: const Color(0x99000000),
        child: Center(
          child: SizedBox(
            key: const ValueKey('s24-roll-modal'),
            width: 905,
            height: 640,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  matchPurchaseRollShellAsset,
                  key: const ValueKey('s24-reference-first-shell'),
                  fit: BoxFit.fill,
                  filterQuality: FilterQuality.high,
                  excludeFromSemantics: true,
                ),
                const ProductionOfferCoinTrail(),
                ProductionRollFlash(success: result.success),
                Positioned(
                  left: 64,
                  top: 188,
                  width: 205,
                  height: 190,
                  child: _OfferResultPortrait(result: result, circular: true),
                ),
                Positioned(
                  top: 176,
                  left: 430,
                  width: 252,
                  height: 252,
                  child: Stack(
                    fit: StackFit.expand,
                    alignment: Alignment.center,
                    children: [
                      Image.asset(
                        '$runtimeAssetRoot/ui/common/d100_roll_disc.webp',
                        fit: BoxFit.contain,
                        filterQuality: FilterQuality.high,
                        excludeFromSemantics: true,
                      ),
                      Center(
                        child: _RollingD100Number(
                          finalRoll: result.roll!,
                          duration: duration,
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  left: 285,
                  top: 62,
                  width: 340,
                  height: 78,
                  child: Center(
                    child: Text(
                      localizedDisplayCase(context, 'Purchase Roll'),
                      style: const TextStyle(
                        color: hifiGold,
                        fontFamily: 'Cinzel',
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  left: 330,
                  top: 430,
                  width: 450,
                  height: 64,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '${localizedDisplayCase(context, colorLabel(result.targetColor))} ${localizedDisplayCase(context, pieceTypeLabel(result.targetType))} · ${countries[result.targetCountryId]?.name ?? localizedDisplayCase(context, 'Neutral Court')}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Color(0xFF342315),
                          fontFamily: 'Cinzel',
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          letterSpacing: .5,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        result.buyerHadExactIntel
                            ? Localizations.localeOf(context).languageCode ==
                                      'zh'
                                  ? '成功率 ${result.chance}%'
                                  : '${result.chance}% SUCCESS CHANCE'
                            : localizedDisplayCase(
                                context,
                                'Success Chance Hidden',
                              ),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Color(0xFF6A4630),
                          fontFamily: 'Cormorant Garamond',
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  left: 72,
                  top: 516,
                  width: 760,
                  height: 76,
                  child: Center(
                    child: Text(
                      result.ringTokenConsumed
                          ? Localizations.localeOf(context).languageCode == 'zh'
                                ? '钻石戒指强化本次 D100 · +${result.treasureModifier}'
                                : 'DIAMOND RING EMPOWERED THIS D100 · +${result.treasureModifier}'
                          : localizedDisplayCase(
                              context,
                              'The Court Is Casting the D100…',
                            ),
                      key: result.ringTokenConsumed
                          ? const ValueKey('s24-diamond-ring-roll')
                          : null,
                      style: const TextStyle(
                        color: hifiInk,
                        fontFamily: 'Cinzel',
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RollingD100Number extends StatelessWidget {
  const _RollingD100Number({required this.finalRoll, required this.duration});

  final int finalRoll;
  final Duration duration;

  static const _style = TextStyle(
    color: Colors.white,
    fontSize: 72,
    fontWeight: FontWeight.w900,
    shadows: [Shadow(blurRadius: 8, color: Colors.black)],
  );

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.maybeOf(context)?.disableAnimations ?? false) {
      return Text(
        '$finalRoll',
        key: const ValueKey('s24-reduced-motion-roll'),
        style: _style,
      );
    }
    return TweenAnimationBuilder<double>(
      key: const ValueKey('s24-animated-roll'),
      tween: Tween(begin: 0, end: 1),
      duration: duration,
      curve: Curves.easeOutCubic,
      builder: (context, progress, _) {
        final displayed = progress >= .995
            ? finalRoll
            : ((progress * 497).floor() % 100) + 1;
        return Text('$displayed', style: _style);
      },
    );
  }
}

class _PurchaseOutcomeOverlay extends StatelessWidget {
  const _PurchaseOutcomeOverlay({
    required this.controller,
    required this.result,
    required this.placementPolicy,
  });

  final GameController controller;
  final OfferResult result;
  final PurchasePlacementPolicy placementPolicy;

  @override
  Widget build(BuildContext context) {
    final settlesInPlace =
        placementPolicy == PurchasePlacementPolicy.blackInPlace &&
        result.success &&
        controller.phase == GamePhase.redeploy &&
        controller.redeployPiece?.color == PieceColor.black;
    void continueFromResult() {
      if (settlesInPlace) {
        controller.resolvePendingPurchaseInPlace();
      } else {
        controller.dismissLastOfferResult();
      }
    }

    final title = result.resolutionKind == OfferResolutionKind.humiliated
        ? 'Offer Humiliated'
        : result.success
        ? 'Contract Accepted'
        : 'Contract Rejected';
    return Positioned.fill(
      child: CallbackShortcuts(
        bindings: <ShortcutActivator, VoidCallback>{
          const SingleActivator(LogicalKeyboardKey.enter): continueFromResult,
          const SingleActivator(LogicalKeyboardKey.numpadEnter):
              continueFromResult,
        },
        child: Focus(
          key: const ValueKey('purchase-result-focus'),
          autofocus: true,
          child: ColoredBox(
            color: const Color(0x99000000),
            child: Center(
              child: SizedBox(
                key: const ValueKey('s25-result-panel'),
                width: 940,
                height: 600,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      matchResultShellAsset,
                      key: const ValueKey('s25-reference-first-shell'),
                      fit: BoxFit.fill,
                      filterQuality: FilterQuality.high,
                      excludeFromSemantics: true,
                    ),
                    Positioned(
                      left: 88,
                      top: 166,
                      width: 268,
                      height: 304,
                      child: Column(
                        children: [
                          SizedBox(
                            width: 244,
                            height: 244,
                            child: _OfferResultPortrait(
                              result: result,
                              circular: true,
                            ),
                          ),
                          const SizedBox(height: 8),
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(
                              '${localizedDisplayCase(context, colorLabel(result.targetColor))} ${localizedDisplayCase(context, pieceTypeLabel(result.targetType))}',
                              style: const TextStyle(
                                color: Color(0xFF342315),
                                fontFamily: 'Cinzel',
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 154,
                      top: 65,
                      width: 632,
                      height: 72,
                      child: Center(
                        child: Text(
                          localizedDisplayCase(context, title),
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: result.success
                                ? const Color(0xFF266B4D)
                                : const Color(0xFF9D332F),
                            fontFamily: 'Cinzel',
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 398,
                      top: 164,
                      width: 448,
                      height: 302,
                      child: _ResultFacts(
                        result: result,
                        settlesInPlace: settlesInPlace,
                      ),
                    ),
                    Positioned(
                      left: 399,
                      top: 378,
                      width: 52,
                      height: 52,
                      child: Center(
                        child: Icon(
                          result.success
                              ? Icons.check_rounded
                              : Icons.close_rounded,
                          key: const ValueKey('s25-outcome-icon'),
                          color: result.success
                              ? const Color(0xFF16705B)
                              : const Color(0xFF9D332F),
                          size: 34,
                          shadows: const [
                            Shadow(color: Color(0x66FFFFFF), blurRadius: 2),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 132,
                      top: 489,
                      width: 676,
                      height: 62,
                      child: SizedBox.expand(
                        child: HifiPrimaryButton(
                          key: const ValueKey('purchase-result-dismiss'),
                          label: result.success
                              ? settlesInPlace
                                    ? 'Continue'
                                    : 'Choose Placement'
                              : 'Return to Board',
                          icon: result.success && !settlesInPlace
                              ? Icons.place
                              : Icons.check,
                          variant: HifiButtonVariant.emerald,
                          backgroundAsset: matchButtonEmeraldAsset,
                          backgroundImageScale: matchButtonImageScale,
                          onPressed: continueFromResult,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _OfferResultPortrait extends StatelessWidget {
  const _OfferResultPortrait({required this.result, this.circular = false});

  final OfferResult result;
  final bool circular;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0x44221A12),
        border: Border.all(color: hifiGoldDark, width: 1.5),
        shape: circular ? BoxShape.circle : BoxShape.rectangle,
        borderRadius: circular ? null : BorderRadius.circular(10),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: circular
            ? ClipOval(child: _portrait())
            : ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: _portrait(),
              ),
      ),
    );
  }

  Widget _portrait() => PieceArtImage(
    countryId: result.targetCountryId,
    type: result.targetType,
    kind: PieceArtKind.portrait,
    alignment: Alignment.bottomCenter,
  );
}

class _ResultFacts extends StatelessWidget {
  const _ResultFacts({required this.result, required this.settlesInPlace});

  final OfferResult result;
  final bool settlesInPlace;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      key: const ValueKey('s25-result-facts'),
      container: true,
      label: result.success
          ? localizedUiCopy(context, 'Accepted contract facts')
          : localizedUiCopy(context, 'Rejected contract facts'),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (result.roll != null)
            _ResultFactRow(label: 'D100 roll', value: '${result.roll}'),
          if (result.roll == null)
            _ResultFactRow(
              label: 'Resolution',
              value: result.resolutionKind == OfferResolutionKind.automatic
                  ? localizedDisplayCase(context, 'Automatic')
                  : localizedDisplayCase(context, 'No Roll'),
            ),
          if (result.resolutionKind == OfferResolutionKind.rolled)
            _ResultFactRow(
              label: 'Success threshold',
              value: result.buyerHadExactIntel
                  ? '${result.chance}%'
                  : localizedDisplayCase(context, 'Hidden'),
            ),
          _ResultFactRow(
            label: 'Contract paid',
            value: Localizations.localeOf(context).languageCode == 'zh'
                ? '${result.paid} 金币'
                : '${result.paid} Gold',
          ),
          if (!result.success)
            _ResultFactRow(
              label: 'Refund returned',
              value: Localizations.localeOf(context).languageCode == 'zh'
                  ? '${result.refund} 金币'
                  : '${result.refund} Gold',
            ),
          _ResultFactRow(
            label: 'Reaction',
            value: switch (result.publicReaction) {
              OfferReaction.humiliated => localizedDisplayCase(
                context,
                'Loyalty Strengthened',
              ),
              OfferReaction.tempted => localizedDisplayCase(
                context,
                'Loyalty Weakened',
              ),
              OfferReaction.accepted => localizedDisplayCase(
                context,
                'Accepted',
              ),
            },
          ),
          if (result.buyerHadExactIntel &&
              result.loyaltyBefore != null &&
              result.loyaltyAfter != null)
            _ResultFactRow(
              label: 'Revealed loyalty',
              value: '${result.loyaltyBefore} → ${result.loyaltyAfter}',
            ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.only(left: 64, right: 8),
            child: Text(
              result.success
                  ? localizedUiCopy(
                      context,
                      settlesInPlace
                          ? 'The piece will transform on its current tile after you continue.'
                          : 'The piece has joined your court. Choose its redeploy square.',
                    )
                  : result.publicReaction == OfferReaction.humiliated
                  ? localizedUiCopy(
                      context,
                      'Humiliated — loyalty strengthened.',
                    )
                  : result.publicReaction == OfferReaction.tempted
                  ? localizedUiCopy(context, 'Tempted — loyalty weakened.')
                  : result.refund > 0
                  ? Localizations.localeOf(context).languageCode == 'zh'
                        ? '契约被拒绝。你的王庭收回了 ${result.refund} 金币。'
                        : 'The contract was rejected. Your court recovered ${result.refund} Gold.'
                  : localizedUiCopy(
                      context,
                      'The contract was rejected. Return to the board.',
                    ),
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF5C3B25),
                fontFamily: 'Cormorant Garamond',
                fontSize: 18,
                fontWeight: FontWeight.w700,
                height: 1.2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ResultFactRow extends StatelessWidget {
  const _ResultFactRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              localizedDisplayCase(context, label),
              style: const TextStyle(
                color: Color(0xFF6A4630),
                fontFamily: 'Cinzel',
                fontSize: 13,
                fontWeight: FontWeight.w800,
                letterSpacing: .5,
              ),
            ),
          ),
          Text(
            localizedUiCopy(context, value),
            style: const TextStyle(
              color: Color(0xFF342315),
              fontFamily: 'Cinzel',
              fontSize: 17,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}
