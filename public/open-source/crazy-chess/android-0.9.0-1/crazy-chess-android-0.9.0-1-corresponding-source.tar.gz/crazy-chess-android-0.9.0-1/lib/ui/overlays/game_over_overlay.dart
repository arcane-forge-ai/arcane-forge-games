import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../game/game_controller.dart';
import '../../l10n/ui_copy.dart';
import '../effects/production_board_effects.dart';
import '../menu/hifi_menu_widgets.dart';
import '../shared/country_crest.dart';
import '../shared/piece_art.dart';
import '../shared/formatters.dart';
import '../shared/reference_first_match_art.dart';

class GameOverOverlay extends StatelessWidget {
  const GameOverOverlay({
    required this.controller,
    this.onLobby,
    this.onRematch,
    super.key,
  });

  final GameController controller;
  final VoidCallback? onLobby;
  final VoidCallback? onRematch;

  @override
  Widget build(BuildContext context) {
    final winner = controller.winner;
    final endReason = controller.resolvedGameEndReason;
    final featuredColor = endReason == GameEndReason.kingTrapfall
        ? (winner == null
              ? null
              : winner == PieceColor.white
              ? PieceColor.black
              : PieceColor.white)
        : winner;
    final country = featuredColor == null
        ? null
        : controller.countryForColor(featuredColor);
    return Positioned.fill(
      child: Stack(
        children: [
          const ProductionFinalBoardDimOverlay(),
          _OutcomePlate(
            country: country,
            featuredColor: featuredColor,
            winner: winner,
            endReason: endReason,
          ),
          _OutcomeTitle(endReason: endReason),
          _ScorePanel(controller: controller, endReason: endReason),
          Positioned(
            left: 540,
            width: 560,
            bottom: 42,
            height: 72,
            child: Row(
              children: [
                Expanded(
                  child: HifiPrimaryButton(
                    key: const ValueKey('s28-play-again'),
                    label: 'Play Again',
                    icon: Icons.refresh,
                    variant: HifiButtonVariant.gold,
                    backgroundAsset: matchButtonGoldAsset,
                    backgroundCenterSlice: matchButtonCenterSlice,
                    backgroundImageScale: matchButtonImageScale,
                    onPressed: onRematch ?? controller.returnToSetup,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: HifiPrimaryButton(
                    key: const ValueKey('s28-back-to-lobby'),
                    label: 'Back to Lobby',
                    icon: Icons.home,
                    variant: HifiButtonVariant.dark,
                    backgroundAsset: matchButtonDarkAsset,
                    backgroundCenterSlice: matchButtonCenterSlice,
                    backgroundImageScale: matchButtonImageScale,
                    onPressed: onLobby ?? controller.returnToSetup,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _OutcomePlate extends StatelessWidget {
  const _OutcomePlate({
    required this.country,
    required this.featuredColor,
    required this.winner,
    required this.endReason,
  });

  final CountryConfig? country;
  final PieceColor? featuredColor;
  final PieceColor? winner;
  final GameEndReason endReason;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 18,
      top: 72,
      width: 520,
      height: 790,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (country != null)
            Image.asset(
              endReason == GameEndReason.kingTrapfall
                  ? PieceArtResolver.trapfallPortrait(country!.id)
                  : PieceArtResolver.victoryPortrait(country!.id),
              key: ValueKey(
                endReason == GameEndReason.kingTrapfall
                    ? 's28-trapfall-portrait'
                    : 's28-winner-portrait',
              ),
              fit: BoxFit.contain,
              alignment: Alignment.bottomCenter,
              filterQuality: FilterQuality.high,
              errorBuilder: (context, error, stackTrace) =>
                  Center(child: CountryCrest(country: country!, size: 180)),
            )
          else
            const Icon(Icons.shield_outlined, color: hifiGold, size: 180),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: 430,
              padding: const EdgeInsets.fromLTRB(22, 48, 22, 22),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0xF20A1013)],
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    country?.name ?? localizedUiCopy(context, 'Final Board'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: hifiInk,
                      fontFamily: 'Georgia',
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      height: 1,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    endReason == GameEndReason.kingTrapfall &&
                            featuredColor != null
                        ? Localizations.localeOf(context).languageCode == 'zh'
                              ? '${colorLabel(featuredColor!)}方王落入战场陷阱。${winner == null ? '没有王庭获胜。' : '${colorLabel(winner!)}方王庭获胜。'}'
                              : '${colorLabel(featuredColor!)} King fell to a battlefield trap. ${winner == null ? 'No court claims victory.' : '${colorLabel(winner!)} court wins.'}'
                        : winner == null
                        ? localizedUiCopy(context, 'No court claims victory.')
                        : Localizations.localeOf(context).languageCode == 'zh'
                        ? '${colorLabel(winner!)}方王庭获胜。'
                        : '${colorLabel(winner!)} court victorious.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: country?.secondaryColor ?? hifiGold,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OutcomeTitle extends StatelessWidget {
  const _OutcomeTitle({required this.endReason});

  final GameEndReason endReason;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 480,
      top: 110,
      width: 632,
      height: 230,
      child: endReason == GameEndReason.kingTrapfall
          ? Semantics(
              key: const ValueKey('s28-trapfall-banner'),
              image: true,
              label: localizedUiCopy(context, 'King Trapfall'),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [
                      Color(0xFF120B17),
                      Color(0xFF4B1720),
                      Color(0xFF120B17),
                    ],
                  ),
                  border: Border.all(color: hifiGold, width: 2),
                  boxShadow: const [
                    BoxShadow(color: Colors.black87, blurRadius: 22),
                    BoxShadow(color: Color(0x994E1020), blurRadius: 18),
                  ],
                ),
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.warning_amber_rounded,
                        color: Color(0xFFEBC66F),
                        size: 42,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        localizedDisplayCase(context, 'King Trapfall'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: hifiInk,
                          fontFamily: 'Cinzel',
                          fontSize: 46,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                          shadows: [
                            Shadow(color: Colors.black, blurRadius: 12),
                          ],
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        localizedDisplayCase(
                          context,
                          'The Battlefield Claimed the Crown',
                        ),
                        style: const TextStyle(
                          color: hifiGold,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
          : Semantics(
              key: ValueKey(
                endReason == GameEndReason.stalemate
                    ? 's28-stalemate-banner'
                    : 's28-checkmate-banner',
              ),
              image: true,
              label: endReason == GameEndReason.stalemate
                  ? localizedUiCopy(context, 'Stalemate')
                  : localizedUiCopy(context, 'Checkmate Victory'),
              child: Image.asset(
                endReason == GameEndReason.stalemate
                    ? matchStalemateBannerAsset
                    : matchCheckmateVictoryBannerAsset,
                fit: BoxFit.contain,
                filterQuality: FilterQuality.high,
                excludeFromSemantics: true,
              ),
            ),
    );
  }
}

class _ScorePanel extends StatelessWidget {
  const _ScorePanel({required this.controller, required this.endReason});

  final GameController controller;
  final GameEndReason endReason;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: 30,
      top: 154,
      width: 450,
      height: 596,
      child: HifiPanel(
        backgroundAsset: '$runtimeAssetRoot/ui/common/result_panel_9slice.webp',
        backgroundCenterSlice: const Rect.fromLTRB(104, 104, 920, 920),
        padding: endReason == GameEndReason.kingTrapfall
            ? const EdgeInsets.fromLTRB(48, 40, 48, 58)
            : const EdgeInsets.fromLTRB(48, 52, 48, 84),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              localizedUiCopy(context, 'Final Result'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF6A4B1F),
                fontFamily: 'Georgia',
                fontSize: 34,
                fontWeight: FontWeight.w900,
              ),
            ),
            SizedBox(height: endReason == GameEndReason.kingTrapfall ? 14 : 22),
            _ResultStat(
              icon: Icons.repeat,
              label: 'Turn Count',
              value: '${controller.turnCount}',
              compact: endReason == GameEndReason.kingTrapfall,
            ),
            _ResultStat(
              icon: Icons.groups,
              label: 'Purchased Pieces',
              value: '${controller.purchaseSuccesses}',
              compact: endReason == GameEndReason.kingTrapfall,
            ),
            _ResultStat(
              icon: Icons.gavel,
              label: 'Rejected Contracts',
              value: '${controller.purchaseFailures}',
              compact: endReason == GameEndReason.kingTrapfall,
            ),
            _ResultStat(
              icon: Icons.monetization_on,
              label: 'Final Gold',
              value:
                  '${controller.gold[PieceColor.white]} / ${controller.gold[PieceColor.black]}',
              compact: endReason == GameEndReason.kingTrapfall,
            ),
            if (endReason == GameEndReason.kingTrapfall)
              _ResultStat(
                icon: Icons.warning_amber_rounded,
                label: 'Victory Cause',
                value: localizedUiCopy(context, 'Battlefield Trap'),
                compact: true,
              ),
            const Spacer(),
            Text(
              localizedUiCopy(
                context,
                'The final board remains visible for review.',
              ),
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xFF5E4B2F), fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}

class _ResultStat extends StatelessWidget {
  const _ResultStat({
    required this.icon,
    required this.label,
    required this.value,
    this.compact = false,
  });

  final IconData icon;
  final String label;
  final String value;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: compact ? 6 : 10),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xDD111820),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: hifiGoldDark),
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: 16,
            vertical: compact ? 8 : 12,
          ),
          child: Row(
            children: [
              Icon(icon, color: hifiGold),
              const SizedBox(width: 12),
              Flexible(
                flex: 3,
                child: Text(
                  localizedUiCopy(context, label),
                  style: const TextStyle(
                    color: hifiMuted,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Flexible(
                flex: 2,
                child: Text(
                  value,
                  maxLines: 2,
                  overflow: TextOverflow.fade,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    color: hifiInk,
                    fontSize: value.length > 10 ? 16 : 20,
                    fontWeight: FontWeight.w900,
                    height: 1.05,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
