import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../domain/board_presentation.dart';
import '../../last_piece/last_piece_models.dart';
import '../../last_piece/last_piece_session_controller.dart';

class LastPiecePresentationCoordinator extends ChangeNotifier {
  LastPiecePresentationCoordinator({
    required this.controller,
    this.moveDuration = const Duration(milliseconds: 400),
    this.transformDuration = const Duration(milliseconds: 480),
    this.spawnDuration = const Duration(milliseconds: 320),
  }) {
    controller.addListener(_handleControllerChanged);
  }

  final LastPieceSessionController controller;
  final Duration moveDuration;
  final Duration transformDuration;
  final Duration spawnDuration;

  final List<LastPiecePresentationStep> _queue = <LastPiecePresentationStep>[];
  Timer? _timer;
  Completer<void>? _settleCompleter;
  int _lastSeenSequenceSerial = 0;
  bool _reducedMotion = false;
  bool _disposed = false;

  LastPiecePresentationStep? activeStep;
  BoardMotionEvent? lastCompletedMotion;

  bool get reducedMotion => _reducedMotion;
  bool get isBusy => activeStep != null || _queue.isNotEmpty;

  Future<void> settle() {
    if (!isBusy) {
      return Future<void>.value();
    }
    _settleCompleter ??= Completer<void>();
    return _settleCompleter!.future;
  }

  void setReducedMotion(bool value) {
    if (_reducedMotion == value) {
      return;
    }
    _reducedMotion = value;
    if (value && isBusy) {
      _timer?.cancel();
      _timer = null;
      _drainReducedMotion();
      return;
    }
    notifyListeners();
  }

  void reset() {
    _timer?.cancel();
    _timer = null;
    _queue.clear();
    activeStep = null;
    lastCompletedMotion = null;
    _lastSeenSequenceSerial = controller.presentationSequenceSerial;
    _completeSettled();
    notifyListeners();
  }

  void _handleControllerChanged() {
    if (_disposed) {
      return;
    }
    final sequenceSerial = controller.presentationSequenceSerial;
    if (sequenceSerial == 0 && _lastSeenSequenceSerial != 0) {
      reset();
      return;
    }
    if (sequenceSerial == 0 || sequenceSerial == _lastSeenSequenceSerial) {
      return;
    }
    _lastSeenSequenceSerial = sequenceSerial;
    _queue.addAll(controller.presentationSteps);
    _settleCompleter ??= Completer<void>();
    if (activeStep == null) {
      _startNext();
    }
  }

  void _startNext() {
    _timer?.cancel();
    _timer = null;
    if (_reducedMotion) {
      _drainReducedMotion();
      return;
    }
    if (_queue.isEmpty) {
      activeStep = null;
      _completeSettled();
      notifyListeners();
      return;
    }
    activeStep = _queue.removeAt(0);
    notifyListeners();
    _timer = Timer(_durationFor(activeStep!), _finishActiveStep);
  }

  Duration _durationFor(LastPiecePresentationStep step) {
    return switch (step.kind) {
      LastPiecePresentationKind.motion => moveDuration,
      LastPiecePresentationKind.transformation => transformDuration,
      LastPiecePresentationKind.spawn => spawnDuration,
    };
  }

  void _finishActiveStep() {
    final completed = activeStep;
    if (completed?.motion != null) {
      lastCompletedMotion = completed!.motion;
    }
    activeStep = null;
    _startNext();
  }

  void _drainReducedMotion() {
    if (activeStep?.motion != null) {
      lastCompletedMotion = activeStep!.motion;
    }
    for (final step in _queue) {
      if (step.motion != null) {
        lastCompletedMotion = step.motion;
      }
    }
    _queue.clear();
    activeStep = null;
    _completeSettled();
    notifyListeners();
  }

  void _completeSettled() {
    final completer = _settleCompleter;
    _settleCompleter = null;
    if (completer != null && !completer.isCompleted) {
      completer.complete();
    }
  }

  @override
  void dispose() {
    if (_disposed) {
      return;
    }
    _disposed = true;
    _timer?.cancel();
    controller.removeListener(_handleControllerChanged);
    _completeSettled();
    super.dispose();
  }
}
