import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../battlefield/battlefield_models.dart';
import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../game/game_controller.dart';
import '../../l10n/ui_copy.dart';
import '../menu/hifi_menu_widgets.dart';
import '../shared/country_crest.dart';
import '../shared/formatters.dart';
import '../shared/piece_art.dart';
import '../shared/reference_first_match_art.dart';
import '../shared/special_tile_art.dart';

class OfferComposer extends StatelessWidget {
  const OfferComposer({required this.controller, super.key});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final square = controller.offerTarget;
    if (square == null) {
      return Text(localizedUiCopy(context, 'No offer target.'));
    }
    final piece = controller.pieceAt(square);
    if (piece == null) {
      return Text(localizedUiCopy(context, 'No offer target.'));
    }
    final country = countries[piece.countryId]!;
    final revealed = controller.isPieceRevealed(piece);
    final previewExact = controller.calculateChance(includeHidden: true);
    final loyaltyBand = controller.visibleLoyaltyBandForActiveCourt(piece);
    return SizedBox.expand(
      key: const ValueKey('s22-contract-parchment'),
      child: Stack(
        fit: StackFit.expand,
        clipBehavior: Clip.hardEdge,
        children: [
          Image.asset(
            matchOfferContractShellAsset,
            key: const ValueKey('s22-reference-first-shell'),
            fit: BoxFit.fill,
            filterQuality: FilterQuality.high,
            excludeFromSemantics: true,
          ),
          Positioned(
            left: 250,
            top: 70,
            width: 442,
            height: 82,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  localizedDisplayCase(context, 'Offer Contract'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontFamily: 'Cinzel',
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  localizedUiCopy(
                    context,
                    'Propose terms to the opposing court',
                  ),
                  style: const TextStyle(
                    color: hifiMuted,
                    fontFamily: 'Cormorant Garamond',
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: 54,
            top: 102,
            width: 216,
            height: 330,
            child: _ContractTargetRegion(
              country: country,
              piece: piece,
              squareName: controller.squareName(square),
            ),
          ),
          Positioned(
            left: 500,
            top: 164,
            width: 208,
            height: 150,
            child: _ContractFactsRegion(
              controller: controller,
              piece: piece,
              revealed: revealed,
              loyaltyBand: loyaltyBand,
              exactLoyalty: controller.visibleExactLoyaltyForActiveCourt(piece),
              preview: previewExact,
            ),
          ),
          Positioned(
            left: 206,
            top: 328,
            width: 360,
            height: 92,
            child: _OfferValueRegion(controller: controller),
          ),
          Positioned(
            left: 118,
            top: 435,
            width: 470,
            height: 58,
            child: GoldOfferStepper(
              value: controller.offerGold,
              maxGold: controller.gold[controller.turn]!,
              onChanged: controller.setOfferGold,
            ),
          ),
          Positioned(
            left: 600,
            top: 342,
            width: 112,
            height: 152,
            child: _ChanceRegion(
              controller: controller,
              revealed: revealed,
              preview: previewExact,
            ),
          ),
          Positioned(
            left: 154,
            top: 530,
            width: 576,
            height: 60,
            child: _ContractActions(controller: controller),
          ),
        ],
      ),
    );
  }
}

class _ContractTargetRegion extends StatelessWidget {
  const _ContractTargetRegion({
    required this.country,
    required this.piece,
    required this.squareName,
  });

  final CountryConfig country;
  final ChessPiece piece;
  final String squareName;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          key: const ValueKey('s22-target-portrait'),
          height: 218,
          child: ClipOval(
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: country.color.withValues(alpha: .22),
              ),
              child: PieceArtImage(
                countryId: piece.countryId,
                type: piece.type,
                kind: PieceArtKind.portrait,
                alignment: Alignment.bottomCenter,
              ),
            ),
          ),
        ),
        const SizedBox(height: 9),
        Text(
          '${colorLabel(piece.color).toUpperCase()} ${pieceTypeLabel(piece.type).toUpperCase()}',
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: Color(0xFF342315),
            fontFamily: 'Cinzel',
            fontSize: 15,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 5),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CountryCrest(country: country, size: 20),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                '${country.name} · $squareName',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Color(0xFF6A4630),
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _ContractFactsRegion extends StatelessWidget {
  const _ContractFactsRegion({
    required this.controller,
    required this.piece,
    required this.revealed,
    required this.loyaltyBand,
    required this.exactLoyalty,
    required this.preview,
  });

  final GameController controller;
  final ChessPiece piece;
  final bool revealed;
  final LoyaltyBand? loyaltyBand;
  final int? exactLoyalty;
  final ChancePreview preview;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _ContractFactBar(
          label: 'AVAILABLE GOLD',
          value: '${controller.gold[controller.turn]}',
        ),
        const SizedBox(height: 8),
        _ContractFactBar(
          key: ValueKey(
            controller.visibleFairPriceForActiveCourt(piece) == null
                ? 's22-fair-price-hidden'
                : 's22-fair-price-visible',
          ),
          label: 'FAIR COST',
          value:
              '${controller.visibleFairPriceForActiveCourt(piece) ?? 'UNKNOWN'}',
        ),
        const SizedBox(height: 8),
        _ContractFactBar(
          key: ValueKey(
            loyaltyBand != null
                ? exactLoyalty != null
                      ? 's22-exact-loyalty'
                      : 's22-coarse-loyalty'
                : 's22-hidden-chance-fact',
          ),
          label: loyaltyBand == null ? 'SUCCESS' : 'LOYALTY',
          value: loyaltyBand == null
              ? 'HIDDEN'
              : exactLoyalty != null
              ? '$exactLoyalty'
              : localizedDisplayCase(context, loyaltyBand!.label),
        ),
        if (preview.countryOfferPriceAdjustment != 0 ||
            preview.countryChanceModifier != 0) ...[
          const SizedBox(height: 8),
          _ContractFactBar(
            key: const ValueKey('s22-country-rule-adjustment'),
            label: preview.targetExposed ? 'EXPOSED' : 'COUNTRY RULE',
            value: preview.countryChanceModifier != 0
                ? signed(preview.countryChanceModifier)
                : '${localizedDisplayCase(context, 'Price')} ${signed(preview.countryOfferPriceAdjustment)}',
          ),
        ],
      ],
    );
  }
}

class _ContractFactBar extends StatelessWidget {
  const _ContractFactBar({required this.label, required this.value, super.key});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(left: 16, right: 8),
        child: Row(
          children: [
            Expanded(
              child: Text(
                localizedDisplayCase(context, label),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: hifiMuted,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              localizedUiCopy(context, value),
              style: const TextStyle(
                color: hifiGold,
                fontFamily: 'Cinzel',
                fontSize: 13,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OfferValueRegion extends StatelessWidget {
  const _OfferValueRegion({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          localizedDisplayCase(context, 'Offered Gold'),
          style: const TextStyle(
            color: hifiMuted,
            fontFamily: 'Cinzel',
            fontSize: 11,
            fontWeight: FontWeight.w900,
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 5),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 54,
              height: 50,
              child: HifiPrimaryButton(
                key: const ValueKey('s22-offer-minus'),
                label: '−',
                onPressed: () => controller.adjustOfferGold(-5),
                variant: HifiButtonVariant.dark,
                backgroundAsset: matchButtonDarkAsset,
                backgroundImageScale: matchButtonImageScale,
              ),
            ),
            SizedBox(
              width: 182,
              child: Text(
                '${controller.offerGold}',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: hifiGold,
                  fontFamily: 'Cinzel',
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            SizedBox(
              width: 54,
              height: 50,
              child: HifiPrimaryButton(
                key: const ValueKey('s22-offer-plus'),
                label: '+',
                onPressed: () => controller.adjustOfferGold(5),
                variant: HifiButtonVariant.dark,
                backgroundAsset: matchButtonDarkAsset,
                backgroundImageScale: matchButtonImageScale,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _ChanceRegion extends StatelessWidget {
  const _ChanceRegion({
    required this.controller,
    required this.revealed,
    required this.preview,
  });

  final GameController controller;
  final bool revealed;
  final ChancePreview preview;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ChanceStateBadge(revealed: revealed, exactChance: preview.finalChance),
        if (preview.ringTokenApplied) ...[
          const SizedBox(height: 5),
          Row(
            key: ValueKey('s22-diamond-ring-armed'),
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SpecialTileArt(
                type: SpecialTileType.diamondRing,
                size: 18,
                scale: 1.35,
              ),
              const SizedBox(width: 3),
              Text(
                Localizations.localeOf(context).languageCode == 'zh'
                    ? '戒指 +50'
                    : 'RING +50',
                style: const TextStyle(
                  color: Color(0xFF145D6B),
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ],
        const SizedBox(height: 8),
        if (controller.activeCountry.id == 'spy' && !revealed)
          SizedBox(
            width: double.infinity,
            height: 48,
            child: HifiPrimaryButton(
              key: const ValueKey('s22-reveal-chance'),
              label: 'Reveal',
              icon: Icons.visibility,
              onPressed: controller.revealOfferChance,
              variant: HifiButtonVariant.dark,
              backgroundAsset: matchButtonDarkAsset,
              backgroundImageScale: matchButtonImageScale,
            ),
          )
        else
          Text(
            revealed
                ? localizedUiCopy(context, 'Exact odds shown')
                : localizedUiCopy(context, 'Hidden by court rules'),
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: hifiMuted,
              fontSize: 10,
              height: 1.15,
            ),
          ),
      ],
    );
  }
}

class _ContractActions extends StatelessWidget {
  const _ContractActions({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: SizedBox.expand(
            child: HifiPrimaryButton(
              key: const ValueKey('s22-submit-contract'),
              label: 'Submit Offer',
              icon: Icons.gavel,
              variant: HifiButtonVariant.emerald,
              backgroundAsset: matchButtonEmeraldAsset,
              backgroundImageScale: matchButtonImageScale,
              onPressed: controller.confirmOffer,
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: SizedBox.expand(
            child: HifiPrimaryButton(
              key: const ValueKey('s22-close-contract'),
              label: 'Return to Board',
              icon: Icons.close,
              onPressed: controller.cancelOffer,
              variant: HifiButtonVariant.dark,
              backgroundAsset: matchButtonDarkAsset,
              backgroundImageScale: matchButtonImageScale,
            ),
          ),
        ),
      ],
    );
  }
}

class ChanceStateBadge extends StatelessWidget {
  const ChanceStateBadge({
    required this.revealed,
    required this.exactChance,
    super.key,
  });

  final bool revealed;
  final int exactChance;

  @override
  Widget build(BuildContext context) {
    final asset = revealed
        ? 'assets/runtime/ui/common/chance_badge_revealed.webp'
        : 'assets/runtime/ui/common/chance_badge_hidden.webp';
    final label = revealed
        ? Localizations.localeOf(context).languageCode == 'zh'
              ? '准确概率 $exactChance%'
              : 'Exact $exactChance%'
        : localizedUiCopy(context, 'Chance hidden');
    final content = Center(
      child: Text(
        label,
        key: ValueKey(revealed ? 's22-exact-chance' : 's22-hidden-chance-text'),
        style: TextStyle(
          color: revealed ? const Color(0xFFd7f5ea) : hifiInk,
          fontSize: 12,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
    return SizedBox(
      width: 170,
      height: 40,
      child: HifiAssetSurface(
        key: ValueKey(
          revealed ? 's22-chance-badge-revealed' : 's22-chance-badge-hidden',
        ),
        asset: asset,
        child: content,
      ),
    );
  }
}

class GoldOfferStepper extends StatelessWidget {
  const GoldOfferStepper({
    required this.value,
    required this.maxGold,
    required this.onChanged,
    super.key,
  });

  final int value;
  final int maxGold;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final maximum = math.max(1, maxGold);
    final progress = maximum == 1 ? 0.0 : (value - 1) / (maximum - 1);
    return SizedBox(
      key: const ValueKey('s22-gold-stepper'),
      height: 42,
      child: LayoutBuilder(
        builder: (context, constraints) {
          const thumbDiameter = 30.0;
          const sliderInset = 24.0;
          final thumbLeft =
              sliderInset -
              thumbDiameter / 2 +
              progress * (constraints.maxWidth - sliderInset * 2);
          return Stack(
            alignment: Alignment.center,
            children: [
              const Positioned(
                left: sliderInset,
                right: sliderInset,
                top: 16,
                height: 8,
                child: Image(
                  image: AssetImage(
                    'assets/runtime/ui/common/gold_stepper_track.webp',
                  ),
                  fit: BoxFit.fill,
                  filterQuality: FilterQuality.high,
                  excludeFromSemantics: true,
                ),
              ),
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  trackHeight: 4,
                  activeTrackColor: Colors.transparent,
                  inactiveTrackColor: Colors.transparent,
                  thumbColor: Colors.transparent,
                  overlayColor: Colors.transparent,
                  thumbShape: const RoundSliderThumbShape(
                    enabledThumbRadius: 15,
                  ),
                ),
                child: Slider(
                  min: 1,
                  max: maximum.toDouble(),
                  divisions: math.max(1, maximum - 1),
                  value: value.toDouble().clamp(1, maximum.toDouble()),
                  onChanged: (next) => onChanged(next.round()),
                ),
              ),
              Positioned(
                left: thumbLeft,
                top: 6,
                child: const IgnorePointer(
                  child: Image(
                    image: AssetImage(
                      'assets/runtime/ui/common/gold_stepper_knob.webp',
                    ),
                    width: thumbDiameter,
                    height: thumbDiameter,
                    filterQuality: FilterQuality.high,
                    excludeFromSemantics: true,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
