import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import 'country_crest.dart';
import 'formatters.dart';

const referenceFirstPieceArtRoot =
    'assets/runtime/pieces/characters/reference_first';
const mercantileSpyPieceArtRoot = 'assets/runtime/pieces/characters/match';
const mercantileSideLiveryRoot =
    '$mercantileSpyPieceArtRoot/mercantile_liveries';
const ashenSideLiveryRoot =
    'assets/runtime/pieces/characters/living/ashen_liveries';
const trapfallArtRoot = 'assets/runtime/battlefields/chaos_crucible/trapfall';

@immutable
class PieceArtSpec {
  const PieceArtSpec({
    required this.boardTokenAsset,
    required this.portraitAsset,
    required this.roleLabel,
    required this.identityKey,
    this.boardTokenFallbackAsset,
    this.fallbackAsset,
  });

  final String boardTokenAsset;
  final String portraitAsset;
  final String roleLabel;
  final String identityKey;
  final String? boardTokenFallbackAsset;
  final String? fallbackAsset;
}

class PieceArtResolver {
  const PieceArtResolver._();

  static PieceArtSpec resolve({
    required String countryId,
    required PieceType type,
    PieceColor? color,
  }) {
    final identity = _identity(countryId, type);
    final isMercantile = countryId == 'mercantile';
    final isSpy = countryId == 'spy';
    final hasCountrySpecificArt = isMercantile || isSpy;
    final keepApprovedMercantileRoyalToken =
        isMercantile && (type == PieceType.king || type == PieceType.queen);
    final originalBoardToken = keepApprovedMercantileRoyalToken
        ? '$referenceFirstPieceArtRoot/${identity}_token.webp'
        : hasCountrySpecificArt
        ? '$mercantileSpyPieceArtRoot/${identity}_token.webp'
        : '$referenceFirstPieceArtRoot/${identity}_token.webp';
    final sideBoardToken = color == null
        ? null
        : switch (countryId) {
            'mercantile' =>
              '$mercantileSideLiveryRoot/${color.name}/'
                  'mercantile_${type.name}_token.webp',
            'ashen' =>
              '$ashenSideLiveryRoot/${color.name}/'
                  'ashen_${type.name}_token.webp',
            _ => null,
          };
    return PieceArtSpec(
      boardTokenAsset: sideBoardToken ?? originalBoardToken,
      portraitAsset: hasCountrySpecificArt
          ? '$mercantileSpyPieceArtRoot/${countryId}_${type.name}_portrait.webp'
          : '$referenceFirstPieceArtRoot/${identity}_portrait.webp',
      roleLabel: pieceTypeLabel(type),
      identityKey: identity,
      boardTokenFallbackAsset: sideBoardToken == null
          ? null
          : originalBoardToken,
      fallbackAsset: _fallbackAsset(countryId, type),
    );
  }

  static String _identity(String countryId, PieceType type) {
    if (countryId == 'mercantile' || countryId == 'spy') {
      return '${countryId}_${type.name}';
    }
    if (type == PieceType.king || type == PieceType.queen) {
      if (countryId == 'iron') {
        return '${countryId}_${type.name}';
      }
      return 'neutral_${type.name}';
    }
    return 'shared_${type.name}';
  }

  static String? _fallbackAsset(String countryId, PieceType type) {
    if (countryId == 'mercantile' && type == PieceType.queen) {
      return 'assets/runtime/pieces/characters/mercantile/queen_bust.webp';
    }
    if (countryId == 'iron' && type == PieceType.king) {
      return 'assets/runtime/pieces/countries/iron/representative_bust_neutral.webp';
    }
    return null;
  }

  static String victoryPortrait(String countryId) {
    return switch (countryId) {
      'mercantile' => '$referenceFirstPieceArtRoot/mercantile_king_master.webp',
      'iron' => '$referenceFirstPieceArtRoot/iron_king_master.webp',
      _ => '$referenceFirstPieceArtRoot/neutral_king_master.webp',
    };
  }

  static String trapfallPortrait(String countryId) {
    return switch (countryId) {
      'mercantile' => '$trapfallArtRoot/mercantile_king_trapfall.webp',
      'spy' => '$trapfallArtRoot/spy_king_trapfall.webp',
      _ => resolve(countryId: countryId, type: PieceType.king).portraitAsset,
    };
  }
}

class PieceArtImage extends StatelessWidget {
  const PieceArtImage({
    required this.countryId,
    required this.type,
    required this.kind,
    this.color,
    this.fit = BoxFit.contain,
    this.alignment = Alignment.center,
    this.filterQuality = FilterQuality.high,
    super.key,
  }) : assert(kind == PieceArtKind.portrait || color != null);

  final String countryId;
  final PieceType type;
  final PieceArtKind kind;
  final PieceColor? color;
  final BoxFit fit;
  final Alignment alignment;
  final FilterQuality filterQuality;

  @override
  Widget build(BuildContext context) {
    final spec = PieceArtResolver.resolve(
      countryId: countryId,
      type: type,
      color: color,
    );
    final asset = kind == PieceArtKind.token
        ? spec.boardTokenAsset
        : spec.portraitAsset;
    return Image.asset(
      asset,
      key: ValueKey(
        'piece-art-${kind.name}-${spec.identityKey}'
        '${kind == PieceArtKind.token ? '-${color!.name}' : ''}',
      ),
      fit: fit,
      alignment: alignment,
      filterQuality: filterQuality,
      excludeFromSemantics: true,
      errorBuilder: (context, error, stackTrace) {
        final fallback = kind == PieceArtKind.token
            ? spec.boardTokenFallbackAsset
            : spec.fallbackAsset;
        if (fallback != null) {
          return Image.asset(
            fallback,
            fit: fit,
            alignment: alignment,
            filterQuality: filterQuality,
            excludeFromSemantics: true,
          );
        }
        final country = countries[countryId];
        return Stack(
          alignment: Alignment.center,
          children: [
            if (country != null)
              Opacity(
                opacity: .32,
                child: CountryCrest(country: country, size: 96),
              ),
            Text(
              _fallbackSymbol(type),
              style: TextStyle(
                color: country?.secondaryColor ?? const Color(0xFFE6C36A),
                fontSize: kind == PieceArtKind.token ? 34 : 70,
                fontWeight: FontWeight.w900,
                shadows: const [Shadow(color: Colors.black, blurRadius: 8)],
              ),
            ),
          ],
        );
      },
    );
  }
}

enum PieceArtKind { token, portrait }

String _fallbackSymbol(PieceType type) => switch (type) {
  PieceType.king => '♚',
  PieceType.queen => '♛',
  PieceType.rook => '♜',
  PieceType.bishop => '♝',
  PieceType.knight => '♞',
  PieceType.pawn => '♟',
};
