import 'package:flutter/material.dart';

import '../../battlefield/battlefield_models.dart';
import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../game/game_controller.dart';
import '../../l10n/ui_copy.dart';
import '../menu/hifi_menu_widgets.dart';
import '../shared/country_ability_copy.dart';
import '../shared/country_crest.dart';
import '../shared/reference_first_match_art.dart';
import '../shared/formatters.dart';
import '../shared/special_tile_art.dart';

class PlayerPlate extends StatelessWidget {
  const PlayerPlate({required this.controller, required this.color, super.key});

  final GameController controller;
  final PieceColor color;

  @override
  Widget build(BuildContext context) {
    final country = controller.countryForColor(color);
    final active =
        controller.phase == GamePhase.playing && controller.turn == color;
    final check =
        controller.phase == GamePhase.playing &&
        controller.isKingInCheck(color);
    final generatedCountrySurface =
        country.id == 'mercantile' || country.id == 'spy';
    final crestAsset = matchCountryCrestAsset(country.id);
    return AnimatedContainer(
      key: ValueKey('s20-player-plate-${country.id}-${color.name}'),
      duration: const Duration(milliseconds: 180),
      child: HifiAssetSurface(
        asset: matchCourtPlateAsset(
          country.id,
          blackSide: color == PieceColor.black,
        ),
        centerSlice: generatedCountrySurface
            ? null
            : matchCourtPlateCenterSlice,
        padding: const EdgeInsets.fromLTRB(42, 8, 34, 8),
        child: Row(
          children: [
            SizedBox(
              width: 40,
              height: 40,
              child: crestAsset == null
                  ? CountryCrest(country: country, size: 40)
                  : Image.asset(
                      crestAsset,
                      key: ValueKey('s20-country-crest-${country.id}'),
                      fit: BoxFit.contain,
                      filterQuality: FilterQuality.high,
                      errorBuilder: (context, error, stackTrace) =>
                          CountryCrest(country: country, size: 40),
                    ),
            ),
            const SizedBox(width: 46),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${colorLabel(color)} · ${country.shortName}',
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: check
                                ? const Color(0xFFFFAAA8)
                                : active
                                ? country.secondaryColor
                                : hifiInk,
                            fontFamily: 'Cinzel',
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            height: 1,
                          ),
                        ),
                      ),
                      if (color == PieceColor.black &&
                          controller.opponentMode ==
                              OpponentMode.stockfish) ...[
                        const SizedBox(width: 6),
                        const DecoratedBox(
                          key: ValueKey('stockfish-black-badge'),
                          decoration: BoxDecoration(
                            color: Color(0xFFB27C24),
                            borderRadius: BorderRadius.all(Radius.circular(3)),
                          ),
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: 5,
                              vertical: 2,
                            ),
                            child: Text(
                              'AI',
                              style: TextStyle(
                                color: Color(0xFF15100A),
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(width: 6),
                      _CountryAbilityButton(country: country, color: color),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Text(
                        Localizations.localeOf(context).languageCode == 'zh'
                            ? '金币 ${controller.gold[color]}${check ? '  ·  将军' : ''}'
                            : 'Gold ${controller.gold[color]}${check ? '  ·  CHECK' : ''}',
                        style: TextStyle(
                          fontSize: 12,
                          height: 1,
                          color: check
                              ? const Color(0xFFffaaa8)
                              : const Color(0xFFd7d0c3),
                        ),
                      ),
                      if (controller.diamondRingTokens[color]! > 0) ...[
                        const SizedBox(width: 10),
                        SpecialTileArt(
                          key: ValueKey('diamond-ring-${color.name}'),
                          type: SpecialTileType.diamondRing,
                          size: 18,
                          scale: 1.35,
                        ),
                        const SizedBox(width: 2),
                        Text(
                          '${controller.diamondRingTokens[color]}',
                          style: const TextStyle(
                            color: Color(0xFFBCEFFF),
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            height: 1,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CountryAbilityButton extends StatelessWidget {
  const _CountryAbilityButton({required this.country, required this.color});

  final CountryConfig country;
  final PieceColor color;

  @override
  Widget build(BuildContext context) {
    final label = localizedUiCopy(context, 'Ability');
    final side = color == PieceColor.white
        ? localizedUiCopy(context, 'White Court')
        : localizedUiCopy(context, 'Black Court');
    return Tooltip(
      message: countrySignatureTrait(country),
      waitDuration: const Duration(milliseconds: 250),
      child: Semantics(
        button: true,
        label: '$side · ${country.name} · $label',
        hint: countrySignatureTrait(country),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            key: ValueKey('country-ability-${color.name}'),
            borderRadius: BorderRadius.circular(5),
            onTap: () => showDialog<void>(
              context: context,
              barrierLabel: localizedUiCopy(context, 'Country Ability'),
              builder: (context) =>
                  _CountryAbilityDialog(country: country, color: color),
            ),
            child: Container(
              constraints: const BoxConstraints(minWidth: 72, minHeight: 28),
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
              decoration: BoxDecoration(
                color: country.color.withValues(alpha: .24),
                border: Border.all(
                  color: country.secondaryColor.withValues(alpha: .72),
                ),
                borderRadius: BorderRadius.circular(5),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.auto_awesome,
                    color: country.secondaryColor,
                    size: 13,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    localizedDisplayCase(context, 'Ability'),
                    style: const TextStyle(
                      color: hifiInk,
                      fontFamily: 'Cinzel',
                      fontSize: 9,
                      fontWeight: FontWeight.w900,
                      height: 1,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CountryAbilityDialog extends StatelessWidget {
  const _CountryAbilityDialog({required this.country, required this.color});

  final CountryConfig country;
  final PieceColor color;

  @override
  Widget build(BuildContext context) {
    final side = color == PieceColor.white
        ? localizedUiCopy(context, 'White Court')
        : localizedUiCopy(context, 'Black Court');
    final rules = countryRuleDetails(country);
    return Dialog(
      key: ValueKey('country-ability-dialog-${country.id}-${color.name}'),
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 620, maxHeight: 700),
        child: Material(
          color: Colors.transparent,
          child: HifiPanel(
            padding: const EdgeInsets.fromLTRB(30, 26, 30, 24),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CountryCrest(country: country, size: 64),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              localizedDisplayCase(context, 'Country Ability'),
                              style: TextStyle(
                                color: country.secondaryColor,
                                fontFamily: 'Cinzel',
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.1,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              country.name,
                              style: const TextStyle(
                                color: hifiInk,
                                fontFamily: 'Georgia',
                                fontSize: 30,
                                fontWeight: FontWeight.w900,
                                height: 1,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              side,
                              style: const TextStyle(
                                color: hifiMuted,
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        key: const ValueKey('country-ability-close'),
                        tooltip: MaterialLocalizations.of(
                          context,
                        ).closeButtonTooltip,
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.close, color: hifiInk),
                      ),
                    ],
                  ),
                  const Divider(height: 30, color: hifiGoldDark),
                  Text(
                    localizedDisplayCase(context, 'Signature Trait'),
                    style: const TextStyle(
                      color: hifiGold,
                      fontFamily: 'Cinzel',
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: .9,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    countrySignatureTrait(country),
                    style: const TextStyle(
                      color: hifiInk,
                      fontFamily: 'Georgia',
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      height: 1.25,
                    ),
                  ),
                  const SizedBox(height: 18),
                  for (final rule in rules)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Icon(
                              Icons.diamond,
                              color: country.secondaryColor,
                              size: 12,
                            ),
                          ),
                          const SizedBox(width: 9),
                          Expanded(
                            child: Text(
                              rule,
                              style: const TextStyle(
                                color: hifiMuted,
                                fontSize: 14,
                                height: 1.35,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 10),
                  Text(
                    localizedDisplayCase(context, 'Public Modifiers'),
                    style: const TextStyle(
                      color: hifiGold,
                      fontFamily: 'Cinzel',
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: .9,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _AbilityStatChip(
                        label: localizedUiCopy(context, 'Starting Gold'),
                        value: signed(country.startingGoldModifier),
                      ),
                      _AbilityStatChip(
                        label: localizedUiCopy(context, 'Merchant Payout'),
                        value: signed(country.merchantPayoutModifier),
                      ),
                      _AbilityStatChip(
                        label: localizedUiCopy(context, 'Offer Modifier'),
                        value: signed(country.offenseModifier),
                      ),
                      _AbilityStatChip(
                        label: localizedUiCopy(context, 'Starting Loyalty'),
                        value: country.loyaltyStartSummary,
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      const Icon(
                        Icons.info_outline,
                        color: hifiMuted,
                        size: 16,
                      ),
                      const SizedBox(width: 7),
                      Expanded(
                        child: Text(
                          localizedUiCopy(
                            context,
                            'Reference only — no action spent',
                          ),
                          style: const TextStyle(
                            color: hifiMuted,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 150,
                        child: HifiPrimaryButton(
                          key: const ValueKey('country-ability-done'),
                          label: 'Done',
                          icon: Icons.check,
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AbilityStatChip extends StatelessWidget {
  const _AbilityStatChip({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xAA0A1116),
        border: Border.all(color: hifiGoldDark),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        child: Text.rich(
          TextSpan(
            children: [
              TextSpan(
                text: '$label  ',
                style: const TextStyle(color: hifiMuted, fontSize: 11),
              ),
              TextSpan(
                text: value,
                style: const TextStyle(
                  color: hifiInk,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
