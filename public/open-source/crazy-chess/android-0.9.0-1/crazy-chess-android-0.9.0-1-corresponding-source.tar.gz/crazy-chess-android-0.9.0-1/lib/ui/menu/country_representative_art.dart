import 'package:flutter/material.dart';

import '../../domain/countries.dart';
import '../shared/country_crest.dart';

/// Resolves a production representative without ever borrowing another
/// country's portrait. Incomplete countries receive an intentional,
/// country-colored silhouette built around their own emblem.
class CountryRepresentativeArt extends StatelessWidget {
  const CountryRepresentativeArt({
    required this.country,
    this.bust = false,
    this.alignment = Alignment.bottomCenter,
    this.fit = BoxFit.contain,
    super.key,
  });

  final CountryConfig country;
  final bool bust;
  final Alignment alignment;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) {
    final asset = bust
        ? country.representativeBustAsset
        : country.representativeFullAsset;
    if (country.portraitReady && asset != null) {
      return Image.asset(
        asset,
        key: ValueKey('representative-${country.id}-${bust ? 'bust' : 'full'}'),
        fit: fit,
        alignment: alignment,
        filterQuality: FilterQuality.high,
        semanticLabel: '${country.name} representative',
      );
    }
    return Semantics(
      image: true,
      label: '${country.name} representative placeholder',
      child: Stack(
        key: ValueKey('representative-${country.id}-placeholder'),
        alignment: Alignment.bottomCenter,
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: FractionallySizedBox(
              widthFactor: bust ? .74 : .68,
              heightFactor: bust ? .92 : .86,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      country.secondaryColor.withValues(alpha: .78),
                      country.color.withValues(alpha: .92),
                      const Color(0xFF080B0E),
                    ],
                  ),
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.elliptical(180, 120),
                  ),
                  border: Border.all(
                    color: country.secondaryColor.withValues(alpha: .72),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: country.color.withValues(alpha: .5),
                      blurRadius: 28,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Align(
            alignment: const Alignment(0, -.15),
            child: FractionallySizedBox(
              widthFactor: bust ? .34 : .28,
              child: AspectRatio(
                aspectRatio: 1,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xE610151A),
                    border: Border.all(color: country.secondaryColor, width: 2),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: FittedBox(child: CountryCrest(country: country)),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
