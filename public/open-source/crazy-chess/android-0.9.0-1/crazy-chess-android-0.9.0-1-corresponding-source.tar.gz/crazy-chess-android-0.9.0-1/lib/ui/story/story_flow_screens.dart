import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../battlefield/battlefield_models.dart';
import '../../domain/chess_models.dart';
import '../../l10n/ui_copy.dart';
import '../../story/story_campaign_controller.dart';
import '../../story/story_models.dart';
import '../board/board_presentation_coordinator.dart';
import '../match/match_screen.dart';
import '../menu/hifi_menu_widgets.dart';

const _storyBackdrop = 'assets/runtime/scenes/setup/s02_lobby_court_bg.webp';

class StoryCampaignMapScreen extends StatelessWidget {
  const StoryCampaignMapScreen({
    required this.controller,
    required this.onBack,
    super.key,
  });

  final StoryCampaignController controller;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    if (controller.loadError != null) {
      return _StoryLoadError(
        message: controller.loadError!,
        onRetry: () => unawaited(controller.initialize()),
        onBack: onBack,
      );
    }
    if (controller.phase == StoryCampaignPhase.loading) {
      return const ColoredBox(
        color: Color(0xFF080B0E),
        child: Center(child: CircularProgressIndicator(color: hifiGold)),
      );
    }
    final campaign = controller.campaign;
    final selected = controller.selectedMission;
    return HifiScaffold(
      key: const ValueKey('story-map-screen'),
      backdropAsset: _storyBackdrop,
      backdropOpacity: .62,
      showDefaultScrims: false,
      child: Stack(
        children: [
          const Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xE5121718),
                    Color(0xB8282116),
                    Color(0xE5080B0E),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 48,
            top: 34,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  appLocalizationsOf(context).modeStoryCampaign,
                  key: const ValueKey('story-map-title'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontFamily: 'Cinzel',
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.2,
                  ),
                ),
                Text(
                  campaign.title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Cinzel',
                    fontSize: 38,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(
                  width: 730,
                  child: Text(
                    campaign.theme,
                    style: const TextStyle(
                      color: hifiMuted,
                      fontSize: 16,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: 70,
            right: 470,
            top: 152,
            bottom: 80,
            child: CustomPaint(
              painter: _CampaignRoutePainter(missions: campaign.missions),
              child: Stack(
                children: [
                  for (var index = 0; index < campaign.missions.length; index++)
                    _MissionNode(
                      mission: campaign.missions[index],
                      index: index,
                      selected:
                          campaign.missions[index].id ==
                          controller.selectedMissionId,
                      unlocked: controller.isMissionUnlocked(
                        campaign.missions[index].id,
                      ),
                      completed: controller.isMissionCompleted(
                        campaign.missions[index].id,
                      ),
                      onPressed: () =>
                          controller.selectMission(campaign.missions[index].id),
                    ),
                ],
              ),
            ),
          ),
          Positioned(
            right: 42,
            top: 132,
            bottom: 48,
            width: 390,
            child: _MissionDetailPanel(
              mission: selected,
              unlocked: controller.isMissionUnlocked(selected.id),
              completed: controller.isMissionCompleted(selected.id),
              recruitedCount: controller.profile.recruitedCharacterIds.length,
              onStart: controller.startSelectedMission,
            ),
          ),
          Positioned(
            left: 34,
            bottom: 24,
            child: TextButton.icon(
              key: const ValueKey('story-map-back'),
              onPressed: onBack,
              icon: const Icon(Icons.arrow_back),
              label: Text(localizedUiCopy(context, 'Back to Mode Select')),
              style: TextButton.styleFrom(foregroundColor: hifiMuted),
            ),
          ),
        ],
      ),
    );
  }
}

class StoryDialogueScreen extends StatelessWidget {
  const StoryDialogueScreen({required this.controller, super.key});

  final StoryCampaignController controller;

  @override
  Widget build(BuildContext context) {
    final line = controller.activeLine;
    if (line == null) {
      return const SizedBox.shrink();
    }
    final character = controller.campaign.characterById(line.speakerId);
    final portrait = character.portraitAsset(
      line.portraitStage,
      line.expression,
    );
    return CallbackShortcuts(
      bindings: <ShortcutActivator, VoidCallback>{
        const SingleActivator(LogicalKeyboardKey.enter):
            controller.advanceDialogue,
        const SingleActivator(LogicalKeyboardKey.space):
            controller.advanceDialogue,
        const SingleActivator(LogicalKeyboardKey.escape):
            controller.toggleBacklog,
      },
      child: Focus(
        autofocus: true,
        child: GestureDetector(
          key: const ValueKey('story-dialogue-screen'),
          behavior: HitTestBehavior.opaque,
          onTap: controller.backlogOpen ? null : controller.advanceDialogue,
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(
                controller.activeMission.battlefieldId.name == 'classic'
                    ? _storyBackdrop
                    : controller.gameController.battlefield.backgroundAsset ??
                          _storyBackdrop,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stack) =>
                    const ColoredBox(color: Color(0xFF10171B)),
              ),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0x66000000),
                      Color(0x10000000),
                      Color(0xE6000000),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: line.side == StoryDialogueSide.left
                    ? Alignment.bottomLeft
                    : Alignment.bottomRight,
                child: Padding(
                  padding: EdgeInsets.only(
                    left: line.side == StoryDialogueSide.left ? 30 : 760,
                    right: line.side == StoryDialogueSide.right ? 30 : 760,
                    bottom: 148,
                  ),
                  child: Image.asset(
                    portrait,
                    key: ValueKey(
                      'story-portrait-${line.speakerId}-${line.portraitStage}-${line.expression}',
                    ),
                    height: 610,
                    fit: BoxFit.contain,
                    alignment: Alignment.bottomCenter,
                    errorBuilder: (context, error, stack) => Icon(
                      Icons.person,
                      size: 300,
                      color: hifiGold.withValues(alpha: .5),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 118,
                right: 118,
                bottom: 58,
                height: 230,
                child: _DialogueFrame(
                  characterName: character.displayName,
                  text: line.text,
                  canSkip: controller.canSkipActiveScene,
                  onSkip: controller.skipActiveScene,
                  onBacklog: controller.toggleBacklog,
                ),
              ),
              Positioned(
                left: 32,
                right: 32,
                top: 22,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _StoryMissionTag(mission: controller.activeMission),
                    const Spacer(),
                    SizedBox(
                      width: 650,
                      child: _VictoryConditionsBanner(
                        key: const ValueKey(
                          'story-dialogue-victory-conditions',
                        ),
                        mission: controller.activeMission,
                      ),
                    ),
                  ],
                ),
              ),
              if (controller.backlogOpen)
                _DialogueBacklog(
                  lines: controller.backlog,
                  campaign: controller.campaign,
                  onClose: controller.toggleBacklog,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class StoryBattleScreen extends StatefulWidget {
  const StoryBattleScreen({
    required this.controller,
    required this.presentationCoordinator,
    this.storyDirectorStatus,
    super.key,
  });

  final StoryCampaignController controller;
  final BoardPresentationCoordinator presentationCoordinator;
  final Widget? storyDirectorStatus;

  @override
  State<StoryBattleScreen> createState() => _StoryBattleScreenState();
}

class _StoryBattleScreenState extends State<StoryBattleScreen> {
  bool _settlementScheduled = false;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_scheduleSettlement);
    widget.presentationCoordinator.addListener(_scheduleSettlement);
    _scheduleSettlement();
  }

  @override
  void didUpdateWidget(covariant StoryBattleScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_scheduleSettlement);
      widget.controller.addListener(_scheduleSettlement);
    }
    if (oldWidget.presentationCoordinator != widget.presentationCoordinator) {
      oldWidget.presentationCoordinator.removeListener(_scheduleSettlement);
      widget.presentationCoordinator.addListener(_scheduleSettlement);
    }
    _scheduleSettlement();
  }

  @override
  void dispose() {
    widget.controller.removeListener(_scheduleSettlement);
    widget.presentationCoordinator.removeListener(_scheduleSettlement);
    super.dispose();
  }

  void _scheduleSettlement() {
    if (_settlementScheduled || !mounted) {
      return;
    }
    _settlementScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _settlementScheduled = false;
      if (!mounted || widget.presentationCoordinator.isBusy) {
        return;
      }
      widget.controller.evaluateAfterPresentation();
      if (widget.controller.phase == StoryCampaignPhase.battle &&
          widget.controller.gameController.turn == PieceColor.black &&
          !widget.controller.isAiThinking) {
        unawaited(widget.controller.makeEnemyMove());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final story = widget.controller;
    return Stack(
      children: [
        AbsorbPointer(
          absorbing: story.playerInputLocked,
          child: MatchScreen(
            controller: story.gameController,
            presentationCoordinator: widget.presentationCoordinator,
            aiThinking: story.isAiThinking,
            aiInputLocked: story.playerInputLocked,
            storyDirectorStatus: widget.storyDirectorStatus,
            showGameOverOverlay: false,
          ),
        ),
        Positioned(
          left: 420,
          right: 500,
          top: 102,
          child: _ObjectiveBanner(mission: story.activeMission),
        ),
        if (story.turnSkipNotice case final notice?)
          Positioned(
            left: 520,
            right: 520,
            top: 158,
            child: _TurnSkipNoticeBanner(
              message: notice,
              skippedColor: story.lastSkippedTurnColor,
            ),
          ),
        Positioned(
          right: 22,
          bottom: 18,
          child: OutlinedButton.icon(
            key: const ValueKey('story-battle-map'),
            onPressed: story.returnToMap,
            icon: const Icon(Icons.map_outlined),
            label: Text(appLocalizationsOf(context).storyCampaignMap),
            style: OutlinedButton.styleFrom(
              foregroundColor: hifiMuted,
              backgroundColor: const Color(0xE60B1014),
            ),
          ),
        ),
      ],
    );
  }
}

class _TurnSkipNoticeBanner extends StatelessWidget {
  const _TurnSkipNoticeBanner({
    required this.message,
    required this.skippedColor,
  });

  final String message;
  final PieceColor? skippedColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      key: const ValueKey('story-turn-skip-notice'),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
      decoration: BoxDecoration(
        color: const Color(0xF21B2228),
        border: Border.all(color: hifiGold, width: 1.5),
        borderRadius: BorderRadius.circular(8),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 18)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            skippedColor == PieceColor.white
                ? Icons.keyboard_double_arrow_right
                : Icons.keyboard_double_arrow_left,
            color: hifiGold,
          ),
          const SizedBox(width: 10),
          Flexible(
            child: Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                letterSpacing: .25,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class StoryResultsScreen extends StatelessWidget {
  const StoryResultsScreen({
    required this.controller,
    required this.onLobby,
    super.key,
  });

  final StoryCampaignController controller;
  final VoidCallback onLobby;

  @override
  Widget build(BuildContext context) {
    final mission = controller.activeMission;
    final next = controller.campaign.nextAfter(mission.id);
    return HifiScaffold(
      backdropAsset: _storyBackdrop,
      backdropOpacity: .5,
      child: Center(
        child: Container(
          key: const ValueKey('story-results-screen'),
          width: 780,
          padding: const EdgeInsets.all(42),
          decoration: BoxDecoration(
            color: const Color(0xF20B1014),
            border: Border.all(color: hifiGold, width: 2),
            borderRadius: BorderRadius.circular(16),
            boxShadow: const [BoxShadow(color: Colors.black, blurRadius: 30)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                controller.missionSucceeded
                    ? Icons.workspace_premium
                    : Icons.replay_circle_filled,
                size: 72,
                color: controller.missionSucceeded
                    ? hifiGold
                    : const Color(0xFFE38B78),
              ),
              const SizedBox(height: 12),
              Text(
                controller.missionSucceeded
                    ? localizedDisplayCase(context, 'Mission Complete')
                    : localizedDisplayCase(context, 'Formation Broken'),
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: 'Cinzel',
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '${mission.id.toUpperCase()} · ${mission.title}',
                style: const TextStyle(color: hifiGold, fontSize: 20),
              ),
              const SizedBox(height: 18),
              Text(
                controller.missionSucceeded
                    ? next == null
                          ? localizedUiCopy(
                              context,
                              'Alder Crown is restored. The complete epilogue is now recorded.',
                            )
                          : Localizations.localeOf(context).languageCode == 'zh'
                          ? '${next.id.toUpperCase()} 已在战役地图上解锁。'
                          : '${next.id.toUpperCase()} is now available on the campaign map.'
                    : localizedUiCopy(
                        context,
                        'Named characters return when the authored mission setup is rebuilt. There is no permadeath.',
                      ),
                textAlign: TextAlign.center,
                style: const TextStyle(color: hifiMuted, fontSize: 16),
              ),
              const SizedBox(height: 30),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                alignment: WrapAlignment.center,
                children: [
                  FilledButton.icon(
                    key: const ValueKey('story-results-retry'),
                    onPressed: controller.retryMission,
                    icon: const Icon(Icons.refresh),
                    label: Text(localizedUiCopy(context, 'Retry Mission')),
                  ),
                  OutlinedButton.icon(
                    key: const ValueKey('story-results-map'),
                    onPressed: controller.returnToMap,
                    icon: const Icon(Icons.map),
                    label: Text(localizedUiCopy(context, 'Campaign Map')),
                  ),
                  TextButton(
                    key: const ValueKey('story-results-lobby'),
                    onPressed: onLobby,
                    child: Text(localizedUiCopy(context, 'Return to Lobby')),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MissionNode extends StatelessWidget {
  const _MissionNode({
    required this.mission,
    required this.index,
    required this.selected,
    required this.unlocked,
    required this.completed,
    required this.onPressed,
  });

  final CampaignMissionDefinition mission;
  final int index;
  final bool selected;
  final bool unlocked;
  final bool completed;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: mission.mapX * 940 - 42,
      top: mission.mapY * 610 - 42,
      width: 108,
      height: 108,
      child: Semantics(
        label:
            '${mission.id}, ${mission.title}, ${_missionStateLabel(context, completed: completed, unlocked: unlocked)}',
        button: unlocked,
        child: InkWell(
          key: ValueKey('story-node-${mission.id}'),
          onTap: unlocked ? onPressed : null,
          customBorder: const CircleBorder(),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: !unlocked
                  ? const Color(0xFF24282B)
                  : completed
                  ? const Color(0xFF1B5138)
                  : selected
                  ? const Color(0xFF8C5E1C)
                  : const Color(0xFF42351F),
              border: Border.all(
                color: selected ? Colors.white : hifiGold,
                width: selected ? 4 : 2,
              ),
              boxShadow: unlocked
                  ? [
                      BoxShadow(
                        color: hifiGold.withValues(alpha: .35),
                        blurRadius: selected ? 22 : 10,
                      ),
                    ]
                  : null,
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  !unlocked
                      ? Icons.lock
                      : completed
                      ? Icons.check
                      : Icons.flag,
                  color: unlocked ? Colors.white : hifiMuted,
                  size: 30,
                ),
                Text(
                  'M${index + 1}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CampaignRoutePainter extends CustomPainter {
  const _CampaignRoutePainter({required this.missions});

  final List<CampaignMissionDefinition> missions;

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path();
    for (var index = 0; index < missions.length; index++) {
      final point = Offset(
        missions[index].mapX * 940 + 12,
        missions[index].mapY * 610 + 12,
      );
      if (index == 0) {
        path.moveTo(point.dx, point.dy);
      } else {
        path.lineTo(point.dx, point.dy);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = hifiGold.withValues(alpha: .55)
        ..strokeWidth = 5
        ..style = PaintingStyle.stroke,
    );
  }

  @override
  bool shouldRepaint(covariant _CampaignRoutePainter oldDelegate) => false;
}

class _MissionDetailPanel extends StatelessWidget {
  const _MissionDetailPanel({
    required this.mission,
    required this.unlocked,
    required this.completed,
    required this.recruitedCount,
    required this.onStart,
  });

  final CampaignMissionDefinition mission;
  final bool unlocked;
  final bool completed;
  final int recruitedCount;
  final VoidCallback onStart;

  @override
  Widget build(BuildContext context) {
    final playerPieces = mission.pieces
        .where((piece) => piece.color == PieceColor.white)
        .length;
    return Container(
      padding: const EdgeInsets.all(26),
      decoration: BoxDecoration(
        color: const Color(0xF20B1014),
        border: Border.all(color: hifiGoldDark),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            mission.id.toUpperCase(),
            style: const TextStyle(
              color: hifiGold,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            mission.title,
            style: const TextStyle(
              color: Colors.white,
              fontFamily: 'Cinzel',
              fontSize: 28,
              fontWeight: FontWeight.w800,
            ),
          ),
          Text(mission.subtitle, style: const TextStyle(color: hifiMuted)),
          const Divider(height: 34, color: hifiGoldDark),
          _MapVictoryConditions(mission: mission),
          const SizedBox(height: 8),
          _DetailRow(
            icon: Icons.groups_2,
            text: Localizations.localeOf(context).languageCode == 'zh'
                ? '$playerPieces 枚棋子的编排阵型'
                : '$playerPieces-piece authored formation',
          ),
          _DetailRow(
            icon: Icons.landscape,
            text: battlefieldDefinitions[mission.battlefieldId]!.name,
          ),
          _DetailRow(
            icon: Icons.person_add_alt_1,
            text: Localizations.localeOf(context).languageCode == 'zh'
                ? '$recruitedCount 名持续登场的剧情角色'
                : '$recruitedCount persistent story characters',
          ),
          const Spacer(),
          if (completed)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                localizedDisplayCase(context, 'Completed · Replay available'),
                style: const TextStyle(
                  color: Color(0xFF7EDAA9),
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              key: const ValueKey('story-start-mission'),
              onPressed: unlocked ? onStart : null,
              icon: Icon(unlocked ? Icons.play_arrow : Icons.lock),
              label: Text(
                unlocked
                    ? completed
                          ? localizedUiCopy(context, 'Replay Mission')
                          : localizedUiCopy(context, 'Begin Mission')
                    : localizedUiCopy(context, 'Mission Locked'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: hifiGold, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(text, style: const TextStyle(color: hifiMuted)),
          ),
        ],
      ),
    );
  }
}

class _MapVictoryConditions extends StatelessWidget {
  const _MapVictoryConditions({required this.mission});

  final CampaignMissionDefinition mission;

  @override
  Widget build(BuildContext context) {
    final alternate = mission.alternateVictoryCondition;
    return Semantics(
      label:
          '${appLocalizationsOf(context).storyVictoryConditions}。${mission.victoryConditionsInline}',
      child: Container(
        key: const ValueKey('story-map-victory-conditions'),
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: hifiGold.withValues(alpha: .08),
          border: Border.all(color: hifiGold.withValues(alpha: .65)),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.flag_circle, color: hifiGold, size: 21),
                const SizedBox(width: 9),
                Text(
                  localizedDisplayCase(context, 'Victory Conditions'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            _VictoryConditionLine(
              label: alternate == null
                  ? localizedDisplayCase(context, 'Win By')
                  : localizedDisplayCase(context, 'Primary'),
              text: mission.primaryVictoryCondition,
            ),
            if (alternate != null) ...[
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Center(
                  child: Text(
                    Localizations.localeOf(context).languageCode == 'zh'
                        ? '— 或 —'
                        : '— OR —',
                    style: const TextStyle(
                      color: hifiGold,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    ),
                  ),
                ),
              ),
              _VictoryConditionLine(
                label: localizedDisplayCase(context, 'Alternate'),
                text: alternate,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _VictoryConditionLine extends StatelessWidget {
  const _VictoryConditionLine({required this.label, required this.text});

  final String label;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: hifiMuted,
            fontSize: 10,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.1,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _DialogueFrame extends StatelessWidget {
  const _DialogueFrame({
    required this.characterName,
    required this.text,
    required this.canSkip,
    required this.onSkip,
    required this.onBacklog,
  });

  final String characterName;
  final String text;
  final bool canSkip;
  final VoidCallback onSkip;
  final VoidCallback onBacklog;

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(38, 54, 38, 24),
          decoration: BoxDecoration(
            color: const Color(0xF5F0E6CC),
            border: Border.all(color: const Color(0xFF9B6A22), width: 3),
            borderRadius: BorderRadius.circular(12),
            boxShadow: const [BoxShadow(color: Colors.black, blurRadius: 22)],
          ),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  text,
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF241B11),
                    fontFamily: 'Cormorant Garamond',
                    fontSize: 27,
                    fontWeight: FontWeight.w700,
                    height: 1.18,
                  ),
                ),
              ),
              const SizedBox(width: 18),
              const Icon(Icons.keyboard_arrow_down, color: Color(0xFF8C5E1C)),
            ],
          ),
        ),
        Positioned(
          left: 28,
          top: -15,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xFF513714),
              border: Border.all(color: hifiGold),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              characterName,
              style: const TextStyle(
                color: Colors.white,
                fontFamily: 'Cinzel',
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
        Positioned(
          right: 18,
          top: 10,
          child: Row(
            children: [
              TextButton(
                onPressed: onBacklog,
                child: Text('${localizedUiCopy(context, 'Backlog')} [Esc]'),
              ),
              if (canSkip)
                TextButton(
                  onPressed: onSkip,
                  child: Text(localizedUiCopy(context, 'Skip Seen')),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _DialogueBacklog extends StatelessWidget {
  const _DialogueBacklog({
    required this.lines,
    required this.campaign,
    required this.onClose,
  });

  final List<CampaignDialogueLine> lines;
  final CampaignDefinition campaign;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: const Color(0xF20A0E12),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(230, 70, 230, 70),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      localizedDisplayCase(context, 'Dialogue Backlog'),
                      style: const TextStyle(
                        color: hifiGold,
                        fontFamily: 'Cinzel',
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  IconButton(
                    key: const ValueKey('story-backlog-close'),
                    onPressed: onClose,
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                ],
              ),
              const Divider(color: hifiGoldDark),
              Expanded(
                child: ListView.separated(
                  itemCount: lines.length,
                  separatorBuilder: (_, _) =>
                      const Divider(color: Color(0xFF30363B)),
                  itemBuilder: (context, index) {
                    final line = lines[index];
                    final name = campaign
                        .characterById(line.speakerId)
                        .displayName;
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: '$name  ',
                              style: const TextStyle(
                                color: hifiGold,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            TextSpan(
                              text: line.text,
                              style: const TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              Text(
                localizedUiCopy(context, 'Press Esc to return'),
                style: const TextStyle(color: hifiMuted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ObjectiveBanner extends StatelessWidget {
  const _ObjectiveBanner({required this.mission});

  final CampaignMissionDefinition mission;

  @override
  Widget build(BuildContext context) {
    return Container(
      key: const ValueKey('story-objective-banner'),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xEE10151A),
        border: Border.all(color: hifiGoldDark),
        borderRadius: BorderRadius.circular(7),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.flag_circle, color: hifiGold, size: 20),
          const SizedBox(width: 9),
          Flexible(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '${mission.id.toUpperCase()} · ${localizedDisplayCase(context, 'Victory Conditions')}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: hifiGold,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  mission.victoryConditionsInline,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .25,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _VictoryConditionsBanner extends StatelessWidget {
  const _VictoryConditionsBanner({required this.mission, super.key});

  final CampaignMissionDefinition mission;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label:
          '${appLocalizationsOf(context).storyVictoryConditions}。${mission.victoryConditionsInline}',
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
        decoration: BoxDecoration(
          color: const Color(0xF20B1014),
          border: Border.all(color: hifiGold, width: 1.5),
          borderRadius: BorderRadius.circular(8),
          boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 14)],
        ),
        child: Row(
          children: [
            const Icon(Icons.flag_circle, color: hifiGold, size: 24),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    localizedDisplayCase(context, 'Victory Conditions'),
                    style: const TextStyle(
                      color: hifiGold,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.25,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    mission.victoryConditionsInline,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StoryMissionTag extends StatelessWidget {
  const _StoryMissionTag({required this.mission});

  final CampaignMissionDefinition mission;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xD90B1014),
        border: Border.all(color: hifiGoldDark),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Text(
        '${mission.id.toUpperCase()} · ${mission.title}',
        style: const TextStyle(
          color: hifiGold,
          fontFamily: 'Cinzel',
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _StoryLoadError extends StatelessWidget {
  const _StoryLoadError({
    required this.message,
    required this.onRetry,
    required this.onBack,
  });

  final String message;
  final VoidCallback onRetry;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xFF080B0E),
      child: Center(
        child: SizedBox(
          width: 680,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.error_outline,
                color: Colors.redAccent,
                size: 52,
              ),
              const SizedBox(height: 16),
              Text(
                localizedUiCopy(context, 'Story Campaign could not load'),
                style: const TextStyle(color: Colors.white, fontSize: 26),
              ),
              const SizedBox(height: 12),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: hifiMuted),
              ),
              const SizedBox(height: 22),
              Wrap(
                spacing: 12,
                children: [
                  FilledButton(
                    onPressed: onRetry,
                    child: Text(localizedUiCopy(context, 'Retry')),
                  ),
                  TextButton(
                    onPressed: onBack,
                    child: Text(localizedUiCopy(context, 'Back')),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

String _missionStateLabel(
  BuildContext context, {
  required bool completed,
  required bool unlocked,
}) {
  if (Localizations.localeOf(context).languageCode == 'zh') {
    return completed
        ? '已完成'
        : unlocked
        ? '已解锁'
        : '未解锁';
  }
  return completed
      ? 'completed'
      : unlocked
      ? 'unlocked'
      : 'locked';
}
