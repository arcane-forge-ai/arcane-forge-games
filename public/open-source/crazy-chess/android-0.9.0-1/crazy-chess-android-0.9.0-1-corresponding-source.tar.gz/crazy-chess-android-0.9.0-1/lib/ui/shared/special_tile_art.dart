import 'package:flutter/material.dart';

import '../../battlefield/battlefield_models.dart';

const String _specialTileAssetRoot =
    'assets/runtime/battlefields/special_tiles';

String specialTileAssetPath(SpecialTileType type) {
  return switch (type) {
    SpecialTileType.knightShrine => '$_specialTileAssetRoot/knight_shrine.webp',
    SpecialTileType.treasureChest =>
      '$_specialTileAssetRoot/treasure_chest.webp',
    SpecialTileType.diamondRing => '$_specialTileAssetRoot/diamond_ring.webp',
    SpecialTileType.visibleTrap => '$_specialTileAssetRoot/visible_trap.webp',
    SpecialTileType.mystery => '$_specialTileAssetRoot/mystery.webp',
  };
}

Color specialTileAccent(SpecialTileType type) {
  return switch (type) {
    SpecialTileType.knightShrine => const Color(0xFF9FEA87),
    SpecialTileType.treasureChest => const Color(0xFFFFC85C),
    SpecialTileType.diamondRing => const Color(0xFF8DEBFF),
    SpecialTileType.visibleTrap => const Color(0xFFFF625B),
    SpecialTileType.mystery => const Color(0xFFD39BFF),
  };
}

Color specialTileDeepColor(SpecialTileType type) {
  return switch (type) {
    SpecialTileType.knightShrine => const Color(0xFF173C2B),
    SpecialTileType.treasureChest => const Color(0xFF4C2511),
    SpecialTileType.diamondRing => const Color(0xFF123B4B),
    SpecialTileType.visibleTrap => const Color(0xFF451516),
    SpecialTileType.mystery => const Color(0xFF2B1743),
  };
}

SpecialTileType? specialTileTypeForEvent(BattlefieldEventType type) {
  return switch (type) {
    BattlefieldEventType.knightPromotion ||
    BattlefieldEventType.kingGuarded => SpecialTileType.knightShrine,
    BattlefieldEventType.treasureFound ||
    BattlefieldEventType.mysteryTreasure => SpecialTileType.treasureChest,
    BattlefieldEventType.diamondRingFound => SpecialTileType.diamondRing,
    BattlefieldEventType.trapTriggered => SpecialTileType.visibleTrap,
    BattlefieldEventType.mysteryTrap => SpecialTileType.mystery,
    BattlefieldEventType.tilesSpawned => null,
  };
}

class SpecialTileArt extends StatelessWidget {
  const SpecialTileArt({
    required this.type,
    required this.size,
    this.scale = 1.18,
    this.opacity = 1,
    this.semanticLabel,
    this.artKey,
    super.key,
  });

  final SpecialTileType type;
  final double size;
  final double scale;
  final double opacity;
  final String? semanticLabel;
  final Key? artKey;

  @override
  Widget build(BuildContext context) {
    final image = Opacity(
      opacity: opacity,
      child: ClipRect(
        child: Transform.scale(
          scale: scale,
          child: Image.asset(
            specialTileAssetPath(type),
            key: artKey,
            fit: BoxFit.contain,
            filterQuality: FilterQuality.high,
            excludeFromSemantics: semanticLabel == null,
            semanticLabel: semanticLabel,
          ),
        ),
      ),
    );
    return SizedBox(width: size, height: size, child: image);
  }
}
