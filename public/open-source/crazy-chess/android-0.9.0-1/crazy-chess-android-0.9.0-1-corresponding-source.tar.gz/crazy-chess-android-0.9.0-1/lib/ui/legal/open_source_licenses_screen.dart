import 'package:flutter/material.dart';

import '../menu/hifi_menu_widgets.dart';

const crazyChessAndroidSourceSnapshotUrl =
    'https://games.arcaneforge.ai/open-source/crazy-chess/'
    'android-0.9.0-1/';
const crazyChessAndroidSourceSnapshot = 'android-0.9.0-1';

class OpenSourceLicensesScreen extends StatelessWidget {
  const OpenSourceLicensesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SelectionArea(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Open Source Licenses',
              style: TextStyle(
                color: hifiInk,
                fontFamily: 'Georgia',
                fontSize: 38,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Crazy Chess includes open-source software. These notices are '
              'available offline; source links can be copied for later use.',
              style: TextStyle(color: hifiMuted, height: 1.4),
            ),
            const SizedBox(height: 22),
            const _LicenseSection(
              title: 'Stockfish 18',
              children: [
                Text(
                  'Crazy Chess Android uses Stockfish 18 as an in-process '
                  'native FFI chess engine.',
                ),
                SizedBox(height: 10),
                Text(
                  'License: GNU General Public License v3.0 (GPL-3.0-only).',
                ),
                Text(
                  'No warranty: Stockfish is provided without warranty, '
                  'including without the implied warranty of merchantability '
                  'or fitness for a particular purpose.',
                ),
                SelectableText(
                  'Full license: https://www.gnu.org/licenses/gpl-3.0.html',
                ),
                Text('Upstream tag: sf_18'),
                Text('Upstream commit: cb3d4ee'),
                Text('Mobile wrapper: stockfish 1.8.1+crazychess.1'),
                Text(
                  'The vendored wrapper is modified to remove build-time '
                  'downloads, require prepared NNUE files, use the current '
                  'Android toolchain, and expose initialization/disposal.',
                ),
              ],
            ),
            const SizedBox(height: 14),
            const _LicenseSection(
              title: 'NNUE evaluation networks',
              children: [
                Text(
                  'Stockfish NNUE network files are distributed with their '
                  'upstream Stockfish attribution and CC0 dedication. Their '
                  'SHA-256 values are pinned in the corresponding source.',
                ),
                SizedBox(height: 10),
                Text('Main network: nn-c288c895ea92.nnue'),
                SelectableText(
                  'SHA-256: c288c895ea924429ea9092e3f36b2b3c1f00f2a3a4c759ff7e57e79e3b43e4a7',
                ),
                Text('Small network: nn-37f18f62d772.nnue'),
                SelectableText(
                  'SHA-256: 37f18f62d772f3107e1d6aaca3898c130c3c86f2ab63e6555fbbca20635a899d',
                ),
              ],
            ),
            const SizedBox(height: 14),
            const _LicenseSection(
              title: 'Corresponding source',
              children: [
                Text('Source snapshot: Crazy Chess Android 0.9.0+1'),
                Text('Release identifier: $crazyChessAndroidSourceSnapshot'),
                SizedBox(height: 6),
                SelectableText(crazyChessAndroidSourceSnapshotUrl),
                SizedBox(height: 10),
                Text(
                  'This versioned public source snapshot must be published '
                  'before external tester distribution. It includes the '
                  'mobile wrapper, native build files, license text, and '
                  'pinned NNUE metadata.',
                ),
                SizedBox(height: 10),
                SelectableText(
                  'Upstream source: '
                  'https://github.com/official-stockfish/Stockfish/archive/refs/tags/sf_18.tar.gz',
                ),
                SelectableText(
                  'GPL text: https://www.gnu.org/licenses/gpl-3.0.html',
                ),
              ],
            ),
            const SizedBox(height: 22),
            HifiPrimaryButton(
              key: ValueKey('open-source-all-licenses'),
              label: 'View all third-party licenses',
              icon: Icons.menu_book,
              onPressed: () => showLicensePage(
                context: context,
                applicationName: 'Crazy Chess',
                applicationVersion: '0.9.0+1',
              ),
              variant: HifiButtonVariant.dark,
            ),
          ],
        ),
      ),
    );
  }
}

class _LicenseSection extends StatelessWidget {
  const _LicenseSection({required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: hifiPanelSoft,
        border: Border.all(color: hifiGoldDark),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: DefaultTextStyle(
          style: const TextStyle(color: hifiInk, height: 1.4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: hifiGold,
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                ),
              ),
              const SizedBox(height: 10),
              ...children,
            ],
          ),
        ),
      ),
    );
  }
}
