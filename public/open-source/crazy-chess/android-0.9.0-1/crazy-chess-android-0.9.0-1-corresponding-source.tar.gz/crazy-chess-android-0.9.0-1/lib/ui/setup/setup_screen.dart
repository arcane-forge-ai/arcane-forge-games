import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../game/game_controller.dart';
import 'country_picker.dart';
import 'setup_footer.dart';

class SetupScreen extends StatelessWidget {
  const SetupScreen({required this.controller, super.key});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1d2125), Color(0xFF292018), Color(0xFF17191d)],
        ),
      ),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1180),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.asset(
                        'assets/runtime/ui/identity/shared_court_portrait.webp',
                        width: 132,
                        height: 132,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(width: 22),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Crazy Chess',
                            style: TextStyle(
                              fontSize: 42,
                              fontWeight: FontWeight.w800,
                              height: 1,
                            ),
                          ),
                          SizedBox(height: 12),
                          Text(
                            'Hotseat chess with gold, a traveling merchant, country powers, hidden betrayal resolve, contracts, and redeployed defectors.',
                            style: TextStyle(
                              fontSize: 16,
                              color: Color(0xFFc8c2b7),
                              height: 1.35,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final twoColumns = constraints.maxWidth > 860;
                      final white = CountryPicker(
                        title: 'White Court',
                        selectedId: controller.setupWhiteCountryId,
                        onSelected: (id) =>
                            controller.setSetupCountry(PieceColor.white, id),
                      );
                      final black = CountryPicker(
                        title: 'Black Court',
                        selectedId: controller.setupBlackCountryId,
                        onSelected: (id) =>
                            controller.setSetupCountry(PieceColor.black, id),
                      );
                      if (twoColumns) {
                        return Row(
                          children: [
                            Expanded(child: white),
                            const SizedBox(width: 18),
                            Expanded(child: black),
                          ],
                        );
                      }
                      return ListView(
                        children: [white, const SizedBox(height: 18), black],
                      );
                    },
                  ),
                ),
                const SizedBox(height: 18),
                SetupFooter(controller: controller),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
