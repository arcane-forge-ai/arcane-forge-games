import 'package:flutter/material.dart';

import '../../domain/countries.dart';

/// Renders production emblems when available and an honest code-native
/// monogram for countries whose final identity art has not been authored yet.
class CountryCrest extends StatelessWidget {
  const CountryCrest({required this.country, this.size = 48, super.key});

  final CountryConfig country;
  final double size;

  @override
  Widget build(BuildContext context) {
    if (!country.temporaryIdentity) {
      return Image.asset(
        country.asset,
        key: ValueKey('country-crest-${country.id}'),
        width: size,
        height: size,
        fit: BoxFit.contain,
        semanticLabel: '${country.name} crest',
      );
    }
    return Semantics(
      image: true,
      label: '${country.name} temporary monogram crest',
      child: SizedBox.square(
        key: ValueKey('country-crest-${country.id}-temporary'),
        dimension: size,
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [country.secondaryColor, country.color],
            ),
            borderRadius: BorderRadius.circular(size * .22),
            border: Border.all(
              color: country.secondaryColor.withValues(alpha: .9),
              width: mathMax(1.0, size * .045),
            ),
            boxShadow: [
              BoxShadow(
                color: country.color.withValues(alpha: .45),
                blurRadius: size * .18,
              ),
            ],
          ),
          child: Center(
            child: Text(
              country.monogram,
              style: TextStyle(
                color: const Color(0xFF081014),
                fontFamily: 'Cinzel',
                fontSize: size * .28,
                fontWeight: FontWeight.w900,
                letterSpacing: -.5,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

double mathMax(double a, double b) => a > b ? a : b;
