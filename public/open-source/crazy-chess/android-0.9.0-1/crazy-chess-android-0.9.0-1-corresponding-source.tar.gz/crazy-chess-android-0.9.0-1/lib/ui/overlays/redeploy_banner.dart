import 'package:flutter/material.dart';

import '../../game/game_controller.dart';
import '../../l10n/ui_copy.dart';

class RedeployBanner extends StatelessWidget {
  const RedeployBanner({required this.controller, super.key});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 18,
      right: 18,
      bottom: 18,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xEE102b2b),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xFF7ce9d9)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Text(
            localizedUiCopy(
              context,
              'Redeploy: choose a highlighted square in your own half. The piece cannot return to its original square or give immediate check.',
            ),
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
      ),
    );
  }
}
