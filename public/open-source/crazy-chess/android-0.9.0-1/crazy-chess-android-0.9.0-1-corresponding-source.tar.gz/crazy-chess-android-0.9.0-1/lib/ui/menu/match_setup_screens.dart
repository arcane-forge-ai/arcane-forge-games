import 'package:flutter/material.dart';

import '../../battlefield/battlefield_models.dart';
import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../game/game_controller.dart';
import '../../l10n/runtime_game_locale.dart';
import '../../l10n/ui_copy.dart';
import '../shared/formatters.dart';
import '../shared/country_crest.dart';
import '../shared/country_ability_copy.dart';
import 'country_representative_art.dart';
import 'hifi_menu_widgets.dart';
import 'reference_layout.dart';

const _matchSettingsAssetRoot = '$runtimeAssetRoot/ui/match_settings';
const _countrySelectAssetRoot = '$runtimeAssetRoot/ui/country_select';
const _s04SheetRoot = _matchSettingsAssetRoot;
const _s05CropRoot = _countrySelectAssetRoot;

class MatchSettingsScreen extends StatelessWidget {
  const MatchSettingsScreen({
    required this.controller,
    this.aiAvailable = false,
    required this.onBack,
    required this.onContinue,
    super.key,
  });

  final GameController controller;
  final bool aiAvailable;
  final VoidCallback onBack;
  final VoidCallback onContinue;

  static const settingsBounds = Rect.fromLTWH(292, 108, 900, 650);
  static const explanationBounds = Rect.fromLTWH(1212, 82, 420, 718);
  static const continueBounds = Rect.fromLTWH(566, 807, 522, 104);

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    const rowBounds = [
      Rect.fromLTWH(320, 148, 842, 76),
      Rect.fromLTWH(320, 228, 842, 76),
      Rect.fromLTWH(320, 308, 842, 76),
      Rect.fromLTWH(320, 388, 842, 76),
      Rect.fromLTWH(320, 468, 842, 76),
      Rect.fromLTWH(320, 548, 842, 76),
      Rect.fromLTWH(320, 628, 842, 76),
    ];
    return HifiScaffold(
      backdropAsset: '$_matchSettingsAssetRoot/s04_match_settings_bg.webp',
      backdropOpacity: 1,
      showDefaultScrims: false,
      child: Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xB5090C0F),
                  Color(0x25090C0F),
                  Color(0xC9080B0D),
                ],
              ),
            ),
          ),
          ReferenceAction(
            key: const ValueKey('s04-back'),
            sourceBounds: const Rect.fromLTWH(12, 15, 172, 58),
            semanticLabel: localizedUiCopy(context, 'Back to mode select'),
            onPressed: onBack,
            child: Image.asset(
              '$_s04SheetRoot/back_button.webp',
              fit: BoxFit.fill,
              excludeFromSemantics: true,
            ),
          ),
          ReferencePositioned(
            sourceBounds: Rect.fromLTWH(198, 12, 510, 72),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                localizedDisplayCase(context, 'Create Match'),
                key: ValueKey('s04-title'),
                style: TextStyle(
                  color: hifiInk,
                  fontFamily: 'Cinzel',
                  fontSize: 39,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2.2,
                  shadows: [Shadow(color: Colors.black, blurRadius: 12)],
                ),
              ),
            ),
          ),
          ReferencePositioned(
            sourceBounds: const Rect.fromLTWH(14, 108, 250, 650),
            child: _MatchBanner(controller: controller),
          ),
          ReferencePositioned(
            sourceBounds: settingsBounds,
            child: HifiPanel(
              padding: EdgeInsets.zero,
              color: const Color(0xE80D151A),
              child: const SizedBox.expand(),
            ),
          ),
          ReferencePositioned(
            sourceBounds: rowBounds[0],
            child: _ReferenceSettingRow(
              iconAsset: '$_s04SheetRoot/category_match_type_selected.webp',
              title: 'Match Type',
              subtitle: 'Choose your opponent',
              values: const ['Local', 'AI', 'Custom'],
              selectedValue:
                  controller.setupOpponentMode == OpponentMode.stockfish
                  ? 'AI'
                  : 'Local',
              lockedValues: aiAvailable
                  ? const {'Custom'}
                  : const {'AI', 'Custom'},
              semanticPrefix: 's04-match',
              onValueChanged: (value) {
                controller.setOpponentMode(
                  value == 'AI' ? OpponentMode.stockfish : OpponentMode.local,
                );
              },
            ),
          ),
          ReferencePositioned(
            sourceBounds: rowBounds[1],
            child: const _ReferenceSettingRow(
              iconAsset: '$_s04SheetRoot/category_timer_default.webp',
              title: 'Timer',
              subtitle: 'Turn time limit',
              values: ['Off', 'Relaxed', 'Standard', 'Blitz'],
              selectedValue: 'Off',
              semanticPrefix: 's04-timer',
            ),
          ),
          ReferencePositioned(
            sourceBounds: rowBounds[2],
            child: _ReferenceMerchantSpeedRow(controller: controller),
          ),
          ReferencePositioned(
            sourceBounds: rowBounds[3],
            child: _ReferenceStartingGoldRow(controller: controller),
          ),
          ReferencePositioned(
            sourceBounds: rowBounds[4],
            child: _ReferenceMerchantPayoutRow(controller: controller),
          ),
          ReferencePositioned(
            sourceBounds: rowBounds[5],
            child: const _ReferenceSettingRow(
              iconAsset: '$_s04SheetRoot/category_board_skin_default.webp',
              title: 'Board Skin',
              subtitle: 'Battlefield presentation',
              values: ['Neutral', 'Country Theme'],
              selectedValue: 'Neutral',
              semanticPrefix: 's04-board',
            ),
          ),
          ReferencePositioned(
            sourceBounds: rowBounds[6],
            child: const _ReferenceSettingRow(
              iconAsset: '$_s04SheetRoot/category_personality_set_default.webp',
              title: 'Personality Set',
              subtitle: 'Court behavior profile',
              values: ['Starter'],
              selectedValue: 'Starter',
              semanticPrefix: 's04-personality',
            ),
          ),
          ReferencePositioned(
            sourceBounds: explanationBounds,
            child: _MatchExplanationPanel(
              opponentMode: controller.setupOpponentMode,
            ),
          ),
          ReferencePositioned(
            sourceBounds: const Rect.fromLTWH(14, 832, 250, 65),
            child: HifiPrimaryButton(
              key: const ValueKey('s04-load-preset'),
              label: localizedUiCopy(context, 'Load Preset'),
              icon: Icons.lock_outline,
              onPressed: null,
              variant: HifiButtonVariant.dark,
            ),
          ),
          ReferencePositioned(
            sourceBounds: continueBounds,
            child: HifiPrimaryButton(
              key: const ValueKey('s04-continue'),
              label: l10n.commonContinue,
              icon: Icons.arrow_forward,
              large: true,
              variant: HifiButtonVariant.emerald,
              onPressed: onContinue,
            ),
          ),
          ReferenceAction(
            key: const ValueKey('s04-reset'),
            sourceBounds: const Rect.fromLTWH(1374, 834, 274, 62),
            semanticLabel: localizedUiCopy(context, 'Reset to Default'),
            onPressed: () {
              controller.setOpponentMode(OpponentMode.local);
              controller.setMerchantSpeed(4);
              controller.setStartingGold(10);
              controller.setMerchantPayout(8);
              controller.setBattlefield(BattlefieldId.classic);
            },
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xD90A1116),
                border: Border.all(color: hifiGoldDark),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    '$_s04SheetRoot/reset_to_default.webp',
                    width: 38,
                    height: 38,
                    fit: BoxFit.contain,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    localizedDisplayCase(context, 'Reset to Default'),
                    style: const TextStyle(
                      color: hifiInk,
                      fontFamily: 'Cinzel',
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MatchBanner extends StatelessWidget {
  const _MatchBanner({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final isAi = controller.setupOpponentMode == OpponentMode.stockfish;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xB20A1116),
        border: Border.all(color: hifiGoldDark, width: 1.5),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 18)],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 25, 18, 20),
        child: Column(
          children: [
            Icon(
              isAi ? Icons.memory : Icons.workspace_premium,
              color: hifiGold,
              size: 70,
            ),
            const SizedBox(height: 16),
            Text(
              localizedDisplayCase(context, isAi ? 'AI Duel' : 'Local Duel'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: hifiInk,
                fontFamily: 'Cinzel',
                fontSize: 23,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              localizedUiCopy(
                context,
                isAi
                    ? 'Human White versus Stockfish Black.\nYour mechanisms remain fully armed.'
                    : 'Two courts. One board.\nEvery contract changes the war.',
              ),
              textAlign: TextAlign.center,
              style: const TextStyle(color: hifiMuted, height: 1.35),
            ),
            const Spacer(),
            const Divider(color: hifiGoldDark),
            const SizedBox(height: 10),
            Text(
              '${localizedDisplayCase(context, 'Gold')} ${controller.setupStartingGold}'
              '  ·  ${localizedDisplayCase(context, 'Payout')} ${controller.setupMerchantPayout}'
              '  ·  ${localizedDisplayCase(context, 'Speed')} ${controller.setupMerchantSpeed}',
              style: const TextStyle(
                color: hifiGold,
                fontWeight: FontWeight.w800,
                letterSpacing: .8,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReferenceSettingRow extends StatelessWidget {
  const _ReferenceSettingRow({
    required this.iconAsset,
    required this.title,
    required this.subtitle,
    required this.values,
    required this.selectedValue,
    required this.semanticPrefix,
    this.lockedValues = const {},
    this.onValueChanged,
  });

  final String iconAsset;
  final String title;
  final String subtitle;
  final List<String> values;
  final String selectedValue;
  final String semanticPrefix;
  final Set<String> lockedValues;
  final ValueChanged<String>? onValueChanged;

  @override
  Widget build(BuildContext context) {
    final localizedTitle = localizedUiCopy(context, title);
    final localizedSubtitle = localizedUiCopy(context, subtitle);
    return HifiAssetSurface(
      asset: '$runtimeAssetRoot/ui/common/setting_row_9slice.webp',
      centerSlice: const Rect.fromLTRB(160, 64, 1376, 128),
      imageScale: 2,
      padding: const EdgeInsets.fromLTRB(18, 5, 18, 5),
      child: Row(
        children: [
          Image.asset(iconAsset, width: 48, height: 48, fit: BoxFit.contain),
          const SizedBox(width: 12),
          SizedBox(
            width: 190,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  localizedTitle,
                  style: const TextStyle(
                    color: Color(0xFF2B1C0F),
                    fontFamily: 'Cinzel',
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    height: 1,
                  ),
                ),
                Text(
                  localizedSubtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF695033),
                    fontSize: 10,
                    height: 1.1,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Row(
              children: [
                for (final value in values)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(right: 7),
                      child: _ReferenceSegment(
                        key: ValueKey('$semanticPrefix-${_keyPart(value)}'),
                        label: localizedUiCopy(context, value),
                        selected: selectedValue == value,
                        locked: lockedValues.contains(value),
                        onPressed:
                            lockedValues.contains(value) ||
                                onValueChanged == null
                            ? null
                            : () => onValueChanged!(value),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ReferenceMerchantSpeedRow extends StatelessWidget {
  const _ReferenceMerchantSpeedRow({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return HifiAssetSurface(
      asset: '$runtimeAssetRoot/ui/common/setting_row_9slice.webp',
      centerSlice: const Rect.fromLTRB(160, 64, 1376, 128),
      imageScale: 2,
      padding: const EdgeInsets.fromLTRB(18, 5, 18, 5),
      child: Row(
        children: [
          Image.asset(
            '$_s04SheetRoot/category_merchant_speed_default.webp',
            width: 48,
            height: 48,
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 190,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  localizedUiCopy(context, 'Merchant Speed'),
                  style: const TextStyle(
                    color: Color(0xFF2B1C0F),
                    fontFamily: 'Cinzel',
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    height: 1,
                  ),
                ),
                Text(
                  localizedUiCopy(context, 'Trade route arrival'),
                  style: const TextStyle(
                    color: Color(0xFF695033),
                    fontSize: 10,
                    height: 1.1,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          for (final speed in const [1, 2, 4, 6])
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(right: 7),
                child: _ReferenceSegment(
                  key: ValueKey('s04-merchant-$speed'),
                  label: '$speed',
                  subtitle: localizedUiCopy(context, switch (speed) {
                    1 => 'Slow',
                    2 => 'Normal',
                    4 => 'Fast',
                    _ => 'Very Fast',
                  }),
                  selected: controller.setupMerchantSpeed == speed,
                  onPressed: () => controller.setMerchantSpeed(speed),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ReferenceStartingGoldRow extends StatelessWidget {
  const _ReferenceStartingGoldRow({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return _ReferenceSettingRow(
      iconAsset: '$_s04SheetRoot/category_economy_default.webp',
      title: 'Starting Gold',
      subtitle: 'Base treasury before country modifiers',
      values: const ['6', '10', '14'],
      selectedValue: '${controller.setupStartingGold}',
      semanticPrefix: 's04-starting-gold',
      onValueChanged: (value) => controller.setStartingGold(int.parse(value)),
    );
  }
}

class _ReferenceMerchantPayoutRow extends StatelessWidget {
  const _ReferenceMerchantPayoutRow({required this.controller});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return _ReferenceSettingRow(
      iconAsset: '$_s04SheetRoot/category_chance_visibility_default.webp',
      title: 'Merchant Payout',
      subtitle: 'Base gold paid at each court',
      values: const ['4', '8', '12'],
      selectedValue: '${controller.setupMerchantPayout}',
      semanticPrefix: 's04-merchant-payout',
      onValueChanged: (value) => controller.setMerchantPayout(int.parse(value)),
    );
  }
}

class _ReferenceSegment extends StatelessWidget {
  const _ReferenceSegment({
    required this.label,
    required this.selected,
    this.subtitle,
    this.locked = false,
    this.onPressed,
    super.key,
  });

  final String label;
  final String? subtitle;
  final bool selected;
  final bool locked;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    return Semantics(
      button: true,
      selected: selected,
      enabled: !locked && onPressed != null,
      label: locked ? '$label · ${l10n.commonLocked}' : label,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: locked ? null : onPressed,
          child: HifiAssetSurface(
            asset: selected
                ? '$runtimeAssetRoot/ui/common/segmented_selected_9slice.webp'
                : '$runtimeAssetRoot/ui/common/segmented_default_9slice.webp',
            centerSlice: const Rect.fromLTRB(96, 64, 416, 128),
            imageScale: 4,
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (locked) ...[
                      const Icon(
                        Icons.lock,
                        size: 11,
                        color: Color(0xFF6B5232),
                      ),
                      const SizedBox(width: 3),
                    ],
                    Flexible(
                      child: Text(
                        label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: selected ? hifiInk : const Color(0xFF2B1C0F),
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
                if (subtitle != null)
                  Text(
                    subtitle!,
                    maxLines: 1,
                    style: TextStyle(
                      color: selected ? hifiMuted : const Color(0xFF6B5232),
                      fontSize: 9,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MatchExplanationPanel extends StatelessWidget {
  const _MatchExplanationPanel({required this.opponentMode});

  final OpponentMode opponentMode;

  @override
  Widget build(BuildContext context) {
    return HifiPanel(
      padding: const EdgeInsets.fromLTRB(82, 72, 48, 30),
      backgroundAsset:
          '$runtimeAssetRoot/ui/common/panel_parchment_9slice.webp',
      backgroundCenterSlice: const Rect.fromLTWH(128, 128, 768, 768),
      child: DefaultTextStyle(
        style: const TextStyle(
          color: Color(0xFF2B1C0F),
          fontFamily: 'Cormorant Garamond',
          fontWeight: FontWeight.w600,
          height: 1.28,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              localizedDisplayCase(context, 'Match Settings'),
              style: const TextStyle(
                fontFamily: 'Cinzel',
                fontSize: 18,
                fontWeight: FontWeight.w900,
                height: 1,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              localizedUiCopy(
                context,
                opponentMode == OpponentMode.stockfish
                    ? 'Shape the pace before challenging the local Stockfish court.'
                    : 'Shape the pace of your local duel before the courts take the field.',
              ),
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 14),
            _ParchmentRule(
              title: localizedDisplayCase(
                context,
                opponentMode == OpponentMode.stockfish
                    ? 'AI Duel'
                    : 'Local Duel',
              ),
              text: localizedUiCopy(
                context,
                opponentMode == OpponentMode.stockfish
                    ? 'You are White. Stockfish is Black and makes normal legal moves.'
                    : 'Two players share this device.',
              ),
            ),
            _ParchmentRule(
              title: localizedDisplayCase(context, 'Merchant Speed'),
              text: localizedUiCopy(
                context,
                'Four squares per turn is the default campaign pace.',
              ),
            ),
            _ParchmentRule(
              title: localizedDisplayCase(context, 'Hidden Chance'),
              text: localizedUiCopy(
                context,
                'Purchase odds remain secret until a court reveals them.',
              ),
            ),
            _ParchmentRule(
              title: localizedDisplayCase(context, 'Neutral Board'),
              text: localizedUiCopy(
                context,
                'The battlefield stays visually impartial.',
              ),
            ),
            const SizedBox(height: 8),
            const Divider(color: Color(0xFF805716)),
            Text(
              localizedUiCopy(
                context,
                'Locked settings remain visible as future match options.',
              ),
              style: const TextStyle(fontSize: 13, fontStyle: FontStyle.italic),
            ),
          ],
        ),
      ),
    );
  }
}

class _ParchmentRule extends StatelessWidget {
  const _ParchmentRule({required this.title, required this.text});
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Color(0xFF654516),
              fontFamily: 'Cinzel',
              fontSize: 12,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
          const SizedBox(height: 3),
          Text(text, style: const TextStyle(fontSize: 14, height: 1.1)),
        ],
      ),
    );
  }
}

class CountrySelectScreen extends StatelessWidget {
  const CountrySelectScreen({
    required this.controller,
    required this.selectedSide,
    required this.onSelectedSideChanged,
    required this.onBack,
    required this.onDetails,
    required this.onStart,
    super.key,
  });

  final GameController controller;
  final PieceColor selectedSide;
  final ValueChanged<PieceColor> onSelectedSideChanged;
  final VoidCallback onBack;
  final VoidCallback onDetails;
  final VoidCallback onStart;

  static const portraitBounds = Rect.fromLTWH(0, 96, 425, 690);
  static const gridBounds = Rect.fromLTWH(426, 145, 790, 624);
  static const traitBounds = Rect.fromLTWH(1220, 145, 425, 624);

  @override
  Widget build(BuildContext context) {
    final selectedId = selectedSide == PieceColor.white
        ? controller.setupWhiteCountryId
        : controller.setupBlackCountryId;
    final selected = countries[selectedId]!;
    final otherId = selectedSide == PieceColor.white
        ? controller.setupBlackCountryId
        : controller.setupWhiteCountryId;

    return HifiScaffold(
      backdropAsset: '$_countrySelectAssetRoot/s05_country_hall_bg.webp',
      backdropOpacity: 1,
      showDefaultScrims: false,
      child: Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xA60A0D11),
                  Color(0x180A0D11),
                  Color(0xD00A0D11),
                ],
              ),
            ),
          ),
          ReferenceAction(
            key: const ValueKey('s05-back'),
            sourceBounds: const Rect.fromLTWH(12, 15, 172, 58),
            semanticLabel: 'Back to match settings',
            onPressed: onBack,
            child: Image.asset(
              '$_s04SheetRoot/back_button.webp',
              fit: BoxFit.fill,
            ),
          ),
          const ReferencePositioned(
            sourceBounds: Rect.fromLTWH(198, 11, 410, 78),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'CRAZY CHESS',
                style: TextStyle(
                  color: hifiInk,
                  fontFamily: 'Cinzel',
                  fontSize: 34,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.6,
                ),
              ),
            ),
          ),
          ReferencePositioned(
            sourceBounds: const Rect.fromLTWH(565, 24, 610, 85),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  localizedDisplayCase(context, 'Choose Your Country'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontFamily: 'Cinzel',
                    fontSize: 23,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                    height: 1,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  localizedUiCopy(context, 'Select a realm for each court'),
                  style: const TextStyle(
                    color: hifiMuted,
                    fontSize: 13,
                    height: 1,
                  ),
                ),
              ],
            ),
          ),
          ReferencePositioned(
            sourceBounds: const Rect.fromLTWH(1430, 20, 205, 66),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: const [
                _BareUtility(icon: Icons.menu_book, label: 'Rules'),
                SizedBox(width: 18),
                _BareUtility(icon: Icons.settings, label: 'Settings'),
              ],
            ),
          ),
          ReferencePositioned(
            sourceBounds: portraitBounds,
            child: _CountryPortraitStage(
              country: selected,
              selectedSide: selectedSide,
              white: countries[controller.setupWhiteCountryId]!,
              black: countries[controller.setupBlackCountryId]!,
              onSelectedSideChanged: onSelectedSideChanged,
            ),
          ),
          ReferencePositioned(
            sourceBounds: gridBounds,
            child: _CountryGrid(
              selectedId: selectedId,
              otherId: otherId,
              onCountrySelected: (id) =>
                  controller.setSetupCountry(selectedSide, id),
            ),
          ),
          ReferencePositioned(
            sourceBounds: traitBounds,
            child: _ReferenceCountryTraitPanel(country: selected),
          ),
          ReferencePositioned(
            sourceBounds: const Rect.fromLTWH(430, 794, 250, 72),
            child: const HifiPrimaryButton(
              key: ValueKey('s05-compare'),
              label: 'Compare',
              icon: Icons.lock_outline,
              onPressed: null,
              variant: HifiButtonVariant.dark,
            ),
          ),
          ReferencePositioned(
            sourceBounds: const Rect.fromLTWH(705, 794, 250, 72),
            child: HifiPrimaryButton(
              key: const ValueKey('s05-details'),
              label: 'Details',
              icon: Icons.article_outlined,
              onPressed: onDetails,
              variant: HifiButtonVariant.emerald,
            ),
          ),
          ReferencePositioned(
            sourceBounds: const Rect.fromLTWH(980, 785, 400, 91),
            child: HifiPrimaryButton(
              key: const ValueKey('s05-confirm'),
              label: 'Confirm',
              icon: Icons.arrow_forward,
              large: true,
              variant: HifiButtonVariant.gold,
              backgroundAsset:
                  '$runtimeAssetRoot/ui/common/button_start_match_9slice.webp',
              backgroundCenterSlice: const Rect.fromLTRB(160, 80, 864, 176),
              backgroundImageScale: 4,
              onPressed: onStart,
            ),
          ),
        ],
      ),
    );
  }
}

class _CountryPortraitStage extends StatelessWidget {
  const _CountryPortraitStage({
    required this.country,
    required this.selectedSide,
    required this.white,
    required this.black,
    required this.onSelectedSideChanged,
  });

  final CountryConfig country;
  final PieceColor selectedSide;
  final CountryConfig white;
  final CountryConfig black;
  final ValueChanged<PieceColor> onSelectedSideChanged;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 128),
          child: CountryRepresentativeArt(
            country: country,
            fit: country.id == 'spy' ? BoxFit.cover : BoxFit.contain,
          ),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [0, .62, 1],
              colors: [Color(0x00000000), Color(0x00000000), Color(0xE6090C0F)],
            ),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: 172,
            margin: const EdgeInsets.fromLTRB(18, 0, 16, 7),
            padding: const EdgeInsets.fromLTRB(16, 13, 16, 13),
            decoration: BoxDecoration(
              color: const Color(0xE50C1419),
              border: Border.all(color: country.secondaryColor, width: 1.5),
              boxShadow: const [
                BoxShadow(color: Colors.black87, blurRadius: 14),
              ],
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    CountryCrest(country: country, size: 50),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            country.name,
                            maxLines: 1,
                            style: const TextStyle(
                              color: hifiInk,
                              fontFamily: 'Cinzel',
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          Text(
                            _countryTagline(country),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: country.secondaryColor,
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _CourtChoice(
                        key: const ValueKey('s05-side-white'),
                        label: localizedUiCopy(context, 'White Court'),
                        country: white,
                        selected: selectedSide == PieceColor.white,
                        onPressed: () =>
                            onSelectedSideChanged(PieceColor.white),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _CourtChoice(
                        key: const ValueKey('s05-side-black'),
                        label: localizedUiCopy(context, 'Black Court'),
                        country: black,
                        selected: selectedSide == PieceColor.black,
                        onPressed: () =>
                            onSelectedSideChanged(PieceColor.black),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _CourtChoice extends StatelessWidget {
  const _CourtChoice({
    required this.label,
    required this.country,
    required this.selected,
    required this.onPressed,
    super.key,
  });

  final String label;
  final CountryConfig country;
  final bool selected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selected,
      label: '$label ${country.name}',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          child: Ink(
            height: 54,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              color: selected
                  ? country.color.withValues(alpha: .55)
                  : const Color(0xC90A0F13),
              border: Border.all(
                color: selected ? country.secondaryColor : hifiGoldDark,
                width: selected ? 2 : 1,
              ),
            ),
            child: Row(
              children: [
                CountryCrest(country: country, size: 29),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    label,
                    maxLines: 2,
                    style: const TextStyle(
                      color: hifiInk,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CountryGrid extends StatelessWidget {
  const _CountryGrid({
    required this.selectedId,
    required this.otherId,
    required this.onCountrySelected,
  });

  final String selectedId;
  final String otherId;
  final ValueChanged<String> onCountrySelected;

  @override
  Widget build(BuildContext context) {
    final live = selectableCountries.toList(growable: false);
    final cards = <Widget>[
      for (final country in live)
        _ReferenceCountryCard(
          key: ValueKey('s05-country-${country.id}'),
          country: country,
          selected: country.id == selectedId,
          otherSelected: country.id == otherId,
          cropAsset: '$_s05CropRoot/${country.id}_card.webp',
          onPressed: () => onCountrySelected(country.id),
        ),
      for (var index = 1; index <= 6; index++)
        _FutureRealmCard(key: ValueKey('s05-future-$index'), index: index),
    ];
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0x9C080C10),
        border: Border.all(color: hifiGoldDark.withValues(alpha: .75)),
      ),
      child: ClipRect(
        child: SingleChildScrollView(
          key: const ValueKey('s05-country-scroll'),
          padding: const EdgeInsets.all(9),
          child: GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 20,
            childAspectRatio: 176 / 250,
            children: cards,
          ),
        ),
      ),
    );
  }
}

class _ReferenceCountryCard extends StatelessWidget {
  const _ReferenceCountryCard({
    required this.country,
    required this.selected,
    required this.otherSelected,
    required this.cropAsset,
    required this.onPressed,
    super.key,
  });

  final CountryConfig country;
  final bool selected;
  final bool otherSelected;
  final String cropAsset;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selected,
      label: country.name,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          child: AspectRatio(
            aspectRatio: 176 / 250,
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (!country.temporaryIdentity)
                  Image.asset(cropAsset, fit: BoxFit.fill)
                else ...[
                  DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [country.color, const Color(0xFF080C10)],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 18, 16, 42),
                    child: CountryRepresentativeArt(country: country),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      color: const Color(0xD8080C10),
                      child: Text(
                        Localizations.localeOf(context).languageCode == 'zh'
                            ? country.name
                            : '${country.shortName.toUpperCase()} · TEMP IDENTITY',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: hifiGold,
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                ],
                if (!selected) const ColoredBox(color: Color(0x30000000)),
                DecoratedBox(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: selected
                          ? country.secondaryColor
                          : Colors.transparent,
                      width: selected ? 4 : 0,
                    ),
                  ),
                ),
                if (otherSelected)
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      margin: const EdgeInsets.all(7),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 3,
                      ),
                      color: const Color(0xD80B1014),
                      child: Text(
                        localizedDisplayCase(context, 'Other Court'),
                        style: const TextStyle(
                          color: hifiGold,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FutureRealmCard extends StatelessWidget {
  const _FutureRealmCard({required this.index, super.key});
  final int index;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      enabled: false,
      label: Localizations.localeOf(context).languageCode == 'zh'
          ? '未来阵营 $index，尚未解锁'
          : 'Future Realm $index locked',
      child: AspectRatio(
        aspectRatio: 176 / 250,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: const Color(0xE311171C),
            border: Border.all(color: hifiGoldDark),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF182027), Color(0xFF090D11)],
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.shield_outlined, color: hifiGoldDark, size: 55),
              const SizedBox(height: 12),
              const Icon(Icons.lock, color: hifiGold, size: 22),
              const SizedBox(height: 8),
              Text(
                localizedDisplayCase(context, 'Future Realm'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: hifiMuted,
                  fontFamily: 'Cinzel',
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ReferenceCountryTraitPanel extends StatelessWidget {
  const _ReferenceCountryTraitPanel({required this.country});
  final CountryConfig country;

  @override
  Widget build(BuildContext context) {
    return HifiPanel(
      padding: const EdgeInsets.fromLTRB(82, 66, 48, 22),
      backgroundAsset:
          '$runtimeAssetRoot/ui/common/panel_trait_parchment_9slice.webp',
      backgroundCenterSlice: const Rect.fromLTRB(112, 112, 656, 912),
      child: DefaultTextStyle(
        style: const TextStyle(
          color: Color(0xFF281A0E),
          fontFamily: 'Cormorant Garamond',
          fontWeight: FontWeight.w600,
          height: 1.2,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CountryCrest(country: country, size: 48),
                const SizedBox(width: 12),
                Expanded(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text(
                      localizedDisplayCase(context, country.name),
                      maxLines: 1,
                      style: const TextStyle(
                        fontFamily: 'Cinzel',
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        height: 1,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 9),
            Text(
              country.fantasy,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                height: 1.1,
              ),
            ),
            const SizedBox(height: 12),
            _TraitLine(
              label: 'Economy',
              value: Localizations.localeOf(context).languageCode == 'zh'
                  ? '初始金币 ${signed(country.startingGoldModifier)} · 商人收益 ${signed(country.merchantPayoutModifier)}'
                  : 'Starting Gold ${signed(country.startingGoldModifier)} · Merchant ${signed(country.merchantPayoutModifier)}',
            ),
            _TraitLine(label: 'Loyalty', value: country.loyaltySummary),
            _TraitLine(
              label: 'Purchase',
              value: Localizations.localeOf(context).languageCode == 'zh'
                  ? '报价 ${signed(country.offenseModifier)}'
                  : 'Offer ${signed(country.offenseModifier)}',
            ),
            _TraitLine(
              label: 'Signature Trait',
              value: countrySignatureTrait(country),
            ),
            const SizedBox(height: 4),
            const Divider(color: Color(0xFF805716)),
            Text(
              localizedDisplayCase(context, 'Representative Pieces'),
              style: const TextStyle(
                fontFamily: 'Cinzel',
                color: Color(0xFF654516),
                fontSize: 11,
                fontWeight: FontWeight.w900,
                height: 1,
              ),
            ),
            const SizedBox(height: 6),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(
                  Icons.workspace_premium,
                  color: Color(0xFF654516),
                  size: 22,
                ),
                Icon(Icons.auto_awesome, color: Color(0xFF654516), size: 22),
                Icon(Icons.castle, color: Color(0xFF654516), size: 22),
                Icon(Icons.church, color: Color(0xFF654516), size: 22),
                Icon(Icons.pets, color: Color(0xFF654516), size: 22),
                Icon(Icons.circle, color: Color(0xFF654516), size: 22),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TraitLine extends StatelessWidget {
  const _TraitLine({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            localizedDisplayCase(context, label),
            style: const TextStyle(
              color: Color(0xFF654516),
              fontFamily: 'Cinzel',
              fontSize: 11,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              height: 1.05,
            ),
          ),
        ],
      ),
    );
  }
}

class _BareUtility extends StatelessWidget {
  const _BareUtility({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      enabled: false,
      label: Localizations.localeOf(context).languageCode == 'zh'
          ? '${localizedUiCopy(context, label)}不可用'
          : '$label unavailable',
      child: Icon(
        icon,
        color: hifiGold,
        size: 32,
        shadows: const [Shadow(color: Colors.black, blurRadius: 8)],
      ),
    );
  }
}

String _keyPart(String value) =>
    value.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '-');

String _countryTagline(CountryConfig country) {
  return switch (country.id) {
    'mercantile' =>
      RuntimeGameLocale.isSimplifiedChinese ? '财富就是筹码' : 'WEALTH IS LEVERAGE',
    'iron' =>
      RuntimeGameLocale.isSimplifiedChinese ? '誓言比黄金长久' : 'OATHS OUTLAST GOLD',
    'horse' =>
      RuntimeGameLocale.isSimplifiedChinese
          ? '铁骑冲破战线'
          : 'CAVALRY BREAKS THE LINE',
    'spy' =>
      RuntimeGameLocale.isSimplifiedChinese
          ? '情报于无声处制胜'
          : 'KNOWLEDGE WINS IN SILENCE',
    'corsair' =>
      RuntimeGameLocale.isSimplifiedChinese ? '每次吃子都有回报' : 'EVERY CAPTURE PAYS',
    'sunlit' =>
      RuntimeGameLocale.isSimplifiedChinese
          ? '主教揭示真相'
          : 'BISHOPS REVEAL THE TRUTH',
    _ =>
      RuntimeGameLocale.isSimplifiedChinese
          ? '无被动特性的王庭'
          : 'A COURT WITHOUT A PASSIVE',
  };
}
