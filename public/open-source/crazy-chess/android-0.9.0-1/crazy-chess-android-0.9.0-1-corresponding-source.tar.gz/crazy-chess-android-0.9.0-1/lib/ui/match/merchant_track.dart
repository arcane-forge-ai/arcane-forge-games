import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../game/game_controller.dart';
import '../../l10n/ui_copy.dart';
import '../menu/hifi_menu_widgets.dart';
import '../shared/reference_first_match_art.dart';

class MerchantTrack extends StatelessWidget {
  const MerchantTrack({required this.controller, super.key});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final percent = controller.merchantPosition / 16;
    return HifiAssetSurface(
      key: const ValueKey('s20-vertical-merchant-route'),
      asset: matchHudMerchantRailAsset,
      centerSlice: matchMerchantRailCenterSlice,
      padding: const EdgeInsets.fromLTRB(10, 24, 10, 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            localizedDisplayCase(context, 'Black'),
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFFC8C2B7),
              fontSize: 10,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                const markerSize = 48.0;
                final merchantTop =
                    (constraints.maxHeight - markerSize) * (1 - percent);
                return Stack(
                  alignment: Alignment.topCenter,
                  children: [
                    Positioned(
                      top: 4,
                      bottom: 4,
                      width: 10,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: const Color(0xFF373027),
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(color: const Color(0xFF8F7137)),
                        ),
                      ),
                    ),
                    Positioned(
                      top: merchantTop,
                      child: AnimatedContainer(
                        key: const ValueKey('s20-merchant-caravan'),
                        duration: const Duration(milliseconds: 180),
                        width: markerSize,
                        height: markerSize,
                        decoration: BoxDecoration(
                          color: const Color(0xCC0D1718),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: const Color(0xFFE8C46C),
                            width: 2,
                          ),
                          boxShadow: const [
                            BoxShadow(color: Color(0x88765118), blurRadius: 12),
                          ],
                        ),
                        alignment: Alignment.center,
                        child: Padding(
                          padding: const EdgeInsets.all(3),
                          child: SizedBox.expand(
                            child: Transform.rotate(
                              angle: controller.merchantDirection >= 0
                                  ? 0
                                  : math.pi,
                              child: Image.asset(
                                matchMerchantCaravanAsset,
                                fit: BoxFit.cover,
                                alignment: const Alignment(0, .65),
                                filterQuality: FilterQuality.high,
                                excludeFromSemantics: true,
                                errorBuilder: (context, error, stackTrace) =>
                                    const Icon(
                                      Icons.local_shipping,
                                      size: 22,
                                      color: Color(0xFFE8C46C),
                                    ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          Text(
            localizedDisplayCase(context, 'White'),
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFFC8C2B7),
              fontSize: 10,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            '${controller.merchantPosition}/16',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFFE6C66F),
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          Text(
            Localizations.localeOf(context).languageCode == 'zh'
                ? '速度 ${controller.merchantSpeed}'
                : 'SPD ${controller.merchantSpeed}',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFFB8AA8E),
              fontSize: 9,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
