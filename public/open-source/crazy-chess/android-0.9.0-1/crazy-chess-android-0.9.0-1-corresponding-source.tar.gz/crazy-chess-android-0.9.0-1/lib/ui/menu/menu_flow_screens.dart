import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../ai/chess_engine.dart';
import '../../domain/chess_models.dart';
import '../../l10n/ui_copy.dart';
import 'hifi_menu_widgets.dart';
import 'reference_layout.dart';
import 's01_gold_motes.dart';

const _referenceAssetRoot = '$runtimeAssetRoot/scenes/setup';

enum HifiMenuStage {
  title,
  lobby,
  modeSelect,
  matchSettings,
  battlefieldSelect,
  countrySelect,
  countryDetail,
  versusLoading,
  courtDorm,
  collectionMatrix,
  pieceProfile,
  loadout,
  postgameSummary,
  tutorialRules,
  settings,
  lastPieceCountrySelect,
  lastPieceLevelLadder,
  lastPieceRun,
  lastPieceResults,
  storyMap,
  storyDialogue,
  storyBattle,
  storyResults,
  livingHub,
  livingPrologue,
  livingBriefing,
  livingBattle,
  livingResults,
}

class TitleScreen extends StatelessWidget {
  const TitleScreen({
    required this.backgroundAsset,
    required this.onStart,
    required this.onSettings,
    required this.onExit,
    super.key,
  });

  final String backgroundAsset;
  final VoidCallback onStart;
  final VoidCallback onSettings;
  final VoidCallback onExit;

  @override
  Widget build(BuildContext context) {
    return HifiScaffold(
      backdropAsset: backgroundAsset,
      backdropOpacity: 1,
      showDefaultScrims: false,
      child: Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                stops: [0, 0.34, 0.62, 1],
                colors: [
                  Color(0xE6090D10),
                  Color(0xB80B1014),
                  Color(0x240B1014),
                  Color(0x26000000),
                ],
              ),
            ),
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0x33000000),
                  Color(0x00000000),
                  Color(0xA6000000),
                ],
              ),
            ),
          ),
          const S01GoldMotes(),
          Padding(
            padding: const EdgeInsets.fromLTRB(58, 34, 58, 34),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: Text(
                    'v1.0.0',
                    style: TextStyle(
                      color: hifiMuted.withValues(alpha: 0.9),
                      fontSize: 14,
                    ),
                  ),
                ),
                const Spacer(),
                SizedBox(
                  width: 720,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Image.asset(
                        'assets/runtime/ui/title/ui_crest_product_large.webp',
                        width: 102,
                        height: 102,
                        filterQuality: FilterQuality.high,
                        semanticLabel: 'Crazy Chess product crest',
                      ),
                      const SizedBox(height: 12),
                      Semantics(
                        image: true,
                        label: 'Crazy Chess',
                        child: SizedBox(
                          width: 690,
                          height: 148,
                          child: Image.asset(
                            'assets/runtime/ui/title/ui_logo_crazy_chess_full.webp',
                            fit: BoxFit.contain,
                            alignment: Alignment.centerLeft,
                            filterQuality: FilterQuality.high,
                            excludeFromSemantics: true,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        localizedUiCopy(context, 'Plan. Trade. Dominate.'),
                        style: const TextStyle(
                          color: hifiGold,
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          height: 1,
                          letterSpacing: 1.4,
                        ),
                      ),
                      const SizedBox(height: 34),
                      SizedBox(
                        width: 440,
                        child: HifiPrimaryButton(
                          label: 'Press Start',
                          icon: Icons.play_arrow,
                          large: true,
                          backgroundAsset:
                              'assets/runtime/ui/title/ui_button_press_start_9slice.webp',
                          backgroundCenterSlice: const Rect.fromLTWH(
                            120,
                            25,
                            240,
                            50,
                          ),
                          onPressed: onStart,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        localizedUiCopy(context, 'Click to begin'),
                        style: const TextStyle(
                          color: hifiGold,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: 430,
                  child: HifiPanel(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
                    backgroundAsset:
                        'assets/runtime/ui/title/ui_card_latest_news_9slice.webp',
                    backgroundCenterSlice: const Rect.fromLTWH(
                      100,
                      30,
                      312,
                      90,
                    ),
                    child: Row(
                      children: [
                        Image.asset(
                          'assets/runtime/ui/title/ui_crest_product_large.webp',
                          width: 68,
                          height: 68,
                          filterQuality: FilterQuality.high,
                          excludeFromSemantics: true,
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                localizedUiCopy(context, 'Latest News'),
                                style: const TextStyle(
                                  color: hifiGold,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 7),
                              Text(
                                localizedUiCopy(
                                  context,
                                  'Season 02: Crown Campaign. New contracts await your strategy.',
                                ),
                                style: const TextStyle(
                                  color: hifiMuted,
                                  fontSize: 13,
                                  height: 1.25,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            right: 58,
            bottom: 34,
            child: Row(
              children: [
                HifiIconSquare(
                  key: const ValueKey('title-settings'),
                  icon: Icons.settings,
                  label: 'Settings',
                  tooltip: 'Settings',
                  frameAsset:
                      'assets/runtime/ui/title/ui_icon_square_9slice.webp',
                  onPressed: onSettings,
                ),
                const SizedBox(width: 18),
                HifiIconSquare(
                  key: const ValueKey('title-exit'),
                  icon: Icons.exit_to_app,
                  label: 'Exit',
                  tooltip: 'Exit Game',
                  frameAsset:
                      'assets/runtime/ui/title/ui_icon_square_9slice.webp',
                  onPressed: onExit,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class LobbyScreen extends StatelessWidget {
  const LobbyScreen({
    required this.onPlay,
    required this.onCollection,
    required this.onCourt,
    required this.onLoadout,
    required this.onRecords,
    required this.onRules,
    required this.onSettings,
    super.key,
  });

  final VoidCallback onPlay;
  final VoidCallback onCollection;
  final VoidCallback onCourt;
  final VoidCallback onLoadout;
  final VoidCallback onRecords;
  final VoidCallback onRules;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    return HifiScaffold(
      backdropAsset: '$_referenceAssetRoot/s02_lobby_court_bg.webp',
      backdropOpacity: 1,
      showDefaultScrims: false,
      child: Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          const ReferencePositioned(
            sourceBounds: Rect.fromLTWH(0, 0, 1672, 94),
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xC9000000),
                    Color(0x83000000),
                    Color(0x00000000),
                  ],
                ),
              ),
            ),
          ),
          ReferencePositioned(
            sourceBounds: const Rect.fromLTWH(8, 80, 744, 742),
            child: Image.asset(
              '$runtimeAssetRoot/pieces/countries/mercantile/representative_full_neutral.webp',
              fit: BoxFit.contain,
              alignment: Alignment.bottomCenter,
              filterQuality: FilterQuality.high,
              excludeFromSemantics: true,
            ),
          ),
          const ReferencePositioned(
            sourceBounds: Rect.fromLTWH(12, 18, 350, 196),
            child: _LobbyIdentityCluster(),
          ),
          const ReferenceLayer(
            asset: '$_referenceAssetRoot/s02_campaign.webp',
            sourceBounds: Rect.fromLTWH(13, 688, 426, 114),
          ),
          ReferenceAction(
            key: const ValueKey('s02-play'),
            sourceBounds: const Rect.fromLTWH(924, 116, 642, 197),
            semanticLabel: localizedUiCopy(context, 'Play'),
            onPressed: onPlay,
            child: Image.asset(
              '$_referenceAssetRoot/s02_play_plaque.webp',
              fit: BoxFit.fill,
              excludeFromSemantics: true,
            ),
          ),
          ReferenceAction(
            key: const ValueKey('s02-collection'),
            sourceBounds: const Rect.fromLTWH(925, 336, 638, 195),
            semanticLabel: localizedUiCopy(context, 'Collection'),
            onPressed: onCollection,
            child: Image.asset(
              '$_referenceAssetRoot/s02_collection_plaque.webp',
              fit: BoxFit.fill,
              excludeFromSemantics: true,
            ),
          ),
          ReferenceAction(
            key: const ValueKey('s02-court'),
            sourceBounds: const Rect.fromLTWH(925, 549, 638, 178),
            semanticLabel: localizedUiCopy(context, 'Court'),
            onPressed: onCourt,
            child: Image.asset(
              '$_referenceAssetRoot/s02_court_plaque.webp',
              fit: BoxFit.fill,
              excludeFromSemantics: true,
            ),
          ),
          const ReferenceLayer(
            asset: '$_referenceAssetRoot/s02_currency_rail.webp',
            sourceBounds: Rect.fromLTWH(827, 16, 547, 59),
          ),
          const ReferenceLayer(
            asset: '$_referenceAssetRoot/s02_utility_icons.webp',
            sourceBounds: Rect.fromLTWH(1389, 19, 259, 57),
          ),
          ReferenceAction(
            key: const ValueKey('s02-utility-mail'),
            sourceBounds: const Rect.fromLTWH(1389, 12, 58, 70),
            semanticLabel: localizedUiCopy(context, 'Messages unavailable'),
            child: const SizedBox.expand(),
          ),
          ReferenceAction(
            key: const ValueKey('s02-utility-friends'),
            sourceBounds: const Rect.fromLTWH(1456, 12, 58, 70),
            semanticLabel: localizedUiCopy(context, 'Friends unavailable'),
            child: const SizedBox.expand(),
          ),
          ReferenceAction(
            key: const ValueKey('s02-utility-missions'),
            sourceBounds: const Rect.fromLTWH(1524, 12, 58, 70),
            semanticLabel: localizedUiCopy(
              context,
              'Daily missions unavailable',
            ),
            child: const SizedBox.expand(),
          ),
          ReferenceAction(
            key: const ValueKey('s02-settings'),
            sourceBounds: const Rect.fromLTWH(1590, 12, 70, 70),
            semanticLabel: l10n.settingsTitle,
            onPressed: onSettings,
            child: const SizedBox.expand(),
          ),
          const ReferenceLayer(
            asset: '$_referenceAssetRoot/s02_bottom_nav.webp',
            sourceBounds: Rect.fromLTWH(6, 817, 1659, 118),
          ),
          ReferenceAction(
            key: const ValueKey('s02-nav-lobby'),
            sourceBounds: const Rect.fromLTWH(8, 817, 320, 118),
            semanticLabel: localizedUiCopy(context, 'Lobby active'),
            child: const SizedBox.expand(),
          ),
          ReferenceAction(
            key: const ValueKey('s02-nav-country'),
            sourceBounds: const Rect.fromLTWH(330, 817, 246, 118),
            semanticLabel: l10n.navCountries,
            onPressed: onCourt,
            child: const SizedBox.expand(),
          ),
          ReferenceAction(
            key: const ValueKey('s02-nav-roster'),
            sourceBounds: const Rect.fromLTWH(578, 817, 250, 118),
            semanticLabel: l10n.navRoster,
            onPressed: onCollection,
            child: const SizedBox.expand(),
          ),
          ReferenceAction(
            key: const ValueKey('s02-nav-loadout'),
            sourceBounds: const Rect.fromLTWH(830, 817, 252, 118),
            semanticLabel: l10n.navLoadout,
            onPressed: onLoadout,
            child: const SizedBox.expand(),
          ),
          ReferenceAction(
            key: const ValueKey('s02-nav-records'),
            sourceBounds: const Rect.fromLTWH(1084, 817, 244, 118),
            semanticLabel: l10n.navRecords,
            onPressed: onRecords,
            child: const SizedBox.expand(),
          ),
          ReferenceAction(
            key: const ValueKey('s02-nav-rules'),
            sourceBounds: const Rect.fromLTWH(1330, 817, 334, 118),
            semanticLabel: l10n.navRules,
            onPressed: onRules,
            child: const SizedBox.expand(),
          ),
        ],
      ),
    );
  }
}

class ModeSelectScreen extends StatelessWidget {
  const ModeSelectScreen({
    required this.selectedMode,
    required this.aiAvailable,
    required this.engineStatus,
    required this.onModeChanged,
    required this.onBack,
    required this.onContinue,
    this.livingCampaignStatus,
    super.key,
  });

  final PlayMode selectedMode;
  final bool aiAvailable;
  final EngineStatus engineStatus;
  final ValueChanged<PlayMode> onModeChanged;
  final VoidCallback onBack;
  final VoidCallback onContinue;
  final String? livingCampaignStatus;

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    final selectedModeLabel = switch (selectedMode) {
      PlayMode.localDuel => l10n.modeLocalDuel,
      PlayMode.aiDuel => l10n.modeAiDuel,
      PlayMode.storyCampaign => l10n.modeStoryCampaign,
      PlayMode.lastPieceStanding => l10n.modeLastPiece,
      PlayMode.livingCampaign => l10n.modeLivingCampaign,
    };
    final confirmLabel = Localizations.localeOf(context).languageCode == 'zh'
        ? '${l10n.commonConfirm}$selectedModeLabel'
        : '${l10n.commonConfirm} $selectedModeLabel';
    return HifiScaffold(
      backdropAsset: '$_referenceAssetRoot/s02_lobby_court_bg.webp',
      backdropOpacity: .72,
      showDefaultScrims: false,
      child: Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          const ReferencePositioned(
            sourceBounds: Rect.fromLTWH(0, 0, 1672, 96),
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xDE000000),
                    Color(0xA0000000),
                    Color(0x00000000),
                  ],
                ),
              ),
            ),
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0x9B050807),
                  Color(0x84050708),
                  Color(0xAB030505),
                ],
              ),
            ),
          ),
          const ReferencePositioned(
            sourceBounds: Rect.fromLTWH(350, 110, 590, 56),
            child: ColoredBox(color: Color(0x95000000)),
          ),
          const ReferencePositioned(
            sourceBounds: Rect.fromLTWH(420, 842, 740, 76),
            child: ColoredBox(color: Color(0x95000000)),
          ),
          const ReferenceLayer(
            asset: '$_referenceAssetRoot/s03_brand.webp',
            sourceBounds: Rect.fromLTWH(17, 15, 300, 75),
          ),
          const ReferenceLayer(
            asset: '$_referenceAssetRoot/s03_top_rail.webp',
            sourceBounds: Rect.fromLTWH(929, 28, 716, 50),
          ),
          const ReferenceLayer(
            asset: '$_referenceAssetRoot/s03_choose_mode_title.webp',
            sourceBounds: Rect.fromLTWH(394, 121, 500, 34),
          ),
          _SelectableModeReferenceCard(
            key: const ValueKey('s03-local-duel'),
            sourceBounds: const Rect.fromLTWH(119, 165, 516, 361),
            semanticLabel: l10n.modeLocalDuel,
            asset: '$_referenceAssetRoot/s03_local_duel_card.webp',
            selected: selectedMode == PlayMode.localDuel,
            onPressed: () => onModeChanged(PlayMode.localDuel),
          ),
          if (aiAvailable)
            _SelectableModeReferenceCard(
              key: const ValueKey('s03-ai-duel'),
              sourceBounds: const Rect.fromLTWH(678, 165, 492, 361),
              semanticLabel: '${l10n.modeAiDuel} · Stockfish',
              asset: '$_referenceAssetRoot/s03_ai_duel_card.webp',
              selected: selectedMode == PlayMode.aiDuel,
              onPressed: () => onModeChanged(PlayMode.aiDuel),
            )
          else
            _LockedModeReferenceCard(
              key: const ValueKey('s03-ai-duel'),
              sourceBounds: const Rect.fromLTWH(678, 165, 492, 361),
              semanticLabel:
                  '${l10n.modeAiDuel} · ${localizedUiCopy(context, 'Unavailable in this environment')}',
              asset: '$_referenceAssetRoot/s03_ai_duel_card.webp',
              badge: 'UNAVAILABLE',
            ),
          _StoryModeReferenceCard(
            key: const ValueKey('s03-story-campaign'),
            sourceBounds: Rect.fromLTWH(51, 543, 344, 260),
            asset: '$_referenceAssetRoot/s03_custom_rules_card.webp',
            selected: selectedMode == PlayMode.storyCampaign,
            onPressed: () => onModeChanged(PlayMode.storyCampaign),
          ),
          _LastPieceModeReferenceCard(
            key: const ValueKey('s03-last-piece-standing'),
            sourceBounds: Rect.fromLTWH(422, 543, 371, 260),
            asset: 'assets/runtime/modes/last_piece/s03_mode_card.webp',
            selected: selectedMode == PlayMode.lastPieceStanding,
            onPressed: () => onModeChanged(PlayMode.lastPieceStanding),
          ),
          _LivingCampaignModeReferenceCard(
            key: const ValueKey('s03-living-campaign'),
            sourceBounds: const Rect.fromLTWH(810, 543, 388, 260),
            asset: '$_referenceAssetRoot/s03_ranked_online_card.webp',
            selected: selectedMode == PlayMode.livingCampaign,
            onPressed: () => onModeChanged(PlayMode.livingCampaign),
            status: livingCampaignStatus,
          ),
          if (selectedMode == PlayMode.localDuel)
            const ReferenceLayer(
              asset: '$_referenceAssetRoot/s03_local_duel_detail.webp',
              sourceBounds: Rect.fromLTWH(1217, 165, 420, 647),
            )
          else if (selectedMode == PlayMode.aiDuel)
            ReferencePositioned(
              sourceBounds: const Rect.fromLTWH(1217, 165, 420, 647),
              child: _AiDuelDetailPanel(engineStatus: engineStatus),
            )
          else if (selectedMode == PlayMode.lastPieceStanding)
            const ReferencePositioned(
              sourceBounds: Rect.fromLTWH(1217, 165, 420, 647),
              child: _LastPieceDetailPanel(),
            )
          else if (selectedMode == PlayMode.livingCampaign)
            const ReferencePositioned(
              sourceBounds: Rect.fromLTWH(1217, 165, 420, 647),
              child: _LivingCampaignDetailPanel(),
            )
          else
            const ReferencePositioned(
              sourceBounds: Rect.fromLTWH(1217, 165, 420, 647),
              child: _StoryCampaignDetailPanel(),
            ),
          const ReferenceLayer(
            asset: '$_referenceAssetRoot/s03_tip.webp',
            sourceBounds: Rect.fromLTWH(455, 856, 668, 52),
          ),
          ReferenceAction(
            key: const ValueKey('s03-back'),
            sourceBounds: const Rect.fromLTWH(29, 852, 149, 61),
            semanticLabel: l10n.commonBack,
            onPressed: onBack,
            child: Image.asset(
              '$_referenceAssetRoot/s03_back_button.webp',
              fit: BoxFit.fill,
              excludeFromSemantics: true,
            ),
          ),
          ReferenceAction(
            key: const ValueKey('s03-confirm'),
            sourceBounds: const Rect.fromLTWH(1324, 852, 292, 61),
            semanticLabel: confirmLabel,
            onPressed: onContinue,
            child: Image.asset(
              '$_referenceAssetRoot/s03_confirm_button.webp',
              fit: BoxFit.fill,
              excludeFromSemantics: true,
            ),
          ),
          if (selectedMode == PlayMode.aiDuel &&
              engineStatus == EngineStatus.starting)
            const Positioned.fill(
              child: ColoredBox(
                color: Color(0xB8000000),
                child: Center(child: _StockfishLoadingPanel()),
              ),
            ),
        ],
      ),
    );
  }
}

class _LobbyIdentityCluster extends StatelessWidget {
  const _LobbyIdentityCluster();

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 104,
          height: 132,
          child: Image.asset(
            '$runtimeAssetRoot/pieces/countries/mercantile/representative_avatar.webp',
            fit: BoxFit.contain,
            alignment: Alignment.topCenter,
            excludeFromSemantics: true,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  localizedDisplayCase(context, 'Grand Duchy of'),
                  style: const TextStyle(
                    color: Color(0xFFF0D08A),
                    fontFamily: 'Cormorant Garamond',
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    height: .95,
                    shadows: [Shadow(color: Colors.black, blurRadius: 6)],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  localizedDisplayCase(context, 'Aurelia'),
                  style: const TextStyle(
                    color: Color(0xFFE7C06D),
                    fontFamily: 'Cinzel',
                    fontSize: 31,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -.7,
                    height: 1,
                    shadows: [Shadow(color: Colors.black, blurRadius: 7)],
                  ),
                ),
                const SizedBox(height: 4),
                const SizedBox(
                  width: 190,
                  child: Divider(color: Color(0xFFB78D42), height: 1),
                ),
                const SizedBox(height: 7),
                Text(
                  localizedUiCopy(context, 'Player Name'),
                  style: const TextStyle(
                    color: Color(0xFFF1DDAD),
                    fontFamily: 'Cormorant Garamond',
                    fontSize: 21,
                    fontWeight: FontWeight.w700,
                    height: 1,
                    shadows: [Shadow(color: Colors.black, blurRadius: 6)],
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  localizedUiCopy(context, 'Lv. 38  ·  Strategist'),
                  style: const TextStyle(
                    color: Color(0xFFE0B862),
                    fontFamily: 'Cormorant Garamond',
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    height: 1,
                    shadows: [Shadow(color: Colors.black, blurRadius: 6)],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _LockedModeReferenceCard extends StatelessWidget {
  const _LockedModeReferenceCard({
    required this.sourceBounds,
    required this.semanticLabel,
    required this.asset,
    this.badge = 'FUTURE',
    super.key,
  });

  final Rect sourceBounds;
  final String semanticLabel;
  final String asset;
  final String badge;

  @override
  Widget build(BuildContext context) {
    return ReferenceAction(
      sourceBounds: sourceBounds,
      semanticLabel: semanticLabel,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(asset, fit: BoxFit.fill, excludeFromSemantics: true),
          const ColoredBox(color: Color(0x8A000000)),
          Center(
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xDB11110F),
                border: Border.all(color: const Color(0xFFD2A852), width: 1.2),
                borderRadius: BorderRadius.circular(4),
                boxShadow: const [
                  BoxShadow(color: Colors.black, blurRadius: 8),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 7,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.lock, color: Color(0xFFF0C76F), size: 16),
                    const SizedBox(width: 6),
                    Text(
                      localizedDisplayCase(context, badge),
                      style: const TextStyle(
                        color: Color(0xFFF0C76F),
                        fontFamily: 'Cinzel',
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: .7,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StoryModeReferenceCard extends StatelessWidget {
  const _StoryModeReferenceCard({
    required this.sourceBounds,
    required this.asset,
    required this.selected,
    required this.onPressed,
    super.key,
  });

  final Rect sourceBounds;
  final String asset;
  final bool selected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    return ReferenceAction(
      sourceBounds: sourceBounds,
      semanticLabel: l10n.modeStoryCampaign,
      onPressed: onPressed,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(asset, fit: BoxFit.fill, excludeFromSemantics: true),
          const ColoredBox(color: Color(0x8F090B0D)),
          DecoratedBox(
            decoration: BoxDecoration(
              border: Border.all(
                color: selected ? Colors.white : hifiGold,
                width: selected ? 5 : 2,
              ),
              boxShadow: selected
                  ? const [BoxShadow(color: Color(0xAAE6B95E), blurRadius: 20)]
                  : null,
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.auto_stories, color: hifiGold, size: 56),
                const SizedBox(height: 10),
                Text(
                  localizedDisplayCase(context, 'Story Campaign'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Cinzel',
                    fontSize: 23,
                    fontWeight: FontWeight.w900,
                    shadows: [Shadow(color: Colors.black, blurRadius: 8)],
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  localizedDisplayCase(context, '7-Mission Saga'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LivingCampaignModeReferenceCard extends StatelessWidget {
  const _LivingCampaignModeReferenceCard({
    required this.sourceBounds,
    required this.asset,
    required this.selected,
    required this.onPressed,
    this.status,
    super.key,
  });

  final Rect sourceBounds;
  final String asset;
  final bool selected;
  final VoidCallback onPressed;
  final String? status;

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    return ReferenceAction(
      sourceBounds: sourceBounds,
      semanticLabel: l10n.modeLivingCampaign,
      onPressed: onPressed,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(asset, fit: BoxFit.fill, excludeFromSemantics: true),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xA80A1115), Color(0xE30B0809)],
              ),
            ),
          ),
          DecoratedBox(
            decoration: BoxDecoration(
              border: Border.all(
                color: selected ? Colors.white : hifiGold,
                width: selected ? 5 : 2,
              ),
              boxShadow: selected
                  ? const [BoxShadow(color: Color(0xAAE6B95E), blurRadius: 20)]
                  : null,
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.auto_awesome, color: hifiGold, size: 52),
                const SizedBox(height: 8),
                Text(
                  localizedDisplayCase(context, 'Living Campaign'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Cinzel',
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                    shadows: [Shadow(color: Colors.black, blurRadius: 8)],
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  localizedDisplayCase(context, 'AI-Woven · Persistent Canon'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: hifiGold,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.1,
                  ),
                ),
              ],
            ),
          ),
          if (status != null && status != 'IDLE')
            Positioned(
              top: 12,
              right: 12,
              child: Container(
                key: const ValueKey('living-mode-status-badge'),
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xE60A0E12),
                  border: Border.all(
                    color: status == 'NEEDS ATTENTION'
                        ? const Color(0xFFE38B78)
                        : hifiGold,
                  ),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  localizedDisplayCase(context, status!),
                  style: TextStyle(
                    color: status == 'NEEDS ATTENTION'
                        ? const Color(0xFFE38B78)
                        : hifiGold,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .8,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _StoryCampaignDetailPanel extends StatelessWidget {
  const _StoryCampaignDetailPanel();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: const Color(0xE60C1115),
        border: Border.all(color: hifiGoldDark),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.auto_stories, color: hifiGold, size: 48),
          const SizedBox(height: 20),
          Text(
            localizedDisplayCase(context, 'The Crown We Earn'),
            style: const TextStyle(
              color: Colors.white,
              fontFamily: 'Cinzel',
              fontSize: 24,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            localizedUiCopy(
              context,
              'Lead King Rowan through a complete seven-mission medieval fantasy campaign.',
            ),
            style: const TextStyle(color: hifiMuted, height: 1.4),
          ),
          const SizedBox(height: 28),
          _ModeDetailLine(icon: Icons.route, label: 'Linear  ·  7 Missions'),
          _ModeDetailLine(
            icon: Icons.save,
            label: 'Autosave  ·  Between Missions',
          ),
          _ModeDetailLine(
            icon: Icons.psychology,
            label: 'Tile-Aware Campaign AI',
          ),
          _ModeDetailLine(
            icon: Icons.favorite,
            label: 'Captures  ·  No Permadeath',
          ),
          const Spacer(),
          Text(
            localizedUiCopy(
              context,
              'A crown is earned through loyalty, not merely inherited.',
            ),
            style: const TextStyle(
              color: hifiGold,
              fontStyle: FontStyle.italic,
              height: 1.35,
            ),
          ),
        ],
      ),
    );
  }
}

class _LivingCampaignDetailPanel extends StatelessWidget {
  const _LivingCampaignDetailPanel();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: const Color(0xE60C1115),
        border: Border.all(color: hifiGoldDark),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.auto_awesome, color: hifiGold, size: 48),
            const SizedBox(height: 20),
            Text(
              localizedDisplayCase(context, 'The Story Remembers'),
              style: const TextStyle(
                color: Colors.white,
                fontFamily: 'Cinzel',
                fontSize: 23,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              localizedUiCopy(
                context,
                'Begin with one fixed battle. Every later chapter is generated from who survived, who fell, what was learned, and what remains unresolved.',
              ),
              style: const TextStyle(color: hifiMuted, height: 1.4),
            ),
            const SizedBox(height: 28),
            _ModeDetailLine(
              icon: Icons.hub,
              label: 'Two-Stage Story + Mission AI',
            ),
            _ModeDetailLine(
              icon: Icons.history,
              label: 'Complete Structured Canon',
            ),
            _ModeDetailLine(
              icon: Icons.person_off,
              label: 'Verified Permadeath',
            ),
            _ModeDetailLine(icon: Icons.save, label: 'Local Run Archives'),
            const SizedBox(height: 24),
            Text(
              localizedUiCopy(
                context,
                'Requires a locally configured Doubao Ark API key. Generation may take time and never silently falls back to another provider.',
              ),
              style: const TextStyle(
                color: hifiGold,
                fontStyle: FontStyle.italic,
                height: 1.35,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SelectableModeReferenceCard extends StatelessWidget {
  const _SelectableModeReferenceCard({
    required this.sourceBounds,
    required this.semanticLabel,
    required this.asset,
    required this.selected,
    required this.onPressed,
    super.key,
  });

  final Rect sourceBounds;
  final String semanticLabel;
  final String asset;
  final bool selected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return ReferenceAction(
      sourceBounds: sourceBounds,
      semanticLabel: semanticLabel,
      onPressed: onPressed,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(asset, fit: BoxFit.fill, excludeFromSemantics: true),
          if (selected)
            DecoratedBox(
              key: ValueKey('$semanticLabel-selected'),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFFFD77B), width: 5),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xAAE2A93D),
                    blurRadius: 16,
                    spreadRadius: 2,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _LastPieceModeReferenceCard extends StatelessWidget {
  const _LastPieceModeReferenceCard({
    required this.sourceBounds,
    required this.asset,
    required this.selected,
    required this.onPressed,
    super.key,
  });

  final Rect sourceBounds;
  final String asset;
  final bool selected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    return ReferenceAction(
      sourceBounds: sourceBounds,
      semanticLabel: l10n.modeLastPiece,
      onPressed: onPressed,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(asset, fit: BoxFit.cover, excludeFromSemantics: true),
          const ColoredBox(color: Color(0xA006120D)),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Color(0xEF07100B)],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(26, 38, 26, 28),
            child: Column(
              children: [
                const Icon(
                  Icons.workspace_premium,
                  color: Color(0xFFFFD978),
                  size: 58,
                ),
                const Spacer(),
                Text(
                  localizedDisplayCase(context, 'Last Piece Standing'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xFFFFE8AD),
                    fontFamily: 'Cinzel',
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    height: 1.08,
                    letterSpacing: .8,
                    shadows: [Shadow(color: Colors.black, blurRadius: 8)],
                  ),
                ),
                const SizedBox(height: 9),
                Text(
                  localizedDisplayCase(context, 'Endless Survival'),
                  style: const TextStyle(
                    color: Color(0xFF8EE1AF),
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.3,
                  ),
                ),
              ],
            ),
          ),
          if (selected)
            DecoratedBox(
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFFFFD77B), width: 5),
                boxShadow: [
                  BoxShadow(
                    color: Color(0xAAE2A93D),
                    blurRadius: 16,
                    spreadRadius: 2,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _AiDuelDetailPanel extends StatelessWidget {
  const _AiDuelDetailPanel({required this.engineStatus});

  final EngineStatus engineStatus;

  @override
  Widget build(BuildContext context) {
    final statusLabel = switch (engineStatus) {
      EngineStatus.starting => 'Engine Starting',
      EngineStatus.ready => 'Engine Ready',
      EngineStatus.thinking => 'Engine Thinking',
      EngineStatus.failed => 'Engine Needs Retry',
      EngineStatus.unavailable => 'Local Engine',
    };
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xEC0A1014),
        border: Border.all(color: const Color(0xFFCEAA5A), width: 2),
        boxShadow: const [BoxShadow(color: Colors.black87, blurRadius: 18)],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(34, 40, 34, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.memory, color: Color(0xFFF1C86B), size: 72),
            const SizedBox(height: 24),
            Text(
              localizedDisplayCase(context, 'AI Duel'),
              style: const TextStyle(
                color: Color(0xFFF1D89E),
                fontFamily: 'Cinzel',
                fontSize: 29,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.4,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              localizedUiCopy(
                context,
                'You command White and may use every Crazy Chess mechanism. Stockfish commands Black with normal legal chess moves.',
              ),
              style: const TextStyle(
                color: Color(0xFFDBD2C0),
                fontSize: 18,
                height: 1.35,
              ),
            ),
            const SizedBox(height: 26),
            const Divider(color: Color(0xFF8D6B2D)),
            const SizedBox(height: 18),
            const _ModeDetailLine(icon: Icons.person, label: 'Human  ·  White'),
            const _ModeDetailLine(
              icon: Icons.smart_toy,
              label: 'Stockfish 18  ·  Black',
            ),
            _ModeDetailLine(
              icon: Icons.bolt,
              label: kIsWeb
                  ? '500 ms  ·  Web Worker  ·  32 MB'
                  : '500 ms  ·  1 Thread  ·  64 MB',
            ),
            const Spacer(),
            Text(
              localizedDisplayCase(context, statusLabel),
              key: const ValueKey('s03-ai-engine-status'),
              style: const TextStyle(
                color: Color(0xFFF1C86B),
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LastPieceDetailPanel extends StatelessWidget {
  const _LastPieceDetailPanel();

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xF00A120E),
        border: Border.all(color: const Color(0xFFCEAA5A), width: 2),
        boxShadow: const [BoxShadow(color: Colors.black87, blurRadius: 18)],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(28, 26, 28, 22),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(
                Icons.workspace_premium,
                color: Color(0xFFF1C86B),
                size: 54,
              ),
              const SizedBox(height: 14),
              Text(
                localizedDisplayCase(context, 'Last Piece Standing'),
                style: const TextStyle(
                  color: Color(0xFFF1D89E),
                  fontFamily: 'Cinzel',
                  fontSize: 23,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 9),
              Text(
                localizedUiCopy(
                  context,
                  'Command one piece against an endless, uncapped enemy tide. The board never clears; survive, score, transform, and choose when to retire.',
                ),
                style: const TextStyle(
                  color: Color(0xFFDBD2C0),
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              const SizedBox(height: 14),
              const Divider(color: Color(0xFF8D6B2D)),
              const SizedBox(height: 10),
              const _ModeDetailLine(
                icon: Icons.star,
                label: 'Stars  ·  300 / 700 / 1,200',
              ),
              const _ModeDetailLine(
                icon: Icons.add_circle,
                label: 'No Enemy Cap  ·  Seeded Hunts',
              ),
              const _ModeDetailLine(
                icon: Icons.auto_awesome,
                label: 'Score + Transformation Tiles',
              ),
              const _ModeDetailLine(
                icon: Icons.route,
                label: 'Sequential Level Ladder',
              ),
              const SizedBox(height: 5),
              Text(
                localizedDisplayCase(context, '3 Levels at Launch · 50+ Ready'),
                style: const TextStyle(
                  color: Color(0xFF8EE1AF),
                  fontWeight: FontWeight.w900,
                  letterSpacing: .8,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StockfishLoadingPanel extends StatelessWidget {
  const _StockfishLoadingPanel();

  @override
  Widget build(BuildContext context) {
    return Semantics(
      key: const ValueKey('stockfish-loading'),
      label: localizedUiCopy(context, 'Loading Stockfish'),
      liveRegion: true,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xF010171C),
          border: Border.all(color: const Color(0xFFE1BA61), width: 2),
          boxShadow: const [BoxShadow(color: Colors.black, blurRadius: 24)],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 38, vertical: 28),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                width: 28,
                height: 28,
                child: CircularProgressIndicator(
                  color: Color(0xFFE1BA61),
                  strokeWidth: 3,
                ),
              ),
              const SizedBox(width: 18),
              Text(
                '${localizedUiCopy(context, 'Loading Stockfish')}…',
                style: const TextStyle(
                  color: Color(0xFFF1D89E),
                  fontFamily: 'Cinzel',
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeDetailLine extends StatelessWidget {
  const _ModeDetailLine({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFCDA34F), size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              localizedDisplayCase(context, label),
              style: const TextStyle(
                color: Color(0xFFE8DDC6),
                fontSize: 14,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
