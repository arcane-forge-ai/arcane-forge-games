import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../game/game_controller.dart';
import '../../l10n/ui_copy.dart';
import '../menu/hifi_menu_widgets.dart';
import '../shared/formatters.dart';
import '../shared/reference_first_match_art.dart';

class InfoPanel extends StatelessWidget {
  const InfoPanel({required this.controller, super.key});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return HifiAssetSurface(
      key: const ValueKey('s20-event-log-panel'),
      asset: matchHudEventLogAsset,
      centerSlice: matchEventLogCenterSlice,
      padding: const EdgeInsets.fromLTRB(34, 64, 34, 34),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            localizedDisplayCase(context, 'Event Log'),
            style: const TextStyle(
              color: hifiGold,
              fontFamily: 'Cinzel',
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            Localizations.localeOf(context).languageCode == 'zh'
                ? '第 ${controller.turnCount} 回合 · ${colorLabel(controller.turn)}'
                : 'TURN ${controller.turnCount} · ${colorLabel(controller.turn).toUpperCase()}',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: Color(0xFFf1d47f),
            ),
          ),
          const SizedBox(height: 10),
          if (controller.economyEnabled) ...[
            Row(
              children: [
                Expanded(
                  child: _EconomyValue(
                    label: 'WHITE',
                    value: controller.gold[PieceColor.white]!,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _EconomyValue(
                    label: 'BLACK',
                    value: controller.gold[PieceColor.black]!,
                  ),
                ),
              ],
            ),
          ],
          if (controller.activeKingInCheck &&
              controller.phase == GamePhase.playing) ...[
            const SizedBox(height: 8),
            Text(
              localizedUiCopy(
                context,
                'King safety active: purchases disabled until check is answered.',
              ),
              style: const TextStyle(
                color: Color(0xFFffaaa8),
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
          const Divider(height: 24),
          Text(
            localizedDisplayCase(context, 'Court Record'),
            style: const TextStyle(
              color: hifiMuted,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              letterSpacing: .8,
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.separated(
              itemCount: controller.localizedEventLog.length,
              separatorBuilder: (context, index) =>
                  const Divider(height: 12, color: Color(0x223c4450)),
              itemBuilder: (context, index) {
                return Text(
                  controller.localizedEventLog[index],
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFFd4c7b5),
                    height: 1.25,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _EconomyValue extends StatelessWidget {
  const _EconomyValue({required this.label, required this.value});

  final String label;
  final int value;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xB20A1116),
        border: Border.all(color: hifiGoldDark),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
        child: Column(
          children: [
            Text(
              localizedDisplayCase(context, label),
              style: const TextStyle(color: hifiMuted, fontSize: 9),
            ),
            Text(
              Localizations.localeOf(context).languageCode == 'zh'
                  ? '$value 金币'
                  : '$value GOLD',
              style: const TextStyle(
                color: hifiGold,
                fontSize: 13,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
