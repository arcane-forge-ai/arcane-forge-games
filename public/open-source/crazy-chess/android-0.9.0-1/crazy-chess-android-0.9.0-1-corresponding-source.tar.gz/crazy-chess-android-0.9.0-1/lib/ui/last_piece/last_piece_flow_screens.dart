import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../battlefield/battlefield_models.dart';
import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../last_piece/last_piece_models.dart';
import '../../last_piece/last_piece_session_controller.dart';
import '../../l10n/ui_copy.dart';
import '../board/board_presentation_layers.dart';
import '../board/piece_token.dart';
import '../effects/production_board_effects.dart';
import '../menu/country_representative_art.dart';
import '../menu/hifi_menu_widgets.dart';
import '../shared/country_crest.dart';
import '../shared/formatters.dart';
import '../shared/special_tile_art.dart';
import 'last_piece_presentation_coordinator.dart';

const _lastPieceBackdrop =
    'assets/runtime/battlefields/chaos_crucible/background.webp';

class LastPieceCountrySelectScreen extends StatelessWidget {
  const LastPieceCountrySelectScreen({
    required this.controller,
    required this.onBack,
    required this.onContinue,
    super.key,
  });

  final LastPieceSessionController controller;
  final VoidCallback onBack;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    return HifiScaffold(
      backdropAsset: _lastPieceBackdrop,
      backdropOpacity: .46,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(42, 22, 42, 34),
        child: Column(
          children: [
            HifiTopBar(
              screenCode: 'LPS-01',
              title: 'Choose Your Court',
              onBack: onBack,
            ),
            const SizedBox(height: 10),
            HifiSectionTitle(
              'One champion. One court identity.',
              subtitle:
                  'Country changes presentation and Familiarity rewards only. '
                  'Every court receives the same level balance.',
            ),
            const SizedBox(height: 24),
            Expanded(
              child: GridView.count(
                key: const ValueKey('last-piece-country-grid'),
                crossAxisCount: 2,
                childAspectRatio: 2.55,
                mainAxisSpacing: 18,
                crossAxisSpacing: 18,
                children: [
                  for (final country in selectableCountries)
                    _LastPieceCountryCard(
                      country: country,
                      selected: controller.selectedCountryId == country.id,
                      familiarity: controller.familiarityFor(country.id),
                      onPressed: () => controller.selectCountry(country.id),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Align(
              alignment: Alignment.centerRight,
              child: SizedBox(
                width: 360,
                child: HifiPrimaryButton(
                  key: const ValueKey('last-piece-country-continue'),
                  label: 'Choose Level',
                  icon: Icons.arrow_forward,
                  variant: HifiButtonVariant.gold,
                  onPressed: onContinue,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LastPieceCountryCard extends StatelessWidget {
  const _LastPieceCountryCard({
    required this.country,
    required this.selected,
    required this.familiarity,
    required this.onPressed,
  });

  final CountryConfig country;
  final bool selected;
  final int familiarity;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selected,
      label: Localizations.localeOf(context).languageCode == 'zh'
          ? '${country.name}，熟悉度 $familiarity${selected ? '，已选择' : ''}'
          : '${country.name}, $familiarity Familiarity${selected ? ', selected' : ''}',
      child: Material(
        key: ValueKey('last-piece-country-${country.id}'),
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xF21B211F), Color(0xEA0B100F)],
              ),
              border: Border.all(
                color: selected ? hifiGold : country.color,
                width: selected ? 4 : 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: selected
                      ? hifiGold.withValues(alpha: .35)
                      : Colors.black54,
                  blurRadius: selected ? 18 : 8,
                ),
              ],
            ),
            child: ClipRect(
              child: Row(
                children: [
                  SizedBox(
                    width: 190,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        CountryRepresentativeArt(
                          country: country,
                          bust: true,
                          alignment: Alignment.bottomCenter,
                        ),
                        Align(
                          alignment: Alignment.bottomLeft,
                          child: Container(
                            width: 62,
                            height: 62,
                            margin: const EdgeInsets.all(14),
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: const Color(0xE80B100F),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: country.secondaryColor,
                                width: 2,
                              ),
                            ),
                            child: CountryCrest(country: country, size: 72),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 22, 18, 22),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            country.name,
                            style: const TextStyle(
                              color: hifiInk,
                              fontFamily: 'Georgia',
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            country.fantasy,
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: hifiMuted,
                              fontSize: 14,
                              height: 1.25,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            Localizations.localeOf(context).languageCode == 'zh'
                                ? '熟悉度 $familiarity'
                                : '$familiarity FAMILIARITY',
                            style: TextStyle(
                              color: country.secondaryColor,
                              fontWeight: FontWeight.w900,
                              letterSpacing: .8,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Icon(
                    selected ? Icons.check_circle : Icons.circle_outlined,
                    color: selected ? hifiGold : hifiMuted,
                    size: 34,
                  ),
                  const SizedBox(width: 18),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class LastPieceLevelLadderScreen extends StatelessWidget {
  const LastPieceLevelLadderScreen({
    required this.controller,
    required this.onBack,
    required this.onStart,
    super.key,
  });

  final LastPieceSessionController controller;
  final VoidCallback onBack;
  final VoidCallback onStart;

  @override
  Widget build(BuildContext context) {
    final country = countries[controller.selectedCountryId]!;
    return HifiScaffold(
      backdropAsset: _lastPieceBackdrop,
      backdropOpacity: .42,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(42, 22, 42, 34),
        child: Column(
          children: [
            HifiTopBar(
              screenCode: 'LPS-02',
              title: 'Level Ladder',
              onBack: onBack,
              trailing: [
                CountryCrest(country: country, size: 54),
                const SizedBox(width: 12),
                Text(
                  Localizations.localeOf(context).languageCode == 'zh'
                      ? '${country.shortName} · 熟悉度 ${controller.familiarityFor(country.id)}'
                      : '${country.shortName} · ${controller.familiarityFor(country.id)} Familiarity',
                  style: const TextStyle(
                    color: hifiInk,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            HifiSectionTitle(
              'Endless trials',
              subtitle:
                  'Earn one star at 300 to unlock the next numbered level. '
                  'The run continues after every star.',
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.separated(
                key: const ValueKey('last-piece-level-list'),
                padding: const EdgeInsets.only(right: 12),
                itemCount: controller.catalog.levels.length,
                separatorBuilder: (_, _) => const SizedBox(height: 14),
                itemBuilder: (context, index) {
                  final level = controller.catalog.levels[index];
                  final unlocked = controller.isLevelUnlocked(level.id);
                  final selected = controller.selectedLevelId == level.id;
                  final record = controller.profile.levelRecords[level.id];
                  return _LastPieceLevelCard(
                    level: level,
                    playerCountryId: country.id,
                    unlocked: unlocked,
                    selected: selected,
                    bestScore: record?.bestScore ?? 0,
                    bestStars: record?.bestStars ?? 0,
                    onPressed: unlocked
                        ? () => controller.selectLevel(level.id)
                        : null,
                  );
                },
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: Text(
                    localizedUiCopy(
                      context,
                      'Permanent IDs · append-only catalog · ready for 50+ levels',
                    ),
                    style: const TextStyle(
                      color: hifiMuted,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                SizedBox(
                  width: 360,
                  child: HifiPrimaryButton(
                    key: const ValueKey('last-piece-level-start'),
                    label: Localizations.localeOf(context).languageCode == 'zh'
                        ? '开始第 ${controller.selectedLevelId} 关'
                        : 'Start Level ${controller.selectedLevelId}',
                    icon: Icons.play_arrow,
                    variant: HifiButtonVariant.gold,
                    onPressed:
                        controller.isLevelUnlocked(controller.selectedLevelId)
                        ? onStart
                        : null,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _LastPieceLevelCard extends StatelessWidget {
  const _LastPieceLevelCard({
    required this.level,
    required this.playerCountryId,
    required this.unlocked,
    required this.selected,
    required this.bestScore,
    required this.bestStars,
    required this.onPressed,
  });

  final LastPieceLevelDefinition level;
  final String playerCountryId;
  final bool unlocked;
  final bool selected;
  final int bestScore;
  final int bestStars;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final weights = level.enemyWeights.entries
        .map((entry) => '${pieceTypeLabel(entry.key)} ${entry.value}%')
        .join(' · ');
    return Material(
      key: ValueKey('last-piece-level-${level.id}'),
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 160),
          opacity: unlocked ? 1 : .52,
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: const Color(0xE5141B1A),
              border: Border.all(
                color: selected ? hifiGold : const Color(0xFF526052),
                width: selected ? 4 : 1.5,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 18, 24, 18),
              child: Row(
                children: [
                  SizedBox(
                    width: 92,
                    height: 92,
                    child: PieceToken(
                      piece: ChessPiece(
                        id: 'last-piece-level-${level.id}',
                        type: level.startingPiece,
                        color: PieceColor.white,
                        countryId: playerCountryId,
                        loyalty: null,
                        fairPrice: null,
                      ),
                      checked: false,
                    ),
                  ),
                  const SizedBox(width: 18),
                  SizedBox(
                    width: 116,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          level.id,
                          style: const TextStyle(
                            color: hifiGold,
                            fontFamily: 'Cinzel',
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text(
                          unlocked
                              ? localizedDisplayCase(context, 'Available')
                              : localizedDisplayCase(context, 'Locked'),
                          style: TextStyle(
                            color: unlocked
                                ? const Color(0xFF84D9A6)
                                : const Color(0xFFD98170),
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 24),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          level.title,
                          style: const TextStyle(
                            color: hifiInk,
                            fontFamily: 'Georgia',
                            fontSize: 25,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 7),
                        Text(
                          Localizations.localeOf(context).languageCode == 'zh'
                              ? '${pieceTypeLabel(level.startingPiece)}位于 ${lastPieceSquareName(level.startingSquare)} · '
                                    '初始敌人 ${level.initialEnemies} · 每 ${level.spawnInterval} 个敌方阶段生成'
                              : '${pieceTypeLabel(level.startingPiece)} on '
                                    '${lastPieceSquareName(level.startingSquare)} · '
                                    '${level.initialEnemies} initial · spawn every '
                                    '${level.spawnInterval} enemy phases',
                          style: const TextStyle(
                            color: hifiMuted,
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          weights,
                          style: const TextStyle(
                            color: Color(0xFF9DB5A7),
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 24),
                  SizedBox(
                    width: 230,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '★' * bestStars + '☆' * (3 - bestStars),
                          style: const TextStyle(
                            color: hifiGold,
                            fontSize: 25,
                            letterSpacing: 4,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          Localizations.localeOf(context).languageCode == 'zh'
                              ? '最佳  $bestScore'
                              : 'BEST  $bestScore',
                          style: const TextStyle(
                            color: hifiInk,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text(
                          Localizations.localeOf(context).languageCode == 'zh'
                              ? '星级 300 · 700 · 1,200'
                              : 'Stars 300 · 700 · 1,200',
                          style: const TextStyle(
                            color: hifiMuted,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Icon(
                    unlocked
                        ? selected
                              ? Icons.radio_button_checked
                              : Icons.radio_button_off
                        : Icons.lock,
                    color: selected ? hifiGold : hifiMuted,
                    size: 32,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class LastPieceRunScreen extends StatelessWidget {
  const LastPieceRunScreen({
    required this.controller,
    required this.presentationCoordinator,
    required this.onMove,
    required this.onPromotion,
    required this.onRetire,
    required this.onBackToLadder,
    this.storyDirectorStatus,
    super.key,
  });

  final LastPieceSessionController controller;
  final LastPiecePresentationCoordinator presentationCoordinator;
  final ValueChanged<Square> onMove;
  final ValueChanged<PieceType> onPromotion;
  final VoidCallback onRetire;
  final VoidCallback onBackToLadder;
  final Widget? storyDirectorStatus;

  @override
  Widget build(BuildContext context) {
    final country = countries[controller.selectedCountryId]!;
    return HifiScaffold(
      backdropAsset: _lastPieceBackdrop,
      backdropOpacity: .58,
      showDefaultScrims: false,
      child: Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: [
                  Color(0xE8040908),
                  Color(0x82040A08),
                  Color(0xC9080B0A),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(28, 18, 28, 24),
            child: Column(
              children: [
                SizedBox(
                  height: 70,
                  child: Row(
                    children: [
                      CountryCrest(country: country, size: 54),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            Localizations.localeOf(context).languageCode == 'zh'
                                ? '残子求生 · 第 ${controller.activeLevel.id} 关'
                                : 'LAST PIECE STANDING · LEVEL ${controller.activeLevel.id}',
                            style: const TextStyle(
                              color: hifiGold,
                              fontFamily: 'Cinzel',
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              letterSpacing: .9,
                            ),
                          ),
                          Text(
                            country.name,
                            style: const TextStyle(
                              color: hifiInk,
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                      const Spacer(),
                      _RunMetric(
                        label: localizedUiCopy(context, 'SCORE'),
                        value: '${controller.score}',
                      ),
                      const SizedBox(width: 12),
                      _RunMetric(
                        label: localizedUiCopy(context, 'STARS'),
                        value:
                            '${'★' * controller.stars}'
                            '${'☆' * (3 - controller.stars)}',
                      ),
                      const SizedBox(width: 12),
                      _RunMetric(
                        label: localizedUiCopy(context, 'ENEMIES'),
                        value: '${controller.enemies.length}',
                      ),
                      const SizedBox(width: 16),
                      if (storyDirectorStatus != null) ...[
                        storyDirectorStatus!,
                        const SizedBox(width: 12),
                      ],
                      SizedBox(
                        width: 190,
                        child: HifiPrimaryButton(
                          key: const ValueKey('last-piece-retire'),
                          label: localizedUiCopy(context, 'Retire Run'),
                          icon: Icons.flag,
                          variant: HifiButtonVariant.dark,
                          onPressed: presentationCoordinator.isBusy
                              ? null
                              : onRetire,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        child: Center(
                          child: AspectRatio(
                            aspectRatio: 1,
                            child: LastPieceSurvivalBoard(
                              controller: controller,
                              presentationCoordinator: presentationCoordinator,
                              onMove: onMove,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 22),
                      SizedBox(
                        width: 390,
                        child: _LastPieceHud(
                          controller: controller,
                          presentationCoordinator: presentationCoordinator,
                          onPromotion: onPromotion,
                          onBackToLadder: onBackToLadder,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (controller.milestoneBanner != null)
            Positioned(
              key: const ValueKey('last-piece-milestone-banner'),
              top: 98,
              left: 390,
              right: 470,
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: controller.clearMilestoneBanner,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: const Color(0xF0193E31),
                      border: Border.all(color: hifiGold, width: 2),
                      boxShadow: const [
                        BoxShadow(color: Colors.black87, blurRadius: 16),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 13,
                      ),
                      child: Text(
                        controller.milestoneBanner!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Color(0xFFFFE5A0),
                          fontFamily: 'Cinzel',
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          letterSpacing: .8,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class LastPieceSurvivalBoard extends StatelessWidget {
  const LastPieceSurvivalBoard({
    required this.controller,
    required this.presentationCoordinator,
    required this.onMove,
    super.key,
  });

  final LastPieceSessionController controller;
  final LastPiecePresentationCoordinator presentationCoordinator;
  final ValueChanged<Square> onMove;

  @override
  Widget build(BuildContext context) {
    final activeStep = presentationCoordinator.activeStep;
    final frame = activeStep?.frame ?? _currentFrame();
    final legalMoves = presentationCoordinator.isBusy
        ? const <ChessMove>[]
        : controller.legalPlayerMoves();
    final legalBySquare = <Square, ChessMove>{
      for (final move in legalMoves) move.to: move,
    };
    final country = countries[controller.selectedCountryId]!;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xFF21170F),
        border: Border.all(color: hifiGold, width: 6),
        boxShadow: const [
          BoxShadow(color: Colors.black87, blurRadius: 22, spreadRadius: 4),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final boardSize = constraints.biggest;
            final hiddenPieceIds = _hiddenPieceIds(activeStep);
            return Stack(
              fit: StackFit.expand,
              children: [
                Column(
                  children: [
                    for (var row = 0; row < 8; row++)
                      Expanded(
                        child: Row(
                          children: [
                            for (var col = 0; col < 8; col++)
                              Expanded(
                                child: Builder(
                                  builder: (context) {
                                    final square = Square(row, col);
                                    final enemy = frame.enemies
                                        .where((unit) => unit.square == square)
                                        .firstOrNull;
                                    final tile = frame.rewardTiles
                                        .where(
                                          (reward) => reward.square == square,
                                        )
                                        .firstOrNull;
                                    final move = legalBySquare[square];
                                    return _LastPieceSquare(
                                      square: square,
                                      playerType: frame.player.type,
                                      isPlayer:
                                          frame.player.square == square &&
                                          !hiddenPieceIds.contains(
                                            frame.player.id,
                                          ),
                                      enemy: enemy,
                                      tile: tile,
                                      legal: move != null,
                                      capture: move?.isCapture ?? false,
                                      inputLocked:
                                          presentationCoordinator.isBusy,
                                      onMove: onMove,
                                    );
                                  },
                                ),
                              ),
                          ],
                        ),
                      ),
                  ],
                ),
                ..._staticPieces(frame, boardSize, hiddenPieceIds),
                if (activeStep?.kind == LastPiecePresentationKind.motion)
                  BoardMotionLayer(
                    event: activeStep!.motion!,
                    boardSize: boardSize,
                    duration: presentationCoordinator.moveDuration,
                    keyPrefix: 'last-piece-motion',
                    captureKeyPrefix: 'last-piece-capture-impact',
                    movingKeyPrefix: 'last-piece-moving',
                  ),
                if (activeStep?.kind ==
                    LastPiecePresentationKind.transformation)
                  BoardPieceTransformLayer(
                    serial: activeStep!.serial,
                    square: activeStep.square!,
                    before: activeStep.before!,
                    after: activeStep.after!,
                    boardSize: boardSize,
                    duration: presentationCoordinator.transformDuration,
                    accent: country.secondaryColor,
                    semanticLabel:
                        '${pieceTypeLabel(activeStep.before!.type)} transforms '
                        'into ${pieceTypeLabel(activeStep.after!.type)}',
                    layerKeyPrefix: 'last-piece-transform',
                    glowKey: 'last-piece-transform-glow',
                    beforeKey:
                        'last-piece-transform-before-${activeStep.serial}',
                    afterKey: 'last-piece-transform-after-${activeStep.serial}',
                  ),
                if (activeStep?.kind == LastPiecePresentationKind.spawn)
                  _LastPieceSpawnLayer(
                    step: activeStep!,
                    boardSize: boardSize,
                    duration: presentationCoordinator.spawnDuration,
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  LastPieceBoardFrame _currentFrame() {
    return LastPieceBoardFrame(
      player: controller.player,
      enemies: List<LastPieceUnit>.unmodifiable(controller.enemies),
      rewardTiles: List<LastPieceRewardTile>.unmodifiable(
        controller.rewardTiles,
      ),
    );
  }

  Set<String> _hiddenPieceIds(LastPiecePresentationStep? step) {
    if (step == null) {
      return const <String>{};
    }
    return switch (step.kind) {
      LastPiecePresentationKind.motion => <String>{
        for (final motion in step.motion!.motions) motion.piece.id,
        if (step.motion!.capturedPiece != null) step.motion!.capturedPiece!.id,
      },
      LastPiecePresentationKind.transformation => <String>{step.before!.id},
      LastPiecePresentationKind.spawn => const <String>{},
    };
  }

  List<Widget> _staticPieces(
    LastPieceBoardFrame frame,
    Size boardSize,
    Set<String> hiddenPieceIds,
  ) {
    return <Widget>[
      if (!hiddenPieceIds.contains(frame.player.id))
        Positioned.fromRect(
          rect: boardSquareRect(boardSize, frame.player.square),
          child: IgnorePointer(
            child: PieceToken(
              key: ValueKey('last-piece-player-${frame.player.id}'),
              piece: _pieceFor(frame.player, player: true),
              checked: false,
              selected: !presentationCoordinator.isBusy,
            ),
          ),
        ),
      for (final enemy in frame.enemies)
        if (!hiddenPieceIds.contains(enemy.id))
          Positioned.fromRect(
            rect: boardSquareRect(boardSize, enemy.square),
            child: IgnorePointer(
              child: PieceToken(
                key: ValueKey('last-piece-enemy-${enemy.id}'),
                piece: _pieceFor(enemy, player: false),
                checked: false,
              ),
            ),
          ),
    ];
  }

  ChessPiece _pieceFor(LastPieceUnit unit, {required bool player}) {
    return ChessPiece(
      id: unit.id,
      type: unit.type,
      color: player ? PieceColor.white : PieceColor.black,
      countryId: player ? controller.selectedCountryId : 'iron',
      loyalty: null,
      fairPrice: null,
    );
  }
}

class _LastPieceSquare extends StatelessWidget {
  const _LastPieceSquare({
    required this.square,
    required this.playerType,
    required this.isPlayer,
    required this.enemy,
    required this.tile,
    required this.legal,
    required this.capture,
    required this.inputLocked,
    required this.onMove,
  });

  final Square square;
  final PieceType playerType;
  final bool isPlayer;
  final LastPieceUnit? enemy;
  final LastPieceRewardTile? tile;
  final bool legal;
  final bool capture;
  final bool inputLocked;
  final ValueChanged<Square> onMove;

  @override
  Widget build(BuildContext context) {
    final light = (square.row + square.col).isEven;
    return Semantics(
      button: legal && !inputLocked,
      label: _semanticLabel(context, enemy, tile, isPlayer),
      child: GestureDetector(
        key: ValueKey('last-piece-square-${square.row}-${square.col}'),
        onTap: legal && !inputLocked ? () => onMove(square) : null,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Positioned.fill(
              child: Image.asset(
                light
                    ? 'assets/runtime/pieces/board/mercantile/'
                          'square_light.webp'
                    : 'assets/runtime/pieces/board/mercantile/'
                          'square_dark.webp',
                fit: BoxFit.cover,
                filterQuality: FilterQuality.medium,
                excludeFromSemantics: true,
                errorBuilder: (context, error, stackTrace) => ColoredBox(
                  color: light
                      ? const Color(0xFFB99B69)
                      : const Color(0xFF4D372B),
                ),
              ),
            ),
            if (tile != null)
              Positioned.fill(child: _RewardTileArt(tile: tile!)),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: isPlayer
                      ? const Color(0x2946D6C4)
                      : Colors.transparent,
                  border: Border.all(
                    color: isPlayer
                        ? const Color(0xFFFFE08A)
                        : const Color(0x332D1F16),
                    width: isPlayer ? 3 : .6,
                  ),
                ),
              ),
            ),
            if (legal)
              Center(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: ProductionLegalTargetMarker(
                    capture: capture,
                    redeploy: false,
                  ),
                ),
              ),
            Positioned(
              left: 4,
              top: 2,
              child: Text(
                lastPieceSquareName(square),
                style: TextStyle(
                  color: light
                      ? const Color(0x995D4A2F)
                      : const Color(0x99F1DFB9),
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _semanticLabel(
    BuildContext context,
    LastPieceUnit? enemy,
    LastPieceRewardTile? tile,
    bool isPlayer,
  ) {
    final contents = <String>[lastPieceSquareName(square)];
    if (isPlayer) {
      contents.add(
        Localizations.localeOf(context).languageCode == 'zh'
            ? '玩家${pieceTypeLabel(playerType)}'
            : 'player ${pieceTypeLabel(playerType)}',
      );
    }
    if (enemy != null) {
      contents.add(
        Localizations.localeOf(context).languageCode == 'zh'
            ? '敌方${pieceTypeLabel(enemy.type)}'
            : 'enemy ${pieceTypeLabel(enemy.type)}',
      );
    }
    if (tile?.kind == LastPieceRewardKind.score) {
      contents.add(
        Localizations.localeOf(context).languageCode == 'zh'
            ? '${tile!.scoreValue} 分奖励格'
            : '${tile!.scoreValue} point Score Tile',
      );
    }
    if (tile?.kind == LastPieceRewardKind.transformation) {
      contents.add(
        Localizations.localeOf(context).languageCode == 'zh'
            ? '${pieceTypeLabel(tile!.targetRole!)}转化格'
            : '${pieceTypeLabel(tile!.targetRole!)} Transformation Tile',
      );
    }
    if (legal) {
      contents.add(
        Localizations.localeOf(context).languageCode == 'zh'
            ? '合法走法'
            : 'legal move',
      );
    }
    return contents.join(', ');
  }
}

class _LastPieceSpawnLayer extends StatelessWidget {
  const _LastPieceSpawnLayer({
    required this.step,
    required this.boardSize,
    required this.duration,
  });

  final LastPiecePresentationStep step;
  final Size boardSize;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    final piece = step.spawnedPiece!;
    return Positioned.fromRect(
      rect: boardSquareRect(boardSize, step.square!),
      child: IgnorePointer(
        child: TweenAnimationBuilder<double>(
          key: ValueKey('last-piece-spawn-${step.serial}'),
          duration: duration,
          curve: Curves.easeOutBack,
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, progress, _) {
            final pulse = math.sin(progress * math.pi);
            return Semantics(
              label: Localizations.localeOf(context).languageCode == 'zh'
                  ? '敌方${pieceTypeLabel(piece.type)}生成'
                  : 'Enemy ${pieceTypeLabel(piece.type)} spawns',
              child: Transform.scale(
                scale: .42 + progress * .58,
                child: Opacity(
                  opacity: progress.clamp(0, 1),
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(
                          0xFFFF806F,
                        ).withValues(alpha: .35 + pulse * .6),
                        width: 2 + pulse * 3,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(
                            0xFFFF5747,
                          ).withValues(alpha: pulse * .72),
                          blurRadius: 14 + pulse * 28,
                          spreadRadius: pulse * 5,
                        ),
                      ],
                    ),
                    child: PieceToken(
                      key: ValueKey(
                        'last-piece-spawned-${step.serial}-${piece.id}',
                      ),
                      piece: piece.toChessPiece(),
                      checked: false,
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _RewardTileArt extends StatelessWidget {
  const _RewardTileArt({required this.tile});

  final LastPieceRewardTile tile;

  @override
  Widget build(BuildContext context) {
    final score = tile.kind == LastPieceRewardKind.score;
    return Opacity(
      opacity: .9,
      child: Stack(
        fit: StackFit.expand,
        alignment: Alignment.center,
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final target = tile.targetRole;
              if (!score && target != PieceType.knight) {
                return Opacity(
                  opacity: .9,
                  child: Image.asset(
                    'assets/runtime/modes/last_piece/'
                    'transformation_tiles/${target!.name}.webp',
                    fit: BoxFit.cover,
                    excludeFromSemantics: true,
                  ),
                );
              }
              return SpecialTileArt(
                type: score
                    ? SpecialTileType.treasureChest
                    : SpecialTileType.knightShrine,
                size: constraints.biggest.shortestSide,
                opacity: .82,
                semanticLabel: null,
              );
            },
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              margin: const EdgeInsets.all(3),
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              color: const Color(0xD9000000),
              child: Text(
                score
                    ? '+${tile.scoreValue}'
                    : '→ ${pieceTypeLabel(tile.targetRole!)}',
                maxLines: 1,
                overflow: TextOverflow.fade,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RunMetric extends StatelessWidget {
  const _RunMetric({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xD70B1210),
        border: Border.all(color: const Color(0xFF6D775D)),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        child: Column(
          children: [
            Text(
              localizedUiCopy(context, label),
              style: const TextStyle(
                color: hifiMuted,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
              ),
            ),
            Text(
              value,
              style: const TextStyle(
                color: hifiInk,
                fontSize: 19,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LastPieceHud extends StatelessWidget {
  const _LastPieceHud({
    required this.controller,
    required this.presentationCoordinator,
    required this.onPromotion,
    required this.onBackToLadder,
  });

  final LastPieceSessionController controller;
  final LastPiecePresentationCoordinator presentationCoordinator;
  final ValueChanged<PieceType> onPromotion;
  final VoidCallback onBackToLadder;

  @override
  Widget build(BuildContext context) {
    final captureTotal = controller.captureCounts.values.fold<int>(
      0,
      (sum, count) => sum + count,
    );
    return Column(
      children: [
        HifiPanel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                localizedDisplayCase(context, 'Survival Status'),
                style: const TextStyle(
                  color: hifiGold,
                  fontFamily: 'Cinzel',
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 14),
              _HudRow(
                label: 'Survived phases',
                value: '${controller.survivedPhases}',
              ),
              _HudRow(label: 'Captures', value: '$captureTotal'),
              _HudRow(
                label: 'Transformations',
                value: '${controller.transformations}',
              ),
              _HudRow(
                label: 'Reward tiles',
                value:
                    '${controller.rewardTiles.length} / '
                    '${controller.activeLevel.maxRewardTiles}',
              ),
              _HudRow(
                label: 'Next spawn',
                value: Localizations.localeOf(context).languageCode == 'zh'
                    ? '每 ${controller.activeLevel.spawnInterval} 个阶段 · ${controller.currentSpawnBatchSize} 个敌人'
                    : '${controller.currentSpawnBatchSize} '
                          '${controller.currentSpawnBatchSize == 1 ? 'enemy' : 'enemies'} every '
                          '${controller.activeLevel.spawnInterval} phases',
              ),
              const Divider(color: Color(0xFF755E36)),
              Text(
                controller.stars == 3
                    ? localizedUiCopy(
                        context,
                        'All stars earned — keep playing for your best score.',
                      )
                    : Localizations.localeOf(context).languageCode == 'zh'
                    ? '再得 ${controller.nextMilestone - controller.score} 分即可获得第 ${controller.stars + 1} 颗星'
                    : '${controller.nextMilestone - controller.score} points to ${controller.stars + 1} star',
                style: const TextStyle(
                  color: Color(0xFFFFD983),
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (controller.phase == LastPieceRunPhase.promotion)
          HifiPanel(
            child: Column(
              children: [
                Text(
                  localizedDisplayCase(context, 'Standard Pawn Promotion'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final role in const [
                      PieceType.queen,
                      PieceType.rook,
                      PieceType.bishop,
                      PieceType.knight,
                    ])
                      FilledButton(
                        key: ValueKey('last-piece-promotion-${role.name}'),
                        onPressed: presentationCoordinator.isBusy
                            ? null
                            : () => onPromotion(role),
                        child: Text(pieceTypeLabel(role)),
                      ),
                  ],
                ),
              ],
            ),
          ),
        const SizedBox(height: 14),
        Expanded(
          child: HifiPanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  localizedDisplayCase(context, 'Field Log'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView.separated(
                    reverse: false,
                    itemCount: controller.localizedEventLog.length,
                    separatorBuilder: (_, _) =>
                        const Divider(color: Colors.white12, height: 12),
                    itemBuilder: (context, index) => Text(
                      controller.localizedEventLog[index],
                      style: TextStyle(
                        color: index == 0 ? hifiInk : hifiMuted,
                        fontSize: 12,
                        height: 1.25,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        TextButton.icon(
          key: const ValueKey('last-piece-run-ladder'),
          onPressed: presentationCoordinator.isBusy ? null : onBackToLadder,
          icon: const Icon(Icons.view_list),
          label: Text(
            localizedUiCopy(context, 'Abandon Run And Return To Ladder'),
          ),
        ),
      ],
    );
  }
}

class _HudRow extends StatelessWidget {
  const _HudRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              localizedUiCopy(context, label),
              style: const TextStyle(color: hifiMuted),
            ),
          ),
          Text(
            value,
            style: const TextStyle(color: hifiInk, fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}

class LastPieceResultsScreen extends StatelessWidget {
  const LastPieceResultsScreen({
    required this.controller,
    required this.onRetry,
    required this.onNextLevel,
    required this.onLadder,
    required this.onCourtDorm,
    required this.onLobby,
    super.key,
  });

  final LastPieceSessionController controller;
  final VoidCallback onRetry;
  final VoidCallback? onNextLevel;
  final VoidCallback onLadder;
  final VoidCallback onCourtDorm;
  final VoidCallback onLobby;

  @override
  Widget build(BuildContext context) {
    final result = controller.result!;
    final country = countries[result.countryId]!;
    return HifiScaffold(
      backdropAsset: _lastPieceBackdrop,
      backdropOpacity: .52,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(50, 28, 50, 38),
        child: Row(
          children: [
            Expanded(
              flex: 5,
              child: HifiPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      result.endReason == LastPieceEndReason.captured
                          ? localizedDisplayCase(context, 'The Last Piece Fell')
                          : localizedDisplayCase(context, 'Run Retired'),
                      key: const ValueKey('last-piece-result-title'),
                      style: const TextStyle(
                        color: hifiGold,
                        fontFamily: 'Cinzel',
                        fontSize: 38,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      Localizations.localeOf(context).languageCode == 'zh'
                          ? '${country.name} · 第 ${result.levelId} 关'
                          : '${country.name} · Level ${result.levelId}',
                      style: const TextStyle(
                        color: hifiInk,
                        fontFamily: 'Georgia',
                        fontSize: 26,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Expanded(
                      child: Stack(
                        alignment: Alignment.bottomCenter,
                        children: [
                          Positioned.fill(
                            child: CountryRepresentativeArt(
                              country: country,
                              bust: true,
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: Container(
                              width: 82,
                              height: 82,
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: const Color(0xE80B100F),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: country.secondaryColor,
                                  width: 2,
                                ),
                              ),
                              child: CountryCrest(country: country, size: 72),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Center(
                      child: Text(
                        '${result.score}',
                        style: const TextStyle(
                          color: Color(0xFFFFDF84),
                          fontSize: 72,
                          fontWeight: FontWeight.w900,
                          height: 1,
                        ),
                      ),
                    ),
                    Center(
                      child: Text(
                        localizedDisplayCase(context, 'Final Score'),
                        style: const TextStyle(
                          color: hifiMuted,
                          letterSpacing: 2,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Center(
                      child: Text(
                        '${'★' * result.stars}${'☆' * (3 - result.stars)}',
                        style: const TextStyle(
                          color: hifiGold,
                          fontSize: 42,
                          letterSpacing: 8,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      result.stars > 0
                          ? localizedUiCopy(
                              context,
                              'Level passed. The unlock was saved when you crossed 300.',
                            )
                          : localizedUiCopy(
                              context,
                              'Reach 300 in a future run to unlock the next level.',
                            ),
                      style: const TextStyle(
                        color: hifiMuted,
                        fontSize: 15,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 28),
            Expanded(
              flex: 6,
              child: Column(
                children: [
                  HifiPanel(
                    child: Column(
                      children: [
                        _ResultRow(
                          label: 'Personal best',
                          value: '${result.personalBest}',
                        ),
                        _ResultRow(
                          label: 'Survived phases',
                          value: '${result.survivedPhases}',
                        ),
                        _ResultRow(
                          label: 'Capture points',
                          value: '${result.capturePoints}',
                        ),
                        _ResultRow(
                          label: 'Score-tile points',
                          value: '${result.tilePoints}',
                        ),
                        _ResultRow(
                          label: 'Transformations',
                          value: '${result.transformations}',
                        ),
                        _ResultRow(label: 'Seed', value: '${result.seed}'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  HifiPanel(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          localizedDisplayCase(context, 'Country Familiarity'),
                          style: const TextStyle(
                            color: hifiGold,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '+${result.familiarityGained} · ${Localizations.localeOf(context).languageCode == 'zh' ? '总计 ${result.totalFamiliarity}' : '${result.totalFamiliarity} total'}',
                          style: const TextStyle(
                            color: hifiInk,
                            fontSize: 25,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        if (result.firstPassBonusAwarded > 0)
                          Text(
                            Localizations.localeOf(context).languageCode == 'zh'
                                ? '含首次通关一次性奖励 +${result.firstPassBonusAwarded}'
                                : 'Includes one-time first-pass bonus +${result.firstPassBonusAwarded}',
                            style: const TextStyle(color: hifiMuted),
                          ),
                        if (result.newRewardIds.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          Text(
                            '${localizedDisplayCase(context, 'Unlocked')} · '
                            '${result.newRewardIds.map((id) => _familiarityRewardLabel(context, id)).join(' · ')}',
                            key: const ValueKey(
                              'last-piece-familiarity-unlock',
                            ),
                            style: const TextStyle(
                              color: Color(0xFF8DE1AD),
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 2,
                      childAspectRatio: 3.2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      children: [
                        HifiPrimaryButton(
                          key: const ValueKey('last-piece-result-retry'),
                          label: 'Retry',
                          icon: Icons.refresh,
                          onPressed: onRetry,
                        ),
                        HifiPrimaryButton(
                          key: const ValueKey('last-piece-result-next'),
                          label: 'Next Level',
                          icon: Icons.arrow_forward,
                          onPressed: onNextLevel,
                        ),
                        HifiPrimaryButton(
                          key: const ValueKey('last-piece-result-ladder'),
                          label: 'Level Ladder',
                          icon: Icons.view_list,
                          onPressed: onLadder,
                        ),
                        HifiPrimaryButton(
                          key: const ValueKey('last-piece-result-court'),
                          label: 'Court Dorm',
                          icon: Icons.castle,
                          onPressed: onCourtDorm,
                        ),
                        HifiPrimaryButton(
                          key: const ValueKey('last-piece-result-lobby'),
                          label: 'Lobby',
                          icon: Icons.home,
                          variant: HifiButtonVariant.dark,
                          onPressed: onLobby,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _familiarityRewardLabel(BuildContext context, String id) {
    return switch (id.split(':').last) {
      'chronicle1' =>
        Localizations.localeOf(context).languageCode == 'zh'
            ? '编年史 I'
            : 'Chronicle I',
      'gallery1' =>
        Localizations.localeOf(context).languageCode == 'zh'
            ? '画廊 I'
            : 'Gallery I',
      final value => value,
    };
  }
}

class _ResultRow extends StatelessWidget {
  const _ResultRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              localizedUiCopy(context, label),
              style: const TextStyle(color: hifiMuted),
            ),
          ),
          Text(
            value,
            style: const TextStyle(color: hifiInk, fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}
