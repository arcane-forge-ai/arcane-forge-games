import '../../domain/countries.dart';
import '../../l10n/runtime_game_locale.dart';

String countrySignatureTrait(CountryConfig country) => switch (country.id) {
  'mercantile' =>
    RuntimeGameLocale.isSimplifiedChinese
        ? '契约失败时返还部分费用。'
        : 'Failed contracts return part of their cost.',
  'iron' =>
    RuntimeGameLocale.isSimplifiedChinese
        ? '敌方所有报价的有效金币减少 25。'
        : 'Every enemy offer counts as 25 less effective Gold.',
  'horse' =>
    RuntimeGameLocale.isSimplifiedChinese
        ? '针对马的报价获得公允价修正；马吃子会冲击忠诚。'
        : 'Knight offers shift by fair price; Knight captures shock Loyalty.',
  'spy' =>
    RuntimeGameLocale.isSimplifiedChinese
        ? '读取忠诚区间，并可揭示单次报价的精确信息。'
        : 'Read Loyalty bands and reveal exact intel for one offer.',
  'corsair' =>
    RuntimeGameLocale.isSimplifiedChinese
        ? '每次吃子最多窃取 6 金币。'
        : 'Every capture steals up to 6 Gold.',
  'sunlit' =>
    RuntimeGameLocale.isSimplifiedChinese
        ? '主教攻击会揭示准确忠诚，并使成功率 +25。'
        : 'Bishop attacks expose exact Loyalty and grant +25 chance.',
  _ =>
    RuntimeGameLocale.isSimplifiedChinese
        ? '不应用任何阵营被动。'
        : 'No country passive applies.',
};

List<String> countryRuleDetails(CountryConfig country) => switch (country.id) {
  'mercantile' => [
    RuntimeGameLocale.isSimplifiedChinese
        ? '失败报价返还 ${country.failedRefundPercent}%，最多返还 ${country.failedRefundCap} 金币。'
        : 'Failed offers refund ${country.failedRefundPercent}%, capped at ${country.failedRefundCap} Gold.',
  ],
  'iron' => [
    RuntimeGameLocale.isSimplifiedChinese
        ? '敌方对任意非王棋子的报价均按少 ${country.ironEffectiveOfferPenalty} 金币计算。'
        : 'Every enemy offer against a non-King counts as ${country.ironEffectiveOfferPenalty} less effective Gold.',
    RuntimeGameLocale.isSimplifiedChinese
        ? '兵与车以 80–90 忠诚开局；其他棋子为 65–75。'
        : 'Pawns and Rooks begin at 80–90 Loyalty; other pieces begin at 65–75.',
  ],
  'horse' => [
    RuntimeGameLocale.isSimplifiedChinese
        ? '你收买马时，有效报价增加公允价的 ${country.horseKnightPricePercent}%；敌方骏马王国的马会抵消同等数值。'
        : 'Your Knight offers gain ${country.horseKnightPricePercent}% of fair price; enemy Horse Knights negate the same amount.',
    RuntimeGameLocale.isSimplifiedChinese
        ? '骏马王国的马吃子后，所有存活敌方非王棋子忠诚 -${country.horseKnightCaptureLoyaltyDamage}；买方成功率上限为 ${country.horseKnightOfferCap}%。'
        : 'A Horse Knight capture reduces every surviving enemy non-King by ${country.horseKnightCaptureLoyaltyDamage} Loyalty; buyer success is capped at ${country.horseKnightOfferCap}%.',
  ],
  'spy' => [
    RuntimeGameLocale.isSimplifiedChinese
        ? '主动回合可读取敌方非王棋子的粗略忠诚区间。'
        : 'During its active turn, Spy reads coarse Loyalty bands for enemy non-Kings.',
    RuntimeGameLocale.isSimplifiedChinese
        ? '每回合可揭示一个目标本次报价的准确忠诚与成功率，并获得 +${country.spyRevealBonus}；敌方商人收益 -${country.opponentMerchantPayoutPenalty}。'
        : 'Once per turn, Reveal shows exact Loyalty and chance for one offer and grants +${country.spyRevealBonus}; enemy Merchant Payout is -${country.opponentMerchantPayoutPenalty}.',
  ],
  'corsair' => [
    RuntimeGameLocale.isSimplifiedChinese
        ? '启用经济时，每次吃子从敌方国库转移最多 ${country.captureGoldSteal} 金币。'
        : 'While economy is enabled, every capture transfers up to ${country.captureGoldSteal} Gold from the opposing treasury.',
  ],
  'sunlit' => [
    RuntimeGameLocale.isSimplifiedChinese
        ? '主教攻击的敌方非王棋子会暴露准确忠诚；对该目标的报价成功率 +${country.sunlitExposedChanceBonus}。'
        : 'Enemy non-Kings attacked by a Bishop expose exact Loyalty and gain +${country.sunlitExposedChanceBonus} offer chance.',
    RuntimeGameLocale.isSimplifiedChinese
        ? '最后一名主教失去时，所有友方忠诚减半；主教恢复时，忠诚翻倍。'
        : 'Losing the final Bishop halves allied Loyalty; restoring a Bishop doubles it.',
  ],
  _ => [
    RuntimeGameLocale.isSimplifiedChinese
        ? '该王庭不应用任何阵营被动。'
        : 'This court uses no country passive.',
  ],
};
