import 'package:flutter/material.dart';

import '../../game/game_controller.dart';

class SetupFooter extends StatelessWidget {
  const SetupFooter({required this.controller, super.key});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xDD111316),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF343941)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Wrap(
          spacing: 10,
          runSpacing: 10,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            const Text(
              'Merchant speed',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            for (final speed in const [1, 2, 3, 4, 6, 8])
              ChoiceChip(
                label: Text('$speed'),
                selected: controller.setupMerchantSpeed == speed,
                onSelected: (_) => controller.setMerchantSpeed(speed),
              ),
            FilledButton.icon(
              onPressed: controller.startNewGame,
              icon: const Icon(Icons.sports_esports),
              label: const Text('Start Match'),
            ),
          ],
        ),
      ),
    );
  }
}
