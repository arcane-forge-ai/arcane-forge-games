import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../domain/board_presentation.dart';
import '../../domain/chess_models.dart';
import 'piece_token.dart';

Rect boardSquareRect(Size boardSize, Square square) {
  final width = boardSize.width / 8;
  final height = boardSize.height / 8;
  return Rect.fromLTWH(square.col * width, square.row * height, width, height);
}

class BoardMotionLayer extends StatelessWidget {
  const BoardMotionLayer({
    required this.event,
    required this.boardSize,
    required this.duration,
    this.keyPrefix = 'board-motion',
    this.captureKeyPrefix = 'capture-impact',
    this.movingKeyPrefix = 'moving-piece',
    super.key,
  });

  final BoardMotionEvent event;
  final Size boardSize;
  final Duration duration;
  final String keyPrefix;
  final String captureKeyPrefix;
  final String movingKeyPrefix;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: IgnorePointer(
        child: TweenAnimationBuilder<double>(
          key: ValueKey('$keyPrefix-${event.serial}'),
          duration: duration,
          curve: Curves.linear,
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, progress, _) {
            final travel = Curves.easeInOutCubic.transform(progress);
            final lift = 1 + math.sin(progress * math.pi) * .08;
            final captureOpacity = progress < .78
                ? 1.0
                : ((1 - progress) / .22).clamp(0.0, 1.0);
            return Stack(
              clipBehavior: Clip.none,
              children: [
                if (event.capturedPiece != null && event.capturedSquare != null)
                  Positioned.fromRect(
                    rect: boardSquareRect(boardSize, event.capturedSquare!),
                    child: Opacity(
                      key: ValueKey(
                        '$captureKeyPrefix-${event.capturedPiece!.id}',
                      ),
                      opacity: captureOpacity,
                      child: PieceToken(
                        piece: event.capturedPiece!.toChessPiece(),
                        checked: false,
                        loyaltyBand: event.capturedPiece!.loyaltyBand,
                      ),
                    ),
                  ),
                for (final motion in event.motions)
                  Positioned.fromRect(
                    rect: Rect.lerp(
                      boardSquareRect(boardSize, motion.from),
                      boardSquareRect(boardSize, motion.to),
                      travel,
                    )!,
                    child: Transform.scale(
                      scale: lift,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: const Color(
                                0xFF8DE6DE,
                              ).withValues(alpha: .26),
                              blurRadius: 18,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: PieceToken(
                          key: ValueKey(
                            '$movingKeyPrefix-${event.serial}-'
                            '${motion.piece.id}',
                          ),
                          piece: motion.piece.toChessPiece(),
                          checked: false,
                          loyaltyBand: motion.piece.loyaltyBand,
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class BoardPieceTransformLayer extends StatelessWidget {
  const BoardPieceTransformLayer({
    required this.serial,
    required this.square,
    required this.before,
    required this.after,
    required this.boardSize,
    required this.duration,
    required this.accent,
    required this.semanticLabel,
    this.layerKeyPrefix = 'piece-transform',
    this.glowKey = 'piece-transform-glow',
    this.beforeKey,
    this.afterKey,
    super.key,
  });

  final int serial;
  final Square square;
  final PresentedPiece before;
  final PresentedPiece after;
  final Size boardSize;
  final Duration duration;
  final Color accent;
  final String semanticLabel;
  final String layerKeyPrefix;
  final String glowKey;
  final String? beforeKey;
  final String? afterKey;

  @override
  Widget build(BuildContext context) {
    return Positioned.fromRect(
      rect: boardSquareRect(boardSize, square),
      child: IgnorePointer(
        child: TweenAnimationBuilder<double>(
          key: ValueKey('$layerKeyPrefix-$serial'),
          duration: duration,
          curve: Curves.linear,
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, progress, _) {
            final afterOpacity = Curves.easeInOutCubic.transform(progress);
            final glow = math.sin(progress * math.pi);
            return Semantics(
              label: semanticLabel,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  FractionallySizedBox(
                    widthFactor: .92,
                    heightFactor: .92,
                    child: DecoratedBox(
                      key: ValueKey(glowKey),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: accent.withValues(alpha: .35 + glow * .65),
                          width: 2 + glow * 3,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: accent.withValues(alpha: glow * .72),
                            blurRadius: 16 + glow * 24,
                            spreadRadius: glow * 5,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Opacity(
                    opacity: 1 - afterOpacity,
                    child: PieceToken(
                      key: ValueKey(
                        beforeKey ?? 'transform-before-${before.id}',
                      ),
                      piece: before.toChessPiece(),
                      checked: false,
                      loyaltyBand: before.loyaltyBand,
                    ),
                  ),
                  Opacity(
                    opacity: afterOpacity,
                    child: PieceToken(
                      key: ValueKey(afterKey ?? 'transform-after-${after.id}'),
                      piece: after.toChessPiece(),
                      checked: false,
                      loyaltyBand: after.loyaltyBand,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
