import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../game/game_controller.dart';
import '../../living_campaign/living_campaign_models.dart';
import '../../l10n/ui_copy.dart';
import '../menu/hifi_menu_widgets.dart';
import '../shared/country_crest.dart';
import '../shared/formatters.dart';
import '../shared/piece_art.dart';
import '../shared/reference_first_match_art.dart';
import '../shared/stat_pill.dart';
import '../shared/text_styles.dart';
import 'redeploy_panel.dart';

class ActionPanel extends StatelessWidget {
  const ActionPanel({
    required this.controller,
    this.piecePresentationResolver,
    super.key,
  });

  final GameController controller;
  final Future<LivingPiecePresentation?> Function(ChessPiece piece)?
  piecePresentationResolver;

  @override
  Widget build(BuildContext context) {
    final redeploy = controller.phase == GamePhase.redeploy;
    if (redeploy) {
      return RedeployPanel(controller: controller);
    }
    final gameOver = controller.phase == GamePhase.gameOver;
    return HifiAssetSurface(
      key: const ValueKey('s21-piece-inspector'),
      asset: matchHudInspectorAsset,
      centerSlice: matchInspectorCenterSlice,
      backgroundImageOutset: EdgeInsets.zero,
      padding: const EdgeInsets.fromLTRB(34, 34, 34, 32),
      child: gameOver
          ? const SizedBox.expand(
              key: ValueKey('s28-inspector-content-cleared'),
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  localizedDisplayCase(context, 'Selected Piece'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: hifiGold,
                    fontFamily: 'Cinzel',
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 10),
                Expanded(child: _panelBody(context)),
              ],
            ),
    );
  }

  Widget _panelBody(BuildContext context) {
    if (controller.phase == GamePhase.offer) {
      return Center(
        child: Text(
          localizedUiCopy(
            context,
            'Contract negotiation is open over the board.',
          ),
          textAlign: TextAlign.center,
          style: softText,
        ),
      );
    }
    final square = controller.selectedSquare;
    if (square == null) {
      return const EmptySelectionPanel();
    }
    final piece = controller.pieceAt(square);
    if (piece == null) {
      return const EmptySelectionPanel();
    }
    final country = countries[piece.countryId]!;
    final enemy = piece.color != controller.turn;
    final purchasable =
        controller.economyEnabled && enemy && piece.type != PieceType.king;
    final visibleFairPrice = controller.visibleFairPriceForActiveCourt(piece);
    final visibleLoyaltyBand = controller.visibleLoyaltyBandForActiveCourt(
      piece,
    );
    final presentation = piecePresentationResolver?.call(piece);
    return ListView(
      key: const ValueKey('s21-piece-inspector-scroll'),
      padding: EdgeInsets.zero,
      children: [
        FutureBuilder<LivingPiecePresentation?>(
          future: presentation,
          builder: (context, snapshot) => _InspectorPortrait(
            piece: piece,
            country: country,
            presentation: snapshot.data,
          ),
        ),
        const SizedBox(height: 12),
        FutureBuilder<LivingPiecePresentation?>(
          future: presentation,
          builder: (context, snapshot) => Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                snapshot.data?.name ??
                    '${colorLabel(piece.color)} ${pieceTypeLabel(piece.type)}',
                key: ValueKey(
                  snapshot.data == null
                      ? 'selected-piece-${piece.id}'
                      : 'selected-character-${snapshot.data!.characterId}',
                ),
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              if (snapshot.data != null)
                Text(
                  '${colorLabel(piece.color)} ${pieceTypeLabel(piece.type)}',
                  style: softText,
                ),
            ],
          ),
        ),
        const SizedBox(height: 4),
        Row(
          children: [
            CountryCrest(country: country, size: 28),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                country.name,
                style: TextStyle(
                  color: country.secondaryColor,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          Localizations.localeOf(context).languageCode == 'zh'
              ? '格子 ${controller.squareName(square)}。${enemy ? '敌方目标。' : '友方棋子。'}'
              : 'Square ${controller.squareName(square)}. ${enemy ? 'Enemy target.' : 'Friendly piece.'}',
          style: softText,
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            if (visibleFairPrice != null)
              StatPill(
                Localizations.localeOf(context).languageCode == 'zh'
                    ? '谍报 · 公允价 $visibleFairPrice'
                    : 'Spy Intel · Fair $visibleFairPrice',
                key: const ValueKey('s21-spy-fair-price'),
              ),
            if (visibleLoyaltyBand != null)
              StatPill(
                Localizations.localeOf(context).languageCode == 'zh'
                    ? '忠诚 · ${localizedUiCopy(context, visibleLoyaltyBand.label)}'
                    : 'Loyalty · ${visibleLoyaltyBand.label}',
                key: const ValueKey('s21-spy-loyalty-band'),
              ),
            StatPill(
              Localizations.localeOf(context).languageCode == 'zh'
                  ? (enemy ? '敌方' : '我方王庭')
                  : (enemy ? 'ENEMY' : 'YOUR COURT'),
            ),
          ],
        ),
        const SizedBox(height: 20),
        if (purchasable)
          SizedBox(
            height: 58,
            child: HifiPrimaryButton(
              key: const ValueKey('s21-offer-action'),
              label: 'Offer Contract',
              icon: Icons.description,
              variant: HifiButtonVariant.gold,
              backgroundAsset: matchButtonGoldAsset,
              backgroundImageScale: matchButtonImageScale,
              onPressed: controller.openOfferForSelected,
            ),
          ),
        if (!enemy)
          Text(
            localizedUiCopy(
              context,
              'Choose a highlighted square on the board to move this piece.',
            ),
            textAlign: TextAlign.center,
            style: softText,
          ),
        if (enemy && piece.type == PieceType.king)
          Text(
            localizedUiCopy(
              context,
              'The opposing King is protected from contracts.',
            ),
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFFFFD08A),
              fontWeight: FontWeight.w800,
            ),
          ),
        if (enemy && piece.type != PieceType.king && !controller.economyEnabled)
          Text(
            localizedUiCopy(
              context,
              'Contracts are not available in this mission.',
            ),
            textAlign: TextAlign.center,
            style: softText,
          ),
        if (controller.offerError != null) ...[
          const SizedBox(height: 10),
          Text(
            controller.offerError!,
            style: const TextStyle(color: Color(0xFFffd08a)),
          ),
        ],
      ],
    );
  }
}

class _InspectorPortrait extends StatelessWidget {
  const _InspectorPortrait({
    required this.piece,
    required this.country,
    required this.presentation,
  });

  final ChessPiece piece;
  final CountryConfig country;
  final LivingPiecePresentation? presentation;

  @override
  Widget build(BuildContext context) {
    final bytes = presentation?.portraitBytes;
    final reference = presentation?.portraitReference;
    final Widget portrait;
    if (bytes != null) {
      portrait = Image.memory(
        bytes,
        key: ValueKey(
          'selected-character-portrait-${presentation!.characterId}',
        ),
        fit: BoxFit.contain,
        alignment: Alignment.bottomCenter,
        gaplessPlayback: true,
      );
    } else if (reference?.startsWith('assets/') == true) {
      portrait = Image.asset(
        reference!,
        key: ValueKey(
          'selected-character-portrait-${presentation!.characterId}',
        ),
        fit: BoxFit.contain,
        alignment: Alignment.bottomCenter,
        errorBuilder: (context, error, stackTrace) => PieceArtImage(
          countryId: piece.countryId,
          type: piece.type,
          kind: PieceArtKind.portrait,
          alignment: Alignment.bottomCenter,
        ),
      );
    } else {
      portrait = PieceArtImage(
        countryId: piece.countryId,
        type: piece.type,
        kind: PieceArtKind.portrait,
        alignment: Alignment.bottomCenter,
      );
    }
    return SizedBox(
      height: 250,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: country.color.withValues(alpha: .18),
          border: Border.all(color: country.secondaryColor, width: 1.5),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Padding(padding: const EdgeInsets.all(8), child: portrait),
      ),
    );
  }
}

class EmptySelectionPanel extends StatelessWidget {
  const EmptySelectionPanel({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        localizedUiCopy(
          context,
          'Select a piece on the board to open its portrait and role details.',
        ),
        textAlign: TextAlign.center,
        style: const TextStyle(color: Color(0xFFbdb4a5), height: 1.4),
      ),
    );
  }
}
