import 'package:flutter/material.dart';

const softText = TextStyle(color: Color(0xFFbdb4a5), height: 1.35);

const labelStyle = TextStyle(
  fontSize: 12,
  color: Color(0xFF9d9488),
  fontWeight: FontWeight.w800,
  letterSpacing: 0,
);
