import 'package:flutter/material.dart';

class DecoratedPanel extends StatelessWidget {
  const DecoratedPanel({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xEE171a1f),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF343a43)),
      ),
      child: Padding(padding: const EdgeInsets.all(14), child: child),
    );
  }
}
