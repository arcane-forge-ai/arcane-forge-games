import '../../domain/chess_models.dart';
import '../../l10n/runtime_game_locale.dart';

String signed(int value) => value >= 0 ? '+$value' : '$value';

String colorLabel(PieceColor color) => color == PieceColor.white
    ? RuntimeGameLocale.copy.sideWhite
    : RuntimeGameLocale.copy.sideBlack;

String pieceTypeLabel(PieceType type) {
  switch (type) {
    case PieceType.pawn:
      return RuntimeGameLocale.copy.piecePawn;
    case PieceType.knight:
      return RuntimeGameLocale.copy.pieceKnight;
    case PieceType.bishop:
      return RuntimeGameLocale.copy.pieceBishop;
    case PieceType.rook:
      return RuntimeGameLocale.copy.pieceRook;
    case PieceType.queen:
      return RuntimeGameLocale.copy.pieceQueen;
    case PieceType.king:
      return RuntimeGameLocale.copy.pieceKing;
  }
}

String pieceSymbol(ChessPiece piece) {
  if (piece.color == PieceColor.white) {
    switch (piece.type) {
      case PieceType.pawn:
        return '♙';
      case PieceType.knight:
        return '♘';
      case PieceType.bishop:
        return '♗';
      case PieceType.rook:
        return '♖';
      case PieceType.queen:
        return '♕';
      case PieceType.king:
        return '♔';
    }
  }
  switch (piece.type) {
    case PieceType.pawn:
      return '♟';
    case PieceType.knight:
      return '♞';
    case PieceType.bishop:
      return '♝';
    case PieceType.rook:
      return '♜';
    case PieceType.queen:
      return '♛';
    case PieceType.king:
      return '♚';
  }
}
