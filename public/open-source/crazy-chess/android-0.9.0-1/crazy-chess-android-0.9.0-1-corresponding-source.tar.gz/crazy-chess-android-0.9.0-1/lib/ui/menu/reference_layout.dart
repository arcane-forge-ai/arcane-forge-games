import 'package:flutter/material.dart';

import '../../app/stage_metrics.dart';

/// Converts the approved 1672×941 source keyframes into the fixed game stage.
///
/// S02 and S03 deliberately use this helper instead of proportional `Row` and
/// `Column` layout: the owner requested their visible geometry match the
/// accepted reference at the 1600×900 runtime size.
class ReferenceGeometry {
  const ReferenceGeometry._();

  static const double sourceWidth = 1672;
  static const double sourceHeight = 941;

  static double get scaleX => StageMetrics.logicalWidth / sourceWidth;
  static double get scaleY => StageMetrics.logicalHeight / sourceHeight;

  static Rect toStage(Rect sourceBounds) {
    return Rect.fromLTWH(
      sourceBounds.left * scaleX,
      sourceBounds.top * scaleY,
      sourceBounds.width * scaleX,
      sourceBounds.height * scaleY,
    );
  }
}

class ReferencePositioned extends StatelessWidget {
  const ReferencePositioned({
    required this.sourceBounds,
    required this.child,
    super.key,
  });

  final Rect sourceBounds;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Positioned.fromRect(
      rect: ReferenceGeometry.toStage(sourceBounds),
      child: child,
    );
  }
}

class ReferenceLayer extends StatelessWidget {
  const ReferenceLayer({
    required this.asset,
    required this.sourceBounds,
    this.fit = BoxFit.fill,
    super.key,
  });

  final String asset;
  final Rect sourceBounds;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) {
    return ReferencePositioned(
      sourceBounds: sourceBounds,
      child: Image.asset(
        asset,
        fit: fit,
        filterQuality: FilterQuality.high,
        excludeFromSemantics: true,
      ),
    );
  }
}

/// A measured visual layer whose hit area stays aligned with its reference.
class ReferenceAction extends StatelessWidget {
  const ReferenceAction({
    required this.sourceBounds,
    required this.semanticLabel,
    required this.child,
    this.onPressed,
    super.key,
  });

  final Rect sourceBounds;
  final String semanticLabel;
  final Widget child;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return ReferencePositioned(
      sourceBounds: sourceBounds,
      child: Semantics(
        button: true,
        enabled: onPressed != null,
        label: semanticLabel,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onPressed,
            child: ExcludeSemantics(child: child),
          ),
        ),
      ),
    );
  }
}
