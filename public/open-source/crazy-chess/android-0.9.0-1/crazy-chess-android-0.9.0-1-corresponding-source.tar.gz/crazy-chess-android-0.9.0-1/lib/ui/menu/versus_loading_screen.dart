import 'package:flutter/material.dart';

import '../../domain/countries.dart';
import '../../game/game_controller.dart';
import '../../l10n/ui_copy.dart';
import 'country_representative_art.dart';
import 'hifi_menu_widgets.dart';
import 'reference_layout.dart';
import '../shared/country_crest.dart';

const _s07ReferenceRoot = '$runtimeAssetRoot/scenes/versus';

class VersusLoadingScreen extends StatefulWidget {
  const VersusLoadingScreen({
    required this.controller,
    required this.onBack,
    required this.onStartMatch,
    this.loadingDuration = const Duration(seconds: 5),
    super.key,
  });

  final GameController controller;
  final VoidCallback onBack;
  final VoidCallback onStartMatch;
  final Duration loadingDuration;

  static const leftPortraitBounds = Rect.fromLTWH(32, 140, 470, 585);
  static const boardBounds = Rect.fromLTWH(566, 222, 538, 445);
  static const rightPortraitBounds = Rect.fromLTWH(1165, 140, 470, 585);
  static const loadingBounds = Rect.fromLTWH(520, 760, 632, 108);

  @override
  State<VersusLoadingScreen> createState() => _VersusLoadingScreenState();
}

class _VersusLoadingScreenState extends State<VersusLoadingScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _loading;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _loading =
        AnimationController(vsync: this, duration: widget.loadingDuration)
          ..addStatusListener((status) {
            if (status == AnimationStatus.completed && mounted) {
              setState(() => _ready = true);
            }
          })
          ..forward();
  }

  @override
  void didUpdateWidget(covariant VersusLoadingScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.loadingDuration != widget.loadingDuration && !_ready) {
      _loading.duration = widget.loadingDuration;
    }
  }

  @override
  void dispose() {
    _loading.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final white = countries[widget.controller.setupWhiteCountryId]!;
    final black = countries[widget.controller.setupBlackCountryId]!;
    return HifiScaffold(
      backdropAsset: '$_s07ReferenceRoot/s07_versus_bg.webp',
      backdropOpacity: 1,
      showDefaultScrims: false,
      child: Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xB5090C10),
                  Color(0x15090C10),
                  Color(0xCC090C10),
                ],
              ),
            ),
          ),
          ReferenceAction(
            key: const ValueKey('s07-back'),
            sourceBounds: const Rect.fromLTWH(14, 15, 115, 48),
            semanticLabel: 'Back to country select',
            onPressed: widget.onBack,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xB20B1116),
                border: Border.all(color: hifiGoldDark),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.arrow_back, color: hifiGold, size: 18),
                  const SizedBox(width: 6),
                  Text(
                    localizedDisplayCase(context, 'Back'),
                    style: const TextStyle(
                      color: hifiInk,
                      fontFamily: 'Cinzel',
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
          ),
          ReferencePositioned(
            sourceBounds: Rect.fromLTWH(480, 20, 712, 120),
            child: Column(
              children: [
                const Text(
                  'CRAZY CHESS',
                  style: TextStyle(
                    color: hifiInk,
                    fontFamily: 'Cinzel',
                    fontSize: 31,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.2,
                    shadows: [Shadow(color: Colors.black, blurRadius: 14)],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  localizedDisplayCase(context, 'Courts at War'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontFamily: 'Cinzel',
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 3.5,
                  ),
                ),
              ],
            ),
          ),
          ReferencePositioned(
            sourceBounds: VersusLoadingScreen.leftPortraitBounds,
            child: _VersusPortrait(
              courtLabel: localizedDisplayCase(context, 'White Court'),
              country: white,
              alignment: Alignment.bottomLeft,
            ),
          ),
          ReferencePositioned(
            sourceBounds: VersusLoadingScreen.rightPortraitBounds,
            child: _VersusPortrait(
              courtLabel: localizedDisplayCase(context, 'Black Court'),
              country: black,
              alignment: Alignment.bottomRight,
              mirror: true,
            ),
          ),
          ReferencePositioned(
            sourceBounds: VersusLoadingScreen.boardBounds,
            child: _BattlefieldPreview(controller: widget.controller),
          ),
          const ReferencePositioned(
            sourceBounds: Rect.fromLTWH(730, 123, 208, 100),
            child: Center(
              child: Text(
                'VS',
                style: TextStyle(
                  color: hifiGold,
                  fontFamily: 'Cinzel',
                  fontSize: 66,
                  fontWeight: FontWeight.w900,
                  shadows: [
                    Shadow(color: Color(0xFF0A655D), blurRadius: 14),
                    Shadow(color: Color(0xFF7A1D25), blurRadius: 24),
                  ],
                ),
              ),
            ),
          ),
          ReferencePositioned(
            sourceBounds: VersusLoadingScreen.loadingBounds,
            child: AnimatedBuilder(
              animation: _loading,
              builder: (context, _) {
                if (_ready) {
                  return HifiPrimaryButton(
                    key: const ValueKey('s07-enter-match'),
                    label: 'Enter Match',
                    icon: Icons.sports_esports,
                    large: true,
                    variant: HifiButtonVariant.emerald,
                    onPressed: widget.onStartMatch,
                  );
                }
                return Semantics(
                  key: const ValueKey('s07-loading'),
                  label: Localizations.localeOf(context).languageCode == 'zh'
                      ? '正在准备战场，完成 ${(_loading.value * 100).round()}%'
                      : 'Preparing battlefield ${(_loading.value * 100).round()} percent',
                  value: '${(_loading.value * 100).round()}%',
                  child: _LoadingRibbon(progress: _loading.value),
                );
              },
            ),
          ),
          if (_ready)
            Positioned(
              left: 0,
              right: 0,
              bottom: 18,
              child: Semantics(
                key: const ValueKey('s07-ready'),
                label: localizedUiCopy(context, 'Battlefield ready'),
                child: Text(
                  localizedDisplayCase(context, 'Battlefield ready'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: hifiGold,
                    fontFamily: 'Cinzel',
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _VersusPortrait extends StatelessWidget {
  const _VersusPortrait({
    required this.courtLabel,
    required this.country,
    required this.alignment,
    this.mirror = false,
  });

  final String courtLabel;
  final CountryConfig country;
  final Alignment alignment;
  final bool mirror;

  @override
  Widget build(BuildContext context) {
    final art = CountryRepresentativeArt(
      country: country,
      alignment: alignment,
      fit: country.id == 'spy' ? BoxFit.cover : BoxFit.contain,
    );
    return Stack(
      fit: StackFit.expand,
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(0, .2),
              radius: .8,
              colors: [
                country.color.withValues(alpha: .55),
                Colors.transparent,
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 116),
          child: mirror ? Transform.flip(flipX: true, child: art) : art,
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: 122,
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 13, 18, 12),
            decoration: BoxDecoration(
              color: const Color(0xE90B1116),
              border: Border.all(color: country.secondaryColor, width: 1.5),
              boxShadow: const [
                BoxShadow(color: Colors.black87, blurRadius: 18),
              ],
            ),
            child: Row(
              children: [
                CountryCrest(country: country, size: 62),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        courtLabel,
                        style: TextStyle(
                          color: country.secondaryColor,
                          fontFamily: 'Cinzel',
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        localizedDisplayCase(context, country.name),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: hifiInk,
                          fontFamily: 'Cinzel',
                          fontSize: 21,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _BattlefieldPreview extends StatelessWidget {
  const _BattlefieldPreview({required this.controller});
  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          localizedDisplayCase(context, 'Battlefield Preview'),
          style: const TextStyle(
            color: hifiGold,
            fontFamily: 'Cinzel',
            fontSize: 16,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 9),
        Expanded(
          child: DecoratedBox(
            decoration: BoxDecoration(
              border: Border.all(color: hifiGoldDark, width: 2),
              boxShadow: const [
                BoxShadow(color: Colors.black87, blurRadius: 18),
              ],
            ),
            child: Image.asset(
              '$_s07ReferenceRoot/battlefield_board.webp',
              fit: BoxFit.fill,
              filterQuality: FilterQuality.high,
            ),
          ),
        ),
        const SizedBox(height: 10),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: const Color(0xE20A1015),
            border: Border.all(color: hifiGoldDark),
          ),
          child: Text(
            Localizations.localeOf(context).languageCode == 'zh'
                ? '商人速度 ${controller.setupMerchantSpeed}  ·  标准经济  ·  概率隐藏  ·  中立棋盘'
                : 'Merchant ${controller.setupMerchantSpeed}  ·  Economy Standard  ·  Chance Hidden  ·  Board Neutral',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: hifiMuted,
              fontFamily: 'Cormorant Garamond',
              fontSize: 15,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}

class _LoadingRibbon extends StatelessWidget {
  const _LoadingRibbon({required this.progress});
  final double progress;

  @override
  Widget build(BuildContext context) {
    final pulse = .65 + .35 * (1 - (progress * 8 % 2 - 1).abs());
    return HifiAssetSurface(
      asset: '$runtimeAssetRoot/ui/common/loading_ribbon_9slice.webp',
      imageScale: 3,
      centerSlice: const Rect.fromLTRB(128, 64, 896, 128),
      padding: const EdgeInsets.fromLTRB(68, 18, 68, 17),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            localizedDisplayCase(context, 'Preparing the Battlefield'),
            style: const TextStyle(
              color: Color(0xFF2C1D10),
              fontFamily: 'Cinzel',
              fontSize: 13,
              fontWeight: FontWeight.w900,
              letterSpacing: .8,
            ),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 10,
              backgroundColor: const Color(0xFF8B7652),
              color: Color.lerp(
                const Color(0xFF0E5D58),
                const Color(0xFF51BDB0),
                pulse,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
