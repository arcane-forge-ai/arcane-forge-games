import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../shared/piece_art.dart';

class PieceToken extends StatelessWidget {
  const PieceToken({
    required this.piece,
    required this.checked,
    this.selected = false,
    this.loyaltyBand,
    super.key,
  });

  final ChessPiece piece;
  final bool checked;
  final bool selected;
  final LoyaltyBand? loyaltyBand;

  @override
  Widget build(BuildContext context) {
    final country = countries[piece.countryId]!;
    return FractionallySizedBox(
      widthFactor: 0.82,
      heightFactor: 0.82,
      child: AnimatedScale(
        key: ValueKey('piece-token-${piece.id}'),
        duration: const Duration(milliseconds: 160),
        scale: selected ? 1.12 : 1,
        child: AnimatedSlide(
          duration: const Duration(milliseconds: 160),
          offset: selected ? const Offset(0, -.045) : Offset.zero,
          child: Semantics(
            container: true,
            image: true,
            explicitChildNodes: true,
            label:
                '${piece.color == PieceColor.white ? 'White' : 'Black'} '
                '${country.shortName} ${piece.type.name}'
                '${selected ? ', selected' : ''}'
                '${loyaltyBand == null ? '' : ', ${loyaltyBand!.label} loyalty'}',
            child: DecoratedBox(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    country.secondaryColor.withValues(
                      alpha: selected || checked ? .52 : .18,
                    ),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: checked
                        ? const Color(0xAAff413d)
                        : selected
                        ? country.secondaryColor.withValues(alpha: .72)
                        : const Color(0x66000000),
                    blurRadius: checked ? 18 : (selected ? 15 : 7),
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(3, 1, 3, 7),
                    child: PieceArtImage(
                      countryId: piece.countryId,
                      type: piece.type,
                      kind: PieceArtKind.token,
                      color: piece.color,
                      filterQuality: FilterQuality.medium,
                    ),
                  ),
                  if (loyaltyBand != null)
                    Positioned(
                      left: 7,
                      right: 7,
                      bottom: 2,
                      height: 8,
                      child: ExcludeSemantics(
                        child: _SegmentedLoyaltyBar(
                          key: ValueKey('piece-loyalty-bar-${piece.id}'),
                          band: loyaltyBand!,
                          foreground: country.secondaryColor,
                          background: country.color,
                          emphasized: piece.newlyPurchased || checked,
                        ),
                      ),
                    ),
                  Positioned(
                    right: 0,
                    bottom: 4,
                    width: 20,
                    height: 20,
                    child: _RoleMedallion(type: piece.type, color: piece.color),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _SegmentedLoyaltyBar extends StatelessWidget {
  const _SegmentedLoyaltyBar({
    required this.band,
    required this.foreground,
    required this.background,
    required this.emphasized,
    super.key,
  });

  final LoyaltyBand band;
  final Color foreground;
  final Color background;
  final bool emphasized;

  @override
  Widget build(BuildContext context) {
    return Row(
      key: ValueKey('loyalty-band-${band.name}'),
      children: List<Widget>.generate(5, (index) {
        final filled = index < band.filledSegments;
        return Expanded(
          child: Container(
            margin: EdgeInsets.only(right: index == 4 ? 0 : 1.5),
            decoration: BoxDecoration(
              color: filled ? foreground : background.withValues(alpha: .36),
              borderRadius: BorderRadius.circular(2),
              border: Border.all(
                color: foreground.withValues(alpha: filled ? 1 : .56),
                width: emphasized ? 1.2 : .7,
              ),
              boxShadow: const [
                BoxShadow(color: Colors.black54, blurRadius: 2),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class _RoleMedallion extends StatelessWidget {
  const _RoleMedallion({required this.type, required this.color});

  final PieceType type;
  final PieceColor color;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      container: true,
      label:
          '${color == PieceColor.white ? 'White' : 'Black'} '
          '${type.name} role medallion',
      child: DecoratedBox(
        key: ValueKey('piece-role-badge-${color.name}-${type.name}'),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color == PieceColor.white
              ? const Color(0xFFF4E9CB)
              : const Color(0xFF151719),
          border: Border.all(
            color: color == PieceColor.white
                ? const Color(0xFF9C7A31)
                : const Color(0xFF9D3F45),
            width: 1.5,
          ),
          boxShadow: const [
            BoxShadow(
              color: Colors.black87,
              blurRadius: 4,
              offset: Offset(0, 1),
            ),
          ],
        ),
        child: Center(
          child: Text(
            _roleSymbol(type, color),
            key: ValueKey('piece-role-glyph-${color.name}-${type.name}'),
            style: TextStyle(
              color: color == PieceColor.white
                  ? const Color(0xFF182424)
                  : const Color(0xFFF4E9CB),
              fontSize: 13,
              height: 1,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ),
    );
  }
}

String _roleSymbol(PieceType type, PieceColor color) {
  if (color == PieceColor.white) {
    return switch (type) {
      PieceType.king => '♔',
      PieceType.queen => '♕',
      PieceType.rook => '♖',
      PieceType.bishop => '♗',
      PieceType.knight => '♘',
      PieceType.pawn => '♙',
    };
  }
  return switch (type) {
    PieceType.king => '♚',
    PieceType.queen => '♛',
    PieceType.rook => '♜',
    PieceType.bishop => '♝',
    PieceType.knight => '♞',
    PieceType.pawn => '♟',
  };
}
