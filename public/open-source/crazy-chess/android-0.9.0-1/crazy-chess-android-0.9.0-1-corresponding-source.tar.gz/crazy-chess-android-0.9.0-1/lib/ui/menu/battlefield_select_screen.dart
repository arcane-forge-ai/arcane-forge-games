import 'package:flutter/material.dart';

import '../../battlefield/battlefield_models.dart';
import '../../game/game_controller.dart';
import '../../l10n/runtime_game_locale.dart';
import '../../l10n/ui_copy.dart';
import '../shared/special_tile_art.dart';
import 'hifi_menu_widgets.dart';

class BattlefieldSelectScreen extends StatelessWidget {
  const BattlefieldSelectScreen({
    required this.controller,
    required this.onBack,
    required this.onContinue,
    super.key,
  });

  final GameController controller;
  final VoidCallback onBack;
  final VoidCallback onContinue;

  @override
  Widget build(BuildContext context) {
    final selected = controller.setupBattlefield;
    return HifiScaffold(
      backdropAsset:
          'assets/runtime/ui/match_settings/s04_match_settings_bg.webp',
      backdropOpacity: .78,
      showDefaultScrims: false,
      child: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xC5080D10), Color(0xED05080A)],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(48, 30, 48, 30),
          child: Column(
            children: [
              Row(
                children: [
                  HifiPrimaryButton(
                    key: const ValueKey('battlefield-back'),
                    label: 'Back',
                    icon: Icons.arrow_back,
                    variant: HifiButtonVariant.dark,
                    onPressed: onBack,
                  ),
                  const SizedBox(width: 32),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          localizedDisplayCase(context, 'Choose Battlefield'),
                          style: const TextStyle(
                            color: hifiInk,
                            fontFamily: 'Cinzel',
                            fontSize: 38,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2.2,
                            shadows: [
                              Shadow(color: Colors.black, blurRadius: 12),
                            ],
                          ),
                        ),
                        Text(
                          localizedUiCopy(
                            context,
                            'The land changes the war. Every effect is mirrored and visible.',
                          ),
                          style: const TextStyle(
                            color: hifiMuted,
                            fontSize: 16,
                            letterSpacing: .4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _SeedBadge(hasEffects: selected.hasMapEffects),
                ],
              ),
              const SizedBox(height: 24),
              Expanded(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      child: GridView.count(
                        physics: const ClampingScrollPhysics(),
                        padding: const EdgeInsets.only(bottom: 18),
                        crossAxisCount: 2,
                        mainAxisSpacing: 18,
                        crossAxisSpacing: 18,
                        childAspectRatio: 2.05,
                        children: [
                          for (final definition
                              in battlefieldDefinitions.values)
                            _BattlefieldCard(
                              key: ValueKey(
                                'battlefield-card-${definition.id.name}',
                              ),
                              definition: definition,
                              selected:
                                  controller.setupBattlefieldId ==
                                  definition.id,
                              onPressed: () =>
                                  controller.setBattlefield(definition.id),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 24),
                    SizedBox(
                      width: 390,
                      child: _BattlefieldDetail(definition: selected),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      localizedUiCopy(
                        context,
                        'Special tiles charge after completed main actions. Active tiles cannot receive a betrayed piece.',
                      ),
                      style: const TextStyle(color: hifiMuted, fontSize: 14),
                    ),
                  ),
                  SizedBox(
                    width: 330,
                    child: HifiPrimaryButton(
                      key: const ValueKey('battlefield-continue'),
                      label: 'Choose Courts',
                      icon: Icons.arrow_forward,
                      large: true,
                      variant: HifiButtonVariant.emerald,
                      onPressed: onContinue,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BattlefieldCard extends StatelessWidget {
  const _BattlefieldCard({
    required this.definition,
    required this.selected,
    required this.onPressed,
    super.key,
  });

  final BattlefieldDefinition definition;
  final bool selected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final palette = _paletteFor(definition.id);
    return Semantics(
      button: true,
      selected: selected,
      label: '${definition.name}. ${definition.shortDescription}',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            decoration: BoxDecoration(
              color: const Color(0xEE0B1115),
              border: Border.all(
                color: selected ? hifiGold : const Color(0xFF4B5253),
                width: selected ? 3 : 1,
              ),
              boxShadow: selected
                  ? const [
                      BoxShadow(
                        color: Color(0x80D5AA50),
                        blurRadius: 18,
                        spreadRadius: 1,
                      ),
                    ]
                  : const [BoxShadow(color: Colors.black54, blurRadius: 12)],
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 6,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: palette,
                          ),
                        ),
                      ),
                      if (definition.thumbnailAsset != null)
                        Image.asset(
                          definition.thumbnailAsset!,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) =>
                              const SizedBox.shrink(),
                        ),
                      DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withValues(alpha: .78),
                            ],
                          ),
                        ),
                      ),
                      Center(
                        child: _BattlefieldMotif(
                          definition: definition,
                          size: 78,
                        ),
                      ),
                      Positioned(
                        left: 14,
                        right: 14,
                        bottom: 10,
                        child: Text(
                          _effectFamilyLabel(context, definition),
                          style: const TextStyle(
                            color: Color(0xFFF0D69C),
                            fontFamily: 'Cinzel',
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: .7,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 5,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 14, 14, 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          localizedDisplayCase(context, definition.name),
                          maxLines: 2,
                          style: const TextStyle(
                            color: hifiInk,
                            fontFamily: 'Cinzel',
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            height: 1.05,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Expanded(
                          child: Text(
                            definition.shortDescription,
                            style: const TextStyle(
                              color: hifiMuted,
                              fontSize: 13,
                              height: 1.3,
                            ),
                          ),
                        ),
                        Row(
                          children: [
                            Icon(
                              selected
                                  ? Icons.check_circle
                                  : Icons.circle_outlined,
                              color: selected ? hifiGold : hifiMuted,
                              size: 18,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              selected
                                  ? localizedDisplayCase(context, 'Selected')
                                  : localizedDisplayCase(context, 'Choose'),
                              style: TextStyle(
                                color: selected ? hifiGold : hifiMuted,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                letterSpacing: .8,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _BattlefieldDetail extends StatelessWidget {
  const _BattlefieldDetail({required this.definition});

  final BattlefieldDefinition definition;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xF20A1116),
        border: Border.all(color: hifiGoldDark, width: 1.5),
        boxShadow: const [BoxShadow(color: Colors.black87, blurRadius: 18)],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(26, 26, 26, 20),
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _BattlefieldMotif(definition: definition, size: 64),
              const SizedBox(height: 16),
              Text(
                localizedDisplayCase(context, definition.name),
                key: const ValueKey('battlefield-detail-title'),
                style: const TextStyle(
                  color: hifiInk,
                  fontFamily: 'Cinzel',
                  fontSize: 25,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                definition.longDescription,
                style: const TextStyle(color: hifiMuted, height: 1.4),
              ),
              const SizedBox(height: 22),
              const Divider(color: hifiGoldDark),
              const SizedBox(height: 14),
              Text(
                _activeCapLabel(context, definition),
                style: const TextStyle(
                  color: hifiGold,
                  fontWeight: FontWeight.w900,
                  letterSpacing: .8,
                ),
              ),
              const SizedBox(height: 16),
              if (!definition.hasMapEffects)
                _EffectLine(
                  icon: Icons.shield_outlined,
                  title: localizedUiCopy(context, 'No battlefield effects'),
                  subtitle: localizedUiCopy(
                    context,
                    'Current board rules remain unchanged.',
                  ),
                )
              else
                for (final type in definition.spawnTypeCycle)
                  _EffectLine(
                    tileType: type,
                    title: specialTileLabel(type),
                    subtitle: _tileDescription(type),
                  ),
              const SizedBox(height: 22),
              Text(
                localizedDisplayCase(context, 'Spawn Law'),
                style: const TextStyle(
                  color: hifiGold,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                definition.spawnLaw,
                style: TextStyle(color: hifiMuted, fontSize: 12, height: 1.35),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EffectLine extends StatelessWidget {
  const _EffectLine({
    required this.title,
    required this.subtitle,
    this.icon,
    this.tileType,
  }) : assert(icon != null || tileType != null);

  final IconData? icon;
  final SpecialTileType? tileType;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (tileType == null)
            Icon(icon, color: const Color(0xFFE0B65C), size: 23)
          else
            DecoratedBox(
              decoration: BoxDecoration(
                color: specialTileDeepColor(tileType!).withValues(alpha: .72),
                border: Border.all(
                  color: specialTileAccent(tileType!).withValues(alpha: .76),
                ),
                borderRadius: BorderRadius.circular(7),
                boxShadow: const [
                  BoxShadow(color: Colors.black54, blurRadius: 6),
                ],
              ),
              child: SpecialTileArt(
                type: tileType!,
                size: 38,
                scale: 1.28,
                artKey: ValueKey('battlefield-effect-art-${tileType!.name}'),
              ),
            ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: hifiInk,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: hifiMuted,
                    fontSize: 12,
                    height: 1.25,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BattlefieldMotif extends StatelessWidget {
  const _BattlefieldMotif({required this.definition, required this.size});

  final BattlefieldDefinition definition;
  final double size;

  @override
  Widget build(BuildContext context) {
    final types = definition.spawnTypeCycle;
    if (types.isEmpty) {
      return Icon(
        Icons.account_balance,
        color: const Color(0xFFF0D58D),
        size: size * .78,
        shadows: const [Shadow(color: Colors.black, blurRadius: 14)],
      );
    }

    final manyTypes = types.length > 2;
    final motifSize = types.length == 1
        ? size
        : manyTypes
        ? size * .42
        : size * .76;
    const manyTypeAlignments = <Alignment>[
      Alignment(0, -1),
      Alignment(-.92, -.15),
      Alignment(0, 0),
      Alignment(.92, -.15),
      Alignment(0, 1),
    ];
    return SizedBox(
      width: types.length == 1
          ? size
          : manyTypes
          ? size * 1.34
          : size * 1.42,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          for (var index = 0; index < types.length; index++)
            Align(
              alignment: types.length == 1
                  ? Alignment.center
                  : manyTypes
                  ? manyTypeAlignments[index]
                  : Alignment(index == 0 ? -.7 : .7, index == 0 ? -.12 : .12),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: specialTileDeepColor(
                    types[index],
                  ).withValues(alpha: .76),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: specialTileAccent(
                      types[index],
                    ).withValues(alpha: .8),
                    width: 1.5,
                  ),
                  boxShadow: const [
                    BoxShadow(color: Colors.black87, blurRadius: 12),
                  ],
                ),
                child: SpecialTileArt(
                  type: types[index],
                  size: motifSize,
                  scale: 1.2,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _SeedBadge extends StatelessWidget {
  const _SeedBadge({required this.hasEffects});

  final bool hasEffects;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xD90B1216),
        border: Border.all(color: hifiGoldDark),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
        child: Row(
          children: [
            Icon(
              hasEffects ? Icons.casino_outlined : Icons.balance_outlined,
              color: hifiGold,
              size: 19,
            ),
            const SizedBox(width: 8),
            Text(
              hasEffects
                  ? localizedDisplayCase(context, 'Seeded and Symmetric')
                  : localizedDisplayCase(context, 'No Map Effect'),
              style: const TextStyle(
                color: hifiInk,
                fontFamily: 'Cinzel',
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

List<Color> _paletteFor(BattlefieldId id) {
  return switch (id) {
    BattlefieldId.classic => const [Color(0xFF252A2D), Color(0xFF07090A)],
    BattlefieldId.verdantPastures => const [
      Color(0xFF55773B),
      Color(0xFF172C1A),
    ],
    BattlefieldId.gildedBazaar => const [Color(0xFF9B6B27), Color(0xFF321711)],
    BattlefieldId.ruinedCauseway => const [
      Color(0xFF59656B),
      Color(0xFF16191E),
    ],
    BattlefieldId.chaosCrucible => const [
      Color(0xFF4B1C69),
      Color(0xFF0B5D64),
      Color(0xFF8D4A16),
    ],
  };
}

String _tileDescription(SpecialTileType type) {
  if (RuntimeGameLocale.isSimplifiedChinese) {
    return switch (type) {
      SpecialTileType.knightShrine => '驻守 3 次行动：除王以外的棋子变为马。',
      SpecialTileType.treasureChest => '驻守 2 次行动：获得 8–50 金币。',
      SpecialTileType.diamondRing => '驻守 3 次行动：强化下一次针对后的报价掷骰。',
      SpecialTileType.visibleTrap => '驻守 2 次行动：驻守棋子阵亡。',
      SpecialTileType.mystery => '驻守 2 次行动：宝藏或陷阱，各半概率。',
    };
  }
  return switch (type) {
    SpecialTileType.knightShrine =>
      'Hold 3 actions: any non-King becomes a Knight.',
    SpecialTileType.treasureChest => 'Hold 2 actions: gain 8–50 gold.',
    SpecialTileType.diamondRing =>
      'Hold 3 actions: empower the next rolled Queen offer.',
    SpecialTileType.visibleTrap => 'Hold 2 actions: the occupying piece dies.',
    SpecialTileType.mystery => 'Hold 2 actions: 50/50 treasure or trap.',
  };
}

String _effectFamilyLabel(
  BuildContext context,
  BattlefieldDefinition definition,
) {
  if (!definition.hasMapEffects) {
    return localizedDisplayCase(context, 'No Map Effect');
  }
  final count = definition.spawnTypeCycle.length;
  return Localizations.localeOf(context).languageCode == 'zh'
      ? '$count 类效果'
      : '$count EFFECT ${count == 1 ? 'FAMILY' : 'FAMILIES'}';
}

String _activeCapLabel(BuildContext context, BattlefieldDefinition definition) {
  if (!definition.hasMapEffects) {
    return Localizations.localeOf(context).languageCode == 'zh'
        ? '标准规则'
        : 'CLASSIC RULESET';
  }
  final separator = Localizations.localeOf(context).languageCode == 'zh'
      ? ' 或 '
      : ' OR ';
  final values = definition.activeCapChoices.join(separator);
  return Localizations.localeOf(context).languageCode == 'zh'
      ? '场上特殊格上限  $values'
      : 'ACTIVE TILE CAP  $values';
}
