import 'package:flutter/material.dart';

import '../../battlefield/battlefield_models.dart';
import '../shared/special_tile_art.dart';

class SpecialTileVisual extends StatelessWidget {
  const SpecialTileVisual({required this.tile, super.key});

  final SpecialTileState tile;

  @override
  Widget build(BuildContext context) {
    final accent = specialTileAccent(tile.type);
    final progress = tile.progress / tile.chargeRequired;
    final occupied = tile.occupantPieceId != null;
    return Semantics(
      label:
          '${specialTileLabel(tile.type)}, charge ${tile.progress} of ${tile.chargeRequired}',
      child: Stack(
        key: ValueKey(
          'special-tile-${tile.square.row}-${tile.square.col}-${tile.type.name}',
        ),
        fit: StackFit.expand,
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _TileSocketPainter(
                type: tile.type,
                accent: accent,
                deepColor: specialTileDeepColor(tile.type),
                occupied: occupied,
              ),
            ),
          ),
          Positioned.fill(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return Center(
                  child: SpecialTileArt(
                    type: tile.type,
                    size: constraints.maxWidth * .8,
                    scale: 1.22,
                    opacity: occupied ? .52 : .98,
                    artKey: ValueKey(
                      'special-tile-art-${tile.square.row}-${tile.square.col}-${tile.type.name}',
                    ),
                  ),
                );
              },
            ),
          ),
          if (tile.type == SpecialTileType.mystery)
            Center(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: const Color(0xE3150D1E),
                  shape: BoxShape.circle,
                  border: Border.all(color: accent, width: 1.8),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withValues(alpha: .55),
                      blurRadius: 9,
                    ),
                  ],
                ),
                child: const SizedBox(
                  width: 30,
                  height: 30,
                  child: Center(
                    child: Text(
                      '?',
                      style: TextStyle(
                        color: Color(0xFFF4E5FF),
                        fontFamily: 'Cinzel',
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                        height: 1,
                        shadows: [Shadow(color: Colors.black, blurRadius: 5)],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          Positioned.fill(
            child: CustomPaint(
              painter: _ChargeRingPainter(
                progress: progress.clamp(0, 1),
                accent: accent,
              ),
            ),
          ),
          Positioned(
            top: 3,
            right: 3,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xF00A0D0F),
                border: Border.all(color: accent, width: 1.2),
                borderRadius: BorderRadius.circular(8),
                boxShadow: const [
                  BoxShadow(color: Colors.black87, blurRadius: 5),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(4, 2, 4, 2),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (var index = 0; index < tile.chargeRequired; index++)
                      Padding(
                        padding: const EdgeInsets.only(right: 1.5),
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: index < tile.progress
                                ? accent
                                : accent.withValues(alpha: .2),
                            border: Border.all(
                              color: accent.withValues(alpha: .72),
                              width: .6,
                            ),
                          ),
                          child: const SizedBox(width: 3, height: 5),
                        ),
                      ),
                    const SizedBox(width: 1),
                    Text(
                      '${tile.progress}/${tile.chargeRequired}',
                      key: ValueKey(
                        'special-tile-charge-${tile.square.row}-${tile.square.col}',
                      ),
                      style: TextStyle(
                        color: accent,
                        fontSize: 7.5,
                        fontWeight: FontWeight.w900,
                        height: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class BattlefieldSquareFlash extends StatelessWidget {
  const BattlefieldSquareFlash({required this.event, super.key});

  final BattlefieldEvent event;

  @override
  Widget build(BuildContext context) {
    final square = event.square;
    if (square == null) {
      return const SizedBox.shrink();
    }
    final accent = _eventAccent(event.type);
    final icon = _eventIcon(event.type);
    final tileType = specialTileTypeForEvent(event.type);
    final reducedMotion =
        MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    return IgnorePointer(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final size = constraints.maxWidth / 8;
          final child = Stack(
            fit: StackFit.expand,
            children: [
              DecoratedBox(
                decoration: BoxDecoration(
                  color: const Color(0xB30A0D0F),
                  border: Border.all(color: accent, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withValues(alpha: .72),
                      blurRadius: 18,
                      spreadRadius: 3,
                    ),
                  ],
                ),
              ),
              Center(
                child: tileType == null
                    ? Icon(icon, color: accent, size: size * .42)
                    : SpecialTileArt(
                        type: tileType,
                        size: size * .72,
                        scale: 1.2,
                      ),
              ),
            ],
          );
          return Stack(
            children: [
              Positioned(
                left: square.col * size,
                top: square.row * size,
                width: size,
                height: size,
                child: reducedMotion
                    ? child
                    : TweenAnimationBuilder<double>(
                        tween: Tween<double>(begin: 0, end: 1),
                        duration: const Duration(milliseconds: 760),
                        curve: Curves.easeOutCubic,
                        builder: (context, animationProgress, _) {
                          return Opacity(
                            opacity: (1 - animationProgress).clamp(0, 1),
                            child: Transform.scale(
                              scale: .72 + animationProgress * .45,
                              child: child,
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _TileSocketPainter extends CustomPainter {
  const _TileSocketPainter({
    required this.type,
    required this.accent,
    required this.deepColor,
    required this.occupied,
  });

  final SpecialTileType type;
  final Color accent;
  final Color deepColor;
  final bool occupied;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = (Offset.zero & size).deflate(3.5);
    final radius = switch (type) {
      SpecialTileType.treasureChest => 5.0,
      SpecialTileType.visibleTrap => 3.0,
      _ => 12.0,
    };
    final socket = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    canvas.drawRRect(
      socket,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            deepColor.withValues(alpha: occupied ? .7 : .9),
            const Color(0xED070A0C),
          ],
        ).createShader(rect),
    );
    canvas.drawRRect(
      socket,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = occupied ? 2.4 : 1.8
        ..color = accent.withValues(alpha: occupied ? .95 : .8),
    );

    final ornament = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..color = accent.withValues(alpha: .82);
    final inset = size.shortestSide * .13;
    final cornerLength = size.shortestSide * .13;

    switch (type) {
      case SpecialTileType.knightShrine:
        ornament.style = PaintingStyle.fill;
        for (final corner in [
          Offset(inset, inset),
          Offset(size.width - inset, inset),
          Offset(inset, size.height - inset),
          Offset(size.width - inset, size.height - inset),
        ]) {
          canvas.drawCircle(corner, 2.4, ornament);
        }
        break;
      case SpecialTileType.treasureChest:
        for (final corner in [
          Offset(inset, inset),
          Offset(size.width - inset, inset),
          Offset(inset, size.height - inset),
          Offset(size.width - inset, size.height - inset),
        ]) {
          canvas.drawRect(
            Rect.fromCenter(center: corner, width: 5.5, height: 5.5),
            ornament,
          );
        }
        break;
      case SpecialTileType.diamondRing:
        canvas.drawCircle(
          Offset(size.width / 2, size.height / 2),
          size.shortestSide * .39,
          ornament,
        );
        break;
      case SpecialTileType.visibleTrap:
        for (var index = 0; index < 3; index++) {
          final x = size.width * (.3 + index * .2);
          canvas.drawLine(Offset(x - 3, inset), Offset(x, inset + 5), ornament);
          canvas.drawLine(Offset(x, inset + 5), Offset(x + 3, inset), ornament);
        }
        break;
      case SpecialTileType.mystery:
        final mysteryRect = Rect.fromCircle(
          center: Offset(size.width / 2, size.height / 2),
          radius: size.shortestSide * .39,
        );
        canvas.drawArc(mysteryRect, -.8, 1.15, false, ornament);
        canvas.drawArc(mysteryRect, 2.35, 1.15, false, ornament);
        break;
    }

    ornament.style = PaintingStyle.stroke;
    for (final start in [
      Offset(inset, inset),
      Offset(size.width - inset, inset),
      Offset(inset, size.height - inset),
      Offset(size.width - inset, size.height - inset),
    ]) {
      final sx = start.dx < size.width / 2 ? 1.0 : -1.0;
      final sy = start.dy < size.height / 2 ? 1.0 : -1.0;
      canvas.drawLine(start, start + Offset(sx * cornerLength, 0), ornament);
      canvas.drawLine(start, start + Offset(0, sy * cornerLength), ornament);
    }
  }

  @override
  bool shouldRepaint(_TileSocketPainter oldDelegate) {
    return type != oldDelegate.type ||
        accent != oldDelegate.accent ||
        deepColor != oldDelegate.deepColor ||
        occupied != oldDelegate.occupied;
  }
}

class _ChargeRingPainter extends CustomPainter {
  const _ChargeRingPainter({required this.progress, required this.accent});

  final double progress;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final center = rect.center;
    final radius = size.shortestSide * .455;
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5.4
        ..color = Colors.black.withValues(alpha: .72),
    );
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3.2
        ..color = accent.withValues(alpha: .22),
    );
    if (progress > 0) {
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        -1.5708,
        6.2832 * progress,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeWidth = 4.1
          ..color = accent,
      );
    }
  }

  @override
  bool shouldRepaint(_ChargeRingPainter oldDelegate) {
    return progress != oldDelegate.progress || accent != oldDelegate.accent;
  }
}

Color _eventAccent(BattlefieldEventType type) {
  final tileType = specialTileTypeForEvent(type);
  return tileType == null
      ? const Color(0xFFD49BFF)
      : specialTileAccent(tileType);
}

IconData _eventIcon(BattlefieldEventType type) {
  return switch (type) {
    BattlefieldEventType.kingGuarded => Icons.shield_outlined,
    BattlefieldEventType.tilesSpawned => Icons.auto_awesome,
    _ => Icons.auto_awesome,
  };
}
