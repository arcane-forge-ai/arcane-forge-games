import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../battlefield/battlefield_models.dart';
import '../../domain/chess_models.dart';
import '../../living_campaign/living_campaign_controller.dart';
import '../../living_campaign/living_campaign_models.dart';
import '../../living_campaign/living_portrait_resolver.dart';
import '../../living_campaign/living_campaign_settings.dart';
import '../../l10n/runtime_game_locale.dart';
import '../../l10n/ui_copy.dart';
import '../board/board_presentation_coordinator.dart';
import '../match/match_screen.dart';
import '../menu/hifi_menu_widgets.dart';
import '../shared/piece_art.dart';

const _livingBackdrop = 'assets/runtime/scenes/setup/s02_lobby_court_bg.webp';

class LivingCampaignHubScreen extends StatelessWidget {
  const LivingCampaignHubScreen({
    required this.controller,
    required this.settings,
    required this.onBack,
    required this.onPlayAnotherMode,
    required this.onSettings,
    this.allowUnconfiguredGeneration = false,
    super.key,
  });

  final LivingCampaignController controller;
  final EffectiveLivingCampaignSettings settings;
  final VoidCallback onBack;
  final VoidCallback onPlayAnotherMode;
  final VoidCallback onSettings;
  final bool allowUnconfiguredGeneration;

  bool get _canGenerate =>
      allowUnconfiguredGeneration || settings.values.hasApiKey;

  @override
  Widget build(BuildContext context) {
    final active = controller.activeRun;
    final storageBytes = controller.storageBytes;
    return HifiScaffold(
      key: const ValueKey('living-campaign-hub'),
      backdropAsset: _livingBackdrop,
      backdropOpacity: .42,
      showDefaultScrims: false,
      child: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xF20A0E12), Color(0xD3261C18), Color(0xF207090C)],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(54, 38, 54, 34),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  IconButton(
                    key: const ValueKey('living-hub-back'),
                    onPressed: onBack,
                    color: hifiMuted,
                    icon: const Icon(Icons.arrow_back),
                    tooltip: localizedUiCopy(context, 'Back to Mode Select'),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        appLocalizationsOf(context).modeLivingCampaign,
                        style: const TextStyle(
                          color: hifiGold,
                          fontFamily: 'Cinzel',
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2.5,
                        ),
                      ),
                      Text(
                        localizedDisplayCase(context, 'The Story Remembers'),
                        style: const TextStyle(
                          color: Colors.white,
                          fontFamily: 'Cinzel',
                          fontSize: 34,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Text(
                    Localizations.localeOf(context).languageCode == 'zh'
                        ? '${_formatBytes(storageBytes)} 本地存储'
                        : '${_formatBytes(storageBytes)} LOCAL',
                    style: const TextStyle(color: hifiMuted),
                  ),
                  const SizedBox(width: 18),
                  OutlinedButton.icon(
                    key: const ValueKey('living-hub-settings'),
                    onPressed: onSettings,
                    icon: const Icon(Icons.key),
                    label: Text(localizedUiCopy(context, 'Living AI Settings')),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              if (!_canGenerate)
                _NoticePanel(
                  icon: Icons.key_off,
                  text: localizedUiCopy(
                    context,
                    'Ark is not configured. You can play fixed Mission 01, but must add a local API key before scripting Mission 02.',
                  ),
                  actionLabel: 'Open Settings',
                  onAction: onSettings,
                )
              else if (controller.message != null)
                _NoticePanel(
                  icon: controller.hasInterruptedGeneration
                      ? Icons.pause_circle_outline
                      : Icons.info_outline,
                  text: localizedUiCopy(context, controller.message!),
                ),
              const SizedBox(height: 14),
              Expanded(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 6,
                      child: _ActiveRunPanel(
                        run: active,
                        controller: controller,
                        canGenerate: _canGenerate,
                        onContinue: controller.openActiveRun,
                        onResume: () =>
                            unawaited(controller.resumeGeneration()),
                        onRetryPortrait: () =>
                            unawaited(_retryPortrait(context)),
                        onHistory: active == null
                            ? null
                            : () => unawaited(
                                controller.inspectRun(active.runId),
                              ),
                        onNew: () => _startNew(context),
                        onPlayAnotherMode: onPlayAnotherMode,
                        onAbandon: active == null
                            ? null
                            : () => _abandon(context),
                      ),
                    ),
                    const SizedBox(width: 22),
                    Expanded(
                      flex: 4,
                      child: _ArchivePanel(controller: controller),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _startNew(BuildContext context) async {
    final active = controller.activeRun;
    var abandon = false;
    if (active != null && active.status == LivingRunStatus.active) {
      abandon =
          await showDialog<bool>(
            context: context,
            builder: (dialogContext) => AlertDialog(
              title: Text(localizedUiCopy(context, 'Abandon active story?')),
              content: Text(
                localizedUiCopy(
                  context,
                  'The current run will remain in local archives as abandoned. This cannot be undone without deleting that archive.',
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: Text(localizedUiCopy(context, 'Keep Current Run')),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(dialogContext, true),
                  child: Text(localizedUiCopy(context, 'Abandon and Begin')),
                ),
              ],
            ),
          ) ??
          false;
      if (!abandon) return;
    }
    await controller.startNewRun(abandonExisting: abandon);
  }

  Future<void> _retryPortrait(BuildContext context) async {
    final confirmed =
        await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: Text(localizedUiCopy(context, 'Retry portrait generation?')),
            content: Text(
              localizedUiCopy(
                context,
                'This makes one new paid Seedream request for the same character. It will not retry automatically if interrupted or rejected.',
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: Text(localizedUiCopy(context, 'Keep Fallback')),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: Text(localizedUiCopy(context, 'Authorize Retry')),
              ),
            ],
          ),
        ) ??
        false;
    if (confirmed) await controller.retryPortrait();
  }

  Future<void> _abandon(BuildContext context) async {
    final confirmed =
        await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: Text(
              localizedUiCopy(context, 'Abandon this Living Campaign?'),
            ),
            content: Text(
              localizedUiCopy(
                context,
                'The run will stop progressing but remain available in local archives until you delete it.',
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: Text(localizedUiCopy(context, 'Cancel')),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: Text(localizedUiCopy(context, 'Abandon Run')),
              ),
            ],
          ),
        ) ??
        false;
    if (confirmed) await controller.abandonActiveRun();
  }
}

class LivingCampaignPrologueScreen extends StatelessWidget {
  const LivingCampaignPrologueScreen({
    required this.controller,
    required this.onHub,
    super.key,
  });

  final LivingCampaignController controller;
  final VoidCallback onHub;

  @override
  Widget build(BuildContext context) {
    final run = controller.activeRun!;
    return _LivingTextScreen(
      key: const ValueKey('living-campaign-prologue'),
      eyebrow: 'A NEW LIVING CAMPAIGN',
      title: run.campaignTitle,
      subtitle: run.storyPromise,
      body: run.prologue,
      primaryLabel: 'Begin Chapter 1',
      onPrimary: controller.continueFromPrologue,
      secondaryLabel: 'Run Archive',
      onSecondary: onHub,
    );
  }
}

class LivingCampaignDialogueScreen extends StatelessWidget {
  const LivingCampaignDialogueScreen({
    required this.controller,
    required this.onHub,
    super.key,
  });

  final LivingCampaignController controller;
  final VoidCallback onHub;

  @override
  Widget build(BuildContext context) {
    final chapter = controller.activeChapter!;
    final index = controller.dialogueIndex.clamp(
      0,
      chapter.dialogue.length - 1,
    );
    final line = chapter.dialogue[index];
    final character =
        controller.activeRun!.canon.charactersById[line.speakerId];
    final speaker = character?.originalName ?? line.speakerId;
    final matchingPieces = chapter.pieces
        .where((piece) => piece.characterId == line.speakerId)
        .toList(growable: false);
    final pieceType =
        character?.basePieceType ?? matchingPieces.firstOrNull?.pieceType;
    final countryId = matchingPieces.firstOrNull?.countryId ?? 'ashen';
    final portrait = _LivingPortrait(
      controller: controller,
      characterId: line.speakerId,
      characterName: speaker,
      pieceType: pieceType,
      countryId: countryId,
    );
    final dialoguePanel = Container(
      width: 850,
      margin: const EdgeInsets.only(bottom: 48),
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 24),
      decoration: BoxDecoration(
        color: const Color(0xF20A0E12),
        border: Border.all(color: hifiGoldDark, width: 2),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            speaker.toUpperCase(),
            style: const TextStyle(
              color: hifiGold,
              fontFamily: 'Cinzel',
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.4,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            line.text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 22),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              TextButton.icon(
                key: const ValueKey('living-dialogue-backlog'),
                onPressed: () => _showBacklog(context, chapter, index),
                icon: const Icon(Icons.history),
                label: Text(localizedUiCopy(context, 'Backlog')),
              ),
              TextButton(
                onPressed: onHub,
                child: Text(localizedUiCopy(context, 'Run Archive')),
              ),
              TextButton(
                onPressed: controller.skipDialogue,
                child: Text(localizedUiCopy(context, 'Skip to Briefing')),
              ),
              FilledButton.icon(
                key: const ValueKey('living-dialogue-next'),
                onPressed: controller.advanceDialogue,
                icon: Icon(
                  index == chapter.dialogue.length - 1
                      ? Icons.flag_outlined
                      : Icons.arrow_forward,
                ),
                label: Text(
                  localizedUiCopy(
                    context,
                    index == chapter.dialogue.length - 1
                        ? 'Mission Briefing'
                        : 'Continue',
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
    return HifiScaffold(
      key: const ValueKey('living-campaign-dialogue'),
      backdropAsset: _livingBackdrop,
      backdropOpacity: .5,
      child: Stack(
        children: [
          Positioned(
            left: line.side == 'left' ? 40 : null,
            right: line.side == 'right' ? 40 : null,
            top: 70,
            bottom: 70,
            width: 610,
            child: portrait,
          ),
          Positioned(
            left: line.side == 'left' ? null : 84,
            right: line.side == 'left' ? 84 : null,
            bottom: 24,
            child: dialoguePanel,
          ),
          Positioned(
            left: 48,
            top: 38,
            child: Text(
              Localizations.localeOf(context).languageCode == 'zh'
                  ? '第 ${chapter.chapterNumber} 章 · ${chapter.title}'
                  : 'CHAPTER ${chapter.chapterNumber} · ${chapter.title}',
              style: const TextStyle(
                color: hifiGold,
                fontFamily: 'Cinzel',
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showBacklog(
    BuildContext context,
    LivingChapterPackage chapter,
    int currentIndex,
  ) => showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      key: const ValueKey('living-dialogue-backlog-dialog'),
      title: Text(
        Localizations.localeOf(context).languageCode == 'zh'
            ? '第 ${chapter.chapterNumber} 章对话回顾'
            : 'Chapter ${chapter.chapterNumber} Dialogue Backlog',
      ),
      content: SizedBox(
        width: 760,
        height: 430,
        child: ListView.separated(
          itemCount: currentIndex + 1,
          separatorBuilder: (_, _) => const Divider(),
          itemBuilder: (_, index) {
            final item = chapter.dialogue[index];
            final name =
                controller
                    .activeRun!
                    .canon
                    .charactersById[item.speakerId]
                    ?.originalName ??
                item.speakerId;
            return ListTile(
              title: Text(name),
              subtitle: SelectableText(item.text),
            );
          },
        ),
      ),
      actions: [
        FilledButton(
          onPressed: () => Navigator.pop(dialogContext),
          child: Text(localizedUiCopy(context, 'Return')),
        ),
      ],
    ),
  );
}

class LivingCampaignAftermathScreen extends StatelessWidget {
  const LivingCampaignAftermathScreen({required this.controller, super.key});

  final LivingCampaignController controller;

  @override
  Widget build(BuildContext context) {
    final scene = controller.activeAftermathScene!;
    final run = controller.activeRun!;
    final index = controller.dialogueIndex.clamp(0, scene.lines.length - 1);
    final line = scene.lines[index];
    final character = line.speakerId == null
        ? null
        : run.canon.charactersById[line.speakerId];
    final named = line.speakerId == null
        ? null
        : run.namedPiecesByName.values
              .where((record) => record.characterId == line.speakerId)
              .firstOrNull;
    final speaker = line.speakerId == null
        ? localizedDisplayCase(context, 'The Field')
        : named?.name ??
              character?.originalName ??
              localizedDisplayCase(context, 'A Voice in the Ash');
    final pieceType = named?.pieceType ?? character?.basePieceType;
    final countryId = character?.allegiance == LivingAllegiance.enemy
        ? 'iron'
        : 'ashen';
    final panel = Container(
      width: 860,
      margin: const EdgeInsets.only(bottom: 48),
      padding: const EdgeInsets.fromLTRB(34, 25, 34, 25),
      decoration: BoxDecoration(
        color: const Color(0xF20A0E12),
        border: Border.all(color: hifiGoldDark, width: 2),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: line.speakerId == null
            ? CrossAxisAlignment.center
            : CrossAxisAlignment.start,
        children: [
          Text(
            speaker.toUpperCase(),
            textAlign: line.speakerId == null ? TextAlign.center : null,
            style: const TextStyle(
              color: hifiGold,
              fontFamily: 'Cinzel',
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.4,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            line.text,
            textAlign: line.speakerId == null ? TextAlign.center : null,
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              height: 1.5,
              fontStyle: line.speakerId == null
                  ? FontStyle.italic
                  : FontStyle.normal,
            ),
          ),
          const SizedBox(height: 22),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              TextButton.icon(
                key: const ValueKey('living-aftermath-backlog'),
                onPressed: () => _showBacklog(context, scene, index),
                icon: const Icon(Icons.history),
                label: Text(localizedUiCopy(context, 'Backlog')),
              ),
              TextButton(
                onPressed: controller.skipAftermath,
                child: Text(localizedUiCopy(context, 'Skip')),
              ),
              FilledButton.icon(
                key: const ValueKey('living-aftermath-next'),
                onPressed: controller.advanceAftermath,
                icon: Icon(
                  index == scene.lines.length - 1
                      ? Icons.auto_stories
                      : Icons.arrow_forward,
                ),
                label: Text(
                  localizedUiCopy(
                    context,
                    index == scene.lines.length - 1
                        ? 'Remember This Field'
                        : 'Continue',
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
    return HifiScaffold(
      key: const ValueKey('living-campaign-aftermath'),
      backdropAsset: _livingBackdrop,
      backdropOpacity: .48,
      child: Stack(
        children: [
          if (line.speakerId != null && pieceType != null)
            Positioned(
              left: line.side == 'left' ? 40 : null,
              right: line.side == 'right' ? 40 : null,
              top: 70,
              bottom: 70,
              width: 610,
              child: _LivingPortrait(
                controller: controller,
                characterId: line.speakerId!,
                characterName: speaker,
                pieceType: pieceType,
                countryId: countryId,
              ),
            ),
          Positioned(
            left: line.side == 'left'
                ? null
                : line.side == 'center'
                ? 0
                : 84,
            right: line.side == 'right'
                ? null
                : line.side == 'center'
                ? 0
                : 84,
            bottom: 24,
            child: line.side == 'center' ? Center(child: panel) : panel,
          ),
          Positioned(
            left: 48,
            top: 38,
            child: Text(
              Localizations.localeOf(context).languageCode == 'zh'
                  ? '第 ${scene.missionNumber} 章 · 战后余波'
                  : 'CHAPTER ${scene.missionNumber} · AFTERMATH',
              style: const TextStyle(
                color: hifiGold,
                fontFamily: 'Cinzel',
                fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showBacklog(
    BuildContext context,
    LivingAftermathScene scene,
    int currentIndex,
  ) => showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      key: const ValueKey('living-aftermath-backlog-dialog'),
      title: Text(
        Localizations.localeOf(context).languageCode == 'zh'
            ? '第 ${scene.missionNumber} 章战后余波'
            : 'Chapter ${scene.missionNumber} Aftermath',
      ),
      content: SizedBox(
        width: 760,
        height: 430,
        child: ListView.separated(
          itemCount: currentIndex + 1,
          separatorBuilder: (_, _) => const Divider(),
          itemBuilder: (_, itemIndex) {
            final item = scene.lines[itemIndex];
            final name = item.speakerId == null
                ? localizedUiCopy(context, 'The Field')
                : controller
                          .activeRun!
                          .canon
                          .charactersById[item.speakerId]
                          ?.originalName ??
                      'A Voice in the Ash';
            return ListTile(
              title: Text(name),
              subtitle: SelectableText(item.text),
            );
          },
        ),
      ),
      actions: [
        FilledButton(
          onPressed: () => Navigator.pop(dialogContext),
          child: Text(localizedUiCopy(context, 'Return')),
        ),
      ],
    ),
  );
}

class _LivingPortrait extends StatelessWidget {
  const _LivingPortrait({
    required this.controller,
    required this.characterId,
    required this.characterName,
    required this.pieceType,
    required this.countryId,
  });

  final LivingCampaignController controller;
  final String characterId;
  final String characterName;
  final PieceType? pieceType;
  final String countryId;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Uint8List?>(
      future: controller.portraitBytes(characterId),
      builder: (context, snapshot) {
        final bytes = snapshot.data;
        if (bytes != null) {
          return Image.memory(
            bytes,
            fit: BoxFit.contain,
            alignment: Alignment.bottomCenter,
            filterQuality: FilterQuality.high,
            gaplessPlayback: true,
          );
        }
        final neutralFallback = pieceType == null
            ? null
            : LivingPortraitFallbackResolver.neutralAsset(
                pieceType!,
                stableKey:
                    '${(controller.activeRun ?? controller.inspectedRun)?.runId ?? 'no-run'}:$characterId',
              );
        if (neutralFallback != null) {
          return Opacity(
            opacity: .86,
            child: Image.asset(
              neutralFallback,
              key: ValueKey(neutralFallback),
              fit: BoxFit.contain,
              alignment: Alignment.bottomCenter,
              filterQuality: FilterQuality.high,
              errorBuilder: (context, error, stackTrace) => PieceArtImage(
                countryId: countryId,
                type: pieceType!,
                kind: PieceArtKind.portrait,
                fit: BoxFit.contain,
                alignment: Alignment.bottomCenter,
              ),
            ),
          );
        }
        return Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            width: 360,
            height: 500,
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: const Color(0xC912171B),
              border: Border.all(color: hifiGoldDark),
              borderRadius: BorderRadius.circular(180),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.person_outline, color: hifiGold, size: 120),
                const SizedBox(height: 18),
                Text(
                  characterName,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Cinzel',
                    fontSize: 22,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Portrait awaiting approved art promotion',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: hifiMuted, fontSize: 12),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class LivingCampaignHistoryScreen extends StatelessWidget {
  const LivingCampaignHistoryScreen({
    required this.controller,
    this.showDiagnostics = false,
    super.key,
  });

  final LivingCampaignController controller;
  final bool showDiagnostics;

  @override
  Widget build(BuildContext context) {
    final run = controller.inspectedRun!;
    final canon = run.canon;
    return DefaultTabController(
      length: showDiagnostics ? 5 : 4,
      child: HifiScaffold(
        key: const ValueKey('living-campaign-history'),
        backdropAsset: _livingBackdrop,
        backdropOpacity: .3,
        showDefaultScrims: false,
        child: Material(
          color: const Color(0xF20A0E12),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(52, 34, 52, 34),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    IconButton(
                      key: const ValueKey('living-history-back'),
                      onPressed: controller.closeHistory,
                      icon: const Icon(Icons.arrow_back),
                      color: hifiMuted,
                      tooltip: localizedUiCopy(
                        context,
                        'Back to Living Campaign hub',
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            run.campaignTitle,
                            style: const TextStyle(
                              color: Colors.white,
                              fontFamily: 'Cinzel',
                              fontSize: 30,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          Text(
                            Localizations.localeOf(context).languageCode == 'zh'
                                ? '${_livingRunStatusLabel(context, run.status)} · 正史修订 ${canon.revision} · ${_formatBytes(controller.storageBytes)} 本地存储'
                                : '${run.status.name.toUpperCase()} · canon revision ${canon.revision} · ${_formatBytes(controller.storageBytes)} local',
                            style: const TextStyle(color: hifiMuted),
                          ),
                        ],
                      ),
                    ),
                    _RunMetric('GOLD', '${canon.gold}'),
                    const SizedBox(width: 28),
                    _RunMetric(
                      'ROSTER',
                      '${canon.playerRosterByPieceId.length}',
                    ),
                    const SizedBox(width: 28),
                    _RunMetric('CHARACTERS', '${canon.charactersById.length}'),
                  ],
                ),
                const SizedBox(height: 22),
                TabBar(
                  isScrollable: true,
                  tabAlignment: TabAlignment.start,
                  indicatorColor: hifiGold,
                  labelColor: hifiGold,
                  unselectedLabelColor: hifiMuted,
                  tabs: <Widget>[
                    Tab(text: localizedDisplayCase(context, 'Chapters')),
                    Tab(
                      key: const ValueKey('living-history-tab-characters'),
                      text: localizedDisplayCase(context, 'Characters'),
                    ),
                    Tab(
                      text: localizedDisplayCase(context, 'Unfinished Tales'),
                    ),
                    Tab(text: localizedDisplayCase(context, 'Events & Facts')),
                    if (showDiagnostics)
                      Tab(
                        text: localizedDisplayCase(
                          context,
                          'Generation Records',
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: TabBarView(
                    children: <Widget>[
                      _ChapterHistory(run: run, controller: controller),
                      _CharacterHistory(run: run, controller: controller),
                      _ThreadHistory(run: run),
                      _EventFactHistory(run: run),
                      if (showDiagnostics) _GenerationHistory(run: run),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ChapterHistory extends StatelessWidget {
  const _ChapterHistory({required this.run, required this.controller});
  final LivingCampaignRun run;
  final LivingCampaignController controller;

  @override
  Widget build(BuildContext context) {
    final chapters =
        run.chapterPackages
            .where(
              (chapter) => run.battleOutcomes.any(
                (outcome) => outcome.chapterId == chapter.chapterId,
              ),
            )
            .toList()
          ..sort((a, b) => a.chapterNumber.compareTo(b.chapterNumber));
    if (chapters.isEmpty) {
      return const _HistoryEmpty('No completed chapter has entered canon yet.');
    }
    return _HistoryList(
      children: chapters
          .map(
            (chapter) => _ChapterReviewCard(
              run: run,
              chapter: chapter,
              controller: controller,
            ),
          )
          .toList(),
    );
  }
}

class _CharacterHistory extends StatelessWidget {
  const _CharacterHistory({required this.run, required this.controller});
  final LivingCampaignRun run;
  final LivingCampaignController controller;

  @override
  Widget build(BuildContext context) {
    final characters = run.canon.charactersById.values.toList()
      ..sort(
        (a, b) => a.firstChapter != b.firstChapter
            ? a.firstChapter.compareTo(b.firstChapter)
            : a.originalName.compareTo(b.originalName),
      );
    return _HistoryList(
      children: characters
          .map(
            (character) => _CharacterReviewCard(
              character: character,
              run: run,
              controller: controller,
            ),
          )
          .toList(),
    );
  }
}

class _ThreadHistory extends StatelessWidget {
  const _ThreadHistory({required this.run});
  final LivingCampaignRun run;

  @override
  Widget build(BuildContext context) {
    final threads = run.canon.storyThreadsById.values.toList()
      ..sort((a, b) => a.openedChapter.compareTo(b.openedChapter));
    if (threads.isEmpty) {
      return const _HistoryEmpty(
        'No unresolved promise, mystery, conflict, or relationship is waiting.',
      );
    }
    final isChinese = Localizations.localeOf(context).languageCode == 'zh';
    return _HistoryList(
      children: threads
          .map(
            (thread) => _HistoryCard(
              title: thread.title,
              subtitle: isChinese
                  ? '${thread.status == LivingThreadStatus.open ? '仍在发展' : '已解决'} · 第 ${thread.openedChapter} 章开启'
                        '${thread.resolvedChapter == null ? '' : ' · 第 ${thread.resolvedChapter} 章解决'}'
                  : '${thread.status == LivingThreadStatus.open ? 'Still unfolding' : 'Resolved'} · opened Chapter '
                        '${thread.openedChapter}'
                        '${thread.resolvedChapter == null ? '' : ' · resolved Chapter ${thread.resolvedChapter}'}',
              body: isChinese
                  ? '${thread.summary}\n涉及人物：'
                        '${thread.participantIds.map((id) => run.canon.charactersById[id]?.originalName).whereType<String>().join('、')}'
                  : '${thread.summary}\nInvolves: '
                        '${thread.participantIds.map((id) => run.canon.charactersById[id]?.originalName).whereType<String>().join(', ')}',
            ),
          )
          .toList(),
    );
  }
}

class _EventFactHistory extends StatelessWidget {
  const _EventFactHistory({required this.run});
  final LivingCampaignRun run;

  @override
  Widget build(BuildContext context) {
    final isChinese = Localizations.localeOf(context).languageCode == 'zh';
    final events = run.canon.eventLedger.toList()
      ..sort((a, b) => a.chapterNumber.compareTo(b.chapterNumber));
    final facts = run.canon.canonFactsById.values.toList()
      ..sort((a, b) => a.chapterNumber.compareTo(b.chapterNumber));
    final cards = <Widget>[
      ...events.map(
        (event) => _HistoryCard(
          title: isChinese
              ? '第 ${event.chapterNumber} 章 · ${_storyEventLabel(event.type)}'
              : 'Chapter ${event.chapterNumber} · ${_storyEventLabel(event.type)}',
          subtitle: localizedUiCopy(context, 'Remembered event'),
          body: event.description,
        ),
      ),
      ...facts.map(
        (fact) => _HistoryCard(
          title: isChinese
              ? '第 ${fact.chapterNumber} 章 · ${fact.kind == LivingFactKind.verified ? '已知事实' : '低语传闻'}'
              : 'Chapter ${fact.chapterNumber} · ${fact.kind == LivingFactKind.verified ? 'Known truth' : 'Whispered belief'}',
          subtitle: localizedUiCopy(context, 'Part of the living canon'),
          body: fact.statement,
        ),
      ),
    ];
    if (cards.isEmpty) {
      return const _HistoryEmpty('No events or facts recorded.');
    }
    return _HistoryList(children: cards);
  }
}

class _GenerationHistory extends StatelessWidget {
  const _GenerationHistory({required this.run});
  final LivingCampaignRun run;

  @override
  Widget build(BuildContext context) {
    if (run.generationRecords.isEmpty) {
      return const _HistoryEmpty('No provider requests are recorded.');
    }
    return _HistoryList(
      children:
          (run.generationRecords.toList()
                ..sort((a, b) => a.startedAt.compareTo(b.startedAt)))
              .map(
                (record) => _HistoryCard(
                  title:
                      '${record.stage.name} · attempt ${record.attempt} · '
                      '${record.status.name}',
                  subtitle:
                      '${record.model} · ${record.providerRequestId ?? 'no request id'}',
                  body:
                      'Started ${record.startedAt.toLocal()}\n'
                      '${record.errorMessage ?? 'Validated local record retained.'}'
                      '${record.validationWarnings.isEmpty ? '' : '\nWarnings: ${record.validationWarnings.join(' · ')}'}',
                ),
              )
              .toList(),
    );
  }
}

class _ChapterReviewCard extends StatelessWidget {
  const _ChapterReviewCard({
    required this.run,
    required this.chapter,
    required this.controller,
  });

  final LivingCampaignRun run;
  final LivingChapterPackage chapter;
  final LivingCampaignController controller;

  @override
  Widget build(BuildContext context) {
    final outcome = run.battleOutcomes
        .where((candidate) => candidate.chapterId == chapter.chapterId)
        .firstOrNull;
    final memory = run.missionMemories
        .where((candidate) => candidate.missionId == chapter.chapterId)
        .firstOrNull;
    final aftermath = run.aftermathScenesByChapterId[chapter.chapterId];
    final isChinese = Localizations.localeOf(context).languageCode == 'zh';
    return Container(
      key: ValueKey('living-history-chapter-${chapter.chapterNumber}'),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xD914191D),
        border: Border.all(color: const Color(0xFF493D2A)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            isChinese
                ? '第 ${chapter.chapterNumber} 章 · ${chapter.title}'
                : 'Chapter ${chapter.chapterNumber} · ${chapter.title}',
            style: const TextStyle(
              color: Colors.white,
              fontFamily: 'Cinzel',
              fontSize: 19,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '${outcome == null ? (isChinese ? '未解决' : 'UNRESOLVED') : _livingBattleResultLabel(context, outcome.result)} · ${chapter.objective.label}',
            style: const TextStyle(color: hifiGold, fontSize: 12),
          ),
          const SizedBox(height: 16),
          Text(
            localizedDisplayCase(context, 'Setup Story'),
            style: const TextStyle(
              color: hifiGold,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          SelectableText(
            chapter.briefing,
            style: const TextStyle(color: hifiMuted, height: 1.5),
          ),
          const SizedBox(height: 10),
          Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              key: ValueKey('living-history-dialogue-${chapter.chapterNumber}'),
              tilePadding: EdgeInsets.zero,
              childrenPadding: const EdgeInsets.only(bottom: 8),
              iconColor: hifiGold,
              collapsedIconColor: hifiMuted,
              title: Text(
                localizedDisplayCase(context, 'Pre-Battle Conversation'),
                style: const TextStyle(
                  color: hifiGold,
                  fontWeight: FontWeight.w900,
                ),
              ),
              children: chapter.dialogue
                  .map((line) {
                    final speaker = run.canon.charactersById[line.speakerId];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 180,
                            child: Text(
                              speaker?.originalName ??
                                  localizedUiCopy(context, 'Unknown voice'),
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Text(
                              line.text,
                              style: const TextStyle(
                                color: hifiMuted,
                                height: 1.4,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  })
                  .toList(growable: false),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            localizedDisplayCase(context, 'Battle Summary'),
            style: const TextStyle(
              color: hifiGold,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            memory?.battleSummary ??
                (isChinese
                    ? '战斗以${outcome == null ? '未知结果' : _livingBattleResultLabel(context, outcome.result)}结束，共进行 ${outcome?.completedRoundCount ?? 0} 个完整回合。'
                    : '${outcome?.result.name ?? 'The battle ended'} after ${outcome?.completedRoundCount ?? 0} full rounds.'),
            style: const TextStyle(color: hifiMuted, height: 1.5),
          ),
          if (aftermath != null && aftermath.lines.isNotEmpty) ...[
            const SizedBox(height: 10),
            Theme(
              data: Theme.of(
                context,
              ).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                key: ValueKey(
                  'living-history-aftermath-${chapter.chapterNumber}',
                ),
                tilePadding: EdgeInsets.zero,
                childrenPadding: const EdgeInsets.only(bottom: 8),
                iconColor: hifiGold,
                collapsedIconColor: hifiMuted,
                title: Text(
                  localizedDisplayCase(context, 'Aftermath'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                children: aftermath.lines
                    .map((line) {
                      final speaker = line.speakerId == null
                          ? localizedUiCopy(context, 'The Field')
                          : run
                                    .canon
                                    .charactersById[line.speakerId]
                                    ?.originalName ??
                                localizedUiCopy(context, 'A Voice in the Ash');
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 180,
                              child: Text(
                                speaker,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Text(
                                line.text,
                                style: const TextStyle(
                                  color: hifiMuted,
                                  height: 1.4,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    })
                    .toList(growable: false),
              ),
            ),
          ],
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: FutureBuilder<Uint8List?>(
                future: controller.chapterArtBytes(chapter.chapterId),
                builder: (context, snapshot) => snapshot.data == null
                    ? Image.asset(
                        _livingBackdrop,
                        fit: BoxFit.cover,
                        key: ValueKey(
                          'living-history-chapter-art-fallback-${chapter.chapterNumber}',
                        ),
                      )
                    : Image.memory(
                        snapshot.data!,
                        fit: BoxFit.cover,
                        gaplessPlayback: true,
                        key: ValueKey(
                          'living-history-chapter-art-${chapter.chapterNumber}',
                        ),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CharacterReviewCard extends StatelessWidget {
  const _CharacterReviewCard({
    required this.character,
    required this.run,
    required this.controller,
  });

  final LivingCharacter character;
  final LivingCampaignRun run;
  final LivingCampaignController controller;

  @override
  Widget build(BuildContext context) {
    final named = run.namedPiecesByName.values
        .where((record) => record.characterId == character.characterId)
        .firstOrNull;
    final checkpoint =
        run.portraitCheckpointsByCharacterId[character.characterId];
    final countryId = character.allegiance == LivingAllegiance.player
        ? 'ashen'
        : 'iron';
    final isChinese = Localizations.localeOf(context).languageCode == 'zh';
    return Container(
      key: ValueKey('living-history-character-${character.characterId}'),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xD914191D),
        border: Border.all(color: const Color(0xFF493D2A)),
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            height: 180,
            child: FutureBuilder<Uint8List?>(
              future: controller.portraitBytes(character.characterId),
              builder: (context, snapshot) {
                if (snapshot.data != null) {
                  return Image.memory(
                    snapshot.data!,
                    fit: BoxFit.contain,
                    alignment: Alignment.bottomCenter,
                  );
                }
                final authored =
                    character.portraitPath?.startsWith('assets/') == true
                    ? character.portraitPath
                    : LivingPortraitFallbackResolver.fixedAsset(
                            character.characterId,
                          ) ??
                          LivingPortraitFallbackResolver.neutralAsset(
                            character.basePieceType,
                            stableKey:
                                '${run.runId}:${character.characterId}:archive',
                          );
                return authored == null
                    ? const Icon(
                        Icons.person_outline,
                        color: hifiMuted,
                        size: 72,
                      )
                    : Image.asset(
                        authored,
                        fit: BoxFit.contain,
                        alignment: Alignment.bottomCenter,
                      );
              },
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  character.originalName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Cinzel',
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${_storyEnumLabel(character.lifeState.name)} · '
                  '${_storyEnumLabel(character.whereabouts.name)} · '
                  '${_storyEnumLabel(character.allegiance.name)}',
                  style: const TextStyle(color: hifiGold, fontSize: 12),
                ),
                const SizedBox(height: 10),
                Text(
                  character.originalIdentity,
                  style: const TextStyle(color: hifiMuted, height: 1.4),
                ),
                if (named?.loyalty case final loyalty?) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Loyalty $loyalty',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                Row(
                  children: [
                    SizedBox(
                      width: 54,
                      height: 54,
                      child: PieceArtImage(
                        countryId: countryId,
                        type: character.basePieceType,
                        kind: PieceArtKind.token,
                        color: character.allegiance == LivingAllegiance.player
                            ? PieceColor.white
                            : PieceColor.black,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        isChinese
                            ? '${_storyEnumLabel(character.basePieceType.name)}棋子图 · '
                                  '${checkpoint == null ? localizedUiCopy(context, 'Authored or class fallback portrait') : '肖像第 ${checkpoint.attempt} 次尝试：${_storyEnumLabel(checkpoint.status.name)}'}'
                            : '${_storyEnumLabel(character.basePieceType.name)} piece art · '
                                  '${checkpoint == null ? 'Authored or class fallback portrait' : 'Portrait attempt ${checkpoint.attempt}: ${_storyEnumLabel(checkpoint.status.name)}'}',
                        style: const TextStyle(
                          color: hifiMuted,
                          fontSize: 12,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

String _storyEventLabel(LivingEventType type) => _storyEnumLabel(type.name);

String _storyEnumLabel(String value) {
  if (RuntimeGameLocale.isSimplifiedChinese) {
    return switch (value) {
      'alive' => '在世',
      'wounded' => '负伤',
      'presumedDead' => '推定死亡',
      'dead' => '已阵亡',
      'withCourt' => '随王庭行动',
      'reserve' => '后备',
      'missing' => '失踪',
      'captured' => '被俘',
      'unknown' => '下落不明',
      'player' => '我方',
      'enemy' => '敌方',
      'neutral' => '中立',
      'defected' => '已叛离',
      'chapterStarted' => '章节开始',
      'killed' => '阵亡',
      'returned' => '归来',
      'joined' => '加入',
      'purchased' => '被收买',
      'reconciled' => '和解',
      'named' => '获得姓名',
      'promoted' => '晋升',
      'transformed' => '转化',
      'objectiveCompleted' => '目标完成',
      'battleWon' => '战斗胜利',
      'battleLost' => '战斗失利',
      'finaleDeclared' => '终章确立',
      'epilogue' => '尾声',
      'open' => '进行中',
      'resolved' => '已解决',
      'verified' => '已验证事实',
      'reportedBelief' => '传闻信念',
      _ => value,
    };
  }
  final words = value.replaceAllMapped(
    RegExp(r'([a-z])([A-Z])'),
    (match) => '${match.group(1)} ${match.group(2)}',
  );
  return '${words[0].toUpperCase()}${words.substring(1)}';
}

class _HistoryList extends StatelessWidget {
  const _HistoryList({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) => ListView.separated(
    padding: const EdgeInsets.fromLTRB(2, 4, 14, 18),
    itemCount: children.length,
    separatorBuilder: (_, _) => const SizedBox(height: 10),
    itemBuilder: (_, index) => children[index],
  );
}

class _HistoryCard extends StatelessWidget {
  const _HistoryCard({
    required this.title,
    required this.subtitle,
    required this.body,
  });

  final String title;
  final String subtitle;
  final String body;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: const Color(0xD914191D),
      border: Border.all(color: const Color(0xFF493D2A)),
      borderRadius: BorderRadius.circular(9),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          localizedUiCopy(context, title),
          style: const TextStyle(
            color: Colors.white,
            fontFamily: 'Cinzel',
            fontSize: 17,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          localizedUiCopy(context, subtitle),
          style: const TextStyle(color: hifiGold, fontSize: 12),
        ),
        const SizedBox(height: 8),
        SelectableText(
          body,
          style: const TextStyle(color: hifiMuted, height: 1.45),
        ),
      ],
    ),
  );
}

class _HistoryEmpty extends StatelessWidget {
  const _HistoryEmpty(this.message);
  final String message;

  @override
  Widget build(BuildContext context) => Center(
    child: Text(
      localizedUiCopy(context, message),
      style: const TextStyle(color: hifiMuted),
    ),
  );
}

class LivingCampaignEpilogueScreen extends StatelessWidget {
  const LivingCampaignEpilogueScreen({required this.controller, super.key});

  final LivingCampaignController controller;

  @override
  Widget build(BuildContext context) {
    final run = controller.activeRun!;
    final isChinese = Localizations.localeOf(context).languageCode == 'zh';
    return _LivingTextScreen(
      key: const ValueKey('living-campaign-epilogue'),
      eyebrow: localizedDisplayCase(context, 'The Canon Is Sealed'),
      title: run.campaignTitle,
      subtitle: isChinese
          ? '${run.canon.chapterLedger.length} 章 · '
                '${run.canon.charactersById.length} 名已知角色 · '
                '修订 ${run.canon.revision}'
          : '${run.canon.chapterLedger.length} chapters · '
                '${run.canon.charactersById.length} known characters · '
                'revision ${run.canon.revision}',
      body:
          run.epilogue ??
          (run.contentLocale == LivingContentLocale.simplifiedChinese
              ? '本次战役结束时没有留下已记录的尾声。'
              : 'This campaign ended without a recorded epilogue.'),
      primaryLabel: localizedUiCopy(context, 'Archive Completed Run'),
      onPrimary: () => unawaited(controller.closeEpilogue()),
      secondaryLabel: localizedUiCopy(context, 'Run Archive'),
      onSecondary: () => unawaited(controller.closeEpilogue()),
    );
  }
}

class LivingCampaignBriefingScreen extends StatelessWidget {
  const LivingCampaignBriefingScreen({
    required this.controller,
    required this.onHub,
    super.key,
  });

  final LivingCampaignController controller;
  final VoidCallback onHub;

  @override
  Widget build(BuildContext context) {
    final chapter = controller.activeChapter!;
    final run = controller.activeRun!;
    final living = run.canon.charactersById.values
        .where((character) => character.lifeState != LivingLifeState.dead)
        .length;
    return HifiScaffold(
      key: const ValueKey('living-campaign-briefing'),
      backdropAsset: _livingBackdrop,
      backdropOpacity: .46,
      child: Center(
        child: Container(
          width: 1120,
          padding: const EdgeInsets.all(42),
          decoration: BoxDecoration(
            color: const Color(0xF20A0E12),
            border: Border.all(color: hifiGoldDark, width: 2),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              Expanded(
                flex: 6,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      Localizations.localeOf(context).languageCode == 'zh'
                          ? '第 ${chapter.chapterNumber} 章'
                          : 'CHAPTER ${chapter.chapterNumber}',
                      style: const TextStyle(
                        color: hifiGold,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      chapter.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontFamily: 'Cinzel',
                        fontSize: 36,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    Text(
                      chapter.subtitle,
                      style: const TextStyle(
                        color: hifiMuted,
                        fontStyle: FontStyle.italic,
                        fontSize: 17,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      chapter.briefing,
                      style: const TextStyle(
                        color: Color(0xFFE6E0D4),
                        fontSize: 17,
                        height: 1.55,
                      ),
                    ),
                    const SizedBox(height: 30),
                    Wrap(
                      spacing: 12,
                      children: [
                        FilledButton.icon(
                          key: const ValueKey('living-briefing-start'),
                          onPressed: controller.startBattle,
                          icon: const Icon(Icons.sports_esports),
                          label: Text(localizedUiCopy(context, 'Enter Battle')),
                        ),
                        OutlinedButton.icon(
                          onPressed: onHub,
                          icon: const Icon(Icons.inventory_2_outlined),
                          label: Text(localizedUiCopy(context, 'Run Archive')),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 40),
              Expanded(
                flex: 4,
                child: Container(
                  padding: const EdgeInsets.all(26),
                  decoration: BoxDecoration(
                    color: const Color(0xC9141718),
                    border: Border.all(color: const Color(0xFF5F4A2B)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        localizedDisplayCase(context, 'Primary Objective'),
                        style: const TextStyle(
                          color: hifiGold,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        chapter.objective.label,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          height: 1.35,
                        ),
                      ),
                      if (chapter.objective.type !=
                          LivingObjectiveType.checkmate) ...[
                        const SizedBox(height: 8),
                        Text(
                          Localizations.localeOf(context).languageCode == 'zh'
                              ? '备选 · 将死敌方王'
                              : 'ALTERNATE · Checkmate the enemy King',
                          style: const TextStyle(color: hifiMuted),
                        ),
                      ],
                      const Divider(height: 36, color: Color(0xFF5F4A2B)),
                      _BriefingStat('Gold carried', '${run.canon.gold}'),
                      _BriefingStat('Known living characters', '$living'),
                      _BriefingStat(
                        'Battlefield',
                        battlefieldDefinitions[chapter.battlefieldId]!.name,
                      ),
                      _BriefingStat(
                        'Pieces deployed',
                        '${chapter.pieces.length}',
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LivingCampaignBattleScreen extends StatefulWidget {
  const LivingCampaignBattleScreen({
    required this.controller,
    required this.presentationCoordinator,
    this.allowAssistedResolution = false,
    super.key,
  });

  final LivingCampaignController controller;
  final BoardPresentationCoordinator presentationCoordinator;
  final bool allowAssistedResolution;

  @override
  State<LivingCampaignBattleScreen> createState() =>
      _LivingCampaignBattleScreenState();
}

class _LivingCampaignBattleScreenState
    extends State<LivingCampaignBattleScreen> {
  bool _scheduled = false;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_schedule);
    widget.presentationCoordinator.addListener(_schedule);
    _schedule();
  }

  @override
  void dispose() {
    widget.controller.removeListener(_schedule);
    widget.presentationCoordinator.removeListener(_schedule);
    super.dispose();
  }

  void _schedule() {
    if (_scheduled || !mounted) return;
    _scheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scheduled = false;
      if (!mounted || widget.presentationCoordinator.isBusy) return;
      widget.controller.evaluateAfterPresentation();
      if (widget.controller.phase == LivingCampaignPhase.battle &&
          widget.controller.gameController.turn == PieceColor.black &&
          !widget.controller.isAiThinking) {
        unawaited(widget.controller.makeEnemyMove());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final living = widget.controller;
    return Stack(
      children: [
        AbsorbPointer(
          absorbing:
              living.playerInputLocked &&
              living.gameController.lastOfferResult == null,
          child: MatchScreen(
            controller: living.gameController,
            presentationCoordinator: widget.presentationCoordinator,
            aiThinking: living.isAiThinking,
            aiInputLocked: living.playerInputLocked,
            purchasePlacementPolicy: PurchasePlacementPolicy.blackInPlace,
            showGameOverOverlay: false,
            piecePresentationResolver: living.piecePresentation,
          ),
        ),
        Positioned(
          left: 450,
          right: 450,
          top: 98,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xEE0A0E12),
              border: Border.all(color: hifiGoldDark),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              living.activeChapter!.objective.label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
        Positioned(
          right: 22,
          bottom: 18,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.allowAssistedResolution) ...[
                FilledButton.icon(
                  key: const ValueKey('living-demo-resolve-battle'),
                  onPressed: living.debugResolveActiveBattleAsVictory,
                  icon: const Icon(Icons.fact_check_outlined),
                  label: Text(localizedUiCopy(context, 'QA: Resolve Chapter')),
                ),
                const SizedBox(width: 12),
              ],
              OutlinedButton.icon(
                onPressed: living.returnToHub,
                icon: const Icon(Icons.inventory_2_outlined),
                label: Text(localizedUiCopy(context, 'Run Archive')),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class LivingCampaignOutcomeAcknowledgementScreen extends StatelessWidget {
  const LivingCampaignOutcomeAcknowledgementScreen({
    required this.controller,
    required this.onHub,
    super.key,
  });

  final LivingCampaignController controller;
  final VoidCallback onHub;

  @override
  Widget build(BuildContext context) {
    final outcome = controller.pendingOutcome!;
    final won = controller.objectiveSucceeded;
    return HifiScaffold(
      key: const ValueKey('living-campaign-outcome-acknowledgement'),
      backdropAsset: _livingBackdrop,
      backdropOpacity: .45,
      child: Center(
        child: Container(
          width: 800,
          padding: const EdgeInsets.all(42),
          decoration: BoxDecoration(
            color: const Color(0xF20A0E12),
            border: Border.all(color: won ? hifiGold : const Color(0xFF9D4D45)),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                won ? Icons.auto_stories : Icons.broken_image_outlined,
                color: won ? hifiGold : const Color(0xFFE38B78),
                size: 66,
              ),
              const SizedBox(height: 12),
              Text(
                won
                    ? localizedDisplayCase(context, 'The Story Advances')
                    : localizedDisplayCase(context, 'The Court Withdraws'),
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: 'Cinzel',
                  fontSize: 30,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                Localizations.localeOf(context).languageCode == 'zh'
                    ? '${outcome.completedRoundCount} 个完整回合 · 记录 ${outcome.capturedPieces.length} 次吃子 · 记录 ${outcome.purchasedPieceIds.length} 次收买'
                    : '${outcome.completedRoundCount} full rounds · ${outcome.capturedPieces.length} captures recorded · ${outcome.purchasedPieceIds.length} purchases recorded',
                style: const TextStyle(color: hifiMuted),
              ),
              const SizedBox(height: 8),
              Text(
                Localizations.localeOf(context).languageCode == 'zh'
                    ? '战后金币：${outcome.goldAfterBattle}'
                    : 'Gold after battle: ${outcome.goldAfterBattle}',
                style: const TextStyle(color: hifiGold, fontSize: 18),
              ),
              const SizedBox(height: 26),
              Text(
                localizedUiCopy(context, controller.resultExplanation),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: hifiMuted,
                  height: 1.45,
                  fontSize: 17,
                  fontStyle: FontStyle.italic,
                ),
              ),
              const SizedBox(height: 30),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                alignment: WrapAlignment.center,
                children: [
                  FilledButton.icon(
                    key: const ValueKey('living-results-continue'),
                    onPressed: () =>
                        unawaited(controller.continueFromOutcome()),
                    icon: const Icon(Icons.auto_stories),
                    label: Text(localizedUiCopy(context, 'Continue')),
                  ),
                  OutlinedButton.icon(
                    onPressed: controller.retryBattle,
                    icon: const Icon(Icons.refresh),
                    label: Text(localizedUiCopy(context, 'Retry This Battle')),
                  ),
                  TextButton(
                    onPressed: onHub,
                    child: Text(localizedUiCopy(context, 'Run Archive')),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LivingCampaignChapterArtLoadingScreen extends StatelessWidget {
  const LivingCampaignChapterArtLoadingScreen({
    required this.controller,
    super.key,
  });

  final LivingCampaignController controller;

  @override
  Widget build(BuildContext context) {
    return HifiScaffold(
      key: const ValueKey('living-campaign-chapter-art-loading'),
      backdropAsset: _livingBackdrop,
      backdropOpacity: .24,
      child: Center(
        child: Container(
          width: 720,
          padding: const EdgeInsets.all(48),
          decoration: BoxDecoration(
            color: const Color(0xF20A0E12),
            border: Border.all(color: hifiGoldDark, width: 2),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                width: 54,
                height: 54,
                child: CircularProgressIndicator(
                  color: hifiGold,
                  strokeWidth: 3,
                ),
              ),
              const SizedBox(height: 28),
              Text(
                localizedDisplayCase(context, 'The Chronicle Remembers'),
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: 'Cinzel',
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                localizedUiCopy(
                  context,
                  controller.message ??
                      'The last echoes drift across the battlefield.',
                ),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: hifiMuted,
                  fontSize: 17,
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                localizedUiCopy(
                  context,
                  'Gold, loyalty, and every fate on the field are already sealed.',
                ),
                textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFF8E8068), fontSize: 13),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LivingCampaignChapterClosureLoadingScreen extends StatelessWidget {
  const LivingCampaignChapterClosureLoadingScreen({
    required this.controller,
    super.key,
  });

  final LivingCampaignController controller;

  @override
  Widget build(BuildContext context) => HifiScaffold(
    key: const ValueKey('living-campaign-chapter-closure-loading'),
    backdropAsset: _livingBackdrop,
    backdropOpacity: .24,
    child: Center(
      child: Container(
        width: 720,
        padding: const EdgeInsets.all(48),
        decoration: BoxDecoration(
          color: const Color(0xF20A0E12),
          border: Border.all(color: hifiGoldDark, width: 2),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              width: 54,
              height: 54,
              child: CircularProgressIndicator(color: hifiGold, strokeWidth: 3),
            ),
            const SizedBox(height: 28),
            Text(
              localizedDisplayCase(context, 'After the Last Move'),
              style: const TextStyle(
                color: Colors.white,
                fontFamily: 'Cinzel',
                fontSize: 28,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              localizedUiCopy(
                context,
                controller.message ?? controller.generationStageLabel,
              ),
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: hifiMuted,
                fontSize: 17,
                height: 1.45,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              localizedUiCopy(
                context,
                'The battle is sealed. What remains is what the living carry onward.',
              ),
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xFF8E8068), fontSize: 13),
            ),
          ],
        ),
      ),
    ),
  );
}

class LivingCampaignChapterEndingScreen extends StatelessWidget {
  const LivingCampaignChapterEndingScreen({
    required this.controller,
    required this.onHub,
    super.key,
  });

  final LivingCampaignController controller;
  final VoidCallback onHub;

  @override
  Widget build(BuildContext context) {
    final outcome = controller.pendingOutcome!;
    final checkpoint = controller.activeChapterArtCheckpoint;
    final closure = controller.activeChapterClosureCheckpoint;
    final won = outcome.result == LivingBattleResult.victory;
    return FutureBuilder<Uint8List?>(
      future: controller.chapterArtBytes(outcome.chapterId),
      builder: (context, snapshot) {
        final bytes = snapshot.data;
        return Stack(
          key: const ValueKey('living-campaign-chapter-ending'),
          fit: StackFit.expand,
          children: [
            if (bytes != null)
              Image.memory(
                bytes,
                key: const ValueKey('living-chapter-ending-generated-art'),
                fit: BoxFit.cover,
                gaplessPlayback: true,
              )
            else
              Image.asset(
                _livingBackdrop,
                key: const ValueKey('living-chapter-ending-fallback-art'),
                fit: BoxFit.cover,
              ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0x33000000),
                    Color(0x15000000),
                    Color(0xE6090B0D),
                  ],
                  stops: [0, .45, 1],
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: 1040,
                margin: const EdgeInsets.fromLTRB(40, 40, 40, 44),
                padding: const EdgeInsets.fromLTRB(38, 26, 38, 30),
                decoration: BoxDecoration(
                  color: const Color(0xDD080B0E),
                  border: Border.all(
                    color: won ? hifiGold : const Color(0xFF9D4D45),
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: const [
                    BoxShadow(color: Colors.black54, blurRadius: 24),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      won
                          ? localizedDisplayCase(context, 'The Story Advances')
                          : localizedDisplayCase(
                              context,
                              'The Court Withdraws',
                            ),
                      style: const TextStyle(
                        color: Colors.white,
                        fontFamily: 'Cinzel',
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      Localizations.localeOf(context).languageCode == 'zh'
                          ? '${outcome.completedRoundCount} 个完整回合 · 金币 ${outcome.goldAfterBattle}'
                          : '${outcome.completedRoundCount} full rounds · Gold ${outcome.goldAfterBattle}',
                      style: const TextStyle(color: hifiMuted),
                    ),
                    if (checkpoint?.status ==
                        LivingChapterArtStatus.awaitingRetry) ...[
                      const SizedBox(height: 14),
                      Text(
                        localizedUiCopy(
                          context,
                          controller.message ??
                              'The final scene remains hidden beyond the ash.',
                        ),
                        key: const ValueKey('living-chapter-art-warning'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Color(0xFFE7B39E)),
                      ),
                    ],
                    const SizedBox(height: 22),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      alignment: WrapAlignment.center,
                      children: [
                        FilledButton.icon(
                          key: const ValueKey('living-ending-continue'),
                          onPressed:
                              closure?.textStatus ==
                                  LivingClosureTaskStatus.ready
                              ? () => unawaited(
                                  controller.generateFollowingChapter(),
                                )
                              : null,
                          icon: const Icon(Icons.auto_stories),
                          label: Text(
                            controller.activeRun?.status ==
                                    LivingRunStatus.completed
                                ? localizedUiCopy(context, 'Read the Last Page')
                                : localizedUiCopy(
                                    context,
                                    'Continue the Chronicle',
                                  ),
                          ),
                        ),
                        if (checkpoint?.status ==
                            LivingChapterArtStatus.awaitingRetry)
                          OutlinedButton.icon(
                            key: const ValueKey('living-ending-retry-art'),
                            onPressed: controller.isPaidRequestRunning
                                ? null
                                : () => unawaited(
                                    controller.retryChapterEndingArt(),
                                  ),
                            icon: const Icon(Icons.brush_outlined),
                            label: Text(
                              localizedUiCopy(
                                context,
                                'Recall the Final Moment',
                              ),
                            ),
                          ),
                        if (closure?.textStatus ==
                            LivingClosureTaskStatus.awaitingRetry)
                          OutlinedButton.icon(
                            key: const ValueKey(
                              'living-ending-retry-aftermath',
                            ),
                            onPressed: controller.isPaidRequestRunning
                                ? null
                                : () => unawaited(
                                    controller.retryChapterClosureText(),
                                  ),
                            icon: const Icon(Icons.record_voice_over_outlined),
                            label: Text(
                              localizedUiCopy(context, 'Recall Their Words'),
                            ),
                          ),
                        TextButton(
                          onPressed: onHub,
                          child: Text(localizedUiCopy(context, 'Run Archive')),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _LivingTextScreen extends StatelessWidget {
  const _LivingTextScreen({
    required this.eyebrow,
    required this.title,
    required this.subtitle,
    required this.body,
    required this.primaryLabel,
    required this.onPrimary,
    required this.secondaryLabel,
    required this.onSecondary,
    super.key,
  });

  final String eyebrow;
  final String title;
  final String subtitle;
  final String body;
  final String primaryLabel;
  final VoidCallback onPrimary;
  final String secondaryLabel;
  final VoidCallback onSecondary;

  @override
  Widget build(BuildContext context) {
    return HifiScaffold(
      backdropAsset: _livingBackdrop,
      backdropOpacity: .35,
      child: Center(
        child: Container(
          width: 980,
          constraints: const BoxConstraints(maxHeight: 760),
          padding: const EdgeInsets.all(46),
          decoration: BoxDecoration(
            color: const Color(0xF20A0E12),
            border: Border.all(color: hifiGoldDark, width: 2),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                localizedDisplayCase(context, eyebrow),
                style: const TextStyle(
                  color: hifiGold,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: 'Cinzel',
                  fontSize: 38,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                style: const TextStyle(
                  color: hifiGold,
                  fontStyle: FontStyle.italic,
                  fontSize: 16,
                  height: 1.4,
                ),
              ),
              const Divider(height: 34, color: Color(0xFF5F4A2B)),
              Expanded(
                child: SingleChildScrollView(
                  child: SelectableText(
                    body,
                    style: const TextStyle(
                      color: Color(0xFFE8E1D4),
                      fontSize: 18,
                      height: 1.65,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  FilledButton(
                    onPressed: onPrimary,
                    child: Text(localizedUiCopy(context, primaryLabel)),
                  ),
                  const SizedBox(width: 12),
                  TextButton(
                    onPressed: onSecondary,
                    child: Text(localizedUiCopy(context, secondaryLabel)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GenerationProgressCard extends StatelessWidget {
  const _GenerationProgressCard({
    required this.controller,
    required this.onPlayAnotherMode,
  });

  final LivingCampaignController controller;
  final VoidCallback onPlayAnotherMode;

  @override
  Widget build(BuildContext context) {
    final job = controller.activeRun?.generationJob;
    final elapsed = controller.generationElapsed;
    final minutes = elapsed.inMinutes;
    final seconds = elapsed.inSeconds.remainder(60).toString().padLeft(2, '0');
    return Container(
      key: const ValueKey('living-generation-progress-card'),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF17130F),
        border: Border.all(color: hifiGoldDark),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          const SizedBox(
            width: 24,
            height: 24,
            child: CircularProgressIndicator(strokeWidth: 2.5, color: hifiGold),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  localizedDisplayCase(
                    context,
                    controller.generationStageLabel,
                  ),
                  style: const TextStyle(
                    color: hifiGold,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  localizedUiCopy(
                    context,
                    'Attempt ${job?.attempt ?? 1} · $minutes:$seconds elapsed',
                  ),
                  style: const TextStyle(color: hifiMuted, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          OutlinedButton.icon(
            key: const ValueKey('living-play-another-mode'),
            onPressed: onPlayAnotherMode,
            icon: const Icon(Icons.sports_esports_outlined),
            label: Text(localizedUiCopy(context, 'Play Another Mode')),
          ),
        ],
      ),
    );
  }
}

class _ActiveRunPanel extends StatelessWidget {
  const _ActiveRunPanel({
    required this.run,
    required this.controller,
    required this.canGenerate,
    required this.onContinue,
    required this.onResume,
    required this.onRetryPortrait,
    required this.onHistory,
    required this.onNew,
    required this.onPlayAnotherMode,
    required this.onAbandon,
  });

  final LivingCampaignRun? run;
  final LivingCampaignController controller;
  final bool canGenerate;
  final VoidCallback onContinue;
  final VoidCallback onResume;
  final VoidCallback onRetryPortrait;
  final VoidCallback? onHistory;
  final VoidCallback onNew;
  final VoidCallback onPlayAnotherMode;
  final VoidCallback? onAbandon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: const Color(0xD90C1115),
        border: Border.all(color: hifiGoldDark),
        borderRadius: BorderRadius.circular(12),
      ),
      child: run == null
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.auto_stories, color: hifiGold, size: 76),
                const SizedBox(height: 18),
                Text(
                  localizedDisplayCase(context, 'No Active Story'),
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Cinzel',
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  localizedUiCopy(
                    context,
                    'Mission 01 always begins with the approved Ashen Court opening and board. Every later mission responds to verified play.',
                  ),
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: hifiMuted, height: 1.45),
                ),
                const SizedBox(height: 24),
                FilledButton.icon(
                  key: const ValueKey('living-new-run'),
                  onPressed: controller.canStartNewRun ? onNew : null,
                  icon: const Icon(Icons.auto_awesome),
                  label: Text(
                    localizedUiCopy(context, 'Begin New Living Campaign'),
                  ),
                ),
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  localizedDisplayCase(context, 'Active Run'),
                  style: const TextStyle(
                    color: hifiGold,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.8,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  run!.campaignTitle,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Cinzel',
                    fontSize: 30,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  run!.storyPromise.isEmpty
                      ? localizedUiCopy(
                          context,
                          'The opening is waiting to be scripted.',
                        )
                      : run!.storyPromise,
                  style: const TextStyle(color: hifiMuted, height: 1.45),
                ),
                if (controller.isGenerationRunning) ...[
                  const SizedBox(height: 20),
                  _GenerationProgressCard(
                    controller: controller,
                    onPlayAnotherMode: onPlayAnotherMode,
                  ),
                ],
                if (controller.portraitStatusLabel case final label?) ...[
                  const SizedBox(height: 12),
                  Container(
                    key: const ValueKey('living-portrait-status'),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF17130F),
                      border: Border.all(color: hifiGoldDark),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          label == 'A FACE YET UNSEEN'
                              ? Icons.image_not_supported_outlined
                              : Icons.auto_awesome,
                          size: 16,
                          color: label == 'A FACE YET UNSEEN'
                              ? const Color(0xFFE0A45B)
                              : hifiGold,
                        ),
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            localizedUiCopy(context, label),
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: hifiMuted,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const Spacer(),
                Wrap(
                  spacing: 22,
                  runSpacing: 10,
                  children: [
                    _RunMetric('CHAPTER', '${run!.activeChapterNumber}'),
                    _RunMetric('CANON REVISION', '${run!.canon.revision}'),
                    _RunMetric('GOLD', '${run!.canon.gold}'),
                    _RunMetric(
                      'KNOWN CHARACTERS',
                      '${run!.canon.charactersById.length}',
                    ),
                  ],
                ),
                const SizedBox(height: 26),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    if (controller.hasInterruptedGeneration)
                      FilledButton.icon(
                        key: const ValueKey('living-resume-generation'),
                        onPressed: canGenerate ? onResume : null,
                        icon: const Icon(Icons.play_arrow),
                        label: Text(controller.retryGenerationLabel),
                      )
                    else
                      FilledButton.icon(
                        key: const ValueKey('living-continue-run'),
                        onPressed: controller.canContinueStory
                            ? onContinue
                            : null,
                        icon: const Icon(Icons.menu_book),
                        label: Text(localizedUiCopy(context, 'Continue Story')),
                      ),
                    if (controller.hasPortraitAttention)
                      OutlinedButton.icon(
                        key: const ValueKey('living-retry-portrait'),
                        onPressed: canGenerate ? onRetryPortrait : null,
                        icon: const Icon(Icons.refresh),
                        label: Text(
                          localizedUiCopy(context, 'Seek Their Likeness Again'),
                        ),
                      ),
                    OutlinedButton.icon(
                      key: const ValueKey('living-open-history'),
                      onPressed: onHistory,
                      icon: const Icon(Icons.history_edu_outlined),
                      label: Text(localizedUiCopy(context, 'History & Canon')),
                    ),
                    OutlinedButton.icon(
                      onPressed: controller.canStartNewRun ? onNew : null,
                      icon: const Icon(Icons.add),
                      label: Text(localizedUiCopy(context, 'New Run')),
                    ),
                    TextButton(
                      onPressed: controller.canAbandonActiveRun
                          ? onAbandon
                          : null,
                      child: Text(localizedUiCopy(context, 'Abandon')),
                    ),
                  ],
                ),
              ],
            ),
    );
  }
}

class _ArchivePanel extends StatelessWidget {
  const _ArchivePanel({required this.controller});

  final LivingCampaignController controller;

  @override
  Widget build(BuildContext context) {
    final archived = controller.archives
        .where((entry) => entry.status != LivingRunStatus.active)
        .toList();
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xC90A0D10),
        border: Border.all(color: const Color(0xFF493D2A)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            localizedDisplayCase(context, 'Local Archives'),
            style: const TextStyle(
              color: hifiGold,
              fontFamily: 'Cinzel',
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            localizedUiCopy(
              context,
              'Full scripts and generation records stay on this device.',
            ),
            style: const TextStyle(color: hifiMuted, fontSize: 12),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: archived.isEmpty
                ? Center(
                    child: Text(
                      localizedUiCopy(
                        context,
                        'No completed or abandoned runs.',
                      ),
                      style: const TextStyle(color: Color(0xFF817B72)),
                    ),
                  )
                : ListView.separated(
                    itemCount: archived.length,
                    separatorBuilder: (_, _) =>
                        const Divider(color: Color(0xFF3E3528)),
                    itemBuilder: (context, index) {
                      final item = archived[index];
                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(
                          '${_livingRunStatusLabel(context, item.status)} · '
                          '${Localizations.localeOf(context).languageCode == 'zh' ? '第 ${item.activeChapterNumber} 章' : 'Chapter ${item.activeChapterNumber}'}',
                          style: const TextStyle(color: Colors.white),
                        ),
                        subtitle: Text(
                          Localizations.localeOf(context).languageCode == 'zh'
                              ? '已记录 ${item.chapterCount} 章 · ${_formatBytes(item.byteSize)}'
                              : '${item.chapterCount} recorded chapters · ${_formatBytes(item.byteSize)}',
                          style: const TextStyle(color: hifiMuted),
                        ),
                        onTap: () =>
                            unawaited(controller.inspectRun(item.runId)),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              key: ValueKey(
                                'living-inspect-archive-${item.runId}',
                              ),
                              tooltip: localizedUiCopy(
                                context,
                                'Inspect story canon',
                              ),
                              onPressed: () =>
                                  unawaited(controller.inspectRun(item.runId)),
                              icon: const Icon(Icons.menu_book_outlined),
                              color: hifiGold,
                            ),
                            IconButton(
                              tooltip: localizedUiCopy(
                                context,
                                'Delete local archive',
                              ),
                              onPressed: () => _delete(context, item.runId),
                              icon: const Icon(Icons.delete_outline),
                              color: const Color(0xFFE38B78),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Future<void> _delete(BuildContext context, String runId) async {
    final confirmed =
        await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: Text(localizedUiCopy(context, 'Delete local archive?')),
            content: Text(
              localizedUiCopy(
                context,
                'The run JSON, complete generated scripts, prompts, records, and runtime portraits will be permanently removed from this device.',
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: Text(localizedUiCopy(context, 'Cancel')),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: Text(localizedUiCopy(context, 'Delete')),
              ),
            ],
          ),
        ) ??
        false;
    if (confirmed) await controller.deleteArchive(runId);
  }
}

class LivingCampaignStatusPill extends StatelessWidget {
  const LivingCampaignStatusPill({
    required this.controller,
    required this.onPressed,
    this.iconOnly = false,
    super.key,
  });

  final LivingCampaignController controller;
  final VoidCallback onPressed;
  final bool iconOnly;

  @override
  Widget build(BuildContext context) {
    final status = controller.directorStatus;
    final working = switch (status) {
      LivingDirectorStatus.starting ||
      LivingDirectorStatus.providerWorking ||
      LivingDirectorStatus.receiving ||
      LivingDirectorStatus.validating ||
      LivingDirectorStatus.repairing ||
      LivingDirectorStatus.portrait => true,
      _ => false,
    };
    final attention =
        status == LivingDirectorStatus.interrupted ||
        status == LivingDirectorStatus.failed;
    final color = attention
        ? const Color(0xFFE38B78)
        : status == LivingDirectorStatus.ready
        ? const Color(0xFF8FD5A6)
        : hifiGold;
    final icon = attention
        ? Icons.warning_amber_rounded
        : status == LivingDirectorStatus.ready
        ? Icons.auto_stories
        : Icons.auto_awesome;
    final detail = working
        ? controller.generationStageLabel
        : controller.directorStatusLabel;
    final artDetail = controller.portraitStatusLabel;
    return Tooltip(
      message: Localizations.localeOf(context).languageCode == 'zh'
          ? '演化编年史 · ${localizedUiCopy(context, detail)}${artDetail == null ? '' : ' · ${localizedUiCopy(context, artDetail)}'}'
          : 'Living Chronicle · $detail${artDetail == null ? '' : ' · $artDetail'}',
      child: OutlinedButton.icon(
        key: ValueKey(
          iconOnly ? 'living-match-status-icon' : 'living-global-status-pill',
        ),
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          foregroundColor: color,
          backgroundColor: const Color(0xE60A0E12),
          side: BorderSide(color: color.withValues(alpha: .65)),
          minimumSize: iconOnly ? const Size(44, 40) : const Size(0, 42),
          padding: iconOnly
              ? const EdgeInsets.symmetric(horizontal: 11)
              : const EdgeInsets.symmetric(horizontal: 15),
        ),
        icon: working
            ? SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2, color: color),
              )
            : Icon(icon, size: 18),
        label: iconOnly
            ? const SizedBox.shrink()
            : Text(
                localizedUiCopy(context, controller.directorStatusLabel),
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.1,
                ),
              ),
      ),
    );
  }
}

class _NoticePanel extends StatelessWidget {
  const _NoticePanel({
    required this.icon,
    required this.text,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String text;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xE3332415),
        border: Border.all(color: const Color(0xFF8F6A35)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(icon, color: hifiGold),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              localizedUiCopy(context, text),
              style: const TextStyle(color: Colors.white),
            ),
          ),
          if (actionLabel != null)
            TextButton(
              onPressed: onAction,
              child: Text(localizedUiCopy(context, actionLabel!)),
            ),
        ],
      ),
    );
  }
}

class _RunMetric extends StatelessWidget {
  const _RunMetric(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          localizedUiCopy(context, label),
          style: const TextStyle(color: hifiMuted, fontSize: 11),
        ),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 19,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }
}

class _BriefingStat extends StatelessWidget {
  const _BriefingStat(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Text(
              localizedUiCopy(context, label),
              style: const TextStyle(color: hifiMuted),
            ),
          ),
          Text(value, style: const TextStyle(color: Colors.white)),
        ],
      ),
    );
  }
}

String _formatBytes(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
}

String _livingRunStatusLabel(BuildContext context, LivingRunStatus status) {
  if (Localizations.localeOf(context).languageCode == 'zh') {
    return switch (status) {
      LivingRunStatus.active => '进行中',
      LivingRunStatus.completed => '已完成',
      LivingRunStatus.abandoned => '已放弃',
    };
  }
  return status.name.toUpperCase();
}

String _livingBattleResultLabel(
  BuildContext context,
  LivingBattleResult result,
) {
  if (Localizations.localeOf(context).languageCode == 'zh') {
    return switch (result) {
      LivingBattleResult.victory => '胜利',
      LivingBattleResult.defeat => '失败',
      LivingBattleResult.continuedDefeat => '败退后继续',
      LivingBattleResult.trapfall => '王陷落',
    };
  }
  return _storyEnumLabel(result.name).toUpperCase();
}
