import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class NineSlicePatch {
  const NineSlicePatch({required this.src, required this.dst});

  final Rect src;
  final Rect dst;
}

/// Splits a nine-slice asset into source/destination rects.
///
/// [centerSlice] is in source image pixels. Destination cap sizes are those
/// pixel caps divided by [scale], then shrunk if they would overflow [destination].
List<NineSlicePatch> nineSlicePatches({
  required Size imageSize,
  required Rect centerSlice,
  required Rect destination,
  double scale = 1,
}) {
  final srcW = imageSize.width;
  final srcH = imageSize.height;
  if (scale <= 0 || srcW <= 0 || srcH <= 0 || destination.isEmpty) {
    return const [];
  }

  final left = centerSlice.left.clamp(0.0, srcW);
  final top = centerSlice.top.clamp(0.0, srcH);
  final right = centerSlice.right.clamp(left, srcW);
  final bottom = centerSlice.bottom.clamp(top, srcH);

  var dstLeft = left / scale;
  var dstTop = top / scale;
  var dstRight = (srcW - right) / scale;
  var dstBottom = (srcH - bottom) / scale;

  final widthCaps = dstLeft + dstRight;
  if (widthCaps > destination.width && widthCaps > 0) {
    final factor = destination.width / widthCaps;
    dstLeft *= factor;
    dstRight *= factor;
  }
  final heightCaps = dstTop + dstBottom;
  if (heightCaps > destination.height && heightCaps > 0) {
    final factor = destination.height / heightCaps;
    dstTop *= factor;
    dstBottom *= factor;
  }

  final x0 = destination.left;
  final x1 = destination.left + dstLeft;
  final x2 = destination.right - dstRight;
  final x3 = destination.right;
  final y0 = destination.top;
  final y1 = destination.top + dstTop;
  final y2 = destination.bottom - dstBottom;
  final y3 = destination.bottom;

  final patches = <NineSlicePatch>[];
  void add(
    double srcLeft,
    double srcTop,
    double srcRight,
    double srcBottom,
    double dstLeft,
    double dstTop,
    double dstRight,
    double dstBottom,
  ) {
    final src = Rect.fromLTRB(srcLeft, srcTop, srcRight, srcBottom);
    final dst = Rect.fromLTRB(dstLeft, dstTop, dstRight, dstBottom);
    if (src.width <= 0 ||
        src.height <= 0 ||
        dst.width <= 0 ||
        dst.height <= 0) {
      return;
    }
    patches.add(NineSlicePatch(src: src, dst: dst));
  }

  add(0, 0, left, top, x0, y0, x1, y1);
  add(left, 0, right, top, x1, y0, x2, y1);
  add(right, 0, srcW, top, x2, y0, x3, y1);
  add(0, top, left, bottom, x0, y1, x1, y2);
  add(left, top, right, bottom, x1, y1, x2, y2);
  add(right, top, srcW, bottom, x2, y1, x3, y2);
  add(0, bottom, left, srcH, x0, y2, x1, y3);
  add(left, bottom, right, srcH, x1, y2, x2, y3);
  add(right, bottom, srcW, srcH, x2, y2, x3, y3);
  return patches;
}

class NineSliceAssetImage extends StatefulWidget {
  const NineSliceAssetImage({
    required this.asset,
    required this.centerSlice,
    this.scale = 1,
    this.filterQuality = FilterQuality.high,
    super.key,
  });

  final String asset;
  final Rect centerSlice;
  final double scale;
  final FilterQuality filterQuality;

  @override
  State<NineSliceAssetImage> createState() => _NineSliceAssetImageState();
}

class _NineSliceAssetImageState extends State<NineSliceAssetImage> {
  ImageStream? _stream;
  ImageStreamListener? _listener;
  ImageInfo? _imageInfo;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _resolve();
  }

  @override
  void didUpdateWidget(covariant NineSliceAssetImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.asset != widget.asset || oldWidget.scale != widget.scale) {
      _resolve();
    }
  }

  @override
  void dispose() {
    _stopListening();
    _imageInfo?.dispose();
    super.dispose();
  }

  void _resolve() {
    final provider = ExactAssetImage(widget.asset, scale: widget.scale);
    final stream = provider.resolve(createLocalImageConfiguration(context));
    if (stream == _stream) {
      return;
    }
    _stopListening();
    _listener = ImageStreamListener(_handleImage, onError: _handleError);
    _stream = stream..addListener(_listener!);
  }

  void _stopListening() {
    if (_stream != null && _listener != null) {
      _stream!.removeListener(_listener!);
    }
    _stream = null;
    _listener = null;
  }

  void _handleImage(ImageInfo info, bool synchronousCall) {
    _imageInfo?.dispose();
    _imageInfo = info;
    if (mounted) {
      setState(() {});
    }
  }

  void _handleError(Object error, StackTrace? stackTrace) {
    _imageInfo?.dispose();
    _imageInfo = null;
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final image = _imageInfo?.image;
    if (image == null) {
      return const SizedBox.expand();
    }
    return CustomPaint(
      painter: _NineSlicePainter(
        image: image,
        centerSlice: widget.centerSlice,
        scale: widget.scale,
        filterQuality: widget.filterQuality,
      ),
      child: const SizedBox.expand(),
    );
  }
}

class _NineSlicePainter extends CustomPainter {
  const _NineSlicePainter({
    required this.image,
    required this.centerSlice,
    required this.scale,
    required this.filterQuality,
  });

  final ui.Image image;
  final Rect centerSlice;
  final double scale;
  final FilterQuality filterQuality;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..filterQuality = filterQuality;
    for (final patch in nineSlicePatches(
      imageSize: Size(image.width.toDouble(), image.height.toDouble()),
      centerSlice: centerSlice,
      destination: Offset.zero & size,
      scale: scale,
    )) {
      canvas.drawImageRect(image, patch.src, patch.dst, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _NineSlicePainter oldDelegate) {
    return oldDelegate.image != image ||
        oldDelegate.centerSlice != centerSlice ||
        oldDelegate.scale != scale ||
        oldDelegate.filterQuality != filterQuality;
  }
}
