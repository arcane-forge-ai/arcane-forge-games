import 'dart:math' as math;

import 'package:flutter/material.dart';

class S01GoldMotes extends StatefulWidget {
  const S01GoldMotes({super.key});

  static const int moteCount = 36;
  static const Duration loopDuration = Duration(seconds: 12);

  @override
  State<S01GoldMotes> createState() => _S01GoldMotesState();
}

class _S01GoldMotesState extends State<S01GoldMotes>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final List<_GoldMote> _motes;
  bool? _animationsDisabled;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: S01GoldMotes.loopDuration,
    );
    _motes = _buildMotes();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final disabled = MediaQuery.of(context).disableAnimations;
    if (disabled == _animationsDisabled) {
      return;
    }
    _animationsDisabled = disabled;
    if (disabled) {
      _controller
        ..stop()
        ..value = 0.32;
    } else {
      _controller.repeat();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final disabled = _animationsDisabled ?? false;
    return IgnorePointer(
      key: const ValueKey('s01-gold-motes'),
      child: RepaintBoundary(
        child: CustomPaint(
          key: ValueKey(
            disabled ? 's01-gold-motes-static' : 's01-gold-motes-animated',
          ),
          painter: _GoldMotesPainter(_motes, _controller),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }

  List<_GoldMote> _buildMotes() {
    final random = math.Random(0xC0FFEE);
    return List<_GoldMote>.generate(S01GoldMotes.moteCount, (index) {
      final warm = index.isEven;
      return _GoldMote(
        x: random.nextDouble(),
        y: random.nextDouble(),
        radius: 0.8 + random.nextDouble() * 2.2,
        speed: 0.18 + random.nextDouble() * 0.34,
        phase: random.nextDouble(),
        drift: 0.004 + random.nextDouble() * 0.012,
        paint: Paint()
          ..color = warm
              ? Color.fromARGB(70 + random.nextInt(38), 255, 202, 92)
              : Color.fromARGB(58 + random.nextInt(32), 255, 232, 166)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.5),
      );
    }, growable: false);
  }
}

class _GoldMote {
  const _GoldMote({
    required this.x,
    required this.y,
    required this.radius,
    required this.speed,
    required this.phase,
    required this.drift,
    required this.paint,
  });

  final double x;
  final double y;
  final double radius;
  final double speed;
  final double phase;
  final double drift;
  final Paint paint;
}

class _GoldMotesPainter extends CustomPainter {
  _GoldMotesPainter(this.motes, this.animation) : super(repaint: animation);

  final List<_GoldMote> motes;
  final Animation<double> animation;

  @override
  void paint(Canvas canvas, Size size) {
    final time = animation.value;
    for (final mote in motes) {
      final wrappedY = (mote.y - time * mote.speed) % 1;
      final wave = math.sin((time + mote.phase) * math.pi * 2);
      final x = (mote.x + wave * mote.drift) * size.width;
      final y = wrappedY * size.height;
      canvas
        ..save()
        ..translate(x, y)
        ..drawCircle(Offset.zero, mote.radius, mote.paint)
        ..restore();
    }
  }

  @override
  bool shouldRepaint(covariant _GoldMotesPainter oldDelegate) {
    return oldDelegate.animation != animation || oldDelegate.motes != motes;
  }
}
