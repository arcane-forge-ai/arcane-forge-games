import 'package:flutter/material.dart';

const referenceFirstMatchArtRoot = 'assets/runtime/ui/match';
const mercantileSpyMatchArtRoot = 'assets/runtime/ui/match/mercantile_spy';

const matchEnvironmentAsset =
    '$referenceFirstMatchArtRoot/match_environment.webp';
const matchHudCourtPlateAAsset =
    '$referenceFirstMatchArtRoot/hud_court_plate_a.webp';
const matchHudCourtPlateBAsset =
    '$referenceFirstMatchArtRoot/hud_court_plate_b.webp';
const matchHudEventLogAsset = '$referenceFirstMatchArtRoot/hud_event_log.webp';
const matchHudInspectorAsset = '$referenceFirstMatchArtRoot/hud_inspector.webp';
const matchHudMerchantRailAsset =
    '$referenceFirstMatchArtRoot/hud_merchant_rail.webp';
const matchOfferContractShellAsset =
    '$referenceFirstMatchArtRoot/offer_contract_shell.webp';
const matchPurchaseRollShellAsset =
    '$referenceFirstMatchArtRoot/purchase_roll_shell.webp';
const matchResultShellAsset = '$referenceFirstMatchArtRoot/result_shell.webp';
const matchRedeployInstructionShellAsset =
    '$referenceFirstMatchArtRoot/redeploy_instruction_shell.webp';
const matchCheckmateVictoryBannerAsset =
    '$referenceFirstMatchArtRoot/checkmate_victory_banner.webp';
const matchStalemateBannerAsset =
    '$referenceFirstMatchArtRoot/stalemate_banner.webp';

const matchButtonGoldAsset =
    '$referenceFirstMatchArtRoot/button_gold_primary.webp';
const matchButtonEmeraldAsset =
    '$referenceFirstMatchArtRoot/button_emerald_confirm.webp';
const matchButtonDarkAsset =
    '$referenceFirstMatchArtRoot/button_dark_secondary.webp';

const matchCourtPlateCenterSlice = Rect.fromLTRB(100, 16, 1322, 115);
const matchEventLogCenterSlice = Rect.fromLTRB(80, 100, 435, 571);
const matchInspectorCenterSlice = Rect.fromLTRB(80, 100, 361, 590);
const matchMerchantRailCenterSlice = Rect.fromLTRB(28, 100, 87, 571);
const matchButtonCenterSlice = Rect.fromLTRB(100, 70, 1113, 180);
const matchButtonImageScale = 4.0;

String matchCourtPlateAsset(String countryId, {required bool blackSide}) {
  return switch (countryId) {
    'mercantile' => '$mercantileSpyMatchArtRoot/mercantile_court_plate.webp',
    'spy' => '$mercantileSpyMatchArtRoot/spy_court_plate.webp',
    _ => blackSide ? matchHudCourtPlateAAsset : matchHudCourtPlateBAsset,
  };
}

String? matchCountryCrestAsset(String countryId) {
  return switch (countryId) {
    'mercantile' => '$mercantileSpyMatchArtRoot/mercantile_crest.webp',
    'spy' => '$mercantileSpyMatchArtRoot/spy_crest.webp',
    _ => null,
  };
}

const matchMerchantCaravanAsset =
    '$mercantileSpyMatchArtRoot/merchant_caravan.webp';
