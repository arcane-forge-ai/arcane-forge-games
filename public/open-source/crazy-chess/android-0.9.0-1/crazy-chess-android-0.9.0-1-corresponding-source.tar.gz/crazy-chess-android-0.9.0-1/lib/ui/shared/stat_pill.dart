import 'package:flutter/material.dart';

class StatPill extends StatelessWidget {
  const StatPill(this.label, {super.key});

  final String label;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xFF2a2f37),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF454c56)),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
        child: Text(
          label,
          style: const TextStyle(
            fontSize: 11,
            color: Color(0xFFded6c9),
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}
