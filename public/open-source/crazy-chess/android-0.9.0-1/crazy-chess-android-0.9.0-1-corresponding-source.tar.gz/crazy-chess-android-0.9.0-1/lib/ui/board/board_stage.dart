import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../game/game_controller.dart';
import '../overlays/game_over_overlay.dart';
import '../overlays/promotion_overlay.dart';
import '../overlays/redeploy_banner.dart';
import 'board_presentation_coordinator.dart';
import 'game_board.dart';

class BoardStage extends StatelessWidget {
  const BoardStage({
    required this.controller,
    required this.maxSize,
    this.presentationCoordinator,
    this.showGameOverOverlay = true,
    this.showRedeployBanner = true,
    this.tilted = true,
    super.key,
  });

  final GameController controller;
  final double maxSize;
  final BoardPresentationCoordinator? presentationCoordinator;
  final bool showGameOverOverlay;
  final bool showRedeployBanner;
  final bool tilted;

  @override
  Widget build(BuildContext context) {
    final board = ConstrainedBox(
      constraints: BoxConstraints(maxWidth: maxSize, maxHeight: maxSize),
      child: AspectRatio(
        aspectRatio: 1,
        child: Stack(
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xFF211a13),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFc69b50), width: 4),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x99000000),
                    blurRadius: 28,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: Image.asset(
                      controller.battlefield.boardAsset ??
                          'assets/runtime/pieces/board/mercantile/skin_base.webp',
                      key: ValueKey(
                        'battlefield-board-${controller.battlefieldId.name}',
                      ),
                      fit: BoxFit.cover,
                      opacity: const AlwaysStoppedAnimation(.68),
                      filterQuality: FilterQuality.high,
                      excludeFromSemantics: true,
                      errorBuilder: (context, error, stackTrace) =>
                          const SizedBox.shrink(),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: GameBoard(
                      controller: controller,
                      presentationCoordinator: presentationCoordinator,
                    ),
                  ),
                ],
              ),
            ),
            if (controller.phase == GamePhase.promotion &&
                !(presentationCoordinator?.isBusy ?? false))
              PromotionOverlay(controller: controller),
            if (showGameOverOverlay &&
                controller.phase == GamePhase.gameOver &&
                !(presentationCoordinator?.isBusy ?? false))
              GameOverOverlay(controller: controller),
            if (showRedeployBanner &&
                controller.phase == GamePhase.redeploy &&
                !(presentationCoordinator?.isBusy ?? false))
              RedeployBanner(controller: controller),
          ],
        ),
      ),
    );
    if (!tilted) {
      return board;
    }
    return Transform(
      key: const ValueKey('s20-tilted-board'),
      alignment: Alignment.center,
      transform: Matrix4.identity()
        ..setEntry(3, 2, .0008)
        ..rotateX(-.12),
      transformHitTests: true,
      filterQuality: FilterQuality.high,
      child: board,
    );
  }
}
