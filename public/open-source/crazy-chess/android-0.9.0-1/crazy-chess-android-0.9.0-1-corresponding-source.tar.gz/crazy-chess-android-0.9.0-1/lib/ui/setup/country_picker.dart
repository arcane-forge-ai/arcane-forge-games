import 'package:flutter/material.dart';

import '../../domain/countries.dart';
import '../shared/country_crest.dart';
import '../shared/formatters.dart';
import '../shared/stat_pill.dart';

class CountryPicker extends StatelessWidget {
  const CountryPicker({
    required this.title,
    required this.selectedId,
    required this.onSelected,
    super.key,
  });

  final String title;
  final String selectedId;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xCC20242b),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF3b424c)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 430,
              child: ListView.separated(
                itemCount: selectableCountries.length,
                separatorBuilder: (context, index) =>
                    const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final country = selectableCountries.elementAt(index);
                  final selected = selectedId == country.id;
                  return InkWell(
                    borderRadius: BorderRadius.circular(8),
                    onTap: () => onSelected(country.id),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: selected
                            ? country.color.withValues(alpha: 0.28)
                            : const Color(0xFF171a1f),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: selected
                              ? country.secondaryColor
                              : const Color(0xFF343a43),
                          width: selected ? 2 : 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          CountryCrest(country: country, size: 54),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  country.name,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  country.fantasy,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Color(0xFFbbb5aa),
                                    height: 1.25,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 6,
                                  children: [
                                    StatPill(
                                      'Gold ${signed(country.startingGoldModifier)}',
                                    ),
                                    StatPill(
                                      'Payout ${signed(country.merchantPayoutModifier)}',
                                    ),
                                    StatPill(
                                      'Offer ${signed(country.offenseModifier)}',
                                    ),
                                    if (country.id == 'spy')
                                      const StatPill('Reveal'),
                                    if (country.id == 'horse')
                                      const StatPill('Knight pressure'),
                                    if (country.id == 'iron')
                                      const StatPill('High loyalty'),
                                    if (country.id == 'mercantile')
                                      const StatPill('Refunds'),
                                    if (country.id == 'corsair')
                                      const StatPill('Capture theft'),
                                    if (country.id == 'sunlit')
                                      const StatPill('Bishop exposure'),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
