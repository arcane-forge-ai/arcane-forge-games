import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../game/game_controller.dart';
import '../../l10n/runtime_game_locale.dart';
import 'player_plate.dart';

class MatchHeader extends StatelessWidget {
  const MatchHeader({required this.controller, super.key});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: PlayerPlate(controller: controller, color: PieceColor.black),
        ),
        const SizedBox(width: 14),
        SizedBox(
          key: const ValueKey('s20-versus'),
          width: 72,
          child: Text(
            RuntimeGameLocale.isSimplifiedChinese ? '对' : 'VS',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Color(0xFFE6C66F),
              fontFamily: 'Cinzel',
              fontSize: 30,
              fontWeight: FontWeight.w900,
              shadows: [Shadow(color: Colors.black, blurRadius: 10)],
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: PlayerPlate(controller: controller, color: PieceColor.white),
        ),
      ],
    );
  }
}
