import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../game/game_controller.dart';
import '../shared/formatters.dart';

class PromotionOverlay extends StatelessWidget {
  const PromotionOverlay({required this.controller, super.key});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: const Color(0xAA000000),
        child: Center(
          child: Container(
            width: 320,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: const Color(0xFF20242a),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFd0a95c)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Promote Pawn',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final type in const [
                      PieceType.queen,
                      PieceType.rook,
                      PieceType.bishop,
                      PieceType.knight,
                    ])
                      FilledButton(
                        onPressed: () => controller.choosePromotion(type),
                        child: Text(pieceTypeLabel(type)),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
