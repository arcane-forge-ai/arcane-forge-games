import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../domain/board_presentation.dart';
import '../../game/game_controller.dart';

class BoardPresentationCoordinator extends ChangeNotifier {
  BoardPresentationCoordinator({
    required this.controller,
    this.moveDuration = const Duration(milliseconds: 400),
    this.betrayalDuration = const Duration(milliseconds: 480),
  }) {
    _releasedMerchantPulseSerial = controller.merchantPayoutPulseSerial;
    _releasedBattlefieldEventSerial = controller.battlefieldEventSerial;
    controller.addListener(_handleControllerChanged);
  }

  final GameController controller;
  final Duration moveDuration;
  final Duration betrayalDuration;

  Timer? _timer;
  int _lastSeenMoveSerial = 0;
  int _lastSeenBetrayalSerial = 0;
  bool _reducedMotion = false;
  bool _disposed = false;
  late int _releasedMerchantPulseSerial;
  late int _releasedBattlefieldEventSerial;

  BoardMotionEvent? activeMotion;
  BetrayalTransformEvent? activeBetrayal;
  BoardMotionEvent? lastCompletedMotion;

  bool get reducedMotion => _reducedMotion;
  bool get isBusy => activeMotion != null || activeBetrayal != null;
  bool get holdingMoveConsequences => activeMotion != null;
  bool get merchantConsequencesReleased =>
      controller.merchantPayoutPulseSerial == _releasedMerchantPulseSerial;

  bool battlefieldConsequencesReleased(int serial) {
    return serial == _releasedBattlefieldEventSerial;
  }

  void setReducedMotion(bool value) {
    if (_reducedMotion == value) {
      return;
    }
    _reducedMotion = value;
    if (value && isBusy) {
      _finishActivePresentation();
      return;
    }
    notifyListeners();
  }

  void _handleControllerChanged() {
    if (_disposed) {
      return;
    }
    final moveEvent = controller.lastBoardMotionEvent;
    final betrayalEvent = controller.lastBetrayalTransformEvent;

    if (moveEvent == null &&
        betrayalEvent == null &&
        (_lastSeenMoveSerial != 0 || _lastSeenBetrayalSerial != 0)) {
      _timer?.cancel();
      activeMotion = null;
      activeBetrayal = null;
      lastCompletedMotion = null;
      _lastSeenMoveSerial = 0;
      _lastSeenBetrayalSerial = 0;
      _releaseConsequences();
      notifyListeners();
      return;
    }

    if (betrayalEvent != null &&
        betrayalEvent.serial != _lastSeenBetrayalSerial) {
      _lastSeenBetrayalSerial = betrayalEvent.serial;
      _startBetrayal(betrayalEvent);
      return;
    }
    if (moveEvent != null && moveEvent.serial != _lastSeenMoveSerial) {
      _lastSeenMoveSerial = moveEvent.serial;
      _startMotion(moveEvent);
      return;
    }
    if (!isBusy) {
      _releaseConsequences();
    }
  }

  void _startMotion(BoardMotionEvent event) {
    _timer?.cancel();
    activeBetrayal = null;
    if (_reducedMotion || moveDuration == Duration.zero) {
      activeMotion = null;
      lastCompletedMotion = event;
      _releaseConsequences();
      notifyListeners();
      return;
    }
    activeMotion = event;
    notifyListeners();
    _timer = Timer(moveDuration, _finishActivePresentation);
  }

  void _startBetrayal(BetrayalTransformEvent event) {
    _timer?.cancel();
    activeMotion = null;
    if (_reducedMotion || betrayalDuration == Duration.zero) {
      activeBetrayal = null;
      notifyListeners();
      return;
    }
    activeBetrayal = event;
    notifyListeners();
    _timer = Timer(betrayalDuration, _finishActivePresentation);
  }

  void _finishActivePresentation() {
    _timer?.cancel();
    _timer = null;
    if (activeMotion != null) {
      lastCompletedMotion = activeMotion;
    }
    activeMotion = null;
    activeBetrayal = null;
    _releaseConsequences();
    if (!_disposed) {
      notifyListeners();
    }
  }

  void _releaseConsequences() {
    _releasedMerchantPulseSerial = controller.merchantPayoutPulseSerial;
    _releasedBattlefieldEventSerial = controller.battlefieldEventSerial;
  }

  @override
  void dispose() {
    if (_disposed) {
      return;
    }
    _disposed = true;
    _timer?.cancel();
    controller.removeListener(_handleControllerChanged);
    super.dispose();
  }
}
