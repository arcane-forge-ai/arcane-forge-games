import 'package:flutter/material.dart';

import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../game/game_controller.dart';
import '../../l10n/ui_copy.dart';
import '../menu/hifi_menu_widgets.dart';
import '../shared/formatters.dart';
import '../shared/piece_art.dart';
import '../shared/reference_first_match_art.dart';

class RedeployPanel extends StatelessWidget {
  const RedeployPanel({required this.controller, super.key});

  final GameController controller;

  @override
  Widget build(BuildContext context) {
    final piece = controller.redeployPiece;
    final pending = controller.pendingRedeploySquare;
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final height = constraints.maxHeight;
        return Stack(
          key: const ValueKey('s26-redeploy-panel'),
          fit: StackFit.expand,
          children: [
            Image.asset(
              matchRedeployInstructionShellAsset,
              key: const ValueKey('s26-reference-first-shell'),
              fit: BoxFit.fill,
              filterQuality: FilterQuality.high,
              excludeFromSemantics: true,
            ),
            Positioned(
              left: width * .12,
              right: width * .12,
              top: height * .045,
              height: height * .075,
              child: Center(
                child: Text(
                  localizedDisplayCase(context, 'Redeploy Defector'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: hifiGold,
                    fontFamily: 'Cinzel',
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.1,
                  ),
                ),
              ),
            ),
            Positioned(
              left: width * .105,
              right: width * .105,
              top: height * .145,
              height: height * .405,
              child: _RedeployInstructions(
                piece: piece,
                legalCount: controller.legalRedeploySquares().length,
              ),
            ),
            Positioned(
              left: width * .10,
              right: width * .10,
              top: height * .578,
              height: height * .177,
              child: Column(
                children: [
                  Expanded(
                    child: _MarkerLegendRow(
                      key: const ValueKey('s26-legend-valid'),
                      icon: Icons.radio_button_checked,
                      color: Color(0xFF56BDAF),
                      label: 'Valid destination',
                    ),
                  ),
                  Expanded(
                    child: _MarkerLegendRow(
                      key: const ValueKey('s26-legend-forbidden'),
                      icon: Icons.block,
                      color: Color(0xFFD3625A),
                      label: 'Forbidden or occupied',
                    ),
                  ),
                  Expanded(
                    child: _MarkerLegendRow(
                      key: const ValueKey('s26-legend-origin'),
                      icon: Icons.blur_on,
                      color: Color(0xFFB9A57A),
                      label: 'Original square',
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: width * .12,
              right: width * .12,
              top: height * .786,
              height: height * .063,
              child: Center(
                child: Text(
                  pending == null
                      ? localizedDisplayCase(context, 'Choose a Destination')
                      : Localizations.localeOf(context).languageCode == 'zh'
                      ? '目的格 · ${controller.squareName(pending)}'
                      : 'DESTINATION · ${controller.squareName(pending).toUpperCase()}',
                  key: const ValueKey('s26-pending-destination'),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: pending == null
                        ? const Color(0xFFB8A98B)
                        : const Color(0xFF70D5C5),
                    fontFamily: 'Cinzel',
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .6,
                  ),
                ),
              ),
            ),
            Positioned(
              left: width * .12,
              right: width * .12,
              top: height * .875,
              height: height * .075,
              child: _RedeployConfirmButton(
                enabled: pending != null,
                onPressed: pending == null ? null : controller.confirmRedeploy,
              ),
            ),
          ],
        );
      },
    );
  }
}

class _RedeployInstructions extends StatelessWidget {
  const _RedeployInstructions({required this.piece, required this.legalCount});

  final ChessPiece? piece;
  final int legalCount;

  @override
  Widget build(BuildContext context) {
    final country = piece == null ? null : countries[piece!.countryId];
    return Column(
      key: const ValueKey('s26-redeploy-body'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                width: 126,
                child: piece == null
                    ? const SizedBox.shrink()
                    : PieceArtImage(
                        countryId: piece!.countryId,
                        type: piece!.type,
                        kind: PieceArtKind.portrait,
                        alignment: Alignment.bottomCenter,
                      ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      piece == null
                          ? localizedDisplayCase(context, 'Purchased Piece')
                          : '${localizedDisplayCase(context, colorLabel(piece!.color))} ${localizedDisplayCase(context, pieceTypeLabel(piece!.type))}',
                      style: const TextStyle(
                        color: hifiInk,
                        fontFamily: 'Cinzel',
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      country == null
                          ? localizedDisplayCase(context, 'Neutral Court')
                          : localizedDisplayCase(context, country.name),
                      style: const TextStyle(
                        color: hifiGold,
                        fontFamily: 'Cinzel',
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: .7,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      localizedUiCopy(
                        context,
                        'Preview a highlighted square, then confirm the placement. The original square stays forbidden.',
                      ),
                      style: const TextStyle(
                        color: Color(0xFFD9CFB8),
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        height: 1.28,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          Localizations.localeOf(context).languageCode == 'zh'
              ? '$legalCount 个合法重新部署格'
              : '$legalCount LEGAL REDEPLOY SQUARES',
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: Color(0xFF70D5C5),
            fontFamily: 'Cinzel',
            fontSize: 13,
            fontWeight: FontWeight.w900,
            letterSpacing: .7,
          ),
        ),
      ],
    );
  }
}

class _MarkerLegendRow extends StatelessWidget {
  const _MarkerLegendRow({
    required this.icon,
    required this.color,
    required this.label,
    super.key,
  });

  final IconData icon;
  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(width: 50, child: Icon(icon, color: color, size: 24)),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            localizedDisplayCase(context, label),
            style: TextStyle(
              color: color,
              fontFamily: 'Cinzel',
              fontSize: 12,
              fontWeight: FontWeight.w800,
              letterSpacing: .45,
            ),
          ),
        ),
      ],
    );
  }
}

class _RedeployConfirmButton extends StatelessWidget {
  const _RedeployConfirmButton({
    required this.enabled,
    required this.onPressed,
  });

  final bool enabled;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      enabled: enabled,
      label: enabled
          ? localizedUiCopy(context, 'Confirm Placement')
          : localizedUiCopy(
              context,
              'Confirm Placement disabled until a destination is selected',
            ),
      child: Material(
        color: enabled ? Colors.transparent : const Color(0x55000000),
        child: InkWell(
          key: const ValueKey('s26-confirm-placement'),
          onTap: onPressed,
          child: Opacity(
            opacity: enabled ? 1 : .46,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.check_circle_outline,
                  color: hifiInk,
                  size: 22,
                ),
                const SizedBox(width: 9),
                Text(
                  localizedDisplayCase(context, 'Confirm Placement'),
                  style: const TextStyle(
                    color: hifiInk,
                    fontFamily: 'Cinzel',
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .7,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
