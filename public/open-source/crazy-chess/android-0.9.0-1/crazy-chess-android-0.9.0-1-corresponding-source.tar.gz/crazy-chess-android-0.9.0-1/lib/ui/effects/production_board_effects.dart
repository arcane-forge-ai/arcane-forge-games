import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Canonical procedural board markers owned by MAIN-P01.
///
/// These effects deliberately remain live Flutter paint so they track the
/// authoritative board geometry and can honor reduced-motion preferences.
class ProductionLegalTargetMarker extends StatelessWidget {
  const ProductionLegalTargetMarker({
    required this.capture,
    required this.redeploy,
    super.key,
  });

  final bool capture;
  final bool redeploy;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: SizedBox.square(
        key: ValueKey(
          capture
              ? 'board-legal-capture-marker'
              : redeploy
              ? 'board-redeploy-valid-glow'
              : 'board-legal-move-dot',
        ),
        dimension: capture
            ? 90
            : redeploy
            ? 44
            : 28,
        child: CustomPaint(
          painter: _LegalTargetPainter(capture: capture, redeploy: redeploy),
        ),
      ),
    );
  }
}

class _LegalTargetPainter extends CustomPainter {
  const _LegalTargetPainter({required this.capture, required this.redeploy});

  final bool capture;
  final bool redeploy;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    if (capture) {
      final glow = Paint()
        ..color = const Color(0x55FF6F62)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 7;
      final line = Paint()
        ..color = const Color(0xFFFF8E80)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3;
      canvas.drawCircle(center, size.shortestSide * .44, glow);
      canvas.drawCircle(center, size.shortestSide * .44, line);
      return;
    }

    final color = redeploy ? const Color(0xFF63D4CD) : const Color(0xFFE5C866);
    final glow = Paint()
      ..color = color.withValues(alpha: .32)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    final fill = Paint()..color = color.withValues(alpha: .8);
    canvas.drawCircle(center, size.shortestSide * .35, glow);
    canvas.drawCircle(center, size.shortestSide * .2, fill);
    if (redeploy) {
      final ring = Paint()
        ..color = color.withValues(alpha: .9)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2;
      canvas.drawCircle(center, size.shortestSide * .38, ring);
    }
  }

  @override
  bool shouldRepaint(covariant _LegalTargetPainter oldDelegate) {
    return capture != oldDelegate.capture || redeploy != oldDelegate.redeploy;
  }
}

class ProductionCheckPulse extends StatefulWidget {
  const ProductionCheckPulse({required this.child, super.key});

  final Widget child;

  @override
  State<ProductionCheckPulse> createState() => _ProductionCheckPulseState();
}

class _ProductionCheckPulseState extends State<ProductionCheckPulse>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 520),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final reduced = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    if (reduced) {
      _controller.stop();
      _controller.value = .85;
    } else if (!_controller.isAnimating && _controller.value == 0) {
      _controller.forward();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      child: widget.child,
      builder: (context, child) {
        return Stack(
          alignment: Alignment.center,
          children: [
            IgnorePointer(
              child: CustomPaint(
                key: const ValueKey('board-king-check-pulse'),
                size: const Size.square(86),
                painter: _CheckPulsePainter(progress: _controller.value),
              ),
            ),
            child!,
          ],
        );
      },
    );
  }
}

class _CheckPulsePainter extends CustomPainter {
  const _CheckPulsePainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final eased = Curves.easeInOut.transform(progress);
    final radius = size.shortestSide * (.32 + eased * .12);
    final glow = Paint()
      ..color = const Color(0xFFFF4B43).withValues(alpha: .26 + eased * .24)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 9 + eased * 5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7;
    final ring = Paint()
      ..color = const Color(0xFFFF9A8F).withValues(alpha: .65 + eased * .25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2;
    canvas.drawCircle(center, radius, glow);
    canvas.drawCircle(center, radius, ring);

    final tick = Paint()
      ..color = const Color(0xFFFFD0C9).withValues(alpha: .55 + eased * .3)
      ..strokeWidth = 1.5;
    for (var i = 0; i < 8; i++) {
      final angle = math.pi * i / 4;
      final inner = Offset(
        center.dx + math.cos(angle) * (radius + 3),
        center.dy + math.sin(angle) * (radius + 3),
      );
      final outer = Offset(
        center.dx + math.cos(angle) * (radius + 8),
        center.dy + math.sin(angle) * (radius + 8),
      );
      canvas.drawLine(inner, outer, tick);
    }
  }

  @override
  bool shouldRepaint(covariant _CheckPulsePainter oldDelegate) {
    return progress != oldDelegate.progress;
  }
}

class ProductionFinalBoardDimOverlay extends StatelessWidget {
  const ProductionFinalBoardDimOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return const Positioned.fill(
      child: IgnorePointer(
        child: DecoratedBox(
          key: ValueKey('final-board-dim-overlay'),
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.center,
              radius: .92,
              colors: [Color(0x38000000), Color(0xB8000000)],
              stops: [.46, 1],
            ),
          ),
        ),
      ),
    );
  }
}

class ProductionRedeployGhostToken extends StatelessWidget {
  const ProductionRedeployGhostToken({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Opacity(
        key: const ValueKey('board-redeploy-ghost-token'),
        opacity: .42,
        child: Transform.scale(scale: .82, child: child),
      ),
    );
  }
}

class ProductionThreatLine extends StatelessWidget {
  const ProductionThreatLine({required this.from, required this.to, super.key});

  final Alignment from;
  final Alignment to;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: IgnorePointer(
        child: CustomPaint(
          key: const ValueKey('board-threat-line'),
          painter: _ThreatLinePainter(from: from, to: to),
        ),
      ),
    );
  }
}

class _ThreatLinePainter extends CustomPainter {
  const _ThreatLinePainter({required this.from, required this.to});

  final Alignment from;
  final Alignment to;

  @override
  void paint(Canvas canvas, Size size) {
    final start = from.alongSize(size);
    final end = to.alongSize(size);
    final glow = Paint()
      ..color = const Color(0x66FF4238)
      ..strokeWidth = 12
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9);
    final line = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFFFD0C9), Color(0xFFFF4238)],
      ).createShader(Rect.fromPoints(start, end))
      ..strokeWidth = 2.6
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(start, end, glow);
    canvas.drawLine(start, end, line);
  }

  @override
  bool shouldRepaint(covariant _ThreatLinePainter oldDelegate) {
    return from != oldDelegate.from || to != oldDelegate.to;
  }
}

class ProductionRedAlertFlash extends StatefulWidget {
  const ProductionRedAlertFlash({super.key});

  @override
  State<ProductionRedAlertFlash> createState() =>
      _ProductionRedAlertFlashState();
}

class _ProductionRedAlertFlashState extends State<ProductionRedAlertFlash>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final reduced = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    if (reduced) {
      _controller.value = .7;
    } else if (_controller.value == 0) {
      _controller.forward();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) {
            final wave = math.sin(_controller.value * math.pi);
            return DecoratedBox(
              key: const ValueKey('vfx-red-alert-flash'),
              decoration: BoxDecoration(
                border: Border.all(
                  color: Color.fromRGBO(255, 45, 40, .12 + wave * .42),
                  width: 10 + wave * 8,
                ),
                gradient: RadialGradient(
                  colors: [
                    Colors.transparent,
                    Color.fromRGBO(170, 0, 0, .04 + wave * .16),
                  ],
                  stops: const [.65, 1],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class ProductionRollFlash extends StatefulWidget {
  const ProductionRollFlash({required this.success, super.key});

  final bool success;

  @override
  State<ProductionRollFlash> createState() => _ProductionRollFlashState();
}

class _ProductionRollFlashState extends State<ProductionRollFlash>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 460),
    )..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduced = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) {
            final progress = reduced ? .78 : _controller.value;
            return CustomPaint(
              key: const ValueKey('vfx-roll-flash'),
              painter: _RollFlashPainter(
                progress: progress,
                success: widget.success,
              ),
            );
          },
        ),
      ),
    );
  }
}

class _RollFlashPainter extends CustomPainter {
  const _RollFlashPainter({required this.progress, required this.success});

  final double progress;
  final bool success;

  @override
  void paint(Canvas canvas, Size size) {
    final wave = math.sin(progress * math.pi);
    final center = size.center(Offset.zero);
    final color = success ? const Color(0xFF8EE6A0) : const Color(0xFFFF766E);
    final paint = Paint()
      ..color = color.withValues(alpha: wave * .55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7);
    canvas.drawCircle(center, 38 + progress * size.shortestSide * .38, paint);
    for (var i = 0; i < 12; i++) {
      final angle = i * math.pi / 6;
      final inner = 42 + progress * size.shortestSide * .22;
      final outer = inner + 12 + wave * 18;
      canvas.drawLine(
        center + Offset(math.cos(angle) * inner, math.sin(angle) * inner),
        center + Offset(math.cos(angle) * outer, math.sin(angle) * outer),
        paint..strokeWidth = 2,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RollFlashPainter oldDelegate) {
    return progress != oldDelegate.progress || success != oldDelegate.success;
  }
}

class ProductionOfferCoinTrail extends StatefulWidget {
  const ProductionOfferCoinTrail({super.key});

  @override
  State<ProductionOfferCoinTrail> createState() =>
      _ProductionOfferCoinTrailState();
}

class _ProductionOfferCoinTrailState extends State<ProductionOfferCoinTrail>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 640),
    )..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduced = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) => CustomPaint(
            key: const ValueKey('vfx-offer-coin-trail'),
            painter: _CoinTrailPainter(
              progress: reduced ? 1 : _controller.value,
            ),
          ),
        ),
      ),
    );
  }
}

class _CoinTrailPainter extends CustomPainter {
  const _CoinTrailPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(size.width * .22, size.height * .12)
      ..quadraticBezierTo(
        size.width * .32,
        size.height * .55,
        size.width * .5,
        size.height * .48,
      );
    final metric = path.computeMetrics().first;
    final paint = Paint()..color = const Color(0xFFE7BF59);
    for (var i = 0; i < 7; i++) {
      final local = (progress - i * .075).clamp(0.0, 1.0);
      if (local <= 0 || local >= 1) continue;
      final tangent = metric.getTangentForOffset(metric.length * local);
      if (tangent == null) continue;
      paint.color = const Color(0xFFE7BF59).withValues(alpha: 1 - local * .45);
      canvas.drawCircle(tangent.position, 4.5 + (i.isEven ? 1.5 : 0), paint);
      canvas.drawCircle(
        tangent.position,
        7,
        Paint()
          ..color = const Color(0x55765218)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _CoinTrailPainter oldDelegate) {
    return progress != oldDelegate.progress;
  }
}

class ProductionFailureCoinScatter extends StatefulWidget {
  const ProductionFailureCoinScatter({super.key});

  @override
  State<ProductionFailureCoinScatter> createState() =>
      _ProductionFailureCoinScatterState();
}

class _ProductionFailureCoinScatterState
    extends State<ProductionFailureCoinScatter>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduced = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) => CustomPaint(
            key: const ValueKey('vfx-failure-coin-scatter'),
            painter: _CoinScatterPainter(
              progress: reduced ? .76 : _controller.value,
            ),
          ),
        ),
      ),
    );
  }
}

class _CoinScatterPainter extends CustomPainter {
  const _CoinScatterPainter({required this.progress});

  final double progress;

  static const vectors = <Offset>[
    Offset(-.42, -.72),
    Offset(-.75, -.2),
    Offset(-.56, .48),
    Offset(-.18, .78),
    Offset(.25, .7),
    Offset(.62, .38),
    Offset(.76, -.16),
    Offset(.4, -.68),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final eased = Curves.easeOutCubic.transform(progress);
    for (var i = 0; i < vectors.length; i++) {
      final offset = vectors[i] * (46 + eased * 92);
      final coin = center + offset + Offset(0, 54 * progress * progress);
      final alpha = (1 - progress * .72).clamp(0.0, 1.0);
      canvas.drawCircle(
        coin,
        5 + (i.isEven ? 1.5 : 0),
        Paint()..color = const Color(0xFFE7BF59).withValues(alpha: alpha),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _CoinScatterPainter oldDelegate) {
    return progress != oldDelegate.progress;
  }
}

class ProductionMerchantPayoutCoinBurst extends StatefulWidget {
  const ProductionMerchantPayoutCoinBurst({required this.toRight, super.key});

  final bool toRight;

  @override
  State<ProductionMerchantPayoutCoinBurst> createState() =>
      _ProductionMerchantPayoutCoinBurstState();
}

class _ProductionMerchantPayoutCoinBurstState
    extends State<ProductionMerchantPayoutCoinBurst>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 760),
    )..forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduced = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, _) => CustomPaint(
            key: const ValueKey('vfx-merchant-payout-coin-burst'),
            painter: _PayoutBurstPainter(
              progress: reduced ? .72 : _controller.value,
              toRight: widget.toRight,
            ),
          ),
        ),
      ),
    );
  }
}

class _PayoutBurstPainter extends CustomPainter {
  const _PayoutBurstPainter({required this.progress, required this.toRight});

  final double progress;
  final bool toRight;

  @override
  void paint(Canvas canvas, Size size) {
    final origin = Offset(size.width * .5, 74);
    final destination = Offset(size.width * (toRight ? .81 : .19), 56);
    final eased = Curves.easeOutCubic.transform(progress);
    final center = Offset.lerp(origin, destination, eased)!;
    for (var i = 0; i < 11; i++) {
      final angle = i * math.pi * 2 / 11;
      final radius = 8 + math.sin(progress * math.pi) * (22 + i % 3 * 6);
      final point = center + Offset(math.cos(angle), math.sin(angle)) * radius;
      canvas.drawCircle(
        point,
        4.5,
        Paint()
          ..color = const Color(
            0xFFE7BF59,
          ).withValues(alpha: (1 - progress * .62).clamp(0.0, 1.0)),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _PayoutBurstPainter oldDelegate) {
    return progress != oldDelegate.progress || toRight != oldDelegate.toRight;
  }
}
