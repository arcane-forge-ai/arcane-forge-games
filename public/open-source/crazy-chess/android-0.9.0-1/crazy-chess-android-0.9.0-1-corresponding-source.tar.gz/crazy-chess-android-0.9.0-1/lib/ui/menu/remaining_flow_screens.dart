import 'dart:async';

import 'package:flutter/material.dart';

import '../../app/app_locale_controller.dart';
import '../../audio/audio_settings.dart';
import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../domain/economy_config.dart';
import '../../game/game_controller.dart';
import '../../last_piece/last_piece_session_controller.dart';
import '../../l10n/app_localizations.dart';
import '../../l10n/ui_copy.dart';
import '../../living_campaign/living_campaign_settings.dart';
import '../../playtest/playtest_data_exporter.dart';
import '../effects/production_board_effects.dart';
import '../legal/open_source_licenses_screen.dart';
import '../shared/country_crest.dart';
import '../shared/country_ability_copy.dart';
import '../shared/formatters.dart';
import 'country_representative_art.dart';
import 'hifi_menu_widgets.dart';

const _remainingAssetRoot = productionAssetRoot;

const _roles = <PieceType>[
  PieceType.king,
  PieceType.queen,
  PieceType.rook,
  PieceType.bishop,
  PieceType.knight,
  PieceType.pawn,
];

enum LoadoutCategory { board, token, banner, contractSeal, resultVfx, merchant }

enum SettingsCategory {
  display,
  audio,
  controls,
  accessibility,
  gameplay,
  language,
  livingAi,
  playtestData,
  openSourceLicenses,
}

String _loadoutCategoryLabel(AppLocalizations l10n, LoadoutCategory category) =>
    switch (category) {
      LoadoutCategory.board => l10n.loadoutCategoryBoard,
      LoadoutCategory.token => l10n.loadoutCategoryToken,
      LoadoutCategory.banner => l10n.loadoutCategoryBanner,
      LoadoutCategory.contractSeal => l10n.loadoutCategoryContractSeal,
      LoadoutCategory.resultVfx => l10n.loadoutCategoryResultVfx,
      LoadoutCategory.merchant => l10n.loadoutCategoryMerchant,
    };

String _settingsCategoryLabel(
  AppLocalizations l10n,
  SettingsCategory category,
) => switch (category) {
  SettingsCategory.display => l10n.settingsCategoryDisplay,
  SettingsCategory.audio => l10n.settingsCategoryAudio,
  SettingsCategory.controls => l10n.settingsCategoryControls,
  SettingsCategory.accessibility => l10n.settingsCategoryAccessibility,
  SettingsCategory.gameplay => l10n.settingsCategoryGameplay,
  SettingsCategory.language => l10n.settingsCategoryLanguage,
  SettingsCategory.livingAi => l10n.settingsCategoryLivingAi,
  SettingsCategory.playtestData => l10n.settingsCategoryPlaytestData,
  SettingsCategory.openSourceLicenses =>
    l10n.settingsCategoryOpenSourceLicenses,
};

class CountryDetailScreen extends StatelessWidget {
  const CountryDetailScreen({
    required this.countryId,
    required this.onBack,
    required this.onInspectPiece,
    required this.onLoadout,
    super.key,
  });

  final String countryId;
  final VoidCallback onBack;
  final ValueChanged<PieceType> onInspectPiece;
  final VoidCallback onLoadout;

  @override
  Widget build(BuildContext context) {
    final country = countries[countryId]!;
    return HifiScaffold(
      backdropAsset: '$_remainingAssetRoot/s06_country_detail_bg.webp',
      backdropOpacity: .5,
      heroAsset: '$_remainingAssetRoot/mercantile_representative.webp',
      heroAlignment: Alignment.centerLeft,
      heroWidth: 510,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(30, 18, 30, 24),
        child: Column(
          children: [
            HifiTopBar(
              screenCode: 'S06',
              title: 'Country Detail',
              onBack: onBack,
              trailing: const [
                HifiIconSquare(icon: Icons.menu_book, label: 'Rules'),
                SizedBox(width: 10),
                HifiIconSquare(icon: Icons.settings, label: 'Settings'),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Row(
                children: [
                  SizedBox(
                    width: 390,
                    child: _CountryHeroCard(country: country),
                  ),
                  const SizedBox(width: 26),
                  Expanded(
                    child: Column(
                      children: [
                        Expanded(
                          flex: 4,
                          child: HifiPanel(
                            padding: EdgeInsets.zero,
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                Opacity(
                                  opacity: .22,
                                  child: Image.asset(
                                    '$_remainingAssetRoot/ui_panel_9slice.webp',
                                    fit: BoxFit.fill,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                    26,
                                    22,
                                    26,
                                    22,
                                  ),
                                  child: Row(
                                    children: [
                                      CountryCrest(country: country, size: 138),
                                      const SizedBox(width: 24),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              country.name,
                                              style: const TextStyle(
                                                color: hifiInk,
                                                fontFamily: 'Georgia',
                                                fontSize: 42,
                                                fontWeight: FontWeight.w900,
                                                height: 1,
                                              ),
                                            ),
                                            const SizedBox(height: 12),
                                            Text(
                                              country.fantasy,
                                              style: const TextStyle(
                                                color: hifiMuted,
                                                fontSize: 17,
                                                height: 1.35,
                                              ),
                                            ),
                                            const SizedBox(height: 18),
                                            Wrap(
                                              spacing: 10,
                                              runSpacing: 10,
                                              children: [
                                                _TraitChip(
                                                  icon: Icons.monetization_on,
                                                  label:
                                                      'Start ${signed(country.startingGoldModifier)}',
                                                ),
                                                _TraitChip(
                                                  icon: Icons.local_shipping,
                                                  label:
                                                      'Merchant ${signed(country.merchantPayoutModifier)}',
                                                ),
                                                _TraitChip(
                                                  icon: Icons.gavel,
                                                  label:
                                                      'Offer ${signed(country.offenseModifier)}',
                                                ),
                                                _TraitChip(
                                                  icon: Icons.shield,
                                                  label:
                                                      'Loyalty ${country.loyaltyStartSummary}',
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(width: 22),
                                      SizedBox(
                                        width: 360,
                                        child: _CountryRulePanel(
                                          country: country,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 18),
                        Expanded(
                          flex: 3,
                          child: Row(
                            children: [
                              for (final role in _roles) ...[
                                Expanded(
                                  child: _RolePreviewCard(
                                    country: country,
                                    role: role,
                                    onPressed: () => onInspectPiece(role),
                                  ),
                                ),
                                if (role != _roles.last)
                                  const SizedBox(width: 12),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(height: 18),
                        Row(
                          children: [
                            Expanded(
                              child: HifiPrimaryButton(
                                label: 'Inspect Piece',
                                icon: Icons.person_search,
                                onPressed: () =>
                                    onInspectPiece(PieceType.queen),
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: HifiPrimaryButton(
                                label: 'Visual Kit',
                                icon: Icons.palette,
                                onPressed: onLoadout,
                              ),
                            ),
                            const SizedBox(width: 16),
                            const Expanded(
                              child: HifiPrimaryButton(
                                label: 'Practice',
                                icon: Icons.lock,
                                onPressed: null,
                                variant: HifiButtonVariant.dark,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CourtDormScreen extends StatelessWidget {
  const CourtDormScreen({
    required this.lastPieceController,
    required this.countryId,
    required this.onCountryChanged,
    required this.onLobby,
    required this.onCollection,
    required this.onProfile,
    required this.onLoadout,
    required this.onRecords,
    required this.onRules,
    required this.onSettings,
    super.key,
  });

  final LastPieceSessionController lastPieceController;
  final String countryId;
  final ValueChanged<String> onCountryChanged;
  final VoidCallback onLobby;
  final VoidCallback onCollection;
  final VoidCallback onProfile;
  final VoidCallback onLoadout;
  final VoidCallback onRecords;
  final VoidCallback onRules;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    final country = countries[countryId]!;
    final countryOptions = selectableCountries.toList(growable: false);
    final familiarity = lastPieceController.familiarityFor(countryId);
    final chronicleUnlocked = lastPieceController.hasReward(
      countryId,
      'chronicle1',
    );
    final galleryUnlocked = lastPieceController.hasReward(
      countryId,
      'gallery1',
    );
    final courtMusicUnlocked = lastPieceController.hasReward(
      countryId,
      'music_court',
    );
    final battleMusicUnlocked = lastPieceController.hasReward(
      countryId,
      'music_battle',
    );
    return _ProductScaffold(
      screenCode: 'S10',
      title: 'Court Dorm',
      activeNav: HifiNavigationDestination.country,
      backdrop: '$_remainingAssetRoot/s10_court_bg.webp',
      onLobby: onLobby,
      onCollection: onCollection,
      onLoadout: onLoadout,
      onRecords: onRecords,
      onRules: onRules,
      onSettings: onSettings,
      child: Row(
        children: [
          SizedBox(width: 500, child: _CountryHeroCard(country: country)),
          const SizedBox(width: 28),
          Expanded(
            child: Column(
              children: [
                HifiSectionTitle(
                  '${country.shortName} Court',
                  subtitle:
                      'A character-forward hub for roster browsing and visual setup.',
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    for (final option in countryOptions) ...[
                      Expanded(
                        child: _CountryMiniButton(
                          country: option,
                          selected: option.id == country.id,
                          onPressed: () => onCountryChanged(option.id),
                        ),
                      ),
                      if (option != countryOptions.last)
                        const SizedBox(width: 12),
                    ],
                  ],
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        child: HifiPlaque(
                          title: 'Collection',
                          subtitle: 'Browse country x role matrix',
                          icon: Icons.grid_view,
                          selected: true,
                          height: double.infinity,
                          onPressed: onCollection,
                        ),
                      ),
                      const SizedBox(width: 18),
                      Expanded(
                        child: HifiPlaque(
                          title: 'Profile',
                          subtitle: 'Inspect a signature court piece',
                          icon: Icons.person_search,
                          height: double.infinity,
                          onPressed: onProfile,
                        ),
                      ),
                      const SizedBox(width: 18),
                      Expanded(
                        child: HifiPlaque(
                          title: 'Loadout',
                          subtitle: 'Preview board and effect cosmetics',
                          icon: Icons.palette,
                          height: double.infinity,
                          onPressed: onLoadout,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                HifiPanel(
                  child: Column(
                    children: [
                      Row(
                        children: [
                          CountryCrest(country: country, size: 64),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '$familiarity FAMILIARITY',
                                  key: ValueKey('court-familiarity-$countryId'),
                                  style: const TextStyle(
                                    color: hifiGold,
                                    fontSize: 19,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 7),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: LinearProgressIndicator(
                                    value: (familiarity / 100).clamp(0, 1),
                                    minHeight: 10,
                                    backgroundColor: const Color(0xFF202B2A),
                                    color: country.secondaryColor,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  familiarity < 25
                                      ? '${25 - familiarity} to Chronicle I'
                                      : familiarity < 100
                                      ? '${100 - familiarity} to Gallery I'
                                      : 'All Familiarity I rewards unlocked',
                                  style: const TextStyle(
                                    color: hifiMuted,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _FamiliarityRewardCard(
                            key: ValueKey('court-chronicle-$countryId'),
                            icon: Icons.menu_book,
                            title: 'Chronicle I',
                            threshold: 25,
                            unlocked: chronicleUnlocked,
                            onPressed: chronicleUnlocked
                                ? () => _showFamiliarityReward(
                                    context,
                                    title: '${country.shortName} Chronicle I',
                                    message:
                                        'Reward unlocked. Status: draft '
                                        'awaiting owner approval. No final '
                                        'in-game Chronicle prose has been '
                                        'approved yet.',
                                  )
                                : null,
                          ),
                          _FamiliarityRewardCard(
                            key: ValueKey('court-music-$countryId'),
                            icon: Icons.library_music,
                            title: 'Court Theme',
                            threshold: 25,
                            unlocked: courtMusicUnlocked,
                            onPressed: courtMusicUnlocked
                                ? () => _showFamiliarityReward(
                                    context,
                                    title: '${country.shortName} Court Theme',
                                    message:
                                        'Unlocked and active in Court, '
                                        'Collection, Profile, and Loadout.',
                                  )
                                : null,
                          ),
                          _FamiliarityRewardCard(
                            key: ValueKey('battle-music-$countryId'),
                            icon: Icons.graphic_eq,
                            title: 'Battle Anthem',
                            threshold: 100,
                            unlocked: battleMusicUnlocked,
                            onPressed: battleMusicUnlocked
                                ? () => _showFamiliarityReward(
                                    context,
                                    title: '${country.shortName} Battle Anthem',
                                    message:
                                        'Unlocked and active when this court '
                                        'enters a standard match.',
                                  )
                                : null,
                          ),
                          _FamiliarityRewardCard(
                            key: ValueKey('court-gallery-$countryId'),
                            icon: Icons.photo_library,
                            title: 'Gallery I',
                            threshold: 100,
                            unlocked: galleryUnlocked,
                            onPressed: galleryUnlocked
                                ? () => _showFamiliarityReward(
                                    context,
                                    title: '${country.shortName} Gallery I',
                                    message:
                                        'Reward unlocked. Status: brief only. '
                                        'No Gallery I image candidates have '
                                        'been generated yet.',
                                  )
                                : null,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showFamiliarityReward(
    BuildContext context, {
    required String title,
    required String message,
  }) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}

class _FamiliarityRewardCard extends StatelessWidget {
  const _FamiliarityRewardCard({
    required this.icon,
    required this.title,
    required this.threshold,
    required this.unlocked,
    required this.onPressed,
    super.key,
  });

  final IconData icon;
  final String title;
  final int threshold;
  final bool unlocked;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 168,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: unlocked
                  ? const Color(0xCC16392D)
                  : const Color(0xCC171A1D),
              border: Border.all(
                color: unlocked
                    ? const Color(0xFF79D5A4)
                    : const Color(0xFF5F615C),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Icon(
                    unlocked ? icon : Icons.lock,
                    color: unlocked ? const Color(0xFF91E3B5) : hifiMuted,
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            color: hifiInk,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        Text(
                          unlocked ? 'OPEN' : '$threshold required',
                          style: TextStyle(
                            color: unlocked
                                ? const Color(0xFF91E3B5)
                                : hifiMuted,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CollectionMatrixScreen extends StatelessWidget {
  const CollectionMatrixScreen({
    required this.countryId,
    required this.role,
    required this.onCountryChanged,
    required this.onRoleChanged,
    required this.onViewProfile,
    required this.onLobby,
    required this.onCourt,
    required this.onLoadout,
    required this.onRecords,
    required this.onRules,
    required this.onSettings,
    super.key,
  });

  final String countryId;
  final PieceType role;
  final ValueChanged<String> onCountryChanged;
  final ValueChanged<PieceType> onRoleChanged;
  final VoidCallback onViewProfile;
  final VoidCallback onLobby;
  final VoidCallback onCourt;
  final VoidCallback onLoadout;
  final VoidCallback onRecords;
  final VoidCallback onRules;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    final selectedCountry = countries[countryId]!;
    return _ProductScaffold(
      screenCode: 'S11',
      title: 'Country-Piece Collection Matrix',
      activeNav: HifiNavigationDestination.roster,
      backdrop: '$_remainingAssetRoot/s10_court_bg.webp',
      onLobby: onLobby,
      onCollection: null,
      onCourt: onCourt,
      onLoadout: onLoadout,
      onRecords: onRecords,
      onRules: onRules,
      onSettings: onSettings,
      child: Row(
        children: [
          SizedBox(
            width: 420,
            child: HifiPanel(
              padding: EdgeInsets.zero,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    '$_remainingAssetRoot/mercantile_queen_bust.webp',
                    fit: BoxFit.contain,
                  ),
                  DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          selectedCountry.color.withValues(alpha: .2),
                          Colors.black.withValues(alpha: .86),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 22,
                    right: 22,
                    bottom: 22,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CountryCrest(country: selectedCountry, size: 72),
                        const SizedBox(height: 10),
                        Text(
                          '${selectedCountry.shortName} ${pieceTypeLabel(role)}',
                          style: const TextStyle(
                            color: hifiInk,
                            fontFamily: 'Georgia',
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _roleFlavor(role),
                          style: const TextStyle(
                            color: hifiMuted,
                            fontSize: 15,
                            height: 1.35,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 24),
          Expanded(
            child: Column(
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: _FilterPill(label: 'Country', value: 'All'),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: _FilterPill(label: 'Role', value: 'All'),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: _FilterPill(label: 'Personality', value: 'All'),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: _FilterPill(
                        label: 'Owned / Favorite',
                        value: 'All',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: HifiPanel(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const SizedBox(width: 178),
                            for (final roleOption in _roles)
                              Expanded(
                                child: _MatrixHeader(
                                  label: pieceTypeLabel(roleOption),
                                  selected: roleOption == role,
                                  onPressed: () => onRoleChanged(roleOption),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Expanded(
                          child: ListView.separated(
                            itemCount: selectableCountries.length,
                            separatorBuilder: (_, _) =>
                                const SizedBox(height: 8),
                            itemBuilder: (context, rowIndex) {
                              final country = selectableCountries.elementAt(
                                rowIndex,
                              );
                              return SizedBox(
                                height: 82,
                                child: Row(
                                  children: [
                                    SizedBox(
                                      width: 178,
                                      child: _CountryMatrixLabel(
                                        country: country,
                                        selected: country.id == countryId,
                                        onPressed: () =>
                                            onCountryChanged(country.id),
                                      ),
                                    ),
                                    for (final roleOption in _roles)
                                      Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                            left: 8,
                                          ),
                                          child: _MatrixCell(
                                            country: country,
                                            role: roleOption,
                                            selected:
                                                country.id == countryId &&
                                                roleOption == role,
                                            locked: rowIndex > 3,
                                            onPressed: () {
                                              onCountryChanged(country.id);
                                              onRoleChanged(roleOption);
                                            },
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerRight,
                  child: SizedBox(
                    width: 340,
                    child: HifiPrimaryButton(
                      label: 'View Profile',
                      icon: Icons.person,
                      variant: HifiButtonVariant.gold,
                      onPressed: onViewProfile,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class PieceProfileScreen extends StatelessWidget {
  const PieceProfileScreen({
    required this.countryId,
    required this.role,
    required this.onBack,
    required this.onLoadout,
    super.key,
  });

  final String countryId;
  final PieceType role;
  final VoidCallback onBack;
  final VoidCallback onLoadout;

  @override
  Widget build(BuildContext context) {
    final country = countries[countryId]!;
    final price = fairPriceAnchors[role];
    return HifiScaffold(
      backdropAsset: '$_remainingAssetRoot/s10_court_bg.webp',
      backdropOpacity: .42,
      heroAsset: '$_remainingAssetRoot/mercantile_representative.webp',
      heroAlignment: Alignment.centerLeft,
      heroWidth: 540,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(30, 18, 30, 26),
        child: Column(
          children: [
            HifiTopBar(
              screenCode: 'S12',
              title: 'Piece Profile',
              onBack: onBack,
            ),
            const SizedBox(height: 18),
            Expanded(
              child: Row(
                children: [
                  const SizedBox(width: 480),
                  Expanded(
                    child: HifiPanel(
                      padding: EdgeInsets.zero,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Opacity(
                            opacity: .18,
                            child: Image.asset(
                              '$_remainingAssetRoot/ui_panel_9slice.webp',
                              fit: BoxFit.fill,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(28),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 5,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          CountryCrest(
                                            country: country,
                                            size: 82,
                                          ),
                                          const SizedBox(width: 16),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  '${country.shortName} ${pieceTypeLabel(role)}',
                                                  style: const TextStyle(
                                                    color: hifiInk,
                                                    fontFamily: 'Georgia',
                                                    fontSize: 42,
                                                    fontWeight: FontWeight.w900,
                                                    height: 1,
                                                  ),
                                                ),
                                                const SizedBox(height: 8),
                                                Text(
                                                  _roleFlavor(role),
                                                  style: TextStyle(
                                                    color:
                                                        country.secondaryColor,
                                                    fontSize: 18,
                                                    fontWeight: FontWeight.w800,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 24),
                                      Text(
                                        country.fantasy,
                                        style: const TextStyle(
                                          color: hifiMuted,
                                          fontSize: 17,
                                          height: 1.38,
                                        ),
                                      ),
                                      const SizedBox(height: 28),
                                      Wrap(
                                        spacing: 12,
                                        runSpacing: 12,
                                        children: [
                                          _TraitChip(
                                            icon: Icons.monetization_on,
                                            label: price == null
                                                ? 'Cannot buy'
                                                : 'Offer anchor $price',
                                          ),
                                          _TraitChip(
                                            icon: Icons.percent,
                                            label: role == PieceType.king
                                                ? 'Protected'
                                                : 'Base ${baseChances[role]}%',
                                          ),
                                          _TraitChip(
                                            icon: Icons.visibility_off,
                                            label: role == PieceType.king
                                                ? 'No contract'
                                                : 'Resolve hidden',
                                          ),
                                          _TraitChip(
                                            icon: Icons.account_balance,
                                            label: country.shortName,
                                          ),
                                        ],
                                      ),
                                      const Spacer(),
                                      const Text(
                                        'Profile data is a product-facing preview. Exact loyalty and chance appear only for the current offer after a valid reveal.',
                                        style: TextStyle(
                                          color: hifiMuted,
                                          fontSize: 14,
                                          height: 1.35,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 28),
                                Expanded(
                                  flex: 4,
                                  child: Column(
                                    children: [
                                      Expanded(
                                        child: _RoleTokenPreview(
                                          country: country,
                                          role: role,
                                        ),
                                      ),
                                      const SizedBox(height: 18),
                                      HifiPrimaryButton(
                                        label: 'Preview Token',
                                        icon: Icons.token,
                                        onPressed: () {},
                                      ),
                                      const SizedBox(height: 12),
                                      HifiPrimaryButton(
                                        label: 'Visual Loadout',
                                        icon: Icons.palette,
                                        onPressed: onLoadout,
                                      ),
                                      const SizedBox(height: 12),
                                      const HifiPrimaryButton(
                                        label: 'Compare Variants',
                                        icon: Icons.lock,
                                        onPressed: null,
                                        variant: HifiButtonVariant.dark,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LoadoutScreen extends StatelessWidget {
  const LoadoutScreen({
    required this.selectedCategory,
    required this.onCategoryChanged,
    required this.onLobby,
    required this.onCollection,
    required this.onCourt,
    required this.onRecords,
    required this.onRules,
    required this.onSettings,
    super.key,
  });

  final LoadoutCategory selectedCategory;
  final ValueChanged<LoadoutCategory> onCategoryChanged;
  final VoidCallback onLobby;
  final VoidCallback onCollection;
  final VoidCallback onCourt;
  final VoidCallback onRecords;
  final VoidCallback onRules;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    return _ProductScaffold(
      screenCode: 'S14',
      title: l10n.loadoutTitle,
      activeNav: HifiNavigationDestination.loadout,
      backdrop: '$_remainingAssetRoot/s10_court_bg.webp',
      onLobby: onLobby,
      onCollection: onCollection,
      onCourt: onCourt,
      onLoadout: null,
      onRecords: onRecords,
      onRules: onRules,
      onSettings: onSettings,
      child: Row(
        children: [
          SizedBox(
            width: 300,
            child: HifiPanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    l10n.loadoutSlots,
                    style: const TextStyle(
                      color: hifiInk,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 18),
                  for (var i = 1; i <= 5; i++) ...[
                    _SlotRow(index: i, active: i == 1),
                    const SizedBox(height: 10),
                  ],
                  const Spacer(),
                  const LockedBadge(),
                ],
              ),
            ),
          ),
          const SizedBox(width: 24),
          SizedBox(
            width: 330,
            child: HifiPanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    l10n.commonCategories,
                    style: const TextStyle(
                      color: hifiInk,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 16),
                  for (final category in LoadoutCategory.values) ...[
                    _CategoryButton(
                      label: _loadoutCategoryLabel(l10n, category),
                      selected: selectedCategory == category,
                      onPressed: () => onCategoryChanged(category),
                    ),
                    const SizedBox(height: 10),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(width: 24),
          Expanded(
            child: HifiPanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  HifiSectionTitle(
                    _loadoutCategoryLabel(l10n, selectedCategory),
                    subtitle: l10n.loadoutPreviewDescription,
                  ),
                  const SizedBox(height: 22),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 3,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                      childAspectRatio: 1.4,
                      children: [
                        for (var i = 0; i < 9; i++)
                          _PreviewTile(
                            label: i == 0 ? 'Equipped' : 'Future',
                            selected: i == 0,
                            locked: i > 2,
                          ),
                      ],
                    ),
                  ),
                  Row(
                    children: const [
                      Expanded(
                        child: HifiPrimaryButton(
                          label: 'Save Set',
                          icon: Icons.lock,
                          onPressed: null,
                          variant: HifiButtonVariant.dark,
                        ),
                      ),
                      SizedBox(width: 14),
                      Expanded(
                        child: HifiPrimaryButton(
                          label: 'Set Active',
                          icon: Icons.check,
                          onPressed: null,
                          variant: HifiButtonVariant.dark,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PostgameSummaryScreen extends StatelessWidget {
  const PostgameSummaryScreen({
    required this.controller,
    required this.onLobby,
    required this.onRematch,
    super.key,
  });

  final GameController controller;
  final VoidCallback onLobby;
  final VoidCallback onRematch;

  @override
  Widget build(BuildContext context) {
    final hasMatch = controller.phase == GamePhase.gameOver;
    final winner = controller.winner;
    final winnerCountry = winner == null
        ? null
        : controller.countryForColor(winner);
    final endReason = controller.resolvedGameEndReason;
    return Stack(
      fit: StackFit.expand,
      children: [
        HifiScaffold(
          backdropAsset: '$_remainingAssetRoot/s29_postgame_bg.webp',
          backdropOpacity: .5,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(30, 18, 30, 26),
            child: Column(
              children: [
                HifiTopBar(
                  screenCode: 'S29',
                  title: 'Postgame Summary',
                  trailing: [
                    HifiIconSquare(
                      key: const ValueKey('product-lobby'),
                      icon: Icons.home,
                      label: 'Lobby',
                      onPressed: onLobby,
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        flex: 5,
                        child: HifiPanel(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              HifiSectionTitle(
                                hasMatch ? 'Match Record' : 'No Record Yet',
                                subtitle: hasMatch
                                    ? 'Economy and contract moments from the last local duel.'
                                    : 'Finish a local duel to populate this timeline.',
                              ),
                              const SizedBox(height: 20),
                              Expanded(
                                child: ListView.separated(
                                  itemCount: hasMatch
                                      ? controller.localizedEventLog.length
                                            .clamp(1, 10)
                                            .toInt()
                                      : 4,
                                  separatorBuilder: (_, _) =>
                                      const Divider(color: Color(0x333b4550)),
                                  itemBuilder: (context, index) {
                                    final label = hasMatch
                                        ? controller.localizedEventLog[index]
                                        : [
                                            'Start a local match from Country Select.',
                                            'Resolve a contract to create purchase history.',
                                            'Merchant payouts appear in the match ledger.',
                                            'Checkmate unlocks the final record view.',
                                          ][index];
                                    return _TimelineRow(
                                      index: index + 1,
                                      text: label,
                                      muted: !hasMatch,
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 24),
                      Expanded(
                        flex: 4,
                        child: HifiPanel(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              if (winnerCountry != null) ...[
                                CountryCrest(country: winnerCountry, size: 112),
                                const SizedBox(height: 12),
                              ],
                              Text(
                                !hasMatch
                                    ? 'Awaiting First Result'
                                    : switch (endReason) {
                                        GameEndReason.stalemate => 'Stalemate',
                                        GameEndReason.kingTrapfall =>
                                          '${winnerCountry?.name ?? 'Unknown'} Victory · King Trapfall',
                                        _ =>
                                          '${winnerCountry?.name ?? 'Unknown'} Victory',
                                      },
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: hifiInk,
                                  fontFamily: 'Georgia',
                                  fontSize: 34,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 20),
                              _PostgameStat(
                                label: 'Purchased Pieces',
                                value: '${controller.purchaseSuccesses}',
                              ),
                              _PostgameStat(
                                label: 'Rejected Contracts',
                                value: '${controller.purchaseFailures}',
                              ),
                              _PostgameStat(
                                label: 'White Gold',
                                value:
                                    '${controller.gold[PieceColor.white] ?? 0}',
                              ),
                              _PostgameStat(
                                label: 'Black Gold',
                                value:
                                    '${controller.gold[PieceColor.black] ?? 0}',
                              ),
                              const Spacer(),
                              HifiPrimaryButton(
                                label: 'Rematch',
                                icon: Icons.refresh,
                                onPressed: onRematch,
                              ),
                              const SizedBox(height: 12),
                              HifiPrimaryButton(
                                label: 'Lobby',
                                icon: Icons.home,
                                variant: HifiButtonVariant.gold,
                                onPressed: onLobby,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        if (hasMatch && controller.purchaseSuccesses > 0)
          const ProductionOfferCoinTrail(),
        if (hasMatch && controller.purchaseFailures > 0)
          const ProductionFailureCoinScatter(),
        if (hasMatch && controller.lastMerchantPayoutReceiver != null)
          ProductionMerchantPayoutCoinBurst(
            toRight: controller.lastMerchantPayoutReceiver == PieceColor.white,
          ),
      ],
    );
  }
}

class TutorialRulesScreen extends StatelessWidget {
  const TutorialRulesScreen({
    required this.onLobby,
    required this.onCollection,
    required this.onCourt,
    required this.onLoadout,
    required this.onRecords,
    required this.onSettings,
    super.key,
  });

  final VoidCallback onLobby;
  final VoidCallback onCollection;
  final VoidCallback onCourt;
  final VoidCallback onLoadout;
  final VoidCallback onRecords;
  final VoidCallback onSettings;

  @override
  Widget build(BuildContext context) {
    final lessons = const [
      (
        'Normal Chess',
        'Move, capture, check, and checkmate use standard chess rules.',
      ),
      (
        'Gold And Merchant',
        'A route marker pays courts as it reaches each side.',
      ),
      (
        'Purchase Offers',
        'Spend gold on non-king enemy pieces to test loyalty.',
      ),
      (
        'Hidden Resolve',
        'Exact contract chance stays hidden unless a reveal applies.',
      ),
      ('Redeploy', 'Successful purchases must redeploy into the buyer half.'),
      (
        'Country Traits',
        'Each country changes economy, loyalty, or information rules.',
      ),
    ];
    return _ProductScaffold(
      screenCode: 'S30',
      title: 'Tutorial Rules',
      activeNav: HifiNavigationDestination.rules,
      backdrop: '$_remainingAssetRoot/s30_rules_bg.webp',
      onLobby: onLobby,
      onCollection: onCollection,
      onCourt: onCourt,
      onLoadout: onLoadout,
      onRecords: onRecords,
      onRules: null,
      onSettings: onSettings,
      child: Row(
        children: [
          SizedBox(
            width: 330,
            child: HifiPanel(
              child: ListView.separated(
                itemCount: lessons.length,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  return _CategoryButton(
                    label: lessons[index].$1,
                    selected: index == 0,
                    onPressed: () {},
                  );
                },
              ),
            ),
          ),
          const SizedBox(width: 24),
          Expanded(
            child: HifiPanel(
              child: Row(
                children: [
                  Expanded(child: _IllustratedBoardExample()),
                  const SizedBox(width: 26),
                  Expanded(
                    child: ListView.separated(
                      itemCount: lessons.length,
                      separatorBuilder: (_, _) =>
                          const Divider(color: Color(0x333b4550)),
                      itemBuilder: (context, index) {
                        return HifiStatLine(
                          icon: _lessonIcon(index),
                          label: lessons[index].$1,
                          value: lessons[index].$2,
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({
    required this.onLobby,
    required this.onCollection,
    required this.onCourt,
    required this.onLoadout,
    required this.onRecords,
    required this.onRules,
    required this.selectedCategory,
    required this.onCategoryChanged,
    required this.reducedEffects,
    required this.onReducedEffectsChanged,
    required this.audioSettings,
    required this.onMasterVolumeChanged,
    required this.onMusicVolumeChanged,
    required this.onSfxVolumeChanged,
    required this.onMasterMutedChanged,
    required this.onMusicMutedChanged,
    required this.onSfxMutedChanged,
    required this.livingSettingsController,
    required this.onTestLivingAi,
    required this.onExportPlaytestData,
    super.key,
  });

  final VoidCallback onLobby;
  final VoidCallback onCollection;
  final VoidCallback onCourt;
  final VoidCallback onLoadout;
  final VoidCallback onRecords;
  final VoidCallback onRules;
  final SettingsCategory selectedCategory;
  final ValueChanged<SettingsCategory> onCategoryChanged;
  final bool reducedEffects;
  final ValueChanged<bool> onReducedEffectsChanged;
  final GameAudioSettings audioSettings;
  final ValueChanged<double> onMasterVolumeChanged;
  final ValueChanged<double> onMusicVolumeChanged;
  final ValueChanged<double> onSfxVolumeChanged;
  final ValueChanged<bool> onMasterMutedChanged;
  final ValueChanged<bool> onMusicMutedChanged;
  final ValueChanged<bool> onSfxMutedChanged;
  final LivingCampaignSettingsController livingSettingsController;
  final Future<void> Function() onTestLivingAi;
  final Future<PlaytestDataExportResult> Function() onExportPlaytestData;

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    return _ProductScaffold(
      screenCode: 'S31',
      title: l10n.settingsTitle,
      activeNav: HifiNavigationDestination.settings,
      backdrop: '$_remainingAssetRoot/s31_settings_bg.webp',
      onLobby: onLobby,
      onCollection: onCollection,
      onCourt: onCourt,
      onLoadout: onLoadout,
      onRecords: onRecords,
      onRules: onRules,
      onSettings: null,
      child: Row(
        children: [
          SizedBox(
            width: 330,
            child: HifiPanel(
              child: ListView.separated(
                itemCount: SettingsCategory.values.length,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final category = SettingsCategory.values[index];
                  return _CategoryButton(
                    label: _settingsCategoryLabel(l10n, category),
                    selected: selectedCategory == category,
                    onPressed: () => onCategoryChanged(category),
                  );
                },
              ),
            ),
          ),
          const SizedBox(width: 24),
          Expanded(
            child: HifiPanel(
              child: selectedCategory == SettingsCategory.audio
                  ? _AudioMixerPanel(
                      settings: audioSettings,
                      onMasterVolumeChanged: onMasterVolumeChanged,
                      onMusicVolumeChanged: onMusicVolumeChanged,
                      onSfxVolumeChanged: onSfxVolumeChanged,
                      onMasterMutedChanged: onMasterMutedChanged,
                      onMusicMutedChanged: onMusicMutedChanged,
                      onSfxMutedChanged: onSfxMutedChanged,
                    )
                  : selectedCategory == SettingsCategory.livingAi
                  ? _LivingAiSettingsPanel(
                      controller: livingSettingsController,
                      onTest: onTestLivingAi,
                    )
                  : selectedCategory == SettingsCategory.language
                  ? const _LanguageSettingsPanel()
                  : selectedCategory == SettingsCategory.playtestData
                  ? _PlaytestDataSettingsPanel(onExport: onExportPlaytestData)
                  : selectedCategory == SettingsCategory.openSourceLicenses
                  ? const OpenSourceLicensesScreen()
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        HifiSectionTitle(
                          _settingsCategoryLabel(l10n, selectedCategory),
                          subtitle: l10n.settingsDeviceOptionsDescription,
                        ),
                        const SizedBox(height: 26),
                        _SettingLine(
                          icon: Icons.monitor,
                          label: localizedUiCopy(context, 'Resolution'),
                          value: localizedUiCopy(context, 'Fixed 16:9 stage'),
                        ),
                        _SettingLine(
                          icon: Icons.fullscreen,
                          label: localizedUiCopy(context, 'Fullscreen'),
                          value: localizedUiCopy(
                            context,
                            'Future desktop wrapper',
                          ),
                          locked: true,
                        ),
                        _SettingLine(
                          icon: Icons.volume_up,
                          label: localizedUiCopy(context, 'Audio Mixer'),
                          value: localizedUiCopy(
                            context,
                            'Open the Audio category',
                          ),
                        ),
                        SwitchListTile(
                          value: reducedEffects,
                          onChanged: onReducedEffectsChanged,
                          activeThumbColor: hifiGold,
                          title: Text(
                            l10n.setupReducedEffects,
                            style: const TextStyle(
                              color: hifiInk,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          subtitle: Text(
                            localizedUiCopy(
                              context,
                              'Reduces board travel and transformation animation.',
                            ),
                            style: const TextStyle(color: hifiMuted),
                          ),
                        ),
                        _SettingLine(
                          icon: Icons.language,
                          label: l10n.languageSettingTitle,
                          value: _languagePreferenceLabel(
                            l10n,
                            AppLocaleScope.of(context).preference,
                          ),
                        ),
                        const Spacer(),
                        Row(
                          children: [
                            Expanded(
                              child: HifiPrimaryButton(
                                label: l10n.commonApply,
                                icon: Icons.check,
                                onPressed: null,
                                variant: HifiButtonVariant.dark,
                              ),
                            ),
                            SizedBox(width: 16),
                            Expanded(
                              child: HifiPrimaryButton(
                                label: l10n.commonReset,
                                icon: Icons.lock,
                                onPressed: null,
                                variant: HifiButtonVariant.dark,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PlaytestDataSettingsPanel extends StatefulWidget {
  const _PlaytestDataSettingsPanel({required this.onExport});

  final Future<PlaytestDataExportResult> Function() onExport;

  @override
  State<_PlaytestDataSettingsPanel> createState() =>
      _PlaytestDataSettingsPanelState();
}

class _PlaytestDataSettingsPanelState
    extends State<_PlaytestDataSettingsPanel> {
  bool _exporting = false;
  PlaytestDataExportResult? _result;
  String? _error;

  Future<void> _export() async {
    setState(() {
      _exporting = true;
      _result = null;
      _error = null;
    });
    try {
      final result = await widget.onExport();
      if (!mounted) return;
      setState(() => _result = result);
    } on PlaytestExportException catch (error) {
      if (!mounted) return;
      setState(() => _error = error.message);
    } on Object {
      if (!mounted) return;
      setState(() => _error = appLocalizationsOf(context).playtestDataFailed);
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    final result = _result;
    return SingleChildScrollView(
      padding: const EdgeInsets.only(right: 8, bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          HifiSectionTitle(
            l10n.playtestDataTitle,
            subtitle: l10n.playtestDataDescription,
          ),
          const SizedBox(height: 18),
          HifiPanel(
            color: const Color(0x66151c23),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _PlaytestDataInfoRow(
                  icon: Icons.inventory_2_outlined,
                  title: l10n.playtestDataIncludedTitle,
                  body: l10n.playtestDataIncludedBody,
                ),
                const SizedBox(height: 16),
                _PlaytestDataInfoRow(
                  icon: Icons.privacy_tip_outlined,
                  title: l10n.playtestDataPrivacyTitle,
                  body: l10n.playtestDataPrivacyBody,
                ),
                const SizedBox(height: 16),
                _PlaytestDataInfoRow(
                  icon: Icons.folder_zip_outlined,
                  title: l10n.playtestDataDestinationTitle,
                  body: l10n.playtestDataDestinationBody,
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            key: const ValueKey('playtest-data-export'),
            onPressed: _exporting ? null : _export,
            icon: _exporting
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download),
            label: Text(
              _exporting
                  ? l10n.playtestDataExporting
                  : l10n.playtestDataExportButton,
            ),
          ),
          if (result != null) ...[
            const SizedBox(height: 18),
            Semantics(
              liveRegion: true,
              child: Container(
                key: const ValueKey('playtest-data-export-success'),
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0x55325F43),
                  border: Border.all(color: const Color(0xFF4D9A6B)),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      l10n.playtestDataExported(
                        result.runCount,
                        result.metricsCount,
                        result.diagnosticFileCount,
                      ),
                      style: const TextStyle(
                        color: hifiInk,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      result.filePath,
                      style: const TextStyle(color: hifiMuted, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          ],
          if (_error != null) ...[
            const SizedBox(height: 18),
            Semantics(
              liveRegion: true,
              child: Container(
                key: const ValueKey('playtest-data-export-error'),
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0x553F1D1D),
                  border: Border.all(color: const Color(0xFFC85F52)),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _error!,
                  style: const TextStyle(color: hifiInk, height: 1.4),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _PlaytestDataInfoRow extends StatelessWidget {
  const _PlaytestDataInfoRow({
    required this.icon,
    required this.title,
    required this.body,
  });

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Icon(icon, color: hifiGold),
      const SizedBox(width: 12),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: hifiInk,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 3),
            Text(body, style: const TextStyle(color: hifiMuted, height: 1.4)),
          ],
        ),
      ),
    ],
  );
}

String _languagePreferenceLabel(
  AppLocalizations l10n,
  AppLanguagePreference preference,
) => switch (preference) {
  AppLanguagePreference.system => l10n.languageSystem,
  AppLanguagePreference.english => l10n.languageEnglish,
  AppLanguagePreference.simplifiedChinese => l10n.languageSimplifiedChinese,
};

Future<void> _setLanguagePreference(
  BuildContext context,
  AppLocaleController controller,
  AppLanguagePreference preference,
) async {
  if (preference == AppLanguagePreference.simplifiedChinese &&
      controller.preference != AppLanguagePreference.simplifiedChinese) {
    final warningL10n = lookupAppLocalizations(
      AppLocaleController.simplifiedChineseLocale,
    );
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => Dialog(
        key: const ValueKey('chinese-readiness-warning'),
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 780),
          child: HifiPanel(
            padding: const EdgeInsets.fromLTRB(34, 30, 34, 28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: const Color(0x662a1c0d),
                        shape: BoxShape.circle,
                        border: Border.all(color: hifiGoldDark, width: 1.5),
                      ),
                      child: const Icon(
                        Icons.warning_amber_rounded,
                        color: hifiGold,
                        size: 29,
                      ),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            warningL10n.languageChineseReadinessWarningTitle,
                            style: const TextStyle(
                              color: hifiInk,
                              fontFamily: 'Georgia',
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              height: 1.1,
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            warningL10n.languageChineseReadinessWarningBody,
                            style: const TextStyle(
                              color: hifiMuted,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              height: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Divider(height: 1, color: hifiGoldDark),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(
                      width: 170,
                      child: HifiPrimaryButton(
                        key: const ValueKey('chinese-readiness-cancel'),
                        label: warningL10n.commonCancel,
                        variant: HifiButtonVariant.dark,
                        onPressed: () => Navigator.of(dialogContext).pop(false),
                      ),
                    ),
                    const SizedBox(width: 14),
                    SizedBox(
                      width: 250,
                      child: HifiPrimaryButton(
                        key: const ValueKey('chinese-readiness-confirm'),
                        label:
                            warningL10n.languageChineseReadinessWarningConfirm,
                        icon: Icons.translate_rounded,
                        variant: HifiButtonVariant.emerald,
                        onPressed: () => Navigator.of(dialogContext).pop(true),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (confirmed != true || !context.mounted) {
      return;
    }
  }
  await controller.setPreference(preference);
}

class _LanguageSettingsPanel extends StatelessWidget {
  const _LanguageSettingsPanel();

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    final controller = AppLocaleScope.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        HifiSectionTitle(
          l10n.languageSettingTitle,
          subtitle: l10n.languageSettingDescription,
        ),
        const SizedBox(height: 22),
        RadioGroup<AppLanguagePreference>(
          groupValue: controller.preference,
          onChanged: (value) {
            if (value != null) {
              unawaited(_setLanguagePreference(context, controller, value));
            }
          },
          child: Column(
            children: [
              for (final preference in AppLanguagePreference.values)
                RadioListTile<AppLanguagePreference>(
                  key: ValueKey('language-${preference.storedValue}'),
                  value: preference,
                  activeColor: hifiGold,
                  title: Text(
                    _languagePreferenceLabel(l10n, preference),
                    style: const TextStyle(
                      color: hifiInk,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        HifiPanel(
          color: const Color(0x66151c23),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.auto_stories, color: hifiGold),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  l10n.languageLivingPinnedNotice,
                  style: const TextStyle(color: hifiMuted, height: 1.4),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _LivingAiSettingsPanel extends StatefulWidget {
  const _LivingAiSettingsPanel({
    required this.controller,
    required this.onTest,
  });

  final LivingCampaignSettingsController controller;
  final Future<void> Function() onTest;

  @override
  State<_LivingAiSettingsPanel> createState() => _LivingAiSettingsPanelState();
}

class _LivingAiSettingsPanelState extends State<_LivingAiSettingsPanel> {
  late final TextEditingController _apiKey;
  late final TextEditingController _baseUrl;
  late final TextEditingController _textModel;
  late final TextEditingController _imageModel;
  late final TextEditingController _logStages;
  late LivingLogLevel _textLogLevel;
  late LivingLogLevel _imageLogLevel;
  bool _showKey = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final saved = widget.controller.saved;
    _apiKey = TextEditingController(text: saved.apiKey);
    _baseUrl = TextEditingController(text: saved.baseUrl);
    _textModel = TextEditingController(text: saved.textModel);
    _imageModel = TextEditingController(text: saved.imageModel);
    _logStages = TextEditingController(
      text: (saved.logStages.toList()..sort()).join(','),
    );
    _textLogLevel = saved.textLogLevel;
    _imageLogLevel = saved.imageLogLevel;
    widget.controller.addListener(_handleControllerChange);
    _syncDeveloperOverrides(widget.controller.effective);
  }

  @override
  void didUpdateWidget(covariant _LivingAiSettingsPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_handleControllerChange);
      widget.controller.addListener(_handleControllerChange);
      _loadSaved();
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_handleControllerChange);
    _apiKey.dispose();
    _baseUrl.dispose();
    _textModel.dispose();
    _imageModel.dispose();
    _logStages.dispose();
    super.dispose();
  }

  void _handleControllerChange() {
    _syncDeveloperOverrides(widget.controller.effective);
  }

  void _loadSaved() {
    final saved = widget.controller.saved;
    final effective = widget.controller.effective;
    _apiKey.text = effective.isDeveloperOverride('apiKey')
        ? effective.values.apiKey
        : saved.apiKey;
    _baseUrl.text = effective.isDeveloperOverride('baseUrl')
        ? effective.values.baseUrl
        : saved.baseUrl;
    _textModel.text = effective.isDeveloperOverride('textModel')
        ? effective.values.textModel
        : saved.textModel;
    _imageModel.text = effective.isDeveloperOverride('imageModel')
        ? effective.values.imageModel
        : saved.imageModel;
    _logStages.text = effective.isDeveloperOverride('logStages')
        ? (effective.values.logStages.toList()..sort()).join(',')
        : (saved.logStages.toList()..sort()).join(',');
    _textLogLevel = effective.isDeveloperOverride('textLogLevel')
        ? effective.values.textLogLevel
        : saved.textLogLevel;
    _imageLogLevel = effective.isDeveloperOverride('imageLogLevel')
        ? effective.values.imageLogLevel
        : saved.imageLogLevel;
  }

  void _syncDeveloperOverrides(EffectiveLivingCampaignSettings effective) {
    void sync(String field, TextEditingController controller, String value) {
      if (effective.isDeveloperOverride(field) && controller.text != value) {
        controller.value = TextEditingValue(text: value);
      }
    }

    sync('apiKey', _apiKey, effective.values.apiKey);
    sync('baseUrl', _baseUrl, effective.values.baseUrl);
    sync('textModel', _textModel, effective.values.textModel);
    sync('imageModel', _imageModel, effective.values.imageModel);
    sync(
      'logStages',
      _logStages,
      (effective.values.logStages.toList()..sort()).join(','),
    );
    if (effective.isDeveloperOverride('textLogLevel')) {
      _textLogLevel = effective.values.textLogLevel;
    }
    if (effective.isDeveloperOverride('imageLogLevel')) {
      _imageLogLevel = effective.values.imageLogLevel;
    }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final effective = widget.controller.effective;
    final saved = widget.controller.saved;
    await widget.controller.save(
      LivingCampaignSettings(
        apiKey: effective.isDeveloperOverride('apiKey')
            ? saved.apiKey
            : _apiKey.text,
        baseUrl: effective.isDeveloperOverride('baseUrl')
            ? saved.baseUrl
            : _baseUrl.text,
        textModel: effective.isDeveloperOverride('textModel')
            ? saved.textModel
            : _textModel.text,
        imageModel: effective.isDeveloperOverride('imageModel')
            ? saved.imageModel
            : _imageModel.text,
        textLogLevel: effective.isDeveloperOverride('textLogLevel')
            ? saved.textLogLevel
            : _textLogLevel,
        imageLogLevel: effective.isDeveloperOverride('imageLogLevel')
            ? saved.imageLogLevel
            : _imageLogLevel,
        logStages: effective.isDeveloperOverride('logStages')
            ? saved.logStages
            : _logStages.text
                  .split(',')
                  .map((value) => value.trim())
                  .where((value) => value.isNotEmpty)
                  .toSet(),
      ),
    );
    if (mounted) setState(() => _saving = false);
  }

  Future<void> _deleteKey() async {
    await widget.controller.deleteApiKey();
    _loadSaved();
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (widget.controller.isPreviewBuild) {
      return _IncludedLivingAiAccessPanel(
        controller: widget.controller,
        onTest: widget.onTest,
      );
    }
    final effective = widget.controller.effective;
    final status = widget.controller.capabilityStatus;
    return SingleChildScrollView(
      padding: const EdgeInsets.only(right: 8, bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const HifiSectionTitle(
            'Living AI',
            subtitle:
                'Direct Doubao Ark access for generated prologues, chapters, and portraits.',
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xC9342517),
              border: Border.all(color: const Color(0xFF9B733A)),
            ),
            child: Row(
              children: [
                const Icon(Icons.warning_amber, color: hifiGold),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    effective.isDeveloperOverride('apiKey')
                        ? 'This debug launch reads the API key from the repository '
                              '.env. It is not copied into saved player settings.'
                        : 'The player API key is stored unencrypted with ordinary '
                              'local game settings. Do not use a key you cannot revoke.',
                    style: const TextStyle(
                      color: hifiInk,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _LivingSettingField(
            fieldKey: const ValueKey('living-ai-api-key'),
            label: 'ARK API Key',
            controller: _apiKey,
            obscureText: !_showKey,
            source: effective.sources['apiKey']!,
            readOnly: effective.isDeveloperOverride('apiKey'),
            suffix: IconButton(
              onPressed: () => setState(() => _showKey = !_showKey),
              icon: Icon(_showKey ? Icons.visibility_off : Icons.visibility),
            ),
          ),
          const SizedBox(height: 10),
          _LivingSettingField(
            fieldKey: const ValueKey('living-ai-base-url'),
            label: 'Ark Base URL',
            controller: _baseUrl,
            source: effective.sources['baseUrl']!,
            readOnly: effective.isDeveloperOverride('baseUrl'),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _LivingSettingField(
                  fieldKey: const ValueKey('living-ai-text-model'),
                  label: 'Text Model',
                  controller: _textModel,
                  source: effective.sources['textModel']!,
                  readOnly: effective.isDeveloperOverride('textModel'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _LivingSettingField(
                  fieldKey: const ValueKey('living-ai-image-model'),
                  label: 'Portrait Model',
                  controller: _imageModel,
                  source: effective.sources['imageModel']!,
                  readOnly: effective.isDeveloperOverride('imageModel'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const Text(
            'GENERATION DIAGNOSTICS',
            style: TextStyle(
              color: hifiGold,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.3,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _LivingLogLevelField(
                  fieldKey: const ValueKey('living-ai-text-log-level'),
                  label: 'LLM logs',
                  value: effective.isDeveloperOverride('textLogLevel')
                      ? effective.values.textLogLevel
                      : _textLogLevel,
                  source: effective.sources['textLogLevel']!,
                  readOnly: effective.isDeveloperOverride('textLogLevel'),
                  onChanged: (value) => setState(() => _textLogLevel = value),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _LivingLogLevelField(
                  fieldKey: const ValueKey('living-ai-image-log-level'),
                  label: 'Image logs',
                  value: effective.isDeveloperOverride('imageLogLevel')
                      ? effective.values.imageLogLevel
                      : _imageLogLevel,
                  source: effective.sources['imageLogLevel']!,
                  readOnly: effective.isDeveloperOverride('imageLogLevel'),
                  onChanged: (value) => setState(() => _imageLogLevel = value),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _LivingSettingField(
            fieldKey: const ValueKey('living-ai-log-stages'),
            label: 'Logged stages (comma-separated)',
            controller: _logStages,
            source: effective.sources['logStages']!,
            readOnly: effective.isDeveloperOverride('logStages'),
          ),
          const SizedBox(height: 6),
          const Text(
            'Summary records timing, request ID, usage, and validation. Full also prints redacted prompts and responses. Image bytes are never printed.',
            style: TextStyle(color: hifiMuted, fontSize: 11, height: 1.35),
          ),
          const SizedBox(height: 12),
          Text(
            effective.sources.values.contains(LivingSettingSource.developerEnv)
                ? 'Debug source active: non-empty repository .env values override '
                      'saved player fields. Release/profile builds never load .env.'
                : 'Effective source: built-in defaults plus saved player settings.',
            style: const TextStyle(color: hifiMuted, fontSize: 12),
          ),
          const SizedBox(height: 24),
          if (widget.controller.capabilityMessage != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Icon(
                    status == LivingCapabilityStatus.available
                        ? Icons.check_circle
                        : Icons.error_outline,
                    color: status == LivingCapabilityStatus.available
                        ? const Color(0xFF4D9A6B)
                        : const Color(0xFFC85F52),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      widget.controller.capabilityMessage!,
                      style: const TextStyle(color: hifiInk),
                    ),
                  ),
                ],
              ),
            ),
          Wrap(
            spacing: 12,
            runSpacing: 10,
            children: [
              FilledButton.icon(
                key: const ValueKey('living-ai-save'),
                onPressed: _saving ? null : _save,
                icon: const Icon(Icons.save),
                label: Text(_saving ? 'Saving…' : 'Save Local Settings'),
              ),
              OutlinedButton.icon(
                key: const ValueKey('living-ai-test'),
                onPressed: status == LivingCapabilityStatus.testing
                    ? null
                    : () => widget.onTest(),
                icon: status == LivingCapabilityStatus.testing
                    ? const SizedBox.square(
                        dimension: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.network_check),
                label: const Text('Test Text Model'),
              ),
              TextButton.icon(
                key: const ValueKey('living-ai-delete-key'),
                onPressed: _deleteKey,
                icon: const Icon(Icons.delete_outline),
                label: const Text('Delete Saved Key'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _IncludedLivingAiAccessPanel extends StatelessWidget {
  const _IncludedLivingAiAccessPanel({
    required this.controller,
    required this.onTest,
  });

  final LivingCampaignSettingsController controller;
  final Future<void> Function() onTest;

  @override
  Widget build(BuildContext context) {
    final status = controller.capabilityStatus;
    final configured = controller.effective.values.hasApiKey;
    final statusColor = configured
        ? const Color(0xFF4D9A6B)
        : const Color(0xFFC85F52);
    return SingleChildScrollView(
      padding: const EdgeInsets.only(right: 8, bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const HifiSectionTitle(
            'Living AI',
            subtitle: 'AI access is included with this desktop preview.',
          ),
          const SizedBox(height: 18),
          HifiPanel(
            color: const Color(0x66151c23),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  configured ? Icons.cloud_done : Icons.cloud_off,
                  color: statusColor,
                  size: 30,
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Included AI access',
                        key: ValueKey('living-ai-included-access'),
                        style: TextStyle(
                          color: hifiInk,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        configured
                            ? '${controller.previewLabel} access is configured.'
                            : '${controller.previewLabel} access is unavailable.',
                        style: const TextStyle(color: hifiMuted, height: 1.4),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'No provider setup is required. Access is managed by Arcane Forge for this preview.',
                        style: TextStyle(color: hifiMuted, height: 1.4),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          if (controller.capabilityMessage != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Icon(
                    status == LivingCapabilityStatus.available
                        ? Icons.check_circle
                        : Icons.error_outline,
                    color: status == LivingCapabilityStatus.available
                        ? const Color(0xFF4D9A6B)
                        : const Color(0xFFC85F52),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      controller.capabilityMessage!,
                      style: const TextStyle(color: hifiInk),
                    ),
                  ),
                ],
              ),
            ),
          OutlinedButton.icon(
            key: const ValueKey('living-ai-test'),
            onPressed: !configured || status == LivingCapabilityStatus.testing
                ? null
                : () => onTest(),
            icon: status == LivingCapabilityStatus.testing
                ? const SizedBox.square(
                    dimension: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.network_check),
            label: const Text('Test Included AI Access'),
          ),
        ],
      ),
    );
  }
}

class _LivingLogLevelField extends StatelessWidget {
  const _LivingLogLevelField({
    required this.fieldKey,
    required this.label,
    required this.value,
    required this.source,
    required this.readOnly,
    required this.onChanged,
  });

  final Key fieldKey;
  final String label;
  final LivingLogLevel value;
  final LivingSettingSource source;
  final bool readOnly;
  final ValueChanged<LivingLogLevel> onChanged;

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<LivingLogLevel>(
      key: fieldKey,
      initialValue: value,
      dropdownColor: const Color(0xFF151A1C),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: hifiMuted),
        helperText: 'Effective source: ${source.name}',
        helperStyle: const TextStyle(color: hifiMuted, fontSize: 10),
        enabledBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Color(0xFF6A5738)),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: hifiGold),
        ),
      ),
      style: const TextStyle(color: hifiInk),
      items: LivingLogLevel.values
          .map(
            (level) => DropdownMenuItem<LivingLogLevel>(
              value: level,
              child: Text(level.name.toUpperCase()),
            ),
          )
          .toList(growable: false),
      onChanged: readOnly
          ? null
          : (value) {
              if (value != null) onChanged(value);
            },
    );
  }
}

class _LivingSettingField extends StatelessWidget {
  const _LivingSettingField({
    required this.fieldKey,
    required this.label,
    required this.controller,
    required this.source,
    this.obscureText = false,
    this.readOnly = false,
    this.suffix,
  });

  final Key fieldKey;
  final String label;
  final TextEditingController controller;
  final LivingSettingSource source;
  final bool obscureText;
  final bool readOnly;
  final Widget? suffix;

  @override
  Widget build(BuildContext context) {
    return TextField(
      key: fieldKey,
      controller: controller,
      obscureText: obscureText,
      readOnly: readOnly,
      autocorrect: false,
      enableSuggestions: false,
      style: const TextStyle(color: hifiInk),
      decoration: InputDecoration(
        labelText: label,
        helperText:
            'Effective source: ${switch (source) {
              LivingSettingSource.builtIn => 'built-in',
              LivingSettingSource.player => 'player',
              LivingSettingSource.developerEnv => 'developer .env',
              LivingSettingSource.previewBundle => 'included preview access',
            }}',
        suffixIcon: suffix,
        border: const OutlineInputBorder(),
      ),
    );
  }
}

class _AudioMixerPanel extends StatelessWidget {
  const _AudioMixerPanel({
    required this.settings,
    required this.onMasterVolumeChanged,
    required this.onMusicVolumeChanged,
    required this.onSfxVolumeChanged,
    required this.onMasterMutedChanged,
    required this.onMusicMutedChanged,
    required this.onSfxMutedChanged,
  });

  final GameAudioSettings settings;
  final ValueChanged<double> onMasterVolumeChanged;
  final ValueChanged<double> onMusicVolumeChanged;
  final ValueChanged<double> onSfxVolumeChanged;
  final ValueChanged<bool> onMasterMutedChanged;
  final ValueChanged<bool> onMusicMutedChanged;
  final ValueChanged<bool> onSfxMutedChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const HifiSectionTitle(
          'Audio',
          subtitle:
              'Music and effects update immediately and are saved automatically.',
        ),
        const SizedBox(height: 22),
        _AudioChannelControl(
          sliderKey: const ValueKey('audio-master-volume'),
          muteKey: const ValueKey('audio-master-mute'),
          icon: Icons.surround_sound,
          label: 'Master',
          detail: 'Overall game output',
          value: settings.masterVolume,
          muted: settings.masterMuted,
          onVolumeChanged: onMasterVolumeChanged,
          onMutedChanged: onMasterMutedChanged,
        ),
        const SizedBox(height: 16),
        _AudioChannelControl(
          sliderKey: const ValueKey('audio-music-volume'),
          muteKey: const ValueKey('audio-music-mute'),
          icon: Icons.library_music,
          label: 'Music',
          detail: 'Themes, playlists, and battle score',
          value: settings.musicVolume,
          muted: settings.musicMuted,
          onVolumeChanged: onMusicVolumeChanged,
          onMutedChanged: onMusicMutedChanged,
        ),
        const SizedBox(height: 16),
        _AudioChannelControl(
          sliderKey: const ValueKey('audio-sfx-volume'),
          muteKey: const ValueKey('audio-sfx-mute'),
          icon: Icons.campaign,
          label: 'Sound Effects',
          detail: 'Moves, contracts, battlefields, and UI',
          value: settings.sfxVolume,
          muted: settings.sfxMuted,
          onVolumeChanged: onSfxVolumeChanged,
          onMutedChanged: onSfxMutedChanged,
        ),
        const Spacer(),
        const Row(
          children: [
            Icon(Icons.cloud_done, color: Color(0xFF79D5A4)),
            SizedBox(width: 10),
            Text(
              'Saved on this device',
              style: TextStyle(color: hifiMuted, fontWeight: FontWeight.w800),
            ),
          ],
        ),
      ],
    );
  }
}

class _AudioChannelControl extends StatelessWidget {
  const _AudioChannelControl({
    required this.sliderKey,
    required this.muteKey,
    required this.icon,
    required this.label,
    required this.detail,
    required this.value,
    required this.muted,
    required this.onVolumeChanged,
    required this.onMutedChanged,
  });

  final Key sliderKey;
  final Key muteKey;
  final IconData icon;
  final String label;
  final String detail;
  final double value;
  final bool muted;
  final ValueChanged<double> onVolumeChanged;
  final ValueChanged<bool> onMutedChanged;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0x99131B1D),
        border: Border.all(color: const Color(0x665F776F)),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        child: Row(
          children: [
            Icon(icon, color: muted ? hifiMuted : hifiGold, size: 30),
            const SizedBox(width: 14),
            SizedBox(
              width: 172,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: hifiInk,
                      fontWeight: FontWeight.w900,
                      fontSize: 17,
                    ),
                  ),
                  Text(detail, style: const TextStyle(color: hifiMuted)),
                ],
              ),
            ),
            Expanded(
              child: Slider(
                key: sliderKey,
                value: value.clamp(0, 1),
                onChanged: onVolumeChanged,
                activeColor: hifiGold,
                inactiveColor: const Color(0xFF34413E),
              ),
            ),
            SizedBox(
              width: 54,
              child: Text(
                '${(value * 100).round()}%',
                textAlign: TextAlign.end,
                style: const TextStyle(
                  color: hifiInk,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Switch(
              key: muteKey,
              value: !muted,
              onChanged: (enabled) => onMutedChanged(!enabled),
              activeThumbColor: const Color(0xFF79D5A4),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProductScaffold extends StatelessWidget {
  const _ProductScaffold({
    required this.screenCode,
    required this.title,
    required this.activeNav,
    required this.backdrop,
    required this.child,
    required this.onLobby,
    this.onCollection,
    this.onCourt,
    this.onLoadout,
    this.onRecords,
    this.onRules,
    this.onSettings,
  });

  final String screenCode;
  final String title;
  final HifiNavigationDestination activeNav;
  final String backdrop;
  final Widget child;
  final VoidCallback onLobby;
  final VoidCallback? onCollection;
  final VoidCallback? onCourt;
  final VoidCallback? onLoadout;
  final VoidCallback? onRecords;
  final VoidCallback? onRules;
  final VoidCallback? onSettings;

  @override
  Widget build(BuildContext context) {
    final l10n = appLocalizationsOf(context);
    return HifiScaffold(
      backdropAsset: backdrop,
      backdropOpacity: .22,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(30, 18, 30, 20),
        child: Column(
          children: [
            HifiTopBar(
              screenCode: screenCode,
              title: title,
              trailing: [
                HifiIconSquare(
                  key: const ValueKey('product-lobby'),
                  icon: Icons.home,
                  label: l10n.gameLobby,
                  onPressed: onLobby,
                ),
                const SizedBox(width: 10),
                HifiIconSquare(
                  key: const ValueKey('product-settings'),
                  icon: Icons.settings,
                  label: l10n.settingsTitle,
                  onPressed: onSettings,
                ),
              ],
            ),
            const SizedBox(height: 14),
            Expanded(child: child),
            const SizedBox(height: 14),
            HifiBottomNav(
              active: activeNav,
              items: [
                HifiNavItem(
                  HifiNavigationDestination.lobby,
                  l10n.gameLobby,
                  Icons.castle,
                  enabled: true,
                  onPressed: onLobby,
                ),
                HifiNavItem(
                  HifiNavigationDestination.country,
                  l10n.navCountries,
                  Icons.flag,
                  enabled: onCourt != null,
                  onPressed: onCourt,
                ),
                HifiNavItem(
                  HifiNavigationDestination.roster,
                  l10n.navRoster,
                  Icons.groups,
                  enabled: onCollection != null,
                  onPressed: onCollection,
                ),
                HifiNavItem(
                  HifiNavigationDestination.loadout,
                  l10n.navLoadout,
                  Icons.security,
                  enabled: onLoadout != null,
                  onPressed: onLoadout,
                ),
                HifiNavItem(
                  HifiNavigationDestination.records,
                  l10n.navRecords,
                  Icons.history_edu,
                  enabled: onRecords != null,
                  onPressed: onRecords,
                ),
                HifiNavItem(
                  HifiNavigationDestination.rules,
                  l10n.navRules,
                  Icons.menu_book,
                  enabled: onRules != null,
                  onPressed: onRules,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _CountryHeroCard extends StatelessWidget {
  const _CountryHeroCard({required this.country});

  final CountryConfig country;

  @override
  Widget build(BuildContext context) {
    return HifiPanel(
      padding: const EdgeInsets.fromLTRB(22, 22, 22, 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              fit: StackFit.expand,
              children: [
                CountryRepresentativeArt(country: country, bust: true),
                DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        country.color.withValues(alpha: .12),
                        const Color(0xD80B100F),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.bottomLeft,
                  child: Container(
                    width: 82,
                    height: 82,
                    margin: const EdgeInsets.only(left: 6, bottom: 10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xE80B100F),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: country.secondaryColor,
                        width: 2,
                      ),
                    ),
                    child: FittedBox(child: CountryCrest(country: country)),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Text(
            country.name,
            style: const TextStyle(
              color: hifiInk,
              fontFamily: 'Georgia',
              fontSize: 34,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            country.fantasy,
            style: const TextStyle(
              color: hifiMuted,
              fontSize: 16,
              height: 1.35,
            ),
          ),
          const SizedBox(height: 20),
          HifiStatLine(
            icon: Icons.monetization_on,
            label: 'Starting Gold',
            value: signed(country.startingGoldModifier),
          ),
          HifiStatLine(
            icon: Icons.local_shipping,
            label: 'Merchant Payout',
            value: signed(country.merchantPayoutModifier),
          ),
          HifiStatLine(
            icon: Icons.gavel,
            label: 'Offer Modifier',
            value: signed(country.offenseModifier),
          ),
        ],
      ),
    );
  }
}

class _CountryRulePanel extends StatelessWidget {
  const _CountryRulePanel({required this.country});

  final CountryConfig country;

  @override
  Widget build(BuildContext context) {
    final lines = countryRuleDetails(country);
    return HifiPanel(
      color: const Color(0xBB0b1116),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            localizedUiCopy(context, 'Signature Trait'),
            style: const TextStyle(
              color: hifiGold,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 12),
          for (final line in lines)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Text(
                line,
                style: const TextStyle(color: hifiMuted, height: 1.3),
              ),
            ),
        ],
      ),
    );
  }
}

class _RolePreviewCard extends StatelessWidget {
  const _RolePreviewCard({
    required this.country,
    required this.role,
    required this.onPressed,
  });

  final CountryConfig country;
  final PieceType role;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onPressed,
        child: Ink(
          child: HifiAssetSurface(
            asset: '$runtimeAssetRoot/ui/common/role_preview_card_9slice.webp',
            centerSlice: const Rect.fromLTRB(96, 128, 672, 896),
            imageScale: 3,
            padding: const EdgeInsets.fromLTRB(32, 34, 32, 36),
            child: Column(
              children: [
                Icon(_roleIcon(role), color: hifiGoldDark, size: 44),
                const SizedBox(height: 8),
                Text(
                  pieceTypeLabel(role),
                  style: const TextStyle(
                    color: Color(0xFF2b1c0f),
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Expanded(
                  child: Text(
                    _roleFlavor(role),
                    textAlign: TextAlign.center,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFF6b5232),
                      fontSize: 12,
                      height: 1.25,
                    ),
                  ),
                ),
                Text(
                  country.shortName,
                  style: TextStyle(
                    color: country.secondaryColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CountryMiniButton extends StatelessWidget {
  const _CountryMiniButton({
    required this.country,
    required this.selected,
    required this.onPressed,
  });

  final CountryConfig country;
  final bool selected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(8),
        child: Ink(
          height: 78,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: selected
                ? country.color.withValues(alpha: .48)
                : const Color(0xCC111820),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: selected ? country.secondaryColor : hifiGoldDark,
              width: selected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              CountryCrest(country: country, size: 42),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  country.shortName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: hifiInk,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TraitChip extends StatelessWidget {
  const _TraitChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: const Color(0xDD111820),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: hifiGoldDark),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: hifiGold, size: 18),
            const SizedBox(width: 7),
            Text(
              label,
              style: const TextStyle(
                color: hifiInk,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterPill extends StatelessWidget {
  const _FilterPill({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return HifiPanel(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      color: const Color(0xE60d151b),
      child: Row(
        children: [
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: hifiGold,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const Spacer(),
          Flexible(
            child: Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
              style: const TextStyle(color: hifiInk),
            ),
          ),
          const SizedBox(width: 8),
          const Icon(Icons.keyboard_arrow_down, color: hifiGold),
        ],
      ),
    );
  }
}

class _MatrixHeader extends StatelessWidget {
  const _MatrixHeader({
    required this.label,
    required this.selected,
    required this.onPressed,
  });

  final String label;
  final bool selected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(6),
          child: Ink(
            height: 44,
            decoration: BoxDecoration(
              color: selected
                  ? const Color(0xFF8a6727)
                  : const Color(0xFF1a232b),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: selected ? hifiGold : hifiGoldDark),
            ),
            child: Center(
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: hifiInk,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CountryMatrixLabel extends StatelessWidget {
  const _CountryMatrixLabel({
    required this.country,
    required this.selected,
    required this.onPressed,
  });

  final CountryConfig country;
  final bool selected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return _CountryMiniButton(
      country: country,
      selected: selected,
      onPressed: onPressed,
    );
  }
}

class _MatrixCell extends StatelessWidget {
  const _MatrixCell({
    required this.country,
    required this.role,
    required this.selected,
    required this.locked,
    required this.onPressed,
  });

  final CountryConfig country;
  final PieceType role;
  final bool selected;
  final bool locked;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: locked ? .52 : 1,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: locked ? null : onPressed,
          borderRadius: BorderRadius.circular(8),
          child: Ink(
            decoration: BoxDecoration(
              color: selected
                  ? country.color.withValues(alpha: .5)
                  : const Color(0xDD101820),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: selected ? country.secondaryColor : hifiGoldDark,
                width: selected ? 2 : 1,
              ),
            ),
            child: Stack(
              children: [
                Center(child: Icon(_roleIcon(role), color: hifiGold, size: 30)),
                Positioned(
                  left: 6,
                  top: 6,
                  child: Icon(
                    Icons.check_circle,
                    color: locked ? hifiMuted : Colors.lightGreenAccent,
                    size: 16,
                  ),
                ),
                if (locked)
                  const Center(child: Icon(Icons.lock, color: hifiGold)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _RoleTokenPreview extends StatelessWidget {
  const _RoleTokenPreview({required this.country, required this.role});

  final CountryConfig country;
  final PieceType role;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: country.color.withValues(alpha: .22),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: country.secondaryColor),
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(_roleIcon(role), color: hifiGold, size: 108),
            const SizedBox(height: 16),
            Text(
              pieceTypeLabel(role),
              style: const TextStyle(
                color: hifiInk,
                fontFamily: 'Georgia',
                fontSize: 36,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SlotRow extends StatelessWidget {
  const _SlotRow({required this.index, required this.active});

  final int index;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: active ? const Color(0xDD1b3b34) : const Color(0xCC111820),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: active ? hifiGold : hifiGoldDark),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(
              active ? Icons.check_circle : Icons.radio_button_unchecked,
              color: hifiGold,
            ),
            const SizedBox(width: 10),
            Text(
              'Slot $index',
              style: const TextStyle(
                color: hifiInk,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CategoryButton extends StatelessWidget {
  const _CategoryButton({
    required this.label,
    required this.selected,
    required this.onPressed,
  });

  final String label;
  final bool selected;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return HifiPrimaryButton(
      label: label,
      icon: selected
          ? Icons.radio_button_checked
          : Icons.radio_button_unchecked,
      onPressed: onPressed,
      variant: selected ? HifiButtonVariant.gold : HifiButtonVariant.dark,
    );
  }
}

class _PreviewTile extends StatelessWidget {
  const _PreviewTile({
    required this.label,
    required this.selected,
    required this.locked,
  });

  final String label;
  final bool selected;
  final bool locked;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: selected ? const Color(0xDD274037) : const Color(0xCC121920),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: selected ? hifiGold : hifiGoldDark),
      ),
      child: Stack(
        children: [
          const Center(
            child: Icon(Icons.auto_awesome, color: hifiGold, size: 42),
          ),
          Positioned(
            left: 10,
            bottom: 10,
            right: 10,
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: hifiInk,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          if (locked)
            const Positioned(
              top: 8,
              right: 8,
              child: Icon(Icons.lock, color: hifiGold, size: 20),
            ),
        ],
      ),
    );
  }
}

class _TimelineRow extends StatelessWidget {
  const _TimelineRow({
    required this.index,
    required this.text,
    required this.muted,
  });

  final int index;
  final String text;
  final bool muted;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            color: muted ? const Color(0xFF23272d) : const Color(0xFF785924),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            child: Text(
              '$index',
              style: const TextStyle(
                color: hifiInk,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              color: muted ? hifiMuted.withValues(alpha: .72) : hifiMuted,
              height: 1.35,
            ),
          ),
        ),
      ],
    );
  }
}

class _PostgameStat extends StatelessWidget {
  const _PostgameStat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: const Color(0xDD111820),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: hifiGoldDark),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: hifiMuted,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  color: hifiGold,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _IllustratedBoardExample extends StatelessWidget {
  const _IllustratedBoardExample();

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: hifiGold, width: 3),
        ),
        child: GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 8,
          ),
          itemCount: 64,
          itemBuilder: (context, index) {
            final row = index ~/ 8;
            final col = index % 8;
            final highlighted =
                (row == 4 && col == 4) ||
                (row == 3 && col == 5) ||
                (row == 5 && col == 3);
            return DecoratedBox(
              decoration: BoxDecoration(
                color: highlighted
                    ? const Color(0xFF24645b)
                    : ((row + col).isEven
                          ? const Color(0xFFd7c097)
                          : const Color(0xFF735036)),
                border: Border.all(color: const Color(0x221a120c)),
              ),
              child: Center(
                child: highlighted
                    ? const Icon(
                        Icons.circle,
                        color: Color(0xFF9ef5e8),
                        size: 14,
                      )
                    : null,
              ),
            );
          },
        ),
      ),
    );
  }
}

class _SettingLine extends StatelessWidget {
  const _SettingLine({
    required this.icon,
    required this.label,
    required this.value,
    this.locked = false,
  });

  final IconData icon;
  final String label;
  final String value;
  final bool locked;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: HifiPanel(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        color: const Color(0xDD111820),
        child: Row(
          children: [
            Icon(icon, color: hifiGold),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  color: hifiInk,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            Text(value, style: const TextStyle(color: hifiMuted)),
            if (locked) ...[
              const SizedBox(width: 10),
              const Icon(Icons.lock, color: hifiGold, size: 18),
            ],
          ],
        ),
      ),
    );
  }
}

IconData _roleIcon(PieceType role) {
  return switch (role) {
    PieceType.king => Icons.workspace_premium,
    PieceType.queen => Icons.diamond,
    PieceType.rook => Icons.castle,
    PieceType.bishop => Icons.auto_fix_high,
    PieceType.knight => Icons.shield,
    PieceType.pawn => Icons.person,
  };
}

IconData _lessonIcon(int index) {
  return switch (index) {
    0 => Icons.grid_on,
    1 => Icons.local_shipping,
    2 => Icons.gavel,
    3 => Icons.visibility_off,
    4 => Icons.place,
    _ => Icons.flag,
  };
}

String _roleFlavor(PieceType role) {
  return switch (role) {
    PieceType.king => 'Protected sovereign and checkmate target.',
    PieceType.queen => 'High-value negotiator with demanding contracts.',
    PieceType.rook => 'Fortress role with strong loyalty pressure.',
    PieceType.bishop => 'Long diagonal influence and reveal-friendly lines.',
    PieceType.knight => 'Cavalry jumper with country-specific contract hooks.',
    PieceType.pawn => 'Low price, promotion threat, and loyal foot soldier.',
  };
}
