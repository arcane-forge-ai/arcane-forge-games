import 'package:flutter/material.dart';

import '../../domain/board_presentation.dart';
import '../../domain/chess_models.dart';
import '../../domain/countries.dart';
import '../../game/game_controller.dart';
import '../effects/production_board_effects.dart';
import 'board_presentation_layers.dart';
import 'board_presentation_coordinator.dart';
import 'piece_token.dart';
import 'special_tile_visual.dart';

class GameBoard extends StatelessWidget {
  const GameBoard({
    required this.controller,
    this.presentationCoordinator,
    super.key,
  });

  final GameController controller;
  final BoardPresentationCoordinator? presentationCoordinator;

  @override
  Widget build(BuildContext context) {
    final selectedMoves = controller.selectedLegalMoves;
    final redeploySquares = controller.phase == GamePhase.redeploy
        ? controller.legalRedeploySquares().toSet()
        : <Square>{};
    final presentationBusy = presentationCoordinator?.isBusy ?? false;
    final checkedKing = !presentationBusy && controller.activeKingInCheck
        ? controller.kingSquare(controller.turn)
        : null;
    final checkingAttackers = checkedKing == null
        ? const <Square>[]
        : controller.checkingAttackers(controller.turn);
    final activeMotion = presentationCoordinator?.activeMotion;
    final activeBetrayal = presentationCoordinator?.activeBetrayal;

    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final boardSize = Size(constraints.maxWidth, constraints.maxHeight);
          return Stack(
            fit: StackFit.expand,
            children: [
              GridView.builder(
                padding: EdgeInsets.zero,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 8,
                ),
                itemCount: 64,
                itemBuilder: (context, index) {
                  final row = index ~/ 8;
                  final col = index % 8;
                  final square = Square(row, col);
                  final piece = controller.board[row][col];
                  final specialTile = controller.specialTileAt(square);
                  final light = (row + col).isEven;
                  final selected = controller.selectedSquare == square;
                  final legalMove = selectedMoves.any(
                    (move) => move.to == square,
                  );
                  final legalCapture = selectedMoves.any(
                    (move) => move.to == square && move.isCapture,
                  );
                  final redeploy = redeploySquares.contains(square);
                  final pendingRedeploy =
                      controller.pendingRedeploySquare == square;
                  final originalRedeploy =
                      controller.redeployOriginalSquare == square;
                  final pieceIsCheckedKing =
                      !presentationBusy &&
                      piece != null &&
                      piece.type == PieceType.king &&
                      controller.isKingInCheck(piece.color);
                  final stateOverlayColor = _stateOverlayColor(
                    selected,
                    legalMove,
                    legalCapture,
                    redeploy,
                    originalRedeploy,
                    pendingRedeploy,
                    pieceIsCheckedKing,
                  );
                  return GestureDetector(
                    key: ValueKey('board-square-$row-$col'),
                    onTap: () => controller.tapSquare(square),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.asset(
                          _squareAsset(controller, light),
                          fit: BoxFit.cover,
                          filterQuality: FilterQuality.medium,
                          excludeFromSemantics: true,
                          errorBuilder: (context, error, stackTrace) =>
                              ColoredBox(
                                color: light
                                    ? const Color(0xFFB99B69)
                                    : const Color(0xFF4D372B),
                              ),
                        ),
                        if (specialTile != null)
                          SpecialTileVisual(tile: specialTile),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 120),
                          decoration: BoxDecoration(
                            color: stateOverlayColor,
                            border: Border.all(
                              color: selected
                                  ? const Color(0xFFFFE08A)
                                  : const Color(0x332D1F16),
                              width: selected ? 3 : .6,
                            ),
                          ),
                        ),
                        Positioned(
                          left: 4,
                          top: 2,
                          child: Text(
                            controller.squareName(square),
                            style: TextStyle(
                              fontSize: 10,
                              color: light
                                  ? const Color(0x995D4A2F)
                                  : const Color(0x99F1DFB9),
                            ),
                          ),
                        ),
                        if (legalMove || redeploy)
                          Center(
                            child: ProductionLegalTargetMarker(
                              capture: legalCapture,
                              redeploy: redeploy,
                            ),
                          ),
                      ],
                    ),
                  );
                },
              ),
              if (presentationCoordinator?.reducedMotion == true &&
                  !presentationBusy &&
                  presentationCoordinator?.lastCompletedMotion != null)
                ..._reducedMotionHighlights(
                  boardSize,
                  presentationCoordinator!.lastCompletedMotion!,
                ),
              ..._staticPieces(
                boardSize,
                activeMotion: activeMotion,
                activeBetrayal: activeBetrayal,
                showConsequences: !presentationBusy,
              ),
              if (controller.lastBattlefieldEvent?.square != null &&
                  (presentationCoordinator?.battlefieldConsequencesReleased(
                        controller.lastBattlefieldEvent!.serial,
                      ) ??
                      true))
                Positioned.fill(
                  child: BattlefieldSquareFlash(
                    key: ValueKey(
                      'battlefield-square-flash-${controller.lastBattlefieldEvent!.serial}',
                    ),
                    event: controller.lastBattlefieldEvent!,
                  ),
                ),
              if (!presentationBusy &&
                  checkedKing != null &&
                  checkingAttackers.isNotEmpty)
                ProductionThreatLine(
                  from: _squareAlignment(checkingAttackers.first),
                  to: _squareAlignment(checkedKing),
                ),
              if (activeMotion != null)
                _MotionLayer(
                  event: activeMotion,
                  boardSize: boardSize,
                  duration:
                      presentationCoordinator?.moveDuration ?? Duration.zero,
                ),
              if (activeBetrayal != null)
                _BetrayalTransformLayer(
                  event: activeBetrayal,
                  boardSize: boardSize,
                  duration:
                      presentationCoordinator?.betrayalDuration ??
                      Duration.zero,
                ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> _staticPieces(
    Size boardSize, {
    required BoardMotionEvent? activeMotion,
    required BetrayalTransformEvent? activeBetrayal,
    required bool showConsequences,
  }) {
    final movingIds =
        activeMotion?.motions.map((motion) => motion.piece.id).toSet() ??
        <String>{};
    final pieces = <Widget>[];
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final piece = controller.board[row][col];
        if (piece == null || movingIds.contains(piece.id)) {
          continue;
        }
        final square = Square(row, col);
        final checked =
            showConsequences &&
            piece.type == PieceType.king &&
            controller.isKingInCheck(piece.color);
        final token = PieceToken(
          piece: piece,
          checked: checked,
          selected: controller.selectedSquare == square,
          loyaltyBand: controller.visibleLoyaltyBandForActiveCourt(piece),
        );
        pieces.add(
          _positioned(
            boardSize,
            square,
            checked ? ProductionCheckPulse(child: token) : token,
          ),
        );
      }
    }

    final pending = controller.pendingRedeploySquare;
    if (pending != null &&
        controller.redeployPiece != null &&
        activeBetrayal == null) {
      pieces.add(
        _positioned(
          boardSize,
          pending,
          Stack(
            alignment: Alignment.center,
            children: [
              Opacity(
                key: const ValueKey('board-redeploy-preview-token'),
                opacity: .76,
                child: PieceToken(
                  piece: controller.redeployPiece!,
                  checked: false,
                  selected: true,
                  loyaltyBand: controller.visibleLoyaltyBandForActiveCourt(
                    controller.redeployPiece!,
                  ),
                ),
              ),
              const Positioned(
                right: 8,
                top: 8,
                child: Icon(
                  Icons.check_circle,
                  color: Color(0xFF91E0CF),
                  size: 24,
                ),
              ),
            ],
          ),
        ),
      );
    }

    final original = controller.redeployOriginalSquare;
    if (original != null &&
        controller.redeployPiece != null &&
        activeBetrayal == null) {
      pieces.add(
        _positioned(
          boardSize,
          original,
          Stack(
            alignment: Alignment.center,
            children: [
              ProductionRedeployGhostToken(
                child: PieceToken(
                  piece: controller.redeployPiece!,
                  checked: false,
                  loyaltyBand: controller.visibleLoyaltyBandForActiveCourt(
                    controller.redeployPiece!,
                  ),
                ),
              ),
              const Icon(Icons.block, color: Color(0xFFFF5A58), size: 34),
            ],
          ),
        ),
      );
    }
    return pieces;
  }

  List<Widget> _reducedMotionHighlights(
    Size boardSize,
    BoardMotionEvent event,
  ) {
    return [
      for (final motion in event.motions) ...[
        _positioned(
          boardSize,
          motion.from,
          const _StaticMoveHighlight(
            key: ValueKey('reduced-motion-origin'),
            origin: true,
          ),
        ),
        _positioned(
          boardSize,
          motion.to,
          const _StaticMoveHighlight(
            key: ValueKey('reduced-motion-destination'),
            origin: false,
          ),
        ),
      ],
    ];
  }

  Positioned _positioned(Size boardSize, Square square, Widget child) {
    final rect = _squareRect(boardSize, square);
    return Positioned.fromRect(
      rect: rect,
      child: IgnorePointer(child: child),
    );
  }

  String _squareAsset(GameController controller, bool light) {
    final battlefield = controller.battlefield;
    final themed = light
        ? battlefield.lightSquareAsset
        : battlefield.darkSquareAsset;
    if (themed != null) {
      return themed;
    }
    return light
        ? 'assets/runtime/pieces/board/mercantile/square_light.webp'
        : 'assets/runtime/pieces/board/mercantile/square_dark.webp';
  }

  Alignment _squareAlignment(Square square) {
    return Alignment(
      ((square.col + .5) / 8) * 2 - 1,
      ((square.row + .5) / 8) * 2 - 1,
    );
  }

  Color? _stateOverlayColor(
    bool selected,
    bool legal,
    bool capture,
    bool redeploy,
    bool original,
    bool pendingRedeploy,
    bool checked,
  ) {
    if (checked) return const Color(0xE67D2628);
    if (original) return const Color(0xE6572424);
    if (pendingRedeploy) return const Color(0xE03B8F82);
    if (redeploy) return const Color(0xD626655F);
    if (capture) return const Color(0xE6714138);
    if (legal) return const Color(0xC45F5732);
    if (selected) return const Color(0xE6776035);
    return null;
  }
}

class _MotionLayer extends StatelessWidget {
  const _MotionLayer({
    required this.event,
    required this.boardSize,
    required this.duration,
  });

  final BoardMotionEvent event;
  final Size boardSize;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    return BoardMotionLayer(
      event: event,
      boardSize: boardSize,
      duration: duration,
    );
  }
}

class _BetrayalTransformLayer extends StatelessWidget {
  const _BetrayalTransformLayer({
    required this.event,
    required this.boardSize,
    required this.duration,
  });

  final BetrayalTransformEvent event;
  final Size boardSize;
  final Duration duration;

  @override
  Widget build(BuildContext context) {
    final accent =
        countries[event.after.countryId]?.secondaryColor ??
        const Color(0xFFF0C86C);
    return BoardPieceTransformLayer(
      serial: event.serial,
      square: event.square,
      before: event.before,
      after: event.after,
      boardSize: boardSize,
      duration: duration,
      accent: accent,
      semanticLabel:
          '${event.before.countryId} piece betrays and joins '
          '${event.after.countryId}',
      layerKeyPrefix: 'betrayal-transform',
      glowKey: 'betrayal-buyer-glow',
      beforeKey: 'betrayal-before-${event.before.countryId}',
      afterKey: 'betrayal-after-${event.after.countryId}',
    );
  }
}

class _StaticMoveHighlight extends StatelessWidget {
  const _StaticMoveHighlight({required this.origin, super.key});

  final bool origin;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Padding(
        padding: const EdgeInsets.all(4),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: (origin ? const Color(0xFFF0C86C) : const Color(0xFF69D7CF))
                .withValues(alpha: .18),
            border: Border.all(
              color: origin ? const Color(0xFFF0C86C) : const Color(0xFF69D7CF),
              width: 3,
            ),
            borderRadius: BorderRadius.circular(5),
          ),
        ),
      ),
    );
  }
}

Rect _squareRect(Size boardSize, Square square) {
  final cellWidth = boardSize.width / 8;
  final cellHeight = boardSize.height / 8;
  return Rect.fromLTWH(
    square.col * cellWidth,
    square.row * cellHeight,
    cellWidth,
    cellHeight,
  );
}
