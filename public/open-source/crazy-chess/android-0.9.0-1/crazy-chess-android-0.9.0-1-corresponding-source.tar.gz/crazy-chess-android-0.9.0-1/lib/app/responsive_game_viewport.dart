import 'package:flutter/material.dart';

import 'stage_metrics.dart';

class ResponsiveGameViewport extends StatelessWidget {
  const ResponsiveGameViewport({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xFF08090b),
      child: SafeArea(child: _ScaledStage(child: child)),
    );
  }
}

class _ScaledStage extends StatelessWidget {
  const _ScaledStage({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Center(
          child: FittedBox(
            fit: BoxFit.contain,
            child: SizedBox(
              key: StageMetrics.stageKey,
              width: StageMetrics.logicalWidth,
              height: StageMetrics.logicalHeight,
              child: ClipRect(child: child),
            ),
          ),
        );
      },
    );
  }
}
