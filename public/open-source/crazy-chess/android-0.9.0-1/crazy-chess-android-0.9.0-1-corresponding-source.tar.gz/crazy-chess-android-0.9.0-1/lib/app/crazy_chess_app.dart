import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import '../ai/chess_engine.dart';
import '../l10n/app_localizations.dart';
import '../l10n/runtime_game_locale.dart';
import '../playtest/playtest_diagnostics.dart';
import '../story/story_audio_controller.dart';
import 'app_locale_controller.dart';
import 'crazy_chess_shell.dart';
import 'theme.dart';
import 'title_background_rotation.dart';

class CrazyChessApp extends StatefulWidget {
  const CrazyChessApp({
    this.titleBackgroundAsset = TitleBackgroundRotation.defaultBackground,
    this.chessEngine,
    this.storyAudio = const SilentStoryAudio(),
    this.localeController,
    this.playtestDiagnostics,
    super.key,
  });

  final String titleBackgroundAsset;
  final ChessEngine? chessEngine;
  final StoryAudioPort storyAudio;
  final AppLocaleController? localeController;
  final PlaytestDiagnostics? playtestDiagnostics;

  @override
  State<CrazyChessApp> createState() => _CrazyChessAppState();
}

class _CrazyChessAppState extends State<CrazyChessApp> {
  late final AppLocaleController _localeController =
      widget.localeController ??
      AppLocaleController(
        store: MemoryAppLanguagePreferenceStore(),
        initialPreference: AppLanguagePreference.english,
      );

  @override
  void dispose() {
    if (widget.localeController == null) {
      _localeController.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _localeController,
      builder: (context, _) => AppLocaleScope(
        controller: _localeController,
        child: MaterialApp(
          onGenerateTitle: (context) => AppLocalizations.of(context).appTitle,
          debugShowCheckedModeBanner: false,
          locale: _localeController.localeOverride,
          supportedLocales: AppLocalizations.supportedLocales,
          localizationsDelegates: const <LocalizationsDelegate<dynamic>>[
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          localeListResolutionCallback: (locales, supportedLocales) =>
              AppLocaleController.resolveSystemLocales(locales ?? const []),
          theme: buildCrazyChessTheme(),
          builder: (context, child) {
            final locale = Localizations.localeOf(context);
            RuntimeGameLocale.setLocale(locale);
            return Theme(
              data: buildCrazyChessTheme(locale: locale),
              child: child!,
            );
          },
          home: CrazyChessShell(
            titleBackgroundAsset: widget.titleBackgroundAsset,
            chessEngine: widget.chessEngine,
            storyAudio: widget.storyAudio,
            playtestDiagnostics: widget.playtestDiagnostics,
            appLocale: _localeController.effectiveLocale(
              WidgetsBinding.instance.platformDispatcher.locales,
            ),
          ),
        ),
      ),
    );
  }
}
