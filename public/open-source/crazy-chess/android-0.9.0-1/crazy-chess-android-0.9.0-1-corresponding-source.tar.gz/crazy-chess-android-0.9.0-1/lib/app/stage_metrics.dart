import 'package:flutter/widgets.dart';

class StageMetrics {
  const StageMetrics._();

  static const double logicalWidth = 1600;
  static const double logicalHeight = 900;
  static const Size logicalSize = Size(logicalWidth, logicalHeight);
  static const double aspectRatio = logicalWidth / logicalHeight;
  static const Key stageKey = ValueKey<String>('responsive-game-stage');
}
