import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AppLanguagePreference { system, english, simplifiedChinese }

extension AppLanguagePreferenceStorage on AppLanguagePreference {
  String get storedValue => switch (this) {
    AppLanguagePreference.system => 'system',
    AppLanguagePreference.english => 'en',
    AppLanguagePreference.simplifiedChinese => 'zh-Hans',
  };

  Locale? get overrideLocale => switch (this) {
    AppLanguagePreference.system => null,
    AppLanguagePreference.english => const Locale('en'),
    AppLanguagePreference.simplifiedChinese => const Locale.fromSubtags(
      languageCode: 'zh',
      scriptCode: 'Hans',
    ),
  };

  static AppLanguagePreference fromStoredValue(String? value) =>
      switch (value) {
        'system' => AppLanguagePreference.system,
        'en' => AppLanguagePreference.english,
        'zh-Hans' => AppLanguagePreference.simplifiedChinese,
        _ => AppLanguagePreference.english,
      };
}

abstract interface class AppLanguagePreferenceStore {
  Future<String?> read();

  Future<void> write(String value);
}

class SharedPreferencesAppLanguagePreferenceStore
    implements AppLanguagePreferenceStore {
  SharedPreferencesAppLanguagePreferenceStore({
    SharedPreferencesAsync? preferences,
  }) : _preferences = preferences ?? SharedPreferencesAsync();

  static const storageKey = 'app.language_preference.v1';
  final SharedPreferencesAsync _preferences;

  @override
  Future<String?> read() => _preferences.getString(storageKey);

  @override
  Future<void> write(String value) => _preferences.setString(storageKey, value);
}

class MemoryAppLanguagePreferenceStore implements AppLanguagePreferenceStore {
  MemoryAppLanguagePreferenceStore([this.value]);

  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}

class AppLocaleController extends ChangeNotifier with WidgetsBindingObserver {
  AppLocaleController({
    required AppLanguagePreferenceStore store,
    AppLanguagePreference initialPreference = AppLanguagePreference.english,
  }) : _store = store,
       _preference = initialPreference {
    WidgetsBinding.instance.addObserver(this);
  }

  final AppLanguagePreferenceStore _store;
  AppLanguagePreference _preference;

  AppLanguagePreference get preference => _preference;

  Locale? get localeOverride => _preference.overrideLocale;

  Future<void> load() async {
    _preference = AppLanguagePreferenceStorage.fromStoredValue(
      await _store.read(),
    );
  }

  Future<void> setPreference(AppLanguagePreference preference) async {
    if (_preference == preference) {
      return;
    }
    _preference = preference;
    notifyListeners();
    await _store.write(preference.storedValue);
  }

  @override
  void didChangeLocales(List<Locale>? locales) {
    if (_preference == AppLanguagePreference.system) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Locale effectiveLocale(Iterable<Locale> systemLocales) {
    return localeOverride ?? resolveSystemLocales(systemLocales);
  }

  static Locale resolveSystemLocales(Iterable<Locale> locales) {
    for (final locale in locales) {
      if (_isSimplifiedChinese(locale)) {
        return simplifiedChineseLocale;
      }
      if (locale.languageCode == 'zh') {
        // Traditional and unspecified Chinese stay English until zh-Hant exists.
        return englishLocale;
      }
      if (locale.languageCode == 'en') {
        return englishLocale;
      }
    }
    return englishLocale;
  }

  static bool isSimplifiedChinese(Locale locale) =>
      _isSimplifiedChinese(locale);

  static bool _isSimplifiedChinese(Locale locale) {
    if (locale.languageCode != 'zh') {
      return false;
    }
    if (locale.scriptCode == 'Hans') {
      return true;
    }
    return locale.countryCode == 'CN' || locale.countryCode == 'SG';
  }

  static const englishLocale = Locale('en');
  static const simplifiedChineseLocale = Locale.fromSubtags(
    languageCode: 'zh',
    scriptCode: 'Hans',
  );
}

class AppLocaleScope extends InheritedNotifier<AppLocaleController> {
  const AppLocaleScope({
    required AppLocaleController controller,
    required super.child,
    super.key,
  }) : super(notifier: controller);

  static AppLocaleController of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppLocaleScope>();
    assert(scope != null, 'AppLocaleScope is missing above this context.');
    return scope!.notifier!;
  }
}
