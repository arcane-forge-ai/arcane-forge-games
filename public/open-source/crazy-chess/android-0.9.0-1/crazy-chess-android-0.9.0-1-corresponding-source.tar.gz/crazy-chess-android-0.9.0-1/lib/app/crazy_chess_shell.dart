import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../ai/ai_turn_coordinator.dart';
import '../ai/chess_engine.dart';
import '../ai/engine_factory.dart';
import '../audio/audio_catalog.dart';
import '../audio/audio_settings.dart';
import '../audio/game_audio_controller.dart';
import '../audio/game_audio_event_router.dart';
import '../domain/chess_models.dart';
import '../game/game_controller.dart';
import '../last_piece/last_piece_models.dart';
import '../last_piece/last_piece_session_controller.dart';
import '../l10n/ui_copy.dart';
import '../living_campaign/doubao_client.dart';
import '../living_campaign/living_campaign_archive_store.dart';
import '../living_campaign/living_campaign_controller.dart';
import '../living_campaign/living_campaign_demo_gateway.dart';
import '../living_campaign/living_campaign_generation_service.dart';
import '../living_campaign/living_campaign_models.dart';
import '../living_campaign/living_portrait_resolver.dart';
import '../living_campaign/living_campaign_settings.dart';
import '../living_campaign/living_campaign_v2_backend.dart';
import '../playtest/playtest_data_export_destination.dart';
import '../playtest/playtest_data_exporter.dart';
import '../playtest/playtest_diagnostics.dart';
import '../story/story_campaign_controller.dart';
import '../story/story_audio_controller.dart';
import '../story/story_models.dart';
import '../ui/board/board_presentation_coordinator.dart';
import '../ui/last_piece/last_piece_flow_screens.dart';
import '../ui/last_piece/last_piece_presentation_coordinator.dart';
import '../ui/living_campaign/living_campaign_screens.dart';
import '../ui/match/match_screen.dart';
import '../ui/menu/battlefield_select_screen.dart';
import '../ui/menu/menu_flow_screens.dart';
import '../ui/menu/match_setup_screens.dart';
import '../ui/menu/versus_loading_screen.dart';
import '../ui/menu/remaining_flow_screens.dart';
import '../ui/story/story_flow_screens.dart';
import 'responsive_game_viewport.dart';

class CrazyChessShell extends StatefulWidget {
  const CrazyChessShell({
    required this.titleBackgroundAsset,
    this.appLocale = const Locale('en'),
    this.chessEngine,
    this.storyAudio = const SilentStoryAudio(),
    this.livingCampaignArchive,
    this.livingCampaignSettingsController,
    this.livingPrologueGenerator,
    this.livingNextChapterGenerator,
    this.livingPortraitGenerator,
    this.livingChapterArtGenerator,
    this.livingChapterArtRetryGenerator,
    this.livingChapterClosureTextGenerator,
    this.livingChapterClosureTextRetryGenerator,
    this.livingDemoEnabledOverride,
    this.playtestDiagnostics,
    this.playtestDataExporter,
    super.key,
  });

  final String titleBackgroundAsset;
  final Locale appLocale;
  final ChessEngine? chessEngine;
  final StoryAudioPort storyAudio;
  final LivingCampaignArchiveStore? livingCampaignArchive;
  final LivingCampaignSettingsController? livingCampaignSettingsController;
  final LivingPrologueGenerator? livingPrologueGenerator;
  final LivingNextChapterGenerator? livingNextChapterGenerator;
  final LivingPortraitGenerator? livingPortraitGenerator;
  final LivingChapterArtGenerator? livingChapterArtGenerator;
  final LivingChapterArtRetryGenerator? livingChapterArtRetryGenerator;
  final LivingChapterClosureTextGenerator? livingChapterClosureTextGenerator;
  final LivingChapterClosureTextRetryGenerator?
  livingChapterClosureTextRetryGenerator;
  final bool? livingDemoEnabledOverride;
  final PlaytestDiagnostics? playtestDiagnostics;
  final PlaytestDataExporter? playtestDataExporter;

  @override
  State<CrazyChessShell> createState() => _CrazyChessShellState();
}

String livingCampaignMusicCueForPhase(
  LivingCampaignPhase phase, {
  LivingBattleResult? result,
}) => switch (phase) {
  LivingCampaignPhase.loading ||
  LivingCampaignPhase.hub ||
  LivingCampaignPhase.history => 'living_entry_hub',
  LivingCampaignPhase.prologue ||
  LivingCampaignPhase.dialogue ||
  LivingCampaignPhase.briefing => 'living_story_briefing',
  LivingCampaignPhase.battle => 'living_battle',
  LivingCampaignPhase.outcomeAcknowledgement ||
  LivingCampaignPhase.chapterClosureLoading ||
  LivingCampaignPhase.aftermathDialogue ||
  LivingCampaignPhase.chapterArtLoading ||
  LivingCampaignPhase.chapterEnding ||
  LivingCampaignPhase.epilogue =>
    result == LivingBattleResult.defeat
        ? 'living_defeat_result'
        : 'living_victory_result',
};

class _CrazyChessShellState extends State<CrazyChessShell>
    with WidgetsBindingObserver {
  static const bool _livingDemoBuildEnabled = bool.fromEnvironment(
    'LIVING_CAMPAIGN_DEMO',
  );
  static const int _livingDemoDelayMs = int.fromEnvironment(
    'LIVING_CAMPAIGN_DEMO_DELAY_MS',
    defaultValue: 120,
  );

  static const _demoPrecacheAssets = <String>[
    'assets/runtime/ui/match_settings/s04_match_settings_bg.webp',
    'assets/runtime/ui/country_select/s05_country_hall_bg.webp',
    'assets/runtime/scenes/versus/s07_versus_bg.webp',
    'assets/runtime/scenes/versus/battlefield_board.webp',
    'assets/runtime/ui/common/panel_parchment_9slice.webp',
    'assets/runtime/ui/common/panel_trait_parchment_9slice.webp',
    'assets/runtime/pieces/countries/mercantile/representative_full_neutral.webp',
    'assets/runtime/pieces/countries/iron/representative_full_neutral.webp',
  ];

  late final GameController controller;
  late final ChessEngine engine;
  late final BoardPresentationCoordinator presentationCoordinator;
  late final AiTurnCoordinator aiCoordinator;
  late final LastPieceSessionController lastPieceController;
  late final LastPiecePresentationCoordinator lastPiecePresentationCoordinator;
  late final StoryCampaignController storyController;
  late final LivingCampaignArchiveStore livingArchive;
  late final LivingCampaignSettingsController livingSettingsController;
  late final LivingCampaignController livingController;
  late final PlaytestDiagnostics playtestDiagnostics;
  late final PlaytestDataExporter playtestDataExporter;
  late final GameAudioEventRouter audioEventRouter;
  Timer? _lastPieceWarningTimer;
  LivingCampaignPhase? _lastLivingAudioPhase;
  bool _didPrecacheDemoAssets = false;
  int _shownDirectorNoticeSerial = 0;
  HifiMenuStage stage = HifiMenuStage.title;
  PieceColor selectedCountrySide = PieceColor.white;
  String selectedMetaCountryId = 'mercantile';
  PieceType selectedRosterRole = PieceType.queen;
  LoadoutCategory selectedLoadoutCategory = LoadoutCategory.board;
  SettingsCategory selectedSettingsCategory = SettingsCategory.display;
  bool reducedEffects = false;
  PlayMode selectedPlayMode = PlayMode.localDuel;

  bool get _livingDemoEnabled =>
      kDebugMode &&
      (widget.livingDemoEnabledOverride ?? _livingDemoBuildEnabled);

  @override
  void initState() {
    super.initState();
    controller = GameController();
    engine = widget.chessEngine ?? createPlatformChessEngine();
    presentationCoordinator = BoardPresentationCoordinator(
      controller: controller,
    );
    aiCoordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
      presentationListenable: presentationCoordinator,
      isPresentationBusy: () => presentationCoordinator.isBusy,
    );
    lastPieceController = LastPieceSessionController();
    lastPiecePresentationCoordinator = LastPiecePresentationCoordinator(
      controller: lastPieceController,
    );
    storyController = StoryCampaignController(
      gameController: controller,
      audio: widget.storyAudio,
      contentLocale: widget.appLocale,
    );
    livingArchive =
        widget.livingCampaignArchive ?? createLivingCampaignArchiveStore();
    livingSettingsController =
        widget.livingCampaignSettingsController ??
        LivingCampaignSettingsController();
    playtestDiagnostics =
        widget.playtestDiagnostics ?? MemoryPlaytestDiagnostics();
    unawaited(playtestDiagnostics.initialize());
    playtestDataExporter =
        widget.playtestDataExporter ??
        PlaytestDataExporter(
          archive: livingArchive,
          diagnostics: playtestDiagnostics,
          destination: createPlaytestExportDestination(),
          secretsProvider: () => <String>[
            livingSettingsController.effective.values.apiKey,
          ],
        );
    playtestDiagnostics.record(
      'shell_started',
      data: <String, Object?>{'initialStage': stage.name},
    );
    livingController = LivingCampaignController(
      gameController: controller,
      moveEngine: engine,
      archive: livingArchive,
      generatePrologue:
          widget.livingPrologueGenerator ?? _generateLivingPrologue,
      generateNextChapter:
          widget.livingNextChapterGenerator ?? _generateLivingNextChapter,
      snapshotNextChapterGenerator: widget.livingNextChapterGenerator == null
          ? _snapshotLivingNextChapterGenerator
          : () => widget.livingNextChapterGenerator!,
      generatePortrait: widget.livingPortraitGenerator,
      snapshotPortraitGenerator: widget.livingPortraitGenerator == null
          ? _snapshotLivingPortraitGenerator
          : () => widget.livingPortraitGenerator!,
      generateChapterArt: widget.livingChapterArtGenerator,
      snapshotChapterArtGenerator: widget.livingChapterArtGenerator == null
          ? _snapshotLivingChapterArtGenerator
          : () => widget.livingChapterArtGenerator!,
      retryChapterArt: widget.livingChapterArtRetryGenerator,
      snapshotChapterArtRetryGenerator:
          widget.livingChapterArtRetryGenerator == null
          ? _snapshotLivingChapterArtRetryGenerator
          : () => widget.livingChapterArtRetryGenerator!,
      generateChapterClosureText: widget.livingChapterClosureTextGenerator,
      snapshotChapterClosureTextGenerator:
          widget.livingChapterClosureTextGenerator == null
          ? _snapshotLivingChapterClosureTextGenerator
          : () => widget.livingChapterClosureTextGenerator!,
      retryChapterClosureText: widget.livingChapterClosureTextRetryGenerator,
      snapshotChapterClosureTextRetryGenerator:
          widget.livingChapterClosureTextRetryGenerator == null
          ? _snapshotLivingChapterClosureTextRetryGenerator
          : () => widget.livingChapterClosureTextRetryGenerator!,
      generationSettingsSnapshot: _livingGenerationSettingsSnapshot,
      contentLocaleProvider: () => widget.appLocale.languageCode == 'zh'
          ? LivingContentLocale.simplifiedChinese
          : LivingContentLocale.english,
    );
    WidgetsBinding.instance.addObserver(this);
    final lifecycleState = WidgetsBinding.instance.lifecycleState;
    livingController.setAppForeground(
      lifecycleState == null || lifecycleState == AppLifecycleState.resumed,
    );
    livingController.setSessionVisible(_isLivingCampaignStage(stage));
    livingController.addListener(_handleLivingCampaignAudioChanged);
    audioEventRouter = GameAudioEventRouter(
      audio: widget.storyAudio,
      gameController: controller,
      lastPieceController: lastPieceController,
    );
    unawaited(_initializeAudio());
    unawaited(_initializeLastPiece());
    unawaited(storyController.initialize());
    unawaited(_initializeLivingCampaign());
  }

  @override
  void didUpdateWidget(covariant CrazyChessShell oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.appLocale != widget.appLocale) {
      unawaited(storyController.setContentLocale(widget.appLocale));
      unawaited(lastPieceController.loadBundledCatalog());
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    presentationCoordinator.setReducedMotion(
      reducedEffects ||
          (MediaQuery.maybeOf(context)?.disableAnimations ?? false),
    );
    lastPiecePresentationCoordinator.setReducedMotion(
      reducedEffects ||
          (MediaQuery.maybeOf(context)?.disableAnimations ?? false),
    );
    if (_didPrecacheDemoAssets) {
      return;
    }
    _didPrecacheDemoAssets = true;
    for (final asset in _demoPrecacheAssets) {
      precacheImage(AssetImage(asset), context);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    livingController.setAppForeground(state == AppLifecycleState.resumed);
    playtestDiagnostics.record(
      'app_lifecycle_changed',
      data: <String, Object?>{'state': state.name},
    );
  }

  @override
  void dispose() {
    playtestDiagnostics.record(
      'shell_disposed',
      data: <String, Object?>{'finalStage': stage.name},
    );
    unawaited(playtestDiagnostics.flush());
    WidgetsBinding.instance.removeObserver(this);
    _lastPieceWarningTimer?.cancel();
    audioEventRouter.dispose();
    aiCoordinator.dispose();
    presentationCoordinator.dispose();
    lastPiecePresentationCoordinator.dispose();
    lastPieceController.dispose();
    storyController.dispose();
    livingController.removeListener(_handleLivingCampaignAudioChanged);
    livingController.dispose();
    livingSettingsController.dispose();
    unawaited(engine.dispose());
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([
        controller,
        presentationCoordinator,
        aiCoordinator,
        lastPieceController,
        lastPiecePresentationCoordinator,
        storyController,
        livingController,
        livingSettingsController,
        if (_gameAudio != null) _gameAudio!.listenable,
      ]),
      builder: (context, _) {
        _scheduleDirectorNoticeIfAppropriate();
        final showDirectorStatus =
            livingController.directorStatus != LivingDirectorStatus.idle;
        final content = _shouldShowShellStage
            ? _buildMenuStage()
            : MatchScreen(
                controller: controller,
                presentationCoordinator: presentationCoordinator,
                onLobby: _returnToLobby,
                onRematch: () => _goTo(HifiMenuStage.versusLoading),
                onTutorial: () => _goTo(HifiMenuStage.tutorialRules),
                onSettings: () => _goTo(HifiMenuStage.settings),
                aiThinking: aiCoordinator.isThinking,
                aiInputLocked: aiCoordinator.inputLocked,
                aiFailureMessage: aiCoordinator.localizedFailureMessage,
                onRetryAi: aiCoordinator.retry,
                storyDirectorStatus: showDirectorStatus
                    ? LivingCampaignStatusPill(
                        controller: livingController,
                        onPressed: () => _goTo(HifiMenuStage.livingHub),
                        iconOnly: true,
                      )
                    : null,
              );
        return Scaffold(
          body: ResponsiveGameViewport(
            child: Stack(
              fit: StackFit.expand,
              children: [
                content,
                if (_shouldShowShellStage &&
                    showDirectorStatus &&
                    !_usesIntegratedDirectorStatus)
                  Positioned(
                    top: 18,
                    right: 22,
                    child: LivingCampaignStatusPill(
                      controller: livingController,
                      onPressed: () => _goTo(HifiMenuStage.livingHub),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  bool get _shouldShowShellStage {
    if (controller.phase == GamePhase.setup) {
      return true;
    }
    return switch (stage) {
      HifiMenuStage.versusLoading ||
      HifiMenuStage.courtDorm ||
      HifiMenuStage.collectionMatrix ||
      HifiMenuStage.pieceProfile ||
      HifiMenuStage.loadout ||
      HifiMenuStage.postgameSummary ||
      HifiMenuStage.tutorialRules ||
      HifiMenuStage.settings => true,
      HifiMenuStage.lastPieceCountrySelect ||
      HifiMenuStage.lastPieceLevelLadder ||
      HifiMenuStage.lastPieceRun ||
      HifiMenuStage.lastPieceResults => true,
      HifiMenuStage.storyMap ||
      HifiMenuStage.storyDialogue ||
      HifiMenuStage.storyBattle ||
      HifiMenuStage.storyResults => true,
      HifiMenuStage.livingHub ||
      HifiMenuStage.livingPrologue ||
      HifiMenuStage.livingBriefing ||
      HifiMenuStage.livingBattle ||
      HifiMenuStage.livingResults => true,
      _ => false,
    };
  }

  Widget _buildMenuStage() {
    return switch (stage) {
      HifiMenuStage.title => TitleScreen(
        backgroundAsset: widget.titleBackgroundAsset,
        onStart: () => _goTo(HifiMenuStage.lobby),
        onSettings: () => _goTo(HifiMenuStage.settings),
        onExit: _confirmExit,
      ),
      HifiMenuStage.lobby => LobbyScreen(
        onPlay: () => _goTo(HifiMenuStage.modeSelect),
        onCollection: () => _goTo(HifiMenuStage.collectionMatrix),
        onCourt: () => _goTo(HifiMenuStage.courtDorm),
        onLoadout: () => _goTo(HifiMenuStage.loadout),
        onRecords: () => _goTo(HifiMenuStage.postgameSummary),
        onRules: () => _goTo(HifiMenuStage.tutorialRules),
        onSettings: () => _goTo(HifiMenuStage.settings),
      ),
      HifiMenuStage.modeSelect => ModeSelectScreen(
        selectedMode: selectedPlayMode,
        aiAvailable: _stockfishAvailable,
        engineStatus: aiCoordinator.engineStatus,
        onModeChanged: _setPlayMode,
        onBack: () => _goTo(HifiMenuStage.lobby),
        onContinue: _continueFromModeSelect,
        livingCampaignStatus: livingController.directorStatusLabel,
      ),
      HifiMenuStage.matchSettings => MatchSettingsScreen(
        controller: controller,
        aiAvailable: _stockfishAvailable,
        onBack: () => _goTo(HifiMenuStage.modeSelect),
        onContinue: () => _goTo(HifiMenuStage.battlefieldSelect),
      ),
      HifiMenuStage.battlefieldSelect => BattlefieldSelectScreen(
        controller: controller,
        onBack: () => _goTo(HifiMenuStage.matchSettings),
        onContinue: () => _goTo(HifiMenuStage.countrySelect),
      ),
      HifiMenuStage.countrySelect => CountrySelectScreen(
        controller: controller,
        selectedSide: selectedCountrySide,
        onSelectedSideChanged: (side) {
          setState(() => selectedCountrySide = side);
        },
        onBack: () => _goTo(HifiMenuStage.battlefieldSelect),
        onDetails: () {
          selectedMetaCountryId = selectedCountrySide == PieceColor.white
              ? controller.setupWhiteCountryId
              : controller.setupBlackCountryId;
          _goTo(HifiMenuStage.countryDetail);
        },
        onStart: () => _goTo(HifiMenuStage.versusLoading),
      ),
      HifiMenuStage.countryDetail => CountryDetailScreen(
        countryId: selectedMetaCountryId,
        onBack: () => _goTo(HifiMenuStage.countrySelect),
        onInspectPiece: (role) {
          selectedRosterRole = role;
          _goTo(HifiMenuStage.pieceProfile);
        },
        onLoadout: () => _goTo(HifiMenuStage.loadout),
      ),
      HifiMenuStage.versusLoading => VersusLoadingScreen(
        controller: controller,
        onBack: () => _goTo(HifiMenuStage.countrySelect),
        onStartMatch: _startMatch,
      ),
      HifiMenuStage.courtDorm => CourtDormScreen(
        lastPieceController: lastPieceController,
        countryId: selectedMetaCountryId,
        onCountryChanged: (countryId) {
          setState(() => selectedMetaCountryId = countryId);
          _routeMusicForStage();
        },
        onLobby: _returnToLobby,
        onCollection: () => _goTo(HifiMenuStage.collectionMatrix),
        onProfile: () => _goTo(HifiMenuStage.pieceProfile),
        onLoadout: () => _goTo(HifiMenuStage.loadout),
        onRecords: () => _goTo(HifiMenuStage.postgameSummary),
        onRules: () => _goTo(HifiMenuStage.tutorialRules),
        onSettings: () => _goTo(HifiMenuStage.settings),
      ),
      HifiMenuStage.collectionMatrix => CollectionMatrixScreen(
        countryId: selectedMetaCountryId,
        role: selectedRosterRole,
        onCountryChanged: (countryId) {
          setState(() => selectedMetaCountryId = countryId);
          _routeMusicForStage();
        },
        onRoleChanged: (role) {
          setState(() => selectedRosterRole = role);
        },
        onViewProfile: () => _goTo(HifiMenuStage.pieceProfile),
        onLobby: _returnToLobby,
        onCourt: () => _goTo(HifiMenuStage.courtDorm),
        onLoadout: () => _goTo(HifiMenuStage.loadout),
        onRecords: () => _goTo(HifiMenuStage.postgameSummary),
        onRules: () => _goTo(HifiMenuStage.tutorialRules),
        onSettings: () => _goTo(HifiMenuStage.settings),
      ),
      HifiMenuStage.pieceProfile => PieceProfileScreen(
        countryId: selectedMetaCountryId,
        role: selectedRosterRole,
        onBack: () => _goTo(HifiMenuStage.collectionMatrix),
        onLoadout: () => _goTo(HifiMenuStage.loadout),
      ),
      HifiMenuStage.loadout => LoadoutScreen(
        selectedCategory: selectedLoadoutCategory,
        onCategoryChanged: (category) {
          setState(() => selectedLoadoutCategory = category);
        },
        onLobby: _returnToLobby,
        onCollection: () => _goTo(HifiMenuStage.collectionMatrix),
        onCourt: () => _goTo(HifiMenuStage.courtDorm),
        onRecords: () => _goTo(HifiMenuStage.postgameSummary),
        onRules: () => _goTo(HifiMenuStage.tutorialRules),
        onSettings: () => _goTo(HifiMenuStage.settings),
      ),
      HifiMenuStage.postgameSummary => PostgameSummaryScreen(
        controller: controller,
        onLobby: _returnToLobby,
        onRematch: () => _goTo(HifiMenuStage.versusLoading),
      ),
      HifiMenuStage.tutorialRules => TutorialRulesScreen(
        onLobby: _returnToLobby,
        onCollection: () => _goTo(HifiMenuStage.collectionMatrix),
        onCourt: () => _goTo(HifiMenuStage.courtDorm),
        onLoadout: () => _goTo(HifiMenuStage.loadout),
        onRecords: () => _goTo(HifiMenuStage.postgameSummary),
        onSettings: () => _goTo(HifiMenuStage.settings),
      ),
      HifiMenuStage.settings => SettingsScreen(
        onLobby: _returnToLobby,
        onCollection: () => _goTo(HifiMenuStage.collectionMatrix),
        onCourt: () => _goTo(HifiMenuStage.courtDorm),
        onLoadout: () => _goTo(HifiMenuStage.loadout),
        onRecords: () => _goTo(HifiMenuStage.postgameSummary),
        onRules: () => _goTo(HifiMenuStage.tutorialRules),
        selectedCategory: selectedSettingsCategory,
        onCategoryChanged: (category) {
          setState(() => selectedSettingsCategory = category);
        },
        reducedEffects: reducedEffects,
        onReducedEffectsChanged: (value) {
          setState(() {
            reducedEffects = value;
            presentationCoordinator.setReducedMotion(
              value ||
                  (MediaQuery.maybeOf(context)?.disableAnimations ?? false),
            );
            lastPiecePresentationCoordinator.setReducedMotion(
              value ||
                  (MediaQuery.maybeOf(context)?.disableAnimations ?? false),
            );
          });
        },
        audioSettings: _gameAudio?.settings ?? const GameAudioSettings(),
        onMasterVolumeChanged: (value) => _gameAudio?.setMasterVolume(value),
        onMusicVolumeChanged: (value) => _gameAudio?.setMusicVolume(value),
        onSfxVolumeChanged: (value) => _gameAudio?.setSfxVolume(value),
        onMasterMutedChanged: (value) => _gameAudio?.setMasterMuted(value),
        onMusicMutedChanged: (value) => _gameAudio?.setMusicMuted(value),
        onSfxMutedChanged: (value) => _gameAudio?.setSfxMuted(value),
        livingSettingsController: livingSettingsController,
        onTestLivingAi: _testLivingCapability,
        onExportPlaytestData: _exportPlaytestData,
      ),
      HifiMenuStage.lastPieceCountrySelect => LastPieceCountrySelectScreen(
        controller: lastPieceController,
        onBack: () => _goTo(HifiMenuStage.modeSelect),
        onContinue: () => _goTo(HifiMenuStage.lastPieceLevelLadder),
      ),
      HifiMenuStage.lastPieceLevelLadder => LastPieceLevelLadderScreen(
        controller: lastPieceController,
        onBack: () => _goTo(HifiMenuStage.lastPieceCountrySelect),
        onStart: _startLastPieceRun,
      ),
      HifiMenuStage.lastPieceRun => _buildLastPieceRunStage(),
      HifiMenuStage.lastPieceResults => _buildLastPieceResults(),
      HifiMenuStage.storyMap ||
      HifiMenuStage.storyDialogue ||
      HifiMenuStage.storyBattle ||
      HifiMenuStage.storyResults => _buildStoryStage(),
      HifiMenuStage.livingHub ||
      HifiMenuStage.livingPrologue ||
      HifiMenuStage.livingBriefing ||
      HifiMenuStage.livingBattle ||
      HifiMenuStage.livingResults => _buildLivingStage(),
    };
  }

  void _goTo(HifiMenuStage nextStage) {
    final previousStage = stage;
    livingController.setSessionVisible(_isLivingCampaignStage(nextStage));
    setState(() => stage = nextStage);
    playtestDiagnostics.record(
      'screen_changed',
      data: <String, Object?>{'from': previousStage.name, 'to': nextStage.name},
    );
    _routeMusicForStage();
  }

  bool _isLivingCampaignStage(HifiMenuStage value) => switch (value) {
    HifiMenuStage.livingHub ||
    HifiMenuStage.livingPrologue ||
    HifiMenuStage.livingBriefing ||
    HifiMenuStage.livingBattle ||
    HifiMenuStage.livingResults => true,
    _ => false,
  };

  GameAudioController? get _gameAudio {
    final audio = widget.storyAudio;
    return audio is GameAudioController ? audio : null;
  }

  Future<void> _initializeAudio() async {
    final audio = _gameAudio;
    if (audio == null) {
      return;
    }
    await audio.initialize();
    if (mounted) {
      _routeMusicForStage();
    }
  }

  void _routeMusicForStage() {
    final audio = _gameAudio;
    if (audio == null) {
      return;
    }
    if (stage == HifiMenuStage.storyMap ||
        stage == HifiMenuStage.storyDialogue ||
        stage == HifiMenuStage.storyBattle ||
        stage == HifiMenuStage.storyResults) {
      return;
    }
    if (stage == HifiMenuStage.livingHub ||
        stage == HifiMenuStage.livingPrologue ||
        stage == HifiMenuStage.livingBriefing ||
        stage == HifiMenuStage.livingBattle ||
        stage == HifiMenuStage.livingResults) {
      final cue = livingCampaignMusicCueForPhase(
        livingController.phase,
        result: livingController.pendingOutcome?.result,
      );
      audio.playMusic(cue);
      return;
    }
    if (stage == HifiMenuStage.lastPieceRun ||
        stage == HifiMenuStage.lastPieceResults) {
      audio.playContext(GameMusicContext.lastPiece);
      return;
    }
    if (controller.phase != GamePhase.setup) {
      final countryId = controller.whiteCountryId;
      audio.playContext(
        GameMusicContext.battle,
        countryId: countryId,
        familiarity: lastPieceController.familiarityFor(countryId),
      );
      return;
    }
    if (stage == HifiMenuStage.courtDorm ||
        stage == HifiMenuStage.collectionMatrix ||
        stage == HifiMenuStage.countryDetail ||
        stage == HifiMenuStage.pieceProfile ||
        stage == HifiMenuStage.loadout) {
      audio.playContext(
        GameMusicContext.court,
        countryId: selectedMetaCountryId,
        familiarity: lastPieceController.familiarityFor(selectedMetaCountryId),
      );
      return;
    }
    audio.playContext(GameMusicContext.main);
  }

  void _handleLivingCampaignAudioChanged() {
    final next = livingController.phase;
    if (_lastLivingAudioPhase == next) return;
    _lastLivingAudioPhase = next;
    if (mounted) _routeMusicForStage();
  }

  Widget _buildStoryStage() {
    return switch (storyController.phase) {
      StoryCampaignPhase.loading ||
      StoryCampaignPhase.map => StoryCampaignMapScreen(
        controller: storyController,
        onBack: () => _goTo(HifiMenuStage.modeSelect),
      ),
      StoryCampaignPhase.dialogue => StoryDialogueScreen(
        controller: storyController,
      ),
      StoryCampaignPhase.battle => StoryBattleScreen(
        controller: storyController,
        presentationCoordinator: presentationCoordinator,
        storyDirectorStatus:
            livingController.directorStatus == LivingDirectorStatus.idle
            ? null
            : LivingCampaignStatusPill(
                controller: livingController,
                onPressed: () => _goTo(HifiMenuStage.livingHub),
                iconOnly: true,
              ),
      ),
      StoryCampaignPhase.results => StoryResultsScreen(
        controller: storyController,
        onLobby: _returnToLobby,
      ),
    };
  }

  Widget _buildLivingStage() {
    return switch (livingController.phase) {
      LivingCampaignPhase.loading ||
      LivingCampaignPhase.hub => LivingCampaignHubScreen(
        controller: livingController,
        settings: livingSettingsController.effective,
        onBack: () => _goTo(HifiMenuStage.modeSelect),
        onPlayAnotherMode: () => _goTo(HifiMenuStage.modeSelect),
        allowUnconfiguredGeneration: _livingDemoEnabled,
        onSettings: () {
          selectedSettingsCategory = SettingsCategory.livingAi;
          _goTo(HifiMenuStage.settings);
        },
      ),
      LivingCampaignPhase.prologue => LivingCampaignPrologueScreen(
        controller: livingController,
        onHub: livingController.returnToHub,
      ),
      LivingCampaignPhase.epilogue => LivingCampaignEpilogueScreen(
        controller: livingController,
      ),
      LivingCampaignPhase.dialogue => LivingCampaignDialogueScreen(
        controller: livingController,
        onHub: livingController.returnToHub,
      ),
      LivingCampaignPhase.briefing => LivingCampaignBriefingScreen(
        controller: livingController,
        onHub: livingController.returnToHub,
      ),
      LivingCampaignPhase.battle => LivingCampaignBattleScreen(
        controller: livingController,
        presentationCoordinator: presentationCoordinator,
        allowAssistedResolution: _livingDemoEnabled,
      ),
      LivingCampaignPhase.outcomeAcknowledgement =>
        LivingCampaignOutcomeAcknowledgementScreen(
          controller: livingController,
          onHub: livingController.returnToHub,
        ),
      LivingCampaignPhase.chapterClosureLoading =>
        LivingCampaignChapterClosureLoadingScreen(controller: livingController),
      LivingCampaignPhase.aftermathDialogue => LivingCampaignAftermathScreen(
        controller: livingController,
      ),
      LivingCampaignPhase.chapterArtLoading =>
        LivingCampaignChapterArtLoadingScreen(controller: livingController),
      LivingCampaignPhase.chapterEnding => LivingCampaignChapterEndingScreen(
        controller: livingController,
        onHub: livingController.returnToHub,
      ),
      LivingCampaignPhase.history => LivingCampaignHistoryScreen(
        controller: livingController,
        showDiagnostics:
            livingSettingsController.effective.values.textLogLevel !=
                LivingLogLevel.off ||
            livingSettingsController.effective.values.imageLogLevel !=
                LivingLogLevel.off,
      ),
    };
  }

  bool get _stockfishAvailable {
    return widget.chessEngine != null || isStockfishPlatformSupported;
  }

  Future<void> _continueFromModeSelect() async {
    if (selectedPlayMode == PlayMode.livingCampaign) {
      _goTo(HifiMenuStage.livingHub);
      return;
    }
    if (selectedPlayMode == PlayMode.storyCampaign) {
      storyController.enterCampaignMap();
      _goTo(HifiMenuStage.storyMap);
      return;
    }
    if (selectedPlayMode == PlayMode.lastPieceStanding) {
      _goTo(HifiMenuStage.lastPieceCountrySelect);
      return;
    }
    if (selectedPlayMode == PlayMode.aiDuel) {
      final ready = await aiCoordinator.preflight();
      if (!ready) {
        if (mounted) {
          await _showEngineFailure(aiCoordinator.failureMessage);
        }
        return;
      }
    }
    if (mounted) {
      _goTo(HifiMenuStage.matchSettings);
    }
  }

  Future<void> _initializeLivingCampaign() async {
    await livingSettingsController.initialize();
    await livingController.initialize();
  }

  Future<PlaytestDataExportResult> _exportPlaytestData() async {
    await livingController.flushTimingMetrics();
    return playtestDataExporter.export();
  }

  Future<LivingGenerationResult> _generateLivingPrologue(
    LivingCampaignRun run,
  ) async {
    if (_livingDemoEnabled) {
      return LivingCampaignGenerationService(
        gateway: LivingCampaignDemoGateway(
          responseDelay: Duration(milliseconds: _livingDemoDelayMs),
        ),
        archive: livingArchive,
        onProgress: livingController.acceptGenerationProgress,
      ).generatePrologue(run);
    }
    final client = _createLivingDoubaoClient();
    try {
      return await LivingCampaignGenerationService(
        gateway: DoubaoLivingGenerationGateway(client),
        archive: livingArchive,
        onProgress: livingController.acceptGenerationProgress,
      ).generatePrologue(run);
    } finally {
      client.close();
    }
  }

  Future<LivingGenerationResult> _generateLivingNextChapter(
    LivingCampaignRun run,
    LivingBattleOutcomeSnapshot outcome,
  ) => _snapshotLivingNextChapterGenerator()(run, outcome);

  LivingNextChapterGenerator _snapshotLivingNextChapterGenerator() {
    if (_livingDemoEnabled) {
      final backend = LivingCampaignV2Backend(
        gateway: LivingCampaignDemoGateway(
          responseDelay: Duration(milliseconds: _livingDemoDelayMs),
        ),
        archive: livingArchive,
        onProgress: livingController.acceptGenerationProgress,
        customContextTokens: 256000,
      );
      return (run, outcome) =>
          backend.generateNextChapter(run: run, outcome: outcome);
    }
    final settings = livingSettingsController.effective.values;
    return (run, outcome) async {
      final client = _createLivingDoubaoClient(settings);
      try {
        return await LivingCampaignV2Backend(
          gateway: DoubaoLivingCampaignV2Gateway(
            client,
            loadPortraitStyleReferences: _loadLivingPortraitStyleReferences,
          ),
          archive: livingArchive,
          onProgress: livingController.acceptGenerationProgress,
        ).generateNextChapter(run: run, outcome: outcome);
      } finally {
        client.close();
      }
    };
  }

  Future<List<Uint8List>> _loadLivingPortraitStyleReferences() async {
    const paths = <String>[
      'assets/runtime/pieces/characters/living/orsain_half_body.webp',
      'assets/runtime/pieces/characters/living/ysra_half_body.webp',
      'assets/runtime/pieces/characters/living/veyl_half_body.webp',
      'assets/runtime/pieces/characters/living/cael_half_body.webp',
    ];
    final references = <Uint8List>[];
    for (final path in paths) {
      final data = await rootBundle.load(path);
      references.add(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      );
    }
    return List<Uint8List>.unmodifiable(references);
  }

  LivingPortraitGenerator _snapshotLivingPortraitGenerator() {
    if (_livingDemoEnabled) {
      return (run, characterId) {
        final type =
            run.canon.charactersById[characterId]?.basePieceType ??
            PieceType.king;
        final fallback = LivingPortraitFallbackResolver.neutralAsset(
          type,
          stableKey: '${run.runId}:$characterId',
        );
        final pool = LivingPortraitFallbackResolver.neutralAssets(type);
        final fixture = pool.firstWhere(
          (asset) => asset != fallback,
          orElse: () =>
              'assets/runtime/pieces/characters/living/fallbacks/unknown_king_b.webp',
        );
        final backend = LivingCampaignV2Backend(
          gateway: LivingCampaignDemoGateway(
            responseDelay: Duration(milliseconds: _livingDemoDelayMs),
            portraitSucceeds: true,
            portraitFixtureLoader: () =>
                _loadLivingDemoPortraitFixture(fixture),
          ),
          archive: livingArchive,
          onProgress: livingController.acceptGenerationProgress,
          customContextTokens: 256000,
        );
        return backend.retryPortrait(run: run, characterId: characterId);
      };
    }
    final settings = livingSettingsController.effective.values;
    return (run, characterId) async {
      final client = _createLivingDoubaoClient(settings);
      try {
        return await LivingCampaignV2Backend(
          gateway: DoubaoLivingCampaignV2Gateway(
            client,
            loadPortraitStyleReferences: _loadLivingPortraitStyleReferences,
          ),
          archive: livingArchive,
          onProgress: livingController.acceptGenerationProgress,
        ).retryPortrait(run: run, characterId: characterId);
      } finally {
        client.close();
      }
    };
  }

  LivingChapterArtGenerator _snapshotLivingChapterArtGenerator() {
    if (_livingDemoEnabled) {
      final backend = LivingCampaignV2Backend(
        gateway: LivingCampaignDemoGateway(
          responseDelay: Duration(milliseconds: _livingDemoDelayMs),
        ),
        archive: livingArchive,
        onProgress: livingController.acceptGenerationProgress,
        customContextTokens: 256000,
        persistenceDomain: LivingCampaignPersistenceDomain.chapterArt,
      );
      return (run, outcome) =>
          backend.generateChapterEndingArt(run: run, outcome: outcome);
    }
    final settings = livingSettingsController.effective.values;
    return (run, outcome) async {
      final client = _createLivingDoubaoClient(settings);
      try {
        return await LivingCampaignV2Backend(
          gateway: DoubaoLivingCampaignV2Gateway(
            client,
            loadPortraitStyleReferences: _loadLivingPortraitStyleReferences,
          ),
          archive: livingArchive,
          onProgress: livingController.acceptGenerationProgress,
          persistenceDomain: LivingCampaignPersistenceDomain.chapterArt,
        ).generateChapterEndingArt(run: run, outcome: outcome);
      } finally {
        client.close();
      }
    };
  }

  LivingChapterArtRetryGenerator _snapshotLivingChapterArtRetryGenerator() {
    if (_livingDemoEnabled) {
      return (run, chapterId) {
        final backend = LivingCampaignV2Backend(
          gateway: LivingCampaignDemoGateway(
            responseDelay: Duration(milliseconds: _livingDemoDelayMs),
            chapterArtSucceeds: true,
            chapterArtFixtureLoader: () => _loadLivingDemoPortraitFixture(
              'assets/runtime/battlefields/ruined/background.webp',
            ),
          ),
          archive: livingArchive,
          onProgress: livingController.acceptGenerationProgress,
          customContextTokens: 256000,
          persistenceDomain: LivingCampaignPersistenceDomain.chapterArt,
        );
        return backend.retryChapterEndingArt(run: run, chapterId: chapterId);
      };
    }
    final settings = livingSettingsController.effective.values;
    return (run, chapterId) async {
      final client = _createLivingDoubaoClient(settings);
      try {
        return await LivingCampaignV2Backend(
          gateway: DoubaoLivingCampaignV2Gateway(
            client,
            loadPortraitStyleReferences: _loadLivingPortraitStyleReferences,
          ),
          archive: livingArchive,
          onProgress: livingController.acceptGenerationProgress,
          persistenceDomain: LivingCampaignPersistenceDomain.chapterArt,
        ).retryChapterEndingArt(run: run, chapterId: chapterId);
      } finally {
        client.close();
      }
    };
  }

  LivingChapterClosureTextGenerator
  _snapshotLivingChapterClosureTextGenerator() {
    if (_livingDemoEnabled) {
      final backend = LivingCampaignV2Backend(
        gateway: LivingCampaignDemoGateway(
          responseDelay: Duration(milliseconds: _livingDemoDelayMs),
        ),
        archive: livingArchive,
        onProgress: livingController.acceptGenerationProgress,
        customContextTokens: 256000,
        generatePortraits: false,
        persistenceDomain: LivingCampaignPersistenceDomain.closureText,
      );
      return (run, outcome) =>
          backend.generateChapterClosureText(run: run, outcome: outcome);
    }
    final settings = livingSettingsController.effective.values;
    return (run, outcome) async {
      final client = _createLivingDoubaoClient(settings);
      try {
        return await LivingCampaignV2Backend(
          gateway: DoubaoLivingCampaignV2Gateway(
            client,
            loadPortraitStyleReferences: _loadLivingPortraitStyleReferences,
          ),
          archive: livingArchive,
          onProgress: livingController.acceptGenerationProgress,
          generatePortraits: false,
          persistenceDomain: LivingCampaignPersistenceDomain.closureText,
        ).generateChapterClosureText(run: run, outcome: outcome);
      } finally {
        client.close();
      }
    };
  }

  LivingChapterClosureTextRetryGenerator
  _snapshotLivingChapterClosureTextRetryGenerator() {
    if (_livingDemoEnabled) {
      final backend = LivingCampaignV2Backend(
        gateway: LivingCampaignDemoGateway(
          responseDelay: Duration(milliseconds: _livingDemoDelayMs),
        ),
        archive: livingArchive,
        onProgress: livingController.acceptGenerationProgress,
        customContextTokens: 256000,
        generatePortraits: false,
        persistenceDomain: LivingCampaignPersistenceDomain.closureText,
      );
      return (run, chapterId) =>
          backend.retryChapterClosureText(run: run, chapterId: chapterId);
    }
    final settings = livingSettingsController.effective.values;
    return (run, chapterId) async {
      final client = _createLivingDoubaoClient(settings);
      try {
        return await LivingCampaignV2Backend(
          gateway: DoubaoLivingCampaignV2Gateway(
            client,
            loadPortraitStyleReferences: _loadLivingPortraitStyleReferences,
          ),
          archive: livingArchive,
          onProgress: livingController.acceptGenerationProgress,
          generatePortraits: false,
          persistenceDomain: LivingCampaignPersistenceDomain.closureText,
        ).retryChapterClosureText(run: run, chapterId: chapterId);
      } finally {
        client.close();
      }
    };
  }

  Future<Uint8List> _loadLivingDemoPortraitFixture(String asset) async {
    final data = await rootBundle.load(asset);
    return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
  }

  Future<void> _testLivingCapability() async {
    livingSettingsController.markCapabilityTesting();
    if (_livingDemoEnabled) {
      livingSettingsController.markCapabilityAvailable();
      return;
    }
    final client = _createLivingDoubaoClient();
    try {
      await client.testCapability();
      livingSettingsController.markCapabilityAvailable();
    } on LivingProviderException catch (error) {
      livingSettingsController.markCapabilityFailed(error.safeMessage);
    } finally {
      client.close();
    }
  }

  Map<String, Object?> _livingGenerationSettingsSnapshot() {
    final effective = livingSettingsController.effective;
    return <String, Object?>{
      'baseUrl': effective.values.baseUrl,
      'textModel': effective.values.textModel,
      'imageModel': effective.values.imageModel,
      'apiKeyConfigured': effective.values.hasApiKey,
      'apiKeySource': effective.sources['apiKey']?.name ?? 'unknown',
      'textLogLevel': effective.values.textLogLevel.name,
      'imageLogLevel': effective.values.imageLogLevel.name,
      'logStages': effective.values.logStages.toList()..sort(),
    };
  }

  DoubaoClient _createLivingDoubaoClient([LivingCampaignSettings? settings]) {
    final effective = settings ?? livingSettingsController.effective.values;
    final loggingEnabled =
        effective.textLogLevel != LivingLogLevel.off ||
        effective.imageLogLevel != LivingLogLevel.off;
    return DoubaoClient(
      settings: effective,
      textLogLevel: effective.textLogLevel,
      imageLogLevel: effective.imageLogLevel,
      enabledLogStages: effective.logStages,
      debugLogger: loggingEnabled
          ? (message) {
              playtestDiagnostics.record(
                'living_ai_diagnostic',
                message: message,
              );
              if (kDebugMode) {
                debugPrintSynchronously(message, wrapWidth: 1024);
              }
            }
          : null,
    );
  }

  void _setPlayMode(PlayMode value) {
    setState(() {
      selectedPlayMode = value;
      if (value == PlayMode.localDuel) {
        controller.setOpponentMode(OpponentMode.local);
      } else if (value == PlayMode.aiDuel) {
        controller.setOpponentMode(OpponentMode.stockfish);
      }
    });
  }

  Future<void> _initializeLastPiece() async {
    await lastPieceController.loadProfile();
    try {
      await lastPieceController.loadBundledCatalog();
    } on FlutterError {
      // The immutable in-code catalog remains available in asset-light tests.
    }
    if (mounted) {
      _routeMusicForStage();
    }
  }

  Widget _buildLastPieceRunStage() {
    if (lastPieceController.phase == LastPieceRunPhase.gameOver &&
        lastPieceController.result != null &&
        !lastPiecePresentationCoordinator.isBusy) {
      return _buildLastPieceResults();
    }
    return LastPieceRunScreen(
      controller: lastPieceController,
      presentationCoordinator: lastPiecePresentationCoordinator,
      onMove: (square) => unawaited(_moveLastPiece(square)),
      onPromotion: (role) => unawaited(_promoteLastPiece(role)),
      onRetire: () => unawaited(_retireLastPiece()),
      onBackToLadder: () => unawaited(_retireLastPiece()),
      storyDirectorStatus:
          livingController.directorStatus == LivingDirectorStatus.idle
          ? null
          : LivingCampaignStatusPill(
              controller: livingController,
              onPressed: () => _goTo(HifiMenuStage.livingHub),
              iconOnly: true,
            ),
    );
  }

  bool get _usesIntegratedDirectorStatus =>
      stage == HifiMenuStage.storyBattle ||
      stage == HifiMenuStage.lastPieceRun ||
      stage == HifiMenuStage.livingHub ||
      stage == HifiMenuStage.livingBattle;

  bool get _isActiveMatchStage =>
      !_shouldShowShellStage ||
      stage == HifiMenuStage.storyBattle ||
      stage == HifiMenuStage.lastPieceRun ||
      stage == HifiMenuStage.livingBattle;

  void _scheduleDirectorNoticeIfAppropriate() {
    final serial = livingController.directorNoticeSerial;
    if (serial <= _shownDirectorNoticeSerial || _isActiveMatchStage) return;
    _shownDirectorNoticeSerial = serial;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final notice = livingController.takeDeferredDirectorNotice();
      if (notice == null || notice.isEmpty) return;
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Text(localizedUiCopy(context, notice)),
            action: SnackBarAction(
              label: localizedUiCopy(context, 'OPEN'),
              onPressed: () => _goTo(HifiMenuStage.livingHub),
            ),
          ),
        );
    });
  }

  Widget _buildLastPieceResults() {
    final next = lastPieceController.catalog.nextAfter(
      lastPieceController.selectedLevelId,
    );
    return LastPieceResultsScreen(
      controller: lastPieceController,
      onRetry: _startLastPieceRun,
      onNextLevel: next != null && lastPieceController.isLevelUnlocked(next.id)
          ? () {
              lastPieceController.selectLevel(next.id);
              _startLastPieceRun();
            }
          : null,
      onLadder: () => _goTo(HifiMenuStage.lastPieceLevelLadder),
      onCourtDorm: () {
        selectedMetaCountryId = lastPieceController.selectedCountryId;
        _goTo(HifiMenuStage.courtDorm);
      },
      onLobby: _returnToLobby,
    );
  }

  void _startLastPieceRun() {
    lastPieceController.startRun();
    lastPiecePresentationCoordinator.reset();
    _goTo(HifiMenuStage.lastPieceRun);
    widget.storyAudio.playSfx('wave_start');
    _lastPieceWarningTimer?.cancel();
    _lastPieceWarningTimer = Timer(const Duration(milliseconds: 900), () {
      if (mounted && stage == HifiMenuStage.lastPieceRun) {
        widget.storyAudio.playSfx('last_piece_warning');
      }
    });
  }

  Future<void> _moveLastPiece(Square square) async {
    if (lastPiecePresentationCoordinator.isBusy) {
      return;
    }
    await lastPieceController.movePlayer(square);
    await lastPiecePresentationCoordinator.settle();
    if (mounted && lastPieceController.phase == LastPieceRunPhase.gameOver) {
      _goTo(HifiMenuStage.lastPieceResults);
    }
  }

  Future<void> _promoteLastPiece(PieceType role) async {
    if (lastPiecePresentationCoordinator.isBusy) {
      return;
    }
    await lastPieceController.choosePromotion(role);
    await lastPiecePresentationCoordinator.settle();
    if (mounted && lastPieceController.phase == LastPieceRunPhase.gameOver) {
      _goTo(HifiMenuStage.lastPieceResults);
    }
  }

  Future<void> _retireLastPiece() async {
    if (lastPiecePresentationCoordinator.isBusy) {
      return;
    }
    await lastPieceController.retire();
    if (mounted) {
      _goTo(HifiMenuStage.lastPieceResults);
    }
  }

  Future<void> _confirmExit() async {
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Exit Crazy Chess?'),
        content: Text(
          kIsWeb
              ? 'Your browser controls this tab. Confirm to finish this session; you can then close the tab.'
              : 'Any unsaved match progress will be lost.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Exit'),
          ),
        ],
      ),
    );
    if (shouldExit != true || !mounted) {
      return;
    }
    if (kIsWeb) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Session finished. You can now close this browser tab.',
          ),
        ),
      );
      return;
    }
    await SystemNavigator.pop();
  }

  Future<void> _startMatch() async {
    if (controller.setupOpponentMode == OpponentMode.stockfish) {
      final ready = await aiCoordinator.prepareNewGame();
      if (!ready) {
        if (mounted) {
          await _showEngineFailure(aiCoordinator.failureMessage);
        }
        return;
      }
    }
    if (!mounted) {
      return;
    }
    setState(() => stage = HifiMenuStage.lobby);
    controller.startNewGame();
    _routeMusicForStage();
  }

  void _returnToLobby() {
    aiCoordinator.clearFailure();
    unawaited(engine.shutdown());
    controller.returnToSetup();
    setState(() => stage = HifiMenuStage.lobby);
    _routeMusicForStage();
  }

  Future<void> _showEngineFailure(String? message) {
    return showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Stockfish unavailable'),
        content: Text(
          message ??
              'The local chess engine could not start. Retry or return to the lobby.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(dialogContext).pop();
              _returnToLobby();
            },
            child: const Text('Return to Lobby'),
          ),
          FilledButton(
            onPressed: () async {
              final ready = await aiCoordinator.preflight();
              if (ready && dialogContext.mounted) {
                Navigator.of(dialogContext).pop();
              }
            },
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }
}
