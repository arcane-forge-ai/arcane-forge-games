import 'package:flutter/material.dart';

ThemeData buildCrazyChessTheme({Locale locale = const Locale('en')}) {
  final isChinese = locale.languageCode == 'zh';
  final fontFamily = isChinese ? 'Noto Sans SC' : 'Avenir Next';
  final baseTextTheme = ThemeData.dark().textTheme.apply(
    fontFamily: fontFamily,
    bodyColor: Colors.white,
    displayColor: Colors.white,
  );
  return ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color(0xFFcda557),
      brightness: Brightness.dark,
    ),
    scaffoldBackgroundColor: const Color(0xFF151719),
    fontFamily: fontFamily,
    textTheme: baseTextTheme.copyWith(
      bodyLarge: baseTextTheme.bodyLarge?.copyWith(
        height: isChinese ? 1.45 : 1.3,
        letterSpacing: isChinese ? 0 : null,
      ),
      bodyMedium: baseTextTheme.bodyMedium?.copyWith(
        height: isChinese ? 1.45 : 1.3,
        letterSpacing: isChinese ? 0 : null,
      ),
      labelLarge: baseTextTheme.labelLarge?.copyWith(
        height: isChinese ? 1.3 : 1.2,
        letterSpacing: isChinese ? 0 : null,
      ),
    ),
  );
}
