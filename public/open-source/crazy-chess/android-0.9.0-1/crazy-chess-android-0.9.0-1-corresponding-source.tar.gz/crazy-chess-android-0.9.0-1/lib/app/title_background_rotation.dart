import 'package:shared_preferences/shared_preferences.dart';

abstract interface class TitleBackgroundIndexStore {
  Future<int?> readNextIndex();

  Future<void> writeNextIndex(int value);
}

class SharedPreferencesTitleBackgroundIndexStore
    implements TitleBackgroundIndexStore {
  SharedPreferencesTitleBackgroundIndexStore({SharedPreferencesAsync? prefs})
    : _prefs = prefs ?? SharedPreferencesAsync();

  static const _key = 's01_title_background_next_index_v1';

  final SharedPreferencesAsync _prefs;

  @override
  Future<int?> readNextIndex() => _prefs.getInt(_key);

  @override
  Future<void> writeNextIndex(int value) => _prefs.setInt(_key, value);
}

class TitleBackgroundRotation {
  TitleBackgroundRotation({required TitleBackgroundIndexStore store})
    : _store = store;

  static const defaultBackground =
      'assets/runtime/ui/title/screen_s01_title_hall_bg_a.webp';

  static const backgrounds = <String>[
    defaultBackground,
    'assets/runtime/ui/title/screen_s01_title_hall_bg_b.webp',
    'assets/runtime/ui/title/screen_s01_title_hall_bg_c.webp',
  ];

  final TitleBackgroundIndexStore _store;

  Future<String> selectForLaunch() async {
    try {
      final storedIndex = await _store.readNextIndex() ?? 0;
      final selectedIndex = storedIndex % backgrounds.length;
      await _store.writeNextIndex((selectedIndex + 1) % backgrounds.length);
      return backgrounds[selectedIndex];
    } catch (_) {
      return backgrounds.first;
    }
  }
}
