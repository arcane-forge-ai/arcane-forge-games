import 'package:flutter/widgets.dart';

import 'app_localizations.dart';

/// Locale access for immutable domain catalogs whose display getters cannot
/// receive a BuildContext. Gameplay identity and persistence always use IDs.
abstract final class RuntimeGameLocale {
  static Locale _locale = const Locale('en');
  static AppLocalizations _copy = lookupAppLocalizations(_locale);

  static Locale get locale => _locale;
  static AppLocalizations get copy => _copy;
  static bool get isSimplifiedChinese => _locale.languageCode == 'zh';

  static void setLocale(Locale locale) {
    final normalized = locale.languageCode == 'zh'
        ? const Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hans')
        : const Locale('en');
    if (_locale == normalized) {
      return;
    }
    _locale = normalized;
    _copy = lookupAppLocalizations(normalized);
  }
}
