// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Crazy Chess';

  @override
  String get brandName => 'Crazy Chess';

  @override
  String get languageSystem => 'Follow System';

  @override
  String get languageEnglish => 'English';

  @override
  String get languageSimplifiedChinese => 'Simplified Chinese';

  @override
  String get languageSettingTitle => 'Language';

  @override
  String get languageSettingDescription =>
      'Choose the language used by menus and new campaigns.';

  @override
  String get languageChineseReadinessWarningTitle =>
      'Simplified Chinese is not ready yet';

  @override
  String get languageChineseReadinessWarningBody =>
      'The Simplified Chinese version is still in progress. Some screens may contain degraded artwork, untranslated text, or mixed-language labels. You can switch back to English at any time.';

  @override
  String get languageChineseReadinessWarningConfirm => 'Use Simplified Chinese';

  @override
  String get languageLivingPinnedNotice =>
      'Existing Living Campaign stories keep their original language.';

  @override
  String get settingsTitle => 'Settings';

  @override
  String get settingsCategoryDisplay => 'Display';

  @override
  String get settingsCategoryAudio => 'Audio';

  @override
  String get settingsCategoryControls => 'Controls';

  @override
  String get settingsCategoryAccessibility => 'Accessibility';

  @override
  String get settingsCategoryLanguage => 'Language';

  @override
  String get settingsCategoryGameplay => 'Gameplay';

  @override
  String get settingsCategoryAbout => 'About';

  @override
  String get settingsCategoryLivingAi => 'Living AI';

  @override
  String get settingsCategoryPlaytestData => 'Playtest Data';

  @override
  String get settingsCategoryOpenSourceLicenses => 'Open Source Licenses';

  @override
  String get settingsDeviceOptionsDescription =>
      'Display and accessibility options for the current device.';

  @override
  String get playtestDataTitle => 'Export Playtest Data';

  @override
  String get playtestDataDescription =>
      'Create one local ZIP to send to the Crazy Chess team after a playtest.';

  @override
  String get playtestDataIncludedTitle => 'Included';

  @override
  String get playtestDataIncludedBody =>
      'Living Campaign run and generation records, chapter timing metrics, and recent bounded diagnostic logs.';

  @override
  String get playtestDataPrivacyTitle => 'Before you share';

  @override
  String get playtestDataPrivacyBody =>
      'Campaign scripts are included. Portraits, saved settings, and API credentials are excluded. Nothing uploads automatically.';

  @override
  String get playtestDataDestinationTitle => 'Destination';

  @override
  String get playtestDataDestinationBody =>
      'Packaged desktop builds save a timestamped ZIP in your Downloads folder.';

  @override
  String get playtestDataExportButton => 'Export Playtest ZIP';

  @override
  String get playtestDataExporting => 'Exporting…';

  @override
  String get playtestDataFailed =>
      'The playtest ZIP could not be created. Your local campaign data was not changed.';

  @override
  String playtestDataExported(int runCount, int metricsCount, int logCount) {
    return 'Exported $runCount runs, $metricsCount timing files, and $logCount diagnostic logs.';
  }

  @override
  String get loadoutCategoryBoard => 'Board';

  @override
  String get loadoutCategoryToken => 'Token';

  @override
  String get loadoutCategoryBanner => 'Banner';

  @override
  String get loadoutCategoryContractSeal => 'Contract Seal';

  @override
  String get loadoutCategoryResultVfx => 'Result VFX';

  @override
  String get loadoutCategoryMerchant => 'Merchant';

  @override
  String get loadoutTitle => 'Decoration Loadout';

  @override
  String get loadoutSlots => 'Loadout Slots';

  @override
  String get loadoutPreviewDescription =>
      'Cosmetic persistence and unlocks are future systems; this screen previews the product surface.';

  @override
  String get commonCategories => 'Categories';

  @override
  String get loadoutCategoryPieces => 'Pieces';

  @override
  String get loadoutCategoryProfile => 'Profile';

  @override
  String get navHome => 'Home';

  @override
  String get navLoadout => 'Loadout';

  @override
  String get navPlay => 'Play';

  @override
  String get navCountries => 'Countries';

  @override
  String get navSettings => 'Settings';

  @override
  String get navRoster => 'Roster';

  @override
  String get navRecords => 'Records';

  @override
  String get navRules => 'Rules';

  @override
  String get modeLocalDuel => 'Local Duel';

  @override
  String get modeLocalDuelSubtitle => 'Two players on one device';

  @override
  String get modeAiDuel => 'AI Duel';

  @override
  String get modeAiDuelSubtitle => 'Challenge the machine court';

  @override
  String get modeStoryCampaign => 'Story Campaign';

  @override
  String get modeStoryCampaignSubtitle => 'A seven-mission authored tale';

  @override
  String get modeLastPiece => 'Last Piece Standing';

  @override
  String get modeLastPieceSubtitle => 'An endless single-piece survival ladder';

  @override
  String get modeLivingCampaign => 'Living Campaign';

  @override
  String get modeLivingCampaignSubtitle =>
      'An evolving chronicle shaped by your battles';

  @override
  String get commonBack => 'Back';

  @override
  String get commonCancel => 'Cancel';

  @override
  String get commonClose => 'Close';

  @override
  String get commonConfirm => 'Confirm';

  @override
  String get commonContinue => 'Continue';

  @override
  String get commonDone => 'Done';

  @override
  String get commonNext => 'Next';

  @override
  String get commonPrevious => 'Previous';

  @override
  String get commonRetry => 'Retry';

  @override
  String get commonSave => 'Save';

  @override
  String get commonStart => 'Start';

  @override
  String get commonSelect => 'Select';

  @override
  String get commonSelected => 'Selected';

  @override
  String get commonLocked => 'Locked';

  @override
  String get commonLoading => 'Loading…';

  @override
  String get commonOn => 'On';

  @override
  String get commonOff => 'Off';

  @override
  String get commonReset => 'Reset';

  @override
  String get commonApply => 'Apply';

  @override
  String get commonResume => 'Resume';

  @override
  String get commonNewRun => 'New Run';

  @override
  String get commonAbandon => 'Abandon';

  @override
  String get commonArchive => 'Archive';

  @override
  String get commonBacklog => 'Backlog';

  @override
  String get commonSkip => 'Skip';

  @override
  String get commonDetails => 'Details';

  @override
  String get commonUnknown => 'Unknown';

  @override
  String get setupTitle => 'Match Settings';

  @override
  String get setupChooseMode => 'Choose Your Mode';

  @override
  String get setupChooseCountry => 'Choose Your Country';

  @override
  String get setupChooseBattlefield => 'Choose Battlefield';

  @override
  String get setupStartingGold => 'Starting Gold';

  @override
  String get setupMerchantPayout => 'Merchant Payout';

  @override
  String get setupMerchantSpeed => 'Merchant Speed';

  @override
  String get setupReducedEffects => 'Reduced Effects';

  @override
  String get setupConfirmMatch => 'Confirm Match';

  @override
  String get setupBeginBattle => 'Begin Battle';

  @override
  String get sideWhite => 'White';

  @override
  String get sideBlack => 'Black';

  @override
  String get sideWhiteCourt => 'White Court';

  @override
  String get sideBlackCourt => 'Black Court';

  @override
  String get pieceKing => 'King';

  @override
  String get pieceQueen => 'Queen';

  @override
  String get pieceRook => 'Rook';

  @override
  String get pieceBishop => 'Bishop';

  @override
  String get pieceKnight => 'Knight';

  @override
  String get piecePawn => 'Pawn';

  @override
  String get countryAshenCourt => 'Ashen Court';

  @override
  String get countryAshenShort => 'Ashen';

  @override
  String get countryAshenFantasy =>
      'A passive-free court whose identity belongs only to Living Campaign.';

  @override
  String get countryMercantileLeague => 'Mercantile League';

  @override
  String get countryMercantileShort => 'Mercantile';

  @override
  String get countryMercantileFantasy =>
      'Rich traders with flexible loyalty and refunds after bad contracts.';

  @override
  String get countryIronDuchy => 'Iron Duchy';

  @override
  String get countryIronShort => 'Iron';

  @override
  String get countryIronFantasy =>
      'Low-income fortress state with stubborn soldiers and hard-to-buy walls.';

  @override
  String get countryHorseKingdom => 'Horse Kingdom';

  @override
  String get countryHorseShort => 'Horse';

  @override
  String get countryHorseFantasy =>
      'Cavalry nobility that turns knight contracts into political currency.';

  @override
  String get countrySpyCourt => 'Spy Court';

  @override
  String get countrySpyShort => 'Spy';

  @override
  String get countrySpyFantasy =>
      'Information warfare, loyalty intelligence, and quiet income disruption.';

  @override
  String get countryCorsairFreeholds => 'Corsair Freeholds';

  @override
  String get countryCorsairShort => 'Corsair';

  @override
  String get countryCorsairFantasy =>
      'Sea-raider city states that turn every battlefield capture into stolen treasury.';

  @override
  String get countrySunlitSynod => 'Sunlit Synod';

  @override
  String get countrySunlitShort => 'Sunlit';

  @override
  String get countrySunlitFantasy =>
      'A radiant bishop-led court that exposes enemy loyalty and rises or falls with its clergy.';

  @override
  String get countryFutureRealm => 'Future Realm';

  @override
  String countryLoyaltyStartsAt(String range) {
    return 'Starts at $range';
  }

  @override
  String get battlefieldClassicCourt => 'Classic Court';

  @override
  String get battlefieldClassicShort =>
      'Pure Crazy Chess with no battlefield effects.';

  @override
  String get battlefieldClassicLong =>
      'The familiar court. Only chess, merchants, contracts, and loyalty shape the match.';

  @override
  String get battlefieldVerdantDominion => 'Verdant Pastures';

  @override
  String get battlefieldVerdantShort => 'Knight shrines reshape every army.';

  @override
  String get battlefieldVerdantLong =>
      'Ancient riding stones transform any non-king piece that holds them into a knight.';

  @override
  String get battlefieldRuinedThrone => 'Ruined Causeway';

  @override
  String get battlefieldRuinedShort =>
      'Visible hazards and dangerous unknowns.';

  @override
  String get battlefieldRuinedLong =>
      'Open traps are readable threats. Mystery tiles conceal an even chance of treasure or destruction.';

  @override
  String get battlefieldGildedExchange => 'Gilded Bazaar';

  @override
  String get battlefieldGildedShort => 'Win gold and court-changing jewels.';

  @override
  String get battlefieldGildedLong =>
      'Treasure chests swell a court treasury while Diamond Rings empower the next rolled offer to an enemy queen.';

  @override
  String get battlefieldChaosCrucible => 'Chaos Crucible';

  @override
  String get battlefieldChaosShort => 'Every special tile can enter the fray.';

  @override
  String get battlefieldChaosLong =>
      'The Crucible begins dormant, then tears open every third completed action. Each mirrored eruption draws one seeded-random effect from the full battlefield arsenal.';

  @override
  String get battlefieldNoSpecialTiles => 'No special tiles spawn.';

  @override
  String get battlefieldOpeningPair => 'opening pair · ';

  @override
  String battlefieldEveryActions(int count) {
    return 'every $count completed actions';
  }

  @override
  String battlefieldEveryActionRange(int min, int max) {
    return 'every $min–$max completed actions';
  }

  @override
  String get battlefieldSeededRandomEffects => 'seeded-random effects';

  @override
  String get battlefieldSeededEffectOrder => 'seeded effect order';

  @override
  String battlefieldSpawnLaw(String opening, String delay, String selection) {
    return 'Mirrored empty-square pairs · $opening$delay · $selection · one-shot effects';
  }

  @override
  String get tileKnightShrine => 'Knight Shrine';

  @override
  String get tileTreasureChest => 'Treasure Chest';

  @override
  String get tileDiamondRing => 'Diamond Ring';

  @override
  String get tilePortal => 'Portal';

  @override
  String get tileTrap => 'Trap';

  @override
  String get tileBoost => 'Boost';

  @override
  String get tileSwap => 'Swap';

  @override
  String get tileMystery => 'Mystery';

  @override
  String get gameYourTurn => 'Your Turn';

  @override
  String get gameOpponentTurn => 'Opponent Turn';

  @override
  String get gameWhiteToMove => 'White to move';

  @override
  String get gameBlackToMove => 'Black to move';

  @override
  String get gameCheck => 'Check';

  @override
  String get gameCheckmate => 'Checkmate';

  @override
  String get gameStalemate => 'Stalemate';

  @override
  String get gameKingTrapfall => 'King Trapfall';

  @override
  String get gameVictory => 'Victory';

  @override
  String get gameDefeat => 'Defeat';

  @override
  String get gameDraw => 'Draw';

  @override
  String get gameOver => 'Game Over';

  @override
  String get gamePlayAgain => 'Play Again';

  @override
  String get gameBackToLobby => 'Back to Lobby';

  @override
  String get gameLobby => 'Lobby';

  @override
  String get gameEventLog => 'Event Log';

  @override
  String get gameMoveHistory => 'Move History';

  @override
  String get gameOffer => 'Make Offer';

  @override
  String get gameRedeploy => 'Redeploy';

  @override
  String get gameConfirmRedeploy => 'Confirm Redeploy';

  @override
  String get gameGold => 'Gold';

  @override
  String get gameLoyalty => 'Loyalty';

  @override
  String get gameFamiliarity => 'Familiarity';

  @override
  String get gameMerchant => 'Merchant';

  @override
  String get storyTitle => 'Story Campaign';

  @override
  String get storyObjective => 'Objective';

  @override
  String get storyKingRowan => 'King Rowan';

  @override
  String storyReachSquareWithKing(String square, String king) {
    return 'Reach $square with $king';
  }

  @override
  String get storyCheckmateEnemyKing => 'Checkmate the enemy King';

  @override
  String get storyOrSeparator => '  •  OR  •  ';

  @override
  String get storyVictoryConditions => 'Victory Conditions';

  @override
  String get storyMissionComplete => 'Mission Complete';

  @override
  String get storyMissionFailed => 'Mission Failed';

  @override
  String get storyBeginMission => 'Begin Mission';

  @override
  String get storyContinueJourney => 'Continue Journey';

  @override
  String get storyCampaignMap => 'Campaign Map';

  @override
  String get lastPieceTitle => 'Last Piece Standing';

  @override
  String get lastPieceStartRun => 'Start Run';

  @override
  String get lastPieceRetire => 'Retire Run';

  @override
  String get lastPieceScore => 'Score';

  @override
  String get lastPieceBestScore => 'Best Score';

  @override
  String get lastPieceTransformation => 'Transformation';

  @override
  String get lastPieceRunEnded => 'Run Ended';

  @override
  String get livingTitle => 'Living Campaign';

  @override
  String get livingNewChronicle => 'New Chronicle';

  @override
  String get livingContinueChronicle => 'Continue Chronicle';

  @override
  String get livingUnfinishedTales => 'Unfinished Tales';

  @override
  String get livingChronicleArchive => 'Chronicle Archive';

  @override
  String get livingGenerationInProgress => 'The Chronicler is writing…';

  @override
  String get livingRecallWords => 'Recall Their Words';

  @override
  String get livingRecallFinalMoment => 'Recall the Final Moment';

  @override
  String get livingContentLanguage => 'Story language';

  @override
  String get livingContentLanguageEnglish => 'English';

  @override
  String get livingContentLanguageChinese => 'Simplified Chinese';

  @override
  String get errorGeneric => 'Something went wrong.';

  @override
  String get errorTryAgain => 'Please try again.';

  @override
  String get semanticCrazyChessLogo => 'Crazy Chess logo';

  @override
  String get semanticSettings => 'Open settings';

  @override
  String get semanticBack => 'Go back';

  @override
  String get semanticClose => 'Close';

  @override
  String semanticBoardSquare(String piece, String square) {
    return '$piece on $square';
  }

  @override
  String goldAmount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count gold',
      one: '1 gold',
      zero: 'No gold',
    );
    return '$_temp0';
  }

  @override
  String turnNumber(int turn) {
    return 'Turn $turn';
  }

  @override
  String scoreAmount(int score) {
    return 'Score $score';
  }

  @override
  String messageMoved(String side, String piece, String from, String to) {
    return '$side moved $piece from $from to $to.';
  }

  @override
  String messageCaptured(String side, String piece, String square) {
    return '$side captured $piece on $square.';
  }

  @override
  String get messageAiFailure =>
      'The AI court could not complete its turn. Try again or return to the lobby.';
}
