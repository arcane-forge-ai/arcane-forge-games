// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get appTitle => 'Crazy Chess';

  @override
  String get brandName => 'Crazy Chess';

  @override
  String get languageSystem => '跟随系统';

  @override
  String get languageEnglish => 'English';

  @override
  String get languageSimplifiedChinese => '简体中文';

  @override
  String get languageSettingTitle => '语言';

  @override
  String get languageSettingDescription => '选择菜单与新战役使用的语言。';

  @override
  String get languageChineseReadinessWarningTitle => '简体中文尚未完成';

  @override
  String get languageChineseReadinessWarningBody =>
      '简体中文版本仍在完善中。部分界面可能出现画面品质下降、未翻译文字或中英文混排。你可以随时切回 English。';

  @override
  String get languageChineseReadinessWarningConfirm => '仍然使用简体中文';

  @override
  String get languageLivingPinnedNotice => '已有演化战役会保留创建时的剧情语言。';

  @override
  String get settingsTitle => '设置';

  @override
  String get settingsCategoryDisplay => '显示';

  @override
  String get settingsCategoryAudio => '音频';

  @override
  String get settingsCategoryControls => '控制';

  @override
  String get settingsCategoryAccessibility => '无障碍';

  @override
  String get settingsCategoryLanguage => '语言';

  @override
  String get settingsCategoryGameplay => '游戏';

  @override
  String get settingsCategoryAbout => '关于';

  @override
  String get settingsCategoryLivingAi => '演化 AI';

  @override
  String get settingsCategoryPlaytestData => '试玩数据';

  @override
  String get settingsCategoryOpenSourceLicenses => '开源许可';

  @override
  String get settingsDeviceOptionsDescription => '当前设备的显示与无障碍选项。';

  @override
  String get playtestDataTitle => '导出试玩数据';

  @override
  String get playtestDataDescription => '生成一个本地 ZIP，试玩结束后可发送给 Crazy Chess 团队。';

  @override
  String get playtestDataIncludedTitle => '包含内容';

  @override
  String get playtestDataIncludedBody => '演化战役与生成记录、章节用时指标，以及近期且有容量限制的诊断日志。';

  @override
  String get playtestDataPrivacyTitle => '分享前须知';

  @override
  String get playtestDataPrivacyBody =>
      'ZIP 会包含战役剧本，但不会包含肖像、已保存设置或 API 凭据。游戏不会自动上传任何内容。';

  @override
  String get playtestDataDestinationTitle => '保存位置';

  @override
  String get playtestDataDestinationBody => '桌面打包版本会将带时间戳的 ZIP 保存到“下载”文件夹。';

  @override
  String get playtestDataExportButton => '导出试玩 ZIP';

  @override
  String get playtestDataExporting => '正在导出……';

  @override
  String get playtestDataFailed => '无法创建试玩 ZIP；本地战役数据没有被更改。';

  @override
  String playtestDataExported(int runCount, int metricsCount, int logCount) {
    return '已导出 $runCount 个战役、$metricsCount 个用时文件和 $logCount 个诊断日志。';
  }

  @override
  String get loadoutCategoryBoard => '棋盘';

  @override
  String get loadoutCategoryToken => '棋子外观';

  @override
  String get loadoutCategoryBanner => '旗帜';

  @override
  String get loadoutCategoryContractSeal => '契约印章';

  @override
  String get loadoutCategoryResultVfx => '结算特效';

  @override
  String get loadoutCategoryMerchant => '商人';

  @override
  String get loadoutTitle => '装饰装配';

  @override
  String get loadoutSlots => '装配栏位';

  @override
  String get loadoutPreviewDescription => '外观保存与解锁属于后续系统；此页面用于预览完整产品界面。';

  @override
  String get commonCategories => '分类';

  @override
  String get loadoutCategoryPieces => '棋子';

  @override
  String get loadoutCategoryProfile => '档案';

  @override
  String get navHome => '主页';

  @override
  String get navLoadout => '装配';

  @override
  String get navPlay => '对战';

  @override
  String get navCountries => '阵营';

  @override
  String get navSettings => '设置';

  @override
  String get navRoster => '棋子阵容';

  @override
  String get navRecords => '战绩';

  @override
  String get navRules => '规则';

  @override
  String get modeLocalDuel => '本地对战';

  @override
  String get modeLocalDuelSubtitle => '两名玩家在同一设备上对战';

  @override
  String get modeAiDuel => '人机对战';

  @override
  String get modeAiDuelSubtitle => '挑战机械棋庭';

  @override
  String get modeStoryCampaign => '剧情战役';

  @override
  String get modeStoryCampaignSubtitle => '七关手工编排的故事';

  @override
  String get modeLastPiece => '残子求生';

  @override
  String get modeLastPieceSubtitle => '操控单枚棋子展开无尽求生';

  @override
  String get modeLivingCampaign => '演化战役';

  @override
  String get modeLivingCampaignSubtitle => '由每场战斗塑造的演化史诗';

  @override
  String get commonBack => '返回';

  @override
  String get commonCancel => '取消';

  @override
  String get commonClose => '关闭';

  @override
  String get commonConfirm => '确认';

  @override
  String get commonContinue => '继续';

  @override
  String get commonDone => '完成';

  @override
  String get commonNext => '下一步';

  @override
  String get commonPrevious => '上一步';

  @override
  String get commonRetry => '重试';

  @override
  String get commonSave => '保存';

  @override
  String get commonStart => '开始';

  @override
  String get commonSelect => '选择';

  @override
  String get commonSelected => '已选择';

  @override
  String get commonLocked => '未解锁';

  @override
  String get commonLoading => '载入中……';

  @override
  String get commonOn => '开启';

  @override
  String get commonOff => '关闭';

  @override
  String get commonReset => '重置';

  @override
  String get commonApply => '应用';

  @override
  String get commonResume => '继续';

  @override
  String get commonNewRun => '新建战役';

  @override
  String get commonAbandon => '放弃';

  @override
  String get commonArchive => '档案';

  @override
  String get commonBacklog => '回顾';

  @override
  String get commonSkip => '跳过';

  @override
  String get commonDetails => '详情';

  @override
  String get commonUnknown => '未知';

  @override
  String get setupTitle => '对战设置';

  @override
  String get setupChooseMode => '选择模式';

  @override
  String get setupChooseCountry => '选择阵营';

  @override
  String get setupChooseBattlefield => '选择战场';

  @override
  String get setupStartingGold => '初始金币';

  @override
  String get setupMerchantPayout => '商人收益';

  @override
  String get setupMerchantSpeed => '商人速度';

  @override
  String get setupReducedEffects => '减少特效';

  @override
  String get setupConfirmMatch => '确认对战';

  @override
  String get setupBeginBattle => '开始战斗';

  @override
  String get sideWhite => '白方';

  @override
  String get sideBlack => '黑方';

  @override
  String get sideWhiteCourt => '白方棋庭';

  @override
  String get sideBlackCourt => '黑方棋庭';

  @override
  String get pieceKing => '王';

  @override
  String get pieceQueen => '后';

  @override
  String get pieceRook => '车';

  @override
  String get pieceBishop => '象';

  @override
  String get pieceKnight => '马';

  @override
  String get piecePawn => '兵';

  @override
  String get countryAshenCourt => '灰烬王庭';

  @override
  String get countryAshenShort => '灰烬';

  @override
  String get countryAshenFantasy => '不依赖被动能力的王庭，其身份仅属于演化战役。';

  @override
  String get countryMercantileLeague => '商贸联盟';

  @override
  String get countryMercantileShort => '商贸';

  @override
  String get countryMercantileFantasy => '富裕而灵活的商人联盟，失败契约可获得部分退款。';

  @override
  String get countryIronDuchy => '铁壁公国';

  @override
  String get countryIronShort => '铁壁';

  @override
  String get countryIronFantasy => '收入有限的要塞之国，军纪森严，城墙与士兵都难以收买。';

  @override
  String get countryHorseKingdom => '骏马王国';

  @override
  String get countryHorseShort => '骏马';

  @override
  String get countryHorseFantasy => '崇尚骑士的贵族王国，将马的契约化作政治筹码。';

  @override
  String get countrySpyCourt => '谍影王庭';

  @override
  String get countrySpyShort => '谍影';

  @override
  String get countrySpyFantasy => '擅长情报战、忠诚洞察与暗中干扰收入。';

  @override
  String get countryCorsairFreeholds => '海盗自由邦';

  @override
  String get countryCorsairShort => '海盗';

  @override
  String get countryCorsairFantasy => '由海上劫掠者组成的城邦，每次吃子都能夺取敌方金库。';

  @override
  String get countrySunlitSynod => '曜日教廷';

  @override
  String get countrySunlitShort => '曜日';

  @override
  String get countrySunlitFantasy => '由象统领的辉光教廷，能揭露敌方忠诚，并随神职棋子的存亡兴衰。';

  @override
  String get countryFutureRealm => '未来阵营';

  @override
  String countryLoyaltyStartsAt(String range) {
    return '初始为 $range';
  }

  @override
  String get battlefieldClassicCourt => '经典棋庭';

  @override
  String get battlefieldClassicShort => '没有战场效果的纯粹 Crazy Chess 对局。';

  @override
  String get battlefieldClassicLong => '熟悉的棋庭。只有棋局、商人、契约与忠诚度影响胜负。';

  @override
  String get battlefieldVerdantDominion => '苍翠领地';

  @override
  String get battlefieldVerdantShort => '骑士圣坛重塑双方军阵。';

  @override
  String get battlefieldVerdantLong => '古老的骑乘石会将占据它的任何非王棋子转化为马。';

  @override
  String get battlefieldRuinedThrone => '王座废墟';

  @override
  String get battlefieldRuinedShort => '明示的危险与致命的未知。';

  @override
  String get battlefieldRuinedLong => '可见陷阱是明确威胁；谜团格则各有一半概率藏着宝藏或毁灭。';

  @override
  String get battlefieldGildedExchange => '镀金交易所';

  @override
  String get battlefieldGildedShort => '赢取金币与足以改变棋庭的珠宝。';

  @override
  String get battlefieldGildedLong => '宝箱充盈棋庭金库；钻石戒指可强化下一次针对敌方后的报价。';

  @override
  String get battlefieldChaosCrucible => '混沌熔炉';

  @override
  String get battlefieldChaosShort => '所有特殊格都可能加入战局。';

  @override
  String get battlefieldChaosLong =>
      '熔炉初始沉寂，此后每完成三个行动便撕裂棋盘。每次镜像喷发都会从全部战场效果中按种子随机抽取一种。';

  @override
  String get battlefieldNoSpecialTiles => '不会生成特殊格。';

  @override
  String get battlefieldOpeningPair => '开局生成一对 · ';

  @override
  String battlefieldEveryActions(int count) {
    return '每完成 $count 个行动';
  }

  @override
  String battlefieldEveryActionRange(int min, int max) {
    return '每完成 $min–$max 个行动';
  }

  @override
  String get battlefieldSeededRandomEffects => '按种子随机效果';

  @override
  String get battlefieldSeededEffectOrder => '按种子固定效果顺序';

  @override
  String battlefieldSpawnLaw(String opening, String delay, String selection) {
    return '空格镜像成对生成 · $opening$delay · $selection · 一次性效果';
  }

  @override
  String get tileKnightShrine => '骑士圣坛';

  @override
  String get tileTreasureChest => '宝箱';

  @override
  String get tileDiamondRing => '钻石戒指';

  @override
  String get tilePortal => '传送门';

  @override
  String get tileTrap => '陷阱';

  @override
  String get tileBoost => '增益';

  @override
  String get tileSwap => '换位';

  @override
  String get tileMystery => '谜团';

  @override
  String get gameYourTurn => '你的回合';

  @override
  String get gameOpponentTurn => '对手回合';

  @override
  String get gameWhiteToMove => '白方行动';

  @override
  String get gameBlackToMove => '黑方行动';

  @override
  String get gameCheck => '将军';

  @override
  String get gameCheckmate => '将杀';

  @override
  String get gameStalemate => '逼和';

  @override
  String get gameKingTrapfall => '王陷落';

  @override
  String get gameVictory => '胜利';

  @override
  String get gameDefeat => '失败';

  @override
  String get gameDraw => '和棋';

  @override
  String get gameOver => '对局结束';

  @override
  String get gamePlayAgain => '再来一局';

  @override
  String get gameBackToLobby => '返回大厅';

  @override
  String get gameLobby => '大厅';

  @override
  String get gameEventLog => '事件记录';

  @override
  String get gameMoveHistory => '行棋记录';

  @override
  String get gameOffer => '提出报价';

  @override
  String get gameRedeploy => '重新部署';

  @override
  String get gameConfirmRedeploy => '确认部署';

  @override
  String get gameGold => '金币';

  @override
  String get gameLoyalty => '忠诚度';

  @override
  String get gameFamiliarity => '熟练度';

  @override
  String get gameMerchant => '商人';

  @override
  String get storyTitle => '剧情战役';

  @override
  String get storyObjective => '目标';

  @override
  String get storyKingRowan => '罗文王';

  @override
  String storyReachSquareWithKing(String square, String king) {
    return '让$king抵达 $square';
  }

  @override
  String get storyCheckmateEnemyKing => '将杀敌方王';

  @override
  String get storyOrSeparator => '  •  或  •  ';

  @override
  String get storyVictoryConditions => '胜利条件';

  @override
  String get storyMissionComplete => '任务完成';

  @override
  String get storyMissionFailed => '任务失败';

  @override
  String get storyBeginMission => '开始任务';

  @override
  String get storyContinueJourney => '继续旅程';

  @override
  String get storyCampaignMap => '战役地图';

  @override
  String get lastPieceTitle => '残子求生';

  @override
  String get lastPieceStartRun => '开始求生';

  @override
  String get lastPieceRetire => '结束本局';

  @override
  String get lastPieceScore => '得分';

  @override
  String get lastPieceBestScore => '最高得分';

  @override
  String get lastPieceTransformation => '棋子变形';

  @override
  String get lastPieceRunEnded => '求生结束';

  @override
  String get livingTitle => '演化战役';

  @override
  String get livingNewChronicle => '开启新史诗';

  @override
  String get livingContinueChronicle => '续写史诗';

  @override
  String get livingUnfinishedTales => '未竟传说';

  @override
  String get livingChronicleArchive => '史诗档案';

  @override
  String get livingGenerationInProgress => '史官正在书写……';

  @override
  String get livingRecallWords => '重寻往日话语';

  @override
  String get livingRecallFinalMoment => '重现终局一刻';

  @override
  String get livingContentLanguage => '剧情语言';

  @override
  String get livingContentLanguageEnglish => 'English';

  @override
  String get livingContentLanguageChinese => '简体中文';

  @override
  String get errorGeneric => '出现了问题。';

  @override
  String get errorTryAgain => '请重试。';

  @override
  String get semanticCrazyChessLogo => 'Crazy Chess 标志';

  @override
  String get semanticSettings => '打开设置';

  @override
  String get semanticBack => '返回';

  @override
  String get semanticClose => '关闭';

  @override
  String semanticBoardSquare(String piece, String square) {
    return '$piece位于$square';
  }

  @override
  String goldAmount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 枚金币',
      zero: '没有金币',
    );
    return '$_temp0';
  }

  @override
  String turnNumber(int turn) {
    return '第 $turn 回合';
  }

  @override
  String scoreAmount(int score) {
    return '得分 $score';
  }

  @override
  String messageMoved(String side, String piece, String from, String to) {
    return '$side$piece从 $from 移动至 $to。';
  }

  @override
  String messageCaptured(String side, String piece, String square) {
    return '$side在 $square 吃掉了$piece。';
  }

  @override
  String get messageAiFailure => '电脑未能完成回合。请重试或返回大厅。';
}

/// The translations for Chinese, using the Han script (`zh_Hans`).
class AppLocalizationsZhHans extends AppLocalizationsZh {
  AppLocalizationsZhHans() : super('zh_Hans');

  @override
  String get appTitle => 'Crazy Chess';

  @override
  String get brandName => 'Crazy Chess';

  @override
  String get languageSystem => '跟随系统';

  @override
  String get languageEnglish => 'English';

  @override
  String get languageSimplifiedChinese => '简体中文';

  @override
  String get languageSettingTitle => '语言';

  @override
  String get languageSettingDescription => '选择菜单与新战役使用的语言。';

  @override
  String get languageChineseReadinessWarningTitle => '简体中文尚未完成';

  @override
  String get languageChineseReadinessWarningBody =>
      '简体中文版本仍在完善中。部分界面可能出现画面品质下降、未翻译文字或中英文混排。你可以随时切回 English。';

  @override
  String get languageChineseReadinessWarningConfirm => '仍然使用简体中文';

  @override
  String get languageLivingPinnedNotice => '已有演化战役会保留创建时的剧情语言。';

  @override
  String get settingsTitle => '设置';

  @override
  String get settingsCategoryDisplay => '显示';

  @override
  String get settingsCategoryAudio => '音频';

  @override
  String get settingsCategoryControls => '控制';

  @override
  String get settingsCategoryAccessibility => '无障碍';

  @override
  String get settingsCategoryLanguage => '语言';

  @override
  String get settingsCategoryGameplay => '游戏';

  @override
  String get settingsCategoryAbout => '关于';

  @override
  String get settingsCategoryLivingAi => '演化 AI';

  @override
  String get settingsCategoryPlaytestData => '试玩数据';

  @override
  String get settingsCategoryOpenSourceLicenses => '开源许可';

  @override
  String get settingsDeviceOptionsDescription => '当前设备的显示与无障碍选项。';

  @override
  String get playtestDataTitle => '导出试玩数据';

  @override
  String get playtestDataDescription => '生成一个本地 ZIP，试玩结束后可发送给 Crazy Chess 团队。';

  @override
  String get playtestDataIncludedTitle => '包含内容';

  @override
  String get playtestDataIncludedBody => '演化战役与生成记录、章节用时指标，以及近期且有容量限制的诊断日志。';

  @override
  String get playtestDataPrivacyTitle => '分享前须知';

  @override
  String get playtestDataPrivacyBody =>
      'ZIP 会包含战役剧本，但不会包含肖像、已保存设置或 API 凭据。游戏不会自动上传任何内容。';

  @override
  String get playtestDataDestinationTitle => '保存位置';

  @override
  String get playtestDataDestinationBody => '桌面打包版本会将带时间戳的 ZIP 保存到“下载”文件夹。';

  @override
  String get playtestDataExportButton => '导出试玩 ZIP';

  @override
  String get playtestDataExporting => '正在导出……';

  @override
  String get playtestDataFailed => '无法创建试玩 ZIP；本地战役数据没有被更改。';

  @override
  String playtestDataExported(int runCount, int metricsCount, int logCount) {
    return '已导出 $runCount 个战役、$metricsCount 个用时文件和 $logCount 个诊断日志。';
  }

  @override
  String get loadoutCategoryBoard => '棋盘';

  @override
  String get loadoutCategoryToken => '棋子外观';

  @override
  String get loadoutCategoryBanner => '旗帜';

  @override
  String get loadoutCategoryContractSeal => '契约印章';

  @override
  String get loadoutCategoryResultVfx => '结算特效';

  @override
  String get loadoutCategoryMerchant => '商人';

  @override
  String get loadoutTitle => '装饰装配';

  @override
  String get loadoutSlots => '装配栏位';

  @override
  String get loadoutPreviewDescription => '外观保存与解锁属于后续系统；此页面用于预览完整产品界面。';

  @override
  String get commonCategories => '分类';

  @override
  String get loadoutCategoryPieces => '棋子';

  @override
  String get loadoutCategoryProfile => '档案';

  @override
  String get navHome => '主页';

  @override
  String get navLoadout => '装配';

  @override
  String get navPlay => '对战';

  @override
  String get navCountries => '阵营';

  @override
  String get navSettings => '设置';

  @override
  String get navRoster => '棋子阵容';

  @override
  String get navRecords => '战绩';

  @override
  String get navRules => '规则';

  @override
  String get modeLocalDuel => '本地对战';

  @override
  String get modeLocalDuelSubtitle => '两名玩家在同一设备上对战';

  @override
  String get modeAiDuel => '人机对战';

  @override
  String get modeAiDuelSubtitle => '挑战机械棋庭';

  @override
  String get modeStoryCampaign => '剧情战役';

  @override
  String get modeStoryCampaignSubtitle => '七关手工编排的故事';

  @override
  String get modeLastPiece => '残子求生';

  @override
  String get modeLastPieceSubtitle => '操控单枚棋子展开无尽求生';

  @override
  String get modeLivingCampaign => '演化战役';

  @override
  String get modeLivingCampaignSubtitle => '由每场战斗塑造的演化史诗';

  @override
  String get commonBack => '返回';

  @override
  String get commonCancel => '取消';

  @override
  String get commonClose => '关闭';

  @override
  String get commonConfirm => '确认';

  @override
  String get commonContinue => '继续';

  @override
  String get commonDone => '完成';

  @override
  String get commonNext => '下一步';

  @override
  String get commonPrevious => '上一步';

  @override
  String get commonRetry => '重试';

  @override
  String get commonSave => '保存';

  @override
  String get commonStart => '开始';

  @override
  String get commonSelect => '选择';

  @override
  String get commonSelected => '已选择';

  @override
  String get commonLocked => '未解锁';

  @override
  String get commonLoading => '载入中……';

  @override
  String get commonOn => '开启';

  @override
  String get commonOff => '关闭';

  @override
  String get commonReset => '重置';

  @override
  String get commonApply => '应用';

  @override
  String get commonResume => '继续';

  @override
  String get commonNewRun => '新建战役';

  @override
  String get commonAbandon => '放弃';

  @override
  String get commonArchive => '档案';

  @override
  String get commonBacklog => '回顾';

  @override
  String get commonSkip => '跳过';

  @override
  String get commonDetails => '详情';

  @override
  String get commonUnknown => '未知';

  @override
  String get setupTitle => '对战设置';

  @override
  String get setupChooseMode => '选择模式';

  @override
  String get setupChooseCountry => '选择阵营';

  @override
  String get setupChooseBattlefield => '选择战场';

  @override
  String get setupStartingGold => '初始金币';

  @override
  String get setupMerchantPayout => '商人收益';

  @override
  String get setupMerchantSpeed => '商人速度';

  @override
  String get setupReducedEffects => '减少特效';

  @override
  String get setupConfirmMatch => '确认对战';

  @override
  String get setupBeginBattle => '开始战斗';

  @override
  String get sideWhite => '白方';

  @override
  String get sideBlack => '黑方';

  @override
  String get sideWhiteCourt => '白方棋庭';

  @override
  String get sideBlackCourt => '黑方棋庭';

  @override
  String get pieceKing => '王';

  @override
  String get pieceQueen => '后';

  @override
  String get pieceRook => '车';

  @override
  String get pieceBishop => '象';

  @override
  String get pieceKnight => '马';

  @override
  String get piecePawn => '兵';

  @override
  String get countryAshenCourt => '灰烬王庭';

  @override
  String get countryAshenShort => '灰烬';

  @override
  String get countryAshenFantasy => '不依赖被动能力的王庭，其身份仅属于演化战役。';

  @override
  String get countryMercantileLeague => '商贸联盟';

  @override
  String get countryMercantileShort => '商贸';

  @override
  String get countryMercantileFantasy => '富裕而灵活的商人联盟，失败契约可获得部分退款。';

  @override
  String get countryIronDuchy => '铁壁公国';

  @override
  String get countryIronShort => '铁壁';

  @override
  String get countryIronFantasy => '收入有限的要塞之国，军纪森严，城墙与士兵都难以收买。';

  @override
  String get countryHorseKingdom => '骏马王国';

  @override
  String get countryHorseShort => '骏马';

  @override
  String get countryHorseFantasy => '崇尚骑士的贵族王国，将马的契约化作政治筹码。';

  @override
  String get countrySpyCourt => '谍影王庭';

  @override
  String get countrySpyShort => '谍影';

  @override
  String get countrySpyFantasy => '擅长情报战、忠诚洞察与暗中干扰收入。';

  @override
  String get countryCorsairFreeholds => '海盗自由邦';

  @override
  String get countryCorsairShort => '海盗';

  @override
  String get countryCorsairFantasy => '由海上劫掠者组成的城邦，每次吃子都能夺取敌方金库。';

  @override
  String get countrySunlitSynod => '曜日教廷';

  @override
  String get countrySunlitShort => '曜日';

  @override
  String get countrySunlitFantasy => '由象统领的辉光教廷，能揭露敌方忠诚，并随神职棋子的存亡兴衰。';

  @override
  String get countryFutureRealm => '未来阵营';

  @override
  String countryLoyaltyStartsAt(String range) {
    return '初始为 $range';
  }

  @override
  String get battlefieldClassicCourt => '经典棋庭';

  @override
  String get battlefieldClassicShort => '没有战场效果的纯粹 Crazy Chess 对局。';

  @override
  String get battlefieldClassicLong => '熟悉的棋庭。只有棋局、商人、契约与忠诚度影响胜负。';

  @override
  String get battlefieldVerdantDominion => '苍翠领地';

  @override
  String get battlefieldVerdantShort => '骑士圣坛重塑双方军阵。';

  @override
  String get battlefieldVerdantLong => '古老的骑乘石会将占据它的任何非王棋子转化为马。';

  @override
  String get battlefieldRuinedThrone => '王座废墟';

  @override
  String get battlefieldRuinedShort => '明示的危险与致命的未知。';

  @override
  String get battlefieldRuinedLong => '可见陷阱是明确威胁；谜团格则各有一半概率藏着宝藏或毁灭。';

  @override
  String get battlefieldGildedExchange => '镀金交易所';

  @override
  String get battlefieldGildedShort => '赢取金币与足以改变棋庭的珠宝。';

  @override
  String get battlefieldGildedLong => '宝箱充盈棋庭金库；钻石戒指可强化下一次针对敌方后的报价。';

  @override
  String get battlefieldChaosCrucible => '混沌熔炉';

  @override
  String get battlefieldChaosShort => '所有特殊格都可能加入战局。';

  @override
  String get battlefieldChaosLong =>
      '熔炉初始沉寂，此后每完成三个行动便撕裂棋盘。每次镜像喷发都会从全部战场效果中按种子随机抽取一种。';

  @override
  String get battlefieldNoSpecialTiles => '不会生成特殊格。';

  @override
  String get battlefieldOpeningPair => '开局生成一对 · ';

  @override
  String battlefieldEveryActions(int count) {
    return '每完成 $count 个行动';
  }

  @override
  String battlefieldEveryActionRange(int min, int max) {
    return '每完成 $min–$max 个行动';
  }

  @override
  String get battlefieldSeededRandomEffects => '按种子随机效果';

  @override
  String get battlefieldSeededEffectOrder => '按种子固定效果顺序';

  @override
  String battlefieldSpawnLaw(String opening, String delay, String selection) {
    return '空格镜像成对生成 · $opening$delay · $selection · 一次性效果';
  }

  @override
  String get tileKnightShrine => '骑士圣坛';

  @override
  String get tileTreasureChest => '宝箱';

  @override
  String get tileDiamondRing => '钻石戒指';

  @override
  String get tilePortal => '传送门';

  @override
  String get tileTrap => '陷阱';

  @override
  String get tileBoost => '增益';

  @override
  String get tileSwap => '换位';

  @override
  String get tileMystery => '谜团';

  @override
  String get gameYourTurn => '你的回合';

  @override
  String get gameOpponentTurn => '对手回合';

  @override
  String get gameWhiteToMove => '白方行动';

  @override
  String get gameBlackToMove => '黑方行动';

  @override
  String get gameCheck => '将军';

  @override
  String get gameCheckmate => '将杀';

  @override
  String get gameStalemate => '逼和';

  @override
  String get gameKingTrapfall => '王陷落';

  @override
  String get gameVictory => '胜利';

  @override
  String get gameDefeat => '失败';

  @override
  String get gameDraw => '和棋';

  @override
  String get gameOver => '对局结束';

  @override
  String get gamePlayAgain => '再来一局';

  @override
  String get gameBackToLobby => '返回大厅';

  @override
  String get gameLobby => '大厅';

  @override
  String get gameEventLog => '事件记录';

  @override
  String get gameMoveHistory => '行棋记录';

  @override
  String get gameOffer => '提出报价';

  @override
  String get gameRedeploy => '重新部署';

  @override
  String get gameConfirmRedeploy => '确认部署';

  @override
  String get gameGold => '金币';

  @override
  String get gameLoyalty => '忠诚度';

  @override
  String get gameFamiliarity => '熟练度';

  @override
  String get gameMerchant => '商人';

  @override
  String get storyTitle => '剧情战役';

  @override
  String get storyObjective => '目标';

  @override
  String get storyKingRowan => '罗文王';

  @override
  String storyReachSquareWithKing(String square, String king) {
    return '让$king抵达 $square';
  }

  @override
  String get storyCheckmateEnemyKing => '将杀敌方王';

  @override
  String get storyOrSeparator => '  •  或  •  ';

  @override
  String get storyVictoryConditions => '胜利条件';

  @override
  String get storyMissionComplete => '任务完成';

  @override
  String get storyMissionFailed => '任务失败';

  @override
  String get storyBeginMission => '开始任务';

  @override
  String get storyContinueJourney => '继续旅程';

  @override
  String get storyCampaignMap => '战役地图';

  @override
  String get lastPieceTitle => '残子求生';

  @override
  String get lastPieceStartRun => '开始求生';

  @override
  String get lastPieceRetire => '结束本局';

  @override
  String get lastPieceScore => '得分';

  @override
  String get lastPieceBestScore => '最高得分';

  @override
  String get lastPieceTransformation => '棋子变形';

  @override
  String get lastPieceRunEnded => '求生结束';

  @override
  String get livingTitle => '演化战役';

  @override
  String get livingNewChronicle => '开启新史诗';

  @override
  String get livingContinueChronicle => '续写史诗';

  @override
  String get livingUnfinishedTales => '未竟传说';

  @override
  String get livingChronicleArchive => '史诗档案';

  @override
  String get livingGenerationInProgress => '史官正在书写……';

  @override
  String get livingRecallWords => '重寻往日话语';

  @override
  String get livingRecallFinalMoment => '重现终局一刻';

  @override
  String get livingContentLanguage => '剧情语言';

  @override
  String get livingContentLanguageEnglish => 'English';

  @override
  String get livingContentLanguageChinese => '简体中文';

  @override
  String get errorGeneric => '出现了问题。';

  @override
  String get errorTryAgain => '请重试。';

  @override
  String get semanticCrazyChessLogo => 'Crazy Chess 标志';

  @override
  String get semanticSettings => '打开设置';

  @override
  String get semanticBack => '返回';

  @override
  String get semanticClose => '关闭';

  @override
  String semanticBoardSquare(String piece, String square) {
    return '$piece位于$square';
  }

  @override
  String goldAmount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count 枚金币',
      zero: '没有金币',
    );
    return '$_temp0';
  }

  @override
  String turnNumber(int turn) {
    return '第 $turn 回合';
  }

  @override
  String scoreAmount(int score) {
    return '得分 $score';
  }

  @override
  String messageMoved(String side, String piece, String from, String to) {
    return '$side$piece从 $from 移动至 $to。';
  }

  @override
  String messageCaptured(String side, String piece, String square) {
    return '$side在 $square 吃掉了$piece。';
  }

  @override
  String get messageAiFailure => '电脑未能完成回合。请重试或返回大厅。';
}
