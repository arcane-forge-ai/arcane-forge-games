import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_zh.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hans'),
    Locale('zh'),
  ];

  /// No description provided for @appTitle.
  ///
  /// In en, this message translates to:
  /// **'Crazy Chess'**
  String get appTitle;

  /// No description provided for @brandName.
  ///
  /// In en, this message translates to:
  /// **'Crazy Chess'**
  String get brandName;

  /// No description provided for @languageSystem.
  ///
  /// In en, this message translates to:
  /// **'Follow System'**
  String get languageSystem;

  /// No description provided for @languageEnglish.
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get languageEnglish;

  /// No description provided for @languageSimplifiedChinese.
  ///
  /// In en, this message translates to:
  /// **'Simplified Chinese'**
  String get languageSimplifiedChinese;

  /// No description provided for @languageSettingTitle.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get languageSettingTitle;

  /// No description provided for @languageSettingDescription.
  ///
  /// In en, this message translates to:
  /// **'Choose the language used by menus and new campaigns.'**
  String get languageSettingDescription;

  /// No description provided for @languageChineseReadinessWarningTitle.
  ///
  /// In en, this message translates to:
  /// **'Simplified Chinese is not ready yet'**
  String get languageChineseReadinessWarningTitle;

  /// No description provided for @languageChineseReadinessWarningBody.
  ///
  /// In en, this message translates to:
  /// **'The Simplified Chinese version is still in progress. Some screens may contain degraded artwork, untranslated text, or mixed-language labels. You can switch back to English at any time.'**
  String get languageChineseReadinessWarningBody;

  /// No description provided for @languageChineseReadinessWarningConfirm.
  ///
  /// In en, this message translates to:
  /// **'Use Simplified Chinese'**
  String get languageChineseReadinessWarningConfirm;

  /// No description provided for @languageLivingPinnedNotice.
  ///
  /// In en, this message translates to:
  /// **'Existing Living Campaign stories keep their original language.'**
  String get languageLivingPinnedNotice;

  /// No description provided for @settingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settingsTitle;

  /// No description provided for @settingsCategoryDisplay.
  ///
  /// In en, this message translates to:
  /// **'Display'**
  String get settingsCategoryDisplay;

  /// No description provided for @settingsCategoryAudio.
  ///
  /// In en, this message translates to:
  /// **'Audio'**
  String get settingsCategoryAudio;

  /// No description provided for @settingsCategoryControls.
  ///
  /// In en, this message translates to:
  /// **'Controls'**
  String get settingsCategoryControls;

  /// No description provided for @settingsCategoryAccessibility.
  ///
  /// In en, this message translates to:
  /// **'Accessibility'**
  String get settingsCategoryAccessibility;

  /// No description provided for @settingsCategoryLanguage.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get settingsCategoryLanguage;

  /// No description provided for @settingsCategoryGameplay.
  ///
  /// In en, this message translates to:
  /// **'Gameplay'**
  String get settingsCategoryGameplay;

  /// No description provided for @settingsCategoryAbout.
  ///
  /// In en, this message translates to:
  /// **'About'**
  String get settingsCategoryAbout;

  /// No description provided for @settingsCategoryLivingAi.
  ///
  /// In en, this message translates to:
  /// **'Living AI'**
  String get settingsCategoryLivingAi;

  /// No description provided for @settingsCategoryPlaytestData.
  ///
  /// In en, this message translates to:
  /// **'Playtest Data'**
  String get settingsCategoryPlaytestData;

  /// No description provided for @settingsCategoryOpenSourceLicenses.
  ///
  /// In en, this message translates to:
  /// **'Open Source Licenses'**
  String get settingsCategoryOpenSourceLicenses;

  /// No description provided for @settingsDeviceOptionsDescription.
  ///
  /// In en, this message translates to:
  /// **'Display and accessibility options for the current device.'**
  String get settingsDeviceOptionsDescription;

  /// No description provided for @playtestDataTitle.
  ///
  /// In en, this message translates to:
  /// **'Export Playtest Data'**
  String get playtestDataTitle;

  /// No description provided for @playtestDataDescription.
  ///
  /// In en, this message translates to:
  /// **'Create one local ZIP to send to the Crazy Chess team after a playtest.'**
  String get playtestDataDescription;

  /// No description provided for @playtestDataIncludedTitle.
  ///
  /// In en, this message translates to:
  /// **'Included'**
  String get playtestDataIncludedTitle;

  /// No description provided for @playtestDataIncludedBody.
  ///
  /// In en, this message translates to:
  /// **'Living Campaign run and generation records, chapter timing metrics, and recent bounded diagnostic logs.'**
  String get playtestDataIncludedBody;

  /// No description provided for @playtestDataPrivacyTitle.
  ///
  /// In en, this message translates to:
  /// **'Before you share'**
  String get playtestDataPrivacyTitle;

  /// No description provided for @playtestDataPrivacyBody.
  ///
  /// In en, this message translates to:
  /// **'Campaign scripts are included. Portraits, saved settings, and API credentials are excluded. Nothing uploads automatically.'**
  String get playtestDataPrivacyBody;

  /// No description provided for @playtestDataDestinationTitle.
  ///
  /// In en, this message translates to:
  /// **'Destination'**
  String get playtestDataDestinationTitle;

  /// No description provided for @playtestDataDestinationBody.
  ///
  /// In en, this message translates to:
  /// **'Packaged desktop builds save a timestamped ZIP in your Downloads folder.'**
  String get playtestDataDestinationBody;

  /// No description provided for @playtestDataExportButton.
  ///
  /// In en, this message translates to:
  /// **'Export Playtest ZIP'**
  String get playtestDataExportButton;

  /// No description provided for @playtestDataExporting.
  ///
  /// In en, this message translates to:
  /// **'Exporting…'**
  String get playtestDataExporting;

  /// No description provided for @playtestDataFailed.
  ///
  /// In en, this message translates to:
  /// **'The playtest ZIP could not be created. Your local campaign data was not changed.'**
  String get playtestDataFailed;

  /// No description provided for @playtestDataExported.
  ///
  /// In en, this message translates to:
  /// **'Exported {runCount} runs, {metricsCount} timing files, and {logCount} diagnostic logs.'**
  String playtestDataExported(int runCount, int metricsCount, int logCount);

  /// No description provided for @loadoutCategoryBoard.
  ///
  /// In en, this message translates to:
  /// **'Board'**
  String get loadoutCategoryBoard;

  /// No description provided for @loadoutCategoryToken.
  ///
  /// In en, this message translates to:
  /// **'Token'**
  String get loadoutCategoryToken;

  /// No description provided for @loadoutCategoryBanner.
  ///
  /// In en, this message translates to:
  /// **'Banner'**
  String get loadoutCategoryBanner;

  /// No description provided for @loadoutCategoryContractSeal.
  ///
  /// In en, this message translates to:
  /// **'Contract Seal'**
  String get loadoutCategoryContractSeal;

  /// No description provided for @loadoutCategoryResultVfx.
  ///
  /// In en, this message translates to:
  /// **'Result VFX'**
  String get loadoutCategoryResultVfx;

  /// No description provided for @loadoutCategoryMerchant.
  ///
  /// In en, this message translates to:
  /// **'Merchant'**
  String get loadoutCategoryMerchant;

  /// No description provided for @loadoutTitle.
  ///
  /// In en, this message translates to:
  /// **'Decoration Loadout'**
  String get loadoutTitle;

  /// No description provided for @loadoutSlots.
  ///
  /// In en, this message translates to:
  /// **'Loadout Slots'**
  String get loadoutSlots;

  /// No description provided for @loadoutPreviewDescription.
  ///
  /// In en, this message translates to:
  /// **'Cosmetic persistence and unlocks are future systems; this screen previews the product surface.'**
  String get loadoutPreviewDescription;

  /// No description provided for @commonCategories.
  ///
  /// In en, this message translates to:
  /// **'Categories'**
  String get commonCategories;

  /// No description provided for @loadoutCategoryPieces.
  ///
  /// In en, this message translates to:
  /// **'Pieces'**
  String get loadoutCategoryPieces;

  /// No description provided for @loadoutCategoryProfile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get loadoutCategoryProfile;

  /// No description provided for @navHome.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get navHome;

  /// No description provided for @navLoadout.
  ///
  /// In en, this message translates to:
  /// **'Loadout'**
  String get navLoadout;

  /// No description provided for @navPlay.
  ///
  /// In en, this message translates to:
  /// **'Play'**
  String get navPlay;

  /// No description provided for @navCountries.
  ///
  /// In en, this message translates to:
  /// **'Countries'**
  String get navCountries;

  /// No description provided for @navSettings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get navSettings;

  /// No description provided for @navRoster.
  ///
  /// In en, this message translates to:
  /// **'Roster'**
  String get navRoster;

  /// No description provided for @navRecords.
  ///
  /// In en, this message translates to:
  /// **'Records'**
  String get navRecords;

  /// No description provided for @navRules.
  ///
  /// In en, this message translates to:
  /// **'Rules'**
  String get navRules;

  /// No description provided for @modeLocalDuel.
  ///
  /// In en, this message translates to:
  /// **'Local Duel'**
  String get modeLocalDuel;

  /// No description provided for @modeLocalDuelSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Two players on one device'**
  String get modeLocalDuelSubtitle;

  /// No description provided for @modeAiDuel.
  ///
  /// In en, this message translates to:
  /// **'AI Duel'**
  String get modeAiDuel;

  /// No description provided for @modeAiDuelSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Challenge the machine court'**
  String get modeAiDuelSubtitle;

  /// No description provided for @modeStoryCampaign.
  ///
  /// In en, this message translates to:
  /// **'Story Campaign'**
  String get modeStoryCampaign;

  /// No description provided for @modeStoryCampaignSubtitle.
  ///
  /// In en, this message translates to:
  /// **'A seven-mission authored tale'**
  String get modeStoryCampaignSubtitle;

  /// No description provided for @modeLastPiece.
  ///
  /// In en, this message translates to:
  /// **'Last Piece Standing'**
  String get modeLastPiece;

  /// No description provided for @modeLastPieceSubtitle.
  ///
  /// In en, this message translates to:
  /// **'An endless single-piece survival ladder'**
  String get modeLastPieceSubtitle;

  /// No description provided for @modeLivingCampaign.
  ///
  /// In en, this message translates to:
  /// **'Living Campaign'**
  String get modeLivingCampaign;

  /// No description provided for @modeLivingCampaignSubtitle.
  ///
  /// In en, this message translates to:
  /// **'An evolving chronicle shaped by your battles'**
  String get modeLivingCampaignSubtitle;

  /// No description provided for @commonBack.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get commonBack;

  /// No description provided for @commonCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get commonCancel;

  /// No description provided for @commonClose.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get commonClose;

  /// No description provided for @commonConfirm.
  ///
  /// In en, this message translates to:
  /// **'Confirm'**
  String get commonConfirm;

  /// No description provided for @commonContinue.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get commonContinue;

  /// No description provided for @commonDone.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get commonDone;

  /// No description provided for @commonNext.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get commonNext;

  /// No description provided for @commonPrevious.
  ///
  /// In en, this message translates to:
  /// **'Previous'**
  String get commonPrevious;

  /// No description provided for @commonRetry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get commonRetry;

  /// No description provided for @commonSave.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get commonSave;

  /// No description provided for @commonStart.
  ///
  /// In en, this message translates to:
  /// **'Start'**
  String get commonStart;

  /// No description provided for @commonSelect.
  ///
  /// In en, this message translates to:
  /// **'Select'**
  String get commonSelect;

  /// No description provided for @commonSelected.
  ///
  /// In en, this message translates to:
  /// **'Selected'**
  String get commonSelected;

  /// No description provided for @commonLocked.
  ///
  /// In en, this message translates to:
  /// **'Locked'**
  String get commonLocked;

  /// No description provided for @commonLoading.
  ///
  /// In en, this message translates to:
  /// **'Loading…'**
  String get commonLoading;

  /// No description provided for @commonOn.
  ///
  /// In en, this message translates to:
  /// **'On'**
  String get commonOn;

  /// No description provided for @commonOff.
  ///
  /// In en, this message translates to:
  /// **'Off'**
  String get commonOff;

  /// No description provided for @commonReset.
  ///
  /// In en, this message translates to:
  /// **'Reset'**
  String get commonReset;

  /// No description provided for @commonApply.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get commonApply;

  /// No description provided for @commonResume.
  ///
  /// In en, this message translates to:
  /// **'Resume'**
  String get commonResume;

  /// No description provided for @commonNewRun.
  ///
  /// In en, this message translates to:
  /// **'New Run'**
  String get commonNewRun;

  /// No description provided for @commonAbandon.
  ///
  /// In en, this message translates to:
  /// **'Abandon'**
  String get commonAbandon;

  /// No description provided for @commonArchive.
  ///
  /// In en, this message translates to:
  /// **'Archive'**
  String get commonArchive;

  /// No description provided for @commonBacklog.
  ///
  /// In en, this message translates to:
  /// **'Backlog'**
  String get commonBacklog;

  /// No description provided for @commonSkip.
  ///
  /// In en, this message translates to:
  /// **'Skip'**
  String get commonSkip;

  /// No description provided for @commonDetails.
  ///
  /// In en, this message translates to:
  /// **'Details'**
  String get commonDetails;

  /// No description provided for @commonUnknown.
  ///
  /// In en, this message translates to:
  /// **'Unknown'**
  String get commonUnknown;

  /// No description provided for @setupTitle.
  ///
  /// In en, this message translates to:
  /// **'Match Settings'**
  String get setupTitle;

  /// No description provided for @setupChooseMode.
  ///
  /// In en, this message translates to:
  /// **'Choose Your Mode'**
  String get setupChooseMode;

  /// No description provided for @setupChooseCountry.
  ///
  /// In en, this message translates to:
  /// **'Choose Your Country'**
  String get setupChooseCountry;

  /// No description provided for @setupChooseBattlefield.
  ///
  /// In en, this message translates to:
  /// **'Choose Battlefield'**
  String get setupChooseBattlefield;

  /// No description provided for @setupStartingGold.
  ///
  /// In en, this message translates to:
  /// **'Starting Gold'**
  String get setupStartingGold;

  /// No description provided for @setupMerchantPayout.
  ///
  /// In en, this message translates to:
  /// **'Merchant Payout'**
  String get setupMerchantPayout;

  /// No description provided for @setupMerchantSpeed.
  ///
  /// In en, this message translates to:
  /// **'Merchant Speed'**
  String get setupMerchantSpeed;

  /// No description provided for @setupReducedEffects.
  ///
  /// In en, this message translates to:
  /// **'Reduced Effects'**
  String get setupReducedEffects;

  /// No description provided for @setupConfirmMatch.
  ///
  /// In en, this message translates to:
  /// **'Confirm Match'**
  String get setupConfirmMatch;

  /// No description provided for @setupBeginBattle.
  ///
  /// In en, this message translates to:
  /// **'Begin Battle'**
  String get setupBeginBattle;

  /// No description provided for @sideWhite.
  ///
  /// In en, this message translates to:
  /// **'White'**
  String get sideWhite;

  /// No description provided for @sideBlack.
  ///
  /// In en, this message translates to:
  /// **'Black'**
  String get sideBlack;

  /// No description provided for @sideWhiteCourt.
  ///
  /// In en, this message translates to:
  /// **'White Court'**
  String get sideWhiteCourt;

  /// No description provided for @sideBlackCourt.
  ///
  /// In en, this message translates to:
  /// **'Black Court'**
  String get sideBlackCourt;

  /// No description provided for @pieceKing.
  ///
  /// In en, this message translates to:
  /// **'King'**
  String get pieceKing;

  /// No description provided for @pieceQueen.
  ///
  /// In en, this message translates to:
  /// **'Queen'**
  String get pieceQueen;

  /// No description provided for @pieceRook.
  ///
  /// In en, this message translates to:
  /// **'Rook'**
  String get pieceRook;

  /// No description provided for @pieceBishop.
  ///
  /// In en, this message translates to:
  /// **'Bishop'**
  String get pieceBishop;

  /// No description provided for @pieceKnight.
  ///
  /// In en, this message translates to:
  /// **'Knight'**
  String get pieceKnight;

  /// No description provided for @piecePawn.
  ///
  /// In en, this message translates to:
  /// **'Pawn'**
  String get piecePawn;

  /// No description provided for @countryAshenCourt.
  ///
  /// In en, this message translates to:
  /// **'Ashen Court'**
  String get countryAshenCourt;

  /// No description provided for @countryAshenShort.
  ///
  /// In en, this message translates to:
  /// **'Ashen'**
  String get countryAshenShort;

  /// No description provided for @countryAshenFantasy.
  ///
  /// In en, this message translates to:
  /// **'A passive-free court whose identity belongs only to Living Campaign.'**
  String get countryAshenFantasy;

  /// No description provided for @countryMercantileLeague.
  ///
  /// In en, this message translates to:
  /// **'Mercantile League'**
  String get countryMercantileLeague;

  /// No description provided for @countryMercantileShort.
  ///
  /// In en, this message translates to:
  /// **'Mercantile'**
  String get countryMercantileShort;

  /// No description provided for @countryMercantileFantasy.
  ///
  /// In en, this message translates to:
  /// **'Rich traders with flexible loyalty and refunds after bad contracts.'**
  String get countryMercantileFantasy;

  /// No description provided for @countryIronDuchy.
  ///
  /// In en, this message translates to:
  /// **'Iron Duchy'**
  String get countryIronDuchy;

  /// No description provided for @countryIronShort.
  ///
  /// In en, this message translates to:
  /// **'Iron'**
  String get countryIronShort;

  /// No description provided for @countryIronFantasy.
  ///
  /// In en, this message translates to:
  /// **'Low-income fortress state with stubborn soldiers and hard-to-buy walls.'**
  String get countryIronFantasy;

  /// No description provided for @countryHorseKingdom.
  ///
  /// In en, this message translates to:
  /// **'Horse Kingdom'**
  String get countryHorseKingdom;

  /// No description provided for @countryHorseShort.
  ///
  /// In en, this message translates to:
  /// **'Horse'**
  String get countryHorseShort;

  /// No description provided for @countryHorseFantasy.
  ///
  /// In en, this message translates to:
  /// **'Cavalry nobility that turns knight contracts into political currency.'**
  String get countryHorseFantasy;

  /// No description provided for @countrySpyCourt.
  ///
  /// In en, this message translates to:
  /// **'Spy Court'**
  String get countrySpyCourt;

  /// No description provided for @countrySpyShort.
  ///
  /// In en, this message translates to:
  /// **'Spy'**
  String get countrySpyShort;

  /// No description provided for @countrySpyFantasy.
  ///
  /// In en, this message translates to:
  /// **'Information warfare, loyalty intelligence, and quiet income disruption.'**
  String get countrySpyFantasy;

  /// No description provided for @countryCorsairFreeholds.
  ///
  /// In en, this message translates to:
  /// **'Corsair Freeholds'**
  String get countryCorsairFreeholds;

  /// No description provided for @countryCorsairShort.
  ///
  /// In en, this message translates to:
  /// **'Corsair'**
  String get countryCorsairShort;

  /// No description provided for @countryCorsairFantasy.
  ///
  /// In en, this message translates to:
  /// **'Sea-raider city states that turn every battlefield capture into stolen treasury.'**
  String get countryCorsairFantasy;

  /// No description provided for @countrySunlitSynod.
  ///
  /// In en, this message translates to:
  /// **'Sunlit Synod'**
  String get countrySunlitSynod;

  /// No description provided for @countrySunlitShort.
  ///
  /// In en, this message translates to:
  /// **'Sunlit'**
  String get countrySunlitShort;

  /// No description provided for @countrySunlitFantasy.
  ///
  /// In en, this message translates to:
  /// **'A radiant bishop-led court that exposes enemy loyalty and rises or falls with its clergy.'**
  String get countrySunlitFantasy;

  /// No description provided for @countryFutureRealm.
  ///
  /// In en, this message translates to:
  /// **'Future Realm'**
  String get countryFutureRealm;

  /// No description provided for @countryLoyaltyStartsAt.
  ///
  /// In en, this message translates to:
  /// **'Starts at {range}'**
  String countryLoyaltyStartsAt(String range);

  /// No description provided for @battlefieldClassicCourt.
  ///
  /// In en, this message translates to:
  /// **'Classic Court'**
  String get battlefieldClassicCourt;

  /// No description provided for @battlefieldClassicShort.
  ///
  /// In en, this message translates to:
  /// **'Pure Crazy Chess with no battlefield effects.'**
  String get battlefieldClassicShort;

  /// No description provided for @battlefieldClassicLong.
  ///
  /// In en, this message translates to:
  /// **'The familiar court. Only chess, merchants, contracts, and loyalty shape the match.'**
  String get battlefieldClassicLong;

  /// No description provided for @battlefieldVerdantDominion.
  ///
  /// In en, this message translates to:
  /// **'Verdant Pastures'**
  String get battlefieldVerdantDominion;

  /// No description provided for @battlefieldVerdantShort.
  ///
  /// In en, this message translates to:
  /// **'Knight shrines reshape every army.'**
  String get battlefieldVerdantShort;

  /// No description provided for @battlefieldVerdantLong.
  ///
  /// In en, this message translates to:
  /// **'Ancient riding stones transform any non-king piece that holds them into a knight.'**
  String get battlefieldVerdantLong;

  /// No description provided for @battlefieldRuinedThrone.
  ///
  /// In en, this message translates to:
  /// **'Ruined Causeway'**
  String get battlefieldRuinedThrone;

  /// No description provided for @battlefieldRuinedShort.
  ///
  /// In en, this message translates to:
  /// **'Visible hazards and dangerous unknowns.'**
  String get battlefieldRuinedShort;

  /// No description provided for @battlefieldRuinedLong.
  ///
  /// In en, this message translates to:
  /// **'Open traps are readable threats. Mystery tiles conceal an even chance of treasure or destruction.'**
  String get battlefieldRuinedLong;

  /// No description provided for @battlefieldGildedExchange.
  ///
  /// In en, this message translates to:
  /// **'Gilded Bazaar'**
  String get battlefieldGildedExchange;

  /// No description provided for @battlefieldGildedShort.
  ///
  /// In en, this message translates to:
  /// **'Win gold and court-changing jewels.'**
  String get battlefieldGildedShort;

  /// No description provided for @battlefieldGildedLong.
  ///
  /// In en, this message translates to:
  /// **'Treasure chests swell a court treasury while Diamond Rings empower the next rolled offer to an enemy queen.'**
  String get battlefieldGildedLong;

  /// No description provided for @battlefieldChaosCrucible.
  ///
  /// In en, this message translates to:
  /// **'Chaos Crucible'**
  String get battlefieldChaosCrucible;

  /// No description provided for @battlefieldChaosShort.
  ///
  /// In en, this message translates to:
  /// **'Every special tile can enter the fray.'**
  String get battlefieldChaosShort;

  /// No description provided for @battlefieldChaosLong.
  ///
  /// In en, this message translates to:
  /// **'The Crucible begins dormant, then tears open every third completed action. Each mirrored eruption draws one seeded-random effect from the full battlefield arsenal.'**
  String get battlefieldChaosLong;

  /// No description provided for @battlefieldNoSpecialTiles.
  ///
  /// In en, this message translates to:
  /// **'No special tiles spawn.'**
  String get battlefieldNoSpecialTiles;

  /// No description provided for @battlefieldOpeningPair.
  ///
  /// In en, this message translates to:
  /// **'opening pair · '**
  String get battlefieldOpeningPair;

  /// No description provided for @battlefieldEveryActions.
  ///
  /// In en, this message translates to:
  /// **'every {count} completed actions'**
  String battlefieldEveryActions(int count);

  /// No description provided for @battlefieldEveryActionRange.
  ///
  /// In en, this message translates to:
  /// **'every {min}–{max} completed actions'**
  String battlefieldEveryActionRange(int min, int max);

  /// No description provided for @battlefieldSeededRandomEffects.
  ///
  /// In en, this message translates to:
  /// **'seeded-random effects'**
  String get battlefieldSeededRandomEffects;

  /// No description provided for @battlefieldSeededEffectOrder.
  ///
  /// In en, this message translates to:
  /// **'seeded effect order'**
  String get battlefieldSeededEffectOrder;

  /// No description provided for @battlefieldSpawnLaw.
  ///
  /// In en, this message translates to:
  /// **'Mirrored empty-square pairs · {opening}{delay} · {selection} · one-shot effects'**
  String battlefieldSpawnLaw(String opening, String delay, String selection);

  /// No description provided for @tileKnightShrine.
  ///
  /// In en, this message translates to:
  /// **'Knight Shrine'**
  String get tileKnightShrine;

  /// No description provided for @tileTreasureChest.
  ///
  /// In en, this message translates to:
  /// **'Treasure Chest'**
  String get tileTreasureChest;

  /// No description provided for @tileDiamondRing.
  ///
  /// In en, this message translates to:
  /// **'Diamond Ring'**
  String get tileDiamondRing;

  /// No description provided for @tilePortal.
  ///
  /// In en, this message translates to:
  /// **'Portal'**
  String get tilePortal;

  /// No description provided for @tileTrap.
  ///
  /// In en, this message translates to:
  /// **'Trap'**
  String get tileTrap;

  /// No description provided for @tileBoost.
  ///
  /// In en, this message translates to:
  /// **'Boost'**
  String get tileBoost;

  /// No description provided for @tileSwap.
  ///
  /// In en, this message translates to:
  /// **'Swap'**
  String get tileSwap;

  /// No description provided for @tileMystery.
  ///
  /// In en, this message translates to:
  /// **'Mystery'**
  String get tileMystery;

  /// No description provided for @gameYourTurn.
  ///
  /// In en, this message translates to:
  /// **'Your Turn'**
  String get gameYourTurn;

  /// No description provided for @gameOpponentTurn.
  ///
  /// In en, this message translates to:
  /// **'Opponent Turn'**
  String get gameOpponentTurn;

  /// No description provided for @gameWhiteToMove.
  ///
  /// In en, this message translates to:
  /// **'White to move'**
  String get gameWhiteToMove;

  /// No description provided for @gameBlackToMove.
  ///
  /// In en, this message translates to:
  /// **'Black to move'**
  String get gameBlackToMove;

  /// No description provided for @gameCheck.
  ///
  /// In en, this message translates to:
  /// **'Check'**
  String get gameCheck;

  /// No description provided for @gameCheckmate.
  ///
  /// In en, this message translates to:
  /// **'Checkmate'**
  String get gameCheckmate;

  /// No description provided for @gameStalemate.
  ///
  /// In en, this message translates to:
  /// **'Stalemate'**
  String get gameStalemate;

  /// No description provided for @gameKingTrapfall.
  ///
  /// In en, this message translates to:
  /// **'King Trapfall'**
  String get gameKingTrapfall;

  /// No description provided for @gameVictory.
  ///
  /// In en, this message translates to:
  /// **'Victory'**
  String get gameVictory;

  /// No description provided for @gameDefeat.
  ///
  /// In en, this message translates to:
  /// **'Defeat'**
  String get gameDefeat;

  /// No description provided for @gameDraw.
  ///
  /// In en, this message translates to:
  /// **'Draw'**
  String get gameDraw;

  /// No description provided for @gameOver.
  ///
  /// In en, this message translates to:
  /// **'Game Over'**
  String get gameOver;

  /// No description provided for @gamePlayAgain.
  ///
  /// In en, this message translates to:
  /// **'Play Again'**
  String get gamePlayAgain;

  /// No description provided for @gameBackToLobby.
  ///
  /// In en, this message translates to:
  /// **'Back to Lobby'**
  String get gameBackToLobby;

  /// No description provided for @gameLobby.
  ///
  /// In en, this message translates to:
  /// **'Lobby'**
  String get gameLobby;

  /// No description provided for @gameEventLog.
  ///
  /// In en, this message translates to:
  /// **'Event Log'**
  String get gameEventLog;

  /// No description provided for @gameMoveHistory.
  ///
  /// In en, this message translates to:
  /// **'Move History'**
  String get gameMoveHistory;

  /// No description provided for @gameOffer.
  ///
  /// In en, this message translates to:
  /// **'Make Offer'**
  String get gameOffer;

  /// No description provided for @gameRedeploy.
  ///
  /// In en, this message translates to:
  /// **'Redeploy'**
  String get gameRedeploy;

  /// No description provided for @gameConfirmRedeploy.
  ///
  /// In en, this message translates to:
  /// **'Confirm Redeploy'**
  String get gameConfirmRedeploy;

  /// No description provided for @gameGold.
  ///
  /// In en, this message translates to:
  /// **'Gold'**
  String get gameGold;

  /// No description provided for @gameLoyalty.
  ///
  /// In en, this message translates to:
  /// **'Loyalty'**
  String get gameLoyalty;

  /// No description provided for @gameFamiliarity.
  ///
  /// In en, this message translates to:
  /// **'Familiarity'**
  String get gameFamiliarity;

  /// No description provided for @gameMerchant.
  ///
  /// In en, this message translates to:
  /// **'Merchant'**
  String get gameMerchant;

  /// No description provided for @storyTitle.
  ///
  /// In en, this message translates to:
  /// **'Story Campaign'**
  String get storyTitle;

  /// No description provided for @storyObjective.
  ///
  /// In en, this message translates to:
  /// **'Objective'**
  String get storyObjective;

  /// No description provided for @storyKingRowan.
  ///
  /// In en, this message translates to:
  /// **'King Rowan'**
  String get storyKingRowan;

  /// No description provided for @storyReachSquareWithKing.
  ///
  /// In en, this message translates to:
  /// **'Reach {square} with {king}'**
  String storyReachSquareWithKing(String square, String king);

  /// No description provided for @storyCheckmateEnemyKing.
  ///
  /// In en, this message translates to:
  /// **'Checkmate the enemy King'**
  String get storyCheckmateEnemyKing;

  /// No description provided for @storyOrSeparator.
  ///
  /// In en, this message translates to:
  /// **'  •  OR  •  '**
  String get storyOrSeparator;

  /// No description provided for @storyVictoryConditions.
  ///
  /// In en, this message translates to:
  /// **'Victory Conditions'**
  String get storyVictoryConditions;

  /// No description provided for @storyMissionComplete.
  ///
  /// In en, this message translates to:
  /// **'Mission Complete'**
  String get storyMissionComplete;

  /// No description provided for @storyMissionFailed.
  ///
  /// In en, this message translates to:
  /// **'Mission Failed'**
  String get storyMissionFailed;

  /// No description provided for @storyBeginMission.
  ///
  /// In en, this message translates to:
  /// **'Begin Mission'**
  String get storyBeginMission;

  /// No description provided for @storyContinueJourney.
  ///
  /// In en, this message translates to:
  /// **'Continue Journey'**
  String get storyContinueJourney;

  /// No description provided for @storyCampaignMap.
  ///
  /// In en, this message translates to:
  /// **'Campaign Map'**
  String get storyCampaignMap;

  /// No description provided for @lastPieceTitle.
  ///
  /// In en, this message translates to:
  /// **'Last Piece Standing'**
  String get lastPieceTitle;

  /// No description provided for @lastPieceStartRun.
  ///
  /// In en, this message translates to:
  /// **'Start Run'**
  String get lastPieceStartRun;

  /// No description provided for @lastPieceRetire.
  ///
  /// In en, this message translates to:
  /// **'Retire Run'**
  String get lastPieceRetire;

  /// No description provided for @lastPieceScore.
  ///
  /// In en, this message translates to:
  /// **'Score'**
  String get lastPieceScore;

  /// No description provided for @lastPieceBestScore.
  ///
  /// In en, this message translates to:
  /// **'Best Score'**
  String get lastPieceBestScore;

  /// No description provided for @lastPieceTransformation.
  ///
  /// In en, this message translates to:
  /// **'Transformation'**
  String get lastPieceTransformation;

  /// No description provided for @lastPieceRunEnded.
  ///
  /// In en, this message translates to:
  /// **'Run Ended'**
  String get lastPieceRunEnded;

  /// No description provided for @livingTitle.
  ///
  /// In en, this message translates to:
  /// **'Living Campaign'**
  String get livingTitle;

  /// No description provided for @livingNewChronicle.
  ///
  /// In en, this message translates to:
  /// **'New Chronicle'**
  String get livingNewChronicle;

  /// No description provided for @livingContinueChronicle.
  ///
  /// In en, this message translates to:
  /// **'Continue Chronicle'**
  String get livingContinueChronicle;

  /// No description provided for @livingUnfinishedTales.
  ///
  /// In en, this message translates to:
  /// **'Unfinished Tales'**
  String get livingUnfinishedTales;

  /// No description provided for @livingChronicleArchive.
  ///
  /// In en, this message translates to:
  /// **'Chronicle Archive'**
  String get livingChronicleArchive;

  /// No description provided for @livingGenerationInProgress.
  ///
  /// In en, this message translates to:
  /// **'The Chronicler is writing…'**
  String get livingGenerationInProgress;

  /// No description provided for @livingRecallWords.
  ///
  /// In en, this message translates to:
  /// **'Recall Their Words'**
  String get livingRecallWords;

  /// No description provided for @livingRecallFinalMoment.
  ///
  /// In en, this message translates to:
  /// **'Recall the Final Moment'**
  String get livingRecallFinalMoment;

  /// No description provided for @livingContentLanguage.
  ///
  /// In en, this message translates to:
  /// **'Story language'**
  String get livingContentLanguage;

  /// No description provided for @livingContentLanguageEnglish.
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get livingContentLanguageEnglish;

  /// No description provided for @livingContentLanguageChinese.
  ///
  /// In en, this message translates to:
  /// **'Simplified Chinese'**
  String get livingContentLanguageChinese;

  /// No description provided for @errorGeneric.
  ///
  /// In en, this message translates to:
  /// **'Something went wrong.'**
  String get errorGeneric;

  /// No description provided for @errorTryAgain.
  ///
  /// In en, this message translates to:
  /// **'Please try again.'**
  String get errorTryAgain;

  /// No description provided for @semanticCrazyChessLogo.
  ///
  /// In en, this message translates to:
  /// **'Crazy Chess logo'**
  String get semanticCrazyChessLogo;

  /// No description provided for @semanticSettings.
  ///
  /// In en, this message translates to:
  /// **'Open settings'**
  String get semanticSettings;

  /// No description provided for @semanticBack.
  ///
  /// In en, this message translates to:
  /// **'Go back'**
  String get semanticBack;

  /// No description provided for @semanticClose.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get semanticClose;

  /// No description provided for @semanticBoardSquare.
  ///
  /// In en, this message translates to:
  /// **'{piece} on {square}'**
  String semanticBoardSquare(String piece, String square);

  /// No description provided for @goldAmount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =0{No gold} =1{1 gold} other{{count} gold}}'**
  String goldAmount(int count);

  /// No description provided for @turnNumber.
  ///
  /// In en, this message translates to:
  /// **'Turn {turn}'**
  String turnNumber(int turn);

  /// No description provided for @scoreAmount.
  ///
  /// In en, this message translates to:
  /// **'Score {score}'**
  String scoreAmount(int score);

  /// No description provided for @messageMoved.
  ///
  /// In en, this message translates to:
  /// **'{side} moved {piece} from {from} to {to}.'**
  String messageMoved(String side, String piece, String from, String to);

  /// No description provided for @messageCaptured.
  ///
  /// In en, this message translates to:
  /// **'{side} captured {piece} on {square}.'**
  String messageCaptured(String side, String piece, String square);

  /// No description provided for @messageAiFailure.
  ///
  /// In en, this message translates to:
  /// **'The AI court could not complete its turn. Try again or return to the lobby.'**
  String get messageAiFailure;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'zh'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when language+script codes are specified.
  switch (locale.languageCode) {
    case 'zh':
      {
        switch (locale.scriptCode) {
          case 'Hans':
            return AppLocalizationsZhHans();
        }
        break;
      }
  }

  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'zh':
      return AppLocalizationsZh();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
