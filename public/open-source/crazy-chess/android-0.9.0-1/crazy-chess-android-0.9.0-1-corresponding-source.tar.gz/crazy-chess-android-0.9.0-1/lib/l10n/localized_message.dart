import 'runtime_game_locale.dart';

enum LocalizedMessageKey {
  matchStarted,
  scenarioStarted,
  move,
  capture,
  castle,
  promotion,
  check,
  checkmate,
  stalemate,
  offerAccepted,
  offerRejected,
  redeploy,
  merchantPayout,
  battlefield,
  loyalty,
  lastPieceStarted,
  lastPieceCapture,
  lastPieceProgress,
  lastPieceTransformation,
  lastPieceEnded,
  other,
}

class LocalizedMessageRecord {
  const LocalizedMessageRecord({
    required this.key,
    required this.arguments,
    required this.debugEnglish,
  });

  final LocalizedMessageKey key;
  final Map<String, Object?> arguments;
  final String debugEnglish;

  factory LocalizedMessageRecord.fromEnglish(String message) {
    final move = RegExp(
      r'^(White|Black) (Pawn|Knight|Bishop|Rook|Queen|King) moved ([a-h][1-8]) to ([a-h][1-8])\.$',
    ).firstMatch(message);
    if (move != null) {
      return LocalizedMessageRecord(
        key: LocalizedMessageKey.move,
        arguments: <String, Object?>{
          'side': move[1],
          'piece': move[2],
          'from': move[3],
          'to': move[4],
        },
        debugEnglish: message,
      );
    }
    final capture = RegExp(
      r'^(White|Black) (Pawn|Knight|Bishop|Rook|Queen|King) captured (Pawn|Knight|Bishop|Rook|Queen|King) on ([a-h][1-8])\.$',
    ).firstMatch(message);
    if (capture != null) {
      return LocalizedMessageRecord(
        key: LocalizedMessageKey.capture,
        arguments: <String, Object?>{
          'side': capture[1],
          'attacker': capture[2],
          'piece': capture[3],
          'square': capture[4],
        },
        debugEnglish: message,
      );
    }
    final key = switch (message) {
      String value when value.startsWith('Match started:') =>
        LocalizedMessageKey.matchStarted,
      String value when value.startsWith('Scenario ') =>
        LocalizedMessageKey.scenarioStarted,
      String value when value.startsWith('CHECKMATE:') =>
        LocalizedMessageKey.checkmate,
      String value when value.startsWith('Stalemate:') =>
        LocalizedMessageKey.stalemate,
      String value when value.endsWith('king is in check.') =>
        LocalizedMessageKey.check,
      String value when value.contains(' castled ') =>
        LocalizedMessageKey.castle,
      String value when value.contains(' promoted to ') =>
        LocalizedMessageKey.promotion,
      String value when value.startsWith('SUCCESS:') =>
        LocalizedMessageKey.offerAccepted,
      String value
          when value.startsWith('FAILED:') || value.startsWith('HUMILIATED:') =>
        LocalizedMessageKey.offerRejected,
      String value when value.toLowerCase().contains('redeploy') =>
        LocalizedMessageKey.redeploy,
      String value when value.startsWith('Merchant reached') =>
        LocalizedMessageKey.merchantPayout,
      String value
          when value.contains('tile') ||
              value.contains('Shrine') ||
              value.contains('Trap') ||
              value.contains('Mystery') ||
              value.contains('Causeway') ||
              value.contains('Crucible') =>
        LocalizedMessageKey.battlefield,
      String value
          when value.toLowerCase().contains('loyalt') ||
              value.contains('Sunlit') =>
        LocalizedMessageKey.loyalty,
      String value when value.startsWith('Level ') =>
        LocalizedMessageKey.lastPieceStarted,
      String value when value.startsWith('Captured ') =>
        LocalizedMessageKey.lastPieceCapture,
      String value
          when value.startsWith('Survived ') ||
              value.startsWith('Reached star') ||
              value.startsWith('Spawned ') ||
              value.contains(' hunted ') =>
        LocalizedMessageKey.lastPieceProgress,
      String value
          when value.startsWith('Transformed ') ||
              value.startsWith('Pawn promoted') =>
        LocalizedMessageKey.lastPieceTransformation,
      String value
          when value.contains('captured the player') ||
              value.startsWith('The player retired') =>
        LocalizedMessageKey.lastPieceEnded,
      _ => LocalizedMessageKey.other,
    };
    return LocalizedMessageRecord(
      key: key,
      arguments: <String, Object?>{'message': message},
      debugEnglish: message,
    );
  }

  String resolve() {
    if (!RuntimeGameLocale.isSimplifiedChinese) {
      return debugEnglish;
    }
    if (key == LocalizedMessageKey.move) {
      return '${_side(arguments['side'])}${_piece(arguments['piece'])}从 '
          '${arguments['from']} 移动至 ${arguments['to']}。';
    }
    if (key == LocalizedMessageKey.capture) {
      return '${_side(arguments['side'])}${_piece(arguments['attacker'])}在 '
          '${arguments['square']} 吃掉了${_piece(arguments['piece'])}。';
    }
    final message = debugEnglish;
    return switch (key) {
      LocalizedMessageKey.matchStarted => '对局开始。双方棋庭已在选定战场列阵。',
      LocalizedMessageKey.scenarioStarted => '剧情棋局已开始，预设棋子完成列阵。',
      LocalizedMessageKey.checkmate =>
        message.contains('White') ? '将杀：白方获胜。' : '将杀：黑方获胜。',
      LocalizedMessageKey.stalemate => '逼和：当前一方已无合法着法。',
      LocalizedMessageKey.check =>
        message.startsWith('White') ? '白方王正被将军。' : '黑方王正被将军。',
      LocalizedMessageKey.castle => '已完成王车易位。',
      LocalizedMessageKey.promotion => '兵已完成升变。',
      LocalizedMessageKey.offerAccepted => '契约成功：目标接受了报价，请立即重新部署。',
      LocalizedMessageKey.offerRejected => '契约失败：目标拒绝了报价，忠诚度已结算。',
      LocalizedMessageKey.redeploy => '已结算购买棋子的重新部署。',
      LocalizedMessageKey.merchantPayout => '商人抵达棋庭，金币收益已结算。',
      LocalizedMessageKey.battlefield => '战场特殊效果已结算。',
      LocalizedMessageKey.loyalty => '阵营忠诚度效果已结算。',
      LocalizedMessageKey.lastPieceStarted => '残子求生已经开始。',
      LocalizedMessageKey.lastPieceCapture => '吃子成功，得分已增加。',
      LocalizedMessageKey.lastPieceProgress => '敌方阶段与求生进度已结算。',
      LocalizedMessageKey.lastPieceTransformation => '棋子变形已完成。',
      LocalizedMessageKey.lastPieceEnded => '本次残子求生已经结束。',
      LocalizedMessageKey.other => '一项游戏事件已结算。',
      LocalizedMessageKey.move ||
      LocalizedMessageKey.capture => throw StateError('Handled above.'),
    };
  }

  static String _side(Object? value) => value == 'White' ? '白方' : '黑方';

  static String _piece(Object? value) => switch (value) {
    'King' || 'king' => '王',
    'Queen' || 'queen' => '后',
    'Rook' || 'rook' => '车',
    'Bishop' || 'bishop' => '象',
    'Knight' || 'knight' => '马',
    _ => '兵',
  };
}
