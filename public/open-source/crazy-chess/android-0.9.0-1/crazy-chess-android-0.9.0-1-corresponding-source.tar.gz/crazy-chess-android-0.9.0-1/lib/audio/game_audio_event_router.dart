import '../battlefield/battlefield_models.dart';
import '../domain/board_presentation.dart';
import '../domain/chess_models.dart';
import '../game/game_controller.dart';
import '../last_piece/last_piece_models.dart';
import '../last_piece/last_piece_session_controller.dart';
import '../story/story_audio_controller.dart';

class GameAudioEventRouter {
  GameAudioEventRouter({
    required this.audio,
    required this.gameController,
    required this.lastPieceController,
  }) : _lastBoardMotionSerial =
           gameController.lastBoardMotionEvent?.serial ?? 0,
       _lastBetrayalSerial =
           gameController.lastBetrayalTransformEvent?.serial ?? 0,
       _lastMerchantPayoutSerial = gameController.merchantPayoutPulseSerial,
       _lastBattlefieldEventSerial = gameController.battlefieldEventSerial,
       _lastPhase = gameController.phase,
       _lastPromotionSquare = gameController.pendingPromotionSquare,
       _lastOfferResult = gameController.lastOfferResult,
       _lastLastPieceSequence = lastPieceController.presentationSequenceSerial {
    gameController.addListener(_onGameChanged);
    lastPieceController.addListener(_onLastPieceChanged);
  }

  final StoryAudioPort audio;
  final GameController gameController;
  final LastPieceSessionController lastPieceController;

  int _lastBoardMotionSerial;
  int _lastBetrayalSerial;
  int _lastMerchantPayoutSerial;
  int _lastBattlefieldEventSerial;
  int _lastLastPieceSequence;
  GamePhase _lastPhase;
  Square? _lastPromotionSquare;
  OfferResult? _lastOfferResult;
  bool _disposed = false;

  void _onGameChanged() {
    if (_disposed) {
      return;
    }
    final motion = gameController.lastBoardMotionEvent;
    if (motion != null && motion.serial != _lastBoardMotionSerial) {
      _lastBoardMotionSerial = motion.serial;
      audio.playSfx(_boardMotionCue(motion));
      final reason = gameController.resolvedGameEndReason;
      if (reason == GameEndReason.checkmate) {
        audio.playSfx('checkmate');
      } else if (reason == GameEndReason.stalemate) {
        audio.playSfx('stalemate');
      } else if (gameController.activeKingInCheck) {
        audio.playSfx('check');
      }
    }

    if (_lastPhase != GamePhase.offer &&
        gameController.phase == GamePhase.offer) {
      audio.playSfx('offer_open');
    }

    final offerResult = gameController.lastOfferResult;
    if (offerResult != null && !identical(offerResult, _lastOfferResult)) {
      if (offerResult.roll != null) {
        audio.playSfx('offer_roll');
      }
      audio.playSfx(
        offerResult.success ? 'purchase_confirm' : 'purchase_denied',
      );
      if (offerResult.resolutionKind == OfferResolutionKind.humiliated) {
        audio.playSfx('loyalty_gain');
      }
    }
    _lastOfferResult = offerResult;

    final betrayal = gameController.lastBetrayalTransformEvent;
    if (betrayal != null && betrayal.serial != _lastBetrayalSerial) {
      _lastBetrayalSerial = betrayal.serial;
      audio.playSfx('betrayal_reveal');
    }

    if (gameController.merchantPayoutPulseSerial != _lastMerchantPayoutSerial) {
      _lastMerchantPayoutSerial = gameController.merchantPayoutPulseSerial;
      audio.playSfx('merchant_payout');
    }

    final battlefieldEvent = gameController.lastBattlefieldEvent;
    if (battlefieldEvent != null &&
        battlefieldEvent.serial != _lastBattlefieldEventSerial) {
      _lastBattlefieldEventSerial = battlefieldEvent.serial;
      final cue = _battlefieldCue(battlefieldEvent.type);
      if (cue != null) {
        audio.playSfx(cue);
      }
    }

    if (_lastPromotionSquare != null &&
        gameController.pendingPromotionSquare == null) {
      audio.playSfx('promotion');
    }
    _lastPromotionSquare = gameController.pendingPromotionSquare;
    _lastPhase = gameController.phase;
  }

  String _boardMotionCue(BoardMotionEvent event) {
    if (event.kind == BoardMotionKind.castle) {
      return 'castle';
    }
    if (event.kind == BoardMotionKind.redeploy) {
      return 'redeploy';
    }
    if (event.capturedPiece != null) {
      return 'capture';
    }
    if (event.motions.firstOrNull?.piece.type == PieceType.knight) {
      return 'knight_leap';
    }
    return 'piece_move';
  }

  String? _battlefieldCue(BattlefieldEventType type) {
    return switch (type) {
      BattlefieldEventType.knightPromotion ||
      BattlefieldEventType.kingGuarded => 'shrine_blessing',
      BattlefieldEventType.treasureFound => 'treasure_chest_open',
      BattlefieldEventType.diamondRingFound => 'diamond_ring_gain',
      BattlefieldEventType.trapTriggered => 'trap_trigger',
      BattlefieldEventType.mysteryTreasure ||
      BattlefieldEventType.mysteryTrap => 'mystery_reveal',
      BattlefieldEventType.tilesSpawned => null,
    };
  }

  void _onLastPieceChanged() {
    if (_disposed) {
      return;
    }
    final sequence = lastPieceController.presentationSequenceSerial;
    if (sequence == 0) {
      _lastLastPieceSequence = 0;
      return;
    }
    if (sequence == _lastLastPieceSequence) {
      return;
    }
    _lastLastPieceSequence = sequence;
    for (final step in lastPieceController.presentationSteps) {
      switch (step.kind) {
        case LastPiecePresentationKind.motion:
          final motion = step.motion!;
          audio.playSfx(_boardMotionCue(motion));
        case LastPiecePresentationKind.transformation:
          audio.playSfx('transformation');
        case LastPiecePresentationKind.spawn:
          audio.playSfx('enemy_spawn');
      }
    }
  }

  void dispose() {
    if (_disposed) {
      return;
    }
    _disposed = true;
    gameController.removeListener(_onGameChanged);
    lastPieceController.removeListener(_onLastPieceChanged);
  }
}
