import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';

import '../story/story_audio_controller.dart';
import 'audio_catalog.dart';
import 'audio_settings.dart';

typedef GameMusicPlaybackLogger = void Function(String message);

enum GameMusicPlaybackReason { cueChange, playlistAdvance }

class GameMusicPlaybackEvent {
  const GameMusicPlaybackEvent({
    required this.cue,
    required this.candidateLabel,
    required this.playlistIndex,
    required this.playlistLength,
    required this.assetPath,
    required this.reason,
    required this.fadeDuration,
  });

  final String cue;
  final String candidateLabel;
  final int playlistIndex;
  final int playlistLength;
  final String assetPath;
  final GameMusicPlaybackReason reason;
  final Duration fadeDuration;

  String toLogLine() =>
      '[GameAudio] music_started cue=$cue candidate=$candidateLabel '
      'playlist=${playlistIndex + 1}/$playlistLength '
      'reason=${reason.name} fade_ms=${fadeDuration.inMilliseconds} '
      'asset=$assetPath';
}

abstract interface class GameMusicPlayerPort {
  Stream<void> get onPlayerComplete;

  Future<void> setStopReleaseMode();

  Future<void> playAsset(String assetPath, {required double volume});

  Future<void> setVolume(double volume);

  Future<void> stop();

  Future<void> dispose();
}

class AudioplayersGameMusicPlayer implements GameMusicPlayerPort {
  AudioplayersGameMusicPlayer(this.player);

  final AudioPlayer player;

  @override
  Stream<void> get onPlayerComplete => player.onPlayerComplete;

  @override
  Future<void> setStopReleaseMode() => player.setReleaseMode(ReleaseMode.stop);

  @override
  Future<void> playAsset(String assetPath, {required double volume}) =>
      player.play(AssetSource(assetPath), volume: volume);

  @override
  Future<void> setVolume(double volume) => player.setVolume(volume);

  @override
  Future<void> stop() => player.stop();

  @override
  Future<void> dispose() => player.dispose();
}

class GameAudioController implements StoryAudioPort {
  GameAudioController({
    GameAudioSettingsRepository? settingsRepository,
    List<AudioPlayer>? musicPlayers,
    List<GameMusicPlayerPort>? musicPlayerPorts,
    List<AudioPlayer>? sfxPlayers,
    GameMusicPlaybackLogger? musicPlaybackLogger,
    Future<void> Function(Duration duration)? transitionDelay,
  }) : _settingsRepository =
           settingsRepository ??
           GameAudioSettingsRepository(
             store: SharedPreferencesGameAudioSettingsStore(),
           ),
       _musicPlayers =
           musicPlayerPorts ??
           <GameMusicPlayerPort>[
             for (final player
                 in musicPlayers ?? <AudioPlayer>[AudioPlayer(), AudioPlayer()])
               AudioplayersGameMusicPlayer(player),
           ],
       _sfxPlayers =
           sfxPlayers ?? List<AudioPlayer>.generate(4, (_) => AudioPlayer()),
       _musicPlaybackLogger =
           musicPlaybackLogger ?? ((message) => debugPrint(message)),
       _transitionDelay = transitionDelay ?? Future<void>.delayed,
       assert(musicPlayers == null || musicPlayerPorts == null) {
    for (var index = 0; index < _musicPlayers.length; index++) {
      _completionSubscriptions.add(
        _musicPlayers[index].onPlayerComplete.listen(
          (_) => _handleMusicCompleted(index),
        ),
      );
    }
  }

  final GameAudioSettingsRepository _settingsRepository;
  final List<GameMusicPlayerPort> _musicPlayers;
  final List<AudioPlayer> _sfxPlayers;
  final GameMusicPlaybackLogger _musicPlaybackLogger;
  final Future<void> Function(Duration duration) _transitionDelay;
  final ValueNotifier<int> _notifier = ValueNotifier<int>(0);
  final List<StreamSubscription<void>> _completionSubscriptions =
      <StreamSubscription<void>>[];
  final Map<String, int> _playlistCursors = <String, int>{};

  GameAudioSettings settings = const GameAudioSettings();
  String? activeMusicCue;
  int _activeMusicSlot = -1;
  int _sfxCursor = 0;
  int _transitionSerial = 0;
  bool _initialized = false;
  bool _disposed = false;

  Listenable get listenable => _notifier;

  Future<void> initialize() async {
    if (_initialized || _disposed) {
      return;
    }
    _initialized = true;
    final loaded = await _settingsRepository.load();
    if (_disposed) {
      return;
    }
    settings = loaded;
    _notifier.value++;
  }

  void playContext(
    GameMusicContext context, {
    String countryId = 'mercantile',
    int familiarity = 0,
  }) {
    playMusic(
      GameAudioCatalog.cueForContext(
        context,
        countryId: countryId,
        familiarity: familiarity,
      ),
    );
  }

  @override
  void playMusic(String cue) {
    final definition = GameAudioCatalog.music[cue];
    if (_disposed || definition == null || definition.assetPaths.isEmpty) {
      return;
    }
    if (cue == activeMusicCue) {
      return;
    }
    activeMusicCue = cue;
    final cursor = _playlistCursors[cue] ?? 0;
    unawaited(_transitionTo(definition, cursor));
  }

  Future<void> _transitionTo(MusicCueDefinition definition, int cursor) async {
    final transition = ++_transitionSerial;
    final incomingSlot = _activeMusicSlot == 0 ? 1 : 0;
    final incoming = _musicPlayers[incomingSlot];
    final outgoingSlot = _activeMusicSlot;
    final outgoing = outgoingSlot < 0 ? null : _musicPlayers[outgoingSlot];
    final path = definition.assetPaths[cursor % definition.assetPaths.length];
    try {
      await incoming.setStopReleaseMode();
      await incoming.playAsset(path, volume: 0);
      if (_disposed || transition != _transitionSerial) {
        await incoming.stop();
        return;
      }
      _activeMusicSlot = incomingSlot;
      _recordSuccessfulStart(
        definition,
        cursor,
        path,
        GameMusicPlaybackReason.cueChange,
      );
      final target = _musicOutputVolume;
      final completed = await _crossfade(
        incoming: incoming,
        outgoing: outgoing,
        target: target,
        duration: definition.crossfadeDuration,
        transition: transition,
      );
      if (completed) {
        await outgoing?.stop();
      }
    } on Object {
      if (transition == _transitionSerial) {
        activeMusicCue = null;
      }
    }
  }

  void _handleMusicCompleted(int slot) {
    if (_disposed || slot != _activeMusicSlot) {
      return;
    }
    final cue = activeMusicCue;
    final definition = cue == null ? null : GameAudioCatalog.music[cue];
    if (definition == null || definition.assetPaths.isEmpty) {
      return;
    }
    final next = _playlistCursors[cue!] ?? 0;
    final continuation = _transitionSerial;
    unawaited(_continuePlaylist(slot, cue, definition, next, continuation));
  }

  Future<void> _continuePlaylist(
    int slot,
    String cue,
    MusicCueDefinition definition,
    int cursor,
    int continuation,
  ) async {
    final player = _musicPlayers[slot];
    final path = definition.assetPaths[cursor % definition.assetPaths.length];
    try {
      await player.playAsset(path, volume: 0);
      if (_disposed ||
          continuation != _transitionSerial ||
          activeMusicCue != cue ||
          _activeMusicSlot != slot) {
        await player.stop();
        return;
      }
      _recordSuccessfulStart(
        definition,
        cursor,
        path,
        GameMusicPlaybackReason.playlistAdvance,
      );
      await _crossfade(
        incoming: player,
        target: _musicOutputVolume,
        duration: definition.crossfadeDuration,
        transition: continuation,
      );
    } on Object {
      if (activeMusicCue == cue) {
        activeMusicCue = null;
      }
    }
  }

  void _recordSuccessfulStart(
    MusicCueDefinition definition,
    int cursor,
    String path,
    GameMusicPlaybackReason reason,
  ) {
    final index = cursor % definition.assetPaths.length;
    _playlistCursors[definition.id] =
        (index + 1) % definition.assetPaths.length;
    _musicPlaybackLogger(
      GameMusicPlaybackEvent(
        cue: definition.id,
        candidateLabel: definition.candidateLabelAt(index),
        playlistIndex: index,
        playlistLength: definition.assetPaths.length,
        assetPath: path,
        reason: reason,
        fadeDuration: definition.crossfadeDuration,
      ).toLogLine(),
    );
  }

  Future<bool> _crossfade({
    required GameMusicPlayerPort incoming,
    GameMusicPlayerPort? outgoing,
    required double target,
    required Duration duration,
    required int transition,
  }) async {
    const steps = 8;
    final stepDuration = Duration(
      microseconds: duration.inMicroseconds ~/ steps,
    );
    for (var step = 1; step <= steps; step++) {
      if (_disposed || transition != _transitionSerial) {
        return false;
      }
      final progress = step / steps;
      await incoming.setVolume(target * progress);
      if (outgoing != null) {
        await outgoing.setVolume(target * (1 - progress));
      }
      await _transitionDelay(stepDuration);
    }
    return true;
  }

  @override
  void playSfx(String cue) {
    final definition = GameAudioCatalog.sfx[cue];
    final path = definition?.assetPath;
    if (_disposed || path == null || _sfxPlayers.isEmpty) {
      return;
    }
    final player = _sfxPlayers[_sfxCursor % _sfxPlayers.length];
    _sfxCursor++;
    unawaited(_playSfx(player, path));
  }

  Future<void> _playSfx(AudioPlayer player, String path) async {
    try {
      await player.setReleaseMode(ReleaseMode.stop);
      await player.play(AssetSource(path), volume: _sfxOutputVolume);
    } on Object {
      // Audio remains presentational and never blocks rules or input.
    }
  }

  void setMasterVolume(double value) =>
      _update(settings.copyWith(masterVolume: value));

  void setMusicVolume(double value) =>
      _update(settings.copyWith(musicVolume: value));

  void setSfxVolume(double value) =>
      _update(settings.copyWith(sfxVolume: value));

  void setMasterMuted(bool value) =>
      _update(settings.copyWith(masterMuted: value));

  void setMusicMuted(bool value) =>
      _update(settings.copyWith(musicMuted: value));

  void setSfxMuted(bool value) => _update(settings.copyWith(sfxMuted: value));

  void _update(GameAudioSettings next) {
    if (_disposed) {
      return;
    }
    settings = next;
    if (_activeMusicSlot >= 0) {
      unawaited(_musicPlayers[_activeMusicSlot].setVolume(_musicOutputVolume));
    }
    _notifier.value++;
    unawaited(_settingsRepository.save(settings));
  }

  double get _musicOutputVolume {
    if (settings.masterMuted || settings.musicMuted) {
      return 0;
    }
    return .48 * settings.masterVolume * settings.musicVolume;
  }

  double get _sfxOutputVolume {
    if (settings.masterMuted || settings.sfxMuted) {
      return 0;
    }
    return .78 * settings.masterVolume * settings.sfxVolume;
  }

  @override
  Future<void> dispose() async {
    if (_disposed) {
      return;
    }
    _disposed = true;
    _transitionSerial++;
    for (final subscription in _completionSubscriptions) {
      await subscription.cancel();
    }
    await Future.wait<void>([
      for (final player in _musicPlayers) player.dispose(),
      for (final player in _sfxPlayers) player.dispose(),
    ]);
    _notifier.dispose();
  }
}
