import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class GameAudioSettings {
  const GameAudioSettings({
    this.masterVolume = 1,
    this.musicVolume = .8,
    this.sfxVolume = .9,
    this.masterMuted = false,
    this.musicMuted = false,
    this.sfxMuted = false,
  });

  final double masterVolume;
  final double musicVolume;
  final double sfxVolume;
  final bool masterMuted;
  final bool musicMuted;
  final bool sfxMuted;

  GameAudioSettings copyWith({
    double? masterVolume,
    double? musicVolume,
    double? sfxVolume,
    bool? masterMuted,
    bool? musicMuted,
    bool? sfxMuted,
  }) {
    return GameAudioSettings(
      masterVolume: _clamp(masterVolume ?? this.masterVolume),
      musicVolume: _clamp(musicVolume ?? this.musicVolume),
      sfxVolume: _clamp(sfxVolume ?? this.sfxVolume),
      masterMuted: masterMuted ?? this.masterMuted,
      musicMuted: musicMuted ?? this.musicMuted,
      sfxMuted: sfxMuted ?? this.sfxMuted,
    );
  }

  Map<String, Object> toJson() => <String, Object>{
    'version': 1,
    'masterVolume': masterVolume,
    'musicVolume': musicVolume,
    'sfxVolume': sfxVolume,
    'masterMuted': masterMuted,
    'musicMuted': musicMuted,
    'sfxMuted': sfxMuted,
  };

  factory GameAudioSettings.fromJson(Map<String, Object?> json) {
    return GameAudioSettings(
      masterVolume: _clamp((json['masterVolume'] as num?)?.toDouble() ?? 1),
      musicVolume: _clamp((json['musicVolume'] as num?)?.toDouble() ?? .8),
      sfxVolume: _clamp((json['sfxVolume'] as num?)?.toDouble() ?? .9),
      masterMuted: json['masterMuted'] as bool? ?? false,
      musicMuted: json['musicMuted'] as bool? ?? false,
      sfxMuted: json['sfxMuted'] as bool? ?? false,
    );
  }

  static double _clamp(double value) => value.clamp(0, 1).toDouble();
}

abstract interface class GameAudioSettingsStore {
  Future<String?> read();

  Future<void> write(String value);
}

class SharedPreferencesGameAudioSettingsStore
    implements GameAudioSettingsStore {
  SharedPreferencesGameAudioSettingsStore({SharedPreferencesAsync? preferences})
    : _preferences = preferences;

  static const storageKey = 'crazy_chess.audio_settings.v1';

  SharedPreferencesAsync? _preferences;
  String? _testFallback;

  @override
  Future<String?> read() async {
    try {
      _preferences ??= SharedPreferencesAsync();
      return await _preferences!.getString(storageKey);
    } on StateError {
      return _testFallback;
    }
  }

  @override
  Future<void> write(String value) async {
    try {
      _preferences ??= SharedPreferencesAsync();
      await _preferences!.setString(storageKey, value);
    } on StateError {
      _testFallback = value;
    }
  }
}

class GameAudioSettingsRepository {
  GameAudioSettingsRepository({required GameAudioSettingsStore store})
    : _store = store;

  final GameAudioSettingsStore _store;

  Future<GameAudioSettings> load() async {
    final source = await _store.read();
    if (source == null || source.isEmpty) {
      return const GameAudioSettings();
    }
    try {
      final decoded = jsonDecode(source);
      if (decoded is! Map<String, Object?>) {
        return const GameAudioSettings();
      }
      return GameAudioSettings.fromJson(decoded);
    } on FormatException {
      return const GameAudioSettings();
    } on TypeError {
      return const GameAudioSettings();
    }
  }

  Future<void> save(GameAudioSettings settings) {
    return _store.write(jsonEncode(settings.toJson()));
  }
}
