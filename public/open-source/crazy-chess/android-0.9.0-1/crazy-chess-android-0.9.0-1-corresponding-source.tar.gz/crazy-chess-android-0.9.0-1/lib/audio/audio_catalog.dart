enum GameMusicContext { main, court, battle, lastPiece }

class MusicCueDefinition {
  const MusicCueDefinition(
    this.id,
    this.assetPaths, {
    this.candidateLabels = const <String>[],
    this.crossfadeDuration = const Duration(milliseconds: 600),
  });

  final String id;
  final List<String> assetPaths;
  final List<String> candidateLabels;
  final Duration crossfadeDuration;

  String candidateLabelAt(int index) => candidateLabels.isEmpty
      ? '${index + 1}'
      : candidateLabels[index % candidateLabels.length];
}

class SfxCueDefinition {
  const SfxCueDefinition(this.id, this.assetPath, {this.pendingReason});

  final String id;
  final String? assetPath;
  final String? pendingReason;

  bool get isAvailable => assetPath != null;
}

abstract final class GameAudioCatalog {
  static const music = <String, MusicCueDefinition>{
    'main_theme': MusicCueDefinition('main_theme', [
      'runtime/audio/music/main_theme_a.mp3',
      'runtime/audio/music/main_theme_b.mp3',
    ]),
    'court_neutral': MusicCueDefinition('court_neutral', [
      'runtime/audio/music/court_neutral.mp3',
    ]),
    'battle_neutral': MusicCueDefinition('battle_neutral', [
      'runtime/audio/music/battle_neutral.mp3',
    ]),
    'last_piece_survival': MusicCueDefinition('last_piece_survival', [
      'runtime/audio/music/last_piece_survival.mp3',
    ]),
    'mercantile_court': MusicCueDefinition('mercantile_court', [
      'runtime/audio/music/mercantile_court_a.mp3',
      'runtime/audio/music/mercantile_court_b.mp3',
    ]),
    'mercantile_battle': MusicCueDefinition('mercantile_battle', [
      'runtime/audio/music/mercantile_battle.mp3',
    ]),
    'iron_court': MusicCueDefinition('iron_court', [
      'runtime/audio/music/iron_court.mp3',
    ]),
    'iron_battle': MusicCueDefinition('iron_battle', [
      'runtime/audio/music/iron_battle.mp3',
    ]),
    'horse_court': MusicCueDefinition('horse_court', [
      'runtime/audio/music/horse_court.mp3',
    ]),
    'horse_battle': MusicCueDefinition('horse_battle', [
      'runtime/audio/music/horse_battle.mp3',
    ]),
    'spy_court': MusicCueDefinition('spy_court', [
      'runtime/audio/music/spy_court.mp3',
    ]),
    'spy_battle': MusicCueDefinition('spy_battle', [
      'runtime/audio/music/spy_battle.mp3',
    ]),
    'campaign_map': MusicCueDefinition('campaign_map', [
      'runtime/audio/story/music/campaign_map.mp3',
    ]),
    'battle_tension': MusicCueDefinition('battle_tension', [
      'runtime/audio/story/music/battle_tension.mp3',
    ]),
    'emotional_finale': MusicCueDefinition('emotional_finale', [
      'runtime/audio/story/music/emotional_finale.mp3',
    ]),
    'living_entry_hub': MusicCueDefinition(
      'living_entry_hub',
      [
        'runtime/audio/living_campaign/music/entry_hub_a.mp3',
        'runtime/audio/living_campaign/music/entry_hub_b.mp3',
        'runtime/audio/living_campaign/music/entry_hub_c.mp3',
      ],
      candidateLabels: ['A', 'B', 'C'],
      crossfadeDuration: Duration(milliseconds: 1200),
    ),
    'living_story_briefing': MusicCueDefinition(
      'living_story_briefing',
      [
        'runtime/audio/living_campaign/music/story_briefing_b.mp3',
        'runtime/audio/living_campaign/music/story_briefing_c.mp3',
      ],
      candidateLabels: ['B', 'C'],
      crossfadeDuration: Duration(milliseconds: 1200),
    ),
    'living_battle': MusicCueDefinition(
      'living_battle',
      [
        'runtime/audio/living_campaign/music/battle_a.mp3',
        'runtime/audio/living_campaign/music/battle_b.mp3',
        'runtime/audio/living_campaign/music/battle_c.mp3',
      ],
      candidateLabels: ['A', 'B', 'C'],
      crossfadeDuration: Duration(milliseconds: 1200),
    ),
    'living_victory_result': MusicCueDefinition(
      'living_victory_result',
      [
        'runtime/audio/living_campaign/music/victory_result_a.mp3',
        'runtime/audio/living_campaign/music/victory_result_b.mp3',
        'runtime/audio/living_campaign/music/victory_result_c.mp3',
      ],
      candidateLabels: ['A', 'B', 'C'],
      crossfadeDuration: Duration(milliseconds: 2400),
    ),
    'living_defeat_result': MusicCueDefinition(
      'living_defeat_result',
      [
        'runtime/audio/living_campaign/music/defeat_result_a.mp3',
        'runtime/audio/living_campaign/music/defeat_result_c.mp3',
      ],
      candidateLabels: ['A', 'C'],
      crossfadeDuration: Duration(milliseconds: 1200),
    ),
  };

  static const sfx = <String, SfxCueDefinition>{
    'dialogue_advance': SfxCueDefinition(
      'dialogue_advance',
      null,
      pendingReason: 'Arcane Forge generation download blocked by auth',
    ),
    'node_unlock': SfxCueDefinition(
      'node_unlock',
      'runtime/audio/story/sfx/node_unlock.mp3',
    ),
    'mission_start': SfxCueDefinition(
      'mission_start',
      'runtime/audio/story/sfx/mission_start.mp3',
    ),
    'warning': SfxCueDefinition(
      'warning',
      'runtime/audio/story/sfx/warning.mp3',
    ),
    'treasure': SfxCueDefinition(
      'treasure',
      'runtime/audio/story/sfx/treasure.mp3',
    ),
    'victory': SfxCueDefinition(
      'victory',
      'runtime/audio/story/sfx/victory.mp3',
    ),
    'defeat': SfxCueDefinition('defeat', 'runtime/audio/story/sfx/defeat.mp3'),
    'piece_move': SfxCueDefinition(
      'piece_move',
      'runtime/audio/sfx/piece_move.mp3',
    ),
    'knight_leap': SfxCueDefinition(
      'knight_leap',
      'runtime/audio/sfx/knight_leap.mp3',
    ),
    'capture': SfxCueDefinition('capture', 'runtime/audio/sfx/capture.mp3'),
    'check': SfxCueDefinition('check', 'runtime/audio/sfx/check.mp3'),
    'checkmate': SfxCueDefinition(
      'checkmate',
      'runtime/audio/sfx/checkmate.mp3',
    ),
    'stalemate': SfxCueDefinition(
      'stalemate',
      'runtime/audio/sfx/stalemate.mp3',
    ),
    'castle': SfxCueDefinition('castle', 'runtime/audio/sfx/castle.mp3'),
    'promotion': SfxCueDefinition(
      'promotion',
      'runtime/audio/sfx/promotion.mp3',
    ),
    'offer_open': SfxCueDefinition(
      'offer_open',
      'runtime/audio/sfx/offer_open.mp3',
    ),
    'offer_roll': SfxCueDefinition(
      'offer_roll',
      'runtime/audio/sfx/offer_roll.mp3',
    ),
    'purchase_confirm': SfxCueDefinition(
      'purchase_confirm',
      'runtime/audio/sfx/purchase_confirm.mp3',
    ),
    'purchase_denied': SfxCueDefinition(
      'purchase_denied',
      'runtime/audio/sfx/purchase_denied.mp3',
    ),
    'betrayal_reveal': SfxCueDefinition(
      'betrayal_reveal',
      'runtime/audio/sfx/betrayal_reveal.mp3',
    ),
    'loyalty_gain': SfxCueDefinition(
      'loyalty_gain',
      'runtime/audio/sfx/loyalty_gain.mp3',
    ),
    'merchant_payout': SfxCueDefinition(
      'merchant_payout',
      'runtime/audio/sfx/merchant_payout.mp3',
    ),
    'redeploy': SfxCueDefinition('redeploy', 'runtime/audio/sfx/redeploy.mp3'),
    'shrine_blessing': SfxCueDefinition(
      'shrine_blessing',
      'runtime/audio/sfx/shrine_blessing.mp3',
    ),
    'treasure_chest_open': SfxCueDefinition(
      'treasure_chest_open',
      'runtime/audio/sfx/treasure_chest_open.mp3',
    ),
    'diamond_ring_gain': SfxCueDefinition(
      'diamond_ring_gain',
      'runtime/audio/sfx/diamond_ring_gain.mp3',
    ),
    'trap_trigger': SfxCueDefinition(
      'trap_trigger',
      'runtime/audio/sfx/trap_trigger.mp3',
    ),
    'mystery_reveal': SfxCueDefinition(
      'mystery_reveal',
      'runtime/audio/sfx/mystery_reveal.mp3',
    ),
    'transformation': SfxCueDefinition(
      'transformation',
      'runtime/audio/sfx/transformation.mp3',
    ),
    'enemy_spawn': SfxCueDefinition(
      'enemy_spawn',
      'runtime/audio/sfx/enemy_spawn.mp3',
    ),
    'wave_start': SfxCueDefinition(
      'wave_start',
      'runtime/audio/sfx/wave_start.mp3',
    ),
    'last_piece_warning': SfxCueDefinition(
      'last_piece_warning',
      'runtime/audio/sfx/last_piece_warning.mp3',
    ),
  };

  static String cueForContext(
    GameMusicContext context, {
    String countryId = 'mercantile',
    int familiarity = 0,
  }) {
    return switch (context) {
      GameMusicContext.main => 'main_theme',
      GameMusicContext.lastPiece => 'last_piece_survival',
      GameMusicContext.court =>
        familiarity >= 25 && music.containsKey('${countryId}_court')
            ? '${countryId}_court'
            : 'court_neutral',
      GameMusicContext.battle =>
        familiarity >= 100 && music.containsKey('${countryId}_battle')
            ? '${countryId}_battle'
            : 'battle_neutral',
    };
  }
}
