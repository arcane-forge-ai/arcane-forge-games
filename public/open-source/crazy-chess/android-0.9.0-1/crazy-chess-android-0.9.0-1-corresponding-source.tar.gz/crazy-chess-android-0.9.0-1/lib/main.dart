import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'crazy_chess.dart';
import 'playtest/playtest_diagnostics_factory.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final playtestDiagnostics = createPlaytestDiagnostics();
  await playtestDiagnostics.initialize();
  playtestDiagnostics.record(
    'app_started',
    data: <String, Object?>{
      'buildMode': kReleaseMode
          ? 'release'
          : kProfileMode
          ? 'profile'
          : 'debug',
    },
  );
  final previousFlutterErrorHandler = FlutterError.onError;
  FlutterError.onError = (details) {
    playtestDiagnostics.record(
      'flutter_error',
      message: details.exceptionAsString(),
      data: <String, Object?>{
        if (details.library != null) 'library': details.library,
        if (details.context != null) 'context': details.context.toString(),
        if (details.stack != null) 'stack': details.stack.toString(),
      },
    );
    previousFlutterErrorHandler?.call(details);
  };
  final previousPlatformErrorHandler =
      WidgetsBinding.instance.platformDispatcher.onError;
  WidgetsBinding.instance.platformDispatcher.onError = (error, stack) {
    playtestDiagnostics.record(
      'platform_error',
      message: error.toString(),
      data: <String, Object?>{'stack': stack.toString()},
    );
    return previousPlatformErrorHandler?.call(error, stack) ?? false;
  };
  final titleBackgroundAsset = await TitleBackgroundRotation(
    store: SharedPreferencesTitleBackgroundIndexStore(),
  ).selectForLaunch();
  final localeController = AppLocaleController(
    store: SharedPreferencesAppLanguagePreferenceStore(),
  );
  await localeController.load();
  runApp(
    CrazyChessApp(
      titleBackgroundAsset: titleBackgroundAsset,
      storyAudio: GameAudioController(),
      localeController: localeController,
      playtestDiagnostics: playtestDiagnostics,
    ),
  );
}
