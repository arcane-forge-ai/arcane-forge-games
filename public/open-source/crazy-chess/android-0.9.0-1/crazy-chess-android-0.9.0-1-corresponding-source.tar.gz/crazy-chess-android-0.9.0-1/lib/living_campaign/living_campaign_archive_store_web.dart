import 'dart:async';
import 'dart:convert';
import 'dart:js_interop';
import 'dart:typed_data';

import 'package:web/web.dart' as web;

import 'living_campaign_archive_store.dart';
import 'living_campaign_migrations.dart';
import 'living_campaign_metrics.dart';
import 'living_campaign_models.dart';

class WebLivingCampaignArchiveStore implements LivingCampaignArchiveStore {
  static const _legacyDatabaseName = 'crazy_chess_living_campaign_v1';
  static const _databaseName = 'crazy_chess_living_campaign_v2';
  static const _runsStore = 'runs';
  static const _binaryStore = 'binary';
  static const _metricsStore = 'metrics';

  web.IDBDatabase? _database;

  @override
  Future<void> initialize() async {
    if (_database != null) {
      return;
    }
    await _completeRequest(
      web.window.indexedDB.deleteDatabase(_legacyDatabaseName),
    );
    final request = web.window.indexedDB.open(_databaseName, 2);
    request.onupgradeneeded = ((web.Event _) {
      final database = request.result as web.IDBDatabase;
      if (!database.objectStoreNames.contains(_runsStore)) {
        database.createObjectStore(_runsStore);
      }
      if (!database.objectStoreNames.contains(_binaryStore)) {
        database.createObjectStore(_binaryStore);
      }
      if (!database.objectStoreNames.contains(_metricsStore)) {
        database.createObjectStore(_metricsStore);
      }
    }).toJS;
    final result = await _completeRequest(request);
    _database = result as web.IDBDatabase;
  }

  @override
  Future<void> writeRun(LivingCampaignRun run) async {
    await initialize();
    _validateId(run.runId);
    final store = _store(_runsStore, 'readwrite');
    await _completeRequest(
      store.put(
        jsonEncode(LivingCampaignRunCodec.encode(run)).toJS,
        run.runId.toJS,
      ),
    );
  }

  @override
  Future<LivingCampaignRun?> readRun(String runId) async {
    await initialize();
    _validateId(runId);
    final result = await _completeRequest(
      _store(_runsStore, 'readonly').get(runId.toJS),
    );
    if (result == null) {
      return null;
    }
    final raw = (result as JSString).toDart;
    return LivingCampaignRunCodec.decode(
      Map<String, Object?>.from(jsonDecode(raw) as Map),
    );
  }

  @override
  Future<void> writeTimingMetrics(
    LivingCampaignRunTimingMetrics metrics,
  ) async {
    await initialize();
    _validateId(metrics.runId);
    await _completeRequest(
      _store(
        _metricsStore,
        'readwrite',
      ).put(jsonEncode(metrics.toJson()).toJS, metrics.runId.toJS),
    );
  }

  @override
  Future<LivingCampaignRunTimingMetrics?> readTimingMetrics(
    String runId,
  ) async {
    await initialize();
    _validateId(runId);
    final result = await _completeRequest(
      _store(_metricsStore, 'readonly').get(runId.toJS),
    );
    if (result == null) return null;
    final metrics = LivingCampaignRunTimingMetrics.fromJson(
      Map<String, Object?>.from(jsonDecode((result as JSString).toDart) as Map),
    );
    if (metrics.runId != runId) {
      throw const FormatException('Timing metrics run id does not match key.');
    }
    return metrics;
  }

  @override
  Future<List<LivingRunArchiveSummary>> listRuns() async {
    await initialize();
    final result = await _completeRequest(
      _store(_runsStore, 'readonly').getAll(),
    );
    final values = (result! as JSArray<JSAny?>).toDart;
    final summaries = <LivingRunArchiveSummary>[];
    for (final value in values) {
      try {
        final raw = (value! as JSString).toDart;
        final run = LivingCampaignRunCodec.decode(
          Map<String, Object?>.from(jsonDecode(raw) as Map),
        );
        summaries.add(
          LivingRunArchiveSummary(
            runId: run.runId,
            status: run.status,
            createdAt: run.createdAt,
            updatedAt: run.updatedAt,
            activeChapterNumber: run.activeChapterNumber,
            chapterCount: run.canon.chapterLedger.length,
            byteSize:
                utf8.encode(raw).length + await _timingMetricsBytes(run.runId),
          ),
        );
      } on Object {
        // Isolate corrupt entries and keep the remaining archive readable.
      }
    }
    summaries.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return List.unmodifiable(summaries);
  }

  @override
  Future<void> deleteRun(String runId) async {
    await initialize();
    _validateId(runId);
    await _completeRequest(_store(_runsStore, 'readwrite').delete(runId.toJS));
    await _completeRequest(
      _store(_metricsStore, 'readwrite').delete(runId.toJS),
    );
    final keysResult = await _completeRequest(
      _store(_binaryStore, 'readonly').getAllKeys(),
    );
    final keys = (keysResult! as JSArray<JSAny?>).toDart;
    for (final keyValue in keys) {
      final key = (keyValue! as JSString).toDart;
      if (key.startsWith('$runId/')) {
        await _completeRequest(
          _store(_binaryStore, 'readwrite').delete(key.toJS),
        );
      }
    }
  }

  @override
  Future<int> storageBytes() async {
    await initialize();
    var total = 0;
    for (final storeName in <String>[_runsStore, _binaryStore, _metricsStore]) {
      final result = await _completeRequest(
        _store(storeName, 'readonly').getAll(),
      );
      for (final value in (result! as JSArray<JSAny?>).toDart) {
        total += utf8.encode((value! as JSString).toDart).length;
      }
    }
    return total;
  }

  @override
  Future<String> writeBinary({
    required String runId,
    required String fileName,
    required Uint8List bytes,
  }) async {
    await initialize();
    _validateId(runId);
    _validateFileName(fileName);
    final key = '$runId/$fileName';
    await _completeRequest(
      _store(_binaryStore, 'readwrite').put(base64Encode(bytes).toJS, key.toJS),
    );
    return 'indexeddb://$key';
  }

  @override
  Future<Uint8List?> readBinary(String reference) async {
    await initialize();
    const prefix = 'indexeddb://';
    if (!reference.startsWith(prefix)) {
      throw ArgumentError('Invalid IndexedDB binary reference.');
    }
    final key = reference.substring(prefix.length);
    final result = await _completeRequest(
      _store(_binaryStore, 'readonly').get(key.toJS),
    );
    return result == null ? null : base64Decode((result as JSString).toDart);
  }

  Future<int> _timingMetricsBytes(String runId) async {
    final result = await _completeRequest(
      _store(_metricsStore, 'readonly').get(runId.toJS),
    );
    return result == null ? 0 : utf8.encode((result as JSString).toDart).length;
  }

  web.IDBObjectStore _store(String name, web.IDBTransactionMode mode) {
    return _database!.transaction(name.toJS, mode).objectStore(name);
  }

  Future<JSAny?> _completeRequest(web.IDBRequest request) {
    final completer = Completer<JSAny?>();
    request.onsuccess = ((web.Event _) {
      if (!completer.isCompleted) {
        completer.complete(request.result);
      }
    }).toJS;
    request.onerror = ((web.Event _) {
      if (!completer.isCompleted) {
        completer.completeError(
          StateError(request.error?.message ?? 'IndexedDB request failed.'),
        );
      }
    }).toJS;
    return completer.future;
  }

  void _validateId(String value) {
    if (!RegExp(r'^[A-Za-z0-9_-]+$').hasMatch(value)) {
      throw ArgumentError.value(value, 'runId', 'Unsafe run id');
    }
  }

  void _validateFileName(String value) {
    if (!RegExp(r'^[A-Za-z0-9_.-]+$').hasMatch(value) ||
        value == '.' ||
        value == '..') {
      throw ArgumentError.value(value, 'fileName', 'Unsafe file name');
    }
  }
}
