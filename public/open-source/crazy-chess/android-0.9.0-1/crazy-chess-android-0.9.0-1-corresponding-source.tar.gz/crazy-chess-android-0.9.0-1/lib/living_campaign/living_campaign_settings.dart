import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'living_campaign_developer_env_loader.dart';

enum LivingSettingSource { builtIn, player, developerEnv, previewBundle }

enum LivingCapabilityStatus { untested, testing, available, failed }

enum LivingLogLevel {
  off,
  summary,
  full;

  static LivingLogLevel parse(String? value) => values.firstWhere(
    (candidate) => candidate.name == value?.trim().toLowerCase(),
    orElse: () => LivingLogLevel.off,
  );
}

@immutable
class LivingCampaignSettings {
  const LivingCampaignSettings({
    this.apiKey = '',
    this.baseUrl = defaultBaseUrl,
    this.textModel = defaultTextModel,
    this.imageModel = defaultImageModel,
    this.textLogLevel = LivingLogLevel.off,
    this.imageLogLevel = LivingLogLevel.off,
    this.logStages = defaultLogStages,
  });

  static const defaultBaseUrl = 'https://ark.cn-beijing.volces.com/api/v3';
  static const defaultTextModel = 'doubao-seed-2-1-turbo-260628';
  static const defaultImageModel = 'doubao-seedream-5-0-260128';
  static const defaultLogStages = <String>{
    'chronicler',
    'director',
    'builder',
    'history',
    'portrait',
    'chapter_art',
  };

  final String apiKey;
  final String baseUrl;
  final String textModel;
  final String imageModel;
  final LivingLogLevel textLogLevel;
  final LivingLogLevel imageLogLevel;
  final Set<String> logStages;

  bool get hasApiKey => apiKey.trim().isNotEmpty;

  LivingCampaignSettings normalized() => LivingCampaignSettings(
    apiKey: apiKey.trim(),
    baseUrl: _normalizeBaseUrl(baseUrl),
    textModel: textModel.trim().isEmpty ? defaultTextModel : textModel.trim(),
    imageModel: imageModel.trim().isEmpty
        ? defaultImageModel
        : imageModel.trim(),
    textLogLevel: textLogLevel,
    imageLogLevel: imageLogLevel,
    logStages: _normalizeStages(logStages),
  );

  LivingCampaignSettings copyWith({
    String? apiKey,
    String? baseUrl,
    String? textModel,
    String? imageModel,
    LivingLogLevel? textLogLevel,
    LivingLogLevel? imageLogLevel,
    Set<String>? logStages,
  }) => LivingCampaignSettings(
    apiKey: apiKey ?? this.apiKey,
    baseUrl: baseUrl ?? this.baseUrl,
    textModel: textModel ?? this.textModel,
    imageModel: imageModel ?? this.imageModel,
    textLogLevel: textLogLevel ?? this.textLogLevel,
    imageLogLevel: imageLogLevel ?? this.imageLogLevel,
    logStages: logStages ?? this.logStages,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'apiKey': apiKey,
    'baseUrl': baseUrl,
    'textModel': textModel,
    'imageModel': imageModel,
    'textLogLevel': textLogLevel.name,
    'imageLogLevel': imageLogLevel.name,
    'logStages': logStages.toList()..sort(),
  };

  factory LivingCampaignSettings.fromJson(Map<String, Object?> json) {
    return LivingCampaignSettings(
      apiKey: json['apiKey'] as String? ?? '',
      baseUrl: json['baseUrl'] as String? ?? defaultBaseUrl,
      textModel: json['textModel'] as String? ?? defaultTextModel,
      imageModel: json['imageModel'] as String? ?? defaultImageModel,
      textLogLevel: LivingLogLevel.parse(json['textLogLevel'] as String?),
      imageLogLevel: LivingLogLevel.parse(json['imageLogLevel'] as String?),
      logStages:
          (json['logStages'] as List<Object?>?)?.whereType<String>().toSet() ??
          defaultLogStages,
    ).normalized();
  }

  static String _normalizeBaseUrl(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) {
      return defaultBaseUrl;
    }
    return trimmed.endsWith('/')
        ? trimmed.substring(0, trimmed.length - 1)
        : trimmed;
  }

  static Set<String> _normalizeStages(Iterable<String> values) {
    final normalized = values
        .map((value) => value.trim().toLowerCase())
        .where((value) => value.isNotEmpty)
        .toSet();
    return Set<String>.unmodifiable(
      normalized.isEmpty ? defaultLogStages : normalized,
    );
  }
}

@immutable
class LivingDeveloperEnvironment {
  const LivingDeveloperEnvironment({
    this.apiKey = '',
    this.baseUrl = '',
    this.textModel = '',
    this.imageModel = '',
    this.textLogLevel = '',
    this.imageLogLevel = '',
    this.logStages = '',
  });

  factory LivingDeveloperEnvironment.compileTime() {
    if (!kDebugMode) {
      return const LivingDeveloperEnvironment();
    }
    return const LivingDeveloperEnvironment(
      apiKey: String.fromEnvironment('ARK_API_KEY'),
      baseUrl: String.fromEnvironment('ARK_BASE_URL'),
      textModel: String.fromEnvironment('LIVING_CAMPAIGN_TEXT_MODEL'),
      imageModel: String.fromEnvironment('LIVING_CAMPAIGN_IMAGE_MODEL'),
      textLogLevel: String.fromEnvironment('LIVING_TEXT_LOG_LEVEL'),
      imageLogLevel: String.fromEnvironment('LIVING_IMAGE_LOG_LEVEL'),
      logStages: String.fromEnvironment('LIVING_LOG_STAGES'),
    );
  }

  factory LivingDeveloperEnvironment.fromDotEnv(String source) {
    const allowedKeys = <String>{
      'ARK_API_KEY',
      'ARK_BASE_URL',
      'LIVING_CAMPAIGN_TEXT_MODEL',
      'LIVING_CAMPAIGN_IMAGE_MODEL',
      'LIVING_TEXT_LOG_LEVEL',
      'LIVING_IMAGE_LOG_LEVEL',
      'LIVING_LOG_STAGES',
    };
    final values = <String, String>{};
    for (final rawLine in const LineSplitter().convert(source)) {
      var line = rawLine.trim();
      if (line.isEmpty || line.startsWith('#')) {
        continue;
      }
      if (line.startsWith('export ')) {
        line = line.substring('export '.length).trimLeft();
      }
      final separator = line.indexOf('=');
      if (separator <= 0) {
        continue;
      }
      final key = line.substring(0, separator).trim();
      if (!allowedKeys.contains(key)) {
        continue;
      }
      var value = line.substring(separator + 1).trim();
      if (value.length >= 2 &&
          ((value.startsWith('"') && value.endsWith('"')) ||
              (value.startsWith("'") && value.endsWith("'")))) {
        value = value.substring(1, value.length - 1);
      }
      values[key] = value;
    }
    return LivingDeveloperEnvironment(
      apiKey: values['ARK_API_KEY'] ?? '',
      baseUrl: values['ARK_BASE_URL'] ?? '',
      textModel: values['LIVING_CAMPAIGN_TEXT_MODEL'] ?? '',
      imageModel: values['LIVING_CAMPAIGN_IMAGE_MODEL'] ?? '',
      textLogLevel: values['LIVING_TEXT_LOG_LEVEL'] ?? '',
      imageLogLevel: values['LIVING_IMAGE_LOG_LEVEL'] ?? '',
      logStages: values['LIVING_LOG_STAGES'] ?? '',
    );
  }

  static Future<LivingDeveloperEnvironment> debugWorkspaceFile() async {
    if (!kDebugMode) {
      return const LivingDeveloperEnvironment();
    }
    final source = await readLivingCampaignDeveloperEnvironmentFile();
    return source == null
        ? const LivingDeveloperEnvironment()
        : LivingDeveloperEnvironment.fromDotEnv(source);
  }

  final String apiKey;
  final String baseUrl;
  final String textModel;
  final String imageModel;
  final String textLogLevel;
  final String imageLogLevel;
  final String logStages;

  bool get hasAnyOverride =>
      apiKey.trim().isNotEmpty ||
      baseUrl.trim().isNotEmpty ||
      textModel.trim().isNotEmpty ||
      imageModel.trim().isNotEmpty ||
      textLogLevel.trim().isNotEmpty ||
      imageLogLevel.trim().isNotEmpty ||
      logStages.trim().isNotEmpty;

  LivingDeveloperEnvironment overlay(LivingDeveloperEnvironment preferred) {
    String choose(String value, String fallback) =>
        value.trim().isNotEmpty ? value.trim() : fallback.trim();
    return LivingDeveloperEnvironment(
      apiKey: choose(preferred.apiKey, apiKey),
      baseUrl: choose(preferred.baseUrl, baseUrl),
      textModel: choose(preferred.textModel, textModel),
      imageModel: choose(preferred.imageModel, imageModel),
      textLogLevel: choose(preferred.textLogLevel, textLogLevel),
      imageLogLevel: choose(preferred.imageLogLevel, imageLogLevel),
      logStages: choose(preferred.logStages, logStages),
    );
  }
}

@immutable
class PreviewBuildConfig {
  const PreviewBuildConfig({
    this.enabled = false,
    this.label = 'Preview',
    this.apiKey = '',
    this.baseUrl = LivingCampaignSettings.defaultBaseUrl,
    this.textModel = LivingCampaignSettings.defaultTextModel,
    this.imageModel = LivingCampaignSettings.defaultImageModel,
  });

  static const current = PreviewBuildConfig(
    enabled: kReleaseMode && bool.fromEnvironment('CRAZY_CHESS_PREVIEW_BUILD'),
    label: String.fromEnvironment(
      'CRAZY_CHESS_PREVIEW_LABEL',
      defaultValue: 'Preview',
    ),
    apiKey: String.fromEnvironment('ARK_API_KEY'),
    baseUrl: String.fromEnvironment(
      'ARK_BASE_URL',
      defaultValue: LivingCampaignSettings.defaultBaseUrl,
    ),
    textModel: String.fromEnvironment(
      'LIVING_CAMPAIGN_TEXT_MODEL',
      defaultValue: LivingCampaignSettings.defaultTextModel,
    ),
    imageModel: String.fromEnvironment(
      'LIVING_CAMPAIGN_IMAGE_MODEL',
      defaultValue: LivingCampaignSettings.defaultImageModel,
    ),
  );

  final bool enabled;
  final String label;
  final String apiKey;
  final String baseUrl;
  final String textModel;
  final String imageModel;

  bool get hasApiKey => apiKey.trim().isNotEmpty;

  LivingCampaignSettings get settings => LivingCampaignSettings(
    apiKey: apiKey,
    baseUrl: baseUrl,
    textModel: textModel,
    imageModel: imageModel,
  ).normalized();
}

@immutable
class EffectiveLivingCampaignSettings {
  const EffectiveLivingCampaignSettings({
    required this.values,
    required this.sources,
  });

  final LivingCampaignSettings values;
  final Map<String, LivingSettingSource> sources;

  bool isDeveloperOverride(String field) =>
      sources[field] == LivingSettingSource.developerEnv;

  bool isPreviewBundle(String field) =>
      sources[field] == LivingSettingSource.previewBundle;

  factory EffectiveLivingCampaignSettings.resolve({
    required LivingCampaignSettings saved,
    required LivingDeveloperEnvironment developer,
    PreviewBuildConfig preview = PreviewBuildConfig.current,
  }) {
    if (preview.enabled) {
      final values = preview.settings;
      return EffectiveLivingCampaignSettings(
        values: values,
        sources: <String, LivingSettingSource>{
          for (final field in const <String>{
            'apiKey',
            'baseUrl',
            'textModel',
            'imageModel',
            'textLogLevel',
            'imageLogLevel',
            'logStages',
          })
            field: LivingSettingSource.previewBundle,
        },
      );
    }
    final normalizedSaved = saved.normalized();
    String choose(String developerValue, String savedValue) =>
        developerValue.trim().isNotEmpty ? developerValue.trim() : savedValue;
    LivingSettingSource sourceFor(
      String developerValue,
      String savedValue,
      String builtIn,
    ) {
      if (developerValue.trim().isNotEmpty) {
        return LivingSettingSource.developerEnv;
      }
      return savedValue != builtIn && savedValue.trim().isNotEmpty
          ? LivingSettingSource.player
          : LivingSettingSource.builtIn;
    }

    final resolved = LivingCampaignSettings(
      apiKey: choose(developer.apiKey, normalizedSaved.apiKey),
      baseUrl: choose(developer.baseUrl, normalizedSaved.baseUrl),
      textModel: choose(developer.textModel, normalizedSaved.textModel),
      imageModel: choose(developer.imageModel, normalizedSaved.imageModel),
      textLogLevel: developer.textLogLevel.trim().isNotEmpty
          ? LivingLogLevel.parse(developer.textLogLevel)
          : normalizedSaved.textLogLevel,
      imageLogLevel: developer.imageLogLevel.trim().isNotEmpty
          ? LivingLogLevel.parse(developer.imageLogLevel)
          : normalizedSaved.imageLogLevel,
      logStages: developer.logStages.trim().isNotEmpty
          ? developer.logStages
                .split(',')
                .map((value) => value.trim())
                .where((value) => value.isNotEmpty)
                .toSet()
          : normalizedSaved.logStages,
    ).normalized();
    return EffectiveLivingCampaignSettings(
      values: resolved,
      sources: <String, LivingSettingSource>{
        'apiKey': sourceFor(developer.apiKey, normalizedSaved.apiKey, ''),
        'baseUrl': sourceFor(
          developer.baseUrl,
          normalizedSaved.baseUrl,
          LivingCampaignSettings.defaultBaseUrl,
        ),
        'textModel': sourceFor(
          developer.textModel,
          normalizedSaved.textModel,
          LivingCampaignSettings.defaultTextModel,
        ),
        'imageModel': sourceFor(
          developer.imageModel,
          normalizedSaved.imageModel,
          LivingCampaignSettings.defaultImageModel,
        ),
        'textLogLevel': sourceFor(
          developer.textLogLevel,
          normalizedSaved.textLogLevel.name,
          LivingLogLevel.off.name,
        ),
        'imageLogLevel': sourceFor(
          developer.imageLogLevel,
          normalizedSaved.imageLogLevel.name,
          LivingLogLevel.off.name,
        ),
        'logStages': sourceFor(
          developer.logStages,
          (normalizedSaved.logStages.toList()..sort()).join(','),
          (LivingCampaignSettings.defaultLogStages.toList()..sort()).join(','),
        ),
      },
    );
  }
}

abstract interface class LivingCampaignSettingsStore {
  Future<String?> read();
  Future<void> write(String value);
  Future<void> clear();
}

class SharedPreferencesLivingCampaignSettingsStore
    implements LivingCampaignSettingsStore {
  SharedPreferencesLivingCampaignSettingsStore({
    SharedPreferencesAsync? preferences,
  }) : _preferences = preferences;

  static const storageKey = 'living_campaign_provider_settings_v1';
  SharedPreferencesAsync? _preferences;

  Future<SharedPreferencesAsync> get _prefs async =>
      _preferences ??= SharedPreferencesAsync();

  @override
  Future<String?> read() async => (await _prefs).getString(storageKey);

  @override
  Future<void> write(String value) async {
    await (await _prefs).setString(storageKey, value);
  }

  @override
  Future<void> clear() async {
    await (await _prefs).remove(storageKey);
  }
}

class LivingCampaignSettingsRepository {
  LivingCampaignSettingsRepository({required this.store});

  final LivingCampaignSettingsStore store;

  Future<LivingCampaignSettings> load() async {
    final raw = await store.read();
    if (raw == null || raw.isEmpty) {
      return const LivingCampaignSettings();
    }
    try {
      return LivingCampaignSettings.fromJson(
        Map<String, Object?>.from(jsonDecode(raw) as Map),
      );
    } on Object {
      return const LivingCampaignSettings();
    }
  }

  Future<void> save(LivingCampaignSettings settings) =>
      store.write(jsonEncode(settings.normalized().toJson()));

  Future<void> deleteApiKey({required LivingCampaignSettings current}) =>
      save(current.copyWith(apiKey: ''));
}

typedef LivingDeveloperEnvironmentLoader =
    Future<LivingDeveloperEnvironment> Function();

class LivingCampaignSettingsController extends ChangeNotifier {
  LivingCampaignSettingsController({
    LivingCampaignSettingsRepository? repository,
    LivingDeveloperEnvironment? developerEnvironment,
    LivingDeveloperEnvironmentLoader? developerEnvironmentLoader,
    this.previewBuildConfig = PreviewBuildConfig.current,
  }) : repository =
           repository ??
           LivingCampaignSettingsRepository(
             store: SharedPreferencesLivingCampaignSettingsStore(),
           ),
       developerEnvironment =
           developerEnvironment ?? LivingDeveloperEnvironment.compileTime(),
       _developerEnvironmentLoader =
           developerEnvironmentLoader ??
           (developerEnvironment == null
               ? LivingDeveloperEnvironment.debugWorkspaceFile
               : null);

  final LivingCampaignSettingsRepository repository;
  final PreviewBuildConfig previewBuildConfig;
  LivingDeveloperEnvironment developerEnvironment;
  final LivingDeveloperEnvironmentLoader? _developerEnvironmentLoader;

  LivingCampaignSettings saved = const LivingCampaignSettings();
  LivingCapabilityStatus capabilityStatus = LivingCapabilityStatus.untested;
  String? capabilityMessage;
  bool initialized = false;

  EffectiveLivingCampaignSettings get effective =>
      EffectiveLivingCampaignSettings.resolve(
        saved: saved,
        developer: developerEnvironment,
        preview: previewBuildConfig,
      );

  bool get isPreviewBuild => previewBuildConfig.enabled;
  String get previewLabel => previewBuildConfig.label.trim().isEmpty
      ? 'Preview'
      : previewBuildConfig.label.trim();

  Future<void> initialize() async {
    if (_developerEnvironmentLoader case final loader?) {
      try {
        developerEnvironment = developerEnvironment.overlay(await loader());
      } on Object {
        // A missing or sandbox-inaccessible workspace file is equivalent to
        // no developer override. Player settings and built-ins remain usable.
      }
    }
    try {
      saved = await repository.load();
    } on Object {
      // Asset-light widget tests and unsupported embedding environments may
      // not register the preferences plugin. Built-in defaults remain usable.
      saved = const LivingCampaignSettings();
    }
    initialized = true;
    notifyListeners();
  }

  Future<void> save(LivingCampaignSettings next) async {
    saved = next.normalized();
    capabilityStatus = LivingCapabilityStatus.untested;
    capabilityMessage = null;
    await repository.save(saved);
    notifyListeners();
  }

  Future<void> deleteApiKey() async {
    saved = saved.copyWith(apiKey: '');
    capabilityStatus = LivingCapabilityStatus.untested;
    capabilityMessage = null;
    await repository.save(saved);
    notifyListeners();
  }

  void markCapabilityTesting() {
    capabilityStatus = LivingCapabilityStatus.testing;
    capabilityMessage = null;
    notifyListeners();
  }

  void markCapabilityAvailable() {
    capabilityStatus = LivingCapabilityStatus.available;
    capabilityMessage = 'Ark text generation is available.';
    notifyListeners();
  }

  void markCapabilityFailed(String safeMessage) {
    capabilityStatus = LivingCapabilityStatus.failed;
    capabilityMessage = safeMessage;
    notifyListeners();
  }
}
