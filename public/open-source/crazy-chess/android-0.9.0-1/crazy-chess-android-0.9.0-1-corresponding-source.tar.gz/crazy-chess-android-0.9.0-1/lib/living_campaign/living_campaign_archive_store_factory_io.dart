import 'living_campaign_archive_store.dart';
import 'living_campaign_archive_store_io.dart';

LivingCampaignArchiveStore createPlatformLivingCampaignArchiveStore() =>
    IoLivingCampaignArchiveStore();
