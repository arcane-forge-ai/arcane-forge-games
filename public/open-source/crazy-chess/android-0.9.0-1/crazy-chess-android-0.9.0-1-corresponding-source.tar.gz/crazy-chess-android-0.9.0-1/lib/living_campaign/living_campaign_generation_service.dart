import 'dart:async';
import 'dart:convert';

import 'doubao_client.dart';
import 'living_campaign_archive_store.dart';
import 'living_campaign_context.dart';
import 'living_campaign_models.dart';
import 'living_campaign_locale_contract.dart';
import 'living_campaign_prompt_library.dart';
import 'living_campaign_validator.dart';

abstract interface class LivingGenerationGateway {
  String get textModel;
  String get imageModel;

  Future<DoubaoTokenizationResult> countTextTokens(Iterable<String> values);

  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    int maxTokens,
    double temperature,
    DoubaoStreamProgressCallback? onProgress,
  });

  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
  });
}

class DoubaoLivingGenerationGateway implements LivingGenerationGateway {
  const DoubaoLivingGenerationGateway(this.client);

  final DoubaoClient client;

  @override
  String get textModel => client.settings.textModel;

  @override
  String get imageModel => client.settings.imageModel;

  @override
  Future<DoubaoTokenizationResult> countTextTokens(Iterable<String> values) =>
      client.countTextTokens(values);

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    int maxTokens = 8192,
    double temperature = .25,
    DoubaoStreamProgressCallback? onProgress,
  }) => client.chatJson(
    systemPrompt: systemPrompt,
    userPayload: userPayload,
    maxTokens: maxTokens,
    temperature: temperature,
    onProgress: onProgress,
  );

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
  }) => client.generatePortrait(prompt: prompt, seed: seed);
}

class LivingGenerationResult {
  const LivingGenerationResult({
    required this.run,
    required this.completed,
    this.message,
  });

  final LivingCampaignRun run;
  final bool completed;
  final String? message;
}

typedef LivingClock = DateTime Function();
typedef LivingIdFactory = String Function(String prefix);
typedef LivingGenerationProgressCallback =
    FutureOr<void> Function(LivingCampaignRun run);

class LivingCampaignGenerationService {
  LivingCampaignGenerationService({
    required LivingGenerationGateway gateway,
    required LivingCampaignArchiveStore archive,
    LivingCampaignValidator validator = const LivingCampaignValidator(),
    LivingCanonContextBuilder contextBuilder =
        const LivingCanonContextBuilder(),
    LivingCampaignPromptLibrary? promptLibrary,
    LivingClock? clock,
    LivingIdFactory? idFactory,
    LivingGenerationProgressCallback? onProgress,
  }) : _gateway = gateway,
       _archive = archive,
       _validator = validator,
       _contextBuilder = contextBuilder,
       _promptLibrary = promptLibrary ?? AssetLivingCampaignPromptLibrary(),
       _clock = clock ?? DateTime.now,
       _idFactory = idFactory ?? _defaultId,
       _onProgress = onProgress;

  final LivingGenerationGateway _gateway;
  final LivingCampaignArchiveStore _archive;
  final LivingCampaignValidator _validator;
  final LivingCanonContextBuilder _contextBuilder;
  final LivingCampaignPromptLibrary _promptLibrary;
  final LivingClock _clock;
  final LivingIdFactory _idFactory;
  final LivingGenerationProgressCallback? _onProgress;

  static int _idCounter = 0;

  static String _defaultId(String prefix) {
    _idCounter++;
    return '$prefix-${DateTime.now().toUtc().microsecondsSinceEpoch}-$_idCounter';
  }

  Future<String> _loadPrompt(
    LivingCampaignRun run,
    LivingCampaignPrompt prompt,
  ) async {
    try {
      return await _promptLibrary.load(prompt);
    } on Object {
      throw _LivingCallFailure(
        run: run,
        error: LivingProviderException(
          code: 'prompt_asset_unavailable',
          safeMessage:
              'The Living Campaign ${prompt.name} prompt could not be loaded. '
              'Rebuild or reinstall the game before retrying.',
        ),
      );
    }
  }

  Future<LivingGenerationResult> generatePrologue(LivingCampaignRun run) async {
    await _archive.initialize();
    if (run.status != LivingRunStatus.active || run.battleOutcomes.isNotEmpty) {
      return LivingGenerationResult(
        run: run,
        completed: false,
        message: 'A prologue can only be generated before the first battle.',
      );
    }
    final completedInitial = _latestCompletedRecord(
      run,
      LivingGenerationStage.prologue,
    );
    final completedRepair = _latestCompletedRecord(
      run,
      LivingGenerationStage.prologueRepair,
    );
    final resumeStage =
        completedRepair != null ||
            (completedInitial != null &&
                run.generationJob?.stage ==
                    LivingGenerationStage.prologueRepair)
        ? LivingGenerationStage.prologueRepair
        : LivingGenerationStage.prologue;
    var current = run.copyWith(
      updatedAt: _clock(),
      generationJob: _startingJob(run, resumeStage),
    );
    await _persist(current);
    final payload = <String, Object?>{
      'continuityContract': LivingCanonContextBuilder.continuityContract,
      'initialCanon': current.canon.toJson(),
      'fixedChapterOne': current.chapterPackages.first.toJson(),
      'requiredTone': 'severe non-graphic dark fantasy',
    };
    try {
      Map<String, Object?> opening;
      if (completedRepair != null) {
        opening = completedRepair.responsePayload;
        final issues = <String>[
          ..._prologueIssues(opening),
          ...LivingChineseContentValidator.validateResponse(
            opening,
            current.contentLocale,
          ),
        ];
        if (issues.isNotEmpty) {
          return _failValidation(
            current,
            LivingGenerationStage.prologueRepair,
            issues,
          );
        }
      } else {
        if (completedInitial == null) {
          final call = await _callJson(
            run: current,
            stage: LivingGenerationStage.prologue,
            attempt: 1,
            systemPrompt: await _loadPrompt(
              current,
              LivingCampaignPrompt.prologue,
            ),
            payload: payload,
            maxTokens: 1400,
          );
          current = call.run;
          opening = call.response.value;
        } else {
          opening = completedInitial.responsePayload;
        }
        var issues = <String>[
          ..._prologueIssues(opening),
          ...LivingChineseContentValidator.validateResponse(
            opening,
            current.contentLocale,
          ),
        ];
        if (issues.isNotEmpty) {
          current = await _setRunningJob(
            current,
            LivingGenerationStage.prologueRepair,
            attempt: 2,
          );
          final repairCall = await _callJson(
            run: current,
            stage: LivingGenerationStage.prologueRepair,
            attempt: 2,
            systemPrompt: await _loadPrompt(
              current,
              LivingCampaignPrompt.prologueRepair,
            ),
            payload: <String, Object?>{
              ...payload,
              'invalidPrologue': opening,
              'validationIssues': issues,
            },
            maxTokens: 1400,
          );
          current = repairCall.run;
          opening = repairCall.response.value;
          issues = <String>[
            ..._prologueIssues(opening),
            ...LivingChineseContentValidator.validateResponse(
              opening,
              current.contentLocale,
            ),
          ];
          if (issues.isNotEmpty) {
            return _failValidation(
              current,
              LivingGenerationStage.prologueRepair,
              issues,
            );
          }
        }
      }
      current = current.copyWith(
        updatedAt: _clock(),
        campaignTitle: opening['campaignTitle']! as String,
        storyPromise: opening['storyPromise']! as String,
        prologue: opening['prologue']! as String,
        clearGenerationJob: true,
      );
      await _persist(current);
      return LivingGenerationResult(run: current, completed: true);
    } on _LivingCallFailure catch (failure) {
      final paused = failure.run.copyWith(
        updatedAt: _clock(),
        generationJob: _jobWithFailure(
          failure.run.generationJob,
          failure.error,
          LivingGenerationStatus.awaitingResume,
        ),
      );
      await _persist(paused);
      return LivingGenerationResult(
        run: paused,
        completed: false,
        message: failure.error.safeMessage,
      );
    }
  }

  Future<LivingGenerationResult> generateNextChapter({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  }) async {
    await _archive.initialize();
    final eligibilityIssue = _generationEligibilityIssue(run, outcome);
    if (eligibilityIssue != null) {
      return LivingGenerationResult(
        run: run,
        completed: false,
        message: eligibilityIssue,
      );
    }

    final existingCheckpoint = run.generationCheckpoint;
    final resumeStage = existingCheckpoint == null
        ? LivingGenerationStage.director
        : existingCheckpoint.chapterPackage == null
        ? LivingGenerationStage.builder
        : LivingGenerationStage.portrait;
    var current = run.copyWith(
      updatedAt: _clock(),
      battleOutcomes:
          run.battleOutcomes.any(
            (candidate) => candidate.chapterId == outcome.chapterId,
          )
          ? run.battleOutcomes
          : <LivingBattleOutcomeSnapshot>[...run.battleOutcomes, outcome],
      generationJob: _startingJob(run, resumeStage),
    );
    await _persist(current);

    try {
      late LivingDirectorPatch lockedPatch;
      var lockedCanon = current.canon;
      if (existingCheckpoint == null) {
        var directorProjection = _contextBuilder.complete(
          canon: current.canon,
          outcome: outcome,
        );
        var directorCall = await _callWithContextRecovery(
          run: current,
          jobStage: LivingGenerationStage.director,
          attempt: 1,
          systemPrompt: await _loadPrompt(
            current,
            LivingCampaignPrompt.director,
          ),
          projection: directorProjection,
          outcome: outcome,
          extraPayload: const <String, Object?>{},
          maxTokens: 8192,
        );
        current = directorCall.run;
        directorProjection = directorCall.projection;

        LivingDirectorPatch? patch;
        LivingCanonState? nextCanon;
        var directorIssues = <String>[];
        try {
          patch = LivingDirectorPatch.fromJson(directorCall.response.value);
          nextCanon = _validator.applyDirectorPatch(
            canon: directorProjection.canon,
            outcome: outcome,
            patch: patch,
          );
        } on Object catch (error) {
          directorIssues = _safeIssues(error);
        }
        directorIssues.addAll(
          LivingChineseContentValidator.validateResponse(
            directorCall.response.value,
            current.contentLocale,
          ),
        );
        if (patch == null || nextCanon == null || directorIssues.isNotEmpty) {
          current = await _setRunningJob(
            current,
            LivingGenerationStage.directorRepair,
            attempt: 2,
          );
          final repairCall = await _callWithContextRecovery(
            run: current,
            jobStage: LivingGenerationStage.directorRepair,
            attempt: 2,
            systemPrompt: await _loadPrompt(
              current,
              LivingCampaignPrompt.directorRepair,
            ),
            projection: directorProjection,
            outcome: outcome,
            extraPayload: <String, Object?>{
              'invalidDirectorPatch': directorCall.response.value,
              'validationIssues': directorIssues,
            },
            maxTokens: 8192,
          );
          current = repairCall.run;
          directorProjection = repairCall.projection;
          try {
            patch = LivingDirectorPatch.fromJson(repairCall.response.value);
            nextCanon = _validator.applyDirectorPatch(
              canon: directorProjection.canon,
              outcome: outcome,
              patch: patch,
            );
            directorIssues = LivingChineseContentValidator.validateResponse(
              repairCall.response.value,
              current.contentLocale,
            );
          } on Object catch (error) {
            return _failValidation(
              current,
              LivingGenerationStage.directorRepair,
              _safeIssues(error),
            );
          }
          if (directorIssues.isNotEmpty) {
            return _failValidation(
              current,
              LivingGenerationStage.directorRepair,
              directorIssues,
            );
          }
        }

        lockedPatch = patch;
        lockedCanon = nextCanon;
        if (lockedPatch.campaignComplete) {
          current = current.copyWith(
            status: LivingRunStatus.completed,
            updatedAt: _clock(),
            completedAt: _clock(),
            epilogue: lockedPatch.epilogue,
            canon: lockedCanon,
            clearGenerationJob: true,
            clearGenerationCheckpoint: true,
          );
          await _persist(current);
          return LivingGenerationResult(run: current, completed: true);
        }

        current = current.copyWith(
          updatedAt: _clock(),
          canon: lockedCanon,
          generationCheckpoint: LivingChapterGenerationCheckpoint(
            outcomeChapterId: outcome.chapterId,
            directorPatch: lockedPatch,
          ),
        );
        await _persist(current);
      } else {
        final checkpointIssues = _checkpointIssues(
          run: current,
          outcome: outcome,
          checkpoint: existingCheckpoint,
        );
        if (checkpointIssues.isNotEmpty) {
          return _failValidation(current, resumeStage, checkpointIssues);
        }
        lockedPatch = existingCheckpoint.directorPatch;
        lockedCanon = current.canon;
      }

      var chapter = current.generationCheckpoint?.chapterPackage;
      if (chapter == null) {
        current = await _setRunningJob(
          current,
          LivingGenerationStage.builder,
          attempt: 1,
        );
        var builderProjection = _contextBuilder.complete(
          canon: lockedCanon,
          outcome: outcome,
        );
        var builderCall = await _callWithContextRecovery(
          run: current,
          jobStage: LivingGenerationStage.builder,
          attempt: 1,
          systemPrompt: await _loadPrompt(
            current,
            LivingCampaignPrompt.builder,
          ),
          projection: builderProjection,
          outcome: outcome,
          extraPayload: <String, Object?>{
            'lockedDirectorIntent': lockedPatch.nextChapterIntent.toJson(),
          },
          maxTokens: 8192,
        );
        current = builderCall.run;
        builderProjection = builderCall.projection;
        lockedCanon = builderProjection.canon;

        var builderIssues = <String>[];
        try {
          chapter = LivingChapterPackage.fromJson(builderCall.response.value);
          builderIssues = _validator.validateChapterPackage(
            canon: lockedCanon,
            intent: lockedPatch.nextChapterIntent,
            package: chapter,
          );
          builderIssues.addAll(
            LivingChineseContentValidator.validateResponse(
              builderCall.response.value,
              current.contentLocale,
            ),
          );
        } on Object catch (error) {
          builderIssues = _safeIssues(error);
        }
        if (chapter == null || builderIssues.isNotEmpty) {
          current = await _setRunningJob(
            current,
            LivingGenerationStage.builderRepair,
            attempt: 2,
          );
          final repairCall = await _callWithContextRecovery(
            run: current,
            jobStage: LivingGenerationStage.builderRepair,
            attempt: 2,
            systemPrompt: await _loadPrompt(
              current,
              LivingCampaignPrompt.builderRepair,
            ),
            projection: builderProjection,
            outcome: outcome,
            extraPayload: <String, Object?>{
              'lockedDirectorIntent': lockedPatch.nextChapterIntent.toJson(),
              'invalidChapterPackage': builderCall.response.value,
              'validationIssues': builderIssues,
            },
            maxTokens: 8192,
          );
          current = repairCall.run;
          lockedCanon = repairCall.projection.canon;
          try {
            chapter = LivingChapterPackage.fromJson(repairCall.response.value);
            builderIssues = _validator.validateChapterPackage(
              canon: lockedCanon,
              intent: lockedPatch.nextChapterIntent,
              package: chapter,
            );
            builderIssues.addAll(
              LivingChineseContentValidator.validateResponse(
                repairCall.response.value,
                current.contentLocale,
              ),
            );
          } on Object catch (error) {
            builderIssues = _safeIssues(error);
          }
          if (chapter == null || builderIssues.isNotEmpty) {
            return _failValidation(
              current,
              LivingGenerationStage.builderRepair,
              builderIssues,
            );
          }
        }

        current = current.copyWith(
          canon: lockedCanon,
          updatedAt: _clock(),
          generationCheckpoint: current.generationCheckpoint!.copyWith(
            chapterPackage: chapter,
          ),
        );
        await _persist(current);
      }

      final portraitCharacter = chapter.portraitCharacterId == null
          ? null
          : lockedCanon.charactersById[chapter.portraitCharacterId!];
      if (chapter.portraitCharacterId != null &&
          portraitCharacter?.portraitPath == null) {
        final portraitResult = await _generateRequiredPortrait(
          run: current,
          canon: lockedCanon,
          chapter: chapter,
        );
        current = portraitResult.run;
        lockedCanon = portraitResult.canon;
      }

      current = current.copyWith(
        updatedAt: _clock(),
        activeChapterNumber: chapter.chapterNumber,
        canon: lockedCanon,
        chapterPackages: <LivingChapterPackage>[
          ...current.chapterPackages,
          chapter,
        ],
        clearGenerationJob: true,
        clearGenerationCheckpoint: true,
      );
      await _persist(current);
      return LivingGenerationResult(run: current, completed: true);
    } on _LivingCallFailure catch (failure) {
      final paused = failure.run.copyWith(
        updatedAt: _clock(),
        generationJob: _jobWithFailure(
          failure.run.generationJob,
          failure.error,
          LivingGenerationStatus.awaitingResume,
        ),
      );
      await _persist(paused);
      return LivingGenerationResult(
        run: paused,
        completed: false,
        message: failure.error.safeMessage,
      );
    } on LivingProviderException catch (error) {
      final paused = current.copyWith(
        updatedAt: _clock(),
        generationJob: _jobWithFailure(
          current.generationJob,
          error,
          LivingGenerationStatus.awaitingResume,
        ),
      );
      await _persist(paused);
      return LivingGenerationResult(
        run: paused,
        completed: false,
        message: error.safeMessage,
      );
    }
  }

  Future<_ContextCall> _callWithContextRecovery({
    required LivingCampaignRun run,
    required LivingGenerationStage jobStage,
    required int attempt,
    required String systemPrompt,
    required LivingCanonContextProjection projection,
    required LivingBattleOutcomeSnapshot outcome,
    required Map<String, Object?> extraPayload,
    required int maxTokens,
  }) async {
    final payload = <String, Object?>{...projection.payload, ...extraPayload};
    try {
      final call = await _callJson(
        run: run,
        stage: jobStage,
        attempt: attempt,
        systemPrompt: systemPrompt,
        payload: payload,
        maxTokens: maxTokens,
      );
      return _ContextCall(
        run: call.run,
        response: call.response,
        projection: projection,
      );
    } on _LivingCallFailure catch (failure) {
      if (!failure.error.isContextLimit || projection.compacted) {
        rethrow;
      }
      final compacted = _contextBuilder.losslessEventTupleProjection(
        canon: projection.canon,
        outcome: outcome,
        createdAt: _clock(),
      );
      final epochIssues = _contextBuilder.validateMemoryEpoch(
        compacted.canon.memoryEpochs.last,
        projection.canon,
      );
      if (epochIssues.isNotEmpty) {
        return throw _LivingCallFailure(
          run: failure.run,
          error: LivingProviderException(
            code: 'memory_epoch_invalid',
            safeMessage: epochIssues.join(' '),
          ),
        );
      }
      var compactRun = failure.run.copyWith(
        canon: compacted.canon,
        updatedAt: _clock(),
        generationJob: LivingGenerationJob(
          jobId: failure.run.generationJob?.jobId ?? _idFactory('job'),
          stage: LivingGenerationStage.compaction,
          status: LivingGenerationStatus.completed,
          attempt: attempt,
          createdAt: failure.run.generationJob?.createdAt ?? _clock(),
          updatedAt: _clock(),
          settingsSnapshot:
              failure.run.generationJob?.settingsSnapshot ?? const {},
          transportType: 'local',
        ),
        generationRecords: <LivingGenerationRecord>[
          ...failure.run.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-compaction'),
            stage: LivingGenerationStage.compaction,
            attempt: attempt,
            status: LivingGenerationStatus.completed,
            model: _gateway.textModel,
            startedAt: _clock(),
            finishedAt: _clock(),
            requestPayload: const <String, Object?>{
              'reason': 'provider_context_limit',
            },
            responsePayload: <String, Object?>{
              'memoryEpochId': compacted.canon.memoryEpochs.last.epochId,
              'encoding': 'lossless_event_tuples',
              'semanticFieldsRemoved': false,
            },
            inputTokens: null,
            contentLocale: failure.run.contentLocale.tag,
          ),
        ],
      );
      compactRun = await _setRunningJob(compactRun, jobStage, attempt: attempt);
      final retryPayload = <String, Object?>{
        ...compacted.payload,
        ...extraPayload,
      };
      final retry = await _callJson(
        run: compactRun,
        stage: jobStage,
        attempt: attempt,
        systemPrompt: systemPrompt,
        payload: retryPayload,
        maxTokens: maxTokens,
      );
      return _ContextCall(
        run: retry.run,
        response: retry.response,
        projection: compacted,
      );
    }
  }

  Future<_JsonCall> _callJson({
    required LivingCampaignRun run,
    required LivingGenerationStage stage,
    required int attempt,
    required String systemPrompt,
    required Map<String, Object?> payload,
    required int maxTokens,
  }) async {
    final localizedSystemPrompt = LivingCampaignLocaleContract.append(
      systemPrompt,
      run.contentLocale,
    );
    final localizedPayload = <String, Object?>{
      'contentLocale': run.contentLocale.tag,
      ...payload,
    };
    final startedAt = _clock();
    var liveRun = run;
    DateTime? firstProviderEventAt;
    var progressWrites = Future<void>.value();
    int? inputTokens;
    try {
      try {
        final tokenization = await _gateway.countTextTokens(<String>[
          localizedSystemPrompt,
          jsonEncode(localizedPayload),
        ]);
        inputTokens = tokenization.totalTokens;
      } on LivingProviderException {
        // Token counting is observability, never an application-level cap.
      }
      final response = await _gateway.chatJson(
        systemPrompt: localizedSystemPrompt,
        userPayload: localizedPayload,
        maxTokens: maxTokens,
        temperature: .2,
        onProgress: (progress) {
          if (progress.phase != DoubaoStreamPhase.connected) {
            firstProviderEventAt ??= progress.occurredAt;
          }
          final previousJob = liveRun.generationJob;
          if (previousJob == null) return;
          final shouldPersistRequestId =
              progress.requestId != null &&
              progress.requestId != previousJob.providerRequestId;
          final job = previousJob.copyWith(
            updatedAt: progress.occurredAt,
            transportType: 'sse',
            providerRequestId: progress.requestId,
            lastActivityAt: progress.phase == DoubaoStreamPhase.connected
                ? previousJob.lastActivityAt
                : progress.occurredAt,
            receivedContentCharacters: progress.receivedContentCharacters,
          );
          liveRun = liveRun.copyWith(
            updatedAt: progress.occurredAt,
            generationJob: job,
          );
          unawaited(_notifyProgress(liveRun));
          if (shouldPersistRequestId) {
            final snapshot = liveRun;
            progressWrites = progressWrites.then(
              (_) => _archive.writeRun(snapshot),
            );
          }
        },
      );
      await progressWrites;
      final next = liveRun.copyWith(
        updatedAt: _clock(),
        generationRecords: <LivingGenerationRecord>[
          ...liveRun.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-${stage.name}'),
            stage: stage,
            attempt: attempt,
            status: LivingGenerationStatus.completed,
            model: response.model ?? _gateway.textModel,
            startedAt: startedAt,
            finishedAt: _clock(),
            requestPayload: <String, Object?>{
              'systemPrompt': localizedSystemPrompt,
              'userPayload': localizedPayload,
            },
            responsePayload: response.value,
            inputTokens: inputTokens,
            contentLocale: run.contentLocale.tag,
            providerRequestId: response.requestId,
            transportType: response.transport,
            timeToFirstEventMs: response.timeToFirstEvent?.inMilliseconds,
            durationMs: response.duration?.inMilliseconds,
            usage: response.usage,
            finishReason: response.finishReason,
          ),
        ],
      );
      await _persist(next);
      return _JsonCall(run: next, response: response);
    } on LivingProviderException catch (error) {
      await progressWrites;
      final failed = liveRun.copyWith(
        updatedAt: _clock(),
        generationRecords: <LivingGenerationRecord>[
          ...liveRun.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-${stage.name}'),
            stage: stage,
            attempt: attempt,
            status: LivingGenerationStatus.failed,
            model: _gateway.textModel,
            startedAt: startedAt,
            finishedAt: _clock(),
            requestPayload: <String, Object?>{
              'systemPrompt': localizedSystemPrompt,
              'userPayload': localizedPayload,
            },
            responsePayload: const <String, Object?>{},
            inputTokens: inputTokens,
            contentLocale: run.contentLocale.tag,
            providerRequestId:
                error.requestId ?? liveRun.generationJob?.providerRequestId,
            transportType: 'sse',
            timeToFirstEventMs: firstProviderEventAt
                ?.difference(startedAt)
                .inMilliseconds,
            durationMs: _clock().difference(startedAt).inMilliseconds,
            errorCode: error.code,
            errorMessage: error.safeMessage,
          ),
        ],
      );
      await _persist(failed);
      throw _LivingCallFailure(run: failed, error: error);
    }
  }

  Future<_PortraitGeneration> _generateRequiredPortrait({
    required LivingCampaignRun run,
    required LivingCanonState canon,
    required LivingChapterPackage chapter,
  }) async {
    final characterId = chapter.portraitCharacterId!;
    final prompt = chapter.portraitPrompt!;
    var current = await _setRunningJob(
      run,
      LivingGenerationStage.portrait,
      attempt: 1,
    );
    final startedAt = _clock();
    try {
      final portrait = await _gateway.generatePortrait(
        prompt: prompt,
        seed: chapter.seed,
      );
      final reference = await _archive.writeBinary(
        runId: run.runId,
        fileName: 'portrait_$characterId.png',
        bytes: portrait.pngBytes,
      );
      final character = canon.charactersById[characterId];
      if (character == null) {
        throw const LivingProviderException(
          code: 'portrait_character_missing',
          safeMessage: 'The portrait character is missing from canon.',
        );
      }
      final characters = Map<String, LivingCharacter>.from(canon.charactersById)
        ..[characterId] = character.copyWith(portraitPath: reference);
      final nextCanon = canon.copyWith(charactersById: characters);
      current = current.copyWith(
        canon: nextCanon,
        updatedAt: _clock(),
        generationRecords: <LivingGenerationRecord>[
          ...current.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-portrait'),
            stage: LivingGenerationStage.portrait,
            attempt: 1,
            status: LivingGenerationStatus.completed,
            model: _gateway.imageModel,
            startedAt: startedAt,
            finishedAt: _clock(),
            requestPayload: <String, Object?>{
              'characterId': characterId,
              'prompt': portrait.finalPrompt,
              'seed': chapter.seed,
            },
            responsePayload: <String, Object?>{
              'storageReference': reference,
              'width': portrait.width,
              'height': portrait.height,
            },
            inputTokens: null,
            contentLocale: current.contentLocale.tag,
            providerRequestId: portrait.requestId,
            transportType: 'http',
            durationMs: _clock().difference(startedAt).inMilliseconds,
          ),
        ],
      );
      await _persist(current);
      return _PortraitGeneration(run: current, canon: nextCanon);
    } on LivingProviderException catch (error) {
      final failed = current.copyWith(
        updatedAt: _clock(),
        generationJob: _jobWithFailure(
          current.generationJob,
          error,
          LivingGenerationStatus.awaitingResume,
        ),
        generationRecords: <LivingGenerationRecord>[
          ...current.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-portrait'),
            stage: LivingGenerationStage.portrait,
            attempt: 1,
            status: LivingGenerationStatus.failed,
            model: _gateway.imageModel,
            startedAt: startedAt,
            finishedAt: _clock(),
            requestPayload: <String, Object?>{
              'characterId': characterId,
              'prompt': prompt,
              'seed': chapter.seed,
            },
            responsePayload: const <String, Object?>{},
            inputTokens: null,
            contentLocale: current.contentLocale.tag,
            providerRequestId: error.requestId,
            transportType: 'http',
            durationMs: _clock().difference(startedAt).inMilliseconds,
            errorCode: error.code,
            errorMessage: error.safeMessage,
          ),
        ],
      );
      await _persist(failed);
      throw _LivingCallFailure(run: failed, error: error);
    }
  }

  Future<LivingCampaignRun> _setRunningJob(
    LivingCampaignRun run,
    LivingGenerationStage stage, {
    required int attempt,
  }) async {
    final previous = run.generationJob;
    final job = LivingGenerationJob(
      jobId: previous?.jobId ?? _idFactory('job'),
      stage: stage,
      status: LivingGenerationStatus.running,
      attempt: attempt,
      createdAt: previous?.createdAt ?? _clock(),
      updatedAt: _clock(),
      settingsSnapshot: previous?.settingsSnapshot ?? const {},
      transportType: stage == LivingGenerationStage.portrait ? 'http' : 'sse',
    );
    final next = run.copyWith(updatedAt: _clock(), generationJob: job);
    await _persist(next);
    return next;
  }

  Future<LivingGenerationResult> _failValidation(
    LivingCampaignRun run,
    LivingGenerationStage stage,
    List<String> issues,
  ) async {
    final message = issues.isEmpty
        ? 'Generated content failed validation.'
        : issues.join(' ');
    final error = LivingProviderException(
      code: 'validation_failed_after_repair',
      safeMessage: message,
    );
    final failed = run.copyWith(
      updatedAt: _clock(),
      generationJob: _jobWithFailure(
        LivingGenerationJob(
          jobId: run.generationJob?.jobId ?? _idFactory('job'),
          stage: stage,
          status: LivingGenerationStatus.failed,
          attempt: 2,
          createdAt: run.generationJob?.createdAt ?? _clock(),
          updatedAt: _clock(),
          settingsSnapshot: run.generationJob?.settingsSnapshot ?? const {},
          transportType: run.generationJob?.transportType,
          providerRequestId: run.generationJob?.providerRequestId,
          lastActivityAt: run.generationJob?.lastActivityAt,
          receivedContentCharacters:
              run.generationJob?.receivedContentCharacters ?? 0,
        ),
        error,
        LivingGenerationStatus.failed,
      ),
    );
    await _persist(failed);
    return LivingGenerationResult(
      run: failed,
      completed: false,
      message: message,
    );
  }

  LivingGenerationJob _newJob(LivingGenerationStage stage) {
    final now = _clock();
    return LivingGenerationJob(
      jobId: _idFactory('job'),
      stage: stage,
      status: LivingGenerationStatus.running,
      attempt: 1,
      createdAt: now,
      updatedAt: now,
    );
  }

  LivingGenerationJob _startingJob(
    LivingCampaignRun run,
    LivingGenerationStage stage,
  ) {
    final previous = run.generationJob;
    if (previous == null) {
      return _newJob(stage);
    }
    return LivingGenerationJob(
      jobId: previous.jobId,
      stage: stage,
      status: LivingGenerationStatus.running,
      attempt: previous.attempt,
      createdAt: previous.createdAt,
      updatedAt: _clock(),
      settingsSnapshot: previous.settingsSnapshot,
      transportType: stage == LivingGenerationStage.portrait ? 'http' : 'sse',
    );
  }

  LivingGenerationJob _jobWithFailure(
    LivingGenerationJob? previous,
    LivingProviderException error,
    LivingGenerationStatus status,
  ) {
    final now = _clock();
    return LivingGenerationJob(
      jobId: previous?.jobId ?? _idFactory('job'),
      stage: previous?.stage ?? LivingGenerationStage.director,
      status: status,
      attempt: previous?.attempt ?? 1,
      createdAt: previous?.createdAt ?? now,
      updatedAt: now,
      settingsSnapshot: previous?.settingsSnapshot ?? const {},
      transportType: previous?.transportType,
      providerRequestId: error.requestId ?? previous?.providerRequestId,
      lastActivityAt: previous?.lastActivityAt,
      receivedContentCharacters: previous?.receivedContentCharacters ?? 0,
      errorCode: error.code,
      errorMessage: error.safeMessage,
    );
  }

  Future<void> _persist(LivingCampaignRun run) async {
    await _archive.writeRun(run);
    await _notifyProgress(run);
  }

  Future<void> _notifyProgress(LivingCampaignRun run) async {
    final callback = _onProgress;
    if (callback != null) {
      await callback(run);
    }
  }

  List<String> _safeIssues(Object error) {
    if (error is LivingCampaignValidationException) {
      return error.issues;
    }
    if (error is FormatException || error is TypeError) {
      return <String>['Generated JSON does not match the required schema.'];
    }
    return <String>['Generated content could not be validated.'];
  }

  List<String> _prologueIssues(Map<String, Object?> value) {
    final issues = <String>[];
    final title = value['campaignTitle'];
    final promise = value['storyPromise'];
    final prologue = value['prologue'];
    if (title is! String || title.trim().length < 4 || title.length > 80) {
      issues.add('campaignTitle must contain 4–80 characters.');
    }
    if (promise is! String ||
        promise.trim().length < 40 ||
        promise.length > 500) {
      issues.add('storyPromise must contain 40–500 characters.');
    }
    if (prologue is! String ||
        prologue.trim().length < 240 ||
        prologue.length > 2400) {
      issues.add('prologue must contain 240–2400 characters.');
    }
    return issues;
  }

  LivingGenerationRecord? _latestCompletedRecord(
    LivingCampaignRun run,
    LivingGenerationStage stage,
  ) {
    for (final record in run.generationRecords.reversed) {
      if (record.stage == stage &&
          record.status == LivingGenerationStatus.completed) {
        return record;
      }
    }
    return null;
  }

  String? _generationEligibilityIssue(
    LivingCampaignRun run,
    LivingBattleOutcomeSnapshot outcome,
  ) {
    if (run.status != LivingRunStatus.active) {
      return 'Only an active Living Campaign can generate another chapter.';
    }
    if (outcome.chapterNumber != run.activeChapterNumber) {
      return 'The battle outcome is not for the active chapter.';
    }
    if (run.chapterPackages.any(
      (chapter) => chapter.chapterNumber == outcome.chapterNumber + 1,
    )) {
      return 'The next chapter is already generated.';
    }
    return null;
  }

  List<String> _checkpointIssues({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
    required LivingChapterGenerationCheckpoint checkpoint,
  }) {
    final issues = <String>[];
    final patch = checkpoint.directorPatch;
    if (checkpoint.outcomeChapterId != outcome.chapterId) {
      issues.add('Generation checkpoint belongs to a different outcome.');
    }
    if (patch.runId != run.runId || run.canon.runId != run.runId) {
      issues.add('Generation checkpoint run identity does not match.');
    }
    if (patch.campaignComplete) {
      issues.add('A completed-campaign patch cannot remain pending.');
    }
    if (run.canon.revision != patch.basedOnRevision + 1) {
      issues.add('Generation checkpoint canon revision is inconsistent.');
    }
    if (!run.canon.chapterLedger.any(
      (chapter) =>
          chapter.chapterNumber == outcome.chapterNumber &&
          chapter.chapterId == outcome.chapterId,
    )) {
      issues.add('Generation checkpoint is missing its committed chapter.');
    }
    final chapter = checkpoint.chapterPackage;
    if (chapter != null) {
      issues.addAll(
        _validator.validateChapterPackage(
          canon: run.canon,
          intent: patch.nextChapterIntent,
          package: chapter,
        ),
      );
    }
    return issues;
  }
}

class _JsonCall {
  const _JsonCall({required this.run, required this.response});

  final LivingCampaignRun run;
  final DoubaoJsonResponse response;
}

class _ContextCall {
  const _ContextCall({
    required this.run,
    required this.response,
    required this.projection,
  });

  final LivingCampaignRun run;
  final DoubaoJsonResponse response;
  final LivingCanonContextProjection projection;
}

class _PortraitGeneration {
  const _PortraitGeneration({required this.run, required this.canon});

  final LivingCampaignRun run;
  final LivingCanonState canon;
}

class _LivingCallFailure implements Exception {
  const _LivingCallFailure({required this.run, required this.error});

  final LivingCampaignRun run;
  final LivingProviderException error;
}
