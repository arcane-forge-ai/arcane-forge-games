import 'package:flutter/foundation.dart';

import '../battlefield/battlefield_models.dart';
import '../domain/chess_models.dart';
import '../game/scenario_setup.dart';

enum LivingRunStatus { active, completed, abandoned }

enum LivingContentLocale {
  english('en'),
  simplifiedChinese('zh-Hans');

  const LivingContentLocale(this.tag);

  final String tag;

  static LivingContentLocale fromTag(Object? value) => switch (value) {
    'en' => LivingContentLocale.english,
    'zh-Hans' => LivingContentLocale.simplifiedChinese,
    _ => throw FormatException('Unsupported Living contentLocale: $value'),
  };
}

enum LivingLifeState { alive, wounded, presumedDead, dead }

enum LivingWhereabouts { withCourt, reserve, missing, captured, unknown }

enum LivingAllegiance { player, enemy, neutral, defected }

enum LivingRosterPosition { active, reserve, former, none }

enum LivingFactKind { verified, reportedBelief }

enum LivingThreadStatus { open, resolved }

@immutable
class LivingPiecePresentation {
  const LivingPiecePresentation({
    required this.characterId,
    required this.name,
    required this.pieceType,
    this.portraitReference,
    this.portraitBytes,
  });

  final String characterId;
  final String name;
  final PieceType pieceType;
  final String? portraitReference;
  final Uint8List? portraitBytes;
}

enum LivingBattleResult { victory, defeat, continuedDefeat, trapfall }

enum LivingFinaleKind { none, hopeful, tragic }

enum LivingObjectiveType {
  checkmate,
  reachEscape,
  surviveRounds,
  neutralizeTarget,
  rescueRecover,
}

enum LivingEventType {
  chapterStarted,
  captured,
  killed,
  wounded,
  missing,
  returned,
  joined,
  purchased,
  defected,
  reconciled,
  named,
  promoted,
  transformed,
  objectiveCompleted,
  battleWon,
  battleLost,
  finaleDeclared,
  epilogue,
}

enum LivingGenerationStage {
  prologue,
  prologueRepair,
  chronicler,
  chroniclerRepair,
  director,
  directorRepair,
  builder,
  builderRepair,
  portrait,
  chapterArt,
  compaction,
  compactionRepair,
}

enum LivingNamedPieceStatus { undiscovered, ally, enemy, missing, dead }

enum LivingGenerationStatus {
  pending,
  running,
  awaitingResume,
  failed,
  completed,
}

enum LivingPortraitStatus { pending, generating, ready, awaitingRetry }

enum LivingChapterArtStatus { pending, generating, ready, awaitingRetry }

enum LivingClosureTaskStatus { pending, running, ready, awaitingRetry }

T _enumByName<T extends Enum>(Iterable<T> values, Object? raw) {
  if (T == LivingObjectiveType && raw == 'surviveTurns') {
    return LivingObjectiveType.surviveRounds as T;
  }
  return values.firstWhere((value) => value.name == raw);
}

List<String> _strings(Object? raw) =>
    (raw as List<Object?>? ?? const <Object?>[]).cast<String>();

Map<String, Object?> _objectMap(Object? raw) =>
    Map<String, Object?>.from(raw! as Map);

Map<String, Object?>? _optionalObjectMap(Object? raw) =>
    raw == null ? null : Map<String, Object?>.from(raw as Map);

String livingSquareName(Square square) {
  final file = String.fromCharCode('a'.codeUnitAt(0) + square.col);
  return '$file${8 - square.row}';
}

Square livingSquareFromName(String value) {
  if (!RegExp(r'^[a-h][1-8]$').hasMatch(value)) {
    throw FormatException('Invalid chess square: $value');
  }
  return Square(8 - int.parse(value[1]), value.codeUnitAt(0) - 97);
}

@immutable
class LivingRosterPiece {
  const LivingRosterPiece({
    required this.pieceId,
    required this.basePieceType,
    required this.origin,
    required this.lifeState,
    required this.whereabouts,
    required this.allegiance,
    required this.rosterPosition,
    this.missionPieceType,
    this.characterId,
    this.historyEventIds = const <String>[],
  });

  final String pieceId;
  final PieceType basePieceType;
  final PieceType? missionPieceType;
  final String? characterId;
  final String origin;
  final LivingLifeState lifeState;
  final LivingWhereabouts whereabouts;
  final LivingAllegiance allegiance;
  final LivingRosterPosition rosterPosition;
  final List<String> historyEventIds;

  PieceType get battlePieceType => missionPieceType ?? basePieceType;

  LivingRosterPiece copyWith({
    PieceType? basePieceType,
    PieceType? missionPieceType,
    bool clearMissionPieceType = false,
    String? characterId,
    LivingLifeState? lifeState,
    LivingWhereabouts? whereabouts,
    LivingAllegiance? allegiance,
    LivingRosterPosition? rosterPosition,
    List<String>? historyEventIds,
  }) {
    return LivingRosterPiece(
      pieceId: pieceId,
      basePieceType: basePieceType ?? this.basePieceType,
      missionPieceType: clearMissionPieceType
          ? null
          : missionPieceType ?? this.missionPieceType,
      characterId: characterId ?? this.characterId,
      origin: origin,
      lifeState: lifeState ?? this.lifeState,
      whereabouts: whereabouts ?? this.whereabouts,
      allegiance: allegiance ?? this.allegiance,
      rosterPosition: rosterPosition ?? this.rosterPosition,
      historyEventIds: List<String>.unmodifiable(
        historyEventIds ?? this.historyEventIds,
      ),
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'pieceId': pieceId,
    'basePieceType': basePieceType.name,
    if (missionPieceType != null) 'missionPieceType': missionPieceType!.name,
    if (characterId != null) 'characterId': characterId,
    'origin': origin,
    'lifeState': lifeState.name,
    'whereabouts': whereabouts.name,
    'allegiance': allegiance.name,
    'rosterPosition': rosterPosition.name,
    'historyEventIds': historyEventIds,
  };

  factory LivingRosterPiece.fromJson(Map<String, Object?> json) {
    return LivingRosterPiece(
      pieceId: json['pieceId']! as String,
      basePieceType: _enumByName(PieceType.values, json['basePieceType']),
      missionPieceType: json['missionPieceType'] == null
          ? null
          : _enumByName(PieceType.values, json['missionPieceType']),
      characterId: json['characterId'] as String?,
      origin: json['origin']! as String,
      lifeState: _enumByName(LivingLifeState.values, json['lifeState']),
      whereabouts: _enumByName(LivingWhereabouts.values, json['whereabouts']),
      allegiance: _enumByName(LivingAllegiance.values, json['allegiance']),
      rosterPosition: _enumByName(
        LivingRosterPosition.values,
        json['rosterPosition'],
      ),
      historyEventIds: _strings(json['historyEventIds']),
    );
  }
}

@immutable
class LivingCharacter {
  const LivingCharacter({
    required this.characterId,
    required this.originalName,
    required this.originalIdentity,
    required this.basePieceType,
    required this.lifeState,
    required this.whereabouts,
    required this.allegiance,
    required this.firstChapter,
    required this.lastChapter,
    this.linkedPieceId,
    this.aliases = const <String>[],
    this.relationshipNotes = const <String>[],
    this.historyEventIds = const <String>[],
    this.portraitPath,
  });

  final String characterId;
  final String originalName;
  final String originalIdentity;
  final PieceType basePieceType;
  final String? linkedPieceId;
  final List<String> aliases;
  final LivingLifeState lifeState;
  final LivingWhereabouts whereabouts;
  final LivingAllegiance allegiance;
  final int firstChapter;
  final int lastChapter;
  final List<String> relationshipNotes;
  final List<String> historyEventIds;
  final String? portraitPath;

  LivingCharacter copyWith({
    String? originalName,
    String? originalIdentity,
    PieceType? basePieceType,
    List<String>? aliases,
    LivingLifeState? lifeState,
    LivingWhereabouts? whereabouts,
    LivingAllegiance? allegiance,
    int? lastChapter,
    List<String>? relationshipNotes,
    List<String>? historyEventIds,
    String? portraitPath,
  }) {
    return LivingCharacter(
      characterId: characterId,
      originalName: originalName ?? this.originalName,
      originalIdentity: originalIdentity ?? this.originalIdentity,
      basePieceType: basePieceType ?? this.basePieceType,
      linkedPieceId: linkedPieceId,
      aliases: List<String>.unmodifiable(aliases ?? this.aliases),
      lifeState: lifeState ?? this.lifeState,
      whereabouts: whereabouts ?? this.whereabouts,
      allegiance: allegiance ?? this.allegiance,
      firstChapter: firstChapter,
      lastChapter: lastChapter ?? this.lastChapter,
      relationshipNotes: List<String>.unmodifiable(
        relationshipNotes ?? this.relationshipNotes,
      ),
      historyEventIds: List<String>.unmodifiable(
        historyEventIds ?? this.historyEventIds,
      ),
      portraitPath: portraitPath ?? this.portraitPath,
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'characterId': characterId,
    'originalName': originalName,
    'originalIdentity': originalIdentity,
    'basePieceType': basePieceType.name,
    if (linkedPieceId != null) 'linkedPieceId': linkedPieceId,
    'aliases': aliases,
    'lifeState': lifeState.name,
    'whereabouts': whereabouts.name,
    'allegiance': allegiance.name,
    'firstChapter': firstChapter,
    'lastChapter': lastChapter,
    'relationshipNotes': relationshipNotes,
    'historyEventIds': historyEventIds,
    if (portraitPath != null) 'portraitPath': portraitPath,
  };

  factory LivingCharacter.fromJson(Map<String, Object?> json) {
    return LivingCharacter(
      characterId: json['characterId']! as String,
      originalName: json['originalName']! as String,
      originalIdentity: json['originalIdentity']! as String,
      basePieceType: _enumByName(PieceType.values, json['basePieceType']),
      linkedPieceId: json['linkedPieceId'] as String?,
      aliases: _strings(json['aliases']),
      lifeState: _enumByName(LivingLifeState.values, json['lifeState']),
      whereabouts: _enumByName(LivingWhereabouts.values, json['whereabouts']),
      allegiance: _enumByName(LivingAllegiance.values, json['allegiance']),
      firstChapter: (json['firstChapter']! as num).toInt(),
      lastChapter: (json['lastChapter']! as num).toInt(),
      relationshipNotes: _strings(json['relationshipNotes']),
      historyEventIds: _strings(json['historyEventIds']),
      portraitPath: json['portraitPath'] as String?,
    );
  }
}

@immutable
class LivingChapterRecord {
  const LivingChapterRecord({
    required this.chapterNumber,
    required this.chapterId,
    required this.title,
    required this.oneLineSummary,
    required this.objectiveType,
    required this.result,
    required this.eventIds,
    required this.finaleKind,
  });

  final int chapterNumber;
  final String chapterId;
  final String title;
  final String oneLineSummary;
  final LivingObjectiveType objectiveType;
  final LivingBattleResult result;
  final List<String> eventIds;
  final LivingFinaleKind finaleKind;

  Map<String, Object?> toJson() => <String, Object?>{
    'chapterNumber': chapterNumber,
    'chapterId': chapterId,
    'title': title,
    'oneLineSummary': oneLineSummary,
    'objectiveType': objectiveType.name,
    'result': result.name,
    'eventIds': eventIds,
    'finaleKind': finaleKind.name,
  };

  factory LivingChapterRecord.fromJson(Map<String, Object?> json) {
    return LivingChapterRecord(
      chapterNumber: (json['chapterNumber']! as num).toInt(),
      chapterId: json['chapterId']! as String,
      title: json['title']! as String,
      oneLineSummary: json['oneLineSummary']! as String,
      objectiveType: _enumByName(
        LivingObjectiveType.values,
        json['objectiveType'],
      ),
      result: _enumByName(LivingBattleResult.values, json['result']),
      eventIds: _strings(json['eventIds']),
      finaleKind: _enumByName(LivingFinaleKind.values, json['finaleKind']),
    );
  }
}

@immutable
class LivingCanonEvent {
  const LivingCanonEvent({
    required this.eventId,
    required this.chapterNumber,
    required this.type,
    required this.subjectIds,
    required this.description,
    this.causalEventIds = const <String>[],
    this.metadata = const <String, Object?>{},
  });

  final String eventId;
  final int chapterNumber;
  final LivingEventType type;
  final List<String> subjectIds;
  final String description;
  final List<String> causalEventIds;
  final Map<String, Object?> metadata;

  Map<String, Object?> toJson() => <String, Object?>{
    'eventId': eventId,
    'chapterNumber': chapterNumber,
    'type': type.name,
    'subjectIds': subjectIds,
    'description': description,
    'causalEventIds': causalEventIds,
    'metadata': metadata,
  };

  factory LivingCanonEvent.fromJson(Map<String, Object?> json) {
    return LivingCanonEvent(
      eventId: json['eventId']! as String,
      chapterNumber: (json['chapterNumber']! as num).toInt(),
      type: _enumByName(LivingEventType.values, json['type']),
      subjectIds: _strings(json['subjectIds']),
      description: json['description']! as String,
      causalEventIds: _strings(json['causalEventIds']),
      metadata: _optionalObjectMap(json['metadata']) ?? const {},
    );
  }
}

@immutable
class LivingCanonFact {
  const LivingCanonFact({
    required this.factId,
    required this.kind,
    required this.statement,
    required this.chapterNumber,
    required this.subjectIds,
    required this.sourceEventId,
    this.refutesFactId,
  });

  final String factId;
  final LivingFactKind kind;
  final String statement;
  final int chapterNumber;
  final List<String> subjectIds;
  final String sourceEventId;
  final String? refutesFactId;

  Map<String, Object?> toJson() => <String, Object?>{
    'factId': factId,
    'kind': kind.name,
    'statement': statement,
    'chapterNumber': chapterNumber,
    'subjectIds': subjectIds,
    'sourceEventId': sourceEventId,
    if (refutesFactId != null) 'refutesFactId': refutesFactId,
  };

  factory LivingCanonFact.fromJson(Map<String, Object?> json) {
    return LivingCanonFact(
      factId: json['factId']! as String,
      kind: _enumByName(LivingFactKind.values, json['kind']),
      statement: json['statement']! as String,
      chapterNumber: (json['chapterNumber']! as num).toInt(),
      subjectIds: _strings(json['subjectIds']),
      sourceEventId: json['sourceEventId']! as String,
      refutesFactId: json['refutesFactId'] as String?,
    );
  }
}

@immutable
class LivingStoryThread {
  const LivingStoryThread({
    required this.threadId,
    required this.title,
    required this.status,
    required this.participantIds,
    required this.openedChapter,
    required this.lastAdvancedChapter,
    required this.summary,
    required this.evidenceEventIds,
    this.resolvedChapter,
  });

  final String threadId;
  final String title;
  final LivingThreadStatus status;
  final List<String> participantIds;
  final int openedChapter;
  final int lastAdvancedChapter;
  final int? resolvedChapter;
  final String summary;
  final List<String> evidenceEventIds;

  LivingStoryThread copyWith({
    LivingThreadStatus? status,
    int? lastAdvancedChapter,
    int? resolvedChapter,
    String? summary,
    List<String>? evidenceEventIds,
  }) {
    return LivingStoryThread(
      threadId: threadId,
      title: title,
      status: status ?? this.status,
      participantIds: participantIds,
      openedChapter: openedChapter,
      lastAdvancedChapter: lastAdvancedChapter ?? this.lastAdvancedChapter,
      resolvedChapter: resolvedChapter ?? this.resolvedChapter,
      summary: summary ?? this.summary,
      evidenceEventIds: List<String>.unmodifiable(
        evidenceEventIds ?? this.evidenceEventIds,
      ),
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'threadId': threadId,
    'title': title,
    'status': status.name,
    'participantIds': participantIds,
    'openedChapter': openedChapter,
    'lastAdvancedChapter': lastAdvancedChapter,
    if (resolvedChapter != null) 'resolvedChapter': resolvedChapter,
    'summary': summary,
    'evidenceEventIds': evidenceEventIds,
  };

  factory LivingStoryThread.fromJson(Map<String, Object?> json) {
    return LivingStoryThread(
      threadId: json['threadId']! as String,
      title: json['title']! as String,
      status: _enumByName(LivingThreadStatus.values, json['status']),
      participantIds: _strings(json['participantIds']),
      openedChapter: (json['openedChapter']! as num).toInt(),
      lastAdvancedChapter: (json['lastAdvancedChapter']! as num).toInt(),
      resolvedChapter: (json['resolvedChapter'] as num?)?.toInt(),
      summary: json['summary']! as String,
      evidenceEventIds: _strings(json['evidenceEventIds']),
    );
  }
}

@immutable
class LivingRelationship {
  const LivingRelationship({
    required this.relationshipId,
    required this.characterIds,
    required this.currentSummary,
    required this.changeEventIds,
  });

  final String relationshipId;
  final List<String> characterIds;
  final String currentSummary;
  final List<String> changeEventIds;

  LivingRelationship copyWith({
    String? currentSummary,
    List<String>? changeEventIds,
  }) {
    return LivingRelationship(
      relationshipId: relationshipId,
      characterIds: characterIds,
      currentSummary: currentSummary ?? this.currentSummary,
      changeEventIds: List<String>.unmodifiable(
        changeEventIds ?? this.changeEventIds,
      ),
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'relationshipId': relationshipId,
    'characterIds': characterIds,
    'currentSummary': currentSummary,
    'changeEventIds': changeEventIds,
  };

  factory LivingRelationship.fromJson(Map<String, Object?> json) {
    return LivingRelationship(
      relationshipId: json['relationshipId']! as String,
      characterIds: _strings(json['characterIds']),
      currentSummary: json['currentSummary']! as String,
      changeEventIds: _strings(json['changeEventIds']),
    );
  }
}

@immutable
class LivingMemoryEpoch {
  const LivingMemoryEpoch({
    required this.epochId,
    required this.firstChapter,
    required this.lastChapter,
    required this.narrative,
    required this.sourceHashes,
    required this.includedCharacterIds,
    required this.includedEventIds,
    required this.includedThreadIds,
    required this.createdAt,
  });

  final String epochId;
  final int firstChapter;
  final int lastChapter;
  final String narrative;
  final Map<String, String> sourceHashes;
  final List<String> includedCharacterIds;
  final List<String> includedEventIds;
  final List<String> includedThreadIds;
  final DateTime createdAt;

  Map<String, Object?> toJson() => <String, Object?>{
    'epochId': epochId,
    'firstChapter': firstChapter,
    'lastChapter': lastChapter,
    'narrative': narrative,
    'sourceHashes': sourceHashes,
    'includedCharacterIds': includedCharacterIds,
    'includedEventIds': includedEventIds,
    'includedThreadIds': includedThreadIds,
    'createdAt': createdAt.toUtc().toIso8601String(),
  };

  factory LivingMemoryEpoch.fromJson(Map<String, Object?> json) {
    return LivingMemoryEpoch(
      epochId: json['epochId']! as String,
      firstChapter: (json['firstChapter']! as num).toInt(),
      lastChapter: (json['lastChapter']! as num).toInt(),
      narrative: json['narrative']! as String,
      sourceHashes: Map<String, String>.from(json['sourceHashes']! as Map),
      includedCharacterIds: _strings(json['includedCharacterIds']),
      includedEventIds: _strings(json['includedEventIds']),
      includedThreadIds: _strings(json['includedThreadIds']),
      createdAt: DateTime.parse(json['createdAt']! as String),
    );
  }
}

@immutable
class LivingCanonState {
  const LivingCanonState({
    required this.schemaVersion,
    required this.runId,
    required this.revision,
    required this.gold,
    required this.playerRosterByPieceId,
    required this.charactersById,
    required this.chapterLedger,
    required this.eventLedger,
    required this.canonFactsById,
    required this.storyThreadsById,
    required this.relationshipsById,
    required this.memoryEpochs,
  });

  final int schemaVersion;
  final String runId;
  final int revision;
  final int gold;
  final Map<String, LivingRosterPiece> playerRosterByPieceId;
  final Map<String, LivingCharacter> charactersById;
  final List<LivingChapterRecord> chapterLedger;
  final List<LivingCanonEvent> eventLedger;
  final Map<String, LivingCanonFact> canonFactsById;
  final Map<String, LivingStoryThread> storyThreadsById;
  final Map<String, LivingRelationship> relationshipsById;
  final List<LivingMemoryEpoch> memoryEpochs;

  LivingCanonState copyWith({
    int? revision,
    int? gold,
    Map<String, LivingRosterPiece>? playerRosterByPieceId,
    Map<String, LivingCharacter>? charactersById,
    List<LivingChapterRecord>? chapterLedger,
    List<LivingCanonEvent>? eventLedger,
    Map<String, LivingCanonFact>? canonFactsById,
    Map<String, LivingStoryThread>? storyThreadsById,
    Map<String, LivingRelationship>? relationshipsById,
    List<LivingMemoryEpoch>? memoryEpochs,
  }) {
    return LivingCanonState(
      schemaVersion: schemaVersion,
      runId: runId,
      revision: revision ?? this.revision,
      gold: gold ?? this.gold,
      playerRosterByPieceId: Map.unmodifiable(
        playerRosterByPieceId ?? this.playerRosterByPieceId,
      ),
      charactersById: Map.unmodifiable(charactersById ?? this.charactersById),
      chapterLedger: List.unmodifiable(chapterLedger ?? this.chapterLedger),
      eventLedger: List.unmodifiable(eventLedger ?? this.eventLedger),
      canonFactsById: Map.unmodifiable(canonFactsById ?? this.canonFactsById),
      storyThreadsById: Map.unmodifiable(
        storyThreadsById ?? this.storyThreadsById,
      ),
      relationshipsById: Map.unmodifiable(
        relationshipsById ?? this.relationshipsById,
      ),
      memoryEpochs: List.unmodifiable(memoryEpochs ?? this.memoryEpochs),
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': schemaVersion,
    'runId': runId,
    'revision': revision,
    'gold': gold,
    'playerRosterByPieceId': playerRosterByPieceId.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'charactersById': charactersById.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'chapterLedger': chapterLedger.map((value) => value.toJson()).toList(),
    'eventLedger': eventLedger.map((value) => value.toJson()).toList(),
    'canonFactsById': canonFactsById.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'storyThreadsById': storyThreadsById.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'relationshipsById': relationshipsById.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'memoryEpochs': memoryEpochs.map((value) => value.toJson()).toList(),
  };

  factory LivingCanonState.fromJson(Map<String, Object?> json) {
    final roster = _objectMap(json['playerRosterByPieceId']);
    final characters = _objectMap(json['charactersById']);
    final facts = _objectMap(json['canonFactsById']);
    final threads = _objectMap(json['storyThreadsById']);
    final relationships = _objectMap(json['relationshipsById']);
    return LivingCanonState(
      schemaVersion: (json['schemaVersion']! as num).toInt(),
      runId: json['runId']! as String,
      revision: (json['revision']! as num).toInt(),
      gold: (json['gold']! as num).toInt(),
      playerRosterByPieceId: Map.unmodifiable(
        roster.map(
          (key, value) =>
              MapEntry(key, LivingRosterPiece.fromJson(_objectMap(value))),
        ),
      ),
      charactersById: Map.unmodifiable(
        characters.map(
          (key, value) =>
              MapEntry(key, LivingCharacter.fromJson(_objectMap(value))),
        ),
      ),
      chapterLedger: List.unmodifiable(
        (json['chapterLedger']! as List<Object?>).map(
          (value) => LivingChapterRecord.fromJson(_objectMap(value)),
        ),
      ),
      eventLedger: List.unmodifiable(
        (json['eventLedger']! as List<Object?>).map(
          (value) => LivingCanonEvent.fromJson(_objectMap(value)),
        ),
      ),
      canonFactsById: Map.unmodifiable(
        facts.map(
          (key, value) =>
              MapEntry(key, LivingCanonFact.fromJson(_objectMap(value))),
        ),
      ),
      storyThreadsById: Map.unmodifiable(
        threads.map(
          (key, value) =>
              MapEntry(key, LivingStoryThread.fromJson(_objectMap(value))),
        ),
      ),
      relationshipsById: Map.unmodifiable(
        relationships.map(
          (key, value) =>
              MapEntry(key, LivingRelationship.fromJson(_objectMap(value))),
        ),
      ),
      memoryEpochs: List.unmodifiable(
        (json['memoryEpochs']! as List<Object?>).map(
          (value) => LivingMemoryEpoch.fromJson(_objectMap(value)),
        ),
      ),
    );
  }
}

@immutable
class LivingCapturedPieceOutcome {
  const LivingCapturedPieceOutcome({
    required this.pieceId,
    required this.pieceType,
    required this.ownerBeforeBattle,
    required this.capturedByPieceId,
    required this.wasActuallyCaptured,
    this.characterId,
  });

  final String pieceId;
  final PieceType pieceType;
  final LivingAllegiance ownerBeforeBattle;
  final String capturedByPieceId;
  final bool wasActuallyCaptured;
  final String? characterId;

  Map<String, Object?> toJson() => <String, Object?>{
    'pieceId': pieceId,
    'pieceType': pieceType.name,
    'ownerBeforeBattle': ownerBeforeBattle.name,
    'capturedByPieceId': capturedByPieceId,
    'wasActuallyCaptured': wasActuallyCaptured,
    if (characterId != null) 'characterId': characterId,
  };

  factory LivingCapturedPieceOutcome.fromJson(Map<String, Object?> json) {
    return LivingCapturedPieceOutcome(
      pieceId: json['pieceId']! as String,
      pieceType: _enumByName(PieceType.values, json['pieceType']),
      ownerBeforeBattle: _enumByName(
        LivingAllegiance.values,
        json['ownerBeforeBattle'],
      ),
      capturedByPieceId: json['capturedByPieceId']! as String,
      wasActuallyCaptured: json['wasActuallyCaptured']! as bool,
      characterId: json['characterId'] as String?,
    );
  }
}

@immutable
class LivingPurchasedPieceOutcome {
  const LivingPurchasedPieceOutcome({
    required this.pieceId,
    required this.pieceType,
    required this.originCountryId,
    this.characterId,
    this.loyalty,
  });

  final String pieceId;
  final PieceType pieceType;
  final String originCountryId;
  final String? characterId;
  final int? loyalty;

  Map<String, Object?> toJson() => <String, Object?>{
    'pieceId': pieceId,
    'pieceType': pieceType.name,
    'originCountryId': originCountryId,
    if (characterId != null) 'characterId': characterId,
    if (loyalty != null) 'loyalty': loyalty,
  };

  factory LivingPurchasedPieceOutcome.fromJson(Map<String, Object?> json) {
    return LivingPurchasedPieceOutcome(
      pieceId: json['pieceId']! as String,
      pieceType: _enumByName(PieceType.values, json['pieceType']),
      originCountryId: json['originCountryId']! as String,
      characterId: json['characterId'] as String?,
      loyalty: (json['loyalty'] as num?)?.toInt(),
    );
  }
}

@immutable
class LivingPurchaseEventOutcome {
  const LivingPurchaseEventOutcome({
    required this.pieceId,
    required this.pieceType,
    required this.fromAllegiance,
    required this.toAllegiance,
    required this.completedActionNumber,
    this.characterId,
  });

  final String pieceId;
  final PieceType pieceType;
  final LivingAllegiance fromAllegiance;
  final LivingAllegiance toAllegiance;
  final int completedActionNumber;
  final String? characterId;

  Map<String, Object?> toJson() => <String, Object?>{
    'pieceId': pieceId,
    'pieceType': pieceType.name,
    'fromAllegiance': fromAllegiance.name,
    'toAllegiance': toAllegiance.name,
    'completedActionNumber': completedActionNumber,
    if (characterId != null) 'characterId': characterId,
  };

  factory LivingPurchaseEventOutcome.fromJson(Map<String, Object?> json) {
    return LivingPurchaseEventOutcome(
      pieceId: json['pieceId']! as String,
      pieceType: _enumByName(PieceType.values, json['pieceType']),
      fromAllegiance: _enumByName(
        LivingAllegiance.values,
        json['fromAllegiance'],
      ),
      toAllegiance: _enumByName(LivingAllegiance.values, json['toAllegiance']),
      completedActionNumber: (json['completedActionNumber']! as num).toInt(),
      characterId: json['characterId'] as String?,
    );
  }
}

@immutable
class LivingBattleOutcomeSnapshot {
  const LivingBattleOutcomeSnapshot({
    required this.chapterNumber,
    required this.chapterId,
    required this.result,
    required this.endReason,
    required this.objectiveType,
    required this.objectiveCompleted,
    required this.completedTurns,
    this.completedRoundCount = 0,
    required this.goldBefore,
    required this.goldAfterBattle,
    required this.survivingPieceIds,
    required this.capturedPieces,
    required this.purchasedPieceIds,
    required this.missionRoleChanges,
    this.purchasedPieces = const <LivingPurchasedPieceOutcome>[],
    this.purchaseEvents = const <LivingPurchaseEventOutcome>[],
    this.pieceEndStates = const <LivingPieceEndState>[],
    this.matchLog = const <String>[],
    this.pressureTier = 'even',
    this.kingTrapfallPieceId,
  });

  final int chapterNumber;
  final String chapterId;
  final LivingBattleResult result;
  final GameEndReason endReason;
  final LivingObjectiveType objectiveType;
  final String pressureTier;
  final bool objectiveCompleted;
  final int completedTurns;
  final int completedRoundCount;
  final int goldBefore;
  final int goldAfterBattle;
  final List<String> survivingPieceIds;
  final List<LivingCapturedPieceOutcome> capturedPieces;
  final List<String> purchasedPieceIds;
  final List<LivingPurchasedPieceOutcome> purchasedPieces;
  final List<LivingPurchaseEventOutcome> purchaseEvents;
  final List<LivingPieceEndState> pieceEndStates;
  final List<String> matchLog;
  final Map<String, PieceType> missionRoleChanges;
  final String? kingTrapfallPieceId;

  Set<String> get actuallyCapturedPieceIds => capturedPieces
      .where((value) => value.wasActuallyCaptured)
      .map((value) => value.pieceId)
      .toSet();

  Map<String, Object?> toJson() => <String, Object?>{
    'chapterNumber': chapterNumber,
    'chapterId': chapterId,
    'result': result.name,
    'endReason': endReason.name,
    'objectiveType': objectiveType.name,
    'pressureTier': pressureTier,
    'objectiveCompleted': objectiveCompleted,
    'completedTurns': completedTurns,
    'completedRoundCount': completedRoundCount,
    'goldBefore': goldBefore,
    'goldAfterBattle': goldAfterBattle,
    'survivingPieceIds': survivingPieceIds,
    'capturedPieces': capturedPieces.map((value) => value.toJson()).toList(),
    'purchasedPieceIds': purchasedPieceIds,
    'purchasedPieces': purchasedPieces.map((value) => value.toJson()).toList(),
    'purchaseEvents': purchaseEvents.map((value) => value.toJson()).toList(),
    'pieceEndStates': pieceEndStates.map((value) => value.toJson()).toList(),
    'matchLog': matchLog,
    if (kingTrapfallPieceId != null) 'kingTrapfallPieceId': kingTrapfallPieceId,
    'missionRoleChanges': missionRoleChanges.map(
      (key, value) => MapEntry(key, value.name),
    ),
  };

  factory LivingBattleOutcomeSnapshot.fromJson(Map<String, Object?> json) {
    final roleChanges = _objectMap(json['missionRoleChanges']);
    return LivingBattleOutcomeSnapshot(
      chapterNumber: (json['chapterNumber']! as num).toInt(),
      chapterId: json['chapterId']! as String,
      result: _enumByName(LivingBattleResult.values, json['result']),
      endReason: _enumByName(GameEndReason.values, json['endReason']),
      objectiveType: _enumByName(
        LivingObjectiveType.values,
        json['objectiveType'],
      ),
      pressureTier: json['pressureTier'] as String? ?? 'even',
      objectiveCompleted: json['objectiveCompleted']! as bool,
      completedTurns: (json['completedTurns']! as num).toInt(),
      completedRoundCount:
          (json['completedRoundCount'] as num?)?.toInt() ??
          (((json['completedTurns']! as num).toInt() + 1) ~/ 2),
      goldBefore: (json['goldBefore']! as num).toInt(),
      goldAfterBattle: (json['goldAfterBattle']! as num).toInt(),
      survivingPieceIds: _strings(json['survivingPieceIds']),
      capturedPieces: List.unmodifiable(
        (json['capturedPieces']! as List<Object?>).map(
          (value) => LivingCapturedPieceOutcome.fromJson(_objectMap(value)),
        ),
      ),
      purchasedPieceIds: _strings(json['purchasedPieceIds']),
      purchasedPieces: List.unmodifiable(
        (json['purchasedPieces'] as List<Object?>? ?? const <Object?>[]).map(
          (value) => LivingPurchasedPieceOutcome.fromJson(_objectMap(value)),
        ),
      ),
      purchaseEvents: List.unmodifiable(
        (json['purchaseEvents'] as List<Object?>? ?? const <Object?>[]).map(
          (value) => LivingPurchaseEventOutcome.fromJson(_objectMap(value)),
        ),
      ),
      pieceEndStates: List.unmodifiable(
        (json['pieceEndStates'] as List<Object?>? ?? const <Object?>[]).map(
          (value) => LivingPieceEndState.fromJson(_objectMap(value)),
        ),
      ),
      matchLog: _strings(json['matchLog']),
      kingTrapfallPieceId: json['kingTrapfallPieceId'] as String?,
      missionRoleChanges: Map.unmodifiable(
        roleChanges.map(
          (key, value) => MapEntry(key, _enumByName(PieceType.values, value)),
        ),
      ),
    );
  }
}

@immutable
class LivingPieceEndState {
  const LivingPieceEndState({
    required this.pieceId,
    required this.startingType,
    required this.startingColor,
    required this.startingSquare,
    required this.wasCaptured,
    required this.wasPurchased,
    required this.wasPromoted,
    this.characterId,
    this.endingType,
    this.endingColor,
    this.endingSquare,
    this.endingLoyalty,
  });

  final String pieceId;
  final String? characterId;
  final PieceType startingType;
  final PieceColor startingColor;
  final Square startingSquare;
  final PieceType? endingType;
  final PieceColor? endingColor;
  final Square? endingSquare;
  final int? endingLoyalty;
  final bool wasCaptured;
  final bool wasPurchased;
  final bool wasPromoted;

  bool get finishedAlive =>
      !wasCaptured &&
      endingType != null &&
      endingColor != null &&
      endingSquare != null;

  Map<String, Object?> toJson() => <String, Object?>{
    'pieceId': pieceId,
    if (characterId != null) 'characterId': characterId,
    'startingType': startingType.name,
    'startingColor': startingColor.name,
    'startingSquare': livingSquareName(startingSquare),
    if (endingType != null) 'endingType': endingType!.name,
    if (endingColor != null) 'endingColor': endingColor!.name,
    if (endingSquare != null) 'endingSquare': livingSquareName(endingSquare!),
    if (endingLoyalty != null) 'endingLoyalty': endingLoyalty,
    'wasCaptured': wasCaptured,
    'wasPurchased': wasPurchased,
    'wasPromoted': wasPromoted,
  };

  factory LivingPieceEndState.fromJson(Map<String, Object?> json) =>
      LivingPieceEndState(
        pieceId: json['pieceId']! as String,
        characterId: json['characterId'] as String?,
        startingType: _enumByName(PieceType.values, json['startingType']),
        startingColor: _enumByName(PieceColor.values, json['startingColor']),
        startingSquare: livingSquareFromName(json['startingSquare']! as String),
        endingType: json['endingType'] == null
            ? null
            : _enumByName(PieceType.values, json['endingType']),
        endingColor: json['endingColor'] == null
            ? null
            : _enumByName(PieceColor.values, json['endingColor']),
        endingSquare: json['endingSquare'] == null
            ? null
            : livingSquareFromName(json['endingSquare']! as String),
        endingLoyalty: (json['endingLoyalty'] as num?)?.toInt(),
        wasCaptured: json['wasCaptured'] as bool? ?? false,
        wasPurchased: json['wasPurchased'] as bool? ?? false,
        wasPromoted: json['wasPromoted'] as bool? ?? false,
      );
}

@immutable
class LivingCharacterTransition {
  const LivingCharacterTransition({
    required this.characterId,
    required this.chapterNumber,
    required this.causalEventId,
    required this.expectedLifeState,
    required this.expectedWhereabouts,
    required this.expectedAllegiance,
    required this.nextLifeState,
    required this.nextWhereabouts,
    required this.nextAllegiance,
  });

  final String characterId;
  final int chapterNumber;
  final String causalEventId;
  final LivingLifeState expectedLifeState;
  final LivingWhereabouts expectedWhereabouts;
  final LivingAllegiance expectedAllegiance;
  final LivingLifeState nextLifeState;
  final LivingWhereabouts nextWhereabouts;
  final LivingAllegiance nextAllegiance;

  Map<String, Object?> toJson() => <String, Object?>{
    'characterId': characterId,
    'chapterNumber': chapterNumber,
    'causalEventId': causalEventId,
    'expectedLifeState': expectedLifeState.name,
    'expectedWhereabouts': expectedWhereabouts.name,
    'expectedAllegiance': expectedAllegiance.name,
    'nextLifeState': nextLifeState.name,
    'nextWhereabouts': nextWhereabouts.name,
    'nextAllegiance': nextAllegiance.name,
  };

  factory LivingCharacterTransition.fromJson(Map<String, Object?> json) {
    return LivingCharacterTransition(
      characterId: json['characterId']! as String,
      chapterNumber: (json['chapterNumber']! as num).toInt(),
      causalEventId: json['causalEventId']! as String,
      expectedLifeState: _enumByName(
        LivingLifeState.values,
        json['expectedLifeState'],
      ),
      expectedWhereabouts: _enumByName(
        LivingWhereabouts.values,
        json['expectedWhereabouts'],
      ),
      expectedAllegiance: _enumByName(
        LivingAllegiance.values,
        json['expectedAllegiance'],
      ),
      nextLifeState: _enumByName(LivingLifeState.values, json['nextLifeState']),
      nextWhereabouts: _enumByName(
        LivingWhereabouts.values,
        json['nextWhereabouts'],
      ),
      nextAllegiance: _enumByName(
        LivingAllegiance.values,
        json['nextAllegiance'],
      ),
    );
  }
}

@immutable
class LivingThreadChange {
  const LivingThreadChange({
    required this.threadId,
    required this.chapterNumber,
    required this.expectedStatus,
    required this.summary,
    required this.evidenceEventIds,
    this.resolve = false,
  });

  final String threadId;
  final int chapterNumber;
  final LivingThreadStatus expectedStatus;
  final String summary;
  final List<String> evidenceEventIds;
  final bool resolve;

  Map<String, Object?> toJson() => <String, Object?>{
    'threadId': threadId,
    'chapterNumber': chapterNumber,
    'expectedStatus': expectedStatus.name,
    'summary': summary,
    'evidenceEventIds': evidenceEventIds,
    'resolve': resolve,
  };

  factory LivingThreadChange.fromJson(Map<String, Object?> json) {
    return LivingThreadChange(
      threadId: json['threadId']! as String,
      chapterNumber: (json['chapterNumber']! as num).toInt(),
      expectedStatus: _enumByName(
        LivingThreadStatus.values,
        json['expectedStatus'],
      ),
      summary: json['summary']! as String,
      evidenceEventIds: _strings(json['evidenceEventIds']),
      resolve: json['resolve'] as bool? ?? false,
    );
  }
}

@immutable
class LivingRelationshipChange {
  const LivingRelationshipChange({
    required this.relationshipId,
    required this.expectedSummary,
    required this.nextSummary,
    required this.causalEventId,
  });

  final String relationshipId;
  final String expectedSummary;
  final String nextSummary;
  final String causalEventId;

  Map<String, Object?> toJson() => <String, Object?>{
    'relationshipId': relationshipId,
    'expectedSummary': expectedSummary,
    'nextSummary': nextSummary,
    'causalEventId': causalEventId,
  };

  factory LivingRelationshipChange.fromJson(Map<String, Object?> json) {
    return LivingRelationshipChange(
      relationshipId: json['relationshipId']! as String,
      expectedSummary: json['expectedSummary']! as String,
      nextSummary: json['nextSummary']! as String,
      causalEventId: json['causalEventId']! as String,
    );
  }
}

@immutable
class LivingNextChapterIntent {
  const LivingNextChapterIntent({
    required this.chapterNumber,
    required this.conflict,
    required this.objectiveType,
    required this.pressureTier,
    required this.rewardTier,
    required this.finaleKind,
    required this.essentialBeats,
    this.newCharacterId,
  });

  final int chapterNumber;
  final String conflict;
  final LivingObjectiveType objectiveType;
  final String pressureTier;
  final int rewardTier;
  final LivingFinaleKind finaleKind;
  final List<String> essentialBeats;
  final String? newCharacterId;

  Map<String, Object?> toJson() => <String, Object?>{
    'chapterNumber': chapterNumber,
    'conflict': conflict,
    'objectiveType': objectiveType.name,
    'pressureTier': pressureTier,
    'rewardTier': rewardTier,
    'finaleKind': finaleKind.name,
    'essentialBeats': essentialBeats,
    if (newCharacterId != null) 'newCharacterId': newCharacterId,
  };

  factory LivingNextChapterIntent.fromJson(Map<String, Object?> json) {
    return LivingNextChapterIntent(
      chapterNumber: (json['chapterNumber']! as num).toInt(),
      conflict: json['conflict']! as String,
      objectiveType: _enumByName(
        LivingObjectiveType.values,
        json['objectiveType'],
      ),
      pressureTier: json['pressureTier']! as String,
      rewardTier: (json['rewardTier']! as num).toInt(),
      finaleKind: _enumByName(LivingFinaleKind.values, json['finaleKind']),
      essentialBeats: _strings(json['essentialBeats']),
      newCharacterId: json['newCharacterId'] as String?,
    );
  }
}

@immutable
class LivingCompletedChapterPatch {
  const LivingCompletedChapterPatch({
    required this.chapterNumber,
    required this.chapterId,
    required this.title,
    required this.oneLineSummary,
  });

  final int chapterNumber;
  final String chapterId;
  final String title;
  final String oneLineSummary;

  Map<String, Object?> toJson() => <String, Object?>{
    'chapterNumber': chapterNumber,
    'chapterId': chapterId,
    'title': title,
    'oneLineSummary': oneLineSummary,
  };

  factory LivingCompletedChapterPatch.fromJson(Map<String, Object?> json) {
    return LivingCompletedChapterPatch(
      chapterNumber: (json['chapterNumber']! as num).toInt(),
      chapterId: json['chapterId']! as String,
      title: json['title']! as String,
      oneLineSummary: json['oneLineSummary']! as String,
    );
  }
}

@immutable
class LivingDirectorPatch {
  const LivingDirectorPatch({
    required this.schemaVersion,
    required this.runId,
    required this.basedOnRevision,
    required this.completedChapter,
    required this.addCharacters,
    required this.addEvents,
    required this.addCanonFacts,
    required this.openStoryThreads,
    required this.characterTransitions,
    required this.advanceStoryThreads,
    required this.resolveStoryThreads,
    required this.relationshipChanges,
    required this.nextChapterIntent,
    this.addRosterPieces = const <LivingRosterPiece>[],
    this.campaignComplete = false,
    this.epilogue,
  });

  final int schemaVersion;
  final String runId;
  final int basedOnRevision;
  final List<LivingRosterPiece> addRosterPieces;
  final bool campaignComplete;
  final String? epilogue;
  final LivingCompletedChapterPatch completedChapter;
  final List<LivingCharacter> addCharacters;
  final List<LivingCanonEvent> addEvents;
  final List<LivingCanonFact> addCanonFacts;
  final List<LivingStoryThread> openStoryThreads;
  final List<LivingCharacterTransition> characterTransitions;
  final List<LivingThreadChange> advanceStoryThreads;
  final List<LivingThreadChange> resolveStoryThreads;
  final List<LivingRelationshipChange> relationshipChanges;
  final LivingNextChapterIntent nextChapterIntent;

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': schemaVersion,
    'runId': runId,
    'basedOnRevision': basedOnRevision,
    'addRosterPieces': addRosterPieces.map((value) => value.toJson()).toList(),
    'campaignComplete': campaignComplete,
    if (epilogue != null) 'epilogue': epilogue,
    'completedChapter': completedChapter.toJson(),
    'addCharacters': addCharacters.map((value) => value.toJson()).toList(),
    'addEvents': addEvents.map((value) => value.toJson()).toList(),
    'addCanonFacts': addCanonFacts.map((value) => value.toJson()).toList(),
    'openStoryThreads': openStoryThreads
        .map((value) => value.toJson())
        .toList(),
    'characterTransitions': characterTransitions
        .map((value) => value.toJson())
        .toList(),
    'advanceStoryThreads': advanceStoryThreads
        .map((value) => value.toJson())
        .toList(),
    'resolveStoryThreads': resolveStoryThreads
        .map((value) => value.toJson())
        .toList(),
    'relationshipChanges': relationshipChanges
        .map((value) => value.toJson())
        .toList(),
    'nextChapterIntent': nextChapterIntent.toJson(),
  };

  factory LivingDirectorPatch.fromJson(Map<String, Object?> json) {
    List<T> parseList<T>(String key, T Function(Map<String, Object?>) parser) =>
        List<T>.unmodifiable(
          (json[key] as List<Object?>? ?? const <Object?>[]).map(
            (value) => parser(_objectMap(value)),
          ),
        );
    return LivingDirectorPatch(
      schemaVersion: (json['schemaVersion']! as num).toInt(),
      runId: json['runId']! as String,
      basedOnRevision: (json['basedOnRevision']! as num).toInt(),
      addRosterPieces: parseList('addRosterPieces', LivingRosterPiece.fromJson),
      campaignComplete: json['campaignComplete'] as bool? ?? false,
      epilogue: json['epilogue'] as String?,
      completedChapter: LivingCompletedChapterPatch.fromJson(
        _objectMap(json['completedChapter']),
      ),
      addCharacters: parseList('addCharacters', LivingCharacter.fromJson),
      addEvents: parseList('addEvents', LivingCanonEvent.fromJson),
      addCanonFacts: parseList('addCanonFacts', LivingCanonFact.fromJson),
      openStoryThreads: parseList(
        'openStoryThreads',
        LivingStoryThread.fromJson,
      ),
      characterTransitions: parseList(
        'characterTransitions',
        LivingCharacterTransition.fromJson,
      ),
      advanceStoryThreads: parseList(
        'advanceStoryThreads',
        LivingThreadChange.fromJson,
      ),
      resolveStoryThreads: parseList(
        'resolveStoryThreads',
        LivingThreadChange.fromJson,
      ),
      relationshipChanges: parseList(
        'relationshipChanges',
        LivingRelationshipChange.fromJson,
      ),
      nextChapterIntent: LivingNextChapterIntent.fromJson(
        _objectMap(json['nextChapterIntent']),
      ),
    );
  }
}

@immutable
class LivingMissionObjective {
  const LivingMissionObjective({
    required this.type,
    required this.label,
    this.targetSquare,
    this.targetPieceId,
    this.surviveRounds,
    this.legacySurviveActionCount,
  });

  final LivingObjectiveType type;
  final String label;
  final Square? targetSquare;
  final String? targetPieceId;
  final int? surviveRounds;
  final int? legacySurviveActionCount;

  Map<String, Object?> toJson() => <String, Object?>{
    'type': type.name,
    'label': label,
    if (targetSquare != null) 'targetSquare': livingSquareName(targetSquare!),
    if (targetPieceId != null) 'targetPieceId': targetPieceId,
    if (surviveRounds != null) 'surviveRounds': surviveRounds,
    if (legacySurviveActionCount != null)
      'legacySurviveActionCount': legacySurviveActionCount,
  };

  factory LivingMissionObjective.fromJson(Map<String, Object?> json) {
    return LivingMissionObjective(
      type: _enumByName(LivingObjectiveType.values, json['type']),
      label: json['label']! as String,
      targetSquare: json['targetSquare'] == null
          ? null
          : livingSquareFromName(json['targetSquare']! as String),
      targetPieceId: json['targetPieceId'] as String?,
      surviveRounds:
          (json['surviveRounds'] as num?)?.toInt() ??
          ((json['surviveTurns'] as num?) == null
              ? null
              : (((json['surviveTurns']! as num).toInt() + 1) ~/ 2)),
      legacySurviveActionCount:
          (json['legacySurviveActionCount'] as num?)?.toInt() ??
          (json['surviveTurns'] as num?)?.toInt(),
    );
  }
}

@immutable
class LivingMissionPiece {
  const LivingMissionPiece({
    required this.pieceId,
    required this.pieceType,
    required this.color,
    required this.square,
    required this.countryId,
    required this.loyalty,
    required this.fairPrice,
    this.characterId,
    this.personalityId,
    this.hasMoved = false,
  });

  final String pieceId;
  final PieceType pieceType;
  final PieceColor color;
  final Square square;
  final String countryId;
  final int? loyalty;
  final int? fairPrice;
  final String? characterId;
  final String? personalityId;
  final bool hasMoved;

  ScenarioPiecePlacement toScenarioPlacement() => ScenarioPiecePlacement(
    square: square,
    piece: ChessPiece(
      id: pieceId,
      type: pieceType,
      color: color,
      countryId: countryId,
      loyalty: loyalty,
      fairPrice: fairPrice,
      characterId: characterId,
      personalityId: personalityId,
      hasMoved: hasMoved,
    ),
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'pieceId': pieceId,
    'pieceType': pieceType.name,
    'color': color.name,
    'square': livingSquareName(square),
    'countryId': countryId,
    if (loyalty != null) 'loyalty': loyalty,
    if (fairPrice != null) 'fairPrice': fairPrice,
    if (characterId != null) 'characterId': characterId,
    if (personalityId != null) 'personalityId': personalityId,
    'hasMoved': hasMoved,
  };

  factory LivingMissionPiece.fromJson(Map<String, Object?> json) {
    return LivingMissionPiece(
      pieceId: json['pieceId']! as String,
      pieceType: _enumByName(PieceType.values, json['pieceType']),
      color: _enumByName(PieceColor.values, json['color']),
      square: livingSquareFromName(json['square']! as String),
      countryId: json['countryId']! as String,
      loyalty: (json['loyalty'] as num?)?.toInt(),
      fairPrice: (json['fairPrice'] as num?)?.toInt(),
      characterId: json['characterId'] as String?,
      personalityId: json['personalityId'] as String?,
      hasMoved: json['hasMoved'] as bool? ?? false,
    );
  }
}

@immutable
class LivingDialogueLine {
  const LivingDialogueLine({
    required this.lineId,
    required this.speakerId,
    required this.side,
    required this.text,
  });

  final String lineId;
  final String speakerId;
  final String side;
  final String text;

  Map<String, Object?> toJson() => <String, Object?>{
    'lineId': lineId,
    'speakerId': speakerId,
    'side': side,
    'text': text,
  };

  factory LivingDialogueLine.fromJson(Map<String, Object?> json) {
    return LivingDialogueLine(
      lineId: json['lineId']! as String,
      speakerId: json['speakerId']! as String,
      side: json['side']! as String,
      text: json['text']! as String,
    );
  }
}

@immutable
class LivingChapterPackage {
  const LivingChapterPackage({
    required this.schemaVersion,
    required this.runId,
    required this.basedOnRevision,
    required this.chapterNumber,
    required this.chapterId,
    required this.title,
    required this.subtitle,
    required this.briefing,
    required this.objective,
    required this.whiteCountryId,
    required this.blackCountryId,
    required this.startingTurn,
    required this.battlefieldId,
    required this.seed,
    required this.economyEnabled,
    required this.merchantEnabled,
    required this.specialTilesEnabled,
    required this.whiteGold,
    required this.blackGold,
    required this.merchantSpeed,
    required this.pieces,
    required this.reservePieceIds,
    required this.dialogue,
    required this.aiAggression,
    required this.aiDefense,
    required this.aiObjectivePressure,
    required this.aiTileAppetite,
    this.pressureTier = 'even',
    this.portraitCharacterId,
    this.portraitPrompt,
  });

  final int schemaVersion;
  final String runId;
  final int basedOnRevision;
  final int chapterNumber;
  final String chapterId;
  final String title;
  final String subtitle;
  final String briefing;
  final String pressureTier;
  final LivingMissionObjective objective;
  final String whiteCountryId;
  final String blackCountryId;
  final PieceColor startingTurn;
  final BattlefieldId battlefieldId;
  final int seed;
  final bool economyEnabled;
  final bool merchantEnabled;
  final bool specialTilesEnabled;
  final int whiteGold;
  final int blackGold;
  final int merchantSpeed;
  final List<LivingMissionPiece> pieces;
  final List<String> reservePieceIds;
  final List<LivingDialogueLine> dialogue;
  final double aiAggression;
  final double aiDefense;
  final double aiObjectivePressure;
  final double aiTileAppetite;
  final String? portraitCharacterId;
  final String? portraitPrompt;

  LivingChapterPackage withPortraitCandidate({
    required String characterId,
    required String appearanceBrief,
  }) {
    final json = toJson();
    json['portraitCharacterId'] = characterId;
    json['portraitPrompt'] = appearanceBrief;
    return LivingChapterPackage.fromJson(json);
  }

  ScenarioGameSetup toScenarioSetup() => ScenarioGameSetup(
    id: chapterId,
    whiteCountryId: whiteCountryId,
    blackCountryId: blackCountryId,
    turn: startingTurn,
    battlefieldId: battlefieldId,
    battlefieldSeed: seed,
    whiteGold: whiteGold,
    blackGold: blackGold,
    merchantSpeed: merchantSpeed,
    economyEnabled: economyEnabled,
    merchantEnabled: merchantEnabled,
    specialTilesEnabled: specialTilesEnabled,
    pieces: pieces.map((piece) => piece.toScenarioPlacement()).toList(),
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': schemaVersion,
    'runId': runId,
    'basedOnRevision': basedOnRevision,
    'chapterNumber': chapterNumber,
    'chapterId': chapterId,
    'title': title,
    'subtitle': subtitle,
    'briefing': briefing,
    'pressureTier': pressureTier,
    'objective': objective.toJson(),
    'whiteCountryId': whiteCountryId,
    'blackCountryId': blackCountryId,
    'startingTurn': startingTurn.name,
    'battlefieldId': battlefieldId.name,
    'seed': seed,
    'economyEnabled': economyEnabled,
    'merchantEnabled': merchantEnabled,
    'specialTilesEnabled': specialTilesEnabled,
    'whiteGold': whiteGold,
    'blackGold': blackGold,
    'merchantSpeed': merchantSpeed,
    'pieces': pieces.map((value) => value.toJson()).toList(),
    'reservePieceIds': reservePieceIds,
    'dialogue': dialogue.map((value) => value.toJson()).toList(),
    'ai': <String, Object?>{
      'aggression': aiAggression,
      'defense': aiDefense,
      'objectivePressure': aiObjectivePressure,
      'tileAppetite': aiTileAppetite,
    },
    if (portraitCharacterId != null) 'portraitCharacterId': portraitCharacterId,
    if (portraitPrompt != null) 'portraitPrompt': portraitPrompt,
  };

  factory LivingChapterPackage.fromJson(Map<String, Object?> json) {
    final ai = _objectMap(json['ai']);
    return LivingChapterPackage(
      schemaVersion: (json['schemaVersion']! as num).toInt(),
      runId: json['runId']! as String,
      basedOnRevision: (json['basedOnRevision']! as num).toInt(),
      chapterNumber: (json['chapterNumber']! as num).toInt(),
      chapterId: json['chapterId']! as String,
      title: json['title']! as String,
      subtitle: json['subtitle']! as String,
      briefing: json['briefing']! as String,
      pressureTier: json['pressureTier'] as String? ?? 'even',
      objective: LivingMissionObjective.fromJson(_objectMap(json['objective'])),
      whiteCountryId: json['whiteCountryId']! as String,
      blackCountryId: json['blackCountryId']! as String,
      startingTurn: _enumByName(PieceColor.values, json['startingTurn']),
      battlefieldId: _enumByName(BattlefieldId.values, json['battlefieldId']),
      seed: (json['seed']! as num).toInt(),
      economyEnabled: json['economyEnabled']! as bool,
      merchantEnabled: json['merchantEnabled']! as bool,
      specialTilesEnabled: json['specialTilesEnabled']! as bool,
      whiteGold: (json['whiteGold']! as num).toInt(),
      blackGold: (json['blackGold']! as num).toInt(),
      merchantSpeed: (json['merchantSpeed']! as num).toInt(),
      pieces: List.unmodifiable(
        (json['pieces']! as List<Object?>).map(
          (value) => LivingMissionPiece.fromJson(_objectMap(value)),
        ),
      ),
      reservePieceIds: _strings(json['reservePieceIds']),
      dialogue: List.unmodifiable(
        (json['dialogue']! as List<Object?>).map(
          (value) => LivingDialogueLine.fromJson(_objectMap(value)),
        ),
      ),
      aiAggression: (ai['aggression']! as num).toDouble(),
      aiDefense: (ai['defense']! as num).toDouble(),
      aiObjectivePressure: (ai['objectivePressure']! as num).toDouble(),
      aiTileAppetite: (ai['tileAppetite']! as num).toDouble(),
      portraitCharacterId: json['portraitCharacterId'] as String?,
      portraitPrompt: json['portraitPrompt'] as String?,
    );
  }
}

/// Durable boundary between the accepted Story Director decision and the
/// remaining Mission Builder / portrait work.
///
/// The post-Director canon is committed directly to [LivingCampaignRun.canon].
/// This checkpoint retains the locked patch and, once available, the validated
/// chapter package. An interrupted or failed paid request can therefore resume
/// without asking the Director to make the same story decision again.
@immutable
class LivingChapterGenerationCheckpoint {
  const LivingChapterGenerationCheckpoint({
    required this.outcomeChapterId,
    required this.directorPatch,
    this.chapterPackage,
  });

  final String outcomeChapterId;
  final LivingDirectorPatch directorPatch;
  final LivingChapterPackage? chapterPackage;

  LivingChapterGenerationCheckpoint copyWith({
    LivingChapterPackage? chapterPackage,
  }) => LivingChapterGenerationCheckpoint(
    outcomeChapterId: outcomeChapterId,
    directorPatch: directorPatch,
    chapterPackage: chapterPackage ?? this.chapterPackage,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'outcomeChapterId': outcomeChapterId,
    'directorPatch': directorPatch.toJson(),
    if (chapterPackage != null) 'chapterPackage': chapterPackage!.toJson(),
  };

  factory LivingChapterGenerationCheckpoint.fromJson(
    Map<String, Object?> json,
  ) => LivingChapterGenerationCheckpoint(
    outcomeChapterId: json['outcomeChapterId']! as String,
    directorPatch: LivingDirectorPatch.fromJson(
      _objectMap(json['directorPatch']),
    ),
    chapterPackage: json['chapterPackage'] == null
        ? null
        : LivingChapterPackage.fromJson(_objectMap(json['chapterPackage'])),
  );
}

@immutable
class LivingGenerationJob {
  const LivingGenerationJob({
    required this.jobId,
    required this.stage,
    required this.status,
    required this.attempt,
    required this.createdAt,
    required this.updatedAt,
    this.settingsSnapshot = const <String, Object?>{},
    this.transportType,
    this.providerRequestId,
    this.lastActivityAt,
    this.receivedContentCharacters = 0,
    this.errorCode,
    this.errorMessage,
  });

  final String jobId;
  final LivingGenerationStage stage;
  final LivingGenerationStatus status;
  final int attempt;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Map<String, Object?> settingsSnapshot;
  final String? transportType;
  final String? providerRequestId;
  final DateTime? lastActivityAt;
  final int receivedContentCharacters;
  final String? errorCode;
  final String? errorMessage;

  LivingGenerationJob copyWith({
    LivingGenerationStage? stage,
    LivingGenerationStatus? status,
    int? attempt,
    DateTime? updatedAt,
    Map<String, Object?>? settingsSnapshot,
    String? transportType,
    String? providerRequestId,
    DateTime? lastActivityAt,
    int? receivedContentCharacters,
    String? errorCode,
    String? errorMessage,
    bool clearError = false,
  }) => LivingGenerationJob(
    jobId: jobId,
    stage: stage ?? this.stage,
    status: status ?? this.status,
    attempt: attempt ?? this.attempt,
    createdAt: createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    settingsSnapshot: Map<String, Object?>.unmodifiable(
      settingsSnapshot ?? this.settingsSnapshot,
    ),
    transportType: transportType ?? this.transportType,
    providerRequestId: providerRequestId ?? this.providerRequestId,
    lastActivityAt: lastActivityAt ?? this.lastActivityAt,
    receivedContentCharacters:
        receivedContentCharacters ?? this.receivedContentCharacters,
    errorCode: clearError ? null : errorCode ?? this.errorCode,
    errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'jobId': jobId,
    'stage': stage.name,
    'status': status.name,
    'attempt': attempt,
    'createdAt': createdAt.toUtc().toIso8601String(),
    'updatedAt': updatedAt.toUtc().toIso8601String(),
    'settingsSnapshot': settingsSnapshot,
    if (transportType != null) 'transportType': transportType,
    if (providerRequestId != null) 'providerRequestId': providerRequestId,
    if (lastActivityAt != null)
      'lastActivityAt': lastActivityAt!.toUtc().toIso8601String(),
    'receivedContentCharacters': receivedContentCharacters,
    if (errorCode != null) 'errorCode': errorCode,
    if (errorMessage != null) 'errorMessage': errorMessage,
  };

  factory LivingGenerationJob.fromJson(Map<String, Object?> json) {
    return LivingGenerationJob(
      jobId: json['jobId']! as String,
      stage: _enumByName(LivingGenerationStage.values, json['stage']),
      status: _enumByName(LivingGenerationStatus.values, json['status']),
      attempt: (json['attempt']! as num).toInt(),
      createdAt: DateTime.parse(json['createdAt']! as String),
      updatedAt: DateTime.parse(json['updatedAt']! as String),
      settingsSnapshot: Map.unmodifiable(
        _optionalObjectMap(json['settingsSnapshot']) ?? const {},
      ),
      transportType: json['transportType'] as String?,
      providerRequestId: json['providerRequestId'] as String?,
      lastActivityAt: json['lastActivityAt'] == null
          ? null
          : DateTime.parse(json['lastActivityAt']! as String),
      receivedContentCharacters:
          (json['receivedContentCharacters'] as num?)?.toInt() ?? 0,
      errorCode: json['errorCode'] as String?,
      errorMessage: json['errorMessage'] as String?,
    );
  }
}

@immutable
class LivingGenerationRecord {
  const LivingGenerationRecord({
    required this.recordId,
    required this.stage,
    required this.attempt,
    required this.status,
    required this.model,
    required this.startedAt,
    required this.finishedAt,
    required this.requestPayload,
    required this.responsePayload,
    required this.inputTokens,
    this.contentLocale = 'en',
    this.providerRequestId,
    this.transportType,
    this.timeToFirstEventMs,
    this.durationMs,
    this.usage = const <String, Object?>{},
    this.finishReason,
    this.errorCode,
    this.errorMessage,
    this.rawSse = '',
    this.rawContent = '',
    this.validationIssues = const <String>[],
    this.validationWarnings = const <String>[],
    this.repairsRecordId,
  });

  final String recordId;
  final LivingGenerationStage stage;
  final int attempt;
  final LivingGenerationStatus status;
  final String model;
  final DateTime startedAt;
  final DateTime finishedAt;
  final Map<String, Object?> requestPayload;
  final Map<String, Object?> responsePayload;
  final int? inputTokens;
  final String contentLocale;
  final String? providerRequestId;
  final String? transportType;
  final int? timeToFirstEventMs;
  final int? durationMs;
  final Map<String, Object?> usage;
  final String? finishReason;
  final String? errorCode;
  final String? errorMessage;
  final String rawSse;
  final String rawContent;
  final List<String> validationIssues;
  final List<String> validationWarnings;
  final String? repairsRecordId;

  LivingGenerationRecord copyWith({
    LivingGenerationStatus? status,
    List<String>? validationIssues,
    List<String>? validationWarnings,
    String? errorCode,
    String? errorMessage,
  }) => LivingGenerationRecord(
    recordId: recordId,
    stage: stage,
    attempt: attempt,
    status: status ?? this.status,
    model: model,
    startedAt: startedAt,
    finishedAt: finishedAt,
    requestPayload: requestPayload,
    responsePayload: responsePayload,
    inputTokens: inputTokens,
    contentLocale: contentLocale,
    providerRequestId: providerRequestId,
    transportType: transportType,
    timeToFirstEventMs: timeToFirstEventMs,
    durationMs: durationMs,
    usage: usage,
    finishReason: finishReason,
    errorCode: errorCode ?? this.errorCode,
    errorMessage: errorMessage ?? this.errorMessage,
    rawSse: rawSse,
    rawContent: rawContent,
    validationIssues: validationIssues ?? this.validationIssues,
    validationWarnings: validationWarnings ?? this.validationWarnings,
    repairsRecordId: repairsRecordId,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'recordId': recordId,
    'stage': stage.name,
    'attempt': attempt,
    'status': status.name,
    'model': model,
    'startedAt': startedAt.toUtc().toIso8601String(),
    'finishedAt': finishedAt.toUtc().toIso8601String(),
    'requestPayload': requestPayload,
    'responsePayload': responsePayload,
    if (inputTokens != null) 'inputTokens': inputTokens,
    'contentLocale': contentLocale,
    if (providerRequestId != null) 'providerRequestId': providerRequestId,
    if (transportType != null) 'transportType': transportType,
    if (timeToFirstEventMs != null) 'timeToFirstEventMs': timeToFirstEventMs,
    if (durationMs != null) 'durationMs': durationMs,
    if (usage.isNotEmpty) 'usage': usage,
    if (finishReason != null) 'finishReason': finishReason,
    if (errorCode != null) 'errorCode': errorCode,
    if (errorMessage != null) 'errorMessage': errorMessage,
    if (rawSse.isNotEmpty) 'rawSse': rawSse,
    if (rawContent.isNotEmpty) 'rawContent': rawContent,
    if (validationIssues.isNotEmpty) 'validationIssues': validationIssues,
    if (validationWarnings.isNotEmpty) 'validationWarnings': validationWarnings,
    if (repairsRecordId != null) 'repairsRecordId': repairsRecordId,
  };

  factory LivingGenerationRecord.fromJson(Map<String, Object?> json) {
    return LivingGenerationRecord(
      recordId: json['recordId']! as String,
      stage: _enumByName(LivingGenerationStage.values, json['stage']),
      attempt: (json['attempt']! as num).toInt(),
      status: _enumByName(LivingGenerationStatus.values, json['status']),
      model: json['model']! as String,
      startedAt: DateTime.parse(json['startedAt']! as String),
      finishedAt: DateTime.parse(json['finishedAt']! as String),
      requestPayload: Map.unmodifiable(_objectMap(json['requestPayload'])),
      responsePayload: Map.unmodifiable(_objectMap(json['responsePayload'])),
      inputTokens: (json['inputTokens'] as num?)?.toInt(),
      contentLocale: json['contentLocale'] as String? ?? 'en',
      providerRequestId: json['providerRequestId'] as String?,
      transportType: json['transportType'] as String?,
      timeToFirstEventMs: (json['timeToFirstEventMs'] as num?)?.toInt(),
      durationMs: (json['durationMs'] as num?)?.toInt(),
      usage: Map.unmodifiable(_optionalObjectMap(json['usage']) ?? const {}),
      finishReason: json['finishReason'] as String?,
      errorCode: json['errorCode'] as String?,
      errorMessage: json['errorMessage'] as String?,
      rawSse: json['rawSse'] as String? ?? '',
      rawContent: json['rawContent'] as String? ?? '',
      validationIssues: _strings(json['validationIssues']),
      validationWarnings: _strings(json['validationWarnings']),
      repairsRecordId: json['repairsRecordId'] as String?,
    );
  }
}

@immutable
class LivingNamedPieceRecord {
  const LivingNamedPieceRecord({
    required this.name,
    required this.characterId,
    required this.pieceId,
    required this.pieceType,
    required this.status,
    required this.recruitable,
    required this.description,
    required this.discoveredMission,
    required this.lastKnownMission,
    this.loyalty,
    this.portraitPath,
    this.portraitAppearanceBrief,
    this.needsNaming = false,
  });

  final String name;
  final String characterId;
  final String pieceId;
  final PieceType pieceType;
  final LivingNamedPieceStatus status;
  final bool recruitable;
  final String description;
  final int? loyalty;
  final String? portraitPath;
  final String? portraitAppearanceBrief;
  final bool needsNaming;
  final int discoveredMission;
  final int lastKnownMission;

  bool get isAlive => status != LivingNamedPieceStatus.dead;

  LivingNamedPieceRecord copyWith({
    String? name,
    LivingNamedPieceStatus? status,
    int? loyalty,
    String? portraitPath,
    int? lastKnownMission,
    String? description,
    String? portraitAppearanceBrief,
    bool? needsNaming,
  }) => LivingNamedPieceRecord(
    name: name ?? this.name,
    characterId: characterId,
    pieceId: pieceId,
    pieceType: pieceType,
    status: status ?? this.status,
    recruitable: recruitable,
    description: description ?? this.description,
    loyalty: pieceType == PieceType.king ? null : loyalty ?? this.loyalty,
    portraitPath: portraitPath ?? this.portraitPath,
    portraitAppearanceBrief:
        portraitAppearanceBrief ?? this.portraitAppearanceBrief,
    needsNaming: needsNaming ?? this.needsNaming,
    discoveredMission: discoveredMission,
    lastKnownMission: lastKnownMission ?? this.lastKnownMission,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'name': name,
    'characterId': characterId,
    'pieceId': pieceId,
    'pieceType': pieceType.name,
    'status': status.name,
    'recruitable': recruitable,
    'description': description,
    if (loyalty != null) 'loyalty': loyalty,
    if (portraitPath != null) 'portraitPath': portraitPath,
    if (portraitAppearanceBrief != null)
      'portraitAppearanceBrief': portraitAppearanceBrief,
    'needsNaming': needsNaming,
    'discoveredMission': discoveredMission,
    'lastKnownMission': lastKnownMission,
  };

  factory LivingNamedPieceRecord.fromJson(Map<String, Object?> json) =>
      LivingNamedPieceRecord(
        name: json['name']! as String,
        characterId: json['characterId']! as String,
        pieceId: json['pieceId']! as String,
        pieceType: _enumByName(PieceType.values, json['pieceType']),
        status: _enumByName(LivingNamedPieceStatus.values, json['status']),
        recruitable: json['recruitable']! as bool,
        description: json['description']! as String,
        loyalty: (json['loyalty'] as num?)?.toInt(),
        portraitPath: json['portraitPath'] as String?,
        portraitAppearanceBrief: json['portraitAppearanceBrief'] as String?,
        needsNaming: json['needsNaming'] as bool? ?? false,
        discoveredMission: (json['discoveredMission']! as num).toInt(),
        lastKnownMission: (json['lastKnownMission']! as num).toInt(),
      );
}

@immutable
class LivingIdentityAssignment {
  const LivingIdentityAssignment({
    required this.characterId,
    required this.name,
    required this.description,
    required this.portraitAppearanceBrief,
  });

  final String characterId;
  final String name;
  final String description;
  final String portraitAppearanceBrief;

  Map<String, Object?> toJson() => <String, Object?>{
    'characterId': characterId,
    'name': name,
    'description': description,
    'portraitAppearanceBrief': portraitAppearanceBrief,
  };

  factory LivingIdentityAssignment.fromJson(Map<String, Object?> json) =>
      LivingIdentityAssignment(
        characterId: json['characterId']! as String,
        name: json['name']! as String,
        description: json['description']! as String,
        portraitAppearanceBrief: json['portraitAppearanceBrief']! as String,
      );
}

@immutable
class LivingAftermathLine {
  const LivingAftermathLine({
    required this.lineId,
    required this.side,
    required this.text,
    this.speakerId,
  });

  final String lineId;
  final String? speakerId;
  final String side;
  final String text;

  Map<String, Object?> toJson() => <String, Object?>{
    'lineId': lineId,
    'speakerId': speakerId,
    'side': side,
    'text': text,
  };

  factory LivingAftermathLine.fromJson(Map<String, Object?> json) =>
      LivingAftermathLine(
        lineId: json['lineId']! as String,
        speakerId: json['speakerId'] as String?,
        side: json['side']! as String,
        text: json['text']! as String,
      );
}

@immutable
class LivingAftermathScene {
  const LivingAftermathScene({
    required this.runId,
    required this.missionNumber,
    required this.missionId,
    required this.lines,
  });

  final String runId;
  final int missionNumber;
  final String missionId;
  final List<LivingAftermathLine> lines;

  Map<String, Object?> toJson() => <String, Object?>{
    'runId': runId,
    'missionNumber': missionNumber,
    'missionId': missionId,
    'lines': lines.map((line) => line.toJson()).toList(growable: false),
  };

  factory LivingAftermathScene.fromJson(Map<String, Object?> json) =>
      LivingAftermathScene(
        runId: json['runId']! as String,
        missionNumber: (json['missionNumber']! as num).toInt(),
        missionId: json['missionId']! as String,
        lines: List.unmodifiable(
          (json['lines']! as List<Object?>).map(
            (value) => LivingAftermathLine.fromJson(_objectMap(value)),
          ),
        ),
      );
}

@immutable
class LivingChroniclerClosureResult {
  const LivingChroniclerClosureResult({
    required this.memory,
    required this.identityAssignments,
    required this.aftermath,
  });

  final LivingMissionMemory memory;
  final List<LivingIdentityAssignment> identityAssignments;
  final LivingAftermathScene aftermath;

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': 3,
    ...memory.toJson(),
    'identityAssignments': identityAssignments
        .map((assignment) => assignment.toJson())
        .toList(growable: false),
    'aftermath': aftermath.lines
        .map((line) => line.toJson())
        .toList(growable: false),
  };

  factory LivingChroniclerClosureResult.fromJson(Map<String, Object?> json) {
    if ((json['schemaVersion'] as num?)?.toInt() != 3) {
      throw const FormatException('Unsupported Chronicler closure schema.');
    }
    final memory = LivingMissionMemory.fromJson(json);
    return LivingChroniclerClosureResult(
      memory: memory,
      identityAssignments: List.unmodifiable(
        (json['identityAssignments']! as List<Object?>).map(
          (value) => LivingIdentityAssignment.fromJson(_objectMap(value)),
        ),
      ),
      aftermath: LivingAftermathScene(
        runId: memory.runId,
        missionNumber: memory.missionNumber,
        missionId: memory.missionId,
        lines: List.unmodifiable(
          (json['aftermath']! as List<Object?>).map(
            (value) => LivingAftermathLine.fromJson(_objectMap(value)),
          ),
        ),
      ),
    );
  }
}

@immutable
class LivingMissionMemory {
  const LivingMissionMemory({
    required this.runId,
    required this.missionNumber,
    required this.missionId,
    required this.setupSummary,
    required this.battleSummary,
    this.characterIds = const <String>[],
    this.keyEventIds = const <String>[],
  });

  final String runId;
  final int missionNumber;
  final String missionId;
  final String setupSummary;
  final String battleSummary;
  final List<String> characterIds;
  final List<String> keyEventIds;

  Map<String, Object?> toJson() => <String, Object?>{
    'runId': runId,
    'missionNumber': missionNumber,
    'missionId': missionId,
    'setupSummary': setupSummary,
    'battleSummary': battleSummary,
    'characterIds': characterIds,
    'keyEventIds': keyEventIds,
  };

  factory LivingMissionMemory.fromJson(Map<String, Object?> json) =>
      LivingMissionMemory(
        runId: json['runId']! as String,
        missionNumber: (json['missionNumber']! as num).toInt(),
        missionId: json['missionId']! as String,
        setupSummary: json['setupSummary']! as String,
        battleSummary: json['battleSummary']! as String,
        characterIds: _strings(json['characterIds']),
        keyEventIds: _strings(json['keyEventIds']),
      );
}

@immutable
class LivingHistoryDigest {
  const LivingHistoryDigest({
    required this.schemaVersion,
    required this.runId,
    required this.digestId,
    required this.sourceMissionIds,
    required this.narrative,
    required this.sourceTokens,
    required this.digestTokens,
  });

  final int schemaVersion;
  final String runId;
  final String digestId;
  final List<String> sourceMissionIds;
  final String narrative;
  final int sourceTokens;
  final int digestTokens;

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': schemaVersion,
    'runId': runId,
    'digestId': digestId,
    'sourceMissionIds': sourceMissionIds,
    'narrative': narrative,
    'sourceTokens': sourceTokens,
    'digestTokens': digestTokens,
  };

  factory LivingHistoryDigest.fromJson(Map<String, Object?> json) =>
      LivingHistoryDigest(
        schemaVersion: (json['schemaVersion']! as num).toInt(),
        runId: json['runId']! as String,
        digestId: json['digestId']! as String,
        sourceMissionIds: _strings(json['sourceMissionIds']),
        narrative: json['narrative']! as String,
        sourceTokens: (json['sourceTokens']! as num).toInt(),
        digestTokens: (json['digestTokens']! as num).toInt(),
      );
}

@immutable
class LivingDirectorNewCharacter {
  const LivingDirectorNewCharacter({
    required this.name,
    required this.characterId,
    required this.pieceId,
    required this.pieceType,
    required this.status,
    required this.recruitable,
    required this.description,
    this.loyalty,
    this.portraitPrompt,
  });

  final String name;
  final String characterId;
  final String pieceId;
  final PieceType pieceType;
  final LivingNamedPieceStatus status;
  final bool recruitable;
  final String description;
  final int? loyalty;
  final String? portraitPrompt;

  Map<String, Object?> toJson() => <String, Object?>{
    'name': name,
    'characterId': characterId,
    'pieceId': pieceId,
    'pieceType': pieceType.name,
    'status': status.name,
    'recruitable': recruitable,
    'description': description,
    if (loyalty != null) 'loyalty': loyalty,
    if (portraitPrompt != null) 'portraitPrompt': portraitPrompt,
  };

  factory LivingDirectorNewCharacter.fromJson(Map<String, Object?> json) =>
      LivingDirectorNewCharacter(
        name: json['name']! as String,
        characterId: json['characterId']! as String,
        pieceId: json['pieceId']! as String,
        pieceType: _enumByName(PieceType.values, json['pieceType']),
        status: _enumByName(LivingNamedPieceStatus.values, json['status']),
        recruitable: json['recruitable']! as bool,
        description: json['description']! as String,
        loyalty: (json['loyalty'] as num?)?.toInt(),
        portraitPrompt: json['portraitPrompt'] as String?,
      );
}

@immutable
class LivingDirectorStatusChange {
  const LivingDirectorStatusChange({
    required this.characterId,
    required this.fromStatus,
    required this.toStatus,
    required this.reason,
  });

  final String characterId;
  final LivingNamedPieceStatus fromStatus;
  final LivingNamedPieceStatus toStatus;
  final String reason;

  Map<String, Object?> toJson() => <String, Object?>{
    'characterId': characterId,
    'fromStatus': fromStatus.name,
    'toStatus': toStatus.name,
    'reason': reason,
  };

  factory LivingDirectorStatusChange.fromJson(Map<String, Object?> json) =>
      LivingDirectorStatusChange(
        characterId: json['characterId']! as String,
        fromStatus: _enumByName(
          LivingNamedPieceStatus.values,
          json['fromStatus'],
        ),
        toStatus: _enumByName(LivingNamedPieceStatus.values, json['toStatus']),
        reason: json['reason']! as String,
      );
}

@immutable
class LivingV2DirectorDecision {
  const LivingV2DirectorDecision({
    required this.schemaVersion,
    required this.runId,
    required this.basedOnMissionNumber,
    required this.nextMissionNumber,
    required this.title,
    required this.subtitle,
    required this.background,
    required this.dialogue,
    required this.objectiveType,
    required this.objectiveLabel,
    required this.participantCharacterIds,
    required this.enemyNamedCharacterIds,
    required this.statusChanges,
    required this.pressureTier,
    required this.rewardTier,
    required this.finaleKind,
    required this.campaignComplete,
    this.targetCharacterId,
    this.targetSquare,
    this.surviveRounds,
    this.legacySurviveActionCount,
    this.epilogue,
    this.newCharacter,
  });

  final int schemaVersion;
  final String runId;
  final int basedOnMissionNumber;
  final int nextMissionNumber;
  final String title;
  final String subtitle;
  final String background;
  final List<LivingDialogueLine> dialogue;
  final LivingObjectiveType objectiveType;
  final String objectiveLabel;
  final String? targetCharacterId;
  final String? targetSquare;
  final int? surviveRounds;
  final int? legacySurviveActionCount;
  final List<String> participantCharacterIds;
  final List<String> enemyNamedCharacterIds;
  final List<LivingDirectorStatusChange> statusChanges;
  final String pressureTier;
  final int rewardTier;
  final LivingFinaleKind finaleKind;
  final bool campaignComplete;
  final String? epilogue;
  final LivingDirectorNewCharacter? newCharacter;

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': schemaVersion,
    'runId': runId,
    'basedOnMissionNumber': basedOnMissionNumber,
    'nextMissionNumber': nextMissionNumber,
    'title': title,
    'subtitle': subtitle,
    'background': background,
    'dialogue': dialogue.map((value) => value.toJson()).toList(),
    'objectiveType': objectiveType.name,
    'objectiveLabel': objectiveLabel,
    if (targetCharacterId != null) 'targetCharacterId': targetCharacterId,
    if (targetSquare != null) 'targetSquare': targetSquare,
    if (surviveRounds != null) 'surviveRounds': surviveRounds,
    if (legacySurviveActionCount != null)
      'legacySurviveActionCount': legacySurviveActionCount,
    'participantCharacterIds': participantCharacterIds,
    'enemyNamedCharacterIds': enemyNamedCharacterIds,
    'statusChanges': statusChanges.map((value) => value.toJson()).toList(),
    'pressureTier': pressureTier,
    'rewardTier': rewardTier,
    'finaleKind': finaleKind.name,
    'campaignComplete': campaignComplete,
    if (epilogue != null) 'epilogue': epilogue,
    if (newCharacter != null) 'newCharacter': newCharacter!.toJson(),
  };

  factory LivingV2DirectorDecision.fromJson(Map<String, Object?> json) =>
      LivingV2DirectorDecision(
        schemaVersion: (json['schemaVersion']! as num).toInt(),
        runId: json['runId']! as String,
        basedOnMissionNumber: (json['basedOnMissionNumber']! as num).toInt(),
        nextMissionNumber: (json['nextMissionNumber']! as num).toInt(),
        title: json['title']! as String,
        subtitle: json['subtitle']! as String,
        background: json['background']! as String,
        dialogue: List.unmodifiable(
          (json['dialogue']! as List<Object?>).map(
            (value) => LivingDialogueLine.fromJson(_objectMap(value)),
          ),
        ),
        objectiveType: _enumByName(
          LivingObjectiveType.values,
          json['objectiveType'],
        ),
        objectiveLabel: json['objectiveLabel']! as String,
        targetCharacterId: json['targetCharacterId'] as String?,
        targetSquare: json['targetSquare'] as String?,
        surviveRounds:
            (json['surviveRounds'] as num?)?.toInt() ??
            ((json['surviveTurns'] as num?) == null
                ? null
                : (((json['surviveTurns']! as num).toInt() + 1) ~/ 2)),
        legacySurviveActionCount:
            (json['legacySurviveActionCount'] as num?)?.toInt() ??
            (json['surviveTurns'] as num?)?.toInt(),
        participantCharacterIds: _strings(json['participantCharacterIds']),
        enemyNamedCharacterIds: _strings(json['enemyNamedCharacterIds']),
        statusChanges: List.unmodifiable(
          (json['statusChanges']! as List<Object?>).map(
            (value) => LivingDirectorStatusChange.fromJson(_objectMap(value)),
          ),
        ),
        pressureTier: json['pressureTier']! as String,
        rewardTier: (json['rewardTier']! as num).toInt(),
        finaleKind: _enumByName(LivingFinaleKind.values, json['finaleKind']),
        campaignComplete: json['campaignComplete']! as bool,
        epilogue: json['epilogue'] as String?,
        newCharacter: json['newCharacter'] == null
            ? null
            : LivingDirectorNewCharacter.fromJson(
                _objectMap(json['newCharacter']),
              ),
      );
}

@immutable
class LivingV2BuilderDecision {
  const LivingV2BuilderDecision({
    required this.schemaVersion,
    required this.runId,
    required this.missionNumber,
    required this.blackCountryId,
    required this.startingTurn,
    required this.battlefieldId,
    required this.seed,
    required this.blackGold,
    required this.merchantSpeed,
    required this.enemyPieces,
  });

  final int schemaVersion;
  final String runId;
  final int missionNumber;
  final String blackCountryId;
  final PieceColor startingTurn;
  final BattlefieldId battlefieldId;
  final int seed;
  final int blackGold;
  final int merchantSpeed;
  final List<LivingMissionPiece> enemyPieces;

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': schemaVersion,
    'runId': runId,
    'missionNumber': missionNumber,
    'blackCountryId': blackCountryId,
    'startingTurn': startingTurn.name,
    'battlefieldId': battlefieldId.name,
    'seed': seed,
    'blackGold': blackGold,
    'merchantSpeed': merchantSpeed,
    'enemyPieces': enemyPieces.map((value) => value.toJson()).toList(),
  };

  factory LivingV2BuilderDecision.fromJson(Map<String, Object?> json) =>
      LivingV2BuilderDecision(
        schemaVersion: (json['schemaVersion']! as num).toInt(),
        runId: json['runId']! as String,
        missionNumber: (json['missionNumber']! as num).toInt(),
        blackCountryId: json['blackCountryId']! as String,
        startingTurn: _enumByName(PieceColor.values, json['startingTurn']),
        battlefieldId: _enumByName(BattlefieldId.values, json['battlefieldId']),
        seed: (json['seed']! as num).toInt(),
        blackGold: (json['blackGold']! as num).toInt(),
        merchantSpeed: (json['merchantSpeed']! as num).toInt(),
        enemyPieces: List.unmodifiable(
          (json['enemyPieces']! as List<Object?>).map(
            (value) => LivingMissionPiece.fromJson(_objectMap(value)),
          ),
        ),
      );
}

@immutable
class LivingV2GenerationCheckpoint {
  const LivingV2GenerationCheckpoint({
    required this.outcomeMissionId,
    this.missionMemory,
    this.directorDecision,
    this.chapterPackage,
  });

  final String outcomeMissionId;
  final LivingMissionMemory? missionMemory;
  final LivingV2DirectorDecision? directorDecision;
  final LivingChapterPackage? chapterPackage;

  LivingV2GenerationCheckpoint copyWith({
    LivingMissionMemory? missionMemory,
    LivingV2DirectorDecision? directorDecision,
    LivingChapterPackage? chapterPackage,
  }) => LivingV2GenerationCheckpoint(
    outcomeMissionId: outcomeMissionId,
    missionMemory: missionMemory ?? this.missionMemory,
    directorDecision: directorDecision ?? this.directorDecision,
    chapterPackage: chapterPackage ?? this.chapterPackage,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'outcomeMissionId': outcomeMissionId,
    if (missionMemory != null) 'missionMemory': missionMemory!.toJson(),
    if (directorDecision != null)
      'directorDecision': directorDecision!.toJson(),
    if (chapterPackage != null) 'chapterPackage': chapterPackage!.toJson(),
  };

  factory LivingV2GenerationCheckpoint.fromJson(Map<String, Object?> json) =>
      LivingV2GenerationCheckpoint(
        outcomeMissionId: json['outcomeMissionId']! as String,
        missionMemory: json['missionMemory'] == null
            ? null
            : LivingMissionMemory.fromJson(_objectMap(json['missionMemory'])),
        directorDecision: json['directorDecision'] == null
            ? null
            : LivingV2DirectorDecision.fromJson(
                _objectMap(json['directorDecision']),
              ),
        chapterPackage: json['chapterPackage'] == null
            ? null
            : LivingChapterPackage.fromJson(_objectMap(json['chapterPackage'])),
      );
}

@immutable
class LivingPortraitCheckpoint {
  const LivingPortraitCheckpoint({
    required this.runId,
    required this.missionId,
    required this.missionNumber,
    required this.characterId,
    required this.attempt,
    required this.seed,
    required this.status,
    required this.appearanceBrief,
    required this.promptAsset,
    required this.createdAt,
    required this.updatedAt,
    this.finalPrompt,
    this.referenceHashes = const <String>[],
    this.sourceReference,
    this.processedReference,
    this.providerRequestId,
    this.durationMs,
    this.errorCode,
    this.errorMessage,
  });

  final String runId;
  final String missionId;
  final int missionNumber;
  final String characterId;
  final int attempt;
  final int seed;
  final LivingPortraitStatus status;
  final String appearanceBrief;
  final String promptAsset;
  final String? finalPrompt;
  final List<String> referenceHashes;
  final String? sourceReference;
  final String? processedReference;
  final String? providerRequestId;
  final int? durationMs;
  final String? errorCode;
  final String? errorMessage;
  final DateTime createdAt;
  final DateTime updatedAt;

  LivingPortraitCheckpoint copyWith({
    int? attempt,
    LivingPortraitStatus? status,
    DateTime? updatedAt,
    String? finalPrompt,
    List<String>? referenceHashes,
    String? sourceReference,
    String? processedReference,
    String? providerRequestId,
    int? durationMs,
    String? errorCode,
    String? errorMessage,
    bool clearFailure = false,
  }) => LivingPortraitCheckpoint(
    runId: runId,
    missionId: missionId,
    missionNumber: missionNumber,
    characterId: characterId,
    attempt: attempt ?? this.attempt,
    seed: seed,
    status: status ?? this.status,
    appearanceBrief: appearanceBrief,
    promptAsset: promptAsset,
    finalPrompt: finalPrompt ?? this.finalPrompt,
    referenceHashes: List.unmodifiable(referenceHashes ?? this.referenceHashes),
    sourceReference: sourceReference ?? this.sourceReference,
    processedReference: processedReference ?? this.processedReference,
    providerRequestId: providerRequestId ?? this.providerRequestId,
    durationMs: durationMs ?? this.durationMs,
    errorCode: clearFailure ? null : errorCode ?? this.errorCode,
    errorMessage: clearFailure ? null : errorMessage ?? this.errorMessage,
    createdAt: createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'runId': runId,
    'missionId': missionId,
    'missionNumber': missionNumber,
    'characterId': characterId,
    'attempt': attempt,
    'seed': seed,
    'status': status.name,
    'appearanceBrief': appearanceBrief,
    'promptAsset': promptAsset,
    if (finalPrompt != null) 'finalPrompt': finalPrompt,
    'referenceHashes': referenceHashes,
    if (sourceReference != null) 'sourceReference': sourceReference,
    if (processedReference != null) 'processedReference': processedReference,
    if (providerRequestId != null) 'providerRequestId': providerRequestId,
    if (durationMs != null) 'durationMs': durationMs,
    if (errorCode != null) 'errorCode': errorCode,
    if (errorMessage != null) 'errorMessage': errorMessage,
    'createdAt': createdAt.toUtc().toIso8601String(),
    'updatedAt': updatedAt.toUtc().toIso8601String(),
  };

  factory LivingPortraitCheckpoint.fromJson(Map<String, Object?> json) =>
      LivingPortraitCheckpoint(
        runId: json['runId']! as String,
        missionId: json['missionId']! as String,
        missionNumber: (json['missionNumber']! as num).toInt(),
        characterId: json['characterId']! as String,
        attempt: (json['attempt']! as num).toInt(),
        seed: (json['seed']! as num).toInt(),
        status: _enumByName(LivingPortraitStatus.values, json['status']),
        appearanceBrief: json['appearanceBrief']! as String,
        promptAsset: json['promptAsset']! as String,
        finalPrompt: json['finalPrompt'] as String?,
        referenceHashes: _strings(json['referenceHashes']),
        sourceReference: json['sourceReference'] as String?,
        processedReference: json['processedReference'] as String?,
        providerRequestId: json['providerRequestId'] as String?,
        durationMs: (json['durationMs'] as num?)?.toInt(),
        errorCode: json['errorCode'] as String?,
        errorMessage: json['errorMessage'] as String?,
        createdAt: DateTime.parse(json['createdAt']! as String),
        updatedAt: DateTime.parse(json['updatedAt']! as String),
      );
}

@immutable
class LivingChapterEndingArtCheckpoint {
  const LivingChapterEndingArtCheckpoint({
    required this.runId,
    required this.chapterId,
    required this.chapterNumber,
    required this.attempt,
    required this.seed,
    required this.status,
    required this.promptAsset,
    required this.createdAt,
    required this.updatedAt,
    this.finalPrompt,
    this.referenceHashes = const <String>[],
    this.sourceReference,
    this.processedReference,
    this.providerRequestId,
    this.durationMs,
    this.errorCode,
    this.errorMessage,
  });

  final String runId;
  final String chapterId;
  final int chapterNumber;
  final int attempt;
  final int seed;
  final LivingChapterArtStatus status;
  final String promptAsset;
  final String? finalPrompt;
  final List<String> referenceHashes;
  final String? sourceReference;
  final String? processedReference;
  final String? providerRequestId;
  final int? durationMs;
  final String? errorCode;
  final String? errorMessage;
  final DateTime createdAt;
  final DateTime updatedAt;

  LivingChapterEndingArtCheckpoint copyWith({
    int? attempt,
    int? seed,
    LivingChapterArtStatus? status,
    DateTime? updatedAt,
    String? finalPrompt,
    List<String>? referenceHashes,
    String? sourceReference,
    String? processedReference,
    String? providerRequestId,
    int? durationMs,
    String? errorCode,
    String? errorMessage,
    bool clearFailure = false,
  }) => LivingChapterEndingArtCheckpoint(
    runId: runId,
    chapterId: chapterId,
    chapterNumber: chapterNumber,
    attempt: attempt ?? this.attempt,
    seed: seed ?? this.seed,
    status: status ?? this.status,
    promptAsset: promptAsset,
    finalPrompt: finalPrompt ?? this.finalPrompt,
    referenceHashes: List.unmodifiable(referenceHashes ?? this.referenceHashes),
    sourceReference: sourceReference ?? this.sourceReference,
    processedReference: processedReference ?? this.processedReference,
    providerRequestId: providerRequestId ?? this.providerRequestId,
    durationMs: durationMs ?? this.durationMs,
    errorCode: clearFailure ? null : errorCode ?? this.errorCode,
    errorMessage: clearFailure ? null : errorMessage ?? this.errorMessage,
    createdAt: createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'runId': runId,
    'chapterId': chapterId,
    'chapterNumber': chapterNumber,
    'attempt': attempt,
    'seed': seed,
    'status': status.name,
    'promptAsset': promptAsset,
    if (finalPrompt != null) 'finalPrompt': finalPrompt,
    'referenceHashes': referenceHashes,
    if (sourceReference != null) 'sourceReference': sourceReference,
    if (processedReference != null) 'processedReference': processedReference,
    if (providerRequestId != null) 'providerRequestId': providerRequestId,
    if (durationMs != null) 'durationMs': durationMs,
    if (errorCode != null) 'errorCode': errorCode,
    if (errorMessage != null) 'errorMessage': errorMessage,
    'createdAt': createdAt.toUtc().toIso8601String(),
    'updatedAt': updatedAt.toUtc().toIso8601String(),
  };

  factory LivingChapterEndingArtCheckpoint.fromJson(
    Map<String, Object?> json,
  ) => LivingChapterEndingArtCheckpoint(
    runId: json['runId']! as String,
    chapterId: json['chapterId']! as String,
    chapterNumber: (json['chapterNumber']! as num).toInt(),
    attempt: (json['attempt']! as num).toInt(),
    seed: (json['seed']! as num).toInt(),
    status: _enumByName(LivingChapterArtStatus.values, json['status']),
    promptAsset: json['promptAsset']! as String,
    finalPrompt: json['finalPrompt'] as String?,
    referenceHashes: _strings(json['referenceHashes']),
    sourceReference: json['sourceReference'] as String?,
    processedReference: json['processedReference'] as String?,
    providerRequestId: json['providerRequestId'] as String?,
    durationMs: (json['durationMs'] as num?)?.toInt(),
    errorCode: json['errorCode'] as String?,
    errorMessage: json['errorMessage'] as String?,
    createdAt: DateTime.parse(json['createdAt']! as String),
    updatedAt: DateTime.parse(json['updatedAt']! as String),
  );
}

@immutable
class LivingChapterClosureCheckpoint {
  const LivingChapterClosureCheckpoint({
    required this.runId,
    required this.chapterId,
    required this.chapterNumber,
    required this.closureId,
    required this.textTaskId,
    required this.imageTaskId,
    required this.textAttempt,
    required this.imageAttempt,
    required this.textStatus,
    required this.imageStatus,
    required this.createdAt,
    required this.updatedAt,
    this.settingsSnapshot = const <String, Object?>{},
    this.textErrorCode,
    this.textErrorMessage,
    this.imageErrorCode,
    this.imageErrorMessage,
  });

  final String runId;
  final String chapterId;
  final int chapterNumber;
  final String closureId;
  final String textTaskId;
  final String imageTaskId;
  final int textAttempt;
  final int imageAttempt;
  final LivingClosureTaskStatus textStatus;
  final LivingClosureTaskStatus imageStatus;
  final Map<String, Object?> settingsSnapshot;
  final String? textErrorCode;
  final String? textErrorMessage;
  final String? imageErrorCode;
  final String? imageErrorMessage;
  final DateTime createdAt;
  final DateTime updatedAt;

  bool get isTerminal => _terminal(textStatus) && _terminal(imageStatus);

  static bool _terminal(LivingClosureTaskStatus status) =>
      status == LivingClosureTaskStatus.ready ||
      status == LivingClosureTaskStatus.awaitingRetry;

  LivingChapterClosureCheckpoint copyWith({
    int? textAttempt,
    int? imageAttempt,
    LivingClosureTaskStatus? textStatus,
    LivingClosureTaskStatus? imageStatus,
    DateTime? updatedAt,
    String? textErrorCode,
    String? textErrorMessage,
    String? imageErrorCode,
    String? imageErrorMessage,
    bool clearTextFailure = false,
    bool clearImageFailure = false,
  }) => LivingChapterClosureCheckpoint(
    runId: runId,
    chapterId: chapterId,
    chapterNumber: chapterNumber,
    closureId: closureId,
    textTaskId: textTaskId,
    imageTaskId: imageTaskId,
    textAttempt: textAttempt ?? this.textAttempt,
    imageAttempt: imageAttempt ?? this.imageAttempt,
    textStatus: textStatus ?? this.textStatus,
    imageStatus: imageStatus ?? this.imageStatus,
    settingsSnapshot: settingsSnapshot,
    textErrorCode: clearTextFailure
        ? null
        : textErrorCode ?? this.textErrorCode,
    textErrorMessage: clearTextFailure
        ? null
        : textErrorMessage ?? this.textErrorMessage,
    imageErrorCode: clearImageFailure
        ? null
        : imageErrorCode ?? this.imageErrorCode,
    imageErrorMessage: clearImageFailure
        ? null
        : imageErrorMessage ?? this.imageErrorMessage,
    createdAt: createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'runId': runId,
    'chapterId': chapterId,
    'chapterNumber': chapterNumber,
    'closureId': closureId,
    'textTaskId': textTaskId,
    'imageTaskId': imageTaskId,
    'textAttempt': textAttempt,
    'imageAttempt': imageAttempt,
    'textStatus': textStatus.name,
    'imageStatus': imageStatus.name,
    'settingsSnapshot': settingsSnapshot,
    if (textErrorCode != null) 'textErrorCode': textErrorCode,
    if (textErrorMessage != null) 'textErrorMessage': textErrorMessage,
    if (imageErrorCode != null) 'imageErrorCode': imageErrorCode,
    if (imageErrorMessage != null) 'imageErrorMessage': imageErrorMessage,
    'createdAt': createdAt.toUtc().toIso8601String(),
    'updatedAt': updatedAt.toUtc().toIso8601String(),
  };

  factory LivingChapterClosureCheckpoint.fromJson(Map<String, Object?> json) =>
      LivingChapterClosureCheckpoint(
        runId: json['runId']! as String,
        chapterId: json['chapterId']! as String,
        chapterNumber: (json['chapterNumber']! as num).toInt(),
        closureId: json['closureId']! as String,
        textTaskId: json['textTaskId']! as String,
        imageTaskId: json['imageTaskId']! as String,
        textAttempt: (json['textAttempt']! as num).toInt(),
        imageAttempt: (json['imageAttempt']! as num).toInt(),
        textStatus: _enumByName(
          LivingClosureTaskStatus.values,
          json['textStatus'],
        ),
        imageStatus: _enumByName(
          LivingClosureTaskStatus.values,
          json['imageStatus'],
        ),
        settingsSnapshot: Map.unmodifiable(
          _optionalObjectMap(json['settingsSnapshot']) ?? const {},
        ),
        textErrorCode: json['textErrorCode'] as String?,
        textErrorMessage: json['textErrorMessage'] as String?,
        imageErrorCode: json['imageErrorCode'] as String?,
        imageErrorMessage: json['imageErrorMessage'] as String?,
        createdAt: DateTime.parse(json['createdAt']! as String),
        updatedAt: DateTime.parse(json['updatedAt']! as String),
      );
}

@immutable
class LivingCampaignRun {
  const LivingCampaignRun({
    required this.schemaVersion,
    required this.contentLocale,
    required this.runId,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.prologue,
    required this.canon,
    required this.chapterPackages,
    required this.battleOutcomes,
    this.campaignTitle = 'Living Campaign',
    this.storyPromise = '',
    this.epilogue,
    this.generationRecords = const <LivingGenerationRecord>[],
    this.activeChapterNumber = 1,
    this.generationJob,
    this.generationCheckpoint,
    this.v2GenerationCheckpoint,
    this.namedPiecesByName = const <String, LivingNamedPieceRecord>{},
    this.missionMemories = const <LivingMissionMemory>[],
    this.historyDigests = const <LivingHistoryDigest>[],
    this.portraitCheckpointsByCharacterId =
        const <String, LivingPortraitCheckpoint>{},
    this.chapterArtCheckpointsByChapterId =
        const <String, LivingChapterEndingArtCheckpoint>{},
    this.aftermathScenesByChapterId = const <String, LivingAftermathScene>{},
    this.identityAssignmentsByCharacterId =
        const <String, LivingIdentityAssignment>{},
    this.chapterClosureCheckpointsByChapterId =
        const <String, LivingChapterClosureCheckpoint>{},
    this.completedAt,
  });

  final int schemaVersion;
  final LivingContentLocale contentLocale;
  final String runId;
  final LivingRunStatus status;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? completedAt;
  final String campaignTitle;
  final String storyPromise;
  final String? epilogue;
  final String prologue;
  final int activeChapterNumber;
  final LivingCanonState canon;
  final List<LivingChapterPackage> chapterPackages;
  final List<LivingBattleOutcomeSnapshot> battleOutcomes;
  final List<LivingGenerationRecord> generationRecords;
  final LivingGenerationJob? generationJob;
  final LivingChapterGenerationCheckpoint? generationCheckpoint;
  final LivingV2GenerationCheckpoint? v2GenerationCheckpoint;
  final Map<String, LivingNamedPieceRecord> namedPiecesByName;
  final List<LivingMissionMemory> missionMemories;
  final List<LivingHistoryDigest> historyDigests;
  final Map<String, LivingPortraitCheckpoint> portraitCheckpointsByCharacterId;
  final Map<String, LivingChapterEndingArtCheckpoint>
  chapterArtCheckpointsByChapterId;
  final Map<String, LivingAftermathScene> aftermathScenesByChapterId;
  final Map<String, LivingIdentityAssignment> identityAssignmentsByCharacterId;
  final Map<String, LivingChapterClosureCheckpoint>
  chapterClosureCheckpointsByChapterId;

  LivingCampaignRun copyWith({
    LivingRunStatus? status,
    DateTime? updatedAt,
    DateTime? completedAt,
    String? campaignTitle,
    String? storyPromise,
    String? epilogue,
    String? prologue,
    int? activeChapterNumber,
    LivingCanonState? canon,
    List<LivingChapterPackage>? chapterPackages,
    List<LivingBattleOutcomeSnapshot>? battleOutcomes,
    List<LivingGenerationRecord>? generationRecords,
    LivingGenerationJob? generationJob,
    bool clearGenerationJob = false,
    LivingChapterGenerationCheckpoint? generationCheckpoint,
    bool clearGenerationCheckpoint = false,
    LivingV2GenerationCheckpoint? v2GenerationCheckpoint,
    bool clearV2GenerationCheckpoint = false,
    Map<String, LivingNamedPieceRecord>? namedPiecesByName,
    List<LivingMissionMemory>? missionMemories,
    List<LivingHistoryDigest>? historyDigests,
    Map<String, LivingPortraitCheckpoint>? portraitCheckpointsByCharacterId,
    Map<String, LivingChapterEndingArtCheckpoint>?
    chapterArtCheckpointsByChapterId,
    Map<String, LivingAftermathScene>? aftermathScenesByChapterId,
    Map<String, LivingIdentityAssignment>? identityAssignmentsByCharacterId,
    Map<String, LivingChapterClosureCheckpoint>?
    chapterClosureCheckpointsByChapterId,
  }) {
    return LivingCampaignRun(
      schemaVersion: schemaVersion,
      contentLocale: contentLocale,
      runId: runId,
      status: status ?? this.status,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      completedAt: completedAt ?? this.completedAt,
      campaignTitle: campaignTitle ?? this.campaignTitle,
      storyPromise: storyPromise ?? this.storyPromise,
      epilogue: epilogue ?? this.epilogue,
      prologue: prologue ?? this.prologue,
      activeChapterNumber: activeChapterNumber ?? this.activeChapterNumber,
      canon: canon ?? this.canon,
      chapterPackages: List.unmodifiable(
        chapterPackages ?? this.chapterPackages,
      ),
      battleOutcomes: List.unmodifiable(battleOutcomes ?? this.battleOutcomes),
      generationRecords: List.unmodifiable(
        generationRecords ?? this.generationRecords,
      ),
      generationJob: clearGenerationJob
          ? null
          : generationJob ?? this.generationJob,
      generationCheckpoint: clearGenerationCheckpoint
          ? null
          : generationCheckpoint ?? this.generationCheckpoint,
      v2GenerationCheckpoint: clearV2GenerationCheckpoint
          ? null
          : v2GenerationCheckpoint ?? this.v2GenerationCheckpoint,
      namedPiecesByName: Map.unmodifiable(
        namedPiecesByName ?? this.namedPiecesByName,
      ),
      missionMemories: List.unmodifiable(
        missionMemories ?? this.missionMemories,
      ),
      historyDigests: List.unmodifiable(historyDigests ?? this.historyDigests),
      portraitCheckpointsByCharacterId: Map.unmodifiable(
        portraitCheckpointsByCharacterId ??
            this.portraitCheckpointsByCharacterId,
      ),
      chapterArtCheckpointsByChapterId: Map.unmodifiable(
        chapterArtCheckpointsByChapterId ??
            this.chapterArtCheckpointsByChapterId,
      ),
      aftermathScenesByChapterId: Map.unmodifiable(
        aftermathScenesByChapterId ?? this.aftermathScenesByChapterId,
      ),
      identityAssignmentsByCharacterId: Map.unmodifiable(
        identityAssignmentsByCharacterId ??
            this.identityAssignmentsByCharacterId,
      ),
      chapterClosureCheckpointsByChapterId: Map.unmodifiable(
        chapterClosureCheckpointsByChapterId ??
            this.chapterClosureCheckpointsByChapterId,
      ),
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': schemaVersion,
    'contentLocale': contentLocale.tag,
    'runId': runId,
    'status': status.name,
    'createdAt': createdAt.toUtc().toIso8601String(),
    'updatedAt': updatedAt.toUtc().toIso8601String(),
    if (completedAt != null)
      'completedAt': completedAt!.toUtc().toIso8601String(),
    'campaignTitle': campaignTitle,
    'storyPromise': storyPromise,
    if (epilogue != null) 'epilogue': epilogue,
    'prologue': prologue,
    'activeChapterNumber': activeChapterNumber,
    'canon': canon.toJson(),
    'chapterPackages': chapterPackages.map((value) => value.toJson()).toList(),
    'battleOutcomes': battleOutcomes.map((value) => value.toJson()).toList(),
    'generationRecords': generationRecords
        .map((value) => value.toJson())
        .toList(),
    if (generationJob != null) 'generationJob': generationJob!.toJson(),
    if (generationCheckpoint != null)
      'generationCheckpoint': generationCheckpoint!.toJson(),
    if (v2GenerationCheckpoint != null)
      'v2GenerationCheckpoint': v2GenerationCheckpoint!.toJson(),
    'namedPiecesByName': namedPiecesByName.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'missionMemories': missionMemories.map((value) => value.toJson()).toList(),
    'historyDigests': historyDigests.map((value) => value.toJson()).toList(),
    'portraitCheckpointsByCharacterId': portraitCheckpointsByCharacterId.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'chapterArtCheckpointsByChapterId': chapterArtCheckpointsByChapterId.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'aftermathScenesByChapterId': aftermathScenesByChapterId.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'identityAssignmentsByCharacterId': identityAssignmentsByCharacterId.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'chapterClosureCheckpointsByChapterId': chapterClosureCheckpointsByChapterId
        .map((key, value) => MapEntry(key, value.toJson())),
  };

  factory LivingCampaignRun.fromJson(Map<String, Object?> json) {
    return LivingCampaignRun(
      schemaVersion: (json['schemaVersion']! as num).toInt(),
      contentLocale: LivingContentLocale.fromTag(json['contentLocale']),
      runId: json['runId']! as String,
      status: _enumByName(LivingRunStatus.values, json['status']),
      createdAt: DateTime.parse(json['createdAt']! as String),
      updatedAt: DateTime.parse(json['updatedAt']! as String),
      completedAt: json['completedAt'] == null
          ? null
          : DateTime.parse(json['completedAt']! as String),
      campaignTitle: json['campaignTitle'] as String? ?? 'Living Campaign',
      storyPromise: json['storyPromise'] as String? ?? '',
      epilogue: json['epilogue'] as String?,
      prologue: json['prologue']! as String,
      activeChapterNumber: (json['activeChapterNumber']! as num).toInt(),
      canon: LivingCanonState.fromJson(_objectMap(json['canon'])),
      chapterPackages: List.unmodifiable(
        (json['chapterPackages']! as List<Object?>).map(
          (value) => LivingChapterPackage.fromJson(_objectMap(value)),
        ),
      ),
      battleOutcomes: List.unmodifiable(
        (json['battleOutcomes']! as List<Object?>).map(
          (value) => LivingBattleOutcomeSnapshot.fromJson(_objectMap(value)),
        ),
      ),
      generationRecords: List.unmodifiable(
        (json['generationRecords'] as List<Object?>? ?? const <Object?>[]).map(
          (value) => LivingGenerationRecord.fromJson(_objectMap(value)),
        ),
      ),
      generationJob: json['generationJob'] == null
          ? null
          : LivingGenerationJob.fromJson(_objectMap(json['generationJob'])),
      generationCheckpoint: json['generationCheckpoint'] == null
          ? null
          : LivingChapterGenerationCheckpoint.fromJson(
              _objectMap(json['generationCheckpoint']),
            ),
      v2GenerationCheckpoint: json['v2GenerationCheckpoint'] == null
          ? null
          : LivingV2GenerationCheckpoint.fromJson(
              _objectMap(json['v2GenerationCheckpoint']),
            ),
      namedPiecesByName: Map.unmodifiable(
        (_optionalObjectMap(json['namedPiecesByName']) ?? const {}).map(
          (key, value) =>
              MapEntry(key, LivingNamedPieceRecord.fromJson(_objectMap(value))),
        ),
      ),
      missionMemories: List.unmodifiable(
        (json['missionMemories'] as List<Object?>? ?? const <Object?>[]).map(
          (value) => LivingMissionMemory.fromJson(_objectMap(value)),
        ),
      ),
      historyDigests: List.unmodifiable(
        (json['historyDigests'] as List<Object?>? ?? const <Object?>[]).map(
          (value) => LivingHistoryDigest.fromJson(_objectMap(value)),
        ),
      ),
      portraitCheckpointsByCharacterId: Map.unmodifiable(
        (_optionalObjectMap(json['portraitCheckpointsByCharacterId']) ??
                const {})
            .map(
              (key, value) => MapEntry(
                key,
                LivingPortraitCheckpoint.fromJson(_objectMap(value)),
              ),
            ),
      ),
      chapterArtCheckpointsByChapterId: Map.unmodifiable(
        (_optionalObjectMap(json['chapterArtCheckpointsByChapterId']) ??
                const {})
            .map(
              (key, value) => MapEntry(
                key,
                LivingChapterEndingArtCheckpoint.fromJson(_objectMap(value)),
              ),
            ),
      ),
      aftermathScenesByChapterId: Map.unmodifiable(
        (_optionalObjectMap(json['aftermathScenesByChapterId']) ?? const {})
            .map(
              (key, value) => MapEntry(
                key,
                LivingAftermathScene.fromJson(_objectMap(value)),
              ),
            ),
      ),
      identityAssignmentsByCharacterId: Map.unmodifiable(
        (_optionalObjectMap(json['identityAssignmentsByCharacterId']) ??
                const {})
            .map(
              (key, value) => MapEntry(
                key,
                LivingIdentityAssignment.fromJson(_objectMap(value)),
              ),
            ),
      ),
      chapterClosureCheckpointsByChapterId: Map.unmodifiable(
        (_optionalObjectMap(json['chapterClosureCheckpointsByChapterId']) ??
                const {})
            .map(
              (key, value) => MapEntry(
                key,
                LivingChapterClosureCheckpoint.fromJson(_objectMap(value)),
              ),
            ),
      ),
    );
  }
}
