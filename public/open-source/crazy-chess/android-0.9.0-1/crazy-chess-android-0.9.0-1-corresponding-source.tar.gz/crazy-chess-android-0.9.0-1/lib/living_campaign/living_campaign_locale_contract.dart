import 'living_campaign_models.dart';

abstract final class LivingCampaignLocaleContract {
  static String append(String prompt, LivingContentLocale locale) {
    final contract = switch (locale) {
      LivingContentLocale.english => _english,
      LivingContentLocale.simplifiedChinese => _simplifiedChinese,
    };
    return '$prompt\n\n$contract';
  }

  static const _english = '''
## Content locale contract (required)

- contentLocale is `en`.
- Write every player-facing field in natural English.
- Keep JSON keys, enum values, stable IDs, model names, URLs, and algebraic chess square notation unchanged.
- Character names must remain consistent with the supplied canon and prior records.
''';

  static const _simplifiedChinese = '''
## Content locale contract (required)

- contentLocale is `zh-Hans`.
- Write every player-facing title, synopsis, dialogue line, objective label, character name and role, fact, thread, relationship summary, aftermath line, history digest, and epilogue in natural Mainland Simplified Chinese.
- Do not answer those player-facing fields in English. Transliterate newly invented proper names consistently and preserve all supplied Chinese canon names exactly.
- Keep JSON keys, enum values, stable IDs, model names, URLs, and algebraic chess square notation such as `a4` unchanged.
''';
}

abstract final class LivingChineseContentValidator {
  static const _playerFacingKeys = <String>{
    'title',
    'subtitle',
    'briefing',
    'label',
    'text',
    'name',
    'originalName',
    'originalIdentity',
    'description',
    'statement',
    'summary',
    'currentSummary',
    'narrative',
    'storyPromise',
    'prologue',
    'epilogue',
  };

  static List<String> validateResponse(
    Map<String, Object?> response,
    LivingContentLocale locale,
  ) {
    if (locale != LivingContentLocale.simplifiedChinese) {
      return const <String>[];
    }
    final issues = <String>[];

    void visit(Object? value, String path, {bool playerFacing = false}) {
      if (value is Map) {
        for (final entry in value.entries) {
          final key = entry.key.toString();
          visit(
            entry.value,
            path.isEmpty ? key : '$path.$key',
            playerFacing: _playerFacingKeys.contains(key),
          );
        }
      } else if (value is List) {
        for (var index = 0; index < value.length; index++) {
          visit(value[index], '$path[$index]', playerFacing: playerFacing);
        }
      } else if (playerFacing && value is String && value.trim().isNotEmpty) {
        if (!RegExp(r'[\u3400-\u9fff]').hasMatch(value)) {
          issues.add('$path must contain natural Simplified Chinese.');
        }
      }
    }

    visit(response, 'response');
    return issues;
  }
}
