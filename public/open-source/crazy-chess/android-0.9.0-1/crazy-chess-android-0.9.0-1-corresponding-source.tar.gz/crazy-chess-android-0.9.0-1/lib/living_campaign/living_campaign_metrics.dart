import 'package:flutter/foundation.dart';

enum LivingCampaignTimingBucket {
  narrativeReading,
  battleActive,
  aiWait,
  resultsReview,
}

@immutable
class LivingCampaignChapterTimingMetrics {
  const LivingCampaignChapterTimingMetrics({
    required this.chapterNumber,
    required this.updatedAt,
    this.foregroundActiveMs = 0,
    this.narrativeReadingMs = 0,
    this.battleActiveMs = 0,
    this.aiWaitMs = 0,
    this.resultsReviewMs = 0,
    this.firstOpenedAt,
    this.firstBattleStartedAt,
    this.latestBattleEndedAt,
    this.firstCompletedAt,
  });

  final int chapterNumber;
  final DateTime updatedAt;
  final int foregroundActiveMs;
  final int narrativeReadingMs;
  final int battleActiveMs;
  final int aiWaitMs;
  final int resultsReviewMs;
  final DateTime? firstOpenedAt;
  final DateTime? firstBattleStartedAt;
  final DateTime? latestBattleEndedAt;
  final DateTime? firstCompletedAt;

  factory LivingCampaignChapterTimingMetrics.empty({
    required int chapterNumber,
    required DateTime now,
  }) => LivingCampaignChapterTimingMetrics(
    chapterNumber: chapterNumber,
    updatedAt: now,
  );

  LivingCampaignChapterTimingMetrics recordElapsed({
    required Duration elapsed,
    required LivingCampaignTimingBucket? bucket,
    required DateTime at,
  }) {
    final milliseconds = elapsed.inMilliseconds;
    if (milliseconds <= 0) return this;
    return copyWith(
      updatedAt: at,
      foregroundActiveMs: foregroundActiveMs + milliseconds,
      narrativeReadingMs:
          narrativeReadingMs +
          (bucket == LivingCampaignTimingBucket.narrativeReading
              ? milliseconds
              : 0),
      battleActiveMs:
          battleActiveMs +
          (bucket == LivingCampaignTimingBucket.battleActive
              ? milliseconds
              : 0),
      aiWaitMs:
          aiWaitMs +
          (bucket == LivingCampaignTimingBucket.aiWait ? milliseconds : 0),
      resultsReviewMs:
          resultsReviewMs +
          (bucket == LivingCampaignTimingBucket.resultsReview
              ? milliseconds
              : 0),
    );
  }

  LivingCampaignChapterTimingMetrics copyWith({
    DateTime? updatedAt,
    int? foregroundActiveMs,
    int? narrativeReadingMs,
    int? battleActiveMs,
    int? aiWaitMs,
    int? resultsReviewMs,
    DateTime? firstOpenedAt,
    DateTime? firstBattleStartedAt,
    DateTime? latestBattleEndedAt,
    DateTime? firstCompletedAt,
  }) => LivingCampaignChapterTimingMetrics(
    chapterNumber: chapterNumber,
    updatedAt: updatedAt ?? this.updatedAt,
    foregroundActiveMs: foregroundActiveMs ?? this.foregroundActiveMs,
    narrativeReadingMs: narrativeReadingMs ?? this.narrativeReadingMs,
    battleActiveMs: battleActiveMs ?? this.battleActiveMs,
    aiWaitMs: aiWaitMs ?? this.aiWaitMs,
    resultsReviewMs: resultsReviewMs ?? this.resultsReviewMs,
    firstOpenedAt: firstOpenedAt ?? this.firstOpenedAt,
    firstBattleStartedAt: firstBattleStartedAt ?? this.firstBattleStartedAt,
    latestBattleEndedAt: latestBattleEndedAt ?? this.latestBattleEndedAt,
    firstCompletedAt: firstCompletedAt ?? this.firstCompletedAt,
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'chapterNumber': chapterNumber,
    'updatedAt': updatedAt.toUtc().toIso8601String(),
    'foregroundActiveMs': foregroundActiveMs,
    'narrativeReadingMs': narrativeReadingMs,
    'battleActiveMs': battleActiveMs,
    'aiWaitMs': aiWaitMs,
    'resultsReviewMs': resultsReviewMs,
    if (firstOpenedAt != null)
      'firstOpenedAt': firstOpenedAt!.toUtc().toIso8601String(),
    if (firstBattleStartedAt != null)
      'firstBattleStartedAt': firstBattleStartedAt!.toUtc().toIso8601String(),
    if (latestBattleEndedAt != null)
      'latestBattleEndedAt': latestBattleEndedAt!.toUtc().toIso8601String(),
    if (firstCompletedAt != null)
      'firstCompletedAt': firstCompletedAt!.toUtc().toIso8601String(),
  };

  factory LivingCampaignChapterTimingMetrics.fromJson(
    Map<String, Object?> json,
  ) {
    final chapterNumber = _nonNegativeInt(json['chapterNumber']);
    final updatedAt =
        _dateTime(json['updatedAt']) ??
        DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
    return LivingCampaignChapterTimingMetrics(
      chapterNumber: chapterNumber,
      updatedAt: updatedAt,
      foregroundActiveMs: _nonNegativeInt(json['foregroundActiveMs']),
      narrativeReadingMs: _nonNegativeInt(json['narrativeReadingMs']),
      battleActiveMs: _nonNegativeInt(json['battleActiveMs']),
      aiWaitMs: _nonNegativeInt(json['aiWaitMs']),
      resultsReviewMs: _nonNegativeInt(json['resultsReviewMs']),
      firstOpenedAt: _dateTime(json['firstOpenedAt']),
      firstBattleStartedAt: _dateTime(json['firstBattleStartedAt']),
      latestBattleEndedAt: _dateTime(json['latestBattleEndedAt']),
      firstCompletedAt: _dateTime(json['firstCompletedAt']),
    );
  }
}

@immutable
class LivingCampaignRunTimingMetrics {
  const LivingCampaignRunTimingMetrics({
    required this.runId,
    required this.createdAt,
    required this.updatedAt,
    required this.chapters,
    this.schemaVersion = currentSchemaVersion,
    this.foregroundActiveMs = 0,
    this.narrativeReadingMs = 0,
    this.battleActiveMs = 0,
    this.aiWaitMs = 0,
    this.resultsReviewMs = 0,
  });

  static const int currentSchemaVersion = 1;

  final int schemaVersion;
  final String runId;
  final DateTime createdAt;
  final DateTime updatedAt;
  final int foregroundActiveMs;
  final int narrativeReadingMs;
  final int battleActiveMs;
  final int aiWaitMs;
  final int resultsReviewMs;
  final Map<int, LivingCampaignChapterTimingMetrics> chapters;

  int get categorizedActiveMs =>
      narrativeReadingMs + battleActiveMs + aiWaitMs + resultsReviewMs;

  factory LivingCampaignRunTimingMetrics.empty({
    required String runId,
    required DateTime now,
  }) => LivingCampaignRunTimingMetrics(
    runId: runId,
    createdAt: now,
    updatedAt: now,
    chapters: const <int, LivingCampaignChapterTimingMetrics>{},
  );

  LivingCampaignRunTimingMetrics recordElapsed({
    required Duration elapsed,
    required LivingCampaignTimingBucket? bucket,
    required int? chapterNumber,
    required DateTime at,
  }) {
    final milliseconds = elapsed.inMilliseconds;
    if (milliseconds <= 0) return this;
    final nextChapters = Map<int, LivingCampaignChapterTimingMetrics>.from(
      chapters,
    );
    if (chapterNumber != null && chapterNumber > 0) {
      final chapter =
          nextChapters[chapterNumber] ??
          LivingCampaignChapterTimingMetrics.empty(
            chapterNumber: chapterNumber,
            now: at,
          );
      nextChapters[chapterNumber] = chapter.recordElapsed(
        elapsed: elapsed,
        bucket: bucket,
        at: at,
      );
    }
    return copyWith(
      updatedAt: at,
      foregroundActiveMs: foregroundActiveMs + milliseconds,
      narrativeReadingMs:
          narrativeReadingMs +
          (bucket == LivingCampaignTimingBucket.narrativeReading
              ? milliseconds
              : 0),
      battleActiveMs:
          battleActiveMs +
          (bucket == LivingCampaignTimingBucket.battleActive
              ? milliseconds
              : 0),
      aiWaitMs:
          aiWaitMs +
          (bucket == LivingCampaignTimingBucket.aiWait ? milliseconds : 0),
      resultsReviewMs:
          resultsReviewMs +
          (bucket == LivingCampaignTimingBucket.resultsReview
              ? milliseconds
              : 0),
      chapters: nextChapters,
    );
  }

  LivingCampaignRunTimingMetrics markChapterOpened({
    required int chapterNumber,
    required DateTime at,
  }) => _updateChapter(
    chapterNumber: chapterNumber,
    at: at,
    update: (chapter) => chapter.copyWith(
      updatedAt: at,
      firstOpenedAt: chapter.firstOpenedAt ?? at,
    ),
  );

  LivingCampaignRunTimingMetrics markBattleStarted({
    required int chapterNumber,
    required DateTime at,
  }) => _updateChapter(
    chapterNumber: chapterNumber,
    at: at,
    update: (chapter) => chapter.copyWith(
      updatedAt: at,
      firstBattleStartedAt: chapter.firstBattleStartedAt ?? at,
    ),
  );

  LivingCampaignRunTimingMetrics markBattleEnded({
    required int chapterNumber,
    required DateTime at,
  }) => _updateChapter(
    chapterNumber: chapterNumber,
    at: at,
    update: (chapter) =>
        chapter.copyWith(updatedAt: at, latestBattleEndedAt: at),
  );

  LivingCampaignRunTimingMetrics markChapterCompleted({
    required int chapterNumber,
    required DateTime at,
  }) => _updateChapter(
    chapterNumber: chapterNumber,
    at: at,
    update: (chapter) => chapter.copyWith(
      updatedAt: at,
      firstCompletedAt: chapter.firstCompletedAt ?? at,
    ),
  );

  LivingCampaignRunTimingMetrics _updateChapter({
    required int chapterNumber,
    required DateTime at,
    required LivingCampaignChapterTimingMetrics Function(
      LivingCampaignChapterTimingMetrics chapter,
    )
    update,
  }) {
    if (chapterNumber <= 0) return this;
    final nextChapters = Map<int, LivingCampaignChapterTimingMetrics>.from(
      chapters,
    );
    final chapter =
        nextChapters[chapterNumber] ??
        LivingCampaignChapterTimingMetrics.empty(
          chapterNumber: chapterNumber,
          now: at,
        );
    nextChapters[chapterNumber] = update(chapter);
    return copyWith(updatedAt: at, chapters: nextChapters);
  }

  LivingCampaignRunTimingMetrics copyWith({
    DateTime? updatedAt,
    int? foregroundActiveMs,
    int? narrativeReadingMs,
    int? battleActiveMs,
    int? aiWaitMs,
    int? resultsReviewMs,
    Map<int, LivingCampaignChapterTimingMetrics>? chapters,
  }) => LivingCampaignRunTimingMetrics(
    schemaVersion: schemaVersion,
    runId: runId,
    createdAt: createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    foregroundActiveMs: foregroundActiveMs ?? this.foregroundActiveMs,
    narrativeReadingMs: narrativeReadingMs ?? this.narrativeReadingMs,
    battleActiveMs: battleActiveMs ?? this.battleActiveMs,
    aiWaitMs: aiWaitMs ?? this.aiWaitMs,
    resultsReviewMs: resultsReviewMs ?? this.resultsReviewMs,
    chapters: Map<int, LivingCampaignChapterTimingMetrics>.unmodifiable(
      chapters ?? this.chapters,
    ),
  );

  Map<String, Object?> toJson() => <String, Object?>{
    'schemaVersion': schemaVersion,
    'runId': runId,
    'createdAt': createdAt.toUtc().toIso8601String(),
    'updatedAt': updatedAt.toUtc().toIso8601String(),
    'foregroundActiveMs': foregroundActiveMs,
    'narrativeReadingMs': narrativeReadingMs,
    'battleActiveMs': battleActiveMs,
    'aiWaitMs': aiWaitMs,
    'resultsReviewMs': resultsReviewMs,
    'chapters': <String, Object?>{
      for (final entry in chapters.entries)
        '${entry.key}': entry.value.toJson(),
    },
  };

  factory LivingCampaignRunTimingMetrics.fromJson(Map<String, Object?> json) {
    final runId = json['runId'] as String? ?? '';
    final createdAt =
        _dateTime(json['createdAt']) ??
        DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
    final updatedAt = _dateTime(json['updatedAt']) ?? createdAt;
    final chapters = <int, LivingCampaignChapterTimingMetrics>{};
    final rawChapters = json['chapters'];
    if (rawChapters is Map) {
      for (final entry in rawChapters.entries) {
        final key = int.tryParse(entry.key.toString());
        if (key == null || key <= 0 || entry.value is! Map) continue;
        final decoded = LivingCampaignChapterTimingMetrics.fromJson(
          Map<String, Object?>.from(entry.value as Map),
        );
        chapters[key] = decoded.chapterNumber == key
            ? decoded
            : LivingCampaignChapterTimingMetrics(
                chapterNumber: key,
                updatedAt: decoded.updatedAt,
                foregroundActiveMs: decoded.foregroundActiveMs,
                narrativeReadingMs: decoded.narrativeReadingMs,
                battleActiveMs: decoded.battleActiveMs,
                aiWaitMs: decoded.aiWaitMs,
                resultsReviewMs: decoded.resultsReviewMs,
                firstOpenedAt: decoded.firstOpenedAt,
                firstBattleStartedAt: decoded.firstBattleStartedAt,
                latestBattleEndedAt: decoded.latestBattleEndedAt,
                firstCompletedAt: decoded.firstCompletedAt,
              );
      }
    }
    return LivingCampaignRunTimingMetrics(
      schemaVersion: _nonNegativeInt(json['schemaVersion']) == 0
          ? currentSchemaVersion
          : _nonNegativeInt(json['schemaVersion']),
      runId: runId,
      createdAt: createdAt,
      updatedAt: updatedAt,
      foregroundActiveMs: _nonNegativeInt(json['foregroundActiveMs']),
      narrativeReadingMs: _nonNegativeInt(json['narrativeReadingMs']),
      battleActiveMs: _nonNegativeInt(json['battleActiveMs']),
      aiWaitMs: _nonNegativeInt(json['aiWaitMs']),
      resultsReviewMs: _nonNegativeInt(json['resultsReviewMs']),
      chapters: Map<int, LivingCampaignChapterTimingMetrics>.unmodifiable(
        chapters,
      ),
    );
  }
}

int _nonNegativeInt(Object? value) {
  final parsed = switch (value) {
    int number => number,
    num number => number.toInt(),
    String text => int.tryParse(text) ?? 0,
    _ => 0,
  };
  return parsed < 0 ? 0 : parsed;
}

DateTime? _dateTime(Object? value) {
  if (value is! String || value.isEmpty) return null;
  return DateTime.tryParse(value)?.toUtc();
}
