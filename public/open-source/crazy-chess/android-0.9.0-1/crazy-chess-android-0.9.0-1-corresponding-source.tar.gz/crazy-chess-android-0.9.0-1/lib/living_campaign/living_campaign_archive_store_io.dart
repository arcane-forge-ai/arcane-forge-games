import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'living_campaign_archive_store.dart';
import 'living_campaign_migrations.dart';
import 'living_campaign_metrics.dart';
import 'living_campaign_models.dart';

class IoLivingCampaignArchiveStore implements LivingCampaignArchiveStore {
  IoLivingCampaignArchiveStore({Future<Directory> Function()? rootProvider})
    : _rootProvider = rootProvider;

  final Future<Directory> Function()? _rootProvider;
  Directory? _root;
  Future<void>? _initializing;
  bool _initialized = false;

  static const _storageSchemaVersion = 2;
  static const _schemaMarkerName = 'storage-schema-version';

  @override
  Future<void> initialize() {
    if (_initialized) return Future<void>.value();
    return _initializing ??= _initialize();
  }

  Future<void> _initialize() async {
    final root = await _resolveRoot();
    final marker = File(p.join(root.path, _schemaMarkerName));
    final markerVersion = await marker.exists()
        ? int.tryParse((await marker.readAsString()).trim())
        : null;
    final runs = Directory(p.join(root.path, 'runs'));
    final portraits = Directory(p.join(root.path, 'portraits'));
    final metrics = Directory(p.join(root.path, 'metrics'));
    if (markerVersion != _storageSchemaVersion) {
      if (await runs.exists()) await runs.delete(recursive: true);
      if (await portraits.exists()) await portraits.delete(recursive: true);
      if (await metrics.exists()) await metrics.delete(recursive: true);
    }
    await Directory(p.join(root.path, 'runs')).create(recursive: true);
    await Directory(p.join(root.path, 'portraits')).create(recursive: true);
    await Directory(p.join(root.path, 'metrics')).create(recursive: true);
    await marker.writeAsString('$_storageSchemaVersion\n', flush: true);
    _initialized = true;
  }

  @override
  Future<void> writeRun(LivingCampaignRun run) async {
    await initialize();
    _validateId(run.runId);
    final file = File(p.join(_root!.path, 'runs', '${run.runId}.json'));
    final temporary = File('${file.path}.tmp');
    await temporary.writeAsString(
      jsonEncode(LivingCampaignRunCodec.encode(run)),
      flush: true,
    );
    if (await file.exists()) {
      await file.delete();
    }
    await temporary.rename(file.path);
  }

  @override
  Future<LivingCampaignRun?> readRun(String runId) async {
    await initialize();
    _validateId(runId);
    final file = File(p.join(_root!.path, 'runs', '$runId.json'));
    if (!await file.exists()) {
      return null;
    }
    final decoded = jsonDecode(await file.readAsString());
    return LivingCampaignRunCodec.decode(
      Map<String, Object?>.from(decoded as Map),
    );
  }

  @override
  Future<void> writeTimingMetrics(
    LivingCampaignRunTimingMetrics metrics,
  ) async {
    await initialize();
    _validateId(metrics.runId);
    final file = File(p.join(_root!.path, 'metrics', '${metrics.runId}.json'));
    final temporary = File(
      '${file.path}.${DateTime.now().microsecondsSinceEpoch}.tmp',
    );
    try {
      await temporary.writeAsString(jsonEncode(metrics.toJson()), flush: true);
      if (await file.exists()) {
        await file.delete();
      }
      await temporary.rename(file.path);
    } on FileSystemException {
      final rootStillExists = await _root!.exists();
      if (rootStillExists) rethrow;
    }
  }

  @override
  Future<LivingCampaignRunTimingMetrics?> readTimingMetrics(
    String runId,
  ) async {
    await initialize();
    _validateId(runId);
    final file = File(p.join(_root!.path, 'metrics', '$runId.json'));
    if (!await file.exists()) return null;
    final decoded = jsonDecode(await file.readAsString());
    final metrics = LivingCampaignRunTimingMetrics.fromJson(
      Map<String, Object?>.from(decoded as Map),
    );
    if (metrics.runId != runId) {
      throw const FormatException('Timing metrics run id does not match key.');
    }
    return metrics;
  }

  @override
  Future<List<LivingRunArchiveSummary>> listRuns() async {
    await initialize();
    final summaries = <LivingRunArchiveSummary>[];
    await for (final entity in Directory(p.join(_root!.path, 'runs')).list()) {
      if (entity is! File || p.extension(entity.path) != '.json') {
        continue;
      }
      try {
        final bytes = await entity.readAsBytes();
        final decoded = jsonDecode(utf8.decode(bytes));
        final run = LivingCampaignRunCodec.decode(
          Map<String, Object?>.from(decoded as Map),
        );
        summaries.add(
          LivingRunArchiveSummary(
            runId: run.runId,
            status: run.status,
            createdAt: run.createdAt,
            updatedAt: run.updatedAt,
            activeChapterNumber: run.activeChapterNumber,
            chapterCount: run.canon.chapterLedger.length,
            byteSize:
                bytes.length +
                await _portraitBytes(run.runId) +
                await _timingMetricsBytes(run.runId),
          ),
        );
      } on Object {
        // A corrupt archive is isolated; valid runs remain available.
      }
    }
    summaries.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return List.unmodifiable(summaries);
  }

  @override
  Future<void> deleteRun(String runId) async {
    await initialize();
    _validateId(runId);
    final file = File(p.join(_root!.path, 'runs', '$runId.json'));
    if (await file.exists()) {
      await file.delete();
    }
    final portraits = Directory(p.join(_root!.path, 'portraits', runId));
    if (await portraits.exists()) {
      await portraits.delete(recursive: true);
    }
    final metrics = File(p.join(_root!.path, 'metrics', '$runId.json'));
    if (await metrics.exists()) {
      await metrics.delete();
    }
  }

  @override
  Future<int> storageBytes() async {
    await initialize();
    var total = 0;
    await for (final entity in _root!.list(recursive: true)) {
      if (entity is File && !entity.path.endsWith('.tmp')) {
        try {
          total += await entity.length();
        } on FileSystemException {
          // Atomic writers may move a file between listing and sizing it.
        }
      }
    }
    return total;
  }

  @override
  Future<String> writeBinary({
    required String runId,
    required String fileName,
    required Uint8List bytes,
  }) async {
    await initialize();
    _validateId(runId);
    _validateFileName(fileName);
    final directory = Directory(p.join(_root!.path, 'portraits', runId));
    await directory.create(recursive: true);
    final file = File(p.join(directory.path, fileName));
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  @override
  Future<Uint8List?> readBinary(String reference) async {
    await initialize();
    final absolute = p.normalize(p.absolute(reference));
    final portraitRoot = p.normalize(
      p.absolute(p.join(_root!.path, 'portraits')),
    );
    if (!p.isWithin(portraitRoot, absolute)) {
      throw ArgumentError(
        'Binary reference is outside Living Campaign storage.',
      );
    }
    final file = File(absolute);
    return await file.exists() ? file.readAsBytes() : null;
  }

  Future<Directory> _resolveRoot() async {
    final cached = _root;
    if (cached != null) {
      return cached;
    }
    final root = _rootProvider == null
        ? Directory(
            p.join(
              (await getApplicationSupportDirectory()).path,
              'crazy_chess',
              'living_campaign',
            ),
          )
        : await _rootProvider();
    _root = root;
    return root;
  }

  Future<int> _portraitBytes(String runId) async {
    final directory = Directory(p.join(_root!.path, 'portraits', runId));
    if (!await directory.exists()) {
      return 0;
    }
    var total = 0;
    await for (final entity in directory.list(recursive: true)) {
      if (entity is File) {
        total += await entity.length();
      }
    }
    return total;
  }

  Future<int> _timingMetricsBytes(String runId) async {
    final file = File(p.join(_root!.path, 'metrics', '$runId.json'));
    try {
      return await file.exists() ? file.length() : 0;
    } on FileSystemException {
      return 0;
    }
  }

  void _validateId(String value) {
    if (!RegExp(r'^[A-Za-z0-9_-]+$').hasMatch(value)) {
      throw ArgumentError.value(value, 'runId', 'Unsafe run id');
    }
  }

  void _validateFileName(String value) {
    if (!RegExp(r'^[A-Za-z0-9_.-]+$').hasMatch(value) ||
        value == '.' ||
        value == '..') {
      throw ArgumentError.value(value, 'fileName', 'Unsafe file name');
    }
  }
}
