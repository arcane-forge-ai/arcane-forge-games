import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import '../ai/chess_engine.dart';
import '../ai/position_codec.dart';
import '../battlefield/battlefield_models.dart';
import '../domain/chess_models.dart';
import '../game/game_controller.dart';
import '../story/campaign_ai.dart';
import '../story/story_models.dart';
import 'doubao_client.dart';
import 'living_campaign_archive_store.dart';
import 'living_campaign_fixed_opener.dart';
import 'living_campaign_generation_service.dart';
import 'living_campaign_migrations.dart';
import 'living_campaign_metrics.dart';
import 'living_campaign_models.dart';
import 'living_campaign_narrative_copy.dart';
import 'living_campaign_prompt_library.dart';
import 'living_portrait_resolver.dart';
import 'living_campaign_v2_backend.dart';

enum LivingCampaignPhase {
  loading,
  hub,
  prologue,
  epilogue,
  dialogue,
  briefing,
  battle,
  outcomeAcknowledgement,
  chapterClosureLoading,
  aftermathDialogue,
  chapterArtLoading,
  chapterEnding,
  history,
}

enum LivingDirectorStatus {
  idle,
  starting,
  providerWorking,
  receiving,
  validating,
  repairing,
  portrait,
  endingArt,
  ready,
  interrupted,
  failed,
}

typedef LivingPrologueGenerator =
    Future<LivingGenerationResult> Function(LivingCampaignRun run);
typedef LivingNextChapterGenerator =
    Future<LivingGenerationResult> Function(
      LivingCampaignRun run,
      LivingBattleOutcomeSnapshot outcome,
    );
typedef LivingNextChapterGeneratorFactory =
    LivingNextChapterGenerator Function();
typedef LivingPortraitGenerator =
    Future<LivingGenerationResult> Function(
      LivingCampaignRun run,
      String characterId,
    );
typedef LivingPortraitGeneratorFactory = LivingPortraitGenerator Function();
typedef LivingChapterArtGenerator =
    Future<LivingGenerationResult> Function(
      LivingCampaignRun run,
      LivingBattleOutcomeSnapshot outcome,
    );
typedef LivingChapterArtRetryGenerator =
    Future<LivingGenerationResult> Function(
      LivingCampaignRun run,
      String chapterId,
    );
typedef LivingChapterArtGeneratorFactory = LivingChapterArtGenerator Function();
typedef LivingChapterArtRetryGeneratorFactory =
    LivingChapterArtRetryGenerator Function();
typedef LivingChapterClosureTextGenerator =
    Future<LivingGenerationResult> Function(
      LivingCampaignRun run,
      LivingBattleOutcomeSnapshot outcome,
    );
typedef LivingChapterClosureTextRetryGenerator =
    Future<LivingGenerationResult> Function(
      LivingCampaignRun run,
      String chapterId,
    );
typedef LivingChapterClosureTextGeneratorFactory =
    LivingChapterClosureTextGenerator Function();
typedef LivingChapterClosureTextRetryGeneratorFactory =
    LivingChapterClosureTextRetryGenerator Function();

class LivingGenerationTaskHandle {
  LivingGenerationTaskHandle({
    required this.runId,
    required this.jobId,
    required this.initialStage,
    required this.initialAttempt,
    required this.settingsSnapshot,
    required this.completion,
    required this.progress,
  });

  final String runId;
  final String jobId;
  final LivingGenerationStage initialStage;
  final int initialAttempt;
  final Map<String, Object?> settingsSnapshot;
  final Future<void> completion;
  final Stream<LivingCampaignRun> progress;

  StreamSubscription<LivingCampaignRun> onProgress(
    void Function(LivingCampaignRun run) callback,
  ) => progress.listen(callback);
}

class LivingCampaignController extends ChangeNotifier {
  LivingCampaignController({
    required this.gameController,
    this.moveEngine,
    required LivingCampaignArchiveStore archive,
    required LivingPrologueGenerator generatePrologue,
    required LivingNextChapterGenerator generateNextChapter,
    LivingNextChapterGeneratorFactory? snapshotNextChapterGenerator,
    LivingPortraitGenerator? generatePortrait,
    LivingPortraitGeneratorFactory? snapshotPortraitGenerator,
    LivingChapterArtGenerator? generateChapterArt,
    LivingChapterArtGeneratorFactory? snapshotChapterArtGenerator,
    LivingChapterArtRetryGenerator? retryChapterArt,
    LivingChapterArtRetryGeneratorFactory? snapshotChapterArtRetryGenerator,
    LivingChapterClosureTextGenerator? generateChapterClosureText,
    LivingChapterClosureTextGeneratorFactory?
    snapshotChapterClosureTextGenerator,
    LivingChapterClosureTextRetryGenerator? retryChapterClosureText,
    LivingChapterClosureTextRetryGeneratorFactory?
    snapshotChapterClosureTextRetryGenerator,
    LivingCampaignOutcomeReducer outcomeReducer =
        const LivingCampaignOutcomeReducer(),
    DateTime Function()? clock,
    Map<String, Object?> Function()? generationSettingsSnapshot,
    LivingContentLocale Function()? contentLocaleProvider,
  }) : _archive = archive,
       _mutationCoordinator = LivingCampaignRunMutationCoordinator.forArchive(
         archive,
       ),
       _generatePrologue = generatePrologue,
       _generateNextChapter = generateNextChapter,
       _snapshotNextChapterGenerator = snapshotNextChapterGenerator,
       _generatePortrait = generatePortrait,
       _snapshotPortraitGenerator = snapshotPortraitGenerator,
       _generateChapterArt = generateChapterArt,
       _snapshotChapterArtGenerator = snapshotChapterArtGenerator,
       _retryChapterArt = retryChapterArt,
       _snapshotChapterArtRetryGenerator = snapshotChapterArtRetryGenerator,
       _generateChapterClosureText = generateChapterClosureText,
       _snapshotChapterClosureTextGenerator =
           snapshotChapterClosureTextGenerator,
       _retryChapterClosureText = retryChapterClosureText,
       _snapshotChapterClosureTextRetryGenerator =
           snapshotChapterClosureTextRetryGenerator,
       _outcomeReducer = outcomeReducer,
       _clock = clock ?? DateTime.now,
       _generationSettingsSnapshot =
           generationSettingsSnapshot ?? (() => const <String, Object?>{}),
       _contentLocaleProvider =
           contentLocaleProvider ?? (() => LivingContentLocale.english) {
    gameController.addListener(_onGameChanged);
  }

  final GameController gameController;
  final ChessEngine? moveEngine;
  final LivingCampaignArchiveStore _archive;
  final LivingCampaignRunMutationCoordinator _mutationCoordinator;
  final LivingPrologueGenerator _generatePrologue;
  final LivingNextChapterGenerator _generateNextChapter;
  final LivingNextChapterGeneratorFactory? _snapshotNextChapterGenerator;
  final LivingPortraitGenerator? _generatePortrait;
  final LivingPortraitGeneratorFactory? _snapshotPortraitGenerator;
  final LivingChapterArtGenerator? _generateChapterArt;
  final LivingChapterArtGeneratorFactory? _snapshotChapterArtGenerator;
  final LivingChapterArtRetryGenerator? _retryChapterArt;
  final LivingChapterArtRetryGeneratorFactory?
  _snapshotChapterArtRetryGenerator;
  final LivingChapterClosureTextGenerator? _generateChapterClosureText;
  final LivingChapterClosureTextGeneratorFactory?
  _snapshotChapterClosureTextGenerator;
  final LivingChapterClosureTextRetryGenerator? _retryChapterClosureText;
  final LivingChapterClosureTextRetryGeneratorFactory?
  _snapshotChapterClosureTextRetryGenerator;
  final LivingCampaignOutcomeReducer _outcomeReducer;
  final DateTime Function() _clock;
  final Map<String, Object?> Function() _generationSettingsSnapshot;
  final LivingContentLocale Function() _contentLocaleProvider;

  LivingCampaignPhase _phase = LivingCampaignPhase.loading;
  LivingCampaignRun? _activeRun;
  LivingCampaignRunTimingMetrics? _activeTimingMetrics;
  DateTime? _timingSegmentStartedAt;
  LivingCampaignTimingBucket? _timingSegmentBucket;
  int? _timingSegmentChapterNumber;
  bool _appForeground = true;
  bool _sessionVisible = true;
  Future<void> _timingWriteTail = Future<void>.value();

  LivingCampaignPhase get phase => _phase;

  set phase(LivingCampaignPhase value) {
    if (_phase == value) return;
    final now = _clock();
    _finishTimingSegment(now);
    _phase = value;
    _recordTimingMilestone(value, now);
    _beginTimingSegment(now);
  }

  LivingCampaignRun? get activeRun => _activeRun;

  set activeRun(LivingCampaignRun? value) {
    final current = _activeRun;
    final sameAttribution =
        current?.runId == value?.runId &&
        current?.activeChapterNumber == value?.activeChapterNumber;
    if (sameAttribution) {
      _activeRun = value;
      return;
    }
    final now = _clock();
    _finishTimingSegment(now);
    _activeRun = value;
    if (current?.runId != value?.runId) {
      _activeTimingMetrics = value == null
          ? null
          : LivingCampaignRunTimingMetrics.empty(
              runId: value.runId,
              now: value.createdAt,
            );
    }
    _beginTimingSegment(now);
  }

  LivingCampaignRunTimingMetrics? get timingMetrics =>
      _projectedTimingMetrics(_clock());

  LivingCampaignRun? inspectedRun;
  List<LivingRunArchiveSummary> archives = const <LivingRunArchiveSummary>[];
  int storageBytes = 0;
  int dialogueIndex = 0;
  String? message;
  bool isAiThinking = false;
  bool objectiveSucceeded = false;
  LivingBattleOutcomeSnapshot? pendingOutcome;

  CampaignAi? _ai;
  bool _moveEngineDisabledForBattle = false;
  bool _moveEnginePreparedForBattle = false;
  int _lastMotionSerial = 0;
  int _lastBetrayalSerial = 0;
  final List<LivingCapturedPieceOutcome> _captured =
      <LivingCapturedPieceOutcome>[];
  final Set<String> _purchasedPieceIds = <String>{};
  final List<LivingPurchaseEventOutcome> _purchaseEvents =
      <LivingPurchaseEventOutcome>[];
  bool _finishing = false;
  String? _reachInitialOccupantPieceId;
  bool _reachTargetVacated = false;
  bool _reachTargetEntered = false;
  bool _disposed = false;
  Future<void>? _activeGenerationTask;
  LivingGenerationTaskHandle? _activeGenerationHandle;
  StreamController<LivingCampaignRun>? _activeGenerationProgress;
  String? _activeGenerationRunId;
  String? _activeGenerationJobId;
  DoubaoStreamPhase? _providerPhase;
  bool _validatingGeneration = false;
  bool _readySinceLastOpen = false;
  int _taskSerial = 0;
  Timer? _generationTicker;
  Future<void>? _chapterArtTask;
  Future<void>? _chapterClosureTextTask;
  int _closureSerial = 0;
  int directorNoticeSerial = 0;
  String? deferredDirectorNotice;

  LivingChapterPackage? get activeChapter {
    final run = activeRun;
    if (run == null) {
      return null;
    }
    for (final chapter in run.chapterPackages.reversed) {
      if (chapter.chapterNumber == run.activeChapterNumber) {
        return chapter;
      }
    }
    return null;
  }

  bool get playerInputLocked =>
      phase != LivingCampaignPhase.battle ||
      isAiThinking ||
      gameController.turn != PieceColor.white;

  bool get hasInterruptedGeneration {
    final status = activeRun?.generationJob?.status;
    return status == LivingGenerationStatus.awaitingResume ||
        status == LivingGenerationStatus.failed;
  }

  bool get isGenerationRunning => _activeGenerationTask != null;

  bool get isChapterArtRunning => _chapterArtTask != null;

  bool get isChapterClosureTextRunning => _chapterClosureTextTask != null;

  bool get isChapterClosureRunning =>
      isChapterClosureTextRunning || isChapterArtRunning;

  bool get isPaidRequestRunning =>
      isGenerationRunning || isChapterClosureRunning;

  LivingChapterClosureCheckpoint? get activeChapterClosureCheckpoint {
    final chapterId = pendingOutcome?.chapterId ?? activeChapter?.chapterId;
    return chapterId == null
        ? null
        : activeRun?.chapterClosureCheckpointsByChapterId[chapterId];
  }

  LivingAftermathScene? get activeAftermathScene {
    final chapterId = pendingOutcome?.chapterId;
    return chapterId == null
        ? null
        : activeRun?.aftermathScenesByChapterId[chapterId];
  }

  LivingChapterEndingArtCheckpoint? get activeChapterArtCheckpoint {
    final chapterId = pendingOutcome?.chapterId ?? activeChapter?.chapterId;
    return chapterId == null
        ? null
        : activeRun?.chapterArtCheckpointsByChapterId[chapterId];
  }

  Future<Uint8List?> chapterArtBytes(String chapterId) async {
    final run = phase == LivingCampaignPhase.history
        ? inspectedRun
        : activeRun ?? inspectedRun;
    final reference =
        run?.chapterArtCheckpointsByChapterId[chapterId]?.processedReference;
    return reference == null ? null : _archive.readBinary(reference);
  }

  bool get isPortraitRunning =>
      isGenerationRunning &&
      activeRun?.generationJob?.stage == LivingGenerationStage.portrait;

  LivingPortraitCheckpoint? get activePortraitCheckpoint {
    final checkpoints = activeRun?.portraitCheckpointsByCharacterId.values;
    if (checkpoints == null || checkpoints.isEmpty) return null;
    final ordered = checkpoints.toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return ordered.first;
  }

  LivingPortraitCheckpoint? get retryablePortraitCheckpoint {
    final relevantCharacterId = activeChapter?.portraitCharacterId;
    if (relevantCharacterId == null) return null;
    final checkpoints = activeRun?.portraitCheckpointsByCharacterId.values
        .where(
          (value) =>
              value.characterId == relevantCharacterId &&
              value.status == LivingPortraitStatus.awaitingRetry,
        )
        .toList();
    if (checkpoints == null || checkpoints.isEmpty) return null;
    checkpoints.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return checkpoints.first;
  }

  bool get hasPortraitAttention => retryablePortraitCheckpoint != null;

  String? get portraitStatusLabel {
    if (isPortraitRunning ||
        activePortraitCheckpoint?.status == LivingPortraitStatus.pending ||
        activePortraitCheckpoint?.status == LivingPortraitStatus.generating) {
      return 'A NEW FACE EMERGES';
    }
    if (hasPortraitAttention) return 'A FACE YET UNSEEN';
    return null;
  }

  Future<void>? get activeGenerationCompletion => _activeGenerationTask;

  LivingGenerationTaskHandle? get activeGenerationTask =>
      _activeGenerationHandle;

  bool get openingReady {
    final run = activeRun;
    if (run == null || run.generationJob != null) return false;
    return run.schemaVersion == LivingCampaignRunCodec.currentSchemaVersion &&
        run.campaignTitle.trim().isNotEmpty &&
        run.storyPromise.trim().isNotEmpty &&
        run.prologue.trim().isNotEmpty &&
        run.chapterPackages.any((chapter) => chapter.chapterNumber == 1);
  }

  bool get canContinueStory {
    final run = activeRun;
    if (run == null || isGenerationRunning || run.generationJob != null) {
      return false;
    }
    if (run.status == LivingRunStatus.completed) return true;
    if (run.activeChapterNumber == 1 && run.battleOutcomes.isEmpty) {
      return openingReady;
    }
    return run.chapterPackages.any(
      (chapter) => chapter.chapterNumber == run.activeChapterNumber,
    );
  }

  bool get canStartNewRun => !isPaidRequestRunning;

  bool get canAbandonActiveRun =>
      !isPaidRequestRunning && activeRun?.status == LivingRunStatus.active;

  void setAppForeground(bool isForeground) {
    if (_disposed || _appForeground == isForeground) return;
    final now = _clock();
    _finishTimingSegment(now);
    _appForeground = isForeground;
    _beginTimingSegment(now);
  }

  void setSessionVisible(bool isVisible) {
    if (_disposed || _sessionVisible == isVisible) return;
    final now = _clock();
    _finishTimingSegment(now);
    _sessionVisible = isVisible;
    _beginTimingSegment(now);
  }

  Future<void> flushTimingMetrics() async {
    if (!_disposed) {
      final now = _clock();
      _finishTimingSegment(now);
      _beginTimingSegment(now);
    }
    await _timingWriteTail.catchError((Object _) {});
  }

  Duration get generationElapsed {
    final startedAt = activeRun?.generationJob?.createdAt;
    if (startedAt == null) return Duration.zero;
    final elapsed = _clock().difference(startedAt);
    return elapsed.isNegative ? Duration.zero : elapsed;
  }

  LivingDirectorStatus get directorStatus {
    if (isChapterClosureRunning ||
        phase == LivingCampaignPhase.chapterClosureLoading ||
        phase == LivingCampaignPhase.chapterArtLoading) {
      return LivingDirectorStatus.endingArt;
    }
    final job = activeRun?.generationJob;
    if (isGenerationRunning && job != null) {
      if (job.stage == LivingGenerationStage.portrait) {
        return canContinueStory
            ? LivingDirectorStatus.ready
            : LivingDirectorStatus.portrait;
      }
      if (job.stage == LivingGenerationStage.prologueRepair ||
          job.stage == LivingGenerationStage.chroniclerRepair ||
          job.stage == LivingGenerationStage.directorRepair ||
          job.stage == LivingGenerationStage.builderRepair ||
          job.stage == LivingGenerationStage.compactionRepair) {
        return LivingDirectorStatus.repairing;
      }
      if (_validatingGeneration) return LivingDirectorStatus.validating;
      return switch (_providerPhase) {
        DoubaoStreamPhase.receiving => LivingDirectorStatus.receiving,
        DoubaoStreamPhase.connected || DoubaoStreamPhase.providerWorking =>
          LivingDirectorStatus.providerWorking,
        DoubaoStreamPhase.completed => LivingDirectorStatus.validating,
        null => LivingDirectorStatus.starting,
      };
    }
    if (job?.status == LivingGenerationStatus.awaitingResume) {
      return LivingDirectorStatus.interrupted;
    }
    if (job?.status == LivingGenerationStatus.failed) {
      return LivingDirectorStatus.failed;
    }
    if (_readySinceLastOpen || canContinueStory) {
      return LivingDirectorStatus.ready;
    }
    return LivingDirectorStatus.idle;
  }

  String get directorStatusLabel => switch (directorStatus) {
    LivingDirectorStatus.idle => 'IDLE',
    LivingDirectorStatus.starting ||
    LivingDirectorStatus.providerWorking ||
    LivingDirectorStatus.receiving ||
    LivingDirectorStatus.validating ||
    LivingDirectorStatus.repairing ||
    LivingDirectorStatus.portrait ||
    LivingDirectorStatus.endingArt => 'SCRIPTING',
    LivingDirectorStatus.ready => 'READY',
    LivingDirectorStatus.interrupted ||
    LivingDirectorStatus.failed => 'NEEDS ATTENTION',
  };

  String get generationStageLabel {
    final run = activeRun;
    final stage = activeRun?.generationJob?.stage;
    if (run == null) return 'The chronicle waits.';
    if (phase == LivingCampaignPhase.chapterClosureLoading ||
        phase == LivingCampaignPhase.aftermathDialogue) {
      final closure = activeChapterClosureCheckpoint;
      return LivingCampaignNarrativeCopy.choose(
        LivingCampaignNarrativeCopy.chapterClosure,
        runId: run.runId,
        jobId: closure?.closureId ?? 'chapter-closure',
        stage: 'chapter_closure',
        attempt: closure?.textAttempt ?? 1,
      );
    }
    if (isChapterArtRunning || phase == LivingCampaignPhase.chapterArtLoading) {
      final outcome = pendingOutcome;
      return LivingCampaignNarrativeCopy.choose(
        LivingCampaignNarrativeCopy.endingArt,
        runId: run.runId,
        jobId: 'chapter-art-${outcome?.chapterId ?? 'unknown'}',
        stage: 'chapter_art',
        attempt: activeChapterArtCheckpoint?.attempt ?? 1,
      );
    }
    if (stage != null) {
      return LivingCampaignNarrativeCopy.forJob(
        run: run,
        stage: stage,
        attempt: run.generationJob?.attempt ?? 1,
      );
    }
    return switch (directorStatus) {
      LivingDirectorStatus.ready => LivingCampaignNarrativeCopy.forTerminal(
        run: run,
        state: 'ready',
      ),
      LivingDirectorStatus.interrupted =>
        LivingCampaignNarrativeCopy.forTerminal(run: run, state: 'interrupted'),
      LivingDirectorStatus.failed => LivingCampaignNarrativeCopy.forTerminal(
        run: run,
        state: 'failed',
      ),
      _ => 'The chronicle waits.',
    };
  }

  String get diagnosticGenerationStageLabel {
    final stage = activeRun?.generationJob?.stage;
    if (stage == null) return 'idle';
    return switch (stage) {
      LivingGenerationStage.prologue => 'Opening',
      LivingGenerationStage.prologueRepair => 'Repairing opening',
      LivingGenerationStage.chronicler => 'Chronicler',
      LivingGenerationStage.chroniclerRepair => 'Repairing mission memory',
      LivingGenerationStage.director => 'Story Director',
      LivingGenerationStage.directorRepair => 'Repairing Director plan',
      LivingGenerationStage.builder => 'Mission Builder',
      LivingGenerationStage.builderRepair => 'Repairing mission',
      LivingGenerationStage.portrait => 'Character portrait',
      LivingGenerationStage.compaction => 'Compressing story history',
      LivingGenerationStage.compactionRepair => 'Repairing story history',
      LivingGenerationStage.chapterArt => 'Chapter ending illustration',
    };
  }

  String get retryGenerationLabel => switch (activeRun?.generationJob?.stage) {
    LivingGenerationStage.prologue ||
    LivingGenerationStage.prologueRepair => 'Open the First Page Again',
    LivingGenerationStage.director ||
    LivingGenerationStage.directorRepair ||
    LivingGenerationStage.compaction ||
    LivingGenerationStage.compactionRepair => 'Seek the Road Again',
    LivingGenerationStage.chronicler ||
    LivingGenerationStage.chroniclerRepair => 'Recall the Battle Again',
    LivingGenerationStage.builder ||
    LivingGenerationStage.builderRepair => 'Lay the Field Again',
    LivingGenerationStage.portrait => 'Seek Their Likeness Again',
    LivingGenerationStage.chapterArt => 'Recall the Final Moment',
    null => 'Seek the Road Again',
  };

  String get resultExplanation {
    final run = activeRun;
    final outcome = pendingOutcome;
    if (run == null || outcome == null) return '';
    return LivingCampaignNarrativeCopy.resultExplanation(
      runId: run.runId,
      chapterNumber: outcome.chapterNumber,
    );
  }

  Future<void> initialize() async {
    phase = LivingCampaignPhase.loading;
    message = null;
    LivingBattleOutcomeSnapshot? interruptedArtOutcome;
    var resumeAftermath = false;
    notifyListeners();
    try {
      await _archive.initialize();
      await _refreshArchives();
      await _backfillAuthoredPortraits();
      await _refreshArchives();
      final active =
          archives
              .where((summary) => summary.status == LivingRunStatus.active)
              .toList()
            ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      if (active.isNotEmpty) {
        activeRun = await _archive.readRun(active.first.runId);
        final job = activeRun?.generationJob;
        if (job?.status == LivingGenerationStatus.running) {
          if (job!.stage == LivingGenerationStage.portrait) {
            final checkpoints = Map<String, LivingPortraitCheckpoint>.from(
              activeRun!.portraitCheckpointsByCharacterId,
            );
            final pending = checkpoints.entries
                .where(
                  (entry) =>
                      entry.value.status == LivingPortraitStatus.pending ||
                      entry.value.status == LivingPortraitStatus.generating,
                )
                .lastOrNull;
            if (pending != null) {
              checkpoints[pending.key] = pending.value.copyWith(
                status: LivingPortraitStatus.awaitingRetry,
                updatedAt: _clock(),
                errorCode: 'interrupted',
                errorMessage:
                    'Portrait generation was interrupted. Retry explicitly.',
              );
            }
            activeRun = activeRun!.copyWith(
              updatedAt: _clock(),
              portraitCheckpointsByCharacterId: checkpoints,
              clearGenerationJob: true,
            );
          } else {
            activeRun = activeRun!.copyWith(
              generationJob: job.copyWith(
                status: LivingGenerationStatus.awaitingResume,
                updatedAt: _clock(),
                errorCode: 'interrupted',
                errorMessage:
                    'Generation was interrupted. Retry this stage to continue.',
              ),
            );
          }
          await _archive.writeRun(activeRun!);
        }
        final closureCheckpoints =
            Map<String, LivingChapterClosureCheckpoint>.from(
              activeRun?.chapterClosureCheckpointsByChapterId ??
                  const <String, LivingChapterClosureCheckpoint>{},
            );
        var closureChanged = false;
        for (final entry in closureCheckpoints.entries.toList()) {
          var checkpoint = entry.value;
          if (checkpoint.textStatus == LivingClosureTaskStatus.pending ||
              checkpoint.textStatus == LivingClosureTaskStatus.running) {
            checkpoint = checkpoint.copyWith(
              textStatus: LivingClosureTaskStatus.awaitingRetry,
              updatedAt: _clock(),
              textErrorCode: 'interrupted',
              textErrorMessage:
                  'The survivors’ words were interrupted and wait to be recalled.',
            );
            closureChanged = true;
          }
          if (checkpoint.imageStatus == LivingClosureTaskStatus.pending ||
              checkpoint.imageStatus == LivingClosureTaskStatus.running) {
            checkpoint = checkpoint.copyWith(
              imageStatus: LivingClosureTaskStatus.awaitingRetry,
              updatedAt: _clock(),
              imageErrorCode: 'interrupted',
              imageErrorMessage:
                  'The final moment was interrupted and waits to be recalled.',
            );
            closureChanged = true;
          }
          closureCheckpoints[entry.key] = checkpoint;
        }
        if (closureChanged) {
          activeRun = activeRun!.copyWith(
            updatedAt: _clock(),
            chapterClosureCheckpointsByChapterId: closureCheckpoints,
          );
        }
        final chapterArt = Map<String, LivingChapterEndingArtCheckpoint>.from(
          activeRun?.chapterArtCheckpointsByChapterId ??
              const <String, LivingChapterEndingArtCheckpoint>{},
        );
        final interrupted =
            chapterArt.entries
                .where(
                  (entry) =>
                      entry.value.status == LivingChapterArtStatus.pending ||
                      entry.value.status == LivingChapterArtStatus.generating,
                )
                .toList()
              ..sort((a, b) => b.value.updatedAt.compareTo(a.value.updatedAt));
        if (interrupted.isNotEmpty) {
          final entry = interrupted.first;
          chapterArt[entry.key] = entry.value.copyWith(
            status: LivingChapterArtStatus.awaitingRetry,
            updatedAt: _clock(),
            errorCode: 'interrupted',
            errorMessage:
                'The final scene was interrupted and waits to be painted again.',
          );
          activeRun = activeRun!.copyWith(
            updatedAt: _clock(),
            chapterArtCheckpointsByChapterId: chapterArt,
          );
          interruptedArtOutcome = activeRun!.battleOutcomes
              .where((outcome) => outcome.chapterId == entry.key)
              .firstOrNull;
        }
        final resumableClosures =
            activeRun!.chapterClosureCheckpointsByChapterId.values
                .where(
                  (checkpoint) =>
                      checkpoint.chapterNumber ==
                      activeRun!.activeChapterNumber,
                )
                .toList()
              ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
        final resumableClosure = resumableClosures.firstOrNull;
        if (resumableClosure != null) {
          final closureOutcome = activeRun!.battleOutcomes
              .where(
                (outcome) => outcome.chapterId == resumableClosure.chapterId,
              )
              .firstOrNull;
          if (closureOutcome != null) {
            interruptedArtOutcome = closureOutcome;
            final scene = activeRun!
                .aftermathScenesByChapterId[resumableClosure.chapterId];
            resumeAftermath =
                resumableClosure.textStatus == LivingClosureTaskStatus.ready &&
                scene != null &&
                scene.lines.isNotEmpty;
          }
        }
        if (closureChanged || interrupted.isNotEmpty) {
          await _archive.writeRun(activeRun!);
        }
        final resumableCheckpoint = activeRun?.v2GenerationCheckpoint;
        if (interruptedArtOutcome == null &&
            activeRun?.generationJob == null &&
            resumableCheckpoint != null) {
          final outcome = activeRun!.battleOutcomes
              .where(
                (candidate) =>
                    candidate.chapterId ==
                        resumableCheckpoint.outcomeMissionId &&
                    candidate.chapterNumber == activeRun!.activeChapterNumber,
              )
              .firstOrNull;
          final art = outcome == null
              ? null
              : activeRun!.chapterArtCheckpointsByChapterId[outcome.chapterId];
          if (outcome != null && art != null) {
            interruptedArtOutcome = outcome;
          }
        }
      }
      await _loadTimingMetricsForActiveRun();
      if (interruptedArtOutcome != null) {
        pendingOutcome = interruptedArtOutcome;
        objectiveSucceeded =
            interruptedArtOutcome.result == LivingBattleResult.victory;
        if (resumeAftermath) {
          dialogueIndex = 0;
          phase = LivingCampaignPhase.aftermathDialogue;
          message = null;
        } else {
          phase = LivingCampaignPhase.chapterEnding;
          message = 'The final moment waits beyond the ash.';
        }
      } else {
        phase = LivingCampaignPhase.hub;
      }
    } on Object {
      message = 'Living Campaign archives could not be opened.';
      phase = LivingCampaignPhase.hub;
    }
    notifyListeners();
  }

  Future<LivingGenerationTaskHandle?> startNewRun({
    bool abandonExisting = false,
  }) async {
    if (isPaidRequestRunning) return _activeGenerationHandle;
    final existing = activeRun;
    if (existing != null &&
        existing.status == LivingRunStatus.active &&
        !abandonExisting) {
      message = 'Abandon the active run before beginning another.';
      notifyListeners();
      return null;
    }
    if (existing != null && existing.status == LivingRunStatus.active) {
      await _archive.writeRun(
        existing.copyWith(
          status: LivingRunStatus.abandoned,
          updatedAt: _clock(),
          completedAt: _clock(),
          clearGenerationJob: true,
        ),
      );
    }
    final now = _clock();
    final runId = 'living-${now.toUtc().microsecondsSinceEpoch}';
    final run = LivingCampaignFixedOpener.create(
      runId: runId,
      now: now,
      contentLocale: _contentLocaleProvider(),
    );
    activeRun = run;
    phase = LivingCampaignPhase.hub;
    message = null;
    _readySinceLastOpen = true;
    await _archive.writeRun(run);
    await _writeCurrentTimingMetrics();
    await _refreshArchives();
    notifyListeners();
    return null;
  }

  Future<LivingGenerationTaskHandle?> resumeGeneration() async {
    final run = activeRun;
    if (isPaidRequestRunning) return _activeGenerationHandle;
    if (run == null || !hasInterruptedGeneration) {
      return null;
    }
    final retryJob = _newTaskJob(
      stage: run.generationJob!.stage,
      attempt: run.generationJob!.attempt + 1,
    );
    final retryRun = run.copyWith(updatedAt: _clock(), generationJob: retryJob);
    final isPrologue =
        retryRun.battleOutcomes.isEmpty && retryRun.activeChapterNumber == 1;
    final outcome = isPrologue
        ? null
        : retryRun.battleOutcomes.lastOrNull ?? pendingOutcome;
    if (!isPrologue && outcome == null) {
      message = 'The interrupted generation has no verified battle outcome.';
      notifyListeners();
      return null;
    }
    activeRun = retryRun;
    phase = LivingCampaignPhase.hub;
    message = generationStageLabel;
    await _archive.writeRun(retryRun);
    await _refreshArchives();
    notifyListeners();
    return _launchGeneration(
      run: retryRun,
      prologue: isPrologue,
      outcome: outcome,
      nextChapterGenerator: isPrologue
          ? null
          : (_snapshotNextChapterGenerator?.call() ?? _generateNextChapter),
    );
  }

  Future<LivingGenerationTaskHandle?> retryPortrait() async {
    if (isPaidRequestRunning) return _activeGenerationHandle;
    final run = activeRun;
    final checkpoint = retryablePortraitCheckpoint;
    final generator = _snapshotPortraitGenerator?.call() ?? _generatePortrait;
    if (run == null ||
        checkpoint == null ||
        checkpoint.status != LivingPortraitStatus.awaitingRetry ||
        generator == null) {
      return null;
    }
    final retryRun = run.copyWith(
      updatedAt: _clock(),
      generationJob: _newTaskJob(
        stage: LivingGenerationStage.portrait,
        attempt: checkpoint.attempt + 1,
      ),
    );
    activeRun = retryRun;
    message = null;
    await _archive.writeRun(retryRun);
    await _refreshArchives();
    notifyListeners();
    return _launchGeneration(
      run: retryRun,
      prologue: false,
      portraitGenerator: generator,
      portraitCharacterId: checkpoint.characterId,
    );
  }

  void continueFromPrologue() {
    if (activeRun == null || !openingReady || isGenerationRunning) return;
    _readySinceLastOpen = false;
    _openChapterPrelude();
    notifyListeners();
  }

  void advanceDialogue() {
    final dialogue = activeChapter?.dialogue ?? const <LivingDialogueLine>[];
    if (dialogue.isEmpty || dialogueIndex >= dialogue.length - 1) {
      phase = LivingCampaignPhase.briefing;
    } else {
      dialogueIndex++;
    }
    notifyListeners();
  }

  void skipDialogue() {
    phase = LivingCampaignPhase.briefing;
    notifyListeners();
  }

  void openActiveRun() {
    final run = activeRun;
    if (run == null) return;
    if (!canContinueStory) {
      message = hasInterruptedGeneration
          ? generationStageLabel
          : 'The opening must finish before Chapter 1 can begin.';
      notifyListeners();
      return;
    }
    _readySinceLastOpen = false;
    if (run.status == LivingRunStatus.completed) {
      phase = LivingCampaignPhase.epilogue;
    } else if (run.activeChapterNumber == 1 && run.battleOutcomes.isEmpty) {
      phase = LivingCampaignPhase.prologue;
    } else {
      _openChapterPrelude();
    }
    message = null;
    notifyListeners();
  }

  void startBattle() {
    final chapter = activeChapter;
    if (chapter == null || isPaidRequestRunning || !canContinueStory) return;
    _captured.clear();
    _purchasedPieceIds.clear();
    _purchaseEvents.clear();
    _lastMotionSerial = 0;
    _lastBetrayalSerial = 0;
    _finishing = false;
    objectiveSucceeded = false;
    pendingOutcome = null;
    gameController.startScenario(chapter.toScenarioSetup());
    final reachSquare =
        chapter.objective.type == LivingObjectiveType.reachEscape
        ? chapter.objective.targetSquare
        : null;
    _reachInitialOccupantPieceId = reachSquare == null
        ? null
        : gameController.pieceAt(reachSquare)?.id;
    _reachTargetVacated = false;
    _reachTargetEntered = false;
    _ai = CampaignAi(seed: chapter.seed);
    _moveEngineDisabledForBattle = false;
    _moveEnginePreparedForBattle = false;
    phase = LivingCampaignPhase.battle;
    message = null;
    notifyListeners();
  }

  void evaluateAfterPresentation() {
    if (phase != LivingCampaignPhase.battle || _finishing) return;
    _recordRuntimeEvents();
    final chapter = activeChapter;
    if (chapter == null) return;
    _updateReachObjectiveState(chapter);
    if (gameController.phase == GamePhase.gameOver) {
      final reason = gameController.resolvedGameEndReason;
      if (reason == GameEndReason.stalemate &&
          gameController.skipTurnIfNoLegalMove() != null) {
        return;
      }
      final success =
          (reason == GameEndReason.checkmate ||
              reason == GameEndReason.kingTrapfall) &&
          gameController.winner == PieceColor.white;
      _finishBattle(success: success, objectiveCompleted: false);
      return;
    }
    if (_primaryObjectiveSatisfied(chapter)) {
      _finishBattle(success: true, objectiveCompleted: true);
      return;
    }
    if (!gameController.activeKingInCheck &&
        !gameController.hasAnyLegalMove(gameController.turn)) {
      final skipped = gameController.skipTurnIfNoLegalMove();
      if (skipped == null) {
        _finishBattle(success: false, objectiveCompleted: false);
      }
    }
  }

  Future<void> makeEnemyMove() async {
    final chapter = activeChapter;
    final gamePhase = gameController.phase;
    if (phase != LivingCampaignPhase.battle ||
        chapter == null ||
        gamePhase != GamePhase.playing ||
        gameController.turn != PieceColor.black ||
        isAiThinking) {
      return;
    }
    isAiThinking = true;
    notifyListeners();
    await Future<void>.delayed(const Duration(milliseconds: 260));
    if (_disposed ||
        phase != LivingCampaignPhase.battle ||
        gameController.turn != PieceColor.black) {
      isAiThinking = false;
      if (!_disposed) notifyListeners();
      return;
    }
    final profile = CampaignAiProfile(
      aggression: chapter.aiAggression,
      defense: chapter.aiDefense,
      objectivePressure: chapter.aiObjectivePressure,
      tileAppetite: chapter.aiTileAppetite,
    );
    final offer = _ai?.chooseLivingOffer(
      controller: gameController,
      aiProfile: profile,
      attemptChance: .10,
      objectiveTargetPieceId: chapter.objective.targetPieceId,
    );
    if (offer != null) {
      gameController.selectedSquare = offer.target;
      gameController.openOfferForSelected();
      if (gameController.phase == GamePhase.offer) {
        gameController.setOfferGold(offer.gold);
        gameController.confirmOffer();
        isAiThinking = false;
        notifyListeners();
        return;
      }
    }
    ChessMove? move;
    final engine = moveEngine;
    if (engine != null && !_moveEngineDisabledForBattle) {
      try {
        if (!_moveEnginePreparedForBattle) {
          await engine.newGame();
          _moveEnginePreparedForBattle = true;
        }
        final requestedFen = FenCodec.encode(gameController.positionSnapshot());
        final legalMoves = _engineLegalMovesAvoidingVisibleTraps();
        final response = await engine.bestMove(
          EngineMoveRequest(
            fen: requestedFen,
            legalMoves: legalMoves,
            targetElo: livingCampaignTargetElo(chapter.chapterNumber),
          ),
        );
        if (_disposed ||
            phase != LivingCampaignPhase.battle ||
            gameController.phase != GamePhase.playing ||
            gameController.turn != PieceColor.black ||
            FenCodec.encode(gameController.positionSnapshot()) !=
                requestedFen) {
          isAiThinking = false;
          if (!_disposed) notifyListeners();
          return;
        }
        move = UciMove.parse(response.uci).resolve(gameController);
      } on Object catch (error) {
        _moveEngineDisabledForBattle = true;
        debugPrint(
          'Living Campaign Stockfish disabled for this battle: $error',
        );
      }
    }
    move ??= _ai?.chooseConfiguredMove(
      controller: gameController,
      aiProfile: profile,
      targetSquare: chapter.objective.targetSquare,
    );
    if (move != null) {
      gameController.makeMove(move);
      if (gameController.phase == GamePhase.promotion) {
        gameController.choosePromotion(PieceType.queen);
      }
    }
    isAiThinking = false;
    notifyListeners();
  }

  @visibleForTesting
  static int? livingCampaignTargetElo(int chapterNumber) {
    final chapter = chapterNumber < 1 ? 1 : chapterNumber;
    if (chapter >= 20) return null;
    return stockfishMinimumElo + ((chapter - 1) * 100);
  }

  List<String> _engineLegalMovesAvoidingVisibleTraps() {
    final legal = UciMove.legalMoves(gameController);
    final safe = legal
        .where((encoded) {
          final destination = UciMove.parse(encoded).to;
          return gameController.specialTileAt(destination)?.type !=
              SpecialTileType.visibleTrap;
        })
        .toList(growable: false);
    return safe.isEmpty ? legal : safe;
  }

  Future<LivingGenerationTaskHandle?> generateFollowingChapter() async {
    final run = activeRun;
    final outcome = pendingOutcome;
    if (isPaidRequestRunning) return _activeGenerationHandle;
    if (run == null || outcome == null) return null;
    final alreadyCommitted = run.battleOutcomes.any(
      (candidate) => candidate.chapterId == outcome.chapterId,
    );
    var committedRun = run;
    if (!alreadyCommitted) {
      committedRun = _outcomeReducer.apply(
        run: run,
        outcome: outcome,
        now: _clock(),
      );
    } else if (run.v2GenerationCheckpoint?.outcomeMissionId !=
        outcome.chapterId) {
      message =
          'This battle outcome was already committed without a resumable '
          'checkpoint.';
      notifyListeners();
      return null;
    }
    final closure =
        committedRun.chapterClosureCheckpointsByChapterId[outcome.chapterId];
    if (closure?.textStatus != LivingClosureTaskStatus.ready ||
        committedRun.v2GenerationCheckpoint?.missionMemory == null) {
      message = 'The survivors’ words must be recalled before the road opens.';
      notifyListeners();
      return null;
    }
    if (closure?.isTerminal != true) {
      message = 'The last echoes have not yet left the battlefield.';
      notifyListeners();
      return null;
    }
    if (committedRun.status == LivingRunStatus.completed) {
      activeRun = committedRun;
      pendingOutcome = null;
      await _archive.writeRun(committedRun);
      await _refreshArchives();
      phase = LivingCampaignPhase.epilogue;
      notifyListeners();
      return null;
    }
    final checkpoint = committedRun.v2GenerationCheckpoint!;
    final job = _newTaskJob(
      stage: checkpoint.directorDecision == null
          ? LivingGenerationStage.director
          : LivingGenerationStage.builder,
      attempt: 1,
    );
    final queuedRun = committedRun.copyWith(
      updatedAt: _clock(),
      generationJob: job,
    );
    final generation =
        _snapshotNextChapterGenerator?.call() ?? _generateNextChapter;
    activeRun = queuedRun;
    pendingOutcome = null;
    if (gameController.phase != GamePhase.setup) {
      gameController.returnToSetup();
    }
    phase = LivingCampaignPhase.hub;
    message = LivingCampaignNarrativeCopy.forJob(
      run: queuedRun,
      stage: job.stage,
      attempt: job.attempt,
    );
    await _archive.writeRun(queuedRun);
    await _refreshArchives();
    notifyListeners();
    return _launchGeneration(
      run: queuedRun,
      prologue: false,
      outcome: outcome,
      nextChapterGenerator: generation,
    );
  }

  Future<void> continueFromOutcome() async {
    final run = activeRun;
    final outcome = pendingOutcome;
    if (run == null || outcome == null || isPaidRequestRunning) return;
    final alreadyCommitted = run.battleOutcomes.any(
      (candidate) => candidate.chapterId == outcome.chapterId,
    );
    final committed = alreadyCommitted
        ? run
        : _outcomeReducer.apply(run: run, outcome: outcome, now: _clock());
    final now = _clock();
    final closureId =
        'closure-${outcome.chapterId}-${now.toUtc().microsecondsSinceEpoch}';
    final existingClosure =
        committed.chapterClosureCheckpointsByChapterId[outcome.chapterId];
    final closure =
        existingClosure ??
        LivingChapterClosureCheckpoint(
          runId: committed.runId,
          chapterId: outcome.chapterId,
          chapterNumber: outcome.chapterNumber,
          closureId: closureId,
          textTaskId: '$closureId-text',
          imageTaskId: '$closureId-image',
          textAttempt: 1,
          imageAttempt: 1,
          textStatus: LivingClosureTaskStatus.pending,
          imageStatus: LivingClosureTaskStatus.pending,
          settingsSnapshot: Map<String, Object?>.unmodifiable(
            _generationSettingsSnapshot(),
          ),
          createdAt: now,
          updatedAt: now,
        );
    final closures = Map<String, LivingChapterClosureCheckpoint>.from(
      committed.chapterClosureCheckpointsByChapterId,
    )..[outcome.chapterId] = closure;
    final artCheckpoints = Map<String, LivingChapterEndingArtCheckpoint>.from(
      committed.chapterArtCheckpointsByChapterId,
    );
    artCheckpoints.putIfAbsent(
      outcome.chapterId,
      () => LivingChapterEndingArtCheckpoint(
        runId: committed.runId,
        chapterId: outcome.chapterId,
        chapterNumber: outcome.chapterNumber,
        attempt: closure.imageAttempt,
        seed: LivingChapterArtSeed.derive(
          runId: committed.runId,
          chapterId: outcome.chapterId,
          attempt: closure.imageAttempt,
        ),
        status: LivingChapterArtStatus.pending,
        promptAsset: LivingCampaignPrompt.chapterEndingArt.assetPath,
        createdAt: now,
        updatedAt: now,
      ),
    );
    final prepared = committed.copyWith(
      updatedAt: now,
      chapterClosureCheckpointsByChapterId: closures,
      chapterArtCheckpointsByChapterId: artCheckpoints,
    );
    activeRun = prepared;
    phase = LivingCampaignPhase.chapterClosureLoading;
    message = _closureStoryLine(prepared, closure);
    if (gameController.phase != GamePhase.setup) {
      gameController.returnToSetup();
    }
    await _archive.writeRun(prepared);
    await _refreshArchives();
    notifyListeners();
    final textGenerator =
        _snapshotChapterClosureTextGenerator?.call() ??
        _generateChapterClosureText;
    final artGenerator =
        _snapshotChapterArtGenerator?.call() ?? _generateChapterArt;
    final serial = ++_closureSerial;
    if (textGenerator == null) {
      unawaited(
        _markClosureChildUnavailable(
          prepared,
          outcome,
          text: true,
          code: 'chapter_closure_text_unavailable',
          safeMessage: 'The survivors’ words could not be recalled.',
          serial: serial,
        ),
      );
    } else {
      _launchClosureText(
        run: prepared,
        outcome: outcome,
        generator: textGenerator,
        serial: serial,
      );
    }
    if (artGenerator == null) {
      unawaited(
        _markClosureChildUnavailable(
          prepared,
          outcome,
          text: false,
          code: 'chapter_art_unavailable',
          safeMessage: 'The final moment remains beyond sight.',
          serial: serial,
        ),
      );
    } else {
      _launchClosureArt(
        run: prepared,
        outcome: outcome,
        generator: artGenerator,
        serial: serial,
      );
    }
    notifyListeners();
  }

  void _launchClosureText({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
    required LivingChapterClosureTextGenerator generator,
    required int serial,
  }) {
    final expected =
        run.chapterClosureCheckpointsByChapterId[outcome.chapterId]!;
    late final Future<void> task;
    task =
        () async {
          LivingGenerationResult result;
          try {
            result = await generator(run, outcome);
          } on Object {
            await _markClosureChildUnavailable(
              run,
              outcome,
              text: true,
              code: 'chapter_closure_text_exception',
              safeMessage: 'The survivors’ words were lost beyond the field.',
              serial: serial,
            );
            return;
          }
          if (_disposed || serial != _closureSerial) return;
          final latest = await _archive.readRun(run.runId) ?? result.run;
          final checkpoint =
              latest.chapterClosureCheckpointsByChapterId[outcome.chapterId];
          if (!_closureCallbackMatches(
            checkpoint,
            expected: expected,
            text: true,
          )) {
            return;
          }
          activeRun = latest;
          final scene = latest.aftermathScenesByChapterId[outcome.chapterId];
          if (checkpoint!.textStatus == LivingClosureTaskStatus.ready &&
              scene != null &&
              scene.lines.isNotEmpty) {
            dialogueIndex = 0;
            phase = LivingCampaignPhase.aftermathDialogue;
            message = null;
          } else if (_closureImageTerminal(checkpoint)) {
            phase = LivingCampaignPhase.chapterEnding;
            message = 'The survivors’ words remain unspoken.';
          } else {
            phase = LivingCampaignPhase.chapterArtLoading;
            message = 'The survivors’ words remain unspoken.';
          }
          await _refreshArchives();
          notifyListeners();
        }().whenComplete(() {
          if (identical(_chapterClosureTextTask, task)) {
            _setChapterClosureTextTask(null);
            if (!_disposed) notifyListeners();
          }
        });
    _setChapterClosureTextTask(task);
    unawaited(task);
  }

  void _launchClosureArt({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
    required LivingChapterArtGenerator generator,
    required int serial,
  }) {
    final expected =
        run.chapterClosureCheckpointsByChapterId[outcome.chapterId]!;
    late final Future<void> task;
    task =
        () async {
          LivingGenerationResult result;
          try {
            result = await generator(run, outcome);
          } on Object {
            await _markClosureChildUnavailable(
              run,
              outcome,
              text: false,
              code: 'chapter_art_exception',
              safeMessage: 'The final moment remains beyond sight.',
              serial: serial,
            );
            return;
          }
          if (_disposed || serial != _closureSerial) return;
          final latest = await _archive.readRun(run.runId) ?? result.run;
          final checkpoint =
              latest.chapterClosureCheckpointsByChapterId[outcome.chapterId];
          if (!_closureCallbackMatches(
            checkpoint,
            expected: expected,
            text: false,
          )) {
            return;
          }
          activeRun = latest;
          if (phase == LivingCampaignPhase.chapterArtLoading &&
              _closureImageTerminal(checkpoint!)) {
            phase = LivingCampaignPhase.chapterEnding;
            if (!result.completed) {
              message = 'The final moment remains beyond sight.';
            }
          } else if (phase == LivingCampaignPhase.chapterClosureLoading &&
              checkpoint!.textStatus == LivingClosureTaskStatus.awaitingRetry &&
              _closureImageTerminal(checkpoint)) {
            phase = LivingCampaignPhase.chapterEnding;
            message =
                checkpoint.textErrorMessage ??
                'The survivors’ words remain unspoken.';
          }
          await _refreshArchives();
          notifyListeners();
        }().whenComplete(() {
          if (identical(_chapterArtTask, task)) {
            _setChapterArtTask(null);
            if (!_disposed) notifyListeners();
          }
        });
    _setChapterArtTask(task);
    unawaited(task);
  }

  bool _closureCallbackMatches(
    LivingChapterClosureCheckpoint? checkpoint, {
    required LivingChapterClosureCheckpoint expected,
    required bool text,
  }) {
    if (checkpoint == null ||
        checkpoint.runId != expected.runId ||
        checkpoint.closureId != expected.closureId ||
        checkpoint.chapterId != expected.chapterId) {
      return false;
    }
    return text
        ? checkpoint.textTaskId == expected.textTaskId &&
              checkpoint.textAttempt >= expected.textAttempt
        : checkpoint.imageTaskId == expected.imageTaskId &&
              checkpoint.imageAttempt >= expected.imageAttempt;
  }

  bool _closureImageTerminal(LivingChapterClosureCheckpoint checkpoint) =>
      checkpoint.imageStatus == LivingClosureTaskStatus.ready ||
      checkpoint.imageStatus == LivingClosureTaskStatus.awaitingRetry;

  String _closureStoryLine(
    LivingCampaignRun run,
    LivingChapterClosureCheckpoint checkpoint,
  ) => LivingCampaignNarrativeCopy.choose(
    LivingCampaignNarrativeCopy.chapterClosure,
    runId: run.runId,
    jobId: checkpoint.closureId,
    stage: 'chapter_closure',
    attempt: checkpoint.textAttempt,
  );

  Future<void> _markClosureChildUnavailable(
    LivingCampaignRun run,
    LivingBattleOutcomeSnapshot outcome, {
    required bool text,
    required String code,
    required String safeMessage,
    required int serial,
  }) async {
    final updated = await _mutationCoordinator.mutate(
      runId: run.runId,
      seed: run,
      mutation: (latest) {
        final closures = Map<String, LivingChapterClosureCheckpoint>.from(
          latest.chapterClosureCheckpointsByChapterId,
        );
        final checkpoint = closures[outcome.chapterId]!;
        closures[outcome.chapterId] = text
            ? checkpoint.copyWith(
                textStatus: LivingClosureTaskStatus.awaitingRetry,
                updatedAt: _clock(),
                textErrorCode: code,
                textErrorMessage: safeMessage,
              )
            : checkpoint.copyWith(
                imageStatus: LivingClosureTaskStatus.awaitingRetry,
                updatedAt: _clock(),
                imageErrorCode: code,
                imageErrorMessage: safeMessage,
              );
        var next = latest.copyWith(
          updatedAt: _clock(),
          chapterClosureCheckpointsByChapterId: closures,
        );
        if (!text) {
          final art = Map<String, LivingChapterEndingArtCheckpoint>.from(
            latest.chapterArtCheckpointsByChapterId,
          );
          final existing = art[outcome.chapterId];
          if (existing != null) {
            art[outcome.chapterId] = existing.copyWith(
              status: LivingChapterArtStatus.awaitingRetry,
              updatedAt: _clock(),
              errorCode: code,
              errorMessage: safeMessage,
            );
            next = next.copyWith(chapterArtCheckpointsByChapterId: art);
          }
        }
        return next;
      },
    );
    if (_disposed || serial != _closureSerial) return;
    activeRun = updated;
    final closure =
        updated.chapterClosureCheckpointsByChapterId[outcome.chapterId]!;
    if (text) {
      phase = _closureImageTerminal(closure)
          ? LivingCampaignPhase.chapterEnding
          : LivingCampaignPhase.chapterArtLoading;
    } else if (closure.textStatus == LivingClosureTaskStatus.awaitingRetry) {
      phase = LivingCampaignPhase.chapterEnding;
    }
    message = safeMessage;
    await _refreshArchives();
    notifyListeners();
  }

  void advanceAftermath() {
    final lines = activeAftermathScene?.lines ?? const <LivingAftermathLine>[];
    if (lines.isEmpty || dialogueIndex >= lines.length - 1) {
      _finishAftermath();
    } else {
      dialogueIndex++;
      notifyListeners();
    }
  }

  void skipAftermath() => _finishAftermath();

  void _finishAftermath() {
    final closure = activeChapterClosureCheckpoint;
    if (closure == null) return;
    if (_closureImageTerminal(closure)) {
      phase = LivingCampaignPhase.chapterEnding;
      message = closure.imageStatus == LivingClosureTaskStatus.awaitingRetry
          ? 'The final moment remains beyond sight.'
          : null;
    } else {
      phase = LivingCampaignPhase.chapterArtLoading;
      message = LivingCampaignNarrativeCopy.choose(
        LivingCampaignNarrativeCopy.endingArt,
        runId: closure.runId,
        jobId: closure.closureId,
        stage: 'chapter_art_wait',
        attempt: closure.imageAttempt,
      );
    }
    notifyListeners();
  }

  Future<void> retryChapterClosureText() async {
    final run = activeRun;
    final outcome = pendingOutcome;
    final closure = activeChapterClosureCheckpoint;
    if (run == null ||
        outcome == null ||
        closure?.textStatus != LivingClosureTaskStatus.awaitingRetry ||
        isPaidRequestRunning) {
      return;
    }
    final generator =
        _snapshotChapterClosureTextRetryGenerator?.call() ??
        _retryChapterClosureText;
    if (generator == null) return;
    phase = LivingCampaignPhase.chapterClosureLoading;
    message = _closureStoryLine(run, closure!);
    final serial = ++_closureSerial;
    _launchClosureText(
      run: run,
      outcome: outcome,
      generator: (candidate, ignored) =>
          generator(candidate, outcome.chapterId),
      serial: serial,
    );
    notifyListeners();
  }

  Future<void> retryChapterEndingArt() async {
    final run = activeRun;
    final outcome = pendingOutcome;
    final checkpoint = activeChapterArtCheckpoint;
    if (run == null ||
        outcome == null ||
        checkpoint?.status != LivingChapterArtStatus.awaitingRetry ||
        isPaidRequestRunning) {
      return;
    }
    final generator =
        _snapshotChapterArtRetryGenerator?.call() ?? _retryChapterArt;
    if (generator == null) return;
    phase = LivingCampaignPhase.chapterArtLoading;
    final closure = activeChapterClosureCheckpoint;
    message = closure == null
        ? 'The last echoes drift across the battlefield.'
        : LivingCampaignNarrativeCopy.choose(
            LivingCampaignNarrativeCopy.endingArt,
            runId: run.runId,
            jobId: closure.closureId,
            stage: 'chapter_art_retry',
            attempt: checkpoint!.attempt + 1,
          );
    notifyListeners();
    final serial = ++_closureSerial;
    _launchClosureArt(
      run: run,
      outcome: outcome,
      generator: (candidate, ignored) =>
          generator(candidate, outcome.chapterId),
      serial: serial,
    );
  }

  /// Used only by the explicit debug browser-acceptance fixture.
  void debugResolveActiveBattleAsVictory() {
    if (phase != LivingCampaignPhase.battle) return;
    _finishBattle(success: true, objectiveCompleted: true);
  }

  void retryBattle() {
    if (isPaidRequestRunning) return;
    final chapterId = pendingOutcome?.chapterId;
    if (chapterId != null &&
        (activeRun?.battleOutcomes.any(
              (outcome) => outcome.chapterId == chapterId,
            ) ??
            false)) {
      return;
    }
    startBattle();
  }

  Future<void> closeEpilogue() async {
    activeRun = null;
    inspectedRun = null;
    pendingOutcome = null;
    phase = LivingCampaignPhase.hub;
    await _refreshArchives();
    notifyListeners();
  }

  void returnToHub() {
    if (gameController.phase != GamePhase.setup) {
      gameController.returnToSetup();
    }
    phase = LivingCampaignPhase.hub;
    notifyListeners();
  }

  Future<void> abandonActiveRun() async {
    final run = activeRun;
    if (run == null ||
        run.status != LivingRunStatus.active ||
        isPaidRequestRunning) {
      return;
    }
    await _archive.writeRun(
      run.copyWith(
        status: LivingRunStatus.abandoned,
        updatedAt: _clock(),
        completedAt: _clock(),
        clearGenerationJob: true,
      ),
    );
    activeRun = null;
    phase = LivingCampaignPhase.hub;
    message = null;
    await _refreshArchives();
    notifyListeners();
  }

  Future<void> deleteArchive(String runId) async {
    if (activeRun?.runId == runId) return;
    await _archive.deleteRun(runId);
    await _refreshArchives();
    notifyListeners();
  }

  Future<void> inspectRun(String runId) async {
    final run = activeRun?.runId == runId
        ? activeRun
        : await _archive.readRun(runId);
    if (run == null) {
      message = 'That local Living Campaign archive could not be opened.';
      notifyListeners();
      return;
    }
    inspectedRun = run;
    phase = LivingCampaignPhase.history;
    message = null;
    notifyListeners();
  }

  void closeHistory() {
    inspectedRun = null;
    phase = LivingCampaignPhase.hub;
    notifyListeners();
  }

  Future<Uint8List?> portraitBytes(String characterId) async {
    final run = phase == LivingCampaignPhase.history
        ? inspectedRun
        : activeRun ?? inspectedRun;
    final runLocal = run?.canon.charactersById[characterId]?.portraitPath;
    final authored = LivingPortraitFallbackResolver.fixedAsset(characterId);
    final references = <String>[
      if (runLocal?.trim().isNotEmpty == true) runLocal!,
      if (authored != null && authored != runLocal) authored,
    ];
    for (final reference in references) {
      try {
        if (reference.startsWith('assets/')) {
          final data = await rootBundle.load(reference);
          return data.buffer.asUint8List(
            data.offsetInBytes,
            data.lengthInBytes,
          );
        }
        final bytes = await _archive.readBinary(reference);
        if (bytes != null) return bytes;
      } on Object {
        continue;
      }
    }
    return null;
  }

  Future<LivingPiecePresentation?> piecePresentation(ChessPiece piece) async {
    final run = activeRun ?? inspectedRun;
    if (run == null || piece.type == PieceType.pawn) return null;
    final chapterPiece = activeChapter?.pieces
        .where((candidate) => candidate.pieceId == piece.id)
        .firstOrNull;
    final characterId = piece.characterId ?? chapterPiece?.characterId;
    if (characterId == null) return null;
    final named = run.namedPiecesByName.values
        .where((record) => record.characterId == characterId)
        .firstOrNull;
    final canonical = run.canon.charactersById[characterId];
    final name = named?.name ?? canonical?.originalName;
    if (name == null || name.trim().isEmpty) return null;
    final portraitReference =
        named?.portraitPath ??
        canonical?.portraitPath ??
        LivingPortraitFallbackResolver.fixedAsset(characterId) ??
        LivingPortraitFallbackResolver.neutralAsset(
          piece.type,
          stableKey: '${run.runId}:$characterId',
        );
    Uint8List? bytes;
    if (portraitReference != null && !portraitReference.startsWith('assets/')) {
      bytes = await _archive.readBinary(portraitReference);
    }
    return LivingPiecePresentation(
      characterId: characterId,
      name: name,
      pieceType: piece.type,
      portraitReference: portraitReference,
      portraitBytes: bytes,
    );
  }

  void acceptGenerationProgress(LivingCampaignRun run) {
    if (_disposed) return;
    if (isChapterClosureTextRunning && run.runId == activeRun?.runId) {
      final activeClosure = activeChapterClosureCheckpoint;
      final incomingClosure = activeClosure == null
          ? null
          : run.chapterClosureCheckpointsByChapterId[activeClosure.chapterId];
      if (incomingClosure?.closureId == activeClosure?.closureId) {
        activeRun = run;
        notifyListeners();
      }
      return;
    }
    if (!isGenerationRunning) return;
    final job = run.generationJob;
    if (run.runId != _activeGenerationRunId ||
        job == null ||
        job.jobId != _activeGenerationJobId) {
      return;
    }
    activeRun = run;
    _providerPhase = job.receivedContentCharacters > 0
        ? DoubaoStreamPhase.receiving
        : job.lastActivityAt != null
        ? DoubaoStreamPhase.providerWorking
        : job.transportType == 'sse'
        ? DoubaoStreamPhase.connected
        : null;
    final lastRecord = run.generationRecords.lastOrNull;
    _validatingGeneration =
        lastRecord != null &&
        lastRecord.stage == job.stage &&
        lastRecord.attempt == job.attempt &&
        lastRecord.status == LivingGenerationStatus.completed;
    _activeGenerationProgress?.add(run);
    notifyListeners();
  }

  String? takeDeferredDirectorNotice() {
    final notice = deferredDirectorNotice;
    deferredDirectorNotice = null;
    return notice;
  }

  LivingGenerationJob _newTaskJob({
    required LivingGenerationStage stage,
    required int attempt,
  }) {
    final now = _clock();
    return LivingGenerationJob(
      jobId: 'job-${now.toUtc().microsecondsSinceEpoch}-${_taskSerial + 1}',
      stage: stage,
      status: LivingGenerationStatus.running,
      attempt: attempt,
      createdAt: now,
      updatedAt: now,
      settingsSnapshot: Map<String, Object?>.unmodifiable(
        _generationSettingsSnapshot(),
      ),
      transportType: stage == LivingGenerationStage.portrait ? 'http' : 'sse',
    );
  }

  LivingGenerationTaskHandle? _launchGeneration({
    required LivingCampaignRun run,
    required bool prologue,
    LivingBattleOutcomeSnapshot? outcome,
    LivingNextChapterGenerator? nextChapterGenerator,
    LivingPortraitGenerator? portraitGenerator,
    String? portraitCharacterId,
  }) {
    if (_disposed || run.generationJob == null) return null;
    if (isGenerationRunning) return _activeGenerationHandle;
    final token = ++_taskSerial;
    _activeGenerationRunId = run.runId;
    _activeGenerationJobId = run.generationJob!.jobId;
    _providerPhase = null;
    _validatingGeneration = false;
    _readySinceLastOpen = false;
    _generationTicker?.cancel();
    _generationTicker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!_disposed && isGenerationRunning) notifyListeners();
    });
    final startGate = Completer<void>();
    final progress = StreamController<LivingCampaignRun>.broadcast(sync: true);
    final task = startGate.future.then((_) async {
      try {
        await _runGeneration(
          token: token,
          run: run,
          prologue: prologue,
          outcome: outcome,
          nextChapterGenerator: nextChapterGenerator,
          portraitGenerator: portraitGenerator,
          portraitCharacterId: portraitCharacterId,
        );
      } finally {
        if (!progress.isClosed) await progress.close();
      }
    });
    final job = run.generationJob!;
    final handle = LivingGenerationTaskHandle(
      runId: run.runId,
      jobId: job.jobId,
      initialStage: job.stage,
      initialAttempt: job.attempt,
      settingsSnapshot: job.settingsSnapshot,
      completion: task,
      progress: progress.stream,
    );
    _setActiveGenerationTask(task);
    _activeGenerationHandle = handle;
    _activeGenerationProgress = progress;
    notifyListeners();
    startGate.complete();
    unawaited(task);
    return handle;
  }

  Future<void> _runGeneration({
    required int token,
    required LivingCampaignRun run,
    required bool prologue,
    required LivingBattleOutcomeSnapshot? outcome,
    required LivingNextChapterGenerator? nextChapterGenerator,
    required LivingPortraitGenerator? portraitGenerator,
    required String? portraitCharacterId,
  }) async {
    LivingGenerationResult result;
    try {
      result = portraitGenerator != null && portraitCharacterId != null
          ? await portraitGenerator(run, portraitCharacterId)
          : prologue
          ? await _generatePrologue(run)
          : await (nextChapterGenerator ?? _generateNextChapter)(run, outcome!);
    } on Object {
      final failed = run.copyWith(
        updatedAt: _clock(),
        generationJob: run.generationJob!.copyWith(
          status: LivingGenerationStatus.awaitingResume,
          updatedAt: _clock(),
          errorCode: 'generation_exception',
          errorMessage:
              'Story generation stopped unexpectedly. Retry this stage.',
        ),
      );
      await _archive.writeRun(failed);
      result = LivingGenerationResult(
        run: failed,
        completed: false,
        message: failed.generationJob!.errorMessage,
      );
    }
    if (_disposed ||
        token != _taskSerial ||
        run.runId != _activeGenerationRunId ||
        run.generationJob!.jobId != _activeGenerationJobId) {
      return;
    }
    var finalRun = result.run;
    if (!result.completed &&
        finalRun.generationJob?.status == LivingGenerationStatus.running) {
      finalRun = finalRun.copyWith(
        updatedAt: _clock(),
        generationJob: finalRun.generationJob!.copyWith(
          status: LivingGenerationStatus.awaitingResume,
          updatedAt: _clock(),
          errorCode: 'generation_incomplete',
          errorMessage:
              result.message ?? 'Story generation needs an explicit retry.',
        ),
      );
      await _archive.writeRun(finalRun);
    }
    activeRun = finalRun;
    _providerPhase = null;
    _validatingGeneration = false;
    _readySinceLastOpen = result.completed;
    message = result.completed
        ? null
        : result.message ?? 'Story generation needs attention.';
    final portraitNeedsAttention =
        portraitCharacterId != null &&
        finalRun
                .portraitCheckpointsByCharacterId[portraitCharacterId]
                ?.status ==
            LivingPortraitStatus.awaitingRetry;
    deferredDirectorNotice = result.completed
        ? portraitCharacterId != null
              ? portraitNeedsAttention
                    ? 'The chapter is ready with fallback portrait art.'
                    : 'The character portrait is ready.'
              : prologue
              ? 'The opening is ready.'
              : finalRun.status == LivingRunStatus.completed
              ? 'The campaign epilogue is ready.'
              : 'The next chapter is ready.'
        : message;
    directorNoticeSerial++;
    await _refreshArchives();
    _activeGenerationProgress?.add(finalRun);
    _setActiveGenerationTask(null);
    _activeGenerationRunId = null;
    _activeGenerationJobId = null;
    _activeGenerationHandle = null;
    _activeGenerationProgress = null;
    _generationTicker?.cancel();
    _generationTicker = null;
    if (!_disposed) notifyListeners();
  }

  void _setActiveGenerationTask(Future<void>? task) {
    if (identical(_activeGenerationTask, task)) return;
    final now = _clock();
    _finishTimingSegment(now);
    _activeGenerationTask = task;
    _beginTimingSegment(now);
  }

  void _setChapterClosureTextTask(Future<void>? task) {
    if (identical(_chapterClosureTextTask, task)) return;
    final now = _clock();
    _finishTimingSegment(now);
    _chapterClosureTextTask = task;
    _beginTimingSegment(now);
  }

  void _setChapterArtTask(Future<void>? task) {
    if (identical(_chapterArtTask, task)) return;
    final now = _clock();
    _finishTimingSegment(now);
    _chapterArtTask = task;
    _beginTimingSegment(now);
  }

  Future<void> _loadTimingMetricsForActiveRun() async {
    final run = activeRun;
    final now = _clock();
    _finishTimingSegment(now);
    if (run == null) {
      _activeTimingMetrics = null;
      return;
    }
    LivingCampaignRunTimingMetrics? stored;
    try {
      stored = await _archive.readTimingMetrics(run.runId);
    } on Object catch (error) {
      debugPrint('Living Campaign timing metrics could not be read: $error');
    }
    if (activeRun?.runId != run.runId) return;
    _activeTimingMetrics =
        stored ??
        LivingCampaignRunTimingMetrics.empty(
          runId: run.runId,
          now: run.createdAt,
        );
    _beginTimingSegment(_clock());
  }

  Future<void> _writeCurrentTimingMetrics() async {
    final metrics = _activeTimingMetrics;
    if (metrics == null) return;
    _queueTimingMetricsWrite(metrics);
    await _timingWriteTail.catchError((Object _) {});
  }

  LivingCampaignRunTimingMetrics? _projectedTimingMetrics(DateTime at) {
    final metrics = _activeTimingMetrics;
    final startedAt = _timingSegmentStartedAt;
    if (metrics == null || startedAt == null || !_timingEnabled) {
      return metrics;
    }
    final elapsed = at.difference(startedAt);
    if (elapsed.isNegative || elapsed == Duration.zero) return metrics;
    return metrics.recordElapsed(
      elapsed: elapsed,
      bucket: _timingSegmentBucket,
      chapterNumber: _timingSegmentChapterNumber,
      at: at,
    );
  }

  void _finishTimingSegment(DateTime at) {
    final metrics = _activeTimingMetrics;
    final startedAt = _timingSegmentStartedAt;
    final bucket = _timingSegmentBucket;
    final chapterNumber = _timingSegmentChapterNumber;
    _timingSegmentStartedAt = null;
    _timingSegmentBucket = null;
    _timingSegmentChapterNumber = null;
    if (metrics == null || startedAt == null) return;
    final elapsed = at.difference(startedAt);
    if (elapsed.isNegative || elapsed == Duration.zero) return;
    final updated = metrics.recordElapsed(
      elapsed: elapsed,
      bucket: bucket,
      chapterNumber: chapterNumber,
      at: at,
    );
    _activeTimingMetrics = updated;
    _queueTimingMetricsWrite(updated);
  }

  void _beginTimingSegment(DateTime at) {
    if (!_timingEnabled ||
        _activeTimingMetrics == null ||
        !_tracksTiming(phase)) {
      return;
    }
    _timingSegmentStartedAt = at;
    _timingSegmentBucket = _currentTimingBucket();
    _timingSegmentChapterNumber = _timingChapterNumberForPhase(phase);
  }

  bool _tracksTiming(LivingCampaignPhase value) =>
      value != LivingCampaignPhase.loading &&
      value != LivingCampaignPhase.history;

  bool get _timingEnabled => _appForeground && _sessionVisible;

  LivingCampaignTimingBucket? _currentTimingBucket() => switch (phase) {
    LivingCampaignPhase.prologue ||
    LivingCampaignPhase.dialogue ||
    LivingCampaignPhase.briefing ||
    LivingCampaignPhase.aftermathDialogue =>
      LivingCampaignTimingBucket.narrativeReading,
    LivingCampaignPhase.battle => LivingCampaignTimingBucket.battleActive,
    LivingCampaignPhase.outcomeAcknowledgement ||
    LivingCampaignPhase.chapterEnding ||
    LivingCampaignPhase.epilogue => LivingCampaignTimingBucket.resultsReview,
    LivingCampaignPhase.hub =>
      isPaidRequestRunning ? LivingCampaignTimingBucket.aiWait : null,
    LivingCampaignPhase.loading || LivingCampaignPhase.history => null,
    LivingCampaignPhase.chapterClosureLoading ||
    LivingCampaignPhase.chapterArtLoading => LivingCampaignTimingBucket.aiWait,
  };

  int? _timingChapterNumberForPhase(LivingCampaignPhase value) {
    final run = activeRun;
    if (run == null) return null;
    if (value == LivingCampaignPhase.outcomeAcknowledgement ||
        value == LivingCampaignPhase.chapterClosureLoading ||
        value == LivingCampaignPhase.aftermathDialogue ||
        value == LivingCampaignPhase.chapterArtLoading ||
        value == LivingCampaignPhase.chapterEnding ||
        value == LivingCampaignPhase.epilogue) {
      return pendingOutcome?.chapterNumber ??
          run.battleOutcomes.lastOrNull?.chapterNumber ??
          run.activeChapterNumber;
    }
    return run.activeChapterNumber;
  }

  void _recordTimingMilestone(LivingCampaignPhase value, DateTime at) {
    final metrics = _activeTimingMetrics;
    final chapterNumber = _timingChapterNumberForPhase(value);
    if (metrics == null || chapterNumber == null) return;
    LivingCampaignRunTimingMetrics? updated;
    if (value == LivingCampaignPhase.prologue ||
        value == LivingCampaignPhase.dialogue ||
        value == LivingCampaignPhase.briefing) {
      updated = metrics.markChapterOpened(chapterNumber: chapterNumber, at: at);
    } else if (value == LivingCampaignPhase.battle) {
      updated = metrics
          .markChapterOpened(chapterNumber: chapterNumber, at: at)
          .markBattleStarted(chapterNumber: chapterNumber, at: at);
    } else if (value == LivingCampaignPhase.outcomeAcknowledgement) {
      updated = metrics.markBattleEnded(chapterNumber: chapterNumber, at: at);
    } else if (value == LivingCampaignPhase.chapterEnding ||
        value == LivingCampaignPhase.epilogue) {
      updated = metrics.markChapterCompleted(
        chapterNumber: chapterNumber,
        at: at,
      );
    }
    if (updated == null) return;
    _activeTimingMetrics = updated;
    _queueTimingMetricsWrite(updated);
  }

  void _queueTimingMetricsWrite(LivingCampaignRunTimingMetrics metrics) {
    _timingWriteTail = _timingWriteTail
        .catchError((Object _) {})
        .then((_) => _archive.writeTimingMetrics(metrics));
    unawaited(
      _timingWriteTail.catchError((Object error, StackTrace stackTrace) {
        if (!_disposed) {
          debugPrint(
            'Living Campaign timing metrics could not be saved: $error',
          );
        }
      }),
    );
  }

  Future<void> _refreshArchives() async {
    archives = List.unmodifiable(await _archive.listRuns());
    storageBytes = await _archive.storageBytes();
  }

  Future<void> _backfillAuthoredPortraits() async {
    for (final summary in archives) {
      try {
        final stored = await _archive.readRun(summary.runId);
        if (stored == null) continue;
        final migrated =
            LivingPortraitFallbackResolver.backfillAuthoredPortraits(stored);
        if (!identical(stored, migrated)) {
          await _archive.writeRun(migrated);
        }
      } on Object {
        continue;
      }
    }
  }

  void _openChapterPrelude() {
    dialogueIndex = 0;
    phase = (activeChapter?.dialogue.isNotEmpty ?? false)
        ? LivingCampaignPhase.dialogue
        : LivingCampaignPhase.briefing;
  }

  bool _primaryObjectiveSatisfied(LivingChapterPackage chapter) {
    final objective = chapter.objective;
    final target = objective.targetPieceId == null
        ? null
        : _pieceSquare(objective.targetPieceId!);
    return switch (objective.type) {
      LivingObjectiveType.checkmate => false,
      LivingObjectiveType.reachEscape => _reachTargetEntered,
      LivingObjectiveType.surviveRounds =>
        gameController.completedRoundCount >= objective.surviveRounds!,
      LivingObjectiveType.neutralizeTarget =>
        _captured.any(
              (piece) =>
                  piece.wasActuallyCaptured &&
                  piece.pieceId == objective.targetPieceId,
            ) ||
            _purchasedPieceIds.contains(objective.targetPieceId),
      LivingObjectiveType.rescueRecover =>
        _purchasedPieceIds.contains(objective.targetPieceId) &&
            target != null &&
            target == objective.targetSquare &&
            gameController.pieceAt(target)!.color == PieceColor.white,
    };
  }

  Square? _pieceSquare(String pieceId) {
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        if (gameController.board[row][col]?.id == pieceId) {
          return Square(row, col);
        }
      }
    }
    return null;
  }

  void _updateReachObjectiveState(LivingChapterPackage chapter) {
    final objective = chapter.objective;
    if (objective.type != LivingObjectiveType.reachEscape ||
        objective.targetSquare == null ||
        _reachTargetEntered) {
      return;
    }
    final piece = gameController.pieceAt(objective.targetSquare!);
    if (piece == null) {
      if (_reachInitialOccupantPieceId != null) {
        _reachTargetVacated = true;
      }
      return;
    }
    final enteredAfterStart =
        _reachInitialOccupantPieceId == null ||
        piece.id != _reachInitialOccupantPieceId ||
        _reachTargetVacated;
    if (enteredAfterStart &&
        piece.color == PieceColor.white &&
        piece.type != PieceType.pawn) {
      _reachTargetEntered = true;
    }
  }

  void _recordRuntimeEvents() {
    final chapter = activeChapter;
    if (chapter == null) return;
    final motion = gameController.lastBoardMotionEvent;
    if (motion != null && motion.serial > _lastMotionSerial) {
      _lastMotionSerial = motion.serial;
      final captured = motion.capturedPiece;
      if (captured != null) {
        final missionPiece = chapter.pieces
            .where((piece) => piece.pieceId == captured.id)
            .firstOrNull;
        _captured.add(
          LivingCapturedPieceOutcome(
            pieceId: captured.id,
            pieceType: captured.type,
            ownerBeforeBattle: missionPiece?.color == PieceColor.white
                ? LivingAllegiance.player
                : LivingAllegiance.enemy,
            capturedByPieceId: motion.motions.first.piece.id,
            wasActuallyCaptured: true,
            characterId: missionPiece?.characterId,
          ),
        );
      }
    }
    final betrayal = gameController.lastBetrayalTransformEvent;
    if (betrayal != null && betrayal.serial > _lastBetrayalSerial) {
      _lastBetrayalSerial = betrayal.serial;
      final missionPiece = chapter.pieces
          .where((piece) => piece.pieceId == betrayal.after.id)
          .firstOrNull;
      _purchaseEvents.add(
        LivingPurchaseEventOutcome(
          pieceId: betrayal.after.id,
          pieceType: betrayal.after.type,
          fromAllegiance: betrayal.before.color == PieceColor.white
              ? LivingAllegiance.player
              : LivingAllegiance.enemy,
          toAllegiance: betrayal.after.color == PieceColor.white
              ? LivingAllegiance.player
              : LivingAllegiance.enemy,
          completedActionNumber: gameController.completedActionCount + 1,
          characterId: missionPiece?.characterId,
        ),
      );
      if (betrayal.after.color == PieceColor.white) {
        _purchasedPieceIds.add(betrayal.after.id);
      }
    }
  }

  void _finishBattle({
    required bool success,
    required bool objectiveCompleted,
  }) {
    if (_finishing) return;
    _finishing = true;
    _recordRuntimeEvents();
    final run = activeRun!;
    final chapter = activeChapter!;
    final surviving = <String>[];
    final roleChanges = <String, PieceType>{};
    for (final entry in run.canon.playerRosterByPieceId.entries) {
      final square = _pieceSquare(entry.key);
      if (square == null) continue;
      surviving.add(entry.key);
      final liveType = gameController.pieceAt(square)!.type;
      if (liveType != entry.value.basePieceType) {
        roleChanges[entry.key] = liveType;
      }
    }
    final purchasedPieces = <LivingPurchasedPieceOutcome>[];
    for (final pieceId in _purchasedPieceIds) {
      final missionPiece = chapter.pieces
          .where((piece) => piece.pieceId == pieceId)
          .firstOrNull;
      final liveSquare = _pieceSquare(pieceId);
      if (missionPiece == null ||
          liveSquare == null ||
          gameController.pieceAt(liveSquare)!.color != PieceColor.white) {
        continue;
      }
      purchasedPieces.add(
        LivingPurchasedPieceOutcome(
          pieceId: pieceId,
          pieceType: gameController.pieceAt(liveSquare)!.type,
          originCountryId: missionPiece.countryId,
          characterId: missionPiece.characterId,
          loyalty: gameController.pieceAt(liveSquare)!.loyalty,
        ),
      );
    }
    final pieceEndStates = <LivingPieceEndState>[];
    for (final missionPiece in chapter.pieces) {
      final liveSquare = _pieceSquare(missionPiece.pieceId);
      final livePiece = liveSquare == null
          ? null
          : gameController.pieceAt(liveSquare);
      final captured = _captured
          .where(
            (candidate) =>
                candidate.pieceId == missionPiece.pieceId &&
                candidate.wasActuallyCaptured,
          )
          .lastOrNull;
      final purchases = _purchaseEvents
          .where((event) => event.pieceId == missionPiece.pieceId)
          .toList(growable: false);
      final finalPurchase = purchases.lastOrNull;
      final endingType = livePiece?.type ?? captured?.pieceType;
      final endingColor =
          livePiece?.color ??
          switch (finalPurchase?.toAllegiance) {
            LivingAllegiance.player => PieceColor.white,
            LivingAllegiance.enemy => PieceColor.black,
            _ => missionPiece.color,
          };
      pieceEndStates.add(
        LivingPieceEndState(
          pieceId: missionPiece.pieceId,
          characterId: missionPiece.characterId,
          startingType: missionPiece.pieceType,
          startingColor: missionPiece.color,
          startingSquare: missionPiece.square,
          endingType: endingType,
          endingColor: endingColor,
          endingSquare: liveSquare,
          endingLoyalty: livePiece?.loyalty,
          wasCaptured: captured != null,
          wasPurchased: purchases.isNotEmpty,
          wasPromoted:
              missionPiece.pieceType == PieceType.pawn &&
              endingType != null &&
              endingType != PieceType.pawn,
        ),
      );
    }
    pendingOutcome = LivingBattleOutcomeSnapshot(
      chapterNumber: chapter.chapterNumber,
      chapterId: chapter.chapterId,
      result: success ? LivingBattleResult.victory : LivingBattleResult.defeat,
      endReason: gameController.resolvedGameEndReason,
      objectiveType: chapter.objective.type,
      pressureTier: chapter.pressureTier,
      objectiveCompleted: objectiveCompleted,
      completedTurns: gameController.completedActionCount,
      completedRoundCount: gameController.completedRoundCount,
      goldBefore: chapter.whiteGold,
      goldAfterBattle: gameController.gold[PieceColor.white]!,
      survivingPieceIds: List.unmodifiable(surviving),
      capturedPieces: List.unmodifiable(_captured),
      purchasedPieceIds: List.unmodifiable(_purchasedPieceIds),
      purchasedPieces: List.unmodifiable(purchasedPieces),
      purchaseEvents: List.unmodifiable(_purchaseEvents),
      pieceEndStates: List.unmodifiable(pieceEndStates),
      missionRoleChanges: Map.unmodifiable(roleChanges),
      kingTrapfallPieceId:
          gameController.resolvedGameEndReason == GameEndReason.kingTrapfall
          ? gameController.lastBattlefieldEvent?.pieceId
          : null,
      matchLog: List<String>.unmodifiable(gameController.fullEventLog),
    );
    objectiveSucceeded = success;
    phase = LivingCampaignPhase.outcomeAcknowledgement;
    notifyListeners();
  }

  void _onGameChanged() {
    if (!_disposed && phase == LivingCampaignPhase.battle) {
      _recordRuntimeEvents();
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _finishTimingSegment(_clock());
    _disposed = true;
    _taskSerial++;
    _closureSerial++;
    _generationTicker?.cancel();
    _generationTicker = null;
    final progress = _activeGenerationProgress;
    _activeGenerationProgress = null;
    _activeGenerationHandle = null;
    _activeGenerationTask = null;
    _chapterClosureTextTask = null;
    _chapterArtTask = null;
    if (progress != null && !progress.isClosed) unawaited(progress.close());
    gameController.removeListener(_onGameChanged);
    super.dispose();
  }
}
