import 'dart:io';

import 'package:path/path.dart' as p;

Future<String?> readLivingCampaignDeveloperEnvironmentFile() {
  return readLivingCampaignDeveloperEnvironmentFromRoots(<String>[
    Directory.current.path,
    File(Platform.resolvedExecutable).parent.path,
  ]);
}

Future<String?> readLivingCampaignDeveloperEnvironmentFromRoots(
  Iterable<String> roots,
) async {
  final visited = <String>{};
  for (final root in roots) {
    var current = p.normalize(p.absolute(root));
    for (var depth = 0; depth < 16; depth++) {
      if (!visited.add(current)) {
        break;
      }
      final pubspec = File(p.join(current, 'pubspec.yaml'));
      final environment = File(p.join(current, '.env'));
      try {
        if (await pubspec.exists() && await environment.exists()) {
          final projectMarker = await pubspec.readAsString();
          if (RegExp(
            r'^name:\s*crazy_chess\s*$',
            multiLine: true,
          ).hasMatch(projectMarker)) {
            return await environment.readAsString();
          }
        }
      } on FileSystemException {
        // A sandboxed or non-workspace root is not a developer environment.
      }
      final parent = p.dirname(current);
      if (parent == current) {
        break;
      }
      current = parent;
    }
  }
  return null;
}
