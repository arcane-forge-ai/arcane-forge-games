import 'dart:convert';

import 'package:crypto/crypto.dart';

import 'living_campaign_models.dart';

class LivingCanonContextProjection {
  const LivingCanonContextProjection({
    required this.payload,
    required this.canon,
    required this.compacted,
  });

  final Map<String, Object?> payload;
  final LivingCanonState canon;
  final bool compacted;
}

/// Builds the provider input without an application-level chapter or character
/// cap. The normal projection carries the complete structured canon. The
/// compact projection is only used after the provider reports its actual
/// context limit, and changes old event objects into lossless positional tuples.
class LivingCanonContextBuilder {
  const LivingCanonContextBuilder();

  LivingCanonContextProjection complete({
    required LivingCanonState canon,
    required LivingBattleOutcomeSnapshot outcome,
  }) {
    return LivingCanonContextProjection(
      payload: <String, Object?>{
        'continuityContract': continuityContract,
        'canon': canon.toJson(),
        'verifiedBattleOutcome': outcome.toJson(),
      },
      canon: canon,
      compacted: false,
    );
  }

  LivingCanonContextProjection losslessEventTupleProjection({
    required LivingCanonState canon,
    required LivingBattleOutcomeSnapshot outcome,
    required DateTime createdAt,
  }) {
    final epoch = _epochFor(canon, createdAt);
    final canonWithEpoch =
        canon.memoryEpochs.any(
          (candidate) => candidate.epochId == epoch.epochId,
        )
        ? canon
        : canon.copyWith(
            memoryEpochs: <LivingMemoryEpoch>[...canon.memoryEpochs, epoch],
          );
    final full = canonWithEpoch.toJson();
    full.remove('eventLedger');
    full['eventTupleSchema'] = const <String>[
      'eventId',
      'chapterNumber',
      'type',
      'subjectIds',
      'description',
      'causalEventIds',
      'metadata',
    ];
    full['eventLedgerTuples'] = canon.eventLedger.map(_eventTuple).toList();
    return LivingCanonContextProjection(
      payload: <String, Object?>{
        'continuityContract': continuityContract,
        'canon': full,
        'verifiedBattleOutcome': outcome.toJson(),
        'contextEncoding': <String, Object?>{
          'kind': 'lossless_event_tuples',
          'reason': 'provider_context_limit',
          'semanticFieldsRemoved': false,
        },
      },
      canon: canonWithEpoch,
      compacted: true,
    );
  }

  List<String> validateMemoryEpoch(
    LivingMemoryEpoch epoch,
    LivingCanonState canon,
  ) {
    final issues = <String>[];
    final events = <String, LivingCanonEvent>{
      for (final event in canon.eventLedger) event.eventId: event,
    };
    for (final eventId in epoch.includedEventIds) {
      final event = events[eventId];
      if (event == null) {
        issues.add('Memory epoch references missing event $eventId.');
        continue;
      }
      final expected = _hash(event.toJson());
      if (epoch.sourceHashes['event:$eventId'] != expected) {
        issues.add('Memory epoch hash mismatch for event $eventId.');
      }
    }
    for (final characterId in epoch.includedCharacterIds) {
      final character = canon.charactersById[characterId];
      if (character == null) {
        issues.add('Memory epoch references missing character $characterId.');
        continue;
      }
      final expected = _hash(character.toJson());
      if (epoch.sourceHashes['character:$characterId'] != expected) {
        issues.add('Memory epoch hash mismatch for character $characterId.');
      }
    }
    for (final threadId in epoch.includedThreadIds) {
      final thread = canon.storyThreadsById[threadId];
      if (thread == null) {
        issues.add('Memory epoch references missing thread $threadId.');
        continue;
      }
      final expected = _hash(thread.toJson());
      if (epoch.sourceHashes['thread:$threadId'] != expected) {
        issues.add('Memory epoch hash mismatch for thread $threadId.');
      }
    }
    if (epoch.narrative.trim().isEmpty) {
      issues.add('Memory epoch narrative is empty.');
    }
    return issues;
  }

  static const continuityContract = <String, Object?>{
    'completeCanonRequired': true,
    'arbitraryRollingSummaryCap': false,
    'deadCharactersStayDead': true,
    'presumedDeadIsNotDead': true,
    'verifiedFactsCannotBeSilentlyContradicted': true,
    'openThreadsMustRemainVisible': true,
    'stableCharacterAndPieceIds': true,
    'oneLineChapterLedgerIsImmutable': true,
  };

  LivingMemoryEpoch _epochFor(LivingCanonState canon, DateTime createdAt) {
    final sourceHashes = <String, String>{};
    for (final event in canon.eventLedger) {
      sourceHashes['event:${event.eventId}'] = _hash(event.toJson());
    }
    for (final entry in canon.charactersById.entries) {
      sourceHashes['character:${entry.key}'] = _hash(entry.value.toJson());
    }
    for (final entry in canon.storyThreadsById.entries) {
      sourceHashes['thread:${entry.key}'] = _hash(entry.value.toJson());
    }
    final lastChapter = canon.chapterLedger.isEmpty
        ? 0
        : canon.chapterLedger
              .map((chapter) => chapter.chapterNumber)
              .reduce((a, b) => a > b ? a : b);
    final sourceDigest = sha256
        .convert(utf8.encode(_canonicalJson(sourceHashes)))
        .toString();
    return LivingMemoryEpoch(
      epochId: 'epoch-${sourceDigest.substring(0, 16)}',
      firstChapter: canon.chapterLedger.isEmpty ? 0 : 1,
      lastChapter: lastChapter,
      narrative: canon.chapterLedger.isEmpty
          ? 'Before Chapter 1: the complete initial roster, character states, '
                'facts, relationships, and open threads are included by hash.'
          : canon.chapterLedger
                .map(
                  (chapter) =>
                      'Chapter ${chapter.chapterNumber}, ${chapter.title}: '
                      '${chapter.oneLineSummary}',
                )
                .join('\n'),
      sourceHashes: Map.unmodifiable(sourceHashes),
      includedCharacterIds: canon.charactersById.keys.toList(growable: false),
      includedEventIds: canon.eventLedger
          .map((event) => event.eventId)
          .toList(growable: false),
      includedThreadIds: canon.storyThreadsById.keys.toList(growable: false),
      createdAt: createdAt.toUtc(),
    );
  }

  List<Object?> _eventTuple(LivingCanonEvent event) => <Object?>[
    event.eventId,
    event.chapterNumber,
    event.type.name,
    event.subjectIds,
    event.description,
    event.causalEventIds,
    event.metadata,
  ];

  String _hash(Map<String, Object?> value) =>
      sha256.convert(utf8.encode(_canonicalJson(value))).toString();

  String _canonicalJson(Object? value) {
    Object? sort(Object? candidate) {
      if (candidate is Map) {
        final keys = candidate.keys.map((key) => key.toString()).toList()
          ..sort();
        return <String, Object?>{
          for (final key in keys) key: sort(candidate[key]),
        };
      }
      if (candidate is List) {
        return candidate.map(sort).toList(growable: false);
      }
      return candidate;
    }

    return jsonEncode(sort(value));
  }
}
