import '../domain/chess_models.dart';
import 'living_campaign_models.dart';

class LivingCampaignValidationException implements Exception {
  const LivingCampaignValidationException(this.issues);

  final List<String> issues;

  @override
  String toString() =>
      'Living Campaign validation failed: ${issues.join('; ')}';
}

abstract final class LivingRewardPolicy {
  static const allowedTiers = <int>{0, 10, 20, 35, 60};

  static int rewardFor({
    required LivingBattleResult result,
    required String pressureTier,
  }) {
    if (result != LivingBattleResult.victory) {
      return 0;
    }
    return switch (pressureTier) {
      'even' => 10,
      'pressured' => 20,
      'severe' => 35,
      'overwhelming' => 60,
      _ => throw LivingCampaignValidationException(<String>[
        'Unknown pressure tier: $pressureTier',
      ]),
    };
  }
}

class LivingCampaignValidator {
  const LivingCampaignValidator();

  static final RegExp _safeId = RegExp(r'^[A-Za-z0-9_-]+$');

  List<String> validateCanon(LivingCanonState canon) {
    final issues = <String>[];
    if (canon.schemaVersion != 1) {
      issues.add('Unsupported canon schemaVersion ${canon.schemaVersion}.');
    }
    if (!_validId(canon.runId)) {
      issues.add('Canon runId must use only letters, numbers, _ or -.');
    }
    if (canon.revision < 0) {
      issues.add('Canon revision cannot be negative.');
    }
    if (canon.gold < 0) {
      issues.add('Canon gold cannot be negative.');
    }
    final rosterIds = canon.playerRosterByPieceId.keys.toSet();
    final characterIds = canon.charactersById.keys.toSet();
    final knownSubjectIds = <String>{...rosterIds, ...characterIds};
    final eventIds = <String>{};
    for (final entry in canon.playerRosterByPieceId.entries) {
      if (entry.key != entry.value.pieceId) {
        issues.add('Roster key ${entry.key} does not match piece id.');
      }
      if (!_validId(entry.key)) {
        issues.add('Roster piece id ${entry.key} is not storage-safe.');
      }
      if (entry.value.origin.trim().isEmpty) {
        issues.add('Roster piece ${entry.key} has no origin.');
      }
      final characterId = entry.value.characterId;
      if (characterId != null &&
          !canon.charactersById.containsKey(characterId)) {
        issues.add(
          'Piece ${entry.key} references missing character $characterId.',
        );
      }
      if (entry.value.lifeState == LivingLifeState.dead &&
          entry.value.rosterPosition == LivingRosterPosition.active) {
        issues.add('Dead piece ${entry.key} cannot remain active.');
      }
    }
    for (final entry in canon.charactersById.entries) {
      final character = entry.value;
      if (entry.key != character.characterId) {
        issues.add('Character key ${entry.key} does not match character id.');
      }
      if (!_validId(entry.key)) {
        issues.add('Character id ${entry.key} is not storage-safe.');
      }
      if (character.originalName.trim().isEmpty ||
          character.originalIdentity.trim().isEmpty) {
        issues.add('Character ${entry.key} lacks stable original identity.');
      }
      if (character.firstChapter < 0 ||
          character.lastChapter < character.firstChapter ||
          character.lastChapter > canon.chapterLedger.length) {
        issues.add('Character ${entry.key} has an invalid chapter range.');
      }
      if (character.linkedPieceId != null &&
          !canon.playerRosterByPieceId.containsKey(character.linkedPieceId) &&
          character.allegiance == LivingAllegiance.player) {
        issues.add(
          'Player character ${entry.key} references missing piece '
          '${character.linkedPieceId}.',
        );
      }
      final linkedPiece = character.linkedPieceId == null
          ? null
          : canon.playerRosterByPieceId[character.linkedPieceId];
      if (linkedPiece != null && linkedPiece.characterId != entry.key) {
        issues.add(
          'Character ${entry.key} and piece ${linkedPiece.pieceId} do not '
          'reference each other.',
        );
      }
      if (linkedPiece != null &&
          (linkedPiece.basePieceType != character.basePieceType ||
              linkedPiece.lifeState != character.lifeState ||
              linkedPiece.whereabouts != character.whereabouts ||
              linkedPiece.allegiance != character.allegiance)) {
        issues.add(
          'Character ${entry.key} and piece ${linkedPiece.pieceId} have '
          'inconsistent canonical state.',
        );
      }
    }
    for (final event in canon.eventLedger) {
      if (!_validId(event.eventId)) {
        issues.add('Event id ${event.eventId} is not storage-safe.');
      }
      if (!eventIds.add(event.eventId)) {
        issues.add('Duplicate event id ${event.eventId}.');
      }
      if (event.chapterNumber < 0) {
        issues.add('Event ${event.eventId} has a negative chapter.');
      }
      if (event.chapterNumber > canon.chapterLedger.length) {
        issues.add('Event ${event.eventId} belongs to a future chapter.');
      }
      if (event.description.trim().isEmpty) {
        issues.add('Event ${event.eventId} has no description.');
      }
      for (final subjectId in event.subjectIds) {
        if (!knownSubjectIds.contains(subjectId)) {
          issues.add('Event ${event.eventId} has unknown subject $subjectId.');
        }
      }
    }
    for (final event in canon.eventLedger) {
      for (final causalEventId in event.causalEventIds) {
        if (!eventIds.contains(causalEventId)) {
          issues.add(
            'Event ${event.eventId} has unknown cause $causalEventId.',
          );
        }
      }
    }
    for (final piece in canon.playerRosterByPieceId.values) {
      for (final eventId in piece.historyEventIds) {
        if (!eventIds.contains(eventId)) {
          issues.add('Piece ${piece.pieceId} cites unknown event $eventId.');
        }
      }
    }
    for (final character in canon.charactersById.values) {
      for (final eventId in character.historyEventIds) {
        if (!eventIds.contains(eventId)) {
          issues.add(
            'Character ${character.characterId} cites unknown event $eventId.',
          );
        }
      }
    }
    final chapterNumbers = <int>{};
    final chapterIds = <String>{};
    for (var index = 0; index < canon.chapterLedger.length; index++) {
      final chapter = canon.chapterLedger[index];
      if (chapter.chapterNumber != index + 1) {
        issues.add('Canon chapters must be contiguous and ordered from 1.');
      }
      if (!chapterNumbers.add(chapter.chapterNumber)) {
        issues.add('Duplicate chapter number ${chapter.chapterNumber}.');
      }
      if (!_validId(chapter.chapterId) || !chapterIds.add(chapter.chapterId)) {
        issues.add('Chapter id ${chapter.chapterId} is invalid or duplicated.');
      }
      if (chapter.title.trim().isEmpty) {
        issues.add('Chapter ${chapter.chapterNumber} has no title.');
      }
      if (chapter.oneLineSummary.trim().isEmpty ||
          chapter.oneLineSummary.contains('\n')) {
        issues.add(
          'Chapter ${chapter.chapterNumber} summary must be one non-empty line.',
        );
      }
      for (final eventId in chapter.eventIds) {
        if (!eventIds.contains(eventId)) {
          issues.add(
            'Chapter ${chapter.chapterNumber} cites unknown event $eventId.',
          );
        }
      }
    }
    for (final entry in canon.canonFactsById.entries) {
      if (entry.key != entry.value.factId) {
        issues.add('Fact key ${entry.key} does not match fact id.');
      }
      if (!_validId(entry.key)) {
        issues.add('Fact id ${entry.key} is not storage-safe.');
      }
      if (entry.value.statement.trim().isEmpty ||
          entry.value.chapterNumber < 0 ||
          entry.value.chapterNumber > canon.chapterLedger.length) {
        issues.add('Fact ${entry.key} has invalid content or chapter.');
      }
      if (!eventIds.contains(entry.value.sourceEventId)) {
        issues.add(
          'Fact ${entry.key} references missing event '
          '${entry.value.sourceEventId}.',
        );
      }
      final sourceEvent = canon.eventLedger
          .where((event) => event.eventId == entry.value.sourceEventId)
          .firstOrNull;
      if (sourceEvent != null &&
          sourceEvent.chapterNumber != entry.value.chapterNumber) {
        issues.add('Fact ${entry.key} does not match its source chapter.');
      }
      for (final subjectId in entry.value.subjectIds) {
        if (!knownSubjectIds.contains(subjectId)) {
          issues.add('Fact ${entry.key} has unknown subject $subjectId.');
        }
      }
      if (entry.value.refutesFactId != null &&
          !canon.canonFactsById.containsKey(entry.value.refutesFactId)) {
        issues.add('Fact ${entry.key} refutes an unknown fact.');
      }
      final refutedFact = entry.value.refutesFactId == null
          ? null
          : canon.canonFactsById[entry.value.refutesFactId];
      if (refutedFact?.kind == LivingFactKind.verified) {
        issues.add('Fact ${entry.key} cannot refute a verified fact.');
      }
    }
    for (final entry in canon.storyThreadsById.entries) {
      if (entry.key != entry.value.threadId) {
        issues.add('Thread key ${entry.key} does not match thread id.');
      }
      if (!_validId(entry.key)) {
        issues.add('Thread id ${entry.key} is not storage-safe.');
      }
      if (entry.value.title.trim().isEmpty ||
          entry.value.summary.trim().isEmpty ||
          entry.value.participantIds.isEmpty ||
          entry.value.openedChapter < 0 ||
          entry.value.lastAdvancedChapter < entry.value.openedChapter ||
          entry.value.lastAdvancedChapter > canon.chapterLedger.length) {
        issues.add('Thread ${entry.key} has invalid content or chapters.');
      }
      if (entry.value.status == LivingThreadStatus.resolved &&
          entry.value.resolvedChapter == null) {
        issues.add('Resolved thread ${entry.key} has no resolved chapter.');
      }
      if (entry.value.status == LivingThreadStatus.open &&
          entry.value.resolvedChapter != null) {
        issues.add('Open thread ${entry.key} has a resolved chapter.');
      }
      if (entry.value.resolvedChapter != null &&
          (entry.value.resolvedChapter! < entry.value.openedChapter ||
              entry.value.resolvedChapter! > canon.chapterLedger.length)) {
        issues.add('Thread ${entry.key} has an invalid resolved chapter.');
      }
      for (final characterId in entry.value.participantIds) {
        if (!characterIds.contains(characterId)) {
          issues.add(
            'Thread ${entry.key} has unknown participant $characterId.',
          );
        }
      }
      for (final eventId in entry.value.evidenceEventIds) {
        if (!eventIds.contains(eventId)) {
          issues.add('Thread ${entry.key} cites unknown event $eventId.');
        }
      }
    }
    for (final entry in canon.relationshipsById.entries) {
      if (entry.key != entry.value.relationshipId) {
        issues.add('Relationship key ${entry.key} does not match id.');
      }
      if (!_validId(entry.key)) {
        issues.add('Relationship id ${entry.key} is not storage-safe.');
      }
      if (entry.value.characterIds.length != 2 ||
          entry.value.characterIds.toSet().length != 2) {
        issues.add('Relationship ${entry.key} must contain two characters.');
      }
      for (final characterId in entry.value.characterIds) {
        if (!characterIds.contains(characterId)) {
          issues.add(
            'Relationship ${entry.key} has unknown character $characterId.',
          );
        }
      }
      if (entry.value.currentSummary.trim().isEmpty) {
        issues.add('Relationship ${entry.key} has no current summary.');
      }
      for (final eventId in entry.value.changeEventIds) {
        if (!eventIds.contains(eventId)) {
          issues.add('Relationship ${entry.key} cites unknown event $eventId.');
        }
      }
    }
    final epochIds = <String>{};
    for (final epoch in canon.memoryEpochs) {
      if (!_validId(epoch.epochId) || !epochIds.add(epoch.epochId)) {
        issues.add(
          'Memory epoch id ${epoch.epochId} is invalid or duplicated.',
        );
      }
      if (epoch.firstChapter < 0 ||
          epoch.lastChapter < epoch.firstChapter ||
          epoch.narrative.trim().isEmpty) {
        issues.add('Memory epoch ${epoch.epochId} has invalid content.');
      }
      for (final characterId in epoch.includedCharacterIds) {
        if (!characterIds.contains(characterId)) {
          issues.add(
            'Memory epoch ${epoch.epochId} has unknown character $characterId.',
          );
        }
      }
      for (final eventId in epoch.includedEventIds) {
        if (!eventIds.contains(eventId)) {
          issues.add(
            'Memory epoch ${epoch.epochId} has unknown event $eventId.',
          );
        }
      }
      for (final threadId in epoch.includedThreadIds) {
        if (!canon.storyThreadsById.containsKey(threadId)) {
          issues.add(
            'Memory epoch ${epoch.epochId} has unknown thread $threadId.',
          );
        }
      }
    }
    return issues;
  }

  LivingCanonState applyDirectorPatch({
    required LivingCanonState canon,
    required LivingBattleOutcomeSnapshot outcome,
    required LivingDirectorPatch patch,
  }) {
    final issues = <String>[...validateCanon(canon)];
    if (patch.schemaVersion != canon.schemaVersion) {
      issues.add('Director patch schemaVersion does not match canon.');
    }
    if (patch.runId != canon.runId) {
      issues.add('Director patch runId does not match canon.');
    }
    if (patch.basedOnRevision != canon.revision) {
      issues.add(
        'Director patch is stale: expected revision ${canon.revision}, '
        'received ${patch.basedOnRevision}.',
      );
    }
    if (patch.completedChapter.chapterNumber != outcome.chapterNumber ||
        patch.completedChapter.chapterId != outcome.chapterId) {
      issues.add('Completed chapter patch does not match verified outcome.');
    }
    if (patch.completedChapter.oneLineSummary.trim().isEmpty ||
        patch.completedChapter.oneLineSummary.contains('\n')) {
      issues.add('Completed chapter summary must be one non-empty line.');
    }
    if (!_validId(patch.completedChapter.chapterId) ||
        patch.completedChapter.title.trim().isEmpty) {
      issues.add('Completed chapter must have a safe id and non-empty title.');
    }
    final activeWasFinale = canon.chapterLedger.any(
      (chapter) =>
          chapter.chapterNumber == outcome.chapterNumber - 1 &&
          chapter.finaleKind != LivingFinaleKind.none,
    );
    final endedByKingTrapfall = outcome.endReason == GameEndReason.kingTrapfall;
    if (endedByKingTrapfall) {
      final trappedPieceId = outcome.kingTrapfallPieceId;
      if (trappedPieceId == null || trappedPieceId.trim().isEmpty) {
        issues.add('King Trapfall outcome must identify the destroyed King.');
      }
      if (trappedPieceId != null &&
          outcome.survivingPieceIds.contains(trappedPieceId)) {
        issues.add('The Trapfall King cannot also be recorded as surviving.');
      }
      if (outcome.result == LivingBattleResult.defeat) {
        final trappedRosterPiece = trappedPieceId == null
            ? null
            : canon.playerRosterByPieceId[trappedPieceId];
        if (trappedRosterPiece?.basePieceType != PieceType.king) {
          issues.add(
            'A player Trapfall defeat must identify the canonical player King.',
          );
        }
      }
    }
    if (patch.campaignComplete) {
      if (!activeWasFinale && !endedByKingTrapfall) {
        issues.add(
          'Only a locked finale or verified King Trapfall may complete the run.',
        );
      }
      if (patch.epilogue == null ||
          patch.epilogue!.trim().length < 160 ||
          patch.epilogue!.length > 3200) {
        issues.add(
          'A completed campaign requires a 160–3200 character epilogue.',
        );
      }
    } else {
      if (endedByKingTrapfall && outcome.result == LivingBattleResult.defeat) {
        issues.add('A player King Trapfall must complete the campaign.');
      }
      if (patch.nextChapterIntent.chapterNumber != outcome.chapterNumber + 1) {
        issues.add('Next chapter number must immediately follow the outcome.');
      }
      if (patch.nextChapterIntent.conflict.trim().isEmpty ||
          patch.nextChapterIntent.essentialBeats.isEmpty ||
          patch.nextChapterIntent.essentialBeats.any(
            (beat) => beat.trim().isEmpty,
          )) {
        issues.add(
          'Next chapter requires a conflict and at least one essential beat.',
        );
      }
      if (patch.nextChapterIntent.objectiveType ==
          LivingObjectiveType.checkmate) {
        issues.add(
          'Generated chapters cannot lock checkmate as the primary objective.',
        );
      }
      if (patch.nextChapterIntent.finaleKind != LivingFinaleKind.none &&
          patch.nextChapterIntent.chapterNumber < 3) {
        issues.add('A finale cannot begin before Chapter 3.');
      }
    }
    if (patch.addCharacters.length > 1) {
      issues.add('A chapter may introduce at most one named character.');
    }
    final addedCharacterIds = patch.addCharacters
        .map((character) => character.characterId)
        .toSet();
    if (!patch.campaignComplete &&
        (patch.nextChapterIntent.newCharacterId == null
            ? addedCharacterIds.isNotEmpty
            : addedCharacterIds.length != 1 ||
                  !addedCharacterIds.contains(
                    patch.nextChapterIntent.newCharacterId,
                  ))) {
      issues.add(
        'Director newCharacterId must exactly match the one added character.',
      );
    }
    final expectedReward = _safeReward(outcome, patch, issues);

    final characters = Map<String, LivingCharacter>.from(canon.charactersById);
    final roster = Map<String, LivingRosterPiece>.from(
      canon.playerRosterByPieceId,
    );
    final events = List<LivingCanonEvent>.from(canon.eventLedger);
    final facts = Map<String, LivingCanonFact>.from(canon.canonFactsById);
    final threads = Map<String, LivingStoryThread>.from(canon.storyThreadsById);
    final relationships = Map<String, LivingRelationship>.from(
      canon.relationshipsById,
    );
    final existingEventIds = events.map((value) => value.eventId).toSet();
    final newEventIds = <String>{};

    for (final addition in patch.addRosterPieces) {
      if (!_validId(addition.pieceId)) {
        issues.add('Roster addition ${addition.pieceId} has an unsafe id.');
      }
      if (roster.containsKey(addition.pieceId)) {
        issues.add('Roster piece ${addition.pieceId} already exists.');
        continue;
      }
      final purchased = outcome.purchasedPieces
          .where((piece) => piece.pieceId == addition.pieceId)
          .firstOrNull;
      if (purchased == null ||
          !outcome.purchasedPieceIds.contains(addition.pieceId)) {
        issues.add(
          'Roster addition ${addition.pieceId} was not a verified purchase.',
        );
      } else {
        if (addition.basePieceType != purchased.pieceType) {
          issues.add(
            'Roster addition ${addition.pieceId} changed its base piece type.',
          );
        }
        if (addition.characterId != purchased.characterId &&
            purchased.characterId != null) {
          issues.add(
            'Roster addition ${addition.pieceId} changed character identity.',
          );
        }
      }
      if (addition.lifeState != LivingLifeState.alive ||
          addition.whereabouts != LivingWhereabouts.withCourt ||
          addition.allegiance != LivingAllegiance.player ||
          addition.rosterPosition != LivingRosterPosition.active ||
          addition.missionPieceType != null) {
        issues.add(
          'Roster addition ${addition.pieceId} has invalid joining state.',
        );
      }
      roster[addition.pieceId] = addition;
    }
    if (roster.values
            .where(
              (piece) =>
                  piece.rosterPosition == LivingRosterPosition.active &&
                  piece.lifeState != LivingLifeState.dead,
            )
            .length >
        16) {
      issues.add('The active Living Campaign roster cannot exceed 16 pieces.');
    }

    for (final character in patch.addCharacters) {
      if (!_validId(character.characterId)) {
        issues.add('New character ${character.characterId} has an unsafe id.');
      }
      if (characters.containsKey(character.characterId)) {
        issues.add('Character ${character.characterId} already exists.');
      }
      if (character.originalName.trim().isEmpty ||
          character.originalIdentity.trim().isEmpty) {
        issues.add('New character ${character.characterId} lacks identity.');
      }
      if (character.firstChapter != outcome.chapterNumber) {
        issues.add(
          'New character ${character.characterId} has wrong first chapter.',
        );
      }
      if (character.linkedPieceId != null) {
        final piece = roster[character.linkedPieceId];
        if (piece == null) {
          issues.add(
            'Named elevation ${character.characterId} references unknown piece '
            '${character.linkedPieceId}.',
          );
        } else if (piece.characterId != null &&
            piece.characterId != character.characterId) {
          issues.add(
            'Piece ${piece.pieceId} is already named ${piece.characterId}.',
          );
        } else {
          if (piece.basePieceType != character.basePieceType) {
            issues.add(
              'Named elevation ${character.characterId} changed piece type.',
            );
          }
          if (piece.characterId == null) {
            roster[piece.pieceId] = piece.copyWith(
              characterId: character.characterId,
            );
          }
        }
      }
      characters[character.characterId] = character;
    }

    for (final event in patch.addEvents) {
      if (!_validId(event.eventId)) {
        issues.add('Event ${event.eventId} has an unsafe id.');
      }
      if (existingEventIds.contains(event.eventId) ||
          !newEventIds.add(event.eventId)) {
        issues.add('Event ${event.eventId} already exists or is duplicated.');
      }
      if (event.chapterNumber != outcome.chapterNumber) {
        issues.add('Event ${event.eventId} belongs to the wrong chapter.');
      }
      if (event.description.trim().isEmpty) {
        issues.add('Event ${event.eventId} has no description.');
      }
      final knownSubjects = <String>{...characters.keys, ...roster.keys};
      for (final subjectId in event.subjectIds) {
        if (!knownSubjects.contains(subjectId)) {
          issues.add('Event ${event.eventId} has unknown subject $subjectId.');
        }
      }
      events.add(event);
    }
    final allEventIds = <String>{...existingEventIds, ...newEventIds};
    final addedEventsById = <String, LivingCanonEvent>{
      for (final event in patch.addEvents) event.eventId: event,
    };
    for (final event in patch.addEvents) {
      for (final causal in event.causalEventIds) {
        if (!allEventIds.contains(causal)) {
          issues.add('Event ${event.eventId} has unknown cause $causal.');
        }
      }
    }
    for (final characterId in addedCharacterIds) {
      if (!patch.addEvents.any(
        (event) => event.subjectIds.contains(characterId),
      )) {
        issues.add(
          'New character $characterId is not grounded in a chapter event.',
        );
      }
    }

    final transitionedCharacters = <String>{};
    for (final transition in patch.characterTransitions) {
      final character = characters[transition.characterId];
      if (character == null) {
        issues.add('Transition references unknown ${transition.characterId}.');
        continue;
      }
      if (!transitionedCharacters.add(transition.characterId)) {
        issues.add('Character ${transition.characterId} transitions twice.');
      }
      if (transition.chapterNumber != outcome.chapterNumber) {
        issues.add(
          'Transition for ${transition.characterId} has wrong chapter.',
        );
      }
      if (!allEventIds.contains(transition.causalEventId)) {
        issues.add(
          'Transition for ${transition.characterId} has unknown cause '
          '${transition.causalEventId}.',
        );
      }
      final causalEvent =
          addedEventsById[transition.causalEventId] ??
          events
              .where((event) => event.eventId == transition.causalEventId)
              .firstOrNull;
      if (causalEvent != null &&
          !causalEvent.subjectIds.contains(transition.characterId)) {
        issues.add(
          'Transition cause for ${transition.characterId} does not name them.',
        );
      }
      if (transition.nextLifeState == LivingLifeState.dead &&
          causalEvent?.type != LivingEventType.killed) {
        issues.add(
          'Death transition for ${transition.characterId} requires a killed '
          'event.',
        );
      }
      if (transition.nextLifeState == LivingLifeState.wounded &&
          causalEvent?.type != LivingEventType.wounded) {
        issues.add(
          'Wound transition for ${transition.characterId} requires a wounded '
          'event.',
        );
      }
      if (character.lifeState != transition.expectedLifeState ||
          character.whereabouts != transition.expectedWhereabouts ||
          character.allegiance != transition.expectedAllegiance) {
        issues.add(
          'Transition expected state for ${transition.characterId} is stale.',
        );
      }
      if (character.lifeState == LivingLifeState.dead &&
          transition.nextLifeState != LivingLifeState.dead) {
        issues.add('Dead character ${transition.characterId} cannot return.');
      }
      if (transition.nextLifeState == LivingLifeState.dead &&
          !_deathIsEligible(character, outcome)) {
        issues.add(
          'Character ${transition.characterId} was not capture-eligible for death.',
        );
      }
      final nextEvents = <String>[
        ...character.historyEventIds,
        transition.causalEventId,
      ];
      characters[character.characterId] = character.copyWith(
        lifeState: transition.nextLifeState,
        whereabouts: transition.nextWhereabouts,
        allegiance: transition.nextAllegiance,
        lastChapter: outcome.chapterNumber,
        historyEventIds: nextEvents,
      );
      final linkedPieceId = character.linkedPieceId;
      if (linkedPieceId != null && roster.containsKey(linkedPieceId)) {
        final piece = roster[linkedPieceId]!;
        roster[linkedPieceId] = piece.copyWith(
          lifeState: transition.nextLifeState,
          whereabouts: transition.nextWhereabouts,
          allegiance: transition.nextAllegiance,
          rosterPosition: transition.nextLifeState == LivingLifeState.dead
              ? LivingRosterPosition.former
              : piece.rosterPosition,
          historyEventIds: <String>[
            ...piece.historyEventIds,
            transition.causalEventId,
          ],
        );
      }
    }
    for (final event in patch.addEvents.where(
      (event) => event.type == LivingEventType.killed,
    )) {
      for (final characterId in event.subjectIds.where(
        characters.containsKey,
      )) {
        if (!patch.characterTransitions.any(
          (transition) =>
              transition.characterId == characterId &&
              transition.nextLifeState == LivingLifeState.dead,
        )) {
          issues.add(
            'Killed event ${event.eventId} has no matching death transition '
            'for $characterId.',
          );
        }
      }
    }
    if (endedByKingTrapfall && outcome.result == LivingBattleResult.defeat) {
      final trappedPiece =
          canon.playerRosterByPieceId[outcome.kingTrapfallPieceId];
      final trappedCharacterId = trappedPiece?.characterId;
      if (trappedCharacterId != null &&
          !patch.characterTransitions.any(
            (transition) =>
                transition.characterId == trappedCharacterId &&
                transition.nextLifeState == LivingLifeState.dead,
          )) {
        issues.add(
          'The named player King killed by Trapfall requires a death transition.',
        );
      }
    }

    for (final fact in patch.addCanonFacts) {
      if (!_validId(fact.factId)) {
        issues.add('Fact ${fact.factId} has an unsafe id.');
      }
      if (facts.containsKey(fact.factId)) {
        issues.add('Fact ${fact.factId} already exists.');
      }
      if (!allEventIds.contains(fact.sourceEventId)) {
        issues.add('Fact ${fact.factId} has an unknown source event.');
      }
      if (fact.chapterNumber != outcome.chapterNumber ||
          fact.statement.trim().isEmpty) {
        issues.add('Fact ${fact.factId} has invalid content or chapter.');
      }
      final knownSubjects = <String>{...characters.keys, ...roster.keys};
      for (final subjectId in fact.subjectIds) {
        if (!knownSubjects.contains(subjectId)) {
          issues.add('Fact ${fact.factId} has unknown subject $subjectId.');
        }
      }
      if (fact.refutesFactId != null) {
        final target = facts[fact.refutesFactId];
        if (target == null) {
          issues.add('Fact ${fact.factId} refutes an unknown fact.');
        } else if (target.kind == LivingFactKind.verified) {
          issues.add('Verified fact ${target.factId} cannot be refuted.');
        }
      }
      facts[fact.factId] = fact;
    }

    for (final thread in patch.openStoryThreads) {
      if (!_validId(thread.threadId)) {
        issues.add('Thread ${thread.threadId} has an unsafe id.');
      }
      if (threads.containsKey(thread.threadId)) {
        issues.add('Thread ${thread.threadId} already exists.');
      }
      if (thread.status != LivingThreadStatus.open ||
          thread.openedChapter != outcome.chapterNumber) {
        issues.add('New thread ${thread.threadId} has invalid opening state.');
      }
      if (thread.title.trim().isEmpty || thread.summary.trim().isEmpty) {
        issues.add('New thread ${thread.threadId} has empty content.');
      }
      for (final participantId in thread.participantIds) {
        if (!characters.containsKey(participantId)) {
          issues.add(
            'New thread ${thread.threadId} has unknown participant '
            '$participantId.',
          );
        }
      }
      for (final eventId in thread.evidenceEventIds) {
        if (!allEventIds.contains(eventId)) {
          issues.add(
            'New thread ${thread.threadId} cites unknown event $eventId.',
          );
        }
      }
      threads[thread.threadId] = thread;
    }
    final changedThreads = <String>{};
    for (final change in <LivingThreadChange>[
      ...patch.advanceStoryThreads,
      ...patch.resolveStoryThreads,
    ]) {
      final thread = threads[change.threadId];
      if (thread == null) {
        issues.add('Thread change references unknown ${change.threadId}.');
        continue;
      }
      if (!changedThreads.add(change.threadId)) {
        issues.add('Thread ${change.threadId} changes twice.');
      }
      if (thread.status != change.expectedStatus ||
          thread.status == LivingThreadStatus.resolved) {
        issues.add('Thread ${change.threadId} expected status is stale.');
      }
      if (change.chapterNumber != outcome.chapterNumber) {
        issues.add('Thread ${change.threadId} change has wrong chapter.');
      }
      for (final eventId in change.evidenceEventIds) {
        if (!allEventIds.contains(eventId)) {
          issues.add('Thread ${change.threadId} cites unknown event $eventId.');
        }
      }
      threads[change.threadId] = thread.copyWith(
        status: change.resolve
            ? LivingThreadStatus.resolved
            : LivingThreadStatus.open,
        lastAdvancedChapter: outcome.chapterNumber,
        resolvedChapter: change.resolve ? outcome.chapterNumber : null,
        summary: change.summary,
        evidenceEventIds: <String>[
          ...thread.evidenceEventIds,
          ...change.evidenceEventIds,
        ],
      );
    }

    final changedRelationships = <String>{};
    for (final change in patch.relationshipChanges) {
      if (!changedRelationships.add(change.relationshipId)) {
        issues.add('Relationship ${change.relationshipId} changes twice.');
      }
      final relationship = relationships[change.relationshipId];
      if (relationship == null) {
        issues.add(
          'Relationship change references unknown ${change.relationshipId}.',
        );
        continue;
      }
      if (relationship.currentSummary != change.expectedSummary) {
        issues.add(
          'Relationship ${change.relationshipId} expected summary is stale.',
        );
      }
      if (!allEventIds.contains(change.causalEventId)) {
        issues.add(
          'Relationship ${change.relationshipId} cites unknown event.',
        );
      }
      relationships[change.relationshipId] = relationship.copyWith(
        currentSummary: change.nextSummary,
        changeEventIds: <String>[
          ...relationship.changeEventIds,
          change.causalEventId,
        ],
      );
    }

    if (issues.isNotEmpty) {
      throw LivingCampaignValidationException(List.unmodifiable(issues));
    }

    final chapter = LivingChapterRecord(
      chapterNumber: outcome.chapterNumber,
      chapterId: outcome.chapterId,
      title: patch.completedChapter.title,
      oneLineSummary: patch.completedChapter.oneLineSummary,
      objectiveType: outcome.objectiveType,
      result: outcome.result,
      eventIds: patch.addEvents.map((event) => event.eventId).toList(),
      finaleKind: patch.campaignComplete
          ? canon.chapterLedger
                    .where(
                      (candidate) =>
                          candidate.chapterNumber == outcome.chapterNumber - 1,
                    )
                    .firstOrNull
                    ?.finaleKind ??
                (outcome.result == LivingBattleResult.victory
                    ? LivingFinaleKind.hopeful
                    : LivingFinaleKind.tragic)
          : patch.nextChapterIntent.finaleKind,
    );
    final next = canon.copyWith(
      revision: canon.revision + 1,
      gold: outcome.goldAfterBattle + expectedReward,
      playerRosterByPieceId: roster.map(
        (key, value) =>
            MapEntry(key, value.copyWith(clearMissionPieceType: true)),
      ),
      charactersById: characters,
      chapterLedger: <LivingChapterRecord>[...canon.chapterLedger, chapter],
      eventLedger: events,
      canonFactsById: facts,
      storyThreadsById: threads,
      relationshipsById: relationships,
    );
    final nextIssues = validateCanon(next);
    if (nextIssues.isNotEmpty) {
      throw LivingCampaignValidationException(nextIssues);
    }
    return next;
  }

  List<String> validateChapterPackage({
    required LivingCanonState canon,
    required LivingNextChapterIntent intent,
    required LivingChapterPackage package,
  }) {
    final issues = <String>[...validateCanon(canon)];
    if (!const <int>{1, 2}.contains(package.schemaVersion)) {
      issues.add('Builder schemaVersion is unsupported.');
    }
    if (package.runId != canon.runId) {
      issues.add('Builder runId does not match canon.');
    }
    if (package.basedOnRevision != canon.revision) {
      issues.add('Builder package is not pinned to the current revision.');
    }
    if (package.chapterNumber != intent.chapterNumber) {
      issues.add('Builder chapter number does not match Director intent.');
    }
    if (intent.conflict.trim().isEmpty ||
        (intent.chapterNumber > 1 && intent.essentialBeats.isEmpty) ||
        intent.essentialBeats.any((beat) => beat.trim().isEmpty)) {
      issues.add('Locked Director intent has no usable story beats.');
    }
    if (!_validId(package.chapterId) ||
        package.title.trim().isEmpty ||
        package.subtitle.trim().isEmpty ||
        package.briefing.trim().isEmpty) {
      issues.add('Builder chapter requires a safe id and complete story text.');
    }
    if (canon.chapterLedger.any(
      (chapter) => chapter.chapterId == package.chapterId,
    )) {
      issues.add('Builder chapter id already exists in canon.');
    }
    if (package.chapterNumber != canon.chapterLedger.length + 1) {
      issues.add('Builder chapter number must immediately follow canon.');
    }
    if (package.objective.type != intent.objectiveType) {
      issues.add('Builder changed the locked objective type.');
    }
    if (package.pressureTier != intent.pressureTier) {
      issues.add('Builder changed the locked pressure tier.');
    }
    if (package.whiteCountryId != 'ashen') {
      issues.add('The player must remain the Ashen Court.');
    }
    const enemyCountries = <String>{
      'ashen',
      'mercantile',
      'iron',
      'horse',
      'spy',
    };
    if (!enemyCountries.contains(package.blackCountryId)) {
      issues.add('Enemy country ${package.blackCountryId} is not allowlisted.');
    }
    if (package.whiteGold != canon.gold || package.blackGold < 0) {
      issues.add('Builder gold does not match verified player canon.');
    }
    if (!package.economyEnabled ||
        !package.merchantEnabled ||
        !package.specialTilesEnabled) {
      issues.add(
        'Economy, merchant, and special tiles must remain enabled in v1.',
      );
    }
    if (package.merchantSpeed < 1 || package.merchantSpeed > 8) {
      issues.add('Merchant speed must be between 1 and 8.');
    }
    if (package.seed < 0) {
      issues.add('Mission seed cannot be negative.');
    }
    final ids = <String>{};
    final squares = <Square>{};
    final deployedByColor = <PieceColor, List<LivingMissionPiece>>{
      PieceColor.white: <LivingMissionPiece>[],
      PieceColor.black: <LivingMissionPiece>[],
    };
    for (final piece in package.pieces) {
      if (!_validId(piece.pieceId)) {
        issues.add('Mission piece ${piece.pieceId} has an unsafe id.');
      }
      if (!ids.add(piece.pieceId)) {
        issues.add('Piece ${piece.pieceId} is deployed twice.');
      }
      if (!squares.add(piece.square)) {
        issues.add(
          'Square ${livingSquareName(piece.square)} is occupied twice.',
        );
      }
      deployedByColor[piece.color]!.add(piece);
      final expectedCountry = piece.color == PieceColor.white
          ? package.whiteCountryId
          : package.blackCountryId;
      if (piece.countryId != expectedCountry) {
        issues.add(
          'Piece ${piece.pieceId} country does not match its deployed side.',
        );
      }
      if (piece.color == PieceColor.white) {
        final rosterPiece = canon.playerRosterByPieceId[piece.pieceId];
        if (rosterPiece == null) {
          if (piece.pieceType != PieceType.pawn || piece.characterId != null) {
            issues.add('Unknown player piece ${piece.pieceId} is deployed.');
          }
        } else {
          if (rosterPiece.lifeState != LivingLifeState.alive ||
              rosterPiece.whereabouts != LivingWhereabouts.withCourt ||
              rosterPiece.allegiance != LivingAllegiance.player ||
              rosterPiece.rosterPosition != LivingRosterPosition.active) {
            issues.add(
              'Unavailable player piece ${piece.pieceId} is deployed.',
            );
          }
          if (piece.pieceType != rosterPiece.battlePieceType) {
            issues.add('Piece ${piece.pieceId} has an unauthorized role.');
          }
          if (piece.characterId != rosterPiece.characterId) {
            issues.add('Piece ${piece.pieceId} changed character identity.');
          }
        }
      }
      if (piece.characterId != null) {
        if (!_validId(piece.characterId!)) {
          issues.add(
            'Mission character ${piece.characterId} has an unsafe id.',
          );
        }
        final character = canon.charactersById[piece.characterId];
        if (character == null) {
          issues.add(
            'Piece ${piece.pieceId} references unknown character '
            '${piece.characterId}.',
          );
        } else if (piece.color == PieceColor.black &&
            character.basePieceType != piece.pieceType) {
          issues.add(
            'Character ${character.characterId} changed base piece type.',
          );
        }
      }
      if (piece.pieceType == PieceType.king &&
          (piece.loyalty != null || piece.fairPrice != null)) {
        issues.add('King ${piece.pieceId} cannot have Loyalty or a price.');
      }
      if (piece.pieceType != PieceType.king &&
          (piece.loyalty == null ||
              piece.loyalty! < 0 ||
              piece.loyalty! > 100 ||
              piece.fairPrice == null ||
              piece.fairPrice! < 1)) {
        issues.add('Non-King ${piece.pieceId} has invalid economy state.');
      }
    }
    for (final color in PieceColor.values) {
      final pieces = deployedByColor[color]!;
      if (pieces.length > 16) {
        issues.add('${color.name} deploys more than 16 pieces.');
      }
      _validateComposition(color, pieces, issues);
    }
    final whiteKings = deployedByColor[PieceColor.white]!
        .where((piece) => piece.pieceType == PieceType.king)
        .toList();
    final blackKings = deployedByColor[PieceColor.black]!
        .where((piece) => piece.pieceType == PieceType.king)
        .toList();
    if (whiteKings.length == 1 &&
        blackKings.length == 1 &&
        (whiteKings.single.square.row - blackKings.single.square.row).abs() <=
            1 &&
        (whiteKings.single.square.col - blackKings.single.square.col).abs() <=
            1) {
      issues.add('Kings cannot begin on adjacent squares.');
    }
    if (package.reservePieceIds.isNotEmpty) {
      issues.add('Living Campaign v1 does not support mission reserves.');
    }
    _validateObjective(package, ids, issues);
    if (package.dialogue.isEmpty) {
      issues.add('Every chapter requires opening dialogue.');
    }
    final dialogueIds = <String>{};
    final missionCharacterIds = package.pieces
        .map((piece) => piece.characterId)
        .whereType<String>()
        .toSet();
    for (final line in package.dialogue) {
      if (!_validId(line.lineId) || !dialogueIds.add(line.lineId)) {
        issues.add('Dialogue line id ${line.lineId} is invalid or duplicated.');
      }
      if (line.side != 'left' && line.side != 'right') {
        issues.add('Dialogue line ${line.lineId} has an invalid side.');
      }
      if (line.text.trim().isEmpty) {
        issues.add('Dialogue line ${line.lineId} has no text.');
      }
      if (!canon.charactersById.containsKey(line.speakerId) &&
          !missionCharacterIds.contains(line.speakerId)) {
        issues.add(
          'Dialogue line ${line.lineId} has unknown speaker '
          '${line.speakerId}.',
        );
      } else if (canon.charactersById[line.speakerId]?.lifeState ==
          LivingLifeState.dead) {
        issues.add('Dialogue line ${line.lineId} gives speech to the dead.');
      }
    }
    for (final value in <double>[
      package.aiAggression,
      package.aiDefense,
      package.aiObjectivePressure,
      package.aiTileAppetite,
    ]) {
      if (!value.isFinite || value < 0 || value > 1) {
        issues.add('AI profile values must be between 0 and 1.');
      }
    }
    final intendedCharacter = intent.newCharacterId;
    if (intendedCharacter == null && package.portraitCharacterId != null) {
      issues.add('Builder requested an unlocked portrait character.');
    }
    if (intendedCharacter != null &&
        package.portraitCharacterId != intendedCharacter) {
      issues.add('Builder portrait does not match the locked new character.');
    }
    if (intendedCharacter != null &&
        !canon.charactersById.containsKey(intendedCharacter)) {
      issues.add('Locked portrait character is absent from canonical state.');
    }
    if (package.portraitCharacterId != null &&
        (package.portraitPrompt == null ||
            package.portraitPrompt!.trim().isEmpty)) {
      issues.add('Portrait request has no prompt.');
    }
    if (package.portraitCharacterId == null && package.portraitPrompt != null) {
      issues.add('Portrait prompt has no character id.');
    }
    return issues;
  }

  int _safeReward(
    LivingBattleOutcomeSnapshot outcome,
    LivingDirectorPatch patch,
    List<String> issues,
  ) {
    try {
      final reward = LivingRewardPolicy.rewardFor(
        result: outcome.result,
        pressureTier: outcome.pressureTier,
      );
      final nextReward = LivingRewardPolicy.rewardFor(
        result: LivingBattleResult.victory,
        pressureTier: patch.nextChapterIntent.pressureTier,
      );
      if (!patch.campaignComplete &&
          patch.nextChapterIntent.rewardTier != nextReward) {
        issues.add(
          'Director reward ${patch.nextChapterIntent.rewardTier} does not match '
          'next-chapter client tier $nextReward.',
        );
      }
      return reward;
    } on LivingCampaignValidationException catch (error) {
      issues.addAll(error.issues);
      return 0;
    }
  }

  bool _deathIsEligible(
    LivingCharacter character,
    LivingBattleOutcomeSnapshot outcome,
  ) {
    if (character.basePieceType == PieceType.king) {
      return outcome.endReason == GameEndReason.kingTrapfall &&
          character.linkedPieceId != null &&
          character.linkedPieceId == outcome.kingTrapfallPieceId;
    }
    final linkedPieceId = character.linkedPieceId;
    return outcome.capturedPieces.any(
      (piece) =>
          piece.wasActuallyCaptured &&
          (piece.characterId == character.characterId ||
              piece.pieceId == linkedPieceId),
    );
  }

  void _validateComposition(
    PieceColor color,
    List<LivingMissionPiece> pieces,
    List<String> issues,
  ) {
    const caps = <PieceType, int>{
      PieceType.king: 1,
      PieceType.queen: 1,
      PieceType.rook: 2,
      PieceType.bishop: 2,
      PieceType.knight: 2,
      PieceType.pawn: 8,
    };
    for (final entry in caps.entries) {
      final count = pieces
          .where((piece) => piece.pieceType == entry.key)
          .length;
      if (entry.key == PieceType.king && count != 1) {
        issues.add('${color.name} must deploy exactly one King.');
      } else if (count > entry.value) {
        issues.add('${color.name} exceeds the ${entry.key.name} starting cap.');
      }
    }
  }

  void _validateObjective(
    LivingChapterPackage package,
    Set<String> deployedIds,
    List<String> issues,
  ) {
    final objective = package.objective;
    switch (objective.type) {
      case LivingObjectiveType.checkmate:
        if (package.chapterNumber > 1) {
          issues.add(
            'Generated chapters must use a non-checkmate primary objective; '
            'checkmate remains the universal alternate victory.',
          );
        }
        if (objective.targetPieceId != null ||
            objective.targetSquare != null ||
            objective.surviveRounds != null) {
          issues.add('Checkmate objective contains unsupported target fields.');
        }
      case LivingObjectiveType.reachEscape:
        if (objective.targetSquare == null || objective.surviveRounds != null) {
          issues.add('Reach/escape requires a target square.');
        }
        if (objective.targetPieceId != null) {
          issues.add(
            'Reach/escape is completed by any White advanced piece and must not lock a piece ID.',
          );
        }
      case LivingObjectiveType.surviveRounds:
        if (objective.surviveRounds == null ||
            objective.surviveRounds! < 18 ||
            objective.surviveRounds! > 36) {
          issues.add('Survive objective must contain 18–36 full rounds.');
        }
        if (package.pressureTier == 'even') {
          issues.add('Survive objective cannot use even pressure.');
        }
        if (objective.targetPieceId != null || objective.targetSquare != null) {
          issues.add('Survive objective contains unsupported target fields.');
        }
      case LivingObjectiveType.neutralizeTarget:
        if (objective.targetPieceId == null ||
            !deployedIds.contains(objective.targetPieceId)) {
          issues.add('Neutralize objective requires a deployed target piece.');
        } else if (package.pieces
                .firstWhere((piece) => piece.pieceId == objective.targetPieceId)
                .color !=
            PieceColor.black) {
          issues.add('Neutralize target must begin on the enemy side.');
        }
        if (objective.targetSquare != null || objective.surviveRounds != null) {
          issues.add(
            'Neutralize objective contains unsupported target fields.',
          );
        }
      case LivingObjectiveType.rescueRecover:
        if (objective.targetPieceId == null ||
            !deployedIds.contains(objective.targetPieceId) ||
            objective.targetSquare == null) {
          issues.add(
            'Rescue/recover requires a deployed target and extraction square.',
          );
        } else if (package.pieces
                .firstWhere((piece) => piece.pieceId == objective.targetPieceId)
                .color !=
            PieceColor.black) {
          issues.add('Rescue/recover target must begin on the enemy side.');
        }
        if (objective.surviveRounds != null) {
          issues.add('Rescue/recover contains an unsupported turn target.');
        }
    }
  }

  static bool _validId(String value) => _safeId.hasMatch(value);
}
