import 'living_campaign_developer_env_loader_stub.dart'
    if (dart.library.io) 'living_campaign_developer_env_loader_io.dart'
    as platform;

Future<String?> readLivingCampaignDeveloperEnvironmentFile() =>
    platform.readLivingCampaignDeveloperEnvironmentFile();
