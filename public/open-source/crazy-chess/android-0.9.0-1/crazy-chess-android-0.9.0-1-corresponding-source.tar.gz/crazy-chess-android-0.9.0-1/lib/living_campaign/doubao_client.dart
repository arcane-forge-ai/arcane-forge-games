import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:image/image.dart' as img;

import 'living_campaign_settings.dart';

class LivingProviderException implements Exception {
  const LivingProviderException({
    required this.code,
    required this.safeMessage,
    this.statusCode,
    this.requestId,
    this.providerMessage,
    this.redactedResponseBody,
  });

  final String code;
  final String safeMessage;
  final int? statusCode;
  final String? requestId;
  final String? providerMessage;
  final String? redactedResponseBody;

  bool get isContextLimit => code == 'context_length_exceeded';

  @override
  String toString() => safeMessage;
}

class DoubaoTokenizationResult {
  const DoubaoTokenizationResult({
    required this.totalTokens,
    required this.requestId,
    required this.model,
  });

  final int totalTokens;
  final String? requestId;
  final String? model;
}

class LivingSecretRedactor {
  const LivingSecretRedactor();

  String redact(String value, {Iterable<String> secrets = const <String>[]}) {
    var output = value;
    for (final secret in secrets) {
      if (secret.trim().isNotEmpty) {
        output = output.replaceAll(secret, '[REDACTED]');
      }
    }
    output = output.replaceAll(
      RegExp(r'Bearer\s+[A-Za-z0-9._~+\-/=]+', caseSensitive: false),
      'Bearer [REDACTED]',
    );
    output = output.replaceAll(
      RegExp(
        r'("?(?:api[_-]?key|ARK_API_KEY)"?\s*[:=]\s*")([^"\s]+)',
        caseSensitive: false,
      ),
      r'$1[REDACTED]',
    );
    return output;
  }
}

class DoubaoJsonResponse {
  const DoubaoJsonResponse({
    required this.value,
    required this.requestId,
    required this.model,
    required this.usage,
    required this.redactedRawResponse,
    this.rawContent = '',
    this.transport = 'sse',
    this.timeToFirstEvent,
    this.duration,
    this.finishReason,
  });

  final Map<String, Object?> value;
  final String? requestId;
  final String? model;
  final Map<String, Object?> usage;
  final String redactedRawResponse;
  final String rawContent;
  final String transport;
  final Duration? timeToFirstEvent;
  final Duration? duration;
  final String? finishReason;
}

enum DoubaoStreamPhase { connected, providerWorking, receiving, completed }

class DoubaoStreamProgress {
  const DoubaoStreamProgress({
    required this.phase,
    required this.occurredAt,
    this.requestId,
    this.receivedContentCharacters = 0,
    this.reasoningDelta = '',
    this.contentDelta = '',
  });

  final DoubaoStreamPhase phase;
  final DateTime occurredAt;
  final String? requestId;
  final int receivedContentCharacters;
  final String reasoningDelta;
  final String contentDelta;
}

typedef DoubaoStreamProgressCallback =
    void Function(DoubaoStreamProgress progress);
typedef DoubaoDebugLogger = void Function(String message);

class DoubaoPortraitResult {
  const DoubaoPortraitResult({
    required this.pngBytes,
    required this.width,
    required this.height,
    required this.finalPrompt,
    required this.requestId,
    required this.redactedRawResponse,
  });

  final Uint8List pngBytes;
  final int width;
  final int height;
  final String finalPrompt;
  final String? requestId;
  final String redactedRawResponse;
}

class DoubaoChapterArtResult {
  const DoubaoChapterArtResult({
    required this.imageBytes,
    required this.width,
    required this.height,
    required this.finalPrompt,
    required this.requestId,
    required this.redactedRawResponse,
  });

  final Uint8List imageBytes;
  final int width;
  final int height;
  final String finalPrompt;
  final String? requestId;
  final String redactedRawResponse;
}

class DoubaoClient {
  DoubaoClient({
    required this.settings,
    http.Client? httpClient,
    this.tokenizationTimeout = const Duration(seconds: 10),
    this.firstEventTimeout = const Duration(seconds: 120),
    this.streamIdleTimeout = const Duration(seconds: 60),
    this.streamAbsoluteTimeout = const Duration(minutes: 10),
    this.portraitGenerationTimeout = const Duration(seconds: 120),
    this.portraitDownloadTimeout = const Duration(seconds: 60),
    this.chapterArtGenerationTimeout = const Duration(seconds: 120),
    this.chapterArtDownloadTimeout = const Duration(seconds: 60),
    this.debugLogger,
    this.textLogLevel = LivingLogLevel.full,
    this.imageLogLevel = LivingLogLevel.full,
    this.enabledLogStages = const <String>{
      'opening',
      ...LivingCampaignSettings.defaultLogStages,
    },
    LivingSecretRedactor redactor = const LivingSecretRedactor(),
  }) : _http = httpClient ?? http.Client(),
       _redactor = redactor;

  final LivingCampaignSettings settings;
  final Duration tokenizationTimeout;
  final Duration firstEventTimeout;
  final Duration streamIdleTimeout;
  final Duration streamAbsoluteTimeout;
  final Duration portraitGenerationTimeout;
  final Duration portraitDownloadTimeout;
  final Duration chapterArtGenerationTimeout;
  final Duration chapterArtDownloadTimeout;
  final DoubaoDebugLogger? debugLogger;
  final LivingLogLevel textLogLevel;
  final LivingLogLevel imageLogLevel;
  final Set<String> enabledLogStages;
  final http.Client _http;
  final LivingSecretRedactor _redactor;
  int _debugRequestSerial = 0;
  final Map<int, String> _debugStageByRequest = <int, String>{};

  Future<void> testCapability() async {
    final response = await chatJson(
      systemPrompt:
          'Return only one JSON object with exactly this field: '
          '{"livingCampaignCapability":"ok"}.',
      userPayload: const <String, Object?>{'operation': 'capability_test'},
      maxTokens: 64,
      temperature: 0,
    );
    if (response.value['livingCampaignCapability'] != 'ok') {
      throw const LivingProviderException(
        code: 'capability_response_invalid',
        safeMessage: 'Ark responded, but the capability response was invalid.',
      );
    }
  }

  Future<DoubaoTokenizationResult> countTextTokens(
    Iterable<String> values,
  ) async {
    _ensureConfigured();
    final response = await _postJson(
      _endpoint('tokenization'),
      <String, Object?>{
        'model': settings.textModel,
        'text': values.toList(growable: false),
      },
      requestTimeout: tokenizationTimeout,
    );
    final decoded = _decodeObject(response.body);
    _throwForResponse(response, decoded);
    try {
      final data = decoded['data']! as List<Object?>;
      final total = data.fold<int>(0, (sum, raw) {
        final item = Map<String, Object?>.from(raw! as Map);
        return sum + (item['total_tokens']! as num).toInt();
      });
      return DoubaoTokenizationResult(
        totalTokens: total,
        requestId: decoded['id'] as String? ?? _requestId(response),
        model: decoded['model'] as String?,
      );
    } on Object {
      throw LivingProviderException(
        code: 'invalid_tokenization_response',
        safeMessage: 'Ark returned an unreadable tokenization response.',
        statusCode: response.statusCode,
        requestId: _requestId(response),
      );
    }
  }

  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    int maxTokens = 8192,
    double temperature = .25,
    Map<String, Object?>? jsonSchema,
    String jsonSchemaName = 'living_campaign_response',
    bool strictJsonSchema = true,
    bool disableThinking = false,
    DoubaoStreamProgressCallback? onProgress,
  }) async {
    _ensureConfigured();
    final debugRequestNumber = ++_debugRequestSerial;
    _debugStageByRequest[debugRequestNumber] = _debugStageForSchema(
      jsonSchemaName,
    );
    final requestBody = <String, Object?>{
      'model': settings.textModel,
      'messages': <Map<String, Object?>>[
        <String, Object?>{'role': 'system', 'content': systemPrompt},
        <String, Object?>{'role': 'user', 'content': jsonEncode(userPayload)},
      ],
      'stream': true,
      'stream_options': const <String, Object?>{'include_usage': true},
      'max_tokens': maxTokens,
      'temperature': temperature,
      if (disableThinking)
        'thinking': const <String, Object?>{'type': 'disabled'},
      if (jsonSchema != null)
        'response_format': <String, Object?>{
          'type': 'json_schema',
          'json_schema': <String, Object?>{
            'name': jsonSchemaName,
            'strict': strictJsonSchema,
            'schema': jsonSchema,
          },
        },
    };
    _debugLog(
      debugRequestNumber,
      'request',
      'model=${settings.textModel} max_tokens=$maxTokens '
          'temperature=$temperature stream=true '
          'thinking=${disableThinking ? 'disabled' : 'default'} '
          'response_format=${jsonSchema == null ? 'json_object' : 'json_schema'}\n'
          '--- SYSTEM PROMPT ---\n$systemPrompt\n'
          '--- USER PAYLOAD ---\n'
          '${const JsonEncoder.withIndent('  ').convert(userPayload)}\n'
          '--- END REQUEST ---',
    );
    return _postChatStream(
      _endpoint('chat/completions'),
      requestBody,
      onProgress: onProgress,
      debugRequestNumber: debugRequestNumber,
    );
  }

  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) async {
    _ensureConfigured();
    final finalPrompt = prompt.trim();
    if (finalPrompt.isEmpty) {
      throw const LivingProviderException(
        code: 'portrait_prompt_missing',
        safeMessage: 'The portrait appearance brief is empty.',
      );
    }
    final requestBody = <String, Object?>{
      'model': settings.imageModel,
      'prompt': finalPrompt,
      if (referenceImages.isNotEmpty)
        'image': referenceImages
            .map((bytes) => 'data:image/webp;base64,${base64Encode(bytes)}')
            .toList(growable: false),
      'size': '2K',
      'sequential_image_generation': 'disabled',
      'response_format': 'url',
      'watermark': false,
      'seed': ?seed,
    };
    final stopwatch = Stopwatch()..start();
    _imageDebugLog(
      stage: 'portrait',
      event: 'request',
      summary:
          'model=${settings.imageModel} seed=${seed ?? 'provider'} size=2K references=${referenceImages.length}',
      full: 'prompt=$finalPrompt',
    );
    final response = await _postJson(
      _endpoint('images/generations'),
      requestBody,
      requestTimeout: portraitGenerationTimeout,
      timeoutCode: 'portrait_generation_timeout',
      timeoutMessage:
          'Ark did not finish the portrait before the safety limit.',
    );
    final decoded = _decodeObject(response.body);
    _throwForResponse(response, decoded);
    try {
      final data = decoded['data']! as List<Object?>;
      final first = Map<String, Object?>.from(data.first! as Map);
      Uint8List bytes;
      if (first['b64_json'] case final String base64Value) {
        bytes = base64Decode(base64Value);
      } else if (first['url'] case final String url) {
        final http.Response download;
        try {
          final remaining = portraitGenerationTimeout - stopwatch.elapsed;
          if (remaining <= Duration.zero) {
            throw TimeoutException('portrait total budget exhausted');
          }
          final downloadBudget = remaining < portraitDownloadTimeout
              ? remaining
              : portraitDownloadTimeout;
          download = await _http.get(Uri.parse(url)).timeout(downloadBudget);
        } on TimeoutException {
          throw const LivingProviderException(
            code: 'portrait_download_timeout',
            safeMessage:
                'The generated portrait download did not finish in time.',
          );
        }
        if (download.statusCode < 200 || download.statusCode >= 300) {
          throw const LivingProviderException(
            code: 'portrait_download_failed',
            safeMessage: 'The generated portrait could not be downloaded.',
          );
        }
        bytes = download.bodyBytes;
      } else {
        throw const LivingProviderException(
          code: 'portrait_data_missing',
          safeMessage: 'Ark returned no portrait image data.',
        );
      }
      if (onSourceDownloaded != null) {
        await onSourceDownloaded(bytes);
      }
      final processed = LivingPortraitProcessor().process(bytes);
      _imageDebugLog(
        stage: 'portrait',
        event: 'completed',
        summary:
            'request_id=${decoded['id'] as String? ?? _requestId(response) ?? 'unknown'} duration_ms=${stopwatch.elapsedMilliseconds} width=${processed.width} height=${processed.height}',
      );
      return DoubaoPortraitResult(
        pngBytes: processed.bytes,
        width: processed.width,
        height: processed.height,
        finalPrompt: finalPrompt,
        requestId: decoded['id'] as String? ?? _requestId(response),
        redactedRawResponse: _redactor.redact(
          response.body,
          secrets: <String>[settings.apiKey],
        ),
      );
    } on LivingProviderException catch (error) {
      _imageDebugLog(
        stage: 'portrait',
        event: 'failed',
        summary:
            'code=${error.code} request_id=${error.requestId ?? 'unknown'} duration_ms=${stopwatch.elapsedMilliseconds}',
      );
      throw LivingProviderException(
        code: error.code,
        safeMessage: error.safeMessage,
        statusCode: error.statusCode ?? response.statusCode,
        requestId:
            error.requestId ?? decoded['id'] as String? ?? _requestId(response),
        providerMessage: error.providerMessage,
        redactedResponseBody:
            error.redactedResponseBody ??
            _redactor.redact(response.body, secrets: <String>[settings.apiKey]),
      );
    } on Object {
      _imageDebugLog(
        stage: 'portrait',
        event: 'failed',
        summary:
            'code=invalid_portrait_response duration_ms=${stopwatch.elapsedMilliseconds}',
      );
      throw LivingProviderException(
        code: 'invalid_portrait_response',
        safeMessage: 'Ark returned an unreadable portrait response.',
        statusCode: response.statusCode,
        requestId: _requestId(response),
      );
    }
  }

  Future<DoubaoChapterArtResult> generateChapterEndingArt({
    required String prompt,
    required int seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) async {
    _ensureConfigured();
    final finalPrompt = prompt.trim();
    if (finalPrompt.isEmpty) {
      throw const LivingProviderException(
        code: 'chapter_art_prompt_missing',
        safeMessage: 'The final scene has no painting brief.',
      );
    }
    final requestBody = <String, Object?>{
      'model': settings.imageModel,
      'prompt': finalPrompt,
      if (referenceImages.isNotEmpty)
        'image': referenceImages
            .map((bytes) => 'data:image/webp;base64,${base64Encode(bytes)}')
            .toList(growable: false),
      'size': '2560x1440',
      'sequential_image_generation': 'disabled',
      'response_format': 'url',
      'watermark': false,
      'seed': seed,
    };
    final stopwatch = Stopwatch()..start();
    _imageDebugLog(
      stage: 'chapter_art',
      event: 'request',
      summary:
          'model=${settings.imageModel} seed=$seed size=2560x1440 references=${referenceImages.length}',
      full: 'prompt=$finalPrompt',
    );
    final response = await _postJson(
      _endpoint('images/generations'),
      requestBody,
      requestTimeout: chapterArtGenerationTimeout,
      timeoutCode: 'chapter_art_generation_timeout',
      timeoutMessage:
          'The final scene did not finish before the lantern dimmed.',
    );
    final decoded = _decodeObject(response.body);
    _throwForResponse(response, decoded);
    try {
      final data = decoded['data']! as List<Object?>;
      final first = Map<String, Object?>.from(data.first! as Map);
      Uint8List bytes;
      if (first['b64_json'] case final String base64Value) {
        bytes = base64Decode(base64Value);
      } else if (first['url'] case final String url) {
        final http.Response download;
        try {
          final remaining = chapterArtGenerationTimeout - stopwatch.elapsed;
          if (remaining <= Duration.zero) {
            throw TimeoutException('chapter art total budget exhausted');
          }
          final downloadBudget = remaining < chapterArtDownloadTimeout
              ? remaining
              : chapterArtDownloadTimeout;
          download = await _http.get(Uri.parse(url)).timeout(downloadBudget);
        } on TimeoutException {
          throw const LivingProviderException(
            code: 'chapter_art_download_timeout',
            safeMessage:
                'The painted final scene could not be carried home in time.',
          );
        }
        if (download.statusCode < 200 || download.statusCode >= 300) {
          throw const LivingProviderException(
            code: 'chapter_art_download_failed',
            safeMessage: 'The painted final scene could not be recovered.',
          );
        }
        bytes = download.bodyBytes;
      } else {
        throw const LivingProviderException(
          code: 'chapter_art_data_missing',
          safeMessage: 'No final scene returned from the painter.',
        );
      }
      if (onSourceDownloaded != null) {
        await onSourceDownloaded(bytes);
      }
      final processed = LivingChapterSceneProcessor().process(bytes);
      _imageDebugLog(
        stage: 'chapter_art',
        event: 'completed',
        summary:
            'request_id=${decoded['id'] as String? ?? _requestId(response) ?? 'unknown'} duration_ms=${stopwatch.elapsedMilliseconds} width=${processed.width} height=${processed.height}',
      );
      return DoubaoChapterArtResult(
        imageBytes: processed.bytes,
        width: processed.width,
        height: processed.height,
        finalPrompt: finalPrompt,
        requestId: decoded['id'] as String? ?? _requestId(response),
        redactedRawResponse: _redactor.redact(
          response.body,
          secrets: <String>[settings.apiKey],
        ),
      );
    } on LivingProviderException catch (error) {
      _imageDebugLog(
        stage: 'chapter_art',
        event: 'failed',
        summary:
            'code=${error.code} request_id=${error.requestId ?? 'unknown'} duration_ms=${stopwatch.elapsedMilliseconds}',
      );
      throw LivingProviderException(
        code: error.code,
        safeMessage: error.safeMessage,
        statusCode: error.statusCode ?? response.statusCode,
        requestId:
            error.requestId ?? decoded['id'] as String? ?? _requestId(response),
        providerMessage: error.providerMessage,
        redactedResponseBody:
            error.redactedResponseBody ??
            _redactor.redact(response.body, secrets: <String>[settings.apiKey]),
      );
    } on Object {
      _imageDebugLog(
        stage: 'chapter_art',
        event: 'failed',
        summary:
            'code=invalid_chapter_art_response duration_ms=${stopwatch.elapsedMilliseconds}',
      );
      throw LivingProviderException(
        code: 'invalid_chapter_art_response',
        safeMessage: 'The final scene returned in an unreadable form.',
        statusCode: response.statusCode,
        requestId: decoded['id'] as String? ?? _requestId(response),
        redactedResponseBody: _redactor.redact(
          response.body,
          secrets: <String>[settings.apiKey],
        ),
      );
    }
  }

  void close() => _http.close();

  Future<http.Response> _postJson(
    Uri endpoint,
    Map<String, Object?> body, {
    required Duration requestTimeout,
    String timeoutCode = 'timeout',
    String timeoutMessage = 'Ark did not respond before the request timed out.',
  }) async {
    try {
      return await _http
          .post(
            endpoint,
            headers: <String, String>{
              'Authorization': 'Bearer ${settings.apiKey}',
              'Content-Type': 'application/json',
            },
            body: jsonEncode(body),
          )
          .timeout(requestTimeout);
    } on TimeoutException {
      throw LivingProviderException(
        code: timeoutCode,
        safeMessage: timeoutMessage,
      );
    } on LivingProviderException {
      rethrow;
    } on Object catch (error) {
      final description = error.toString().toLowerCase();
      final permissionDenied =
          description.contains('operation not permitted') ||
          description.contains('permission denied');
      throw LivingProviderException(
        code: permissionDenied ? 'network_permission_denied' : 'network_error',
        safeMessage: permissionDenied
            ? 'Ark network access was denied by the operating system. Check '
                  'the app network permission.'
            : 'Ark could not be reached. Check the network and API settings.',
      );
    }
  }

  Future<DoubaoJsonResponse> _postChatStream(
    Uri endpoint,
    Map<String, Object?> body, {
    DoubaoStreamProgressCallback? onProgress,
    required int debugRequestNumber,
  }) async {
    final request = http.Request('POST', endpoint)
      ..headers.addAll(<String, String>{
        'Authorization': 'Bearer ${settings.apiKey}',
        'Content-Type': 'application/json',
        'Accept': 'text/event-stream',
      })
      ..body = jsonEncode(body);
    final stopwatch = Stopwatch()..start();
    try {
      final response = await _http.send(request).timeout(firstEventTimeout);
      final headerRequestId = _requestIdFromHeaders(response.headers);
      _debugLog(
        debugRequestNumber,
        'connected',
        'status=${response.statusCode} request_id=${headerRequestId ?? 'pending'} '
            'content_type=${response.headers['content-type'] ?? 'unknown'}',
      );
      onProgress?.call(
        DoubaoStreamProgress(
          phase: DoubaoStreamPhase.connected,
          occurredAt: DateTime.now(),
          requestId: headerRequestId,
        ),
      );
      if (response.statusCode < 200 || response.statusCode >= 300) {
        final raw = await _readResponseBody(response);
        final decoded = _decodeObject(raw);
        _debugLog(
          debugRequestNumber,
          'provider-error',
          'status=${response.statusCode} '
              'body=${_redactor.redact(raw, secrets: <String>[settings.apiKey])}',
        );
        _throwForStatus(
          statusCode: response.statusCode,
          headers: response.headers,
          decoded: decoded,
          rawResponseBody: raw,
        );
      }

      final contentType = response.headers['content-type']?.toLowerCase() ?? '';
      if (!contentType.contains('text/event-stream')) {
        final raw = await _readResponseBody(response);
        return _parseBufferedChatResponse(
          raw,
          statusCode: response.statusCode,
          headers: response.headers,
          stopwatch: stopwatch,
          onProgress: onProgress,
          debugRequestNumber: debugRequestNumber,
        );
      }
      return await _consumeChatEventStream(
        response,
        stopwatch: stopwatch,
        headerRequestId: headerRequestId,
        onProgress: onProgress,
        debugRequestNumber: debugRequestNumber,
      );
    } on TimeoutException catch (_) {
      _debugLog(debugRequestNumber, 'timeout', 'first_event_timeout');
      throw const LivingProviderException(
        code: 'first_event_timeout',
        safeMessage:
            'Ark did not begin responding before the request timed out.',
      );
    } on LivingProviderException {
      rethrow;
    } on Object catch (error) {
      _debugLog(debugRequestNumber, 'network-error', error.toString());
      throw _networkException(error);
    }
  }

  Future<DoubaoJsonResponse> _consumeChatEventStream(
    http.StreamedResponse response, {
    required Stopwatch stopwatch,
    required String? headerRequestId,
    DoubaoStreamProgressCallback? onProgress,
    required int debugRequestNumber,
  }) async {
    try {
      return await _parseChatEventStream(
        _chatDeadlineEvents(_decodeSseEvents(response.stream), stopwatch),
        stopwatch: stopwatch,
        headerRequestId: headerRequestId,
        onProgress: onProgress,
        debugRequestNumber: debugRequestNumber,
      );
    } on _ChatStreamTimeout catch (error) {
      _debugLog(
        debugRequestNumber,
        'timeout',
        '${error.kind.name} after ${stopwatch.elapsedMilliseconds} ms',
      );
      throw LivingProviderException(
        code: switch (error.kind) {
          _ChatStreamTimeoutKind.firstEvent => 'first_event_timeout',
          _ChatStreamTimeoutKind.idle => 'stream_idle_timeout',
          _ChatStreamTimeoutKind.absolute => 'stream_absolute_timeout',
        },
        safeMessage: switch (error.kind) {
          _ChatStreamTimeoutKind.firstEvent =>
            'Ark did not begin responding before the request timed out.',
          _ChatStreamTimeoutKind.idle =>
            'Ark stopped sending story data before the response completed.',
          _ChatStreamTimeoutKind.absolute =>
            'Ark did not complete the story within the safety limit.',
        },
        requestId: headerRequestId,
      );
    }
  }

  Stream<_SseEvent> _chatDeadlineEvents(
    Stream<_SseEvent> source,
    Stopwatch stopwatch,
  ) async* {
    final iterator = StreamIterator<_SseEvent>(source);
    var sawProviderEvent = false;
    Future<bool>? pendingMoveNext;
    try {
      while (true) {
        final remaining = streamAbsoluteTimeout - stopwatch.elapsed;
        if (remaining <= Duration.zero) {
          throw const _ChatStreamTimeout(_ChatStreamTimeoutKind.absolute);
        }
        final activityLimit = sawProviderEvent
            ? streamIdleTimeout
            : firstEventTimeout - stopwatch.elapsed;
        if (activityLimit <= Duration.zero) {
          throw const _ChatStreamTimeout(_ChatStreamTimeoutKind.firstEvent);
        }
        final wait = remaining < activityLimit ? remaining : activityLimit;
        pendingMoveNext = iterator.moveNext();
        final hasNext = await pendingMoveNext.timeout(
          wait,
          onTimeout: () => throw _ChatStreamTimeout(
            remaining <= activityLimit
                ? _ChatStreamTimeoutKind.absolute
                : sawProviderEvent
                ? _ChatStreamTimeoutKind.idle
                : _ChatStreamTimeoutKind.firstEvent,
          ),
        );
        pendingMoveNext = null;
        if (!hasNext) return;
        sawProviderEvent = true;
        yield iterator.current;
      }
    } finally {
      // Some transformed HTTP streams wait for their source to close while a
      // cancellation is in flight. Do not let that delay the timeout result
      // that must immediately move the durable job to explicit recovery.
      final pending = pendingMoveNext;
      if (pending != null) {
        unawaited(
          pending.then<void>((_) {}, onError: (Object _, StackTrace _) {}),
        );
      }
      unawaited(
        iterator.cancel().then<void>(
          (_) {},
          onError: (Object _, StackTrace _) {},
        ),
      );
    }
  }

  Stream<_SseEvent> _decodeSseEvents(Stream<List<int>> source) async* {
    final dataLines = <String>[];
    final rawLines = <String>[];
    var hasField = false;

    _SseEvent? flush() {
      if (!hasField && rawLines.isEmpty) return null;
      final event = _SseEvent(
        data: dataLines.join('\n'),
        raw: rawLines.join('\n'),
      );
      dataLines.clear();
      rawLines.clear();
      hasField = false;
      return event;
    }

    await for (final line
        in source.transform(utf8.decoder).transform(const LineSplitter())) {
      if (line.isEmpty) {
        final event = flush();
        if (event != null) yield event;
        continue;
      }
      rawLines.add(line);
      if (line.startsWith(':')) {
        hasField = true;
        continue;
      }
      final separator = line.indexOf(':');
      final field = separator < 0 ? line : line.substring(0, separator);
      var value = separator < 0 ? '' : line.substring(separator + 1);
      if (value.startsWith(' ')) value = value.substring(1);
      hasField = true;
      if (field == 'data') dataLines.add(value);
    }
    final event = flush();
    if (event != null) yield event;
  }

  Future<DoubaoJsonResponse> _parseChatEventStream(
    Stream<_SseEvent> source, {
    required Stopwatch stopwatch,
    required String? headerRequestId,
    DoubaoStreamProgressCallback? onProgress,
    required int debugRequestNumber,
  }) async {
    final content = StringBuffer();
    final raw = StringBuffer();
    Map<String, Object?> usage = const <String, Object?>{};
    String? requestId = headerRequestId;
    String? model;
    String? finishReason;
    Duration? firstEventAt;
    var sawDone = false;
    final debugTrace =
        debugLogger == null ||
            textLogLevel != LivingLogLevel.full ||
            !enabledLogStages.contains(
              _debugStageByRequest[debugRequestNumber] ?? 'opening',
            )
        ? null
        : _DoubaoDebugStreamBuffer(
            emit: (event, message) =>
                _debugLog(debugRequestNumber, event, message),
          );
    try {
      await for (final event in source) {
        debugTrace?.recordProviderEvent();
        firstEventAt ??= stopwatch.elapsed;
        final data = event.data;
        if (event.raw.isNotEmpty) raw.writeln(event.raw);
        if (data.isEmpty) {
          debugTrace?.recordProtocolActivity(event.raw);
          onProgress?.call(
            DoubaoStreamProgress(
              phase: DoubaoStreamPhase.providerWorking,
              occurredAt: DateTime.now(),
              requestId: requestId,
              receivedContentCharacters: content.length,
            ),
          );
          continue;
        }
        if (data == '[DONE]') {
          debugTrace?.flush();
          _debugLog(debugRequestNumber, 'done', '[DONE]');
          sawDone = true;
          break;
        }
        final decoded = _decodeObject(data);
        if (decoded.isEmpty) continue;
        requestId = decoded['id'] as String? ?? requestId;
        model = decoded['model'] as String? ?? model;
        if (decoded['error'] is Map) {
          debugTrace?.flush();
          final providerError = Map<String, Object?>.from(
            decoded['error']! as Map,
          );
          final code = providerError['code']?.toString() ?? 'stream_error';
          _debugLog(debugRequestNumber, 'provider-error', code);
          final message =
              providerError['message']?.toString().toLowerCase() ?? '';
          final contextLimit =
              code.toLowerCase().contains('context') ||
              message.contains('context length') ||
              message.contains('maximum context') ||
              message.contains('too many tokens');
          throw LivingProviderException(
            code: contextLimit ? 'context_length_exceeded' : code,
            safeMessage: contextLimit
                ? 'The complete campaign context exceeds the current Ark model window.'
                : 'Ark reported a streaming generation error ($code).',
            requestId: requestId ?? providerError['request_id']?.toString(),
          );
        }
        if (decoded['usage'] is Map) {
          debugTrace?.flush();
          usage = Map<String, Object?>.from(decoded['usage']! as Map);
          _debugLog(debugRequestNumber, 'usage', jsonEncode(usage));
        }
        final reasoningDelta = StringBuffer();
        final contentDelta = StringBuffer();
        String? eventFinishReason;
        final choices =
            decoded['choices'] as List<Object?>? ?? const <Object?>[];
        for (final rawChoice in choices) {
          if (rawChoice is! Map) continue;
          final choice = Map<String, Object?>.from(rawChoice);
          finishReason = choice['finish_reason'] as String? ?? finishReason;
          if (choice['finish_reason'] case final String reason) {
            eventFinishReason = reason;
          }
          final delta = choice['delta'] is Map
              ? Map<String, Object?>.from(choice['delta']! as Map)
              : const <String, Object?>{};
          final reasoningPiece = delta['reasoning_content'];
          if (reasoningPiece is String && reasoningPiece.isNotEmpty) {
            reasoningDelta.write(reasoningPiece);
            debugTrace?.add('reasoning', reasoningPiece);
          }
          final piece = delta['content'];
          if (piece is String && piece.isNotEmpty) {
            content.write(piece);
            contentDelta.write(piece);
            debugTrace?.add('content', piece);
          }
        }
        if (eventFinishReason != null) {
          debugTrace?.flush();
          _debugLog(debugRequestNumber, 'finish', eventFinishReason);
        }
        onProgress?.call(
          DoubaoStreamProgress(
            phase: contentDelta.isNotEmpty
                ? DoubaoStreamPhase.receiving
                : DoubaoStreamPhase.providerWorking,
            occurredAt: DateTime.now(),
            requestId: requestId,
            receivedContentCharacters: content.length,
            reasoningDelta: reasoningDelta.toString(),
            contentDelta: contentDelta.toString(),
          ),
        );
      }
    } on _ChatStreamTimeout {
      rethrow;
    } on LivingProviderException {
      rethrow;
    } on Object catch (error) {
      throw _networkException(error, requestId: requestId);
    } finally {
      debugTrace?.flush();
      if (debugTrace != null) {
        _debugLog(debugRequestNumber, 'stream-summary', debugTrace.summary);
      }
    }
    if (!sawDone) {
      _debugLog(debugRequestNumber, 'incomplete', 'missing [DONE]');
      throw LivingProviderException(
        code: 'stream_incomplete',
        safeMessage: 'Ark ended the story stream before it completed.',
        requestId: requestId,
      );
    }
    if (content.isEmpty) {
      _debugLog(debugRequestNumber, 'invalid', 'completed with empty content');
      throw LivingProviderException(
        code: 'invalid_chat_response',
        safeMessage: 'Ark completed without returning story text.',
        requestId: requestId,
      );
    }
    onProgress?.call(
      DoubaoStreamProgress(
        phase: DoubaoStreamPhase.completed,
        occurredAt: DateTime.now(),
        requestId: requestId,
        receivedContentCharacters: content.length,
      ),
    );
    _debugLog(
      debugRequestNumber,
      'completed',
      'content_characters=${content.length} '
          'duration_ms=${stopwatch.elapsedMilliseconds}',
    );
    return DoubaoJsonResponse(
      value: _extractCompletedChatValue(content.toString()),
      requestId: requestId,
      model: model,
      usage: usage,
      redactedRawResponse: _redactor.redact(
        raw.toString(),
        secrets: <String>[settings.apiKey],
      ),
      rawContent: _redactor.redact(
        content.toString(),
        secrets: <String>[settings.apiKey],
      ),
      timeToFirstEvent: firstEventAt,
      duration: stopwatch.elapsed,
      finishReason: finishReason,
    );
  }

  Future<String> _readResponseBody(http.StreamedResponse response) async {
    final bytes = await response.stream.toBytes().timeout(firstEventTimeout);
    return utf8.decode(bytes);
  }

  DoubaoJsonResponse _parseBufferedChatResponse(
    String raw, {
    required int statusCode,
    required Map<String, String> headers,
    required Stopwatch stopwatch,
    DoubaoStreamProgressCallback? onProgress,
    required int debugRequestNumber,
  }) {
    final decoded = _decodeObject(raw);
    _throwForStatus(statusCode: statusCode, headers: headers, decoded: decoded);
    try {
      final choices = decoded['choices']! as List<Object?>;
      final choice = Map<String, Object?>.from(choices.first! as Map);
      final message = Map<String, Object?>.from(choice['message']! as Map);
      final content = message['content']! as String;
      final requestId =
          decoded['id'] as String? ?? _requestIdFromHeaders(headers);
      onProgress?.call(
        DoubaoStreamProgress(
          phase: DoubaoStreamPhase.completed,
          occurredAt: DateTime.now(),
          requestId: requestId,
          receivedContentCharacters: content.length,
        ),
      );
      _debugLog(
        debugRequestNumber,
        'completed-buffered',
        'content_characters=${content.length} '
            'duration_ms=${stopwatch.elapsedMilliseconds}',
      );
      return DoubaoJsonResponse(
        value: _extractCompletedChatValue(content),
        requestId: requestId,
        model: decoded['model'] as String?,
        usage: decoded['usage'] == null
            ? const <String, Object?>{}
            : Map<String, Object?>.from(decoded['usage']! as Map),
        redactedRawResponse: _redactor.redact(
          raw,
          secrets: <String>[settings.apiKey],
        ),
        rawContent: _redactor.redact(
          content,
          secrets: <String>[settings.apiKey],
        ),
        transport: 'buffered',
        timeToFirstEvent: stopwatch.elapsed,
        duration: stopwatch.elapsed,
        finishReason: choice['finish_reason'] as String?,
      );
    } on LivingProviderException {
      rethrow;
    } on Object {
      throw LivingProviderException(
        code: 'invalid_chat_response',
        safeMessage: 'Ark returned an unreadable text response.',
        statusCode: statusCode,
        requestId: _requestIdFromHeaders(headers),
      );
    }
  }

  LivingProviderException _networkException(Object error, {String? requestId}) {
    final description = error.toString().toLowerCase();
    final permissionDenied =
        description.contains('operation not permitted') ||
        description.contains('permission denied');
    return LivingProviderException(
      code: permissionDenied ? 'network_permission_denied' : 'network_error',
      safeMessage: permissionDenied
          ? 'Ark network access was denied by the operating system. Check '
                'the app network permission.'
          : 'Ark could not be reached. Check the network and API settings.',
      requestId: requestId,
    );
  }

  void _debugLog(int requestNumber, String event, [String message = '']) {
    final logger = debugLogger;
    if (logger == null) return;
    final stage = _debugStageByRequest[requestNumber] ?? 'opening';
    if (textLogLevel == LivingLogLevel.off ||
        !enabledLogStages.contains(stage)) {
      return;
    }
    if (textLogLevel == LivingLogLevel.summary &&
        !_summaryTextEvents.contains(event)) {
      return;
    }
    final visibleMessage = textLogLevel == LivingLogLevel.summary
        ? message.split('\n').first
        : message;
    final safe = _redactor.redact(
      visibleMessage,
      secrets: <String>[settings.apiKey],
    );
    final renderedMessage = textLogLevel == LivingLogLevel.summary
        ? 'stage=$stage${safe.isEmpty ? '' : ' $safe'}'
        : safe;
    logger(
      renderedMessage.isEmpty
          ? '[LivingAI][$requestNumber][$event]'
          : '[LivingAI][$requestNumber][$event] $renderedMessage',
    );
  }

  void _imageDebugLog({
    required String stage,
    required String event,
    required String summary,
    String? full,
  }) {
    final logger = debugLogger;
    if (logger == null ||
        imageLogLevel == LivingLogLevel.off ||
        !enabledLogStages.contains(stage)) {
      return;
    }
    final message = imageLogLevel == LivingLogLevel.full && full != null
        ? '$summary\n$full'
        : summary;
    logger(
      '[LivingImage][$stage][$event] '
      '${_redactor.redact(message, secrets: <String>[settings.apiKey])}',
    );
  }

  String _debugStageForSchema(String schemaName) {
    final lower = schemaName.toLowerCase();
    if (lower.contains('chronicler')) return 'chronicler';
    if (lower.contains('director')) return 'director';
    if (lower.contains('builder')) return 'builder';
    if (lower.contains('history')) return 'history';
    return 'opening';
  }

  static const _summaryTextEvents = <String>{
    'request',
    'usage',
    'finish',
    'completed',
    'completed-buffered',
    'stream-summary',
    'timeout',
    'network-error',
    'provider-error',
    'incomplete',
    'invalid',
  };

  void _throwForResponse(http.Response response, Map<String, Object?> decoded) {
    _throwForStatus(
      statusCode: response.statusCode,
      headers: response.headers,
      decoded: decoded,
    );
  }

  void _throwForStatus({
    required int statusCode,
    required Map<String, String> headers,
    required Map<String, Object?> decoded,
    String? rawResponseBody,
  }) {
    if (statusCode >= 200 && statusCode < 300) {
      return;
    }
    final error = decoded['error'] is Map
        ? Map<String, Object?>.from(decoded['error']! as Map)
        : const <String, Object?>{};
    final providerCode = error['code']?.toString() ?? 'http_error';
    final rawProviderMessage = error['message']?.toString() ?? '';
    final providerMessage = rawProviderMessage.toLowerCase();
    final contextLimit =
        providerCode.toLowerCase().contains('context') ||
        providerMessage.contains('context length') ||
        providerMessage.contains('maximum context') ||
        providerMessage.contains('too many tokens');
    final requestId =
        _requestIdFromHeaders(headers) ?? error['request_id']?.toString();
    final modelUnavailable = providerCode == 'InvalidEndpointOrModel.NotFound';
    final message = contextLimit
        ? 'The complete campaign context exceeds the current Ark model window.'
        : modelUnavailable
        ? 'Ark authenticated the key, but this model is not enabled for the '
              'account or its Model ID is unavailable.'
        : switch (statusCode) {
            401 || 403 => 'Ark rejected the API key or model permission.',
            429 => 'Ark is rate-limited or the account quota is exhausted.',
            >= 500 => 'Ark is temporarily unavailable.',
            _ => 'Ark rejected the generation request ($providerCode).',
          };
    throw LivingProviderException(
      code: contextLimit ? 'context_length_exceeded' : providerCode,
      safeMessage: message,
      statusCode: statusCode,
      requestId: requestId,
      providerMessage: _redactor.redact(
        rawProviderMessage,
        secrets: <String>[settings.apiKey],
      ),
      redactedResponseBody: rawResponseBody == null
          ? null
          : _redactor.redact(
              rawResponseBody,
              secrets: <String>[settings.apiKey],
            ),
    );
  }

  Map<String, Object?> _decodeObject(String raw) {
    try {
      return Map<String, Object?>.from(jsonDecode(raw) as Map);
    } on Object {
      return const <String, Object?>{};
    }
  }

  Map<String, Object?> _extractJsonObject(String content) {
    var candidate = content.trim();
    if (candidate.startsWith('```')) {
      candidate = candidate.replaceFirst(RegExp(r'^```(?:json)?\s*'), '');
      candidate = candidate.replaceFirst(RegExp(r'\s*```$'), '');
    }
    final first = candidate.indexOf('{');
    final last = candidate.lastIndexOf('}');
    if (first < 0 || last <= first) {
      throw const LivingProviderException(
        code: 'json_missing',
        safeMessage: 'Ark returned prose instead of the required JSON object.',
      );
    }
    try {
      return Map<String, Object?>.from(
        jsonDecode(candidate.substring(first, last + 1)) as Map,
      );
    } on Object {
      throw const LivingProviderException(
        code: 'json_invalid',
        safeMessage: 'Ark returned malformed JSON.',
      );
    }
  }

  Map<String, Object?> _extractCompletedChatValue(String content) {
    try {
      return _extractJsonObject(content);
    } on LivingProviderException catch (error) {
      if (error.code != 'json_missing' && error.code != 'json_invalid') {
        rethrow;
      }
      return <String, Object?>{'_invalidRawContent': content};
    }
  }

  Uri _endpoint(String path) =>
      Uri.parse('${settings.normalized().baseUrl}/$path');

  String? _requestId(http.Response response) =>
      _requestIdFromHeaders(response.headers);

  String? _requestIdFromHeaders(Map<String, String> headers) =>
      headers['x-request-id'] ?? headers['x-tt-logid'];

  void _ensureConfigured() {
    if (!settings.normalized().hasApiKey) {
      throw const LivingProviderException(
        code: 'api_key_missing',
        safeMessage: 'Add an Ark API key in Settings before generating.',
      );
    }
    final base = Uri.tryParse(settings.normalized().baseUrl);
    if (base == null || base.scheme != 'https' || base.host.isEmpty) {
      throw const LivingProviderException(
        code: 'base_url_invalid',
        safeMessage: 'The Ark base URL must be a valid HTTPS address.',
      );
    }
  }
}

class _DoubaoDebugStreamBuffer {
  _DoubaoDebugStreamBuffer({required this.emit});

  static const int _maxBlockCharacters = 800;

  final void Function(String event, String message) emit;
  final StringBuffer _buffer = StringBuffer();

  String? _activeEvent;
  int _providerEvents = 0;
  int _protocolEvents = 0;
  int _reasoningCharacters = 0;
  int _contentCharacters = 0;
  int _emittedBlocks = 0;

  String get summary =>
      'provider_events=$_providerEvents protocol_events=$_protocolEvents '
      'reasoning_characters=$_reasoningCharacters '
      'content_characters=$_contentCharacters blocks=$_emittedBlocks';

  void recordProviderEvent() => _providerEvents++;

  void recordProtocolActivity(String raw) {
    _protocolEvents++;
    if (_protocolEvents == 1) {
      emit(
        'activity',
        '${raw.trim()} (further protocol-only activity is summarized)',
      );
    }
  }

  void add(String event, String delta) {
    if (delta.isEmpty) return;
    if (_activeEvent != null && _activeEvent != event) {
      flush();
    }
    _activeEvent = event;
    _buffer.write(delta);
    if (event == 'reasoning') {
      _reasoningCharacters += delta.length;
    } else if (event == 'content') {
      _contentCharacters += delta.length;
    }
    _flushReadyBlocks();
  }

  void flush() {
    if (_buffer.isEmpty || _activeEvent == null) return;
    _emitPrefix(_buffer.length);
    _activeEvent = null;
  }

  void _flushReadyBlocks() {
    while (_buffer.length >= _maxBlockCharacters || _hasParagraph()) {
      final text = _buffer.toString();
      final paragraphEnd = text.indexOf('\n\n');
      if (paragraphEnd > 0 && paragraphEnd + 2 <= _maxBlockCharacters) {
        _emitPrefix(paragraphEnd + 2);
        continue;
      }
      if (text.length < _maxBlockCharacters) return;
      _emitPrefix(_preferredSplit(text));
    }
  }

  bool _hasParagraph() => _buffer.toString().indexOf('\n\n') > 0;

  int _preferredSplit(String text) {
    for (
      var index = _maxBlockCharacters - 1;
      index >= _maxBlockCharacters ~/ 2;
      index--
    ) {
      final codeUnit = text.codeUnitAt(index);
      if (codeUnit == 0x20 ||
          codeUnit == 0x09 ||
          codeUnit == 0x0a ||
          codeUnit == 0x0d) {
        return index + 1;
      }
    }
    var split = _maxBlockCharacters;
    if (split < text.length &&
        _isHighSurrogate(text.codeUnitAt(split - 1)) &&
        _isLowSurrogate(text.codeUnitAt(split))) {
      split--;
    }
    return split;
  }

  bool _isHighSurrogate(int codeUnit) =>
      codeUnit >= 0xd800 && codeUnit <= 0xdbff;

  bool _isLowSurrogate(int codeUnit) =>
      codeUnit >= 0xdc00 && codeUnit <= 0xdfff;

  void _emitPrefix(int characterCount) {
    final text = _buffer.toString();
    final prefix = text.substring(0, characterCount);
    final remainder = text.substring(characterCount);
    emit(_activeEvent!, prefix);
    _emittedBlocks++;
    _buffer.clear();
    _buffer.write(remainder);
  }
}

enum _ChatStreamTimeoutKind { firstEvent, idle, absolute }

class _ChatStreamTimeout implements Exception {
  const _ChatStreamTimeout(this.kind);

  final _ChatStreamTimeoutKind kind;
}

class _SseEvent {
  const _SseEvent({required this.data, required this.raw});

  final String data;
  final String raw;
}

class LivingPortraitProcessResult {
  const LivingPortraitProcessResult({
    required this.bytes,
    required this.width,
    required this.height,
  });

  final Uint8List bytes;
  final int width;
  final int height;
}

class LivingPortraitProcessor {
  LivingPortraitProcessResult process(Uint8List source) {
    final decoded = img.decodeImage(source);
    if (decoded == null || decoded.width < 512 || decoded.height < 512) {
      throw const LivingProviderException(
        code: 'portrait_decode_failed',
        safeMessage: 'The generated portrait image is invalid or too small.',
      );
    }
    final image = decoded.numChannels == 4
        ? decoded
        : decoded.convert(numChannels: 4);
    var transparent = _transparentPixels(image);
    if (transparent < image.width * image.height * .02) {
      _removeFlatEdgeBackground(image);
      transparent = _transparentPixels(image);
    }
    final total = image.width * image.height;
    if (transparent < total * .05) {
      throw const LivingProviderException(
        code: 'portrait_alpha_missing',
        safeMessage:
            'The generated portrait has no usable transparent background.',
      );
    }
    final bounds = _subjectBounds(image);
    if (bounds == null ||
        bounds.width < image.width * .08 ||
        bounds.height < image.height * .20) {
      throw const LivingProviderException(
        code: 'portrait_composition_invalid',
        safeMessage: 'The generated portrait has no usable character subject.',
      );
    }
    final normalized = _normalizeSubject(image, bounds);
    return LivingPortraitProcessResult(
      bytes: Uint8List.fromList(img.encodePng(normalized)),
      width: normalized.width,
      height: normalized.height,
    );
  }

  img.Image _normalizeSubject(img.Image image, _PortraitBounds bounds) {
    final paddingX = (bounds.width * .14).round();
    final paddingTop = (bounds.height * .10).round();
    final paddingBottom = (bounds.height * .04).round();
    final left = (bounds.minX - paddingX).clamp(0, image.width - 1);
    final top = (bounds.minY - paddingTop).clamp(0, image.height - 1);
    final right = (bounds.maxX + paddingX).clamp(0, image.width - 1);
    final bottom = (bounds.maxY + paddingBottom).clamp(0, image.height - 1);
    final cropped = img.copyCrop(
      image,
      x: left,
      y: top,
      width: right - left + 1,
      height: bottom - top + 1,
    );
    final widthScale = 900 / cropped.width;
    final heightScale = 960 / cropped.height;
    final scale = widthScale < heightScale ? widthScale : heightScale;
    final resized = img.copyResize(
      cropped,
      width: (cropped.width * scale).round().clamp(1, 900),
      height: (cropped.height * scale).round().clamp(1, 960),
      interpolation: img.Interpolation.cubic,
    );
    final canvas = img.Image(width: 1024, height: 1024, numChannels: 4);
    img.compositeImage(
      canvas,
      resized,
      dstX: (canvas.width - resized.width) ~/ 2,
      dstY: canvas.height - resized.height,
    );
    return canvas;
  }

  int _transparentPixels(img.Image image) {
    var count = 0;
    for (final pixel in image) {
      if (pixel.a < 32) {
        count++;
      }
    }
    return count;
  }

  void _removeFlatEdgeBackground(img.Image image) {
    final edgeSamples = <img.Pixel>[];
    for (var x = 0; x < image.width; x++) {
      edgeSamples.add(image.getPixel(x, 0));
      edgeSamples.add(image.getPixel(x, image.height - 1));
    }
    for (var y = 1; y < image.height - 1; y++) {
      edgeSamples.add(image.getPixel(0, y));
      edgeSamples.add(image.getPixel(image.width - 1, y));
    }
    final buckets = <int, List<img.Pixel>>{};
    for (final pixel in edgeSamples) {
      final key =
          ((pixel.r.toInt() ~/ 32) << 6) |
          ((pixel.g.toInt() ~/ 32) << 3) |
          (pixel.b.toInt() ~/ 32);
      buckets.putIfAbsent(key, () => <img.Pixel>[]).add(pixel);
    }
    final samples = buckets.values.reduce(
      (largest, candidate) =>
          candidate.length > largest.length ? candidate : largest,
    );
    if (samples.length < edgeSamples.length * .12) {
      return;
    }
    final sampleCount = samples.length;
    final red =
        samples.fold<double>(0, (sum, pixel) => sum + pixel.r) / sampleCount;
    final green =
        samples.fold<double>(0, (sum, pixel) => sum + pixel.g) / sampleCount;
    final blue =
        samples.fold<double>(0, (sum, pixel) => sum + pixel.b) / sampleCount;
    final seen = Uint8List(image.width * image.height);
    final queue = <int>[];
    for (var x = 0; x < image.width; x++) {
      queue.add(x);
      queue.add((image.height - 1) * image.width + x);
    }
    for (var y = 1; y < image.height - 1; y++) {
      queue.add(y * image.width);
      queue.add(y * image.width + image.width - 1);
    }
    var cursor = 0;
    while (cursor < queue.length) {
      final index = queue[cursor++];
      if (seen[index] != 0) {
        continue;
      }
      seen[index] = 1;
      final x = index % image.width;
      final y = index ~/ image.width;
      final pixel = image.getPixel(x, y);
      final distance =
          (pixel.r - red).abs() +
          (pixel.g - green).abs() +
          (pixel.b - blue).abs();
      if (distance > 150) {
        continue;
      }
      pixel.a = distance <= 72
          ? 0
          : ((distance - 72) * 255 / 78).round().clamp(0, 255);
      if (x > 0) queue.add(index - 1);
      if (x + 1 < image.width) queue.add(index + 1);
      if (y > 0) queue.add(index - image.width);
      if (y + 1 < image.height) queue.add(index + image.width);
    }
    if (green > red * 1.25 && green > blue * 1.25 && green > 130) {
      _removeGreenKeyIslandsAndSpill(image, red: red, green: green, blue: blue);
    } else if (red > green * 1.25 &&
        blue > green * 1.25 &&
        red > 130 &&
        blue > 130) {
      _removeMagentaKeyIslandsAndSpill(
        image,
        red: red,
        green: green,
        blue: blue,
      );
    }
  }

  void _removeGreenKeyIslandsAndSpill(
    img.Image image, {
    required double red,
    required double green,
    required double blue,
  }) {
    for (final pixel in image) {
      final strongGreen = pixel.g > pixel.r * 1.12 && pixel.g > pixel.b * 1.12;
      if (!strongGreen) {
        continue;
      }
      final distance =
          (pixel.r - red).abs() +
          (pixel.g - green).abs() +
          (pixel.b - blue).abs();
      if (distance <= 180) {
        final keyedAlpha = distance <= 72
            ? 0
            : ((distance - 72) * 255 / 108).round().clamp(0, 255);
        if (pixel.a > keyedAlpha) {
          pixel.a = keyedAlpha;
        }
      }
      if (pixel.a > 0) {
        final neutralGreen = (pixel.r > pixel.b ? pixel.r : pixel.b) + 8;
        if (pixel.g > neutralGreen) {
          pixel.g = neutralGreen;
        }
      }
    }
  }

  void _removeMagentaKeyIslandsAndSpill(
    img.Image image, {
    required double red,
    required double green,
    required double blue,
  }) {
    for (final pixel in image) {
      final strongMagenta =
          pixel.r > pixel.g * 1.2 &&
          pixel.b > pixel.g * 1.2 &&
          (pixel.r - pixel.b).abs() < 96;
      if (!strongMagenta) {
        continue;
      }
      final distance =
          (pixel.r - red).abs() +
          (pixel.g - green).abs() +
          (pixel.b - blue).abs();
      if (distance <= 180) {
        final keyedAlpha = distance <= 72
            ? 0
            : ((distance - 72) * 255 / 108).round().clamp(0, 255);
        if (pixel.a > keyedAlpha) {
          pixel.a = keyedAlpha;
        }
      }
      if (pixel.a > 0) {
        final neutral = (pixel.g + 10).clamp(0, 255);
        if (pixel.r > neutral) pixel.r = neutral;
        if (pixel.b > neutral) pixel.b = neutral;
      }
    }
  }

  _PortraitBounds? _subjectBounds(img.Image image) {
    var minX = image.width;
    var minY = image.height;
    var maxX = -1;
    var maxY = -1;
    for (final pixel in image) {
      if (pixel.a < 32) {
        continue;
      }
      minX = pixel.x < minX ? pixel.x : minX;
      minY = pixel.y < minY ? pixel.y : minY;
      maxX = pixel.x > maxX ? pixel.x : maxX;
      maxY = pixel.y > maxY ? pixel.y : maxY;
    }
    return maxX < minX
        ? null
        : _PortraitBounds(minX: minX, minY: minY, maxX: maxX, maxY: maxY);
  }
}

class LivingChapterSceneProcessor {
  LivingPortraitProcessResult process(Uint8List source) {
    final decoded = img.decodeImage(source);
    if (decoded == null || decoded.width < 512 || decoded.height < 288) {
      throw const LivingProviderException(
        code: 'chapter_art_decode_failed',
        safeMessage: 'The final scene image is invalid or too small.',
      );
    }
    const targetRatio = 16 / 9;
    final sourceRatio = decoded.width / decoded.height;
    late final img.Image cropped;
    if (sourceRatio > targetRatio) {
      final cropWidth = (decoded.height * targetRatio).round();
      cropped = img.copyCrop(
        decoded,
        x: (decoded.width - cropWidth) ~/ 2,
        y: 0,
        width: cropWidth,
        height: decoded.height,
      );
    } else {
      final cropHeight = (decoded.width / targetRatio).round();
      cropped = img.copyCrop(
        decoded,
        x: 0,
        y: (decoded.height - cropHeight) ~/ 2,
        width: decoded.width,
        height: cropHeight,
      );
    }
    final normalized = img.copyResize(
      cropped,
      width: 2560,
      height: 1440,
      interpolation: img.Interpolation.cubic,
    );
    return LivingPortraitProcessResult(
      bytes: Uint8List.fromList(img.encodePng(normalized, level: 6)),
      width: normalized.width,
      height: normalized.height,
    );
  }
}

class _PortraitBounds {
  const _PortraitBounds({
    required this.minX,
    required this.minY,
    required this.maxX,
    required this.maxY,
  });

  final int minX;
  final int minY;
  final int maxX;
  final int maxY;

  int get width => maxX - minX + 1;
  int get height => maxY - minY + 1;
}
