import 'living_campaign_archive_store.dart';
import 'living_campaign_archive_store_web.dart';

LivingCampaignArchiveStore createPlatformLivingCampaignArchiveStore() =>
    WebLivingCampaignArchiveStore();
