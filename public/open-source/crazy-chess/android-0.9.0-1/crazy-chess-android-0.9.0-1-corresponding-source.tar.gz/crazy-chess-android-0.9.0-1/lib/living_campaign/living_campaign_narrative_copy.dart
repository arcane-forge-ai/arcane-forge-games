import 'dart:convert';

import 'package:crypto/crypto.dart';

import 'living_campaign_models.dart';

/// Stable, story-world language for Living Campaign progress.
///
/// Transport and validation details intentionally stay out of this resolver;
/// diagnostics may expose those separately.
class LivingCampaignNarrativeCopy {
  const LivingCampaignNarrativeCopy._();

  static const opening = <String>[
    'The first page is opening.',
    'The chronicle stirs once more.',
    'A new tale gathers in the ashes.',
  ];
  static const chronicler = <String>[
    'The battle passes into legend.',
    'The field is being remembered.',
    'The last clash enters the chronicle.',
  ];
  static const director = <String>[
    'Fate traces the road ahead.',
    'The next trial gathers beyond the horizon.',
    'A new turning of the tale approaches.',
  ];
  static const builder = <String>[
    'A new battlefield takes shape.',
    'The next field of war is being laid.',
    'Pieces gather beyond the veil.',
  ];
  static const repair = <String>[
    'A broken passage is being restored.',
    'The scribes are mending the tale.',
    'Loose threads are being woven anew.',
  ];
  static const portrait = <String>[
    'A new face emerges.',
    'A stranger’s likeness takes form.',
    'The chronicle is meeting someone new.',
  ];
  static const endingArt = <String>[
    'The last echoes drift across the battlefield.',
    'What happened here is passing into legend.',
    'The road waits beyond the fallen banners.',
  ];
  static const chapterClosure = <String>[
    'The field grows still beneath the ash.',
    'The survivors gather where the banners fell.',
    'Before the road continues, the living count the cost.',
    'The last echoes drift across the battlefield.',
    'What happened here is passing into legend.',
    'The road waits beyond the fallen banners.',
  ];
  static const ready = <String>[
    'The road ahead is open.',
    'The next chapter awaits.',
    'A new trial is ready.',
  ];
  static const interrupted = <String>[
    'The quill has fallen still.',
    'The road ahead has gone quiet.',
    'The telling has been interrupted.',
  ];
  static const failed = <String>[
    'The next page remains unwritten.',
    'Fate has lost the thread.',
    'The chronicle could not continue.',
  ];
  static const resultExplanations = <String>[
    'Those who vanished may yet return.',
    'Only the truly fallen are beyond the reach of the tale.',
    'Every victory and loss leaves its mark on the road ahead.',
  ];

  static String forJob({
    required LivingCampaignRun run,
    required LivingGenerationStage stage,
    required int attempt,
  }) {
    final variants = switch (stage) {
      LivingGenerationStage.prologue => opening,
      LivingGenerationStage.chronicler => chronicler,
      LivingGenerationStage.director ||
      LivingGenerationStage.compaction => director,
      LivingGenerationStage.builder => builder,
      LivingGenerationStage.prologueRepair ||
      LivingGenerationStage.chroniclerRepair ||
      LivingGenerationStage.directorRepair ||
      LivingGenerationStage.builderRepair ||
      LivingGenerationStage.compactionRepair => repair,
      LivingGenerationStage.portrait => portrait,
      LivingGenerationStage.chapterArt => endingArt,
    };
    return choose(
      variants,
      runId: run.runId,
      jobId: run.generationJob?.jobId ?? 'no-job',
      stage: stage.name,
      attempt: attempt,
    );
  }

  static String forTerminal({
    required LivingCampaignRun run,
    required String state,
  }) {
    final variants = switch (state) {
      'ready' => ready,
      'interrupted' => interrupted,
      'failed' => failed,
      _ => ready,
    };
    return choose(
      variants,
      runId: run.runId,
      jobId: run.generationJob?.jobId ?? 'no-job',
      stage: state,
      attempt: run.generationJob?.attempt ?? 1,
    );
  }

  static String resultExplanation({
    required String runId,
    required int chapterNumber,
  }) => choose(
    resultExplanations,
    runId: runId,
    jobId: 'chapter-$chapterNumber',
    stage: 'result',
    attempt: 1,
  );

  static String choose(
    List<String> variants, {
    required String runId,
    required String jobId,
    required String stage,
    required int attempt,
  }) {
    final digest = sha256.convert(
      utf8.encode('$runId|$jobId|$stage|$attempt|narrative-copy'),
    );
    return variants[digest.bytes.first % variants.length];
  }
}
