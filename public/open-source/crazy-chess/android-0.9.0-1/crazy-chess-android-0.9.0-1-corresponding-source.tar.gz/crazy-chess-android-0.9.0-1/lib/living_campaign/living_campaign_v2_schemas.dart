abstract final class LivingCampaignV2Schemas {
  static const chroniclerName = 'living_campaign_chronicler_aftermath_v3';
  static const directorName = 'living_campaign_director_v2';
  static const builderName = 'living_campaign_builder_v2';
  static const historyDigestName = 'living_campaign_history_digest_v2';

  static Map<String, Object?> get chronicler => _object(
    properties: <String, Object?>{
      'schemaVersion': _integer(const <int>[3]),
      'runId': _string(),
      'missionNumber': _integer(null),
      'missionId': _string(),
      'setupSummary': _string(),
      'battleSummary': _string(),
      'characterIds': _array(_string()),
      'keyEventIds': _array(_string()),
      'identityAssignments': _array(
        _object(
          properties: <String, Object?>{
            'characterId': _string(),
            'name': _string(),
            'description': _string(),
            'portraitAppearanceBrief': _string(),
          },
        ),
      ),
      'aftermath': _array(
        _object(
          properties: <String, Object?>{
            'lineId': _string(),
            'speakerId': _nullableString(),
            'side': _enum(const <String>['left', 'right', 'center']),
            'text': _string(),
          },
        ),
      ),
    },
  );

  static Map<String, Object?> get director => _object(
    properties: <String, Object?>{
      'schemaVersion': _integer(const <int>[2]),
      'runId': _string(),
      'basedOnMissionNumber': _integer(null),
      'nextMissionNumber': _integer(null),
      'title': _string(),
      'subtitle': _string(),
      'background': _string(),
      'dialogue': _array(
        _object(
          properties: <String, Object?>{
            'lineId': _string(),
            'speakerId': _string(),
            'side': _enum(const <String>['left', 'right']),
            'text': _string(),
          },
        ),
      ),
      'objectiveType': _enum(const <String>[
        'reachEscape',
        'surviveRounds',
        'neutralizeTarget',
        'rescueRecover',
      ]),
      'objectiveLabel': _string(),
      'targetCharacterId': _nullableString(),
      'targetSquare': _nullableString(),
      'surviveRounds': _nullableInteger(),
      'participantCharacterIds': _array(_string()),
      'enemyNamedCharacterIds': _array(_string()),
      'statusChanges': _array(
        _object(
          properties: <String, Object?>{
            'characterId': _string(),
            'fromStatus': _enum(const <String>['undiscovered', 'missing']),
            'toStatus': _enum(const <String>['ally', 'enemy']),
            'reason': _string(),
          },
        ),
      ),
      'pressureTier': _enum(const <String>[
        'even',
        'pressured',
        'severe',
        'overwhelming',
      ]),
      'rewardTier': _integer(const <int>[0, 10, 20, 35, 60]),
      'finaleKind': _enum(const <String>['none', 'hopeful', 'tragic']),
      'campaignComplete': _boolean(),
      'epilogue': _nullableString(),
      'newCharacter': <String, Object?>{
        'anyOf': <Object?>[
          _object(
            properties: <String, Object?>{
              'name': _string(),
              'characterId': _string(),
              'pieceId': _string(),
              'pieceType': _pieceType(),
              'status': _enum(const <String>[
                'undiscovered',
                'ally',
                'enemy',
                'missing',
                'dead',
              ]),
              'recruitable': _boolean(),
              'description': _string(),
              'loyalty': _nullableInteger(minimum: 0, maximum: 100),
              'portraitPrompt': _nullableString(),
            },
          ),
          const <String, Object?>{'type': 'null'},
        ],
      },
    },
  );

  static Map<String, Object?> get builder => _object(
    properties: <String, Object?>{
      'schemaVersion': _integer(const <int>[2]),
      'runId': _string(),
      'missionNumber': _integer(null),
      'blackCountryId': _enum(const <String>[
        'ashen',
        'mercantile',
        'iron',
        'horse',
        'spy',
      ]),
      'startingTurn': _enum(const <String>['white', 'black']),
      'battlefieldId': _enum(const <String>[
        'classic',
        'verdantPastures',
        'gildedBazaar',
        'ruinedCauseway',
        'chaosCrucible',
      ]),
      'seed': _integer(null),
      'blackGold': _integer(null, minimum: 0),
      'merchantSpeed': _integer(null, minimum: 1, maximum: 8),
      'enemyPieces': _array(
        _object(
          properties: <String, Object?>{
            'pieceId': _string(),
            'pieceType': _pieceType(),
            'color': _enum(const <String>['black']),
            'square': _string(),
            'countryId': _enum(const <String>[
              'ashen',
              'mercantile',
              'iron',
              'horse',
              'spy',
            ]),
            'loyalty': _nullableInteger(minimum: 0, maximum: 100),
            'fairPrice': _nullableInteger(minimum: 1),
            'characterId': _nullableString(),
            'personalityId': _nullableString(),
            'hasMoved': _boolean(),
          },
        ),
        minItems: 1,
        maxItems: 16,
      ),
    },
  );

  static Map<String, Object?> get historyDigest => _object(
    properties: <String, Object?>{
      'schemaVersion': _integer(const <int>[2]),
      'runId': _string(),
      'digestId': _string(),
      'sourceMissionIds': _array(_string(), minItems: 1),
      'narrative': _string(),
    },
  );

  static Map<String, Object?> _object({
    required Map<String, Object?> properties,
  }) => <String, Object?>{
    'type': 'object',
    'additionalProperties': false,
    'properties': properties,
    'required': properties.keys.toList(growable: false),
  };

  static Map<String, Object?> _array(
    Map<String, Object?> items, {
    int? minItems,
    int? maxItems,
  }) => <String, Object?>{
    'type': 'array',
    'items': items,
    'minItems': ?minItems,
    'maxItems': ?maxItems,
  };

  static Map<String, Object?> _string() => const <String, Object?>{
    'type': 'string',
  };

  static Map<String, Object?> _nullableString() => const <String, Object?>{
    'type': <String>['string', 'null'],
  };

  static Map<String, Object?> _boolean() => const <String, Object?>{
    'type': 'boolean',
  };

  static Map<String, Object?> _integer(
    List<int>? values, {
    int? minimum,
    int? maximum,
  }) => <String, Object?>{
    'type': 'integer',
    'enum': ?values,
    'minimum': ?minimum,
    'maximum': ?maximum,
  };

  static Map<String, Object?> _nullableInteger({int? minimum, int? maximum}) =>
      <String, Object?>{
        'type': <String>['integer', 'null'],
        'minimum': ?minimum,
        'maximum': ?maximum,
      };

  static Map<String, Object?> _enum(List<String> values) => <String, Object?>{
    'type': 'string',
    'enum': values,
  };

  static Map<String, Object?> _pieceType() => _enum(const <String>[
    'king',
    'queen',
    'rook',
    'bishop',
    'knight',
    'pawn',
  ]);
}
