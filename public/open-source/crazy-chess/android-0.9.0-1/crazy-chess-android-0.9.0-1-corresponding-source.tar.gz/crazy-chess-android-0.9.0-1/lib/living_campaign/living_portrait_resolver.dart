import 'dart:convert';

import 'package:crypto/crypto.dart';

import '../domain/chess_models.dart';
import 'living_campaign_models.dart';

class LivingPortraitFallbackResolver {
  const LivingPortraitFallbackResolver._();

  static const String root =
      'assets/runtime/pieces/characters/living/fallbacks';

  static const String maelinAsset =
      'assets/runtime/pieces/characters/living/maelin_half_body.webp';
  static const String hadrikAsset =
      'assets/runtime/pieces/characters/living/hadrik_half_body.webp';
  static const String nerisAsset =
      'assets/runtime/pieces/characters/living/neris_half_body.webp';
  static const String tavianAsset =
      'assets/runtime/pieces/characters/living/tavian_half_body.webp';

  static List<String> neutralAssets(PieceType type) => switch (type) {
    PieceType.king => const <String>[
      '$root/unknown_king_a.webp',
      '$root/unknown_king_b.webp',
    ],
    PieceType.queen => const <String>[
      '$root/unknown_queen_a.webp',
      '$root/unknown_queen_b.webp',
    ],
    PieceType.rook => const <String>[
      '$root/unknown_rook_a.webp',
      '$root/unknown_rook_b.webp',
    ],
    PieceType.bishop => const <String>[
      '$root/unknown_bishop_a.webp',
      '$root/unknown_bishop_b.webp',
    ],
    PieceType.knight => const <String>[
      '$root/unknown_knight_a.webp',
      '$root/unknown_knight_b.webp',
    ],
    PieceType.pawn => const <String>[],
  };

  static String? neutralAsset(PieceType type, {required String stableKey}) {
    final assets = neutralAssets(type);
    if (assets.isEmpty) return null;
    final digest = sha256.convert(
      utf8.encode('living-portrait-fallback:$stableKey:${type.name}'),
    );
    return assets[digest.bytes.first % assets.length];
  }

  static const Map<String, String> fixedCharacterAssets = <String, String>{
    'char_orsain':
        'assets/runtime/pieces/characters/living/orsain_half_body.webp',
    'char_ysra': 'assets/runtime/pieces/characters/living/ysra_half_body.webp',
    'char_veyl': 'assets/runtime/pieces/characters/living/veyl_half_body.webp',
    'char_cael': 'assets/runtime/pieces/characters/living/cael_half_body.webp',
    'char_maelin_cinderveil': maelinAsset,
    'char_hadrik_emberwall': hadrikAsset,
    'char_neris_last_bell': nerisAsset,
    'char_tavian_greyspur': tavianAsset,
  };

  static String? fixedAsset(String characterId) =>
      fixedCharacterAssets[characterId];

  static LivingCampaignRun backfillAuthoredPortraits(LivingCampaignRun run) {
    var changed = false;
    final named = Map<String, LivingNamedPieceRecord>.from(
      run.namedPiecesByName,
    );
    for (final entry in named.entries.toList(growable: false)) {
      final asset = fixedAsset(entry.value.characterId);
      if (asset != null && _isMissing(entry.value.portraitPath)) {
        named[entry.key] = entry.value.copyWith(portraitPath: asset);
        changed = true;
      }
    }

    final characters = Map<String, LivingCharacter>.from(
      run.canon.charactersById,
    );
    for (final entry in characters.entries.toList(growable: false)) {
      final asset = fixedAsset(entry.key);
      if (asset != null && _isMissing(entry.value.portraitPath)) {
        characters[entry.key] = entry.value.copyWith(portraitPath: asset);
        changed = true;
      }
    }

    if (!changed) return run;
    return run.copyWith(
      namedPiecesByName: named,
      canon: run.canon.copyWith(charactersById: characters),
    );
  }

  static bool _isMissing(String? value) => value?.trim().isNotEmpty != true;
}
