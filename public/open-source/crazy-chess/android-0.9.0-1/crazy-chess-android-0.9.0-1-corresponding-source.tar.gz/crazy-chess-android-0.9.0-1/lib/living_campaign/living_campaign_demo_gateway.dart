import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import '../battlefield/battlefield_models.dart';
import '../domain/chess_models.dart';
import 'doubao_client.dart';
import 'living_campaign_generation_service.dart';
import 'living_campaign_models.dart';
import 'living_campaign_v2_backend.dart';
import 'living_campaign_v2_schemas.dart';

/// Deterministic acceptance-only provider used by the recorded browser flow.
/// Normal product builds never select it; the shell requires the explicit
/// `LIVING_CAMPAIGN_DEMO` compile-time flag.
class LivingCampaignDemoGateway
    implements LivingGenerationGateway, LivingCampaignV2Gateway {
  LivingCampaignDemoGateway({
    this.responseDelay = const Duration(milliseconds: 120),
    this.portraitSucceeds = false,
    this.portraitFixtureLoader,
    this.chapterArtSucceeds = false,
    this.chapterArtFixtureLoader,
  });

  final Duration responseDelay;
  final bool portraitSucceeds;
  final Future<Uint8List> Function()? portraitFixtureLoader;
  final bool chapterArtSucceeds;
  final Future<Uint8List> Function()? chapterArtFixtureLoader;
  int _requestSerial = 0;

  @override
  String get imageModel => 'living-demo-image';

  @override
  String get textModel => 'living-demo-text';

  @override
  Future<DoubaoTokenizationResult> countTextTokens(
    Iterable<String> values,
  ) async {
    final characters = values.fold<int>(0, (sum, value) => sum + value.length);
    return DoubaoTokenizationResult(
      totalTokens: (characters / 4).ceil(),
      requestId: 'living-demo-tokenize',
      model: textModel,
    );
  }

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    int maxTokens = 8192,
    double temperature = .25,
    Map<String, Object?>? jsonSchema,
    String? jsonSchemaName,
    DoubaoStreamProgressCallback? onProgress,
  }) async {
    onProgress?.call(
      DoubaoStreamProgress(
        phase: DoubaoStreamPhase.providerWorking,
        occurredAt: DateTime.now(),
      ),
    );
    await Future<void>.delayed(responseDelay);
    final isChinese =
        systemPrompt.contains('contentLocale is `zh-Hans`') ||
        userPayload['contentLocale'] == 'zh-Hans';
    final Map<String, Object?> value;
    if (jsonSchemaName == LivingCampaignV2Schemas.chroniclerName) {
      value = _v2MissionMemory(userPayload, isChinese: isChinese);
    } else if (jsonSchemaName == LivingCampaignV2Schemas.directorName) {
      value = _v2Director(userPayload, isChinese: isChinese);
    } else if (jsonSchemaName == LivingCampaignV2Schemas.builderName) {
      value = _v2Builder(userPayload);
    } else if (jsonSchemaName == LivingCampaignV2Schemas.historyDigestName) {
      value = _v2HistoryDigest(userPayload, isChinese: isChinese);
    } else if (userPayload.containsKey('initialCanon')) {
      value = _prologue(isChinese: isChinese);
    } else if (userPayload.containsKey('lockedDirectorIntent')) {
      value = _chapter(userPayload, isChinese: isChinese).toJson();
    } else {
      value = _directorPatch(userPayload, isChinese: isChinese).toJson();
    }
    _requestSerial += 1;
    onProgress?.call(
      DoubaoStreamProgress(
        phase: DoubaoStreamPhase.receiving,
        occurredAt: DateTime.now(),
        requestId: 'living-demo-request-$_requestSerial',
        receivedContentCharacters: value.toString().length,
      ),
    );
    return DoubaoJsonResponse(
      value: value,
      requestId: 'living-demo-request-$_requestSerial',
      model: textModel,
      usage: const <String, Object?>{},
      redactedRawResponse: '<deterministic debug fixture>',
      rawContent: jsonEncode(value),
      finishReason: 'stop',
      timeToFirstEvent: responseDelay,
      duration: responseDelay,
    );
  }

  Map<String, Object?> _v2MissionMemory(
    Map<String, Object?> payload, {
    required bool isChinese,
  }) {
    final mission = Map<String, Object?>.from(payload['mission']! as Map);
    final keyEvents = (payload['keyEvents']! as List<Object?>)
        .map((value) => Map<String, Object?>.from(value! as Map))
        .toList(growable: false);
    final namedCharacters = (payload['namedCharacters']! as List<Object?>)
        .map((value) => Map<String, Object?>.from(value! as Map))
        .toList(growable: false);
    final pendingIdentities =
        (payload['pendingIdentities'] as List<Object?>? ?? const <Object?>[])
            .map((value) => Map<String, Object?>.from(value! as Map))
            .toList(growable: false);
    final eligibleSpeakers =
        (payload['eligibleSpeakers'] as List<Object?>? ?? const <Object?>[])
            .map((value) => Map<String, Object?>.from(value! as Map))
            .toList(growable: false);
    final assignments = pendingIdentities.indexed
        .map(
          (entry) => <String, Object?>{
            'characterId': entry.$2['characterId'],
            'name': entry.$1 == 0
                ? (isChinese ? '烬醒者阿斯特' : 'Aster Emberwake')
                : (isChinese
                      ? '烬醒者阿斯特 ${entry.$1 + 1}'
                      : 'Aster Emberwake ${entry.$1 + 1}'),
            'description': isChinese
                ? '一名因身份转变而向灰烬王庭立下誓言的幸存者。'
                : 'A survivor whose change of station became an oath to the Ashen Court.',
            'portraitAppearanceBrief': isChinese
                ? '成年灰烬战士，象牙白与锈铜色铠甲，披灰黑斗篷，目光沉稳。'
                : 'Adult Ashen warrior, ivory and rust-bronze armor, ash-dark cloak, steady gaze.',
          },
        )
        .toList(growable: false);
    final assignedIds = assignments
        .map((assignment) => assignment['characterId'])
        .whereType<String>()
        .toSet();
    final speakerIds = <String>[
      ...eligibleSpeakers
          .map((speaker) => speaker['characterId'])
          .whereType<String>(),
      ...assignedIds,
    ];
    return <String, Object?>{
      'schemaVersion': 3,
      'runId': payload['runId'],
      'missionNumber': mission['missionNumber'],
      'missionId': mission['missionId'],
      'setupSummary': isChinese
          ? '灰烬王庭在断裂的道路前明确了目标，赶在敌阵彻底合围之前列阵。'
          : 'The Ashen Court faced a broken road and named the objective before '
                'the rival line could close around them.',
      'battleSummary': isChinese
          ? '这场经验证的战斗改变了王庭，也让幸存者朝下一声钟鸣继续前行。'
          : 'The verified battle changed the court and sent its survivors toward '
                'the next tolling bell.',
      'characterIds': namedCharacters
          .map((character) => character['characterId'])
          .whereType<String>()
          .followedBy(assignedIds)
          .toList(growable: false),
      'keyEventIds': keyEvents
          .map((event) => event['eventId'])
          .toList(growable: false),
      'identityAssignments': assignments,
      'aftermath': speakerIds.isEmpty
          ? <Object?>[
              <String, Object?>{
                'lineId': '${mission['missionId']}_aftermath_1',
                'speakerId': null,
                'side': 'center',
                'text': isChinese
                    ? '战场归于寂静，道路记住了所有曾经穿越它的人。'
                    : 'The field fell quiet, and the road remembered those who had crossed it.',
              },
            ]
          : <Object?>[
              <String, Object?>{
                'lineId': '${mission['missionId']}_aftermath_1',
                'speakerId': null,
                'side': 'center',
                'text': isChinese
                    ? '敌旗倒下之处，灰烬缓缓沉降。'
                    : 'Ash settled where the rival banners had fallen.',
              },
              <String, Object?>{
                'lineId': '${mission['missionId']}_aftermath_2',
                'speakerId': speakerIds.first,
                'side': 'left',
                'text': isChinese
                    ? '道路已经夺回。现在清点还有谁能继续走下去。'
                    : 'We won the road. Now we count who can still walk it.',
              },
              <String, Object?>{
                'lineId': '${mission['missionId']}_aftermath_3',
                'speakerId': speakerIds.length > 1
                    ? speakerIds[1]
                    : speakerIds.first,
                'side': 'right',
                'text': isChinese
                    ? '那就把我算在生者之中，也别让死者无名。'
                    : 'Then count me among the living, and let the dead be named.',
              },
              <String, Object?>{
                'lineId': '${mission['missionId']}_aftermath_4',
                'speakerId': speakerIds.first,
                'side': 'left',
                'text': isChinese
                    ? '王冠会继续前行，但也会把这片战场一同背负。'
                    : 'The crown moves on, but it will carry this field with it.',
              },
            ],
    };
  }

  Map<String, Object?> _v2Director(
    Map<String, Object?> payload, {
    required bool isChinese,
  }) {
    final nextMission = (payload['nextMissionNumber']! as num).toInt();
    final eligible = (payload['eligibleAllies']! as List<Object?>)
        .map((value) => Map<String, Object?>.from(value! as Map))
        .toList(growable: false);
    final participants = eligible
        .take(8)
        .map((character) => character['characterId'])
        .toList();
    const recruitedCharacterId = 'char_maelin_cinderveil';
    if (!participants.contains(recruitedCharacterId)) {
      participants.add(recruitedCharacterId);
    }
    final speakerA = participants.first;
    final speakerB = participants.length > 1 ? participants[1] : speakerA;
    return <String, Object?>{
      'schemaVersion': 2,
      'runId': payload['runId'],
      'basedOnMissionNumber': payload['basedOnMissionNumber'],
      'nextMissionNumber': nextMission,
      'title': isChinese ? '灰烬钟鸣' : 'The Ash Bells',
      'subtitle': isChinese ? '坚守至最后一声钟鸣' : 'Stand until the last bell',
      'background': isChinese
          ? '上一场战斗唤醒了王座废墟彼端的六口钟，向一支尚未现身的大军警告：灰烬王庭仍在前进。'
          : 'The last battle woke six bells beyond the Ruined Causeway, warning '
                'an unseen host that the Ashen Court still marches.',
      'dialogue': <Object?>[
        <String, Object?>{
          'lineId': 'living_m${nextMission}_line_1',
          'speakerId': speakerA,
          'side': 'left',
          'text': isChinese
              ? '钟声正在清点我们。守住这里，直到警报彻底沉寂。'
              : 'The bells are counting us. We hold here until the warning dies.',
        },
        <String, Object?>{
          'lineId': 'living_m${nextMission}_line_2',
          'speakerId': speakerB,
          'side': 'right',
          'text': isChinese
              ? '那就让每一声钟鸣都以他们丢失的阵地为代价。'
              : 'Then make every toll cost them ground.',
        },
        <String, Object?>{
          'lineId': 'living_m${nextMission}_line_3',
          'speakerId': 'char_demo_bell_warden',
          'side': 'right',
          'text': isChinese
              ? '你们穿过了一条断路。下一条路会被钟声埋葬。'
              : 'You crossed one broken road. The bells will bury the next.',
        },
        <String, Object?>{
          'lineId': 'living_m${nextMission}_line_4',
          'speakerId': recruitedCharacterId,
          'side': 'left',
          'text': isChinese
              ? '那王冠就用自己的钟声回应。'
              : 'Then the crown will answer with a bell of its own.',
        },
      ],
      'objectiveType': 'surviveRounds',
      'objectiveLabel': isChinese
          ? '守住废墟通道二十个完整回合'
          : 'Hold the causeway for twenty full rounds',
      'targetCharacterId': null,
      'targetSquare': null,
      'surviveRounds': 20,
      'participantCharacterIds': participants,
      'enemyNamedCharacterIds': <Object?>['char_demo_bell_warden'],
      'statusChanges': <Object?>[
        <String, Object?>{
          'characterId': recruitedCharacterId,
          'fromStatus': 'undiscovered',
          'toStatus': 'ally',
          'reason': isChinese
              ? '梅琳女士回应灰烬钟鸣，加入行军中的王庭。'
              : 'Lady Maelin answers the Ash Bells and joins the marching court.',
        },
      ],
      'pressureTier': 'pressured',
      'rewardTier': 20,
      'finaleKind': 'none',
      'campaignComplete': false,
      'epilogue': null,
      'newCharacter': <String, Object?>{
        'name': isChinese ? '钟卫' : 'The Bell Warden',
        'characterId': 'char_demo_bell_warden',
        'pieceId': 'm${nextMission}_enemy_king',
        'pieceType': 'king',
        'status': 'enemy',
        'recruitable': false,
        'description': isChinese
            ? '一名戴着面具、以铁钟统治废墟山谷的君主。'
            : 'A masked ruler who commands the ruined valley through iron bells.',
        'loyalty': null,
        'portraitPrompt': isChinese
            ? '身着暗铁礼服、面容完全遮蔽的钟卫。'
            : 'A masked bell warden in dark iron regalia, face fully obscured.',
      },
    };
  }

  Map<String, Object?> _v2Builder(Map<String, Object?> payload) {
    final director = Map<String, Object?>.from(
      payload['directorDecision']! as Map,
    );
    final mission = (director['nextMissionNumber']! as num).toInt();
    Map<String, Object?> piece(
      String id,
      String type,
      String square, {
      int? loyalty,
      int? price,
      String? characterId,
    }) => <String, Object?>{
      'pieceId': id,
      'pieceType': type,
      'color': 'black',
      'square': square,
      'countryId': 'iron',
      'loyalty': loyalty,
      'fairPrice': price,
      'characterId': characterId,
      'personalityId': null,
      'hasMoved': false,
    };
    return <String, Object?>{
      'schemaVersion': 2,
      'runId': payload['runId'],
      'missionNumber': mission,
      'blackCountryId': 'iron',
      'startingTurn': 'white',
      'battlefieldId': 'ruinedCauseway',
      'seed': 2200 + mission,
      'blackGold': 18,
      'merchantSpeed': 4,
      'enemyPieces': <Object?>[
        piece(
          'm${mission}_enemy_king',
          'king',
          'e8',
          characterId: 'char_demo_bell_warden',
        ),
        piece('m${mission}_enemy_rook', 'rook', 'a7', loyalty: 70, price: 22),
        piece(
          'm${mission}_enemy_bishop',
          'bishop',
          'c8',
          loyalty: 65,
          price: 14,
        ),
        piece(
          'm${mission}_enemy_knight',
          'knight',
          'g7',
          loyalty: 65,
          price: 14,
        ),
        piece('m${mission}_enemy_pawn_d', 'pawn', 'd6', loyalty: 55, price: 6),
        piece('m${mission}_enemy_pawn_f', 'pawn', 'f6', loyalty: 55, price: 6),
      ],
    };
  }

  Map<String, Object?> _v2HistoryDigest(
    Map<String, Object?> payload, {
    required bool isChinese,
  }) {
    final memories = (payload['sourceMemories']! as List<Object?>)
        .map((value) => Map<String, Object?>.from(value! as Map))
        .toList(growable: false);
    return <String, Object?>{
      'schemaVersion': 2,
      'runId': payload['runId'],
      'digestId': 'demo-history-digest',
      'sourceMissionIds': memories
          .map((memory) => memory['missionId'])
          .toList(growable: false),
      'narrative': isChinese
          ? '灰烬王庭接连穿过数片战场，同时保留了主要的忠诚、损失与仍未解决的王冠归属。'
          : 'The Ashen Court crossed successive battlefields while preserving '
                'its major allegiances, losses, and unresolved crown claim.',
      'sourceTokens': payload['sourceTokens'],
      'digestTokens': ((payload['sourceTokens']! as num).toInt() / 3).floor(),
    };
  }

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) async {
    if (!portraitSucceeds || portraitFixtureLoader == null) {
      throw const LivingProviderException(
        code: 'demo_portrait_unavailable',
        safeMessage:
            'The deterministic acceptance portrait failed without blocking the mission.',
      );
    }
    final bytes = await portraitFixtureLoader!();
    await onSourceDownloaded?.call(bytes);
    return DoubaoPortraitResult(
      pngBytes: bytes,
      width: 1024,
      height: 1536,
      finalPrompt: prompt,
      requestId: 'living-demo-portrait-success',
      redactedRawResponse: '<deterministic debug portrait fixture>',
    );
  }

  @override
  Future<DoubaoChapterArtResult> generateChapterEndingArt({
    required String prompt,
    required int seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) async {
    await Future<void>.delayed(responseDelay);
    if (!chapterArtSucceeds || chapterArtFixtureLoader == null) {
      throw const LivingProviderException(
        code: 'demo_chapter_art_unavailable',
        safeMessage: 'The field’s last memory remains hidden beyond the ash.',
      );
    }
    final bytes = await chapterArtFixtureLoader!();
    await onSourceDownloaded?.call(bytes);
    return DoubaoChapterArtResult(
      imageBytes: bytes,
      width: 1672,
      height: 941,
      finalPrompt: prompt,
      requestId: 'living-demo-chapter-art-success',
      redactedRawResponse: '<deterministic debug chapter-art fixture>',
    );
  }

  @override
  Future<List<Uint8List>> loadPortraitStyleReferences() async =>
      const <Uint8List>[];

  Map<String, Object?> _prologue({
    required bool isChinese,
  }) => <String, Object?>{
    'campaignTitle': isChinese ? '拒绝冷却的王冠' : 'The Crown That Refused to Cool',
    'storyPromise': isChinese
        ? '一座破碎的王庭必须决定：当每一场胜利都揭开旧日指控时，忠诚是否还能存续。'
        : 'A broken court must decide whether loyalty can survive the victories '
              'that expose every old accusation.',
    'prologue': List<String>.filled(
      4,
      isChinese
          ? '在王座废墟，奥赛因举起未竟的王冠，伊丝拉清点生者，维尔从火中藏起一页记录，凯尔则注视着身后的道路。誓言尚未破碎，却没有一句能在灰烬钟声下显得完整。'
          : 'At the Ruined Causeway, Orsain lifted an unfinished crown while Ysra '
                'counted the living, Veyl hid a page from the fire, and Cael watched '
                'the road behind them. No oath had yet broken, but none sounded '
                'whole beneath the ash bells. ',
    ).join(),
  };

  LivingDirectorPatch _directorPatch(
    Map<String, Object?> payload, {
    required bool isChinese,
  }) {
    final canon = payload['canon']! as Map<String, Object?>;
    final outcome = payload['verifiedBattleOutcome']! as Map<String, Object?>;
    final chapterNumber = (outcome['chapterNumber']! as num).toInt();
    final chapterId = outcome['chapterId']! as String;
    return LivingDirectorPatch(
      schemaVersion: (canon['schemaVersion']! as num).toInt(),
      runId: canon['runId']! as String,
      basedOnRevision: (canon['revision']! as num).toInt(),
      completedChapter: LivingCompletedChapterPatch(
        chapterNumber: chapterNumber,
        chapterId: chapterId,
        title: isChinese
            ? (chapterNumber == 1 ? '灰烬分界' : '灰烬钟鸣')
            : (chapterNumber == 1 ? 'The Ashen Divide' : 'The Ash Bells'),
        oneLineSummary: isChinese
            ? '灰烬王庭挺过第 $chapterNumber 章，并循着钟声走入一条更狭窄的道路。'
            : 'The Ashen Court survived Chapter $chapterNumber and followed the '
                  'bells into a narrower road.',
      ),
      addCharacters: const <LivingCharacter>[],
      addEvents: <LivingCanonEvent>[
        LivingCanonEvent(
          eventId: 'demo_event_chapter_$chapterNumber',
          chapterNumber: chapterNumber,
          type: LivingEventType.battleWon,
          subjectIds: const <String>['char_orsain'],
          description: isChinese
              ? '灰烬王庭在经验证的浏览器演示战斗中幸存。'
              : 'The Ashen Court survived the verified browser-demo battle.',
        ),
      ],
      addCanonFacts: const <LivingCanonFact>[],
      openStoryThreads: const <LivingStoryThread>[],
      characterTransitions: const <LivingCharacterTransition>[],
      advanceStoryThreads: const <LivingThreadChange>[],
      resolveStoryThreads: const <LivingThreadChange>[],
      relationshipChanges: const <LivingRelationshipChange>[],
      nextChapterIntent: LivingNextChapterIntent(
        chapterNumber: chapterNumber + 1,
        conflict: isChinese
            ? '王庭必须守住山口，直到六口灰烬钟停止鸣响。'
            : 'The court must hold the pass until six ash bells finish tolling.',
        objectiveType: LivingObjectiveType.surviveRounds,
        pressureTier: 'pressured',
        rewardTier: 20,
        finaleKind: LivingFinaleKind.none,
        essentialBeats: isChinese
            ? const <String>['伊丝拉守住狭窄山口。', '维尔辨认出钟声的次序。']
            : const <String>[
                'Ysra holds the narrow pass.',
                'Veyl recognizes the order in the bells.',
              ],
      ),
    );
  }

  LivingChapterPackage _chapter(
    Map<String, Object?> payload, {
    required bool isChinese,
  }) {
    final canon = payload['canon']! as Map<String, Object?>;
    final intent = payload['lockedDirectorIntent']! as Map<String, Object?>;
    final chapterNumber = (intent['chapterNumber']! as num).toInt();
    final gold = (canon['gold']! as num).toInt();
    return LivingChapterPackage(
      schemaVersion: (canon['schemaVersion']! as num).toInt(),
      runId: canon['runId']! as String,
      basedOnRevision: (canon['revision']! as num).toInt(),
      chapterNumber: chapterNumber,
      chapterId: 'living_m${chapterNumber.toString().padLeft(2, '0')}',
      title: isChinese ? '灰烬钟鸣' : 'The Ash Bells',
      subtitle: isChinese ? '坚守至最后一声钟鸣' : 'Stand until the last bell',
      briefing: isChinese
          ? '初次胜利唤醒了废墟山谷中的六口钟。守住通道直到最后一声钟鸣，或以将杀终结敌方王庭。'
          : 'The first victory woke six bells in the ruined valley. Hold the '
                'causeway until the final toll, or end the enemy court by checkmate.',
      pressureTier: intent['pressureTier']! as String,
      objective: LivingMissionObjective(
        type: LivingObjectiveType.surviveRounds,
        label: isChinese
            ? '存活二十个完整回合，或将杀敌方。'
            : 'Survive 20 full rounds or checkmate the enemy.',
        surviveRounds: 20,
      ),
      whiteCountryId: 'ashen',
      blackCountryId: 'iron',
      startingTurn: PieceColor.white,
      battlefieldId: BattlefieldId.ruinedCauseway,
      seed: 2201,
      economyEnabled: true,
      merchantEnabled: true,
      specialTilesEnabled: true,
      whiteGold: gold,
      blackGold: 20,
      merchantSpeed: 4,
      pieces: <LivingMissionPiece>[
        _piece('ashen_king_orsain', PieceType.king, PieceColor.white, 'e1'),
        _piece('ashen_rook_ysra', PieceType.rook, PieceColor.white, 'a1'),
        _piece('ashen_bishop_veyl', PieceType.bishop, PieceColor.white, 'c1'),
        _piece('ashen_knight_cael', PieceType.knight, PieceColor.white, 'g1'),
        _piece('ashen_pawn_d', PieceType.pawn, PieceColor.white, 'd2'),
        _piece('ashen_pawn_e', PieceType.pawn, PieceColor.white, 'e2'),
        _piece('ashen_pawn_f', PieceType.pawn, PieceColor.white, 'f2'),
        _piece('demo_enemy_king_2', PieceType.king, PieceColor.black, 'e8'),
        _piece('demo_enemy_rook_2', PieceType.rook, PieceColor.black, 'a8'),
        _piece('demo_enemy_bishop_2', PieceType.bishop, PieceColor.black, 'c8'),
        _piece('demo_enemy_knight_2', PieceType.knight, PieceColor.black, 'g8'),
        _piece('demo_enemy_pawn_d_2', PieceType.pawn, PieceColor.black, 'd7'),
        _piece('demo_enemy_pawn_e_2', PieceType.pawn, PieceColor.black, 'e7'),
        _piece('demo_enemy_pawn_f_2', PieceType.pawn, PieceColor.black, 'f7'),
      ],
      reservePieceIds: const <String>[],
      dialogue: <LivingDialogueLine>[
        LivingDialogueLine(
          lineId: 'living_m02_line_1',
          speakerId: 'char_ysra',
          side: 'left',
          text: isChinese
              ? '六口钟。最后一声消散时，我们只需要仍然站着。'
              : 'Six bells. We only need to be standing when the last one dies.',
        ),
        LivingDialogueLine(
          lineId: 'living_m02_line_2',
          speakerId: 'char_veyl',
          side: 'right',
          text: isChinese
              ? '它们清点的不是时间，而是我们。'
              : 'They are not counting time. They are counting us.',
        ),
      ],
      aiAggression: .5,
      aiDefense: .5,
      aiObjectivePressure: .6,
      aiTileAppetite: .4,
    );
  }

  LivingMissionPiece _piece(
    String id,
    PieceType type,
    PieceColor color,
    String square,
  ) {
    const characterByPiece = <String, String>{
      'ashen_king_orsain': 'char_orsain',
      'ashen_rook_ysra': 'char_ysra',
      'ashen_bishop_veyl': 'char_veyl',
      'ashen_knight_cael': 'char_cael',
    };
    return LivingMissionPiece(
      pieceId: id,
      pieceType: type,
      color: color,
      square: livingSquareFromName(square),
      countryId: color == PieceColor.white ? 'ashen' : 'iron',
      loyalty: type == PieceType.king ? null : 60,
      fairPrice: type == PieceType.king ? null : 8,
      characterId: characterByPiece[id],
    );
  }
}
