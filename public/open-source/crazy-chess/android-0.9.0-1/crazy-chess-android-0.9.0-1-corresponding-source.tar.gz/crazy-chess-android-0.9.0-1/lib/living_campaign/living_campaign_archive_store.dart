import 'dart:async';

import 'package:flutter/foundation.dart';

import 'living_campaign_archive_store_factory_stub.dart'
    if (dart.library.io) 'living_campaign_archive_store_factory_io.dart'
    if (dart.library.js_interop) 'living_campaign_archive_store_factory_web.dart'
    as platform;
import 'living_campaign_models.dart';
import 'living_campaign_metrics.dart';

@immutable
class LivingRunArchiveSummary {
  const LivingRunArchiveSummary({
    required this.runId,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.activeChapterNumber,
    required this.chapterCount,
    required this.byteSize,
  });

  final String runId;
  final LivingRunStatus status;
  final DateTime createdAt;
  final DateTime updatedAt;
  final int activeChapterNumber;
  final int chapterCount;
  final int byteSize;
}

abstract interface class LivingCampaignArchiveStore {
  Future<void> initialize();
  Future<void> writeRun(LivingCampaignRun run);
  Future<LivingCampaignRun?> readRun(String runId);
  Future<void> writeTimingMetrics(LivingCampaignRunTimingMetrics metrics);
  Future<LivingCampaignRunTimingMetrics?> readTimingMetrics(String runId);
  Future<List<LivingRunArchiveSummary>> listRuns();
  Future<void> deleteRun(String runId);
  Future<int> storageBytes();
  Future<String> writeBinary({
    required String runId,
    required String fileName,
    required Uint8List bytes,
  });
  Future<Uint8List?> readBinary(String reference);
}

LivingCampaignArchiveStore createLivingCampaignArchiveStore() =>
    platform.createPlatformLivingCampaignArchiveStore();

/// Serializes read/merge/write mutations for one run even when text and image
/// providers finish at nearly the same time.
class LivingCampaignRunMutationCoordinator {
  LivingCampaignRunMutationCoordinator._(this._archive);

  static final Expando<LivingCampaignRunMutationCoordinator> _instances =
      Expando<LivingCampaignRunMutationCoordinator>();

  factory LivingCampaignRunMutationCoordinator.forArchive(
    LivingCampaignArchiveStore archive,
  ) => _instances[archive] ??= LivingCampaignRunMutationCoordinator._(archive);

  final LivingCampaignArchiveStore _archive;
  final Map<String, Future<void>> _tails = <String, Future<void>>{};

  Future<LivingCampaignRun> mutate({
    required String runId,
    required LivingCampaignRun seed,
    required FutureOr<LivingCampaignRun> Function(LivingCampaignRun latest)
    mutation,
  }) {
    final completer = Completer<LivingCampaignRun>();
    final previous = _tails[runId] ?? Future<void>.value();
    late final Future<void> next;
    next = previous
        .catchError((Object _) {})
        .then((_) async {
          try {
            final latest = await _archive.readRun(runId) ?? seed;
            final updated = await mutation(latest);
            await _archive.writeRun(updated);
            completer.complete(updated);
          } on Object catch (error, stackTrace) {
            completer.completeError(error, stackTrace);
          }
        })
        .whenComplete(() {
          if (identical(_tails[runId], next)) {
            _tails.remove(runId);
          }
        });
    _tails[runId] = next;
    return completer.future;
  }
}
