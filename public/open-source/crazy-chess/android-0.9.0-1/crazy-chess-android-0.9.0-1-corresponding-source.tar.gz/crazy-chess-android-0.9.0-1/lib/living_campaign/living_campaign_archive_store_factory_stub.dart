import 'living_campaign_archive_store.dart';

LivingCampaignArchiveStore createPlatformLivingCampaignArchiveStore() =>
    throw UnsupportedError('Living Campaign archives are unavailable.');
