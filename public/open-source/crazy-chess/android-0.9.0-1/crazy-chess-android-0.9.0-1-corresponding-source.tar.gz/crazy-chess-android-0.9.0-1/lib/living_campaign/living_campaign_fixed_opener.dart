import '../battlefield/battlefield_models.dart';
import '../domain/chess_models.dart';
import 'living_campaign_models.dart';
import 'living_portrait_resolver.dart';

abstract final class LivingCampaignFixedOpener {
  static const campaignTitle = "The Ashen Crown's Unfinished Reign";
  static const storyPromise =
      'This run follows the survivors of the Ashen Court as they cross the '
      'Ruined Causeway to salvage their fractured legacy. Clashing loyalties, '
      'quiet ambitions, victories, captures, and bargains will rewrite who '
      'holds power and what remains of the court that burned to ash.';
  static const prologue =
      'The old court burned without choosing an heir. At dawn, eight survivors '
      'cross the Ruined Causeway beneath a banner the fire could not finish. '
      'Orsain Ashcrown carries the crown, but each companion carries a different '
      'answer to the question of who deserves it.';
  static const simplifiedChineseCampaignTitle = '灰烬王冠的未竟统治';
  static const simplifiedChineseStoryPromise =
      '本次战役追随灰烬王庭的幸存者穿越王座废墟，试图挽救支离破碎的传承。'
      '彼此冲突的忠诚、隐秘的野心、胜利、俘获与交易，将不断改写权力归属，'
      '也决定那座焚为灰烬的王庭最终还能留下什么。';
  static const simplifiedChinesePrologue =
      '旧王庭在尚未选出继承人时便付之一炬。黎明时分，八名幸存者在一面未被烈火吞尽的旗帜下穿过王座废墟。'
      '灰冠王奥赛因手握王冠，但每位同伴都对谁配得上它怀着不同答案。';

  static LivingCampaignRun create({
    required String runId,
    required DateTime now,
    LivingContentLocale contentLocale = LivingContentLocale.english,
  }) {
    final isChinese = contentLocale == LivingContentLocale.simplifiedChinese;
    final playerSeeds = _playerSeedsFor(contentLocale);
    final localizedCampaignTitle = isChinese
        ? simplifiedChineseCampaignTitle
        : campaignTitle;
    final localizedStoryPromise = isChinese
        ? simplifiedChineseStoryPromise
        : storyPromise;
    final localizedPrologue = isChinese ? simplifiedChinesePrologue : prologue;
    final roster = <String, LivingRosterPiece>{
      for (final seed in playerSeeds)
        seed.pieceId: LivingRosterPiece(
          pieceId: seed.pieceId,
          basePieceType: seed.pieceType,
          characterId: seed.characterId,
          origin: isChinese
              ? '焚毁的灰烬王庭幸存者'
              : 'Survivor of the burned Ashen Court',
          lifeState: LivingLifeState.alive,
          whereabouts: LivingWhereabouts.withCourt,
          allegiance: LivingAllegiance.player,
          rosterPosition: LivingRosterPosition.active,
        ),
    };
    final characters = <String, LivingCharacter>{
      for (final seed in playerSeeds.where(
        (value) => value.characterId != null,
      ))
        seed.characterId!: LivingCharacter(
          characterId: seed.characterId!,
          originalName: seed.displayName!,
          originalIdentity: seed.originalIdentity!,
          basePieceType: seed.pieceType,
          linkedPieceId: seed.pieceId,
          lifeState: LivingLifeState.alive,
          whereabouts: LivingWhereabouts.withCourt,
          allegiance: LivingAllegiance.player,
          firstChapter: 0,
          lastChapter: 0,
          portraitPath: seed.portraitPath,
        ),
    };
    final events = <LivingCanonEvent>[
      LivingCanonEvent(
        eventId: 'event_${runId}_prologue',
        chapterNumber: 0,
        type: LivingEventType.chapterStarted,
        subjectIds: characters.keys.toList(growable: false),
        description: localizedPrologue,
      ),
    ];
    final canon = LivingCanonState(
      schemaVersion: 1,
      runId: runId,
      revision: 0,
      gold: 10,
      playerRosterByPieceId: Map.unmodifiable(roster),
      charactersById: Map.unmodifiable(characters),
      chapterLedger: const <LivingChapterRecord>[],
      eventLedger: List.unmodifiable(events),
      canonFactsById: <String, LivingCanonFact>{
        'fact_${runId}_court_burned': LivingCanonFact(
          factId: 'fact_${runId}_court_burned',
          kind: LivingFactKind.verified,
          statement: isChinese
              ? '第一场战斗开始前，昔日的灰烬王庭已被烈火焚毁。'
              : 'The former Ashen Court burned before the first battle.',
          chapterNumber: 0,
          subjectIds: characters.keys.toList(growable: false),
          sourceEventId: events.single.eventId,
        ),
      },
      storyThreadsById: <String, LivingStoryThread>{
        'thread_${runId}_crown': LivingStoryThread(
          threadId: 'thread_${runId}_crown',
          title: isChinese ? '谁配得上灰烬王冠？' : 'Who deserves the Ashen Crown?',
          status: LivingThreadStatus.open,
          participantIds: characters.keys.toList(growable: false),
          openedChapter: 0,
          lastAdvancedChapter: 0,
          summary: isChinese
              ? '奥赛因戴着王冠，但幸存的王庭尚未认同他的统治究竟应当意味着什么。'
              : 'Orsain bears the crown, but the surviving court has not agreed '
                    'what his rule should mean.',
          evidenceEventIds: <String>[events.single.eventId],
        ),
        'thread_${runId}_cael': LivingStoryThread(
          threadId: 'thread_${runId}_cael',
          title: isChinese ? '无旗骑士' : 'The knight with no banner',
          status: LivingThreadStatus.open,
          participantIds: const <String>['char_cael'],
          openedChapter: 0,
          lastAdvancedChapter: 0,
          summary: isChinese
              ? '凯尔与王庭并肩作战，却拒绝宣誓自己属于它。'
              : 'Cael fights beside the court while refusing to swear that he '
                    'belongs to it.',
          evidenceEventIds: <String>[events.single.eventId],
        ),
      },
      relationshipsById: <String, LivingRelationship>{
        'rel_orsain_ysra': LivingRelationship(
          relationshipId: 'rel_orsain_ysra',
          characterIds: <String>['char_orsain', 'char_ysra'],
          currentSummary: isChinese
              ? '共同求生锻造出一份彼此戒备的信任。'
              : 'Guarded trust forged by shared survival.',
          changeEventIds: const <String>[],
        ),
        'rel_cael_orsain': LivingRelationship(
          relationshipId: 'rel_cael_orsain',
          characterIds: <String>['char_cael', 'char_orsain'],
          currentSummary: isChinese
              ? '一段实用的同盟，却始终笼罩在野心的阴影下。'
              : 'Useful alliance shadowed by ambition.',
          changeEventIds: const <String>[],
        ),
      },
      memoryEpochs: const <LivingMemoryEpoch>[],
    );
    return LivingCampaignRun(
      schemaVersion: 5,
      contentLocale: contentLocale,
      runId: runId,
      status: LivingRunStatus.active,
      createdAt: now,
      updatedAt: now,
      prologue: localizedPrologue,
      campaignTitle: localizedCampaignTitle,
      storyPromise: localizedStoryPromise,
      canon: canon,
      chapterPackages: <LivingChapterPackage>[
        _chapterOne(runId, contentLocale, playerSeeds),
      ],
      battleOutcomes: const <LivingBattleOutcomeSnapshot>[],
      namedPiecesByName: Map.unmodifiable(
        _initialNamedPieces(contentLocale, playerSeeds),
      ),
    );
  }

  static Map<String, LivingNamedPieceRecord> _initialNamedPieces(
    LivingContentLocale contentLocale,
    List<_FixedPieceSeed> playerSeeds,
  ) {
    final records = <String, LivingNamedPieceRecord>{
      for (final seed in playerSeeds)
        seed.displayName!: LivingNamedPieceRecord(
          name: seed.displayName!,
          characterId: seed.characterId!,
          pieceId: seed.pieceId,
          pieceType: seed.pieceType,
          status: LivingNamedPieceStatus.ally,
          recruitable: false,
          description: seed.originalIdentity!,
          loyalty: seed.pieceType == PieceType.king ? null : 60,
          portraitPath: seed.portraitPath,
          discoveredMission: 0,
          lastKnownMission: 0,
        ),
    };
    for (final record in _recruitablePoolFor(contentLocale)) {
      records[record.name] = record;
    }
    return records;
  }

  static LivingChapterPackage _chapterOne(
    String runId,
    LivingContentLocale contentLocale,
    List<_FixedPieceSeed> playerSeeds,
  ) {
    final isChinese = contentLocale == LivingContentLocale.simplifiedChinese;
    final pieces = <LivingMissionPiece>[
      ...playerSeeds.map(
        (seed) => LivingMissionPiece(
          pieceId: seed.pieceId,
          pieceType: seed.pieceType,
          color: PieceColor.white,
          square: seed.square,
          countryId: 'ashen',
          loyalty: seed.pieceType == PieceType.king ? null : 60,
          fairPrice: _fairPrice(seed.pieceType),
          characterId: seed.characterId,
        ),
      ),
      for (final col in <int>[0, 2, 4, 6])
        LivingMissionPiece(
          pieceId: 'living_m01_white_pawn_${String.fromCharCode(97 + col)}2',
          pieceType: PieceType.pawn,
          color: PieceColor.white,
          square: Square(6, col),
          countryId: 'ashen',
          loyalty: 60,
          fairPrice: 6,
        ),
      const LivingMissionPiece(
        pieceId: 'enemy_rook_a8',
        pieceType: PieceType.rook,
        color: PieceColor.black,
        square: Square(0, 0),
        countryId: 'ashen',
        loyalty: 60,
        fairPrice: 22,
      ),
      const LivingMissionPiece(
        pieceId: 'enemy_bishop_c8',
        pieceType: PieceType.bishop,
        color: PieceColor.black,
        square: Square(0, 2),
        countryId: 'ashen',
        loyalty: 60,
        fairPrice: 14,
      ),
      const LivingMissionPiece(
        pieceId: 'enemy_king_e8',
        pieceType: PieceType.king,
        color: PieceColor.black,
        square: Square(0, 4),
        countryId: 'ashen',
        loyalty: null,
        fairPrice: null,
      ),
      const LivingMissionPiece(
        pieceId: 'enemy_knight_g8',
        pieceType: PieceType.knight,
        color: PieceColor.black,
        square: Square(0, 6),
        countryId: 'ashen',
        loyalty: 60,
        fairPrice: 14,
      ),
      for (final col in <int>[0, 2, 4, 6])
        LivingMissionPiece(
          pieceId: 'enemy_pawn_${String.fromCharCode(97 + col)}7',
          pieceType: PieceType.pawn,
          color: PieceColor.black,
          square: Square(1, col),
          countryId: 'ashen',
          loyalty: 60,
          fairPrice: 6,
        ),
    ];
    return LivingChapterPackage(
      schemaVersion: 2,
      runId: runId,
      basedOnRevision: 0,
      chapterNumber: 1,
      chapterId: 'living_m01',
      title: isChinese ? '灰烬分界' : 'The Ashen Divide',
      subtitle: isChinese
          ? '一顶王冠，一条生路，没有无可争议的继承人。'
          : 'One crown. One road out. No uncontested heir.',
      briefing: isChinese
          ? '敌对的灰烬阵线正在王座废墟上合围。击败他们的王，清出道路，并饶过投降者。'
          : 'The rival Ashen line is closing across the Ruined Causeway. Defeat '
                'their King, clear the road, and spare those who surrender.',
      objective: LivingMissionObjective(
        type: LivingObjectiveType.checkmate,
        label: isChinese ? '将杀敌方灰烬之王' : 'Checkmate the rival Ashen King',
      ),
      whiteCountryId: 'ashen',
      blackCountryId: 'ashen',
      startingTurn: PieceColor.white,
      battlefieldId: BattlefieldId.ruinedCauseway,
      seed: 1101,
      economyEnabled: true,
      merchantEnabled: true,
      specialTilesEnabled: true,
      whiteGold: 10,
      blackGold: 10,
      merchantSpeed: 4,
      pieces: List.unmodifiable(pieces),
      reservePieceIds: const <String>[],
      dialogue: <LivingDialogueLine>[
        LivingDialogueLine(
          lineId: 'living_m01_line_01',
          speakerId: 'char_ysra',
          side: 'left',
          text: isChinese
              ? '那是灰烬王庭的盾。我亲手训练过他们左翼的车。'
              : 'Those are Ashen shields. I trained the rook on their left.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_02',
          speakerId: 'char_orsain',
          side: 'right',
          text: isChinese ? '他们会因你而放下武器吗？' : 'Will they stand down for you?',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_03',
          speakerId: 'char_ysra',
          side: 'left',
          text: isChinese
              ? '只要他们还相信你的王冠是从烈火里伪造的，就不会。'
              : 'Not while they believe your crown was forged in the fire.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_04',
          speakerId: 'char_veyl',
          side: 'left',
          text: isChinese
              ? '记录中没有无可争议的继承人。他们的主张并不比我们更空洞。'
              : 'The records name no uncontested heir. Their claim is no emptier than ours.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_05',
          speakerId: 'char_orsain',
          side: 'right',
          text: isChinese
              ? '你偏偏选了最不方便的时刻说实话。'
              : 'You chose an inconvenient hour for honesty.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_06',
          speakerId: 'char_veyl',
          side: 'left',
          text: isChinese
              ? '正因如此，旧王庭才把实话称为叛国。'
              : 'That is why the old court called it treason.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_07',
          speakerId: 'char_cael',
          side: 'left',
          text: isChinese
              ? '你们可以继续争论灰烬，也可以先看看正在收紧的敌阵。'
              : 'You can debate the ashes, or notice that their line is closing.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_08',
          speakerId: 'char_ysra',
          side: 'left',
          text: isChinese
              ? '只要击溃他们，有些人会投降。他们不全是叛徒。'
              : 'If we break them, some will yield. They are not all traitors.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_09',
          speakerId: 'char_orsain',
          side: 'right',
          text: isChinese
              ? '那就饶过每一个放下武器的人。'
              : 'Then offer quarter to anyone who lowers a weapon.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_10',
          speakerId: 'char_cael',
          side: 'left',
          text: isChinese ? '仁慈会把敌人留在我们背后。' : 'Mercy leaves enemies behind us.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_11',
          speakerId: 'char_ysra',
          side: 'left',
          text: isChinese
              ? '屠杀会让四面八方都变成敌人。'
              : 'Slaughter makes enemies everywhere.',
        ),
        LivingDialogueLine(
          lineId: 'living_m01_line_12',
          speakerId: 'char_orsain',
          side: 'right',
          text: isChinese
              ? '够了。击败他们的王，清出通路，饶过投降者。'
              : 'Enough. Defeat their king, clear the causeway, and spare those who surrender.',
        ),
      ],
      aiAggression: .58,
      aiDefense: .52,
      aiObjectivePressure: .64,
      aiTileAppetite: .55,
    );
  }

  static int? _fairPrice(PieceType type) => switch (type) {
    PieceType.pawn => 6,
    PieceType.knight || PieceType.bishop => 14,
    PieceType.rook => 22,
    PieceType.queen => 40,
    PieceType.king => null,
  };

  static List<_FixedPieceSeed> _playerSeedsFor(
    LivingContentLocale contentLocale,
  ) => contentLocale == LivingContentLocale.simplifiedChinese
      ? _simplifiedChinesePlayerSeeds
      : _englishPlayerSeeds;

  static const _englishPlayerSeeds = <_FixedPieceSeed>[
    _FixedPieceSeed(
      pieceId: 'ashen_rook_ysra',
      pieceType: PieceType.rook,
      square: Square(7, 0),
      characterId: 'char_ysra',
      displayName: 'Dame Ysra Stonehand',
      originalIdentity: 'Veteran protector of the Ashen Court',
      portraitPath:
          'assets/runtime/pieces/characters/living/ysra_half_body.webp',
    ),
    _FixedPieceSeed(
      pieceId: 'ashen_bishop_veyl',
      pieceType: PieceType.bishop,
      square: Square(7, 2),
      characterId: 'char_veyl',
      displayName: 'Brother Veyl the Unshriven',
      originalIdentity: 'Forbidden chronicler of the Ashen Court',
      portraitPath:
          'assets/runtime/pieces/characters/living/veyl_half_body.webp',
    ),
    _FixedPieceSeed(
      pieceId: 'ashen_king_orsain',
      pieceType: PieceType.king,
      square: Square(7, 4),
      characterId: 'char_orsain',
      displayName: 'King Orsain Ashcrown',
      originalIdentity: 'Burdened ruler of the surviving Ashen Court',
      portraitPath:
          'assets/runtime/pieces/characters/living/orsain_half_body.webp',
    ),
    _FixedPieceSeed(
      pieceId: 'ashen_knight_cael',
      pieceType: PieceType.knight,
      square: Square(7, 6),
      characterId: 'char_cael',
      displayName: 'Cael of No Banner',
      originalIdentity: 'Ambitious outsider riding with the Ashen Court',
      portraitPath:
          'assets/runtime/pieces/characters/living/cael_half_body.webp',
    ),
  ];

  static const _simplifiedChinesePlayerSeeds = <_FixedPieceSeed>[
    _FixedPieceSeed(
      pieceId: 'ashen_rook_ysra',
      pieceType: PieceType.rook,
      square: Square(7, 0),
      characterId: 'char_ysra',
      displayName: '石手女爵伊丝拉',
      originalIdentity: '灰烬王庭的老练守护者',
      portraitPath:
          'assets/runtime/pieces/characters/living/ysra_half_body.webp',
    ),
    _FixedPieceSeed(
      pieceId: 'ashen_bishop_veyl',
      pieceType: PieceType.bishop,
      square: Square(7, 2),
      characterId: 'char_veyl',
      displayName: '未赦修士维尔',
      originalIdentity: '灰烬王庭的禁忌史官',
      portraitPath:
          'assets/runtime/pieces/characters/living/veyl_half_body.webp',
    ),
    _FixedPieceSeed(
      pieceId: 'ashen_king_orsain',
      pieceType: PieceType.king,
      square: Square(7, 4),
      characterId: 'char_orsain',
      displayName: '灰冠王奥赛因',
      originalIdentity: '背负幸存灰烬王庭的统治者',
      portraitPath:
          'assets/runtime/pieces/characters/living/orsain_half_body.webp',
    ),
    _FixedPieceSeed(
      pieceId: 'ashen_knight_cael',
      pieceType: PieceType.knight,
      square: Square(7, 6),
      characterId: 'char_cael',
      displayName: '无旗者凯尔',
      originalIdentity: '与灰烬王庭同行的野心旅骑',
      portraitPath:
          'assets/runtime/pieces/characters/living/cael_half_body.webp',
    ),
  ];

  static List<LivingNamedPieceRecord> _recruitablePoolFor(
    LivingContentLocale contentLocale,
  ) => contentLocale == LivingContentLocale.simplifiedChinese
      ? _simplifiedChineseRecruitablePool
      : _englishRecruitablePool;

  static const _englishRecruitablePool = <LivingNamedPieceRecord>[
    LivingNamedPieceRecord(
      name: 'Lady Maelin Cinderveil',
      characterId: 'char_maelin_cinderveil',
      pieceId: 'ashen_queen_maelin',
      pieceType: PieceType.queen,
      status: LivingNamedPieceStatus.undiscovered,
      recruitable: true,
      description: 'An Ashen claimant whose court vanished after the fire.',
      loyalty: 40,
      portraitPath: LivingPortraitFallbackResolver.maelinAsset,
      discoveredMission: 0,
      lastKnownMission: 0,
    ),
    LivingNamedPieceRecord(
      name: 'Warden Hadrik Emberwall',
      characterId: 'char_hadrik_emberwall',
      pieceId: 'ashen_rook_hadrik',
      pieceType: PieceType.rook,
      status: LivingNamedPieceStatus.undiscovered,
      recruitable: true,
      description: 'A fortress warden loyal to the laws of the fallen court.',
      loyalty: 75,
      portraitPath: LivingPortraitFallbackResolver.hadrikAsset,
      discoveredMission: 0,
      lastKnownMission: 0,
    ),
    LivingNamedPieceRecord(
      name: 'Sister Neris of the Last Bell',
      characterId: 'char_neris_last_bell',
      pieceId: 'ashen_bishop_neris',
      pieceType: PieceType.bishop,
      status: LivingNamedPieceStatus.undiscovered,
      recruitable: true,
      description: 'A keeper of funerary vows and unfinished oaths.',
      loyalty: 55,
      portraitPath: LivingPortraitFallbackResolver.nerisAsset,
      discoveredMission: 0,
      lastKnownMission: 0,
    ),
    LivingNamedPieceRecord(
      name: 'Ser Tavian Greyspur',
      characterId: 'char_tavian_greyspur',
      pieceId: 'ashen_knight_tavian',
      pieceType: PieceType.knight,
      status: LivingNamedPieceStatus.undiscovered,
      recruitable: true,
      description: 'A wandering Ashen rider who deserted before the burning.',
      loyalty: 60,
      portraitPath: LivingPortraitFallbackResolver.tavianAsset,
      discoveredMission: 0,
      lastKnownMission: 0,
    ),
  ];

  static const _simplifiedChineseRecruitablePool = <LivingNamedPieceRecord>[
    LivingNamedPieceRecord(
      name: '烬帷夫人梅琳',
      characterId: 'char_maelin_cinderveil',
      pieceId: 'ashen_queen_maelin',
      pieceType: PieceType.queen,
      status: LivingNamedPieceStatus.undiscovered,
      recruitable: true,
      description: '一位灰烬王位宣称者，她的王庭在大火后失踪。',
      loyalty: 40,
      portraitPath: LivingPortraitFallbackResolver.maelinAsset,
      discoveredMission: 0,
      lastKnownMission: 0,
    ),
    LivingNamedPieceRecord(
      name: '炽垒守望者哈德里克',
      characterId: 'char_hadrik_emberwall',
      pieceId: 'ashen_rook_hadrik',
      pieceType: PieceType.rook,
      status: LivingNamedPieceStatus.undiscovered,
      recruitable: true,
      description: '忠于陷落王庭旧法的要塞守望者。',
      loyalty: 75,
      portraitPath: LivingPortraitFallbackResolver.hadrikAsset,
      discoveredMission: 0,
      lastKnownMission: 0,
    ),
    LivingNamedPieceRecord(
      name: '终钟修女奈瑞丝',
      characterId: 'char_neris_last_bell',
      pieceId: 'ashen_bishop_neris',
      pieceType: PieceType.bishop,
      status: LivingNamedPieceStatus.undiscovered,
      recruitable: true,
      description: '守护葬仪誓言与未竟盟约的修女。',
      loyalty: 55,
      portraitPath: LivingPortraitFallbackResolver.nerisAsset,
      discoveredMission: 0,
      lastKnownMission: 0,
    ),
    LivingNamedPieceRecord(
      name: '灰刺骑士塔维安',
      characterId: 'char_tavian_greyspur',
      pieceId: 'ashen_knight_tavian',
      pieceType: PieceType.knight,
      status: LivingNamedPieceStatus.undiscovered,
      recruitable: true,
      description: '在大火前便已逃离的灰烬流浪骑士。',
      loyalty: 60,
      portraitPath: LivingPortraitFallbackResolver.tavianAsset,
      discoveredMission: 0,
      lastKnownMission: 0,
    ),
  ];
}

class _FixedPieceSeed {
  const _FixedPieceSeed({
    required this.pieceId,
    required this.pieceType,
    required this.square,
    this.characterId,
    this.displayName,
    this.originalIdentity,
    this.portraitPath,
  });

  final String pieceId;
  final PieceType pieceType;
  final Square square;
  final String? characterId;
  final String? displayName;
  final String? originalIdentity;
  final String? portraitPath;
}
