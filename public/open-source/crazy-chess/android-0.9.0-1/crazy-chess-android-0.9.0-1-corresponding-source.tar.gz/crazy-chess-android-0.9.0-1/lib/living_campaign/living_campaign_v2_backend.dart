import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:crypto/crypto.dart';

import '../domain/chess_models.dart';
import 'doubao_client.dart';
import 'living_campaign_archive_store.dart';
import 'living_campaign_generation_service.dart';
import 'living_campaign_models.dart';
import 'living_campaign_locale_contract.dart';
import 'living_campaign_prompt_library.dart';
import 'living_campaign_v2_schemas.dart';

abstract interface class LivingCampaignBackend {
  Future<LivingGenerationResult> generateChapterClosureText({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  });

  Future<LivingGenerationResult> retryChapterClosureText({
    required LivingCampaignRun run,
    required String chapterId,
  });

  Future<LivingGenerationResult> generateNextChapter({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  });

  Future<LivingGenerationResult> retryPortrait({
    required LivingCampaignRun run,
    required String characterId,
  });

  Future<LivingGenerationResult> generateChapterEndingArt({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  });

  Future<LivingGenerationResult> retryChapterEndingArt({
    required LivingCampaignRun run,
    required String chapterId,
  });
}

enum LivingCampaignPersistenceDomain { general, closureText, chapterArt }

abstract interface class LivingCampaignV2Gateway {
  String get textModel;
  String get imageModel;

  Future<DoubaoTokenizationResult> countTextTokens(Iterable<String> values);

  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    required Map<String, Object?> jsonSchema,
    required String jsonSchemaName,
    required int maxTokens,
    required double temperature,
    DoubaoStreamProgressCallback? onProgress,
  });

  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  });

  Future<DoubaoChapterArtResult> generateChapterEndingArt({
    required String prompt,
    required int seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  });

  Future<List<Uint8List>> loadPortraitStyleReferences();
}

class DoubaoLivingCampaignV2Gateway implements LivingCampaignV2Gateway {
  const DoubaoLivingCampaignV2Gateway(
    this.client, {
    Future<List<Uint8List>> Function()? loadPortraitStyleReferences,
  }) : _loadPortraitStyleReferences = loadPortraitStyleReferences;

  final DoubaoClient client;
  final Future<List<Uint8List>> Function()? _loadPortraitStyleReferences;

  @override
  String get textModel => client.settings.textModel;

  @override
  String get imageModel => client.settings.imageModel;

  @override
  Future<DoubaoTokenizationResult> countTextTokens(Iterable<String> values) =>
      client.countTextTokens(values);

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    required Map<String, Object?> jsonSchema,
    required String jsonSchemaName,
    required int maxTokens,
    required double temperature,
    DoubaoStreamProgressCallback? onProgress,
  }) => client.chatJson(
    systemPrompt: systemPrompt,
    userPayload: userPayload,
    jsonSchema: jsonSchema,
    jsonSchemaName: jsonSchemaName,
    strictJsonSchema: true,
    disableThinking: true,
    maxTokens: maxTokens,
    temperature: temperature,
    onProgress: onProgress,
  );

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) => client.generatePortrait(
    prompt: prompt,
    seed: seed,
    referenceImages: referenceImages,
    onSourceDownloaded: onSourceDownloaded,
  );

  @override
  Future<DoubaoChapterArtResult> generateChapterEndingArt({
    required String prompt,
    required int seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) => client.generateChapterEndingArt(
    prompt: prompt,
    seed: seed,
    referenceImages: referenceImages,
    onSourceDownloaded: onSourceDownloaded,
  );

  @override
  Future<List<Uint8List>> loadPortraitStyleReferences() async =>
      _loadPortraitStyleReferences == null
      ? const <Uint8List>[]
      : List<Uint8List>.unmodifiable(await _loadPortraitStyleReferences());
}

class LivingModelCapabilityProfile {
  const LivingModelCapabilityProfile({
    required this.contextTokens,
    this.compressionThreshold = .55,
    this.protocolSafetyTokens = 1024,
  });

  final int contextTokens;
  final double compressionThreshold;
  final int protocolSafetyTokens;

  int get compressionTriggerTokens =>
      (contextTokens * compressionThreshold).floor();

  int remainingOutputTokens(int inputTokens) =>
      contextTokens - inputTokens - protocolSafetyTokens;

  static LivingModelCapabilityProfile forModel(
    String model, {
    int? customContextTokens,
  }) {
    if (model == 'doubao-seed-2-1-turbo-260628') {
      return const LivingModelCapabilityProfile(contextTokens: 256000);
    }
    if (customContextTokens == null || customContextTokens <= 0) {
      throw const LivingProviderException(
        code: 'model_context_unknown',
        safeMessage:
            'Set the context size before using a custom Living Campaign model.',
      );
    }
    return LivingModelCapabilityProfile(contextTokens: customContextTokens);
  }
}

class LivingPortraitSeed {
  const LivingPortraitSeed._();

  static int derive({
    required String runId,
    required String missionId,
    required String characterId,
    required int attempt,
  }) {
    final digest = sha256.convert(
      utf8.encode('$runId|$missionId|$characterId|portrait|$attempt'),
    );
    final bytes = digest.bytes;
    final value =
        ((bytes[0] << 24) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3]) &
        0x7fffffff;
    return value == 0 ? 1 : value;
  }
}

class LivingChapterArtSeed {
  const LivingChapterArtSeed._();

  static int derive({
    required String runId,
    required String chapterId,
    required int attempt,
  }) {
    final digest = sha256.convert(
      utf8.encode('$runId|$chapterId|chapter_art|$attempt'),
    );
    final bytes = digest.bytes;
    final value =
        ((bytes[0] << 24) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3]) &
        0x7fffffff;
    return value == 0 ? 1 : value;
  }
}

class LivingPersistentCharacterId {
  const LivingPersistentCharacterId._();

  static String derive({
    required String runId,
    required String missionId,
    required String pieceId,
    required String eventType,
  }) {
    final digest = sha256.convert(
      utf8.encode('$runId|$missionId|$pieceId|$eventType'),
    );
    return 'char_${digest.toString().substring(0, 20)}';
  }
}

class LivingCampaignOutcomeReducer {
  const LivingCampaignOutcomeReducer();

  LivingCampaignRun apply({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
    required DateTime now,
  }) {
    final chapter = run.chapterPackages.firstWhere(
      (value) => value.chapterId == outcome.chapterId,
    );
    final named = Map<String, LivingNamedPieceRecord>.from(
      run.namedPiecesByName,
    );
    final finalPurchaseByPiece = <String, LivingPurchaseEventOutcome>{
      for (final event in outcome.purchaseEvents) event.pieceId: event,
    };
    final purchasedByPlayer = <String, LivingPurchasedPieceOutcome>{
      for (final piece in outcome.purchasedPieces) piece.pieceId: piece,
    };
    final transitionEvents = <LivingCanonEvent>[];

    for (final entry in named.entries.toList(growable: false)) {
      var record = entry.value;
      final purchase = finalPurchaseByPiece[record.pieceId];
      if (purchase != null) {
        final nextStatus = purchase.toAllegiance == LivingAllegiance.player
            ? LivingNamedPieceStatus.ally
            : purchase.toAllegiance == LivingAllegiance.enemy
            ? LivingNamedPieceStatus.enemy
            : record.status;
        final purchased = purchasedByPlayer[record.pieceId];
        record = record.copyWith(
          status: nextStatus,
          loyalty: purchased?.loyalty ?? record.loyalty,
          lastKnownMission: outcome.chapterNumber,
        );
        named[entry.key] = record;
        transitionEvents.add(
          LivingCanonEvent(
            eventId: '${outcome.chapterId}_purchase_${record.characterId}',
            chapterNumber: outcome.chapterNumber,
            type: LivingEventType.purchased,
            subjectIds: <String>[record.characterId],
            description:
                '${record.name} changed allegiance to ${nextStatus.name}.',
          ),
        );
        continue;
      }

      final captured = outcome.capturedPieces.any(
        (value) =>
            value.wasActuallyCaptured &&
            value.pieceType != PieceType.pawn &&
            (value.pieceId == record.pieceId ||
                value.characterId == record.characterId),
      );
      final checkmatedEnemyKing =
          outcome.result == LivingBattleResult.victory &&
          outcome.endReason == GameEndReason.checkmate &&
          record.pieceType == PieceType.king &&
          record.status == LivingNamedPieceStatus.enemy &&
          chapter.pieces.any(
            (piece) =>
                piece.color == PieceColor.black &&
                piece.characterId == record.characterId,
          );
      final trapfallen = outcome.kingTrapfallPieceId == record.pieceId;
      if (!captured && !checkmatedEnemyKing && !trapfallen) continue;

      final status = trapfallen
          ? LivingNamedPieceStatus.dead
          : fateFor(
              runId: run.runId,
              missionId: outcome.chapterId,
              characterName: record.name,
              eventType: checkmatedEnemyKing ? 'checkmate' : 'capture',
            );
      named[entry.key] = record.copyWith(
        status: status,
        lastKnownMission: outcome.chapterNumber,
      );
      transitionEvents.add(
        LivingCanonEvent(
          eventId: '${outcome.chapterId}_fate_${record.characterId}',
          chapterNumber: outcome.chapterNumber,
          type: status == LivingNamedPieceStatus.dead
              ? LivingEventType.killed
              : LivingEventType.missing,
          subjectIds: <String>[record.characterId],
          description: status == LivingNamedPieceStatus.dead
              ? '${record.name} was confirmed dead.'
              : '${record.name} vanished from the field but may still live.',
        ),
      );
    }

    final pendingPersistentPieces = <_PendingPersistentPiece>[];
    for (final state in outcome.pieceEndStates) {
      final endingType = state.endingType;
      if (endingType == null ||
          endingType == PieceType.pawn ||
          endingType == PieceType.king ||
          state.endingColor != PieceColor.white ||
          !state.finishedAlive ||
          named.values.any((record) => record.pieceId == state.pieceId)) {
        continue;
      }
      final ascended =
          state.startingType == PieceType.pawn && state.wasPromoted;
      final purchased = state.wasPurchased;
      if (!ascended && !purchased) continue;
      final originCountryId = chapter.pieces
          .where((piece) => piece.pieceId == state.pieceId)
          .map((piece) => piece.countryId)
          .firstOrNull;
      pendingPersistentPieces.add(
        _PendingPersistentPiece(
          pieceId: state.pieceId,
          characterId:
              state.characterId ??
              LivingPersistentCharacterId.derive(
                runId: run.runId,
                missionId: outcome.chapterId,
                pieceId: state.pieceId,
                eventType: ascended ? 'ascension' : 'purchase_identity',
              ),
          pieceType: endingType,
          loyalty: state.endingLoyalty ?? 60,
          originCountryId: originCountryId ?? 'unknown',
          ascended: ascended,
        ),
      );
    }
    if (outcome.pieceEndStates.isEmpty) {
      for (final purchased in outcome.purchasedPieces) {
        if (purchased.pieceType == PieceType.pawn ||
            purchased.pieceType == PieceType.king ||
            named.values.any((record) => record.pieceId == purchased.pieceId)) {
          continue;
        }
        pendingPersistentPieces.add(
          _PendingPersistentPiece(
            pieceId: purchased.pieceId,
            characterId:
                purchased.characterId ??
                LivingPersistentCharacterId.derive(
                  runId: run.runId,
                  missionId: outcome.chapterId,
                  pieceId: purchased.pieceId,
                  eventType: 'purchase_identity',
                ),
            pieceType: purchased.pieceType,
            loyalty: purchased.loyalty ?? 60,
            originCountryId: purchased.originCountryId,
            ascended: false,
          ),
        );
      }
    }
    for (final pending in pendingPersistentPieces) {
      final typeName = pending.pieceType.name;
      final title = pending.ascended
          ? 'The Ascended ${_title(typeName)}'
          : 'The Turncoat ${_title(typeName)}';
      final name = _uniqueProvisionalName(title, named);
      final characterId = pending.characterId;
      named[name] = LivingNamedPieceRecord(
        name: name,
        characterId: characterId,
        pieceId: pending.pieceId,
        pieceType: pending.pieceType,
        status: LivingNamedPieceStatus.ally,
        recruitable: false,
        description: pending.ascended
            ? 'A rank-and-file Ashen Pawn who ascended as a $typeName during '
                  '${outcome.chapterId}; a permanent name is still owed.'
            : 'An advanced ${pending.originCountryId} $typeName purchased into '
                  'the Ashen Court during ${outcome.chapterId}; a permanent '
                  'name is still owed.',
        loyalty: pending.loyalty,
        discoveredMission: outcome.chapterNumber,
        lastKnownMission: outcome.chapterNumber,
        needsNaming: true,
      );
      transitionEvents.add(
        LivingCanonEvent(
          eventId:
              '${outcome.chapterId}_${pending.ascended ? 'ascend' : 'join'}_$characterId',
          chapterNumber: outcome.chapterNumber,
          type: pending.ascended
              ? LivingEventType.promoted
              : LivingEventType.joined,
          subjectIds: <String>[characterId],
          description: pending.ascended
              ? '$name rose from the Pawn ranks and survived with the court.'
              : '$name joined the Ashen Court through purchase.',
        ),
      );
    }

    if (outcome.result == LivingBattleResult.victory) {
      final participantIds =
          chapter.pieces
              .where(
                (piece) =>
                    piece.color == PieceColor.white &&
                    piece.pieceType != PieceType.pawn &&
                    piece.characterId != null,
              )
              .map((piece) => piece.characterId!)
              .toSet()
            ..addAll(
              outcome.purchasedPieces
                  .map((piece) => piece.characterId)
                  .whereType<String>(),
            )
            ..addAll(pendingPersistentPieces.map((piece) => piece.characterId));
      final survivingIds = outcome.survivingPieceIds.toSet()
        ..addAll(
          outcome.pieceEndStates
              .where(
                (state) =>
                    state.finishedAlive &&
                    state.endingColor == PieceColor.white,
              )
              .map((state) => state.pieceId),
        )
        ..addAll(outcome.purchasedPieces.map((piece) => piece.pieceId));
      for (final entry in named.entries.toList(growable: false)) {
        final record = entry.value;
        if (record.pieceType == PieceType.king ||
            record.status != LivingNamedPieceStatus.ally ||
            !participantIds.contains(record.characterId) ||
            !survivingIds.contains(record.pieceId) ||
            record.loyalty == null) {
          continue;
        }
        named[entry.key] = record.copyWith(
          loyalty: math.min(100, record.loyalty! + 20),
          lastKnownMission: outcome.chapterNumber,
        );
      }
    }

    final playerKingTrapfall =
        outcome.endReason == GameEndReason.kingTrapfall &&
        outcome.kingTrapfallPieceId != null &&
        chapter.pieces.any(
          (piece) =>
              piece.color == PieceColor.white &&
              piece.pieceType == PieceType.king &&
              piece.pieceId == outcome.kingTrapfallPieceId,
        );
    final reward = outcome.result == LivingBattleResult.victory
        ? switch (outcome.pressureTier) {
            'pressured' => 20,
            'severe' => 35,
            'overwhelming' => 60,
            _ => 10,
          }
        : 0;

    final characters = Map<String, LivingCharacter>.from(
      run.canon.charactersById,
    );
    final roster = <String, LivingRosterPiece>{
      for (final entry in run.canon.playerRosterByPieceId.entries)
        if (entry.value.basePieceType != PieceType.pawn) entry.key: entry.value,
    };
    for (final record in named.values) {
      final existing = characters[record.characterId];
      final life = record.status == LivingNamedPieceStatus.dead
          ? LivingLifeState.dead
          : LivingLifeState.alive;
      final whereabouts = switch (record.status) {
        LivingNamedPieceStatus.ally => LivingWhereabouts.withCourt,
        LivingNamedPieceStatus.missing => LivingWhereabouts.missing,
        LivingNamedPieceStatus.enemy => LivingWhereabouts.unknown,
        LivingNamedPieceStatus.dead => LivingWhereabouts.missing,
        LivingNamedPieceStatus.undiscovered => LivingWhereabouts.unknown,
      };
      final allegiance = switch (record.status) {
        LivingNamedPieceStatus.ally => LivingAllegiance.player,
        LivingNamedPieceStatus.enemy => LivingAllegiance.enemy,
        _ => existing?.allegiance ?? LivingAllegiance.neutral,
      };
      characters[record.characterId] = existing == null
          ? LivingCharacter(
              characterId: record.characterId,
              originalName: record.name,
              originalIdentity: record.description,
              basePieceType: record.pieceType,
              linkedPieceId: record.pieceId,
              lifeState: life,
              whereabouts: whereabouts,
              allegiance: allegiance,
              firstChapter: record.discoveredMission,
              lastChapter: outcome.chapterNumber,
              portraitPath: record.portraitPath,
            )
          : existing.copyWith(
              lifeState: life,
              whereabouts: whereabouts,
              allegiance: allegiance,
              lastChapter: outcome.chapterNumber,
              portraitPath: existing.portraitPath ?? record.portraitPath,
            );
      if (record.status == LivingNamedPieceStatus.ally &&
          record.pieceType != PieceType.pawn) {
        roster[record.pieceId] = LivingRosterPiece(
          pieceId: record.pieceId,
          basePieceType: record.pieceType,
          characterId: record.characterId,
          origin: record.description,
          lifeState: life,
          whereabouts: whereabouts,
          allegiance: LivingAllegiance.player,
          rosterPosition: LivingRosterPosition.active,
        );
      } else {
        roster.remove(record.pieceId);
      }
    }

    final eventLedger = <LivingCanonEvent>[
      ...run.canon.eventLedger,
      LivingCanonEvent(
        eventId: '${outcome.chapterId}_result',
        chapterNumber: outcome.chapterNumber,
        type: outcome.result == LivingBattleResult.victory
            ? LivingEventType.battleWon
            : LivingEventType.battleLost,
        subjectIds: named.values
            .where((record) => record.status == LivingNamedPieceStatus.ally)
            .map((record) => record.characterId)
            .toList(growable: false),
        description:
            '${outcome.result.name} after ${outcome.completedRoundCount} completed rounds.',
      ),
      ...transitionEvents,
    ];

    return run.copyWith(
      status: playerKingTrapfall ? LivingRunStatus.completed : run.status,
      completedAt: playerKingTrapfall ? now : run.completedAt,
      epilogue: playerKingTrapfall
          ? 'The Ruined Causeway claimed Orsain and the unfinished crown. The '
                'survivors carried the Ashen name onward, but this reign ended '
                'where the road broke beneath its King.'
          : run.epilogue,
      updatedAt: now,
      battleOutcomes:
          run.battleOutcomes.any(
            (value) => value.chapterId == outcome.chapterId,
          )
          ? run.battleOutcomes
          : <LivingBattleOutcomeSnapshot>[...run.battleOutcomes, outcome],
      namedPiecesByName: named,
      canon: run.canon.copyWith(
        revision: run.canon.revision + 1,
        gold: outcome.goldAfterBattle + reward,
        playerRosterByPieceId: roster,
        charactersById: characters,
        eventLedger: eventLedger,
      ),
      v2GenerationCheckpoint: LivingV2GenerationCheckpoint(
        outcomeMissionId: outcome.chapterId,
      ),
      clearGenerationCheckpoint: true,
    );
  }

  LivingNamedPieceStatus fateFor({
    required String runId,
    required String missionId,
    required String characterName,
    required String eventType,
  }) {
    final digest = sha256.convert(
      utf8.encode('$runId|$missionId|$characterName|$eventType'),
    );
    return digest.bytes.first.isEven
        ? LivingNamedPieceStatus.dead
        : LivingNamedPieceStatus.missing;
  }

  static String _title(String value) => value
      .trim()
      .split(RegExp(r'\s+'))
      .where((part) => part.isNotEmpty)
      .map((part) => '${part[0].toUpperCase()}${part.substring(1)}')
      .join(' ');

  static String _uniqueProvisionalName(
    String base,
    Map<String, LivingNamedPieceRecord> named,
  ) {
    if (!named.containsKey(base)) return base;
    var number = 2;
    while (named.containsKey('$base $number')) {
      number++;
    }
    return '$base $number';
  }
}

class _PendingPersistentPiece {
  const _PendingPersistentPiece({
    required this.pieceId,
    required this.characterId,
    required this.pieceType,
    required this.loyalty,
    required this.originCountryId,
    required this.ascended,
  });

  final String pieceId;
  final String characterId;
  final PieceType pieceType;
  final int loyalty;
  final String originCountryId;
  final bool ascended;
}

class LivingCampaignDeployment {
  const LivingCampaignDeployment();

  List<LivingMissionPiece> buildPlayerPieces({
    required LivingCampaignRun run,
    required List<String> participantCharacterIds,
  }) {
    final records = <LivingNamedPieceRecord>[];
    for (final id in participantCharacterIds) {
      final record = run.namedPiecesByName.values
          .where((candidate) => candidate.characterId == id)
          .firstOrNull;
      if (record != null &&
          record.status == LivingNamedPieceStatus.ally &&
          record.pieceType != PieceType.pawn) {
        records.add(record);
      }
    }
    records.sort((a, b) {
      if (a.pieceType == PieceType.king) return -1;
      if (b.pieceType == PieceType.king) return 1;
      return participantCharacterIds
          .indexOf(a.characterId)
          .compareTo(participantCharacterIds.indexOf(b.characterId));
    });

    final occupied = <int>{};
    final advanced = <LivingMissionPiece>[];
    for (final record in records.take(8)) {
      final preferred = _standardColumns[record.pieceType] ?? const <int>[];
      final col =
          preferred.where((value) => !occupied.contains(value)).firstOrNull ??
          List<int>.generate(
            8,
            (value) => value,
          ).where((value) => !occupied.contains(value)).first;
      occupied.add(col);
      advanced.add(
        LivingMissionPiece(
          pieceId: record.pieceId,
          pieceType: record.pieceType,
          color: PieceColor.white,
          square: Square(7, col),
          countryId: 'ashen',
          loyalty: record.pieceType == PieceType.king ? null : record.loyalty,
          fairPrice: _fairPrice(record.pieceType),
          characterId: record.characterId,
        ),
      );
    }
    return <LivingMissionPiece>[
      ...advanced,
      for (final piece in advanced)
        LivingMissionPiece(
          pieceId:
              'm${(run.activeChapterNumber + 1).toString().padLeft(2, '0')}_white_pawn_${piece.square.col}',
          pieceType: PieceType.pawn,
          color: PieceColor.white,
          square: Square(6, piece.square.col),
          countryId: 'ashen',
          loyalty: 60,
          fairPrice: 6,
        ),
    ];
  }

  static const Map<PieceType, List<int>> _standardColumns =
      <PieceType, List<int>>{
        PieceType.king: <int>[4],
        PieceType.queen: <int>[3],
        PieceType.rook: <int>[0, 7],
        PieceType.bishop: <int>[2, 5],
        PieceType.knight: <int>[1, 6],
      };

  static int? _fairPrice(PieceType type) => switch (type) {
    PieceType.pawn => 6,
    PieceType.knight || PieceType.bishop => 14,
    PieceType.rook => 22,
    PieceType.queen => 40,
    PieceType.king => null,
  };
}

class LivingCampaignV2Validator {
  const LivingCampaignV2Validator();

  List<String> validateMemory({
    required LivingMissionMemory memory,
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  }) {
    final issues = <String>[];
    if (memory.missionId != outcome.chapterId ||
        memory.missionNumber != outcome.chapterNumber ||
        memory.runId != run.runId) {
      issues.add('Chronicler identity does not match the completed mission.');
    }
    if (!_oneOrTwoSentences(memory.setupSummary)) {
      issues.add('setupSummary must contain one or two sentences.');
    }
    if (!_oneOrTwoSentences(memory.battleSummary)) {
      issues.add('battleSummary must contain one or two sentences.');
    }
    if (RegExp(
      r'\bpawn\b',
      caseSensitive: false,
    ).hasMatch('${memory.setupSummary} ${memory.battleSummary}')) {
      issues.add('MissionMemory must not track individual Pawns.');
    }
    final knownIds = run.namedPiecesByName.values
        .map((record) => record.characterId)
        .toSet();
    if (memory.characterIds.any((id) => !knownIds.contains(id))) {
      issues.add('MissionMemory references an unknown named character.');
    }
    return issues;
  }

  List<String> validateChroniclerClosure({
    required LivingChroniclerClosureResult closure,
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  }) {
    final issues = validateMemory(
      memory: closure.memory,
      run: run,
      outcome: outcome,
    );
    if (closure.aftermath.runId != run.runId ||
        closure.aftermath.missionId != outcome.chapterId ||
        closure.aftermath.missionNumber != outcome.chapterNumber) {
      issues.add('Aftermath identity does not match the completed mission.');
    }

    final pending = run.namedPiecesByName.values
        .where((record) => record.needsNaming)
        .toList(growable: false);
    final pendingIds = pending.map((record) => record.characterId).toSet();
    final assignedIds = closure.identityAssignments
        .map((assignment) => assignment.characterId)
        .toList(growable: false);
    if (assignedIds.length != assignedIds.toSet().length ||
        assignedIds.toSet().difference(pendingIds).isNotEmpty ||
        pendingIds.difference(assignedIds.toSet()).isNotEmpty) {
      issues.add(
        'Chronicler must assign exactly one identity to every pending character.',
      );
    }
    final permanentNames = closure.identityAssignments
        .map((assignment) => assignment.name.trim().toLowerCase())
        .toList(growable: false);
    if (permanentNames.length != permanentNames.toSet().length) {
      issues.add('Chronicler permanent names must be unique.');
    }
    final establishedNames = run.namedPiecesByName.values
        .where((record) => !record.needsNaming)
        .map((record) => record.name.trim().toLowerCase())
        .toSet();
    for (final assignment in closure.identityAssignments) {
      if (assignment.name.trim().isEmpty ||
          assignment.description.trim().isEmpty ||
          assignment.portraitAppearanceBrief.trim().isEmpty) {
        issues.add('Identity assignments require name, description, and art.');
      }
      if (establishedNames.contains(assignment.name.trim().toLowerCase())) {
        issues.add('A permanent identity duplicates an established name.');
      }
      if (RegExp(
        r'\bchar_|\bpiece[_-]|\b(?:enemy|white|black)\s+(?:king|queen|rook|bishop|knight)\s+[a-h][1-8]\b',
        caseSensitive: false,
      ).hasMatch(assignment.name)) {
        issues.add('A permanent identity exposes a machine label.');
      }
    }

    final allowedSpeakers = _eligibleAftermathSpeakers(run, outcome)
      ..addAll(pendingIds);
    final lineIds = <String>{};
    if (closure.aftermath.lines.isEmpty) {
      issues.add('Aftermath must contain narration or dialogue.');
    }
    for (final line in closure.aftermath.lines) {
      if (!lineIds.add(line.lineId) || line.text.trim().isEmpty) {
        issues.add('Aftermath line IDs must be unique and text non-empty.');
      }
      if (!const <String>{'left', 'right', 'center'}.contains(line.side)) {
        issues.add('Aftermath presentation side is invalid.');
      }
      if (line.speakerId == null) {
        if (line.side != 'center') {
          issues.add('Speakerless aftermath narration must be centered.');
        }
      } else if (!allowedSpeakers.contains(line.speakerId)) {
        issues.add(
          'Aftermath uses a dead, missing, absent, or unknown speaker.',
        );
      }
      if (RegExp(r'\bchar_[A-Za-z0-9_-]+\b').hasMatch(line.text)) {
        issues.add('Aftermath text exposes a raw character ID.');
      }
    }
    return issues;
  }

  Set<String> _eligibleAftermathSpeakers(
    LivingCampaignRun run,
    LivingBattleOutcomeSnapshot outcome,
  ) {
    final endStates = <String, LivingPieceEndState>{
      for (final state in outcome.pieceEndStates) state.pieceId: state,
    };
    final chapter = run.chapterPackages.firstWhere(
      (candidate) => candidate.chapterId == outcome.chapterId,
    );
    final result = <String>{};
    for (final piece in chapter.pieces) {
      final characterId = piece.characterId;
      if (characterId == null) continue;
      final record = run.namedPiecesByName.values
          .where((candidate) => candidate.characterId == characterId)
          .firstOrNull;
      if (record == null ||
          record.status == LivingNamedPieceStatus.dead ||
          record.status == LivingNamedPieceStatus.missing) {
        continue;
      }
      final state = endStates[piece.pieceId];
      if (outcome.pieceEndStates.isNotEmpty && state?.finishedAlive != true) {
        continue;
      }
      result.add(characterId);
    }
    for (final record in run.namedPiecesByName.values) {
      if (!record.needsNaming || record.status != LivingNamedPieceStatus.ally) {
        continue;
      }
      final state = endStates[record.pieceId];
      if (outcome.pieceEndStates.isEmpty || state?.finishedAlive == true) {
        result.add(record.characterId);
      }
    }
    return result;
  }

  List<String> validateDirector({
    required LivingV2DirectorDecision decision,
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  }) {
    final issues = <String>[];
    if (decision.schemaVersion != 2 || decision.runId != run.runId) {
      issues.add('Director schema or run identity is stale.');
    }
    if (decision.basedOnMissionNumber != outcome.chapterNumber ||
        decision.nextMissionNumber != outcome.chapterNumber + 1) {
      issues.add('Director mission sequence is invalid.');
    }
    if (decision.title.trim().isEmpty ||
        decision.subtitle.trim().isEmpty ||
        decision.background.trim().isEmpty) {
      issues.add('Director story fields must be non-empty.');
    }
    if (decision.objectiveType == LivingObjectiveType.checkmate) {
      issues.add('Generated primary objective cannot be checkmate.');
    }
    if (!const <String>{
      'even',
      'pressured',
      'severe',
      'overwhelming',
    }.contains(decision.pressureTier)) {
      issues.add('Director pressure tier is invalid.');
    }
    if (!const <int>{0, 10, 20, 35, 60}.contains(decision.rewardTier)) {
      issues.add('Director reward tier is invalid.');
    }
    final recordsById = <String, LivingNamedPieceRecord>{
      for (final record in run.namedPiecesByName.values)
        record.characterId: record,
    };
    final effectiveRecordsById = Map<String, LivingNamedPieceRecord>.from(
      recordsById,
    );
    final changedIds = <String>{};
    for (final change in decision.statusChanges) {
      final record = recordsById[change.characterId];
      if (!changedIds.add(change.characterId)) {
        issues.add('Director statusChanges contains a duplicate character.');
        continue;
      }
      if (record == null ||
          record.status != change.fromStatus ||
          !const <LivingNamedPieceStatus>{
            LivingNamedPieceStatus.undiscovered,
            LivingNamedPieceStatus.missing,
          }.contains(change.fromStatus)) {
        issues.add('Director status change has a stale source status.');
        continue;
      }
      if (!const <LivingNamedPieceStatus>{
        LivingNamedPieceStatus.ally,
        LivingNamedPieceStatus.enemy,
      }.contains(change.toStatus)) {
        issues.add('Director status change has an invalid destination.');
        continue;
      }
      if (change.toStatus == LivingNamedPieceStatus.ally &&
          !record.recruitable) {
        issues.add('Only a recruitable named piece may join as an ally.');
        continue;
      }
      if (change.reason.trim().isEmpty) {
        issues.add('Director status change requires a story reason.');
        continue;
      }
      effectiveRecordsById[change.characterId] = record.copyWith(
        status: change.toStatus,
        lastKnownMission: decision.nextMissionNumber,
      );
    }
    final participants = decision.participantCharacterIds;
    if (participants.length != participants.toSet().length ||
        participants.isEmpty ||
        participants.length > 8) {
      issues.add('Director participant list must contain 1–8 unique allies.');
    }
    final participantRecords = participants
        .map((id) => effectiveRecordsById[id])
        .whereType<LivingNamedPieceRecord>()
        .toList();
    if (participantRecords.length != participants.length ||
        participantRecords.any(
          (record) => record.status != LivingNamedPieceStatus.ally,
        )) {
      issues.add('Director participants must be current named allies.');
    }
    if (participantRecords
            .where((record) => record.pieceType == PieceType.king)
            .length !=
        1) {
      issues.add('Director must deploy exactly one living player King.');
    }
    final newCharacter = decision.newCharacter;
    final speakerIds = <String>{
      ...recordsById.keys,
      if (newCharacter != null) newCharacter.characterId,
    };
    if (decision.dialogue.length < 2 ||
        decision.dialogue.any(
          (line) =>
              line.text.trim().isEmpty || !speakerIds.contains(line.speakerId),
        )) {
      issues.add('Director dialogue must use valid named speakers.');
    }
    if (newCharacter != null) {
      if (recordsById.containsKey(newCharacter.characterId) ||
          run.namedPiecesByName.containsKey(newCharacter.name)) {
        issues.add('Director newCharacter duplicates an existing identity.');
      }
      if (newCharacter.pieceType == PieceType.pawn) {
        issues.add('A Pawn cannot become a persistent named character.');
      }
      if (newCharacter.status != LivingNamedPieceStatus.enemy ||
          newCharacter.recruitable) {
        issues.add('A generated character must be a non-recruitable enemy.');
      }
      if (newCharacter.pieceType == PieceType.king &&
          newCharacter.loyalty != null) {
        issues.add('Kings cannot have Loyalty.');
      }
    }
    if (decision.enemyNamedCharacterIds.length !=
            decision.enemyNamedCharacterIds.toSet().length ||
        decision.enemyNamedCharacterIds.any(
          (id) =>
              effectiveRecordsById[id]?.status !=
                  LivingNamedPieceStatus.enemy &&
              !(newCharacter?.characterId == id &&
                  newCharacter?.status == LivingNamedPieceStatus.enemy),
        )) {
      issues.add('Director named enemies must be unique current enemies.');
    }
    if (decision.campaignComplete && outcome.chapterNumber < 2) {
      issues.add('An ordinary M01 result cannot directly end the campaign.');
    }
    if (decision.campaignComplete != (decision.epilogue != null)) {
      issues.add('Only a completed campaign may provide an epilogue.');
    }
    switch (decision.objectiveType) {
      case LivingObjectiveType.reachEscape:
        if (decision.targetSquare == null) {
          issues.add('reachEscape requires a targetSquare.');
        }
      case LivingObjectiveType.surviveRounds:
        if ((decision.surviveRounds ?? 0) < 18) {
          issues.add('surviveRounds requires at least 18 completed rounds.');
        }
        if (decision.pressureTier == 'even') {
          issues.add('surviveRounds cannot use even pressure.');
        }
      case LivingObjectiveType.neutralizeTarget:
        if (decision.targetCharacterId == null) {
          issues.add('neutralizeTarget requires targetCharacterId.');
        }
      case LivingObjectiveType.rescueRecover:
        if (decision.targetCharacterId == null ||
            decision.targetSquare == null) {
          issues.add(
            'rescueRecover requires targetCharacterId and targetSquare.',
          );
        }
      case LivingObjectiveType.checkmate:
        break;
    }
    return issues;
  }

  List<String> validateBuilder({
    required LivingV2BuilderDecision builder,
    required LivingV2DirectorDecision director,
    required LivingCampaignRun run,
  }) {
    final issues = <String>[];
    if (builder.schemaVersion != 2 ||
        builder.runId != run.runId ||
        builder.missionNumber != director.nextMissionNumber) {
      issues.add(
        'Builder identity does not match the locked Director mission.',
      );
    }
    final pieces = builder.enemyPieces;
    if (pieces.isEmpty || pieces.length > 16) {
      issues.add('Enemy squad must contain 1–16 pieces.');
    }
    if (pieces.where((piece) => piece.pieceType == PieceType.king).length !=
        1) {
      issues.add('Enemy squad must contain exactly one King.');
    }
    if (pieces.where((piece) => piece.pieceType == PieceType.pawn).length > 8) {
      issues.add('Enemy squad may contain at most eight Pawns.');
    }
    if (pieces.any((piece) => piece.color != PieceColor.black)) {
      issues.add('Every Builder piece must belong to Black.');
    }
    if (pieces.map((piece) => piece.square).toSet().length != pieces.length ||
        pieces.map((piece) => piece.pieceId).toSet().length != pieces.length) {
      issues.add('Enemy piece IDs and squares must be unique.');
    }
    for (final piece in pieces) {
      if (piece.pieceType == PieceType.king) {
        if (piece.loyalty != null || piece.fairPrice != null) {
          issues.add('Enemy King must use null Loyalty and fairPrice.');
        }
      } else if (piece.loyalty == null ||
          piece.loyalty! < 0 ||
          piece.loyalty! > 100 ||
          piece.fairPrice == null ||
          piece.fairPrice! < 1) {
        issues.add('Enemy non-Kings need valid Loyalty and fairPrice.');
      }
      if (piece.pieceType == PieceType.pawn && piece.characterId != null) {
        issues.add('Enemy Pawns cannot have named character IDs.');
      }
    }
    final expectedNamed = director.enemyNamedCharacterIds.toSet()
      ..addAll(<String>{
        if (director.newCharacter?.status == LivingNamedPieceStatus.enemy)
          director.newCharacter!.characterId,
      });
    final actualNamed = pieces
        .map((piece) => piece.characterId)
        .whereType<String>()
        .toSet();
    if (!actualNamed.containsAll(expectedNamed)) {
      issues.add('Builder omitted a locked named enemy character.');
    }
    return issues;
  }

  List<String> builderWarnings({required LivingV2BuilderDecision builder}) {
    final forward = builder.enemyPieces
        .where((piece) => piece.square.row > 3)
        .map((piece) => '${piece.pieceId}:${livingSquareName(piece.square)}')
        .toList(growable: false);
    return forward.isEmpty
        ? const <String>[]
        : <String>[
            'Enemy placement crossed the preferred ranks 5–8: '
                '${forward.join(', ')}.',
          ];
  }

  List<String> validateChapter(LivingChapterPackage chapter) {
    final issues = <String>[];
    final pieces = chapter.pieces;
    if (pieces.map((piece) => piece.square).toSet().length != pieces.length ||
        pieces.map((piece) => piece.pieceId).toSet().length != pieces.length) {
      issues.add('Chapter has overlapping squares or duplicate piece IDs.');
    }
    for (final color in PieceColor.values) {
      if (pieces
              .where(
                (piece) =>
                    piece.color == color && piece.pieceType == PieceType.king,
              )
              .length !=
          1) {
        issues.add('Chapter must have exactly one ${color.name} King.');
      }
    }
    final kings = pieces
        .where((piece) => piece.pieceType == PieceType.king)
        .toList();
    if (kings.length == 2 &&
        (kings[0].square.row - kings[1].square.row).abs() <= 1 &&
        (kings[0].square.col - kings[1].square.col).abs() <= 1) {
      issues.add('Kings cannot begin adjacent.');
    }
    return issues;
  }

  bool _oneOrTwoSentences(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) return false;
    final count = RegExp(
      r'[.!?。！？](?:[\"”’)]?)(?=\s|$|[\u3400-\u9fff])',
    ).allMatches(trimmed).length;
    return count >= 1 && count <= 2;
  }
}

class LivingCampaignV2Backend implements LivingCampaignBackend {
  LivingCampaignV2Backend({
    required LivingCampaignV2Gateway gateway,
    required LivingCampaignArchiveStore archive,
    LivingCampaignPromptLibrary? promptLibrary,
    LivingCampaignV2Validator validator = const LivingCampaignV2Validator(),
    LivingCampaignOutcomeReducer outcomeReducer =
        const LivingCampaignOutcomeReducer(),
    LivingCampaignDeployment deployment = const LivingCampaignDeployment(),
    LivingModelCapabilityProfile? capability,
    int? customContextTokens,
    DateTime Function()? clock,
    String Function(String prefix)? idFactory,
    FutureOr<void> Function(LivingCampaignRun run)? onProgress,
    bool generatePortraits = true,
    LivingCampaignRunMutationCoordinator? mutationCoordinator,
    this.persistenceDomain = LivingCampaignPersistenceDomain.general,
  }) : _gateway = gateway,
       _archive = archive,
       _promptLibrary = promptLibrary ?? AssetLivingCampaignPromptLibrary(),
       _validator = validator,
       _outcomeReducer = outcomeReducer,
       _deployment = deployment,
       _capability =
           capability ??
           LivingModelCapabilityProfile.forModel(
             gateway.textModel,
             customContextTokens: customContextTokens,
           ),
       _clock = clock ?? DateTime.now,
       _idFactory = idFactory ?? _defaultId,
       _onProgress = onProgress,
       _generatePortraits = generatePortraits,
       _mutationCoordinator =
           mutationCoordinator ??
           LivingCampaignRunMutationCoordinator.forArchive(archive);

  final LivingCampaignV2Gateway _gateway;
  final LivingCampaignArchiveStore _archive;
  final LivingCampaignPromptLibrary _promptLibrary;
  final LivingCampaignV2Validator _validator;
  final LivingCampaignOutcomeReducer _outcomeReducer;
  final LivingCampaignDeployment _deployment;
  final LivingModelCapabilityProfile _capability;
  final DateTime Function() _clock;
  final String Function(String prefix) _idFactory;
  final FutureOr<void> Function(LivingCampaignRun run)? _onProgress;
  final bool _generatePortraits;
  final LivingCampaignRunMutationCoordinator _mutationCoordinator;
  final LivingCampaignPersistenceDomain persistenceDomain;

  static int _serial = 0;
  static String _defaultId(String prefix) =>
      '$prefix-${DateTime.now().toUtc().microsecondsSinceEpoch}-${++_serial}';

  @override
  Future<LivingGenerationResult> generateChapterClosureText({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  }) async {
    await _archive.initialize();
    var current = run;
    final existingOutcome = current.battleOutcomes.any(
      (candidate) => candidate.chapterId == outcome.chapterId,
    );
    if (!existingOutcome) {
      current = _outcomeReducer.apply(
        run: current,
        outcome: outcome,
        now: _clock(),
      );
      await _persist(current);
    }
    if (current.v2GenerationCheckpoint?.outcomeMissionId != outcome.chapterId) {
      return _validationFailure(
        current,
        'The chapter closure belongs to another battle outcome.',
      );
    }
    if (current.v2GenerationCheckpoint?.missionMemory != null &&
        current.aftermathScenesByChapterId.containsKey(outcome.chapterId)) {
      return LivingGenerationResult(run: current, completed: true);
    }

    final startedAt = _clock();
    final closures = Map<String, LivingChapterClosureCheckpoint>.from(
      current.chapterClosureCheckpointsByChapterId,
    );
    final previous = closures[outcome.chapterId];
    closures[outcome.chapterId] =
        previous?.copyWith(
          textStatus: LivingClosureTaskStatus.running,
          updatedAt: startedAt,
          clearTextFailure: true,
        ) ??
        LivingChapterClosureCheckpoint(
          runId: current.runId,
          chapterId: outcome.chapterId,
          chapterNumber: outcome.chapterNumber,
          closureId: _idFactory('closure'),
          textTaskId: _idFactory('closure-text'),
          imageTaskId: _idFactory('closure-image'),
          textAttempt: 1,
          imageAttempt: 1,
          textStatus: LivingClosureTaskStatus.running,
          imageStatus: LivingClosureTaskStatus.pending,
          createdAt: startedAt,
          updatedAt: startedAt,
        );
    current = current.copyWith(
      updatedAt: startedAt,
      chapterClosureCheckpointsByChapterId: closures,
    );
    await _persist(current);

    try {
      final payload = _chroniclerPayload(current, outcome);
      final primary = await _callStage(
        run: current,
        stage: LivingGenerationStage.chronicler,
        attempt: closures[outcome.chapterId]!.textAttempt,
        prompt: LivingCampaignPrompt.chronicler,
        payload: payload,
        schema: LivingCampaignV2Schemas.chronicler,
        schemaName: LivingCampaignV2Schemas.chroniclerName,
      );
      current = primary.run;
      LivingChroniclerClosureResult? closure;
      var issues = <String>[];
      try {
        closure = LivingChroniclerClosureResult.fromJson(
          primary.response.value,
        );
        issues = _validator.validateChroniclerClosure(
          closure: closure,
          run: current,
          outcome: outcome,
        );
        issues.addAll(
          LivingChineseContentValidator.validateResponse(
            primary.response.value,
            current.contentLocale,
          ),
        );
      } on Object catch (error) {
        issues = <String>['Chronicler response could not be decoded: $error'];
      }
      if (closure == null || issues.isNotEmpty) {
        current = await _recordValidationIssues(current, issues);
        final repair = await _callStage(
          run: current,
          stage: LivingGenerationStage.chroniclerRepair,
          attempt: closures[outcome.chapterId]!.textAttempt + 1,
          prompt: LivingCampaignPrompt.chroniclerRepair,
          payload: <String, Object?>{
            ...payload,
            'invalidResponse': primary.response.value,
            'validationIssues': issues,
          },
          schema: LivingCampaignV2Schemas.chronicler,
          schemaName: LivingCampaignV2Schemas.chroniclerName,
          repairsRecordId: current.generationRecords.last.recordId,
        );
        current = repair.run;
        try {
          closure = LivingChroniclerClosureResult.fromJson(
            repair.response.value,
          );
          issues = _validator.validateChroniclerClosure(
            closure: closure,
            run: current,
            outcome: outcome,
          );
          issues.addAll(
            LivingChineseContentValidator.validateResponse(
              repair.response.value,
              current.contentLocale,
            ),
          );
        } on Object catch (error) {
          issues = <String>['Repaired Chronicler response is invalid: $error'];
        }
        if (closure == null || issues.isNotEmpty) {
          current = await _recordValidationIssues(current, issues);
          return _closureTextFailure(
            current,
            outcome.chapterId,
            'aftermath_invalid',
            issues.join(' '),
          );
        }
      }
      current = _acceptChroniclerClosure(current, closure, outcome);
      await _persist(current);
      return LivingGenerationResult(run: current, completed: true);
    } on _LivingV2CallFailure catch (failure) {
      return _closureTextFailure(
        failure.run,
        outcome.chapterId,
        failure.error.code,
        failure.error.safeMessage,
      );
    }
  }

  @override
  Future<LivingGenerationResult> retryChapterClosureText({
    required LivingCampaignRun run,
    required String chapterId,
  }) async {
    final closure = run.chapterClosureCheckpointsByChapterId[chapterId];
    final outcome = run.battleOutcomes
        .where((candidate) => candidate.chapterId == chapterId)
        .firstOrNull;
    if (closure == null ||
        closure.textStatus != LivingClosureTaskStatus.awaitingRetry ||
        outcome == null) {
      return LivingGenerationResult(
        run: run,
        completed: false,
        message: 'Those words are not waiting to be recalled.',
      );
    }
    final checkpoints =
        Map<String, LivingChapterClosureCheckpoint>.from(
            run.chapterClosureCheckpointsByChapterId,
          )
          ..[chapterId] = closure.copyWith(
            textAttempt: closure.textAttempt + 1,
            textStatus: LivingClosureTaskStatus.pending,
            updatedAt: _clock(),
            clearTextFailure: true,
          );
    final retryRun = run.copyWith(
      updatedAt: _clock(),
      chapterClosureCheckpointsByChapterId: checkpoints,
    );
    await _persist(retryRun);
    return generateChapterClosureText(run: retryRun, outcome: outcome);
  }

  @override
  Future<LivingGenerationResult> generateNextChapter({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  }) async {
    await _archive.initialize();
    if (run.status != LivingRunStatus.active ||
        outcome.chapterNumber != run.activeChapterNumber ||
        run.chapterPackages.any(
          (chapter) => chapter.chapterNumber == outcome.chapterNumber + 1,
        )) {
      return LivingGenerationResult(
        run: run,
        completed: false,
        message: 'The verified outcome cannot generate this next mission.',
      );
    }
    var current = run;
    try {
      final checkpoint = current.v2GenerationCheckpoint;
      if (checkpoint == null) {
        current = _outcomeReducer.apply(
          run: current,
          outcome: outcome,
          now: _clock(),
        );
        await _persist(current);
      } else if (checkpoint.outcomeMissionId != outcome.chapterId) {
        return _validationFailure(
          current,
          'The V2 checkpoint belongs to another battle outcome.',
        );
      }
      var memory = current.v2GenerationCheckpoint?.missionMemory;
      if (memory == null) {
        final closure = await generateChapterClosureText(
          run: current,
          outcome: outcome,
        );
        current = closure.run;
        if (!closure.completed) return closure;
        memory = current.v2GenerationCheckpoint?.missionMemory;
      }
      if (current.status == LivingRunStatus.completed) {
        return LivingGenerationResult(run: current, completed: true);
      }

      var decision = current.v2GenerationCheckpoint?.directorDecision;
      if (decision == null) {
        final prepared = await _prepareDirectorPayload(current);
        current = prepared.run;
        final primary = await _callStage(
          run: current,
          stage: LivingGenerationStage.director,
          attempt: 1,
          prompt: LivingCampaignPrompt.director,
          payload: prepared.payload,
          schema: LivingCampaignV2Schemas.director,
          schemaName: LivingCampaignV2Schemas.directorName,
        );
        current = primary.run;
        var issues = <String>[];
        try {
          decision = LivingV2DirectorDecision.fromJson(primary.response.value);
          issues = _validator.validateDirector(
            decision: decision,
            run: current,
            outcome: outcome,
          );
          issues.addAll(
            LivingChineseContentValidator.validateResponse(
              primary.response.value,
              current.contentLocale,
            ),
          );
        } on Object catch (error) {
          issues = <String>['Director response could not be decoded: $error'];
        }
        if (decision == null || issues.isNotEmpty) {
          current = await _recordValidationIssues(current, issues);
          final repair = await _callStage(
            run: current,
            stage: LivingGenerationStage.directorRepair,
            attempt: 2,
            prompt: LivingCampaignPrompt.directorRepair,
            payload: <String, Object?>{
              ...prepared.payload,
              'invalidResponse': primary.response.value,
              'validationIssues': issues,
            },
            schema: LivingCampaignV2Schemas.director,
            schemaName: LivingCampaignV2Schemas.directorName,
            repairsRecordId: current.generationRecords.last.recordId,
          );
          current = repair.run;
          try {
            decision = LivingV2DirectorDecision.fromJson(repair.response.value);
            issues = _validator.validateDirector(
              decision: decision,
              run: current,
              outcome: outcome,
            );
            issues.addAll(
              LivingChineseContentValidator.validateResponse(
                repair.response.value,
                current.contentLocale,
              ),
            );
          } on Object catch (error) {
            issues = <String>['Repaired Director response is invalid: $error'];
          }
          if (decision == null || issues.isNotEmpty) {
            current = await _recordValidationIssues(current, issues);
            return _validationFailure(current, issues.join(' '));
          }
        }
        current = _acceptDirector(current, decision);
        await _persist(current);
      }

      if (decision.campaignComplete) {
        current = current.copyWith(
          status: LivingRunStatus.completed,
          completedAt: _clock(),
          updatedAt: _clock(),
          epilogue: decision.epilogue,
          clearGenerationJob: true,
          clearV2GenerationCheckpoint: true,
        );
        await _persist(current);
        return LivingGenerationResult(run: current, completed: true);
      }

      var chapter = current.v2GenerationCheckpoint?.chapterPackage;
      if (chapter == null) {
        final payload = _builderPayload(current, decision);
        final primary = await _callStage(
          run: current,
          stage: LivingGenerationStage.builder,
          attempt: 1,
          prompt: LivingCampaignPrompt.builder,
          payload: payload,
          schema: LivingCampaignV2Schemas.builder,
          schemaName: LivingCampaignV2Schemas.builderName,
        );
        current = primary.run;
        LivingV2BuilderDecision? builder;
        var issues = <String>[];
        var warnings = <String>[];
        try {
          builder = LivingV2BuilderDecision.fromJson(primary.response.value);
          warnings = _validator.builderWarnings(builder: builder);
          issues = _validator.validateBuilder(
            builder: builder,
            director: decision,
            run: current,
          );
          issues.addAll(
            LivingChineseContentValidator.validateResponse(
              primary.response.value,
              current.contentLocale,
            ),
          );
          if (issues.isEmpty) {
            chapter = _assembleChapter(current, decision, builder);
            issues = _validator.validateChapter(chapter);
          }
        } on Object catch (error) {
          issues = <String>['Builder response could not be decoded: $error'];
        }
        if (builder == null || chapter == null || issues.isNotEmpty) {
          current = await _recordValidationIssues(current, issues);
          final repair = await _callStage(
            run: current,
            stage: LivingGenerationStage.builderRepair,
            attempt: 2,
            prompt: LivingCampaignPrompt.builderRepair,
            payload: <String, Object?>{
              ...payload,
              'invalidResponse': primary.response.value,
              'validationIssues': issues,
            },
            schema: LivingCampaignV2Schemas.builder,
            schemaName: LivingCampaignV2Schemas.builderName,
            repairsRecordId: current.generationRecords.last.recordId,
          );
          current = repair.run;
          try {
            builder = LivingV2BuilderDecision.fromJson(repair.response.value);
            warnings = _validator.builderWarnings(builder: builder);
            issues = _validator.validateBuilder(
              builder: builder,
              director: decision,
              run: current,
            );
            issues.addAll(
              LivingChineseContentValidator.validateResponse(
                repair.response.value,
                current.contentLocale,
              ),
            );
            if (issues.isEmpty) {
              chapter = _assembleChapter(current, decision, builder);
              issues = _validator.validateChapter(chapter);
            }
          } on Object catch (error) {
            issues = <String>['Repaired Builder response is invalid: $error'];
          }
          if (builder == null || chapter == null || issues.isNotEmpty) {
            current = await _recordValidationIssues(current, issues);
            return _validationFailure(current, issues.join(' '));
          }
        }
        if (warnings.isNotEmpty) {
          current = await _recordValidationWarnings(current, warnings);
        }
        current = current.copyWith(
          updatedAt: _clock(),
          v2GenerationCheckpoint: current.v2GenerationCheckpoint!.copyWith(
            chapterPackage: chapter,
          ),
        );
        await _persist(current);
      }

      var acceptedChapter = chapter;
      if (acceptedChapter.portraitCharacterId == null) {
        final portraitCandidate = _nextPortraitCandidate(current);
        if (portraitCandidate != null) {
          acceptedChapter = acceptedChapter.withPortraitCandidate(
            characterId: portraitCandidate.characterId,
            appearanceBrief: portraitCandidate.portraitAppearanceBrief!,
          );
          current = current.copyWith(
            updatedAt: _clock(),
            v2GenerationCheckpoint: current.v2GenerationCheckpoint!.copyWith(
              chapterPackage: acceptedChapter,
            ),
          );
          await _persist(current);
        }
      }
      final needsPortrait =
          _generatePortraits &&
          acceptedChapter.portraitCharacterId != null &&
          acceptedChapter.portraitPrompt?.trim().isNotEmpty == true &&
          _portraitMissing(current, acceptedChapter.portraitCharacterId!);
      if (needsPortrait) {
        current = await _generateOptionalPortrait(
          current,
          acceptedChapter,
          attempt: 1,
          clearGenerationJob: false,
        );
      }
      current = current.copyWith(
        updatedAt: _clock(),
        activeChapterNumber: acceptedChapter.chapterNumber,
        chapterPackages:
            current.chapterPackages.any(
              (candidate) => candidate.chapterId == acceptedChapter.chapterId,
            )
            ? current.chapterPackages
            : <LivingChapterPackage>[
                ...current.chapterPackages,
                acceptedChapter,
              ],
        clearGenerationJob: true,
        clearV2GenerationCheckpoint: true,
      );
      await _persist(current);
      return LivingGenerationResult(run: current, completed: true);
    } on _LivingV2CallFailure catch (failure) {
      final paused = failure.run.copyWith(
        updatedAt: _clock(),
        generationJob: failure.run.generationJob?.copyWith(
          status: LivingGenerationStatus.awaitingResume,
          updatedAt: _clock(),
          errorCode: failure.error.code,
          errorMessage: failure.error.safeMessage,
        ),
      );
      await _persist(paused);
      return LivingGenerationResult(
        run: paused,
        completed: false,
        message: failure.error.safeMessage,
      );
    }
  }

  @override
  Future<LivingGenerationResult> retryPortrait({
    required LivingCampaignRun run,
    required String characterId,
  }) async {
    await _archive.initialize();
    final checkpoint = run.portraitCheckpointsByCharacterId[characterId];
    if (run.status != LivingRunStatus.active ||
        checkpoint == null ||
        checkpoint.status != LivingPortraitStatus.awaitingRetry ||
        !_portraitMissing(run, characterId)) {
      return LivingGenerationResult(
        run: run,
        completed: false,
        message: 'This portrait is not waiting for an explicit retry.',
      );
    }
    final chapter = run.chapterPackages
        .where((value) => value.chapterId == checkpoint.missionId)
        .firstOrNull;
    if (chapter == null ||
        chapter.portraitCharacterId != characterId ||
        chapter.portraitPrompt?.trim().isNotEmpty != true) {
      return LivingGenerationResult(
        run: run,
        completed: false,
        message: 'The portrait checkpoint no longer matches its chapter.',
      );
    }
    final current = await _generateOptionalPortrait(
      run,
      chapter,
      attempt: checkpoint.attempt + 1,
    );
    return LivingGenerationResult(run: current, completed: true);
  }

  @override
  Future<LivingGenerationResult> generateChapterEndingArt({
    required LivingCampaignRun run,
    required LivingBattleOutcomeSnapshot outcome,
  }) async {
    await _archive.initialize();
    if (!run.battleOutcomes.any(
      (candidate) => candidate.chapterId == outcome.chapterId,
    )) {
      return LivingGenerationResult(
        run: run,
        completed: false,
        message: 'The battle must enter the chronicle before its final scene.',
      );
    }
    final existing = run.chapterArtCheckpointsByChapterId[outcome.chapterId];
    if (existing != null) {
      if (existing.status == LivingChapterArtStatus.pending) {
        return _generateChapterArt(run, outcome, attempt: existing.attempt);
      }
      return LivingGenerationResult(
        run: run,
        completed: existing.status == LivingChapterArtStatus.ready,
        message: 'This chapter already has a final-scene checkpoint.',
      );
    }
    return _generateChapterArt(run, outcome, attempt: 1);
  }

  @override
  Future<LivingGenerationResult> retryChapterEndingArt({
    required LivingCampaignRun run,
    required String chapterId,
  }) async {
    await _archive.initialize();
    final checkpoint = run.chapterArtCheckpointsByChapterId[chapterId];
    final outcome = run.battleOutcomes
        .where((candidate) => candidate.chapterId == chapterId)
        .firstOrNull;
    if (checkpoint == null ||
        checkpoint.status != LivingChapterArtStatus.awaitingRetry ||
        outcome == null) {
      return LivingGenerationResult(
        run: run,
        completed: false,
        message: 'This final scene is not waiting to be painted again.',
      );
    }
    return _generateChapterArt(run, outcome, attempt: checkpoint.attempt + 1);
  }

  Future<LivingGenerationResult> _generateChapterArt(
    LivingCampaignRun run,
    LivingBattleOutcomeSnapshot outcome, {
    required int attempt,
  }) async {
    final chapter = run.chapterPackages.firstWhere(
      (candidate) => candidate.chapterId == outcome.chapterId,
    );
    final startedAt = _clock();
    final seed = LivingChapterArtSeed.derive(
      runId: run.runId,
      chapterId: chapter.chapterId,
      attempt: attempt,
    );
    final previous = run.chapterArtCheckpointsByChapterId[chapter.chapterId];
    final checkpoints =
        Map<String, LivingChapterEndingArtCheckpoint>.from(
            run.chapterArtCheckpointsByChapterId,
          )
          ..[chapter.chapterId] = LivingChapterEndingArtCheckpoint(
            runId: run.runId,
            chapterId: chapter.chapterId,
            chapterNumber: chapter.chapterNumber,
            attempt: attempt,
            seed: seed,
            status: LivingChapterArtStatus.pending,
            promptAsset: LivingCampaignPrompt.chapterEndingArt.assetPath,
            createdAt: previous?.createdAt ?? startedAt,
            updatedAt: startedAt,
          );
    var current = run.copyWith(
      updatedAt: startedAt,
      chapterArtCheckpointsByChapterId: checkpoints,
    );
    current = _withClosureImageStatus(
      current,
      chapter.chapterId,
      status: LivingClosureTaskStatus.running,
      attempt: attempt,
      clearFailure: true,
    );
    await _persist(current);
    var prompt = '';
    var referenceImages = const <Uint8List>[];
    var referenceHashes = const <String>[];
    String? sourceReference;
    try {
      final contract = await _promptLibrary.load(
        LivingCampaignPrompt.chapterEndingArt,
      );
      final namedParticipants = chapter.pieces
          .where((piece) => piece.characterId != null)
          .map((piece) {
            final character = current.canon.charactersById[piece.characterId];
            return <String, Object?>{
              'characterId': piece.characterId,
              'name': character?.originalName,
              'appearance': character?.originalIdentity,
              'pieceType': piece.pieceType.name,
              'sideAtStart': piece.color.name,
              'survivedOnPlayerSide': outcome.survivingPieceIds.contains(
                piece.pieceId,
              ),
            };
          })
          .toList(growable: false);
      final decisiveEvent =
          outcome.matchLog.lastOrNull ??
          '${outcome.result.name} after ${outcome.completedRoundCount} rounds.';
      final facts = <String, Object?>{
        'chapter': <String, Object?>{
          'number': chapter.chapterNumber,
          'title': chapter.title,
          'setup': chapter.briefing,
          'objective': chapter.objective.toJson(),
          'battlefield': chapter.battlefieldId.name,
        },
        'outcome': outcome.toJson(),
        'decisiveEvent': decisiveEvent,
        'namedParticipants': namedParticipants,
      };
      prompt =
          '$contract\n\n## Authoritative Chapter Facts\n\n'
          '${const JsonEncoder.withIndent('  ').convert(facts)}';
      referenceImages = await _gateway.loadPortraitStyleReferences();
      referenceHashes = referenceImages
          .map((bytes) => sha256.convert(bytes).toString())
          .toList(growable: false);
      checkpoints[chapter.chapterId] = checkpoints[chapter.chapterId]!.copyWith(
        status: LivingChapterArtStatus.generating,
        updatedAt: _clock(),
        finalPrompt: prompt,
        referenceHashes: referenceHashes,
        clearFailure: true,
      );
      current = current.copyWith(
        updatedAt: _clock(),
        chapterArtCheckpointsByChapterId: checkpoints,
      );
      current = _withClosureImageStatus(
        current,
        chapter.chapterId,
        status: LivingClosureTaskStatus.running,
        attempt: attempt,
        clearFailure: true,
      );
      await _persist(current);
      final art = await _gateway.generateChapterEndingArt(
        prompt: prompt,
        seed: seed,
        referenceImages: referenceImages,
        onSourceDownloaded: (bytes) async {
          sourceReference = await _archive.writeBinary(
            runId: run.runId,
            fileName:
                'chapter_${chapter.chapterNumber}_ending_attempt_${attempt}_source.bin',
            bytes: bytes,
          );
        },
      );
      final processedReference = await _archive.writeBinary(
        runId: run.runId,
        fileName:
            'chapter_${chapter.chapterNumber}_ending_attempt_$attempt.png',
        bytes: art.imageBytes,
      );
      final finishedAt = _clock();
      final completed =
          Map<String, LivingChapterEndingArtCheckpoint>.from(
              current.chapterArtCheckpointsByChapterId,
            )
            ..[chapter.chapterId] = current
                .chapterArtCheckpointsByChapterId[chapter.chapterId]!
                .copyWith(
                  status: LivingChapterArtStatus.ready,
                  updatedAt: finishedAt,
                  finalPrompt: art.finalPrompt,
                  sourceReference: sourceReference,
                  processedReference: processedReference,
                  providerRequestId: art.requestId,
                  durationMs: finishedAt.difference(startedAt).inMilliseconds,
                  clearFailure: true,
                );
      current = current.copyWith(
        updatedAt: finishedAt,
        chapterArtCheckpointsByChapterId: completed,
        generationRecords: <LivingGenerationRecord>[
          ...current.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-chapter-art'),
            stage: LivingGenerationStage.chapterArt,
            attempt: attempt,
            status: LivingGenerationStatus.completed,
            model: _gateway.imageModel,
            startedAt: startedAt,
            finishedAt: finishedAt,
            requestPayload: <String, Object?>{
              'chapterId': chapter.chapterId,
              'prompt': art.finalPrompt,
              'promptAsset': LivingCampaignPrompt.chapterEndingArt.assetPath,
              'seed': seed,
              'size': '2560x1440',
              'watermark': false,
              'sequentialImageGeneration': 'disabled',
              'styleReferenceHashes': referenceHashes,
            },
            responsePayload: <String, Object?>{
              'sourceReference': ?sourceReference,
              'processedReference': processedReference,
              'width': art.width,
              'height': art.height,
            },
            inputTokens: null,
            contentLocale: current.contentLocale.tag,
            providerRequestId: art.requestId,
            transportType: 'http',
            durationMs: finishedAt.difference(startedAt).inMilliseconds,
            rawContent: art.redactedRawResponse,
          ),
        ],
      );
      current = _withClosureImageStatus(
        current,
        chapter.chapterId,
        status: LivingClosureTaskStatus.ready,
        attempt: attempt,
        clearFailure: true,
      );
      await _persist(current);
      return LivingGenerationResult(run: current, completed: true);
    } on Object catch (caught) {
      final error = caught is LivingProviderException
          ? caught
          : const LivingProviderException(
              code: 'chapter_art_generation_failed',
              safeMessage: 'The final scene could not be painted.',
            );
      final finishedAt = _clock();
      final failed =
          Map<String, LivingChapterEndingArtCheckpoint>.from(
              current.chapterArtCheckpointsByChapterId,
            )
            ..[chapter.chapterId] = checkpoints[chapter.chapterId]!.copyWith(
              status: LivingChapterArtStatus.awaitingRetry,
              updatedAt: finishedAt,
              sourceReference: sourceReference,
              providerRequestId: error.requestId,
              durationMs: finishedAt.difference(startedAt).inMilliseconds,
              errorCode: error.code,
              errorMessage: error.safeMessage,
            );
      current = current.copyWith(
        updatedAt: finishedAt,
        chapterArtCheckpointsByChapterId: failed,
        generationRecords: <LivingGenerationRecord>[
          ...current.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-chapter-art-failed'),
            stage: LivingGenerationStage.chapterArt,
            attempt: attempt,
            status: LivingGenerationStatus.awaitingResume,
            model: _gateway.imageModel,
            startedAt: startedAt,
            finishedAt: finishedAt,
            requestPayload: <String, Object?>{
              'chapterId': chapter.chapterId,
              'prompt': prompt,
              'promptAsset': LivingCampaignPrompt.chapterEndingArt.assetPath,
              'seed': seed,
              'styleReferenceHashes': referenceHashes,
            },
            responsePayload: <String, Object?>{
              'sourceReference': ?sourceReference,
            },
            inputTokens: null,
            contentLocale: current.contentLocale.tag,
            providerRequestId: error.requestId,
            transportType: 'http',
            durationMs: finishedAt.difference(startedAt).inMilliseconds,
            errorCode: error.code,
            errorMessage: error.safeMessage,
            rawContent: error.redactedResponseBody ?? '',
          ),
        ],
      );
      current = _withClosureImageStatus(
        current,
        chapter.chapterId,
        status: LivingClosureTaskStatus.awaitingRetry,
        attempt: attempt,
        errorCode: error.code,
        errorMessage: error.safeMessage,
      );
      await _persist(current);
      return LivingGenerationResult(
        run: current,
        completed: false,
        message: error.safeMessage,
      );
    }
  }

  LivingCampaignRun _withClosureImageStatus(
    LivingCampaignRun run,
    String chapterId, {
    required LivingClosureTaskStatus status,
    required int attempt,
    String? errorCode,
    String? errorMessage,
    bool clearFailure = false,
  }) {
    final checkpoints = Map<String, LivingChapterClosureCheckpoint>.from(
      run.chapterClosureCheckpointsByChapterId,
    );
    final checkpoint = checkpoints[chapterId];
    if (checkpoint == null) return run;
    checkpoints[chapterId] = checkpoint.copyWith(
      imageAttempt: attempt,
      imageStatus: status,
      updatedAt: _clock(),
      imageErrorCode: errorCode,
      imageErrorMessage: errorMessage,
      clearImageFailure: clearFailure,
    );
    return run.copyWith(
      updatedAt: _clock(),
      chapterClosureCheckpointsByChapterId: checkpoints,
    );
  }

  Map<String, Object?> _chroniclerPayload(
    LivingCampaignRun run,
    LivingBattleOutcomeSnapshot outcome,
  ) {
    final chapter = run.chapterPackages.firstWhere(
      (value) => value.chapterId == outcome.chapterId,
    );
    return <String, Object?>{
      'runId': run.runId,
      'mission': <String, Object?>{
        'missionNumber': chapter.chapterNumber,
        'missionId': chapter.chapterId,
        'title': chapter.title,
        'background': chapter.briefing,
        'dialogue': chapter.dialogue.map((line) => line.toJson()).toList(),
        'objective': chapter.objective.toJson(),
      },
      'battleOutcome': outcome.toJson(),
      'endingPieceStates': outcome.pieceEndStates
          .map((state) => state.toJson())
          .toList(growable: false),
      'matchLog': outcome.matchLog,
      'keyEvents': run.canon.eventLedger
          .where((event) => event.chapterNumber == outcome.chapterNumber)
          .map((event) => event.toJson())
          .toList(growable: false),
      'namedCharacters': run.namedPiecesByName.values
          .where(
            (record) => chapter.pieces.any(
              (piece) => piece.characterId == record.characterId,
            ),
          )
          .map((record) => record.toJson())
          .toList(),
      'pendingIdentities': run.namedPiecesByName.values
          .where((record) => record.needsNaming)
          .map((record) => record.toJson())
          .toList(growable: false),
      'eligibleSpeakers': _eligibleAftermathRecords(
        run,
        outcome,
      ).map((record) => record.toJson()).toList(growable: false),
    };
  }

  List<LivingNamedPieceRecord> _eligibleAftermathRecords(
    LivingCampaignRun run,
    LivingBattleOutcomeSnapshot outcome,
  ) {
    final endStates = <String, LivingPieceEndState>{
      for (final state in outcome.pieceEndStates) state.pieceId: state,
    };
    final chapter = run.chapterPackages.firstWhere(
      (candidate) => candidate.chapterId == outcome.chapterId,
    );
    final ids = <String>{};
    for (final piece in chapter.pieces) {
      final characterId = piece.characterId;
      if (characterId == null) continue;
      final record = run.namedPiecesByName.values
          .where((candidate) => candidate.characterId == characterId)
          .firstOrNull;
      if (record == null ||
          record.status == LivingNamedPieceStatus.dead ||
          record.status == LivingNamedPieceStatus.missing) {
        continue;
      }
      if (outcome.pieceEndStates.isEmpty ||
          endStates[piece.pieceId]?.finishedAlive == true) {
        ids.add(characterId);
      }
    }
    for (final record in run.namedPiecesByName.values.where(
      (candidate) => candidate.needsNaming,
    )) {
      if (outcome.pieceEndStates.isEmpty ||
          endStates[record.pieceId]?.finishedAlive == true) {
        ids.add(record.characterId);
      }
    }
    return run.namedPiecesByName.values
        .where((record) => ids.contains(record.characterId))
        .toList(growable: false);
  }

  LivingCampaignRun _acceptMemory(
    LivingCampaignRun run,
    LivingMissionMemory memory,
    LivingBattleOutcomeSnapshot outcome,
  ) {
    final chapter = run.chapterPackages.firstWhere(
      (value) => value.chapterId == outcome.chapterId,
    );
    final eventIds = <String>{
      '${outcome.chapterId}_result',
      ...memory.keyEventIds,
    }.toList(growable: false);
    final ledger =
        run.canon.chapterLedger.any(
          (record) => record.chapterId == outcome.chapterId,
        )
        ? run.canon.chapterLedger
        : <LivingChapterRecord>[
            ...run.canon.chapterLedger,
            LivingChapterRecord(
              chapterNumber: outcome.chapterNumber,
              chapterId: outcome.chapterId,
              title: chapter.title,
              oneLineSummary: '${memory.setupSummary} ${memory.battleSummary}'
                  .trim(),
              objectiveType: outcome.objectiveType,
              result: outcome.result,
              eventIds: eventIds,
              finaleKind: LivingFinaleKind.none,
            ),
          ];
    return run.copyWith(
      updatedAt: _clock(),
      missionMemories:
          run.missionMemories.any(
            (candidate) => candidate.missionId == memory.missionId,
          )
          ? run.missionMemories
          : <LivingMissionMemory>[...run.missionMemories, memory],
      canon: run.canon.copyWith(chapterLedger: ledger),
      v2GenerationCheckpoint: run.v2GenerationCheckpoint!.copyWith(
        missionMemory: memory,
      ),
    );
  }

  LivingCampaignRun _acceptChroniclerClosure(
    LivingCampaignRun run,
    LivingChroniclerClosureResult closure,
    LivingBattleOutcomeSnapshot outcome,
  ) {
    var current = _acceptMemory(run, closure.memory, outcome);
    final named = Map<String, LivingNamedPieceRecord>.from(
      current.namedPiecesByName,
    );
    final characters = Map<String, LivingCharacter>.from(
      current.canon.charactersById,
    );
    final assignments = Map<String, LivingIdentityAssignment>.from(
      current.identityAssignmentsByCharacterId,
    );
    final events = List<LivingCanonEvent>.from(current.canon.eventLedger);
    for (final assignment in closure.identityAssignments) {
      final oldEntry = named.entries.firstWhere(
        (entry) => entry.value.characterId == assignment.characterId,
      );
      final previous = oldEntry.value;
      named.remove(oldEntry.key);
      final updated = previous.copyWith(
        name: assignment.name,
        description: assignment.description,
        portraitAppearanceBrief: assignment.portraitAppearanceBrief,
        needsNaming: false,
        lastKnownMission: outcome.chapterNumber,
      );
      named[assignment.name] = updated;
      assignments[assignment.characterId] = assignment;
      final character = characters[assignment.characterId];
      if (character != null) {
        characters[assignment.characterId] = character.copyWith(
          originalName: assignment.name,
          originalIdentity: assignment.description,
          aliases: <String>{...character.aliases, previous.name}.toList(),
          lastChapter: outcome.chapterNumber,
        );
      }
      final eventId = '${outcome.chapterId}_named_${assignment.characterId}';
      if (!events.any((event) => event.eventId == eventId)) {
        events.add(
          LivingCanonEvent(
            eventId: eventId,
            chapterNumber: outcome.chapterNumber,
            type: LivingEventType.named,
            subjectIds: <String>[assignment.characterId],
            description:
                '${previous.name} was named ${assignment.name} in the aftermath.',
          ),
        );
      }
    }
    final aftermath = Map<String, LivingAftermathScene>.from(
      current.aftermathScenesByChapterId,
    )..[outcome.chapterId] = closure.aftermath;
    final closureCheckpoints = Map<String, LivingChapterClosureCheckpoint>.from(
      current.chapterClosureCheckpointsByChapterId,
    );
    final checkpoint = closureCheckpoints[outcome.chapterId];
    if (checkpoint != null) {
      closureCheckpoints[outcome.chapterId] = checkpoint.copyWith(
        textStatus: LivingClosureTaskStatus.ready,
        updatedAt: _clock(),
        clearTextFailure: true,
      );
    }
    return current.copyWith(
      updatedAt: _clock(),
      clearGenerationJob: true,
      namedPiecesByName: named,
      identityAssignmentsByCharacterId: assignments,
      aftermathScenesByChapterId: aftermath,
      chapterClosureCheckpointsByChapterId: closureCheckpoints,
      canon: current.canon.copyWith(
        charactersById: characters,
        eventLedger: events,
      ),
    );
  }

  Future<LivingGenerationResult> _closureTextFailure(
    LivingCampaignRun run,
    String chapterId,
    String code,
    String message,
  ) async {
    final checkpoints = Map<String, LivingChapterClosureCheckpoint>.from(
      run.chapterClosureCheckpointsByChapterId,
    );
    final checkpoint = checkpoints[chapterId];
    if (checkpoint != null) {
      checkpoints[chapterId] = checkpoint.copyWith(
        textStatus: LivingClosureTaskStatus.awaitingRetry,
        updatedAt: _clock(),
        textErrorCode: code,
        textErrorMessage: message,
      );
    }
    final failed = run.copyWith(
      updatedAt: _clock(),
      clearGenerationJob: true,
      chapterClosureCheckpointsByChapterId: checkpoints,
    );
    await _persist(failed);
    return LivingGenerationResult(
      run: failed,
      completed: false,
      message: message,
    );
  }

  Future<_PreparedDirectorPayload> _prepareDirectorPayload(
    LivingCampaignRun run,
  ) async {
    var current = run;
    var previousStories = <Object?>[
      for (final memory in current.missionMemories) memory.toJson(),
    ];
    var payload = _directorPayload(current, previousStories);
    final tokens = await _countTokens(<String>[
      await _promptLibrary.load(LivingCampaignPrompt.director),
      jsonEncode(payload),
      jsonEncode(LivingCampaignV2Schemas.director),
    ]);
    if (tokens <= _capability.compressionTriggerTokens) {
      return _PreparedDirectorPayload(run: current, payload: payload);
    }
    if (current.missionMemories.length < 2) {
      throw _LivingV2CallFailure(
        run: current,
        error: const LivingProviderException(
          code: 'context_capacity_exceeded',
          safeMessage:
              'The current roster and latest mission exceed the model context.',
        ),
      );
    }
    final older = current.missionMemories.sublist(
      0,
      current.missionMemories.length - 1,
    );
    final sourceMissionIds = older.map((memory) => memory.missionId).toList();
    final sourceJson = jsonEncode(
      older.map((memory) => memory.toJson()).toList(),
    );
    final sourceTokens = await _countTokens(<String>[sourceJson]);
    final compressorPayload = <String, Object?>{
      'runId': current.runId,
      'requiredSourceMissionIds': sourceMissionIds,
      'olderMissionMemories': older.map((memory) => memory.toJson()).toList(),
    };
    final primary = await _callStage(
      run: current,
      stage: LivingGenerationStage.compaction,
      attempt: 1,
      prompt: LivingCampaignPrompt.historyCompressor,
      payload: compressorPayload,
      schema: LivingCampaignV2Schemas.historyDigest,
      schemaName: LivingCampaignV2Schemas.historyDigestName,
    );
    current = primary.run;
    var digest = await _decodeDigest(
      primary.response.value,
      current.runId,
      sourceMissionIds,
      sourceTokens,
    );
    var issues = <String>[
      ...digest.issues,
      ...LivingChineseContentValidator.validateResponse(
        primary.response.value,
        current.contentLocale,
      ),
    ];
    if (issues.isNotEmpty) {
      current = await _recordValidationIssues(current, issues);
      final repair = await _callStage(
        run: current,
        stage: LivingGenerationStage.compactionRepair,
        attempt: 2,
        prompt: LivingCampaignPrompt.historyCompressorRepair,
        payload: <String, Object?>{
          ...compressorPayload,
          'invalidResponse': primary.response.value,
          'validationIssues': issues,
          'maximumDigestTokens': sourceTokens ~/ 2,
        },
        schema: LivingCampaignV2Schemas.historyDigest,
        schemaName: LivingCampaignV2Schemas.historyDigestName,
        repairsRecordId: current.generationRecords.last.recordId,
      );
      current = repair.run;
      digest = await _decodeDigest(
        repair.response.value,
        current.runId,
        sourceMissionIds,
        sourceTokens,
      );
      issues = <String>[
        ...digest.issues,
        ...LivingChineseContentValidator.validateResponse(
          repair.response.value,
          current.contentLocale,
        ),
      ];
      if (issues.isNotEmpty || digest.value == null) {
        current = await _recordValidationIssues(current, issues);
        throw _LivingV2CallFailure(
          run: current,
          error: LivingProviderException(
            code: 'history_compression_invalid',
            safeMessage: issues.join(' '),
          ),
        );
      }
    }
    final accepted = digest.value!;
    current = current.copyWith(
      historyDigests: <LivingHistoryDigest>[
        ...current.historyDigests,
        accepted,
      ],
      updatedAt: _clock(),
    );
    await _persist(current);
    previousStories = <Object?>[
      <String, Object?>{'historyDigest': accepted.toJson()},
      current.missionMemories.last.toJson(),
    ];
    payload = _directorPayload(current, previousStories);
    final compactedTokens = await _countTokens(<String>[
      await _promptLibrary.load(LivingCampaignPrompt.director),
      jsonEncode(payload),
      jsonEncode(LivingCampaignV2Schemas.director),
    ]);
    if (compactedTokens >= _capability.contextTokens) {
      throw _LivingV2CallFailure(
        run: current,
        error: const LivingProviderException(
          code: 'context_capacity_exceeded',
          safeMessage:
              'The compressed campaign state still exceeds the model context.',
        ),
      );
    }
    return _PreparedDirectorPayload(run: current, payload: payload);
  }

  Map<String, Object?> _directorPayload(
    LivingCampaignRun run,
    List<Object?> previousStories,
  ) => <String, Object?>{
    'runId': run.runId,
    'basedOnMissionNumber': run.activeChapterNumber,
    'nextMissionNumber': run.activeChapterNumber + 1,
    'previousStories': previousStories,
    'namedPiecesByName': run.namedPiecesByName.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'eligibleAllies': run.namedPiecesByName.values
        .where(
          (record) =>
              record.status == LivingNamedPieceStatus.ally && record.isAlive,
        )
        .map((record) => record.toJson())
        .toList(),
    'rules': const <String, Object?>{
      'maximumAdvancedPlayerParticipants': 8,
      'maximumNewPortraitCharacters': 1,
      'ordinaryDefeatEndsCampaign': false,
      'earliestNonTrapfallFinaleMission': 3,
    },
  };

  LivingCampaignRun _acceptDirector(
    LivingCampaignRun run,
    LivingV2DirectorDecision decision,
  ) {
    final named = Map<String, LivingNamedPieceRecord>.from(
      run.namedPiecesByName,
    );
    final characters = Map<String, LivingCharacter>.from(
      run.canon.charactersById,
    );
    final roster = Map<String, LivingRosterPiece>.from(
      run.canon.playerRosterByPieceId,
    );
    final events = List<LivingCanonEvent>.from(run.canon.eventLedger);
    for (final change in decision.statusChanges) {
      final entry = named.entries.firstWhere(
        (candidate) => candidate.value.characterId == change.characterId,
      );
      final record = entry.value.copyWith(
        status: change.toStatus,
        lastKnownMission: decision.nextMissionNumber,
      );
      named[entry.key] = record;
      final character = characters[record.characterId];
      final whereabouts = change.toStatus == LivingNamedPieceStatus.ally
          ? LivingWhereabouts.withCourt
          : LivingWhereabouts.unknown;
      final allegiance = change.toStatus == LivingNamedPieceStatus.ally
          ? LivingAllegiance.player
          : LivingAllegiance.enemy;
      characters[record.characterId] = character == null
          ? LivingCharacter(
              characterId: record.characterId,
              originalName: record.name,
              originalIdentity: record.description,
              basePieceType: record.pieceType,
              linkedPieceId: record.pieceId,
              lifeState: LivingLifeState.alive,
              whereabouts: whereabouts,
              allegiance: allegiance,
              firstChapter: decision.nextMissionNumber,
              lastChapter: decision.nextMissionNumber,
              portraitPath: record.portraitPath,
            )
          : character.copyWith(
              lifeState: LivingLifeState.alive,
              whereabouts: whereabouts,
              allegiance: allegiance,
              lastChapter: decision.nextMissionNumber,
              portraitPath: character.portraitPath ?? record.portraitPath,
            );
      events.add(
        LivingCanonEvent(
          eventId:
              'living_m${decision.nextMissionNumber.toString().padLeft(2, '0')}_director_${record.characterId}',
          chapterNumber: decision.nextMissionNumber,
          type: change.toStatus == LivingNamedPieceStatus.ally
              ? LivingEventType.joined
              : LivingEventType.returned,
          subjectIds: <String>[record.characterId],
          description: change.reason,
        ),
      );
      if (change.toStatus == LivingNamedPieceStatus.ally) {
        roster[record.pieceId] = LivingRosterPiece(
          pieceId: record.pieceId,
          basePieceType: record.pieceType,
          characterId: record.characterId,
          origin: record.description,
          lifeState: LivingLifeState.alive,
          whereabouts: LivingWhereabouts.withCourt,
          allegiance: LivingAllegiance.player,
          rosterPosition: LivingRosterPosition.active,
        );
      } else {
        roster.remove(record.pieceId);
      }
    }
    final newcomer = decision.newCharacter;
    if (newcomer != null) {
      final record = LivingNamedPieceRecord(
        name: newcomer.name,
        characterId: newcomer.characterId,
        pieceId: newcomer.pieceId,
        pieceType: newcomer.pieceType,
        status: newcomer.status,
        recruitable: newcomer.recruitable,
        description: newcomer.description,
        loyalty: newcomer.loyalty,
        discoveredMission: decision.nextMissionNumber,
        lastKnownMission: decision.nextMissionNumber,
      );
      named[record.name] = record;
      characters[record.characterId] = LivingCharacter(
        characterId: record.characterId,
        originalName: record.name,
        originalIdentity: record.description,
        basePieceType: record.pieceType,
        linkedPieceId: record.pieceId,
        lifeState: record.status == LivingNamedPieceStatus.dead
            ? LivingLifeState.dead
            : LivingLifeState.alive,
        whereabouts: record.status == LivingNamedPieceStatus.ally
            ? LivingWhereabouts.withCourt
            : LivingWhereabouts.unknown,
        allegiance: record.status == LivingNamedPieceStatus.ally
            ? LivingAllegiance.player
            : LivingAllegiance.enemy,
        firstChapter: decision.nextMissionNumber,
        lastChapter: decision.nextMissionNumber,
      );
      events.add(
        LivingCanonEvent(
          eventId:
              'living_m${decision.nextMissionNumber.toString().padLeft(2, '0')}_introduced_${record.characterId}',
          chapterNumber: decision.nextMissionNumber,
          type: LivingEventType.named,
          subjectIds: <String>[record.characterId],
          description: record.description,
        ),
      );
    }
    return run.copyWith(
      updatedAt: _clock(),
      namedPiecesByName: named,
      canon: run.canon.copyWith(
        charactersById: characters,
        playerRosterByPieceId: roster,
        eventLedger: events,
      ),
      v2GenerationCheckpoint: run.v2GenerationCheckpoint!.copyWith(
        directorDecision: decision,
      ),
    );
  }

  Map<String, Object?> _builderPayload(
    LivingCampaignRun run,
    LivingV2DirectorDecision decision,
  ) => <String, Object?>{
    'runId': run.runId,
    'directorDecision': decision.toJson(),
    'selectedPlayerAdvancedPieces': decision.participantCharacterIds
        .map(
          (id) => run.namedPiecesByName.values
              .firstWhere((record) => record.characterId == id)
              .toJson(),
        )
        .toList(),
    'namedPiecesByName': run.namedPiecesByName.map(
      (key, value) => MapEntry(key, value.toJson()),
    ),
    'constraints': const <String, Object?>{
      'enemyRanks': <int>[5, 6, 7, 8],
      'enemyPawnMinimum': 0,
      'enemyPawnMaximum': 8,
      'enemyTotalMaximum': 16,
      'exactEnemyKings': 1,
    },
  };

  LivingChapterPackage _assembleChapter(
    LivingCampaignRun run,
    LivingV2DirectorDecision director,
    LivingV2BuilderDecision builder,
  ) {
    final player = _deployment.buildPlayerPieces(
      run: run,
      participantCharacterIds: director.participantCharacterIds,
    );
    String? targetPieceId;
    final targetCharacterId = director.targetCharacterId;
    if (targetCharacterId != null) {
      targetPieceId = <LivingMissionPiece>[...player, ...builder.enemyPieces]
          .where((piece) => piece.characterId == targetCharacterId)
          .map((piece) => piece.pieceId)
          .firstOrNull;
      if (targetPieceId == null) {
        throw StateError('Director target character is absent from the board.');
      }
    }
    final targetSquare = director.targetSquare == null
        ? null
        : livingSquareFromName(director.targetSquare!);
    return LivingChapterPackage(
      schemaVersion: 2,
      runId: run.runId,
      basedOnRevision: run.canon.revision,
      chapterNumber: director.nextMissionNumber,
      chapterId:
          'living_m${director.nextMissionNumber.toString().padLeft(2, '0')}',
      title: director.title,
      subtitle: director.subtitle,
      briefing: director.background,
      pressureTier: director.pressureTier,
      objective: LivingMissionObjective(
        type: director.objectiveType,
        label: director.objectiveLabel,
        targetPieceId: targetPieceId,
        targetSquare: targetSquare,
        surviveRounds: director.surviveRounds,
        legacySurviveActionCount: director.legacySurviveActionCount,
      ),
      whiteCountryId: 'ashen',
      blackCountryId: builder.blackCountryId,
      startingTurn: builder.startingTurn,
      battlefieldId: builder.battlefieldId,
      seed: builder.seed,
      economyEnabled: true,
      merchantEnabled: true,
      specialTilesEnabled: true,
      whiteGold: run.canon.gold,
      blackGold: builder.blackGold,
      merchantSpeed: builder.merchantSpeed,
      pieces: List.unmodifiable(<LivingMissionPiece>[
        ...player,
        ...builder.enemyPieces,
      ]),
      reservePieceIds: const <String>[],
      dialogue: director.dialogue,
      aiAggression: switch (director.pressureTier) {
        'overwhelming' => .82,
        'severe' => .72,
        'pressured' => .64,
        _ => .56,
      },
      aiDefense: switch (director.pressureTier) {
        'overwhelming' => .78,
        'severe' => .68,
        'pressured' => .60,
        _ => .52,
      },
      aiObjectivePressure: .68,
      aiTileAppetite: .56,
      portraitCharacterId: director.newCharacter?.characterId,
      portraitPrompt: director.newCharacter?.portraitPrompt,
    );
  }

  Future<_DecodedDigest> _decodeDigest(
    Map<String, Object?> json,
    String runId,
    List<String> sourceMissionIds,
    int sourceTokens,
  ) async {
    final issues = <String>[];
    LivingHistoryDigest? value;
    try {
      final schemaVersion = (json['schemaVersion']! as num).toInt();
      final responseRunId = json['runId']! as String;
      final ids = (json['sourceMissionIds']! as List<Object?>).cast<String>();
      final narrative = json['narrative']! as String;
      final digestTokens = await _countTokens(<String>[narrative]);
      if (ids.length != sourceMissionIds.length ||
          !List.generate(
            ids.length,
            (index) => ids[index] == sourceMissionIds[index],
          ).every((same) => same)) {
        issues.add(
          'HistoryDigest must preserve every source mission ID in order.',
        );
      }
      if (schemaVersion != 2 || responseRunId != runId) {
        issues.add('HistoryDigest identity does not match the active run.');
      }
      if (digestTokens > sourceTokens ~/ 2) {
        issues.add('HistoryDigest exceeds half the source token count.');
      }
      if (narrative.trim().isEmpty) {
        issues.add('HistoryDigest narrative is empty.');
      }
      value = LivingHistoryDigest(
        schemaVersion: schemaVersion,
        runId: responseRunId,
        digestId: json['digestId']! as String,
        sourceMissionIds: ids,
        narrative: narrative,
        sourceTokens: sourceTokens,
        digestTokens: digestTokens,
      );
    } on Object catch (error) {
      issues.add('HistoryDigest could not be decoded: $error');
    }
    return _DecodedDigest(value: value, issues: issues);
  }

  Future<_LivingV2Call> _callStage({
    required LivingCampaignRun run,
    required LivingGenerationStage stage,
    required int attempt,
    required LivingCampaignPrompt prompt,
    required Map<String, Object?> payload,
    required Map<String, Object?> schema,
    required String schemaName,
    String? repairsRecordId,
  }) async {
    var liveRun = await _setStage(run, stage, attempt);
    final systemPrompt = LivingCampaignLocaleContract.append(
      await _promptLibrary.load(prompt),
      run.contentLocale,
    );
    final localizedPayload = <String, Object?>{
      'contentLocale': run.contentLocale.tag,
      ...payload,
    };
    final inputTokens = await _countTokens(<String>[
      systemPrompt,
      jsonEncode(localizedPayload),
      jsonEncode(schema),
    ]);
    final maxTokens = _capability.remainingOutputTokens(inputTokens);
    if (maxTokens <= 0) {
      throw _LivingV2CallFailure(
        run: liveRun,
        error: const LivingProviderException(
          code: 'context_capacity_exceeded',
          safeMessage: 'The Living Campaign request exceeds model context.',
        ),
      );
    }
    final startedAt = _clock();
    var progressWrites = Future<void>.value();
    try {
      final response = await _gateway.chatJson(
        systemPrompt: systemPrompt,
        userPayload: localizedPayload,
        jsonSchema: schema,
        jsonSchemaName: schemaName,
        maxTokens: maxTokens,
        temperature: .2,
        onProgress: (progress) {
          final previous = liveRun.generationJob;
          if (previous == null) return;
          final persistRequestId =
              progress.requestId != null &&
              progress.requestId != previous.providerRequestId;
          liveRun = liveRun.copyWith(
            updatedAt: progress.occurredAt,
            generationJob: previous.copyWith(
              stage: stage,
              attempt: attempt,
              status: LivingGenerationStatus.running,
              updatedAt: progress.occurredAt,
              transportType: 'sse',
              providerRequestId: progress.requestId,
              lastActivityAt: progress.phase == DoubaoStreamPhase.connected
                  ? previous.lastActivityAt
                  : progress.occurredAt,
              receivedContentCharacters: progress.receivedContentCharacters,
              clearError: true,
            ),
          );
          unawaited(_notify(liveRun));
          if (persistRequestId) {
            final snapshot = liveRun;
            progressWrites = progressWrites.then(
              (_) => _archive.writeRun(snapshot),
            );
          }
        },
      );
      await progressWrites;
      final record = LivingGenerationRecord(
        recordId: _idFactory('record-${stage.name}'),
        stage: stage,
        attempt: attempt,
        status: LivingGenerationStatus.completed,
        model: response.model ?? _gateway.textModel,
        startedAt: startedAt,
        finishedAt: _clock(),
        requestPayload: <String, Object?>{
          'systemPrompt': systemPrompt,
          'userPayload': localizedPayload,
          'responseSchemaName': schemaName,
          'responseSchema': schema,
          'thinking': const <String, Object?>{'type': 'disabled'},
          'maxTokens': maxTokens,
        },
        responsePayload: response.value,
        inputTokens: inputTokens,
        contentLocale: run.contentLocale.tag,
        providerRequestId: response.requestId,
        transportType: response.transport,
        timeToFirstEventMs: response.timeToFirstEvent?.inMilliseconds,
        durationMs: response.duration?.inMilliseconds,
        usage: response.usage,
        finishReason: response.finishReason,
        rawSse: response.redactedRawResponse,
        rawContent: response.rawContent,
        repairsRecordId: repairsRecordId,
      );
      liveRun = liveRun.copyWith(
        updatedAt: _clock(),
        generationRecords: <LivingGenerationRecord>[
          ...liveRun.generationRecords,
          record,
        ],
      );
      await _persist(liveRun);
      return _LivingV2Call(run: liveRun, response: response);
    } on LivingProviderException catch (error) {
      await progressWrites;
      final failed = liveRun.copyWith(
        updatedAt: _clock(),
        generationRecords: <LivingGenerationRecord>[
          ...liveRun.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-${stage.name}-failed'),
            stage: stage,
            attempt: attempt,
            status: LivingGenerationStatus.awaitingResume,
            model: _gateway.textModel,
            startedAt: startedAt,
            finishedAt: _clock(),
            requestPayload: <String, Object?>{
              'systemPrompt': systemPrompt,
              'userPayload': localizedPayload,
              'responseSchemaName': schemaName,
              'responseSchema': schema,
              'thinking': const <String, Object?>{'type': 'disabled'},
              'maxTokens': maxTokens,
            },
            responsePayload: const <String, Object?>{},
            inputTokens: inputTokens,
            contentLocale: run.contentLocale.tag,
            providerRequestId: error.requestId,
            transportType: 'sse',
            errorCode: error.code,
            errorMessage:
                error.providerMessage == null ||
                    error.providerMessage!.trim().isEmpty
                ? error.safeMessage
                : '${error.safeMessage} Provider detail: ${error.providerMessage}',
            rawContent: error.redactedResponseBody ?? '',
            repairsRecordId: repairsRecordId,
          ),
        ],
      );
      await _persist(failed);
      throw _LivingV2CallFailure(run: failed, error: error);
    }
  }

  Future<int> _countTokens(Iterable<String> values) async {
    try {
      return (await _gateway.countTextTokens(values)).totalTokens;
    } on LivingProviderException {
      final characters = values.fold<int>(
        0,
        (sum, value) => sum + value.length,
      );
      return (characters / 2).ceil();
    }
  }

  bool _portraitMissing(LivingCampaignRun run, String characterId) {
    final named = run.namedPiecesByName.values
        .where((record) => record.characterId == characterId)
        .firstOrNull;
    final character = run.canon.charactersById[characterId];
    return named?.portraitPath?.trim().isNotEmpty != true &&
        character?.portraitPath?.trim().isNotEmpty != true;
  }

  LivingNamedPieceRecord? _nextPortraitCandidate(LivingCampaignRun run) {
    final candidates =
        run.namedPiecesByName.values
            .where(
              (record) =>
                  record.pieceType != PieceType.pawn &&
                  record.portraitAppearanceBrief?.trim().isNotEmpty == true &&
                  _portraitMissing(run, record.characterId) &&
                  !run.portraitCheckpointsByCharacterId.containsKey(
                    record.characterId,
                  ),
            )
            .toList()
          ..sort((a, b) {
            final mission = b.discoveredMission.compareTo(a.discoveredMission);
            return mission != 0
                ? mission
                : a.characterId.compareTo(b.characterId);
          });
    return candidates.firstOrNull;
  }

  Future<LivingCampaignRun> _generateOptionalPortrait(
    LivingCampaignRun run,
    LivingChapterPackage chapter, {
    required int attempt,
    bool clearGenerationJob = true,
  }) async {
    final characterId = chapter.portraitCharacterId!;
    final appearanceBrief = chapter.portraitPrompt!.trim();
    final seed = LivingPortraitSeed.derive(
      runId: run.runId,
      missionId: chapter.chapterId,
      characterId: characterId,
      attempt: attempt,
    );
    var current = await _setStage(
      run,
      LivingGenerationStage.portrait,
      attempt,
      transportType: 'http',
    );
    final startedAt = _clock();
    final previousCheckpoint =
        current.portraitCheckpointsByCharacterId[characterId];
    final checkpoints = Map<String, LivingPortraitCheckpoint>.from(
      current.portraitCheckpointsByCharacterId,
    );
    checkpoints[characterId] = LivingPortraitCheckpoint(
      runId: run.runId,
      missionId: chapter.chapterId,
      missionNumber: chapter.chapterNumber,
      characterId: characterId,
      attempt: attempt,
      seed: seed,
      status: LivingPortraitStatus.pending,
      appearanceBrief: appearanceBrief,
      promptAsset: LivingCampaignPrompt.portrait.assetPath,
      createdAt: previousCheckpoint?.createdAt ?? startedAt,
      updatedAt: startedAt,
    );
    current = current.copyWith(
      updatedAt: startedAt,
      portraitCheckpointsByCharacterId: checkpoints,
    );
    await _persist(current);
    var prompt = appearanceBrief;
    var referenceImages = const <Uint8List>[];
    var referenceHashes = const <String>[];
    String? sourceReference;
    try {
      final promptContract = await _promptLibrary.load(
        LivingCampaignPrompt.portrait,
      );
      prompt =
          '$promptContract\n\n'
          '## Authoritative Character Appearance Brief\n\n'
          '$appearanceBrief';
      referenceImages = await _gateway.loadPortraitStyleReferences();
      referenceHashes = referenceImages
          .map((bytes) => sha256.convert(bytes).toString())
          .toList(growable: false);
      checkpoints[characterId] = checkpoints[characterId]!.copyWith(
        status: LivingPortraitStatus.generating,
        updatedAt: _clock(),
        finalPrompt: prompt,
        referenceHashes: referenceHashes,
      );
      current = current.copyWith(
        updatedAt: _clock(),
        portraitCheckpointsByCharacterId: checkpoints,
      );
      await _persist(current);
      final portrait = await _gateway.generatePortrait(
        prompt: prompt,
        seed: seed,
        referenceImages: referenceImages,
        onSourceDownloaded: (bytes) async {
          sourceReference = await _archive.writeBinary(
            runId: run.runId,
            fileName: 'portrait_${characterId}_attempt_${attempt}_source.bin',
            bytes: bytes,
          );
        },
      );
      final reference = await _archive.writeBinary(
        runId: run.runId,
        fileName: 'portrait_${characterId}_attempt_$attempt.png',
        bytes: portrait.pngBytes,
      );
      final named = Map<String, LivingNamedPieceRecord>.from(
        current.namedPiecesByName,
      );
      final namedEntry = named.entries
          .where((entry) => entry.value.characterId == characterId)
          .firstOrNull;
      final character = current.canon.charactersById[characterId];
      if (namedEntry == null || character == null) {
        throw const LivingProviderException(
          code: 'portrait_character_missing',
          safeMessage: 'The portrait character is missing from campaign state.',
        );
      }
      named[namedEntry.key] = namedEntry.value.copyWith(
        portraitPath: reference,
      );
      final characters = Map<String, LivingCharacter>.from(
        current.canon.charactersById,
      )..[characterId] = character.copyWith(portraitPath: reference);
      final finishedAt = _clock();
      final completedCheckpoints =
          Map<String, LivingPortraitCheckpoint>.from(
              current.portraitCheckpointsByCharacterId,
            )
            ..[characterId] = current
                .portraitCheckpointsByCharacterId[characterId]!
                .copyWith(
                  status: LivingPortraitStatus.ready,
                  updatedAt: finishedAt,
                  finalPrompt: portrait.finalPrompt,
                  sourceReference: sourceReference,
                  processedReference: reference,
                  providerRequestId: portrait.requestId,
                  durationMs: finishedAt.difference(startedAt).inMilliseconds,
                  clearFailure: true,
                );
      current = current.copyWith(
        updatedAt: finishedAt,
        namedPiecesByName: named,
        canon: current.canon.copyWith(charactersById: characters),
        portraitCheckpointsByCharacterId: completedCheckpoints,
        clearGenerationJob: clearGenerationJob,
        generationRecords: <LivingGenerationRecord>[
          ...current.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-portrait'),
            stage: LivingGenerationStage.portrait,
            attempt: attempt,
            status: LivingGenerationStatus.completed,
            model: _gateway.imageModel,
            startedAt: startedAt,
            finishedAt: finishedAt,
            requestPayload: <String, Object?>{
              'characterId': characterId,
              'prompt': portrait.finalPrompt,
              'promptAsset': LivingCampaignPrompt.portrait.assetPath,
              'seed': seed,
              'styleReferenceHashes': referenceHashes,
            },
            responsePayload: <String, Object?>{
              'sourceReference': ?sourceReference,
              'processedReference': reference,
              'width': portrait.width,
              'height': portrait.height,
            },
            inputTokens: null,
            contentLocale: current.contentLocale.tag,
            providerRequestId: portrait.requestId,
            transportType: 'http',
            durationMs: finishedAt.difference(startedAt).inMilliseconds,
            rawContent: portrait.redactedRawResponse,
          ),
        ],
      );
      await _persist(current);
      return current;
    } on Object catch (caught) {
      final error = caught is LivingProviderException
          ? caught
          : const LivingProviderException(
              code: 'portrait_generation_failed',
              safeMessage:
                  'The character portrait could not be generated or archived.',
            );
      final finishedAt = _clock();
      final failedCheckpoints =
          Map<String, LivingPortraitCheckpoint>.from(
              current.portraitCheckpointsByCharacterId,
            )
            ..[characterId] = checkpoints[characterId]!.copyWith(
              status: LivingPortraitStatus.awaitingRetry,
              updatedAt: finishedAt,
              sourceReference: sourceReference,
              providerRequestId: error.requestId,
              durationMs: finishedAt.difference(startedAt).inMilliseconds,
              errorCode: error.code,
              errorMessage: error.safeMessage,
            );
      final failed = current.copyWith(
        updatedAt: finishedAt,
        clearGenerationJob: clearGenerationJob,
        portraitCheckpointsByCharacterId: failedCheckpoints,
        generationRecords: <LivingGenerationRecord>[
          ...current.generationRecords,
          LivingGenerationRecord(
            recordId: _idFactory('record-portrait-failed'),
            stage: LivingGenerationStage.portrait,
            attempt: attempt,
            status: LivingGenerationStatus.awaitingResume,
            model: _gateway.imageModel,
            startedAt: startedAt,
            finishedAt: finishedAt,
            requestPayload: <String, Object?>{
              'characterId': characterId,
              'prompt': prompt,
              'promptAsset': LivingCampaignPrompt.portrait.assetPath,
              'seed': seed,
              'styleReferenceHashes': referenceHashes,
            },
            responsePayload: <String, Object?>{
              'sourceReference': ?sourceReference,
            },
            inputTokens: null,
            contentLocale: current.contentLocale.tag,
            providerRequestId: error.requestId,
            transportType: 'http',
            durationMs: finishedAt.difference(startedAt).inMilliseconds,
            errorCode: error.code,
            errorMessage: error.safeMessage,
            rawContent: error.redactedResponseBody ?? '',
          ),
        ],
      );
      await _persist(failed);
      return failed;
    }
  }

  Future<LivingCampaignRun> _setStage(
    LivingCampaignRun run,
    LivingGenerationStage stage,
    int attempt, {
    String transportType = 'sse',
  }) async {
    final previous = run.generationJob;
    final now = _clock();
    final next = run.copyWith(
      updatedAt: now,
      generationJob: LivingGenerationJob(
        jobId: previous?.jobId ?? _idFactory('job'),
        stage: stage,
        status: LivingGenerationStatus.running,
        attempt: attempt,
        createdAt: previous?.createdAt ?? now,
        updatedAt: now,
        settingsSnapshot: previous?.settingsSnapshot ?? const {},
        transportType: transportType,
      ),
    );
    await _persist(next);
    return next;
  }

  Future<LivingCampaignRun> _recordValidationIssues(
    LivingCampaignRun run,
    List<String> issues,
  ) async {
    if (run.generationRecords.isEmpty) return run;
    final records = List<LivingGenerationRecord>.from(run.generationRecords);
    records[records.length - 1] = records.last.copyWith(
      status: LivingGenerationStatus.failed,
      validationIssues: issues,
      errorCode: 'semantic_validation_failed',
      errorMessage: issues.join(' '),
    );
    final next = run.copyWith(updatedAt: _clock(), generationRecords: records);
    await _persist(next);
    return next;
  }

  Future<LivingCampaignRun> _recordValidationWarnings(
    LivingCampaignRun run,
    List<String> warnings,
  ) async {
    if (run.generationRecords.isEmpty || warnings.isEmpty) return run;
    final records = List<LivingGenerationRecord>.from(run.generationRecords);
    records[records.length - 1] = records.last.copyWith(
      validationWarnings: warnings,
    );
    final next = run.copyWith(updatedAt: _clock(), generationRecords: records);
    await _persist(next);
    return next;
  }

  LivingGenerationResult _validationFailure(
    LivingCampaignRun run,
    String message,
  ) {
    final next = run.copyWith(
      updatedAt: _clock(),
      generationJob: run.generationJob?.copyWith(
        status: LivingGenerationStatus.failed,
        updatedAt: _clock(),
        errorCode: 'semantic_validation_failed',
        errorMessage: message,
      ),
    );
    unawaited(_persist(next));
    return LivingGenerationResult(
      run: next,
      completed: false,
      message: message,
    );
  }

  Future<void> _persist(LivingCampaignRun run) async {
    final persisted = await _mutationCoordinator.mutate(
      runId: run.runId,
      seed: run,
      mutation: (latest) => _mergeForPersistence(latest, run),
    );
    await _notify(persisted);
  }

  LivingCampaignRun _mergeForPersistence(
    LivingCampaignRun latest,
    LivingCampaignRun incoming,
  ) {
    final records = <String, LivingGenerationRecord>{
      for (final record in latest.generationRecords) record.recordId: record,
      for (final record in incoming.generationRecords) record.recordId: record,
    }.values.toList()..sort((a, b) => a.startedAt.compareTo(b.startedAt));
    final art = <String, LivingChapterEndingArtCheckpoint>{
      ...latest.chapterArtCheckpointsByChapterId,
    };
    for (final entry in incoming.chapterArtCheckpointsByChapterId.entries) {
      if (persistenceDomain == LivingCampaignPersistenceDomain.closureText) {
        art.putIfAbsent(entry.key, () => entry.value);
      } else {
        art[entry.key] = entry.value;
      }
    }
    final portraits = <String, LivingPortraitCheckpoint>{
      ...latest.portraitCheckpointsByCharacterId,
      ...incoming.portraitCheckpointsByCharacterId,
    };
    final aftermath = <String, LivingAftermathScene>{
      ...latest.aftermathScenesByChapterId,
      ...incoming.aftermathScenesByChapterId,
    };
    final assignments = <String, LivingIdentityAssignment>{
      ...latest.identityAssignmentsByCharacterId,
      ...incoming.identityAssignmentsByCharacterId,
    };
    final closures = <String, LivingChapterClosureCheckpoint>{
      ...latest.chapterClosureCheckpointsByChapterId,
    };
    for (final entry in incoming.chapterClosureCheckpointsByChapterId.entries) {
      closures[entry.key] = _mergeClosureCheckpoint(
        closures[entry.key],
        entry.value,
      );
    }

    if (persistenceDomain == LivingCampaignPersistenceDomain.chapterArt) {
      return latest.copyWith(
        updatedAt: incoming.updatedAt.isAfter(latest.updatedAt)
            ? incoming.updatedAt
            : latest.updatedAt,
        generationRecords: records,
        chapterArtCheckpointsByChapterId: art,
        portraitCheckpointsByCharacterId: portraits,
        chapterClosureCheckpointsByChapterId: closures,
      );
    }
    if (persistenceDomain == LivingCampaignPersistenceDomain.closureText) {
      final memories =
          <String, LivingMissionMemory>{
              for (final memory in latest.missionMemories)
                memory.missionId: memory,
              for (final memory in incoming.missionMemories)
                memory.missionId: memory,
            }.values.toList()
            ..sort((a, b) => a.missionNumber.compareTo(b.missionNumber));
      return latest.copyWith(
        status: incoming.status,
        completedAt: incoming.completedAt,
        updatedAt: incoming.updatedAt.isAfter(latest.updatedAt)
            ? incoming.updatedAt
            : latest.updatedAt,
        epilogue: incoming.epilogue,
        activeChapterNumber: incoming.activeChapterNumber,
        canon: incoming.canon,
        chapterPackages: incoming.chapterPackages,
        battleOutcomes: incoming.battleOutcomes,
        generationRecords: records,
        generationJob: incoming.generationJob,
        clearGenerationJob: incoming.generationJob == null,
        v2GenerationCheckpoint: incoming.v2GenerationCheckpoint,
        clearV2GenerationCheckpoint: incoming.v2GenerationCheckpoint == null,
        namedPiecesByName: incoming.namedPiecesByName,
        missionMemories: memories,
        historyDigests: incoming.historyDigests,
        portraitCheckpointsByCharacterId: portraits,
        chapterArtCheckpointsByChapterId: art,
        aftermathScenesByChapterId: aftermath,
        identityAssignmentsByCharacterId: assignments,
        chapterClosureCheckpointsByChapterId: closures,
      );
    }
    return incoming.copyWith(
      updatedAt: incoming.updatedAt.isAfter(latest.updatedAt)
          ? incoming.updatedAt
          : latest.updatedAt,
      generationRecords: records,
      portraitCheckpointsByCharacterId: portraits,
      chapterArtCheckpointsByChapterId: art,
      aftermathScenesByChapterId: aftermath,
      identityAssignmentsByCharacterId: assignments,
      chapterClosureCheckpointsByChapterId: closures,
    );
  }

  LivingChapterClosureCheckpoint _mergeClosureCheckpoint(
    LivingChapterClosureCheckpoint? latest,
    LivingChapterClosureCheckpoint incoming,
  ) {
    if (latest == null ||
        persistenceDomain == LivingCampaignPersistenceDomain.general) {
      return incoming;
    }
    if (persistenceDomain == LivingCampaignPersistenceDomain.chapterArt) {
      return latest.copyWith(
        imageAttempt: incoming.imageAttempt,
        imageStatus: incoming.imageStatus,
        updatedAt: incoming.updatedAt.isAfter(latest.updatedAt)
            ? incoming.updatedAt
            : latest.updatedAt,
        imageErrorCode: incoming.imageErrorCode,
        imageErrorMessage: incoming.imageErrorMessage,
        clearImageFailure:
            incoming.imageErrorCode == null &&
            incoming.imageErrorMessage == null,
      );
    }
    return latest.copyWith(
      textAttempt: incoming.textAttempt,
      textStatus: incoming.textStatus,
      updatedAt: incoming.updatedAt.isAfter(latest.updatedAt)
          ? incoming.updatedAt
          : latest.updatedAt,
      textErrorCode: incoming.textErrorCode,
      textErrorMessage: incoming.textErrorMessage,
      clearTextFailure:
          incoming.textErrorCode == null && incoming.textErrorMessage == null,
    );
  }

  Future<void> _notify(LivingCampaignRun run) async {
    final callback = _onProgress;
    if (callback != null) await callback(run);
  }
}

class _LivingV2Call {
  const _LivingV2Call({required this.run, required this.response});

  final LivingCampaignRun run;
  final DoubaoJsonResponse response;
}

class _PreparedDirectorPayload {
  const _PreparedDirectorPayload({required this.run, required this.payload});

  final LivingCampaignRun run;
  final Map<String, Object?> payload;
}

class _DecodedDigest {
  const _DecodedDigest({required this.value, required this.issues});

  final LivingHistoryDigest? value;
  final List<String> issues;
}

class _LivingV2CallFailure implements Exception {
  const _LivingV2CallFailure({required this.run, required this.error});

  final LivingCampaignRun run;
  final LivingProviderException error;
}
