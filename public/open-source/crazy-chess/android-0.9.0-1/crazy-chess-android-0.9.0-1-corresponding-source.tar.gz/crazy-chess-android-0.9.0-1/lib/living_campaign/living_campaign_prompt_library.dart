import 'package:flutter/services.dart';

enum LivingCampaignPrompt {
  prologue('assets/prompts/living_campaign/prologue.md'),
  prologueRepair('assets/prompts/living_campaign/prologue_repair.md'),
  chronicler('assets/prompts/living_campaign/chronicler.md'),
  chroniclerRepair('assets/prompts/living_campaign/chronicler_repair.md'),
  director('assets/prompts/living_campaign/director.md'),
  directorRepair('assets/prompts/living_campaign/director_repair.md'),
  builder('assets/prompts/living_campaign/builder.md'),
  builderRepair('assets/prompts/living_campaign/builder_repair.md'),
  historyCompressor('assets/prompts/living_campaign/history_compressor.md'),
  historyCompressorRepair(
    'assets/prompts/living_campaign/history_compressor_repair.md',
  ),
  portrait('assets/prompts/living_campaign/portrait.md'),
  chapterEndingArt('assets/prompts/living_campaign/chapter_ending_art.md');

  const LivingCampaignPrompt(this.assetPath);

  final String assetPath;
}

abstract interface class LivingCampaignPromptLibrary {
  Future<String> load(LivingCampaignPrompt prompt);
}

class AssetLivingCampaignPromptLibrary implements LivingCampaignPromptLibrary {
  AssetLivingCampaignPromptLibrary({AssetBundle? bundle}) : _bundle = bundle;

  final AssetBundle? _bundle;
  final Map<LivingCampaignPrompt, Future<String>> _cache =
      <LivingCampaignPrompt, Future<String>>{};

  @override
  Future<String> load(
    LivingCampaignPrompt prompt,
  ) => _cache.putIfAbsent(prompt, () async {
    final source = await (_bundle ?? rootBundle).loadString(prompt.assetPath);
    final normalized = source.trim();
    if (normalized.isEmpty) {
      throw StateError('Living Campaign prompt is blank: ${prompt.assetPath}');
    }
    return normalized;
  });
}
