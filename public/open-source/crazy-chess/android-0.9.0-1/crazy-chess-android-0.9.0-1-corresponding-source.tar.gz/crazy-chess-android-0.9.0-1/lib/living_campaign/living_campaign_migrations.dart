import 'dart:convert';

import 'living_campaign_models.dart';

abstract final class LivingCampaignRunCodec {
  static const int currentSchemaVersion = 5;

  static Map<String, Object?> encode(LivingCampaignRun run) {
    if (run.schemaVersion != currentSchemaVersion) {
      throw FormatException(
        'Cannot encode Living Campaign schema ${run.schemaVersion}; '
        'current schema is $currentSchemaVersion.',
      );
    }
    return run.toJson();
  }

  static LivingCampaignRun decode(Map<String, Object?> source) {
    return LivingCampaignRun.fromJson(migrate(source));
  }

  static Map<String, Object?> migrate(Map<String, Object?> source) {
    final migrated = _jsonCopy(source);
    final rawVersion = migrated['schemaVersion'];
    final version = rawVersion == null ? 0 : (rawVersion as num).toInt();
    if (version < 0 || version > currentSchemaVersion) {
      throw FormatException(
        'Unsupported Living Campaign schemaVersion $version.',
      );
    }
    if (version == 0) {
      _migratePreVersionArchiveToV1(migrated);
    }
    if ((migrated['schemaVersion'] as num).toInt() == 1) {
      _migrateV1ToV2(migrated);
    }
    if ((migrated['schemaVersion'] as num).toInt() == 2) {
      _migrateV2ToV3(migrated);
    }
    if ((migrated['schemaVersion'] as num).toInt() == 3) {
      _migrateV3ToV4(migrated);
    }
    if ((migrated['schemaVersion'] as num).toInt() == 4) {
      _migrateV4ToV5(migrated);
    }
    return migrated;
  }

  static void _migrateV1ToV2(Map<String, Object?> run) {
    run['schemaVersion'] = 2;
    run.putIfAbsent('namedPiecesByName', () => <String, Object?>{});
    run.putIfAbsent('missionMemories', () => <Object?>[]);
    run.putIfAbsent('historyDigests', () => <Object?>[]);
    run.remove('v2GenerationCheckpoint');
  }

  static void _migrateV2ToV3(Map<String, Object?> run) {
    run['schemaVersion'] = 3;
    for (final value in _list(run['chapterPackages'])) {
      _migrateChapterObjective(_map(value));
    }
    final checkpointValue = run['v2GenerationCheckpoint'];
    if (checkpointValue != null) {
      final checkpoint = _map(checkpointValue);
      final directorValue = checkpoint['directorDecision'];
      if (directorValue != null) {
        _migrateDirectorObjective(_map(directorValue));
      }
      final chapterValue = checkpoint['chapterPackage'];
      if (chapterValue != null) {
        _migrateChapterObjective(_map(chapterValue));
      }
    }
    for (final value in _list(run['battleOutcomes'])) {
      final outcome = _map(value);
      if (outcome['objectiveType'] == 'surviveTurns') {
        outcome['objectiveType'] = 'surviveRounds';
      }
      final actions = (outcome['completedTurns'] as num?)?.toInt() ?? 0;
      outcome.putIfAbsent('completedRoundCount', () => (actions + 1) ~/ 2);
    }
    run.putIfAbsent(
      'chapterArtCheckpointsByChapterId',
      () => <String, Object?>{},
    );
  }

  static void _migrateV3ToV4(Map<String, Object?> run) {
    run['schemaVersion'] = 4;
    run.putIfAbsent('aftermathScenesByChapterId', () => <String, Object?>{});
    run.putIfAbsent(
      'identityAssignmentsByCharacterId',
      () => <String, Object?>{},
    );
    run.putIfAbsent(
      'chapterClosureCheckpointsByChapterId',
      () => <String, Object?>{},
    );
    for (final value in _list(run['battleOutcomes'])) {
      _map(value).putIfAbsent('pieceEndStates', () => <Object?>[]);
    }
    for (final value in _list(run['generationRecords'])) {
      _map(value).putIfAbsent('validationWarnings', () => <Object?>[]);
    }

    final named = _map(run['namedPiecesByName']);
    final renamed = <String, Object?>{};
    final renamedCharacters = <String, String>{};
    for (final entry in named.entries) {
      final record = _map(entry.value);
      record.putIfAbsent('needsNaming', () => false);
      final currentName = record['name'] as String? ?? entry.key;
      final rawMachineLabel = RegExp(
        r'^Turncoat\s+(King|Queen|Rook|Bishop|Knight)\b',
        caseSensitive: false,
      ).hasMatch(currentName);
      if (!rawMachineLabel) {
        renamed[entry.key] = record;
        continue;
      }
      final type = (record['pieceType'] as String? ?? 'rook').toLowerCase();
      final title = '${type[0].toUpperCase()}${type.substring(1)}';
      var provisional = 'The Turncoat $title';
      var suffix = 2;
      while (renamed.containsKey(provisional)) {
        provisional = 'The Turncoat $title $suffix';
        suffix++;
      }
      record['name'] = provisional;
      record['needsNaming'] = true;
      renamed[provisional] = record;
      final characterId = record['characterId'] as String?;
      if (characterId != null) renamedCharacters[characterId] = provisional;
    }
    run['namedPiecesByName'] = renamed;

    final canon = _map(run['canon']);
    final characters = _map(canon['charactersById']);
    for (final entry in renamedCharacters.entries) {
      final value = characters[entry.key];
      if (value == null) continue;
      final character = _map(value);
      final old = character['originalName'] as String?;
      if (old != null && old != entry.value) {
        final aliases = _list(character['aliases']);
        if (!aliases.contains(old)) aliases.add(old);
        character['aliases'] = aliases;
      }
      character['originalName'] = entry.value;
      characters[entry.key] = character;
    }
    canon['charactersById'] = characters;
    run['canon'] = canon;
  }

  static void _migrateV4ToV5(Map<String, Object?> run) {
    run['schemaVersion'] = 5;
    run['contentLocale'] = 'en';
    for (final value in _list(run['generationRecords'])) {
      _map(value).putIfAbsent('contentLocale', () => 'en');
    }
  }

  static void _migrateChapterObjective(Map<String, Object?> chapter) {
    final objective = _map(chapter['objective']);
    if (objective['type'] == 'surviveTurns') {
      objective['type'] = 'surviveRounds';
    }
    final legacy = (objective.remove('surviveTurns') as num?)?.toInt();
    if (legacy != null) {
      objective['legacySurviveActionCount'] = legacy;
      objective['surviveRounds'] = (legacy + 1) ~/ 2;
    }
    chapter['objective'] = objective;
  }

  static void _migrateDirectorObjective(Map<String, Object?> director) {
    if (director['objectiveType'] == 'surviveTurns') {
      director['objectiveType'] = 'surviveRounds';
    }
    final legacy = (director.remove('surviveTurns') as num?)?.toInt();
    if (legacy != null) {
      director['legacySurviveActionCount'] = legacy;
      director['surviveRounds'] = (legacy + 1) ~/ 2;
    }
  }

  static void _migratePreVersionArchiveToV1(Map<String, Object?> run) {
    run['schemaVersion'] = 1;
    run.putIfAbsent('campaignTitle', () => 'Living Campaign');
    run.putIfAbsent('storyPromise', () => '');
    run.putIfAbsent('generationRecords', () => <Object?>[]);

    final canon = _map(run['canon']);
    canon['schemaVersion'] = 1;
    run['canon'] = canon;

    run['chapterPackages'] = _list(run['chapterPackages'])
        .map((value) {
          final chapter = _map(value);
          chapter['schemaVersion'] = 1;
          chapter.putIfAbsent('pressureTier', () => 'even');
          chapter.putIfAbsent('reservePieceIds', () => <Object?>[]);
          return chapter;
        })
        .toList(growable: false);

    run['battleOutcomes'] = _list(run['battleOutcomes'])
        .map((value) {
          final outcome = _map(value);
          outcome.putIfAbsent('pressureTier', () => 'even');
          outcome.putIfAbsent('purchasedPieces', () => <Object?>[]);
          outcome.putIfAbsent('purchaseEvents', () => <Object?>[]);
          return outcome;
        })
        .toList(growable: false);

    final checkpointValue = run['generationCheckpoint'];
    if (checkpointValue != null) {
      final checkpoint = _map(checkpointValue);
      final director = _map(checkpoint['directorPatch']);
      director['schemaVersion'] = 1;
      checkpoint['directorPatch'] = director;
      final chapterValue = checkpoint['chapterPackage'];
      if (chapterValue != null) {
        final chapter = _map(chapterValue);
        chapter['schemaVersion'] = 1;
        chapter.putIfAbsent('pressureTier', () => 'even');
        chapter.putIfAbsent('reservePieceIds', () => <Object?>[]);
        checkpoint['chapterPackage'] = chapter;
      }
      run['generationCheckpoint'] = checkpoint;
    }
  }

  static Map<String, Object?> _jsonCopy(Map<String, Object?> source) {
    return Map<String, Object?>.from(
      jsonDecode(jsonEncode(source)) as Map<Object?, Object?>,
    );
  }

  static Map<String, Object?> _map(Object? value) =>
      Map<String, Object?>.from(value! as Map<Object?, Object?>);

  static List<Object?> _list(Object? value) =>
      List<Object?>.from(value! as List<Object?>);
}
