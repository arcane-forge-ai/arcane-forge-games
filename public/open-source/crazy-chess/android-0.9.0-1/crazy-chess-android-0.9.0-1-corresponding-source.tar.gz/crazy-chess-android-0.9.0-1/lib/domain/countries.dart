import 'package:flutter/material.dart';

import '../l10n/runtime_game_locale.dart';

class CountryConfig {
  const CountryConfig({
    required this.id,
    required String name,
    required String shortName,
    required String fantasy,
    required this.asset,
    required this.color,
    required this.secondaryColor,
    required this.startingGoldModifier,
    required this.merchantPayoutModifier,
    required this.offenseModifier,
    this.availableInSetup = true,
    this.representativeFullAsset,
    this.representativeBustAsset,
    this.portraitReady = false,
    this.failedRefundPercent = 0,
    this.failedRefundCap = 0,
    this.opponentMerchantPayoutPenalty = 0,
    this.spyRevealBonus = 0,
    this.ironEffectiveOfferPenalty = 0,
    this.horseKnightPricePercent = 0,
    this.horseKnightOfferCap = 0,
    this.horseKnightCaptureLoyaltyDamage = 0,
    this.captureGoldSteal = 0,
    this.sunlitExposedChanceBonus = 0,
    this.temporaryIdentity = false,
  }) : englishName = name,
       englishShortName = shortName,
       englishFantasy = fantasy;

  final String id;
  final String englishName;
  final String englishShortName;
  final String englishFantasy;
  final String asset;
  final Color color;
  final Color secondaryColor;
  final int startingGoldModifier;
  final int merchantPayoutModifier;
  final int offenseModifier;
  final bool availableInSetup;
  final String? representativeFullAsset;
  final String? representativeBustAsset;
  final bool portraitReady;
  final int failedRefundPercent;
  final int failedRefundCap;
  final int opponentMerchantPayoutPenalty;
  final int spyRevealBonus;
  final int ironEffectiveOfferPenalty;
  final int horseKnightPricePercent;
  final int horseKnightOfferCap;
  final int horseKnightCaptureLoyaltyDamage;
  final int captureGoldSteal;
  final int sunlitExposedChanceBonus;
  final bool temporaryIdentity;

  String get name => switch (id) {
    'ashen' => RuntimeGameLocale.copy.countryAshenCourt,
    'mercantile' => RuntimeGameLocale.copy.countryMercantileLeague,
    'iron' => RuntimeGameLocale.copy.countryIronDuchy,
    'horse' => RuntimeGameLocale.copy.countryHorseKingdom,
    'spy' => RuntimeGameLocale.copy.countrySpyCourt,
    'corsair' => RuntimeGameLocale.copy.countryCorsairFreeholds,
    'sunlit' => RuntimeGameLocale.copy.countrySunlitSynod,
    _ => englishName,
  };

  String get shortName => switch (id) {
    'ashen' => RuntimeGameLocale.copy.countryAshenShort,
    'mercantile' => RuntimeGameLocale.copy.countryMercantileShort,
    'iron' => RuntimeGameLocale.copy.countryIronShort,
    'horse' => RuntimeGameLocale.copy.countryHorseShort,
    'spy' => RuntimeGameLocale.copy.countrySpyShort,
    'corsair' => RuntimeGameLocale.copy.countryCorsairShort,
    'sunlit' => RuntimeGameLocale.copy.countrySunlitShort,
    _ => englishShortName,
  };

  String get fantasy => switch (id) {
    'ashen' => RuntimeGameLocale.copy.countryAshenFantasy,
    'mercantile' => RuntimeGameLocale.copy.countryMercantileFantasy,
    'iron' => RuntimeGameLocale.copy.countryIronFantasy,
    'horse' => RuntimeGameLocale.copy.countryHorseFantasy,
    'spy' => RuntimeGameLocale.copy.countrySpyFantasy,
    'corsair' => RuntimeGameLocale.copy.countryCorsairFantasy,
    'sunlit' => RuntimeGameLocale.copy.countrySunlitFantasy,
    _ => englishFantasy,
  };

  String get monogram => switch (id) {
    'corsair' => 'CF',
    'sunlit' => 'SS',
    _ => englishShortName.substring(0, 1),
  };

  String get loyaltyStartSummary => switch (id) {
    'mercantile' => '45–55',
    'spy' => '55–65',
    'horse' => '55–65',
    'iron' => '65–75 · Pawns/Rooks 80–90',
    _ => '55–65',
  };

  String get loyaltySummary =>
      RuntimeGameLocale.copy.countryLoyaltyStartsAt(loyaltyStartSummary);
}

const Map<String, CountryConfig> countries = {
  'ashen': CountryConfig(
    id: 'ashen',
    name: 'Ashen Court',
    shortName: 'Ashen',
    fantasy:
        'A passive-free court whose identity belongs only to Living Campaign.',
    asset: 'assets/runtime/pieces/countries/ashen/crest_large.webp',
    color: Color(0xFF6b625b),
    secondaryColor: Color(0xFFc39a62),
    startingGoldModifier: 0,
    merchantPayoutModifier: 0,
    offenseModifier: 0,
    availableInSetup: false,
    representativeFullAsset:
        'assets/runtime/pieces/characters/living/orsain_half_body.webp',
    representativeBustAsset:
        'assets/runtime/pieces/characters/living/orsain_half_body.webp',
    portraitReady: true,
  ),
  'mercantile': CountryConfig(
    id: 'mercantile',
    name: 'Mercantile League',
    shortName: 'Mercantile',
    fantasy:
        'Rich traders with flexible loyalty and refunds after bad contracts.',
    asset: 'assets/runtime/ui/identity/emblem_mercantile.webp',
    color: Color(0xFF1d8c82),
    secondaryColor: Color(0xFFd9b15f),
    startingGoldModifier: 4,
    merchantPayoutModifier: 3,
    offenseModifier: 4,
    representativeFullAsset:
        'assets/runtime/pieces/countries/mercantile/representative_full_neutral.webp',
    representativeBustAsset:
        'assets/runtime/pieces/countries/mercantile/representative_bust_neutral.webp',
    portraitReady: true,
    failedRefundPercent: 25,
    failedRefundCap: 4,
  ),
  'iron': CountryConfig(
    id: 'iron',
    name: 'Iron Duchy',
    shortName: 'Iron',
    fantasy:
        'Low-income fortress state with stubborn soldiers and hard-to-buy walls.',
    asset: 'assets/runtime/ui/identity/emblem_iron.webp',
    color: Color(0xFF6d717d),
    secondaryColor: Color(0xFFbb3046),
    startingGoldModifier: 0,
    merchantPayoutModifier: -2,
    offenseModifier: 0,
    representativeFullAsset:
        'assets/runtime/pieces/countries/iron/representative_full_neutral.webp',
    representativeBustAsset:
        'assets/runtime/pieces/countries/iron/representative_bust_neutral.webp',
    portraitReady: true,
    ironEffectiveOfferPenalty: 25,
  ),
  'horse': CountryConfig(
    id: 'horse',
    name: 'Horse Kingdom',
    shortName: 'Horse',
    fantasy:
        'Cavalry nobility that turns knight contracts into political currency.',
    asset: 'assets/runtime/ui/identity/emblem_horse.webp',
    color: Color(0xFF4b8fc7),
    secondaryColor: Color(0xFF79c567),
    startingGoldModifier: 0,
    merchantPayoutModifier: 0,
    offenseModifier: 0,
    horseKnightPricePercent: 50,
    horseKnightOfferCap: 90,
    horseKnightCaptureLoyaltyDamage: 10,
  ),
  'spy': CountryConfig(
    id: 'spy',
    name: 'Spy Court',
    shortName: 'Spy',
    fantasy:
        'Information warfare, loyalty intelligence, and quiet income disruption.',
    asset: 'assets/runtime/ui/match/mercantile_spy/spy_crest.webp',
    color: Color(0xFF6c4ab6),
    secondaryColor: Color(0xFFc7c7d4),
    startingGoldModifier: 0,
    merchantPayoutModifier: 0,
    offenseModifier: 0,
    representativeFullAsset:
        'assets/runtime/pieces/characters/match/spy_king_portrait.webp',
    representativeBustAsset:
        'assets/runtime/pieces/characters/match/spy_king_portrait.webp',
    portraitReady: true,
    opponentMerchantPayoutPenalty: 1,
    spyRevealBonus: 3,
  ),
  'corsair': CountryConfig(
    id: 'corsair',
    name: 'Corsair Freeholds',
    shortName: 'Corsair',
    fantasy:
        'Sea-raider city states that turn every battlefield capture into stolen treasury.',
    asset: 'assets/runtime/ui/identity/shared_court_portrait.webp',
    color: Color(0xFF1F6273),
    secondaryColor: Color(0xFFD28A43),
    startingGoldModifier: 0,
    merchantPayoutModifier: 0,
    offenseModifier: 0,
    captureGoldSteal: 6,
    temporaryIdentity: true,
  ),
  'sunlit': CountryConfig(
    id: 'sunlit',
    name: 'Sunlit Synod',
    shortName: 'Sunlit',
    fantasy:
        'A radiant bishop-led court that exposes enemy loyalty and rises or falls with its clergy.',
    asset: 'assets/runtime/ui/identity/shared_court_portrait.webp',
    color: Color(0xFFB78524),
    secondaryColor: Color(0xFFFFE4A3),
    startingGoldModifier: 0,
    merchantPayoutModifier: 0,
    offenseModifier: 0,
    sunlitExposedChanceBonus: 25,
    temporaryIdentity: true,
  ),
};

Iterable<CountryConfig> get selectableCountries =>
    countries.values.where((country) => country.availableInSetup);
