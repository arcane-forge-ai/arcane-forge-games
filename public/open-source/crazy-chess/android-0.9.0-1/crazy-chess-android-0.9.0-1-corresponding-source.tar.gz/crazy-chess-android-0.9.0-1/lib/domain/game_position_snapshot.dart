import 'chess_models.dart';

class PositionPiece {
  const PositionPiece({
    required this.type,
    required this.color,
    required this.hasMoved,
  });

  final PieceType type;
  final PieceColor color;
  final bool hasMoved;
}

class GamePositionSnapshot {
  GamePositionSnapshot({
    required List<List<PositionPiece?>> board,
    required this.turn,
    required this.turnCount,
    required this.enPassantSquare,
  }) : board = List<List<PositionPiece?>>.unmodifiable(
         board.map((row) => List<PositionPiece?>.unmodifiable(row)),
       );

  final List<List<PositionPiece?>> board;
  final PieceColor turn;
  final int turnCount;
  final Square? enPassantSquare;

  PositionPiece? pieceAt(Square square) => board[square.row][square.col];
}
