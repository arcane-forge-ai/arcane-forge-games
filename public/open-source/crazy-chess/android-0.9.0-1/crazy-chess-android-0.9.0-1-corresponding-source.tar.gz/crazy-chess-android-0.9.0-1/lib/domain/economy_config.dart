import 'dart:math' as math;

import 'chess_models.dart';

const Map<PieceType, int> fairPriceAnchors = {
  PieceType.pawn: 6,
  PieceType.knight: 14,
  PieceType.bishop: 14,
  PieceType.rook: 22,
  PieceType.queen: 40,
};

class FairPriceBand {
  const FairPriceBand(this.minimum, this.maximum);

  final int minimum;
  final int maximum;
}

class LoyaltyProfile {
  const LoyaltyProfile({
    required this.minimum,
    required this.maximum,
    required this.humiliationThresholdPercent,
    required this.rallyAmount,
  });

  final int minimum;
  final int maximum;
  final int humiliationThresholdPercent;
  final int rallyAmount;
}

LoyaltyProfile loyaltyProfileFor(String countryId, PieceType type) {
  switch (countryId) {
    case 'mercantile':
      return const LoyaltyProfile(
        minimum: 45,
        maximum: 55,
        humiliationThresholdPercent: 50,
        rallyAmount: 8,
      );
    case 'spy':
      return const LoyaltyProfile(
        minimum: 55,
        maximum: 65,
        humiliationThresholdPercent: 50,
        rallyAmount: 8,
      );
    case 'horse':
      return const LoyaltyProfile(
        minimum: 55,
        maximum: 65,
        humiliationThresholdPercent: 50,
        rallyAmount: 8,
      );
    case 'iron':
      final isPawnOrRook = type == PieceType.pawn || type == PieceType.rook;
      return LoyaltyProfile(
        minimum: isPawnOrRook ? 80 : 65,
        maximum: isPawnOrRook ? 90 : 75,
        humiliationThresholdPercent: isPawnOrRook ? 100 : 75,
        rallyAmount: isPawnOrRook ? 12 : 10,
      );
    default:
      return const LoyaltyProfile(
        minimum: 55,
        maximum: 65,
        humiliationThresholdPercent: 50,
        rallyAmount: 8,
      );
  }
}

int? randomStartingLoyalty(
  String countryId,
  PieceType type,
  math.Random random,
) {
  if (type == PieceType.king) {
    return null;
  }
  final profile = loyaltyProfileFor(countryId, type);
  return profile.minimum +
      random.nextInt(profile.maximum - profile.minimum + 1);
}

bool isHumiliatingOffer({
  required int offer,
  required int fairPrice,
  required LoyaltyProfile profile,
}) {
  return offer * 100 < fairPrice * profile.humiliationThresholdPercent;
}

int failedOfferBasePressure({required int offer, required int fairPrice}) {
  if (offer * 100 < fairPrice * 100) {
    return 6;
  }
  if (offer * 100 < fairPrice * 150) {
    return 12;
  }
  return 18;
}

int nearMissPressureBonus(int failedMargin) {
  if (failedMargin <= 5) {
    return 12;
  }
  if (failedMargin <= 15) {
    return 8;
  }
  if (failedMargin <= 30) {
    return 4;
  }
  return 0;
}

int loyaltyChanceModifier(int loyalty) {
  return ((60 - loyalty) * 0.6).round();
}

const Map<PieceType, FairPriceBand> fairPriceBands = {
  PieceType.pawn: FairPriceBand(5, 7),
  PieceType.knight: FairPriceBand(11, 17),
  PieceType.bishop: FairPriceBand(11, 17),
  PieceType.rook: FairPriceBand(17, 27),
  PieceType.queen: FairPriceBand(30, 50),
};

int? randomFairPrice(PieceType type, math.Random random) {
  final band = fairPriceBands[type];
  if (band == null) {
    return null;
  }
  return band.minimum + random.nextInt(band.maximum - band.minimum + 1);
}

const Map<PieceType, int> baseChances = {
  PieceType.pawn: 40,
  PieceType.knight: 28,
  PieceType.bishop: 28,
  PieceType.rook: 20,
  PieceType.queen: 10,
  PieceType.king: 0,
};

const Map<PieceType, int> chanceFloors = {
  PieceType.pawn: 5,
  PieceType.knight: 4,
  PieceType.bishop: 4,
  PieceType.rook: 3,
  PieceType.queen: 2,
  PieceType.king: 0,
};

const Map<PieceType, int> chanceCaps = {
  PieceType.pawn: 90,
  PieceType.knight: 75,
  PieceType.bishop: 75,
  PieceType.rook: 65,
  PieceType.queen: 45,
  PieceType.king: 0,
};
