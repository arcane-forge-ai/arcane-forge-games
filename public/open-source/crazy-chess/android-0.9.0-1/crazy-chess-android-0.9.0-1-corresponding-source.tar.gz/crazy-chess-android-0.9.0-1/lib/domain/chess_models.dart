import 'package:flutter/foundation.dart';

enum PieceColor { white, black }

enum PieceType { pawn, knight, bishop, rook, queen, king }

enum GamePhase { setup, playing, offer, redeploy, promotion, gameOver }

enum GameEndReason { none, checkmate, stalemate, kingTrapfall }

enum OpponentMode { local, stockfish }

enum PlayMode {
  localDuel,
  aiDuel,
  storyCampaign,
  lastPieceStanding,
  livingCampaign,
}

enum LoyaltyBand {
  broken('Broken', 0),
  fractured('Fractured', 1),
  susceptible('Susceptible', 2),
  wavering('Wavering', 3),
  loyal('Loyal', 4),
  steadfast('Steadfast', 5);

  const LoyaltyBand(this.label, this.filledSegments);

  final String label;
  final int filledSegments;
}

enum LoyaltyIntelligence { hidden, coarse, exact }

enum OfferResolutionKind { rolled, humiliated, automatic }

enum OfferReaction { accepted, humiliated, tempted }

LoyaltyBand loyaltyBandFor(int loyalty) {
  if (loyalty <= 0) {
    return LoyaltyBand.broken;
  }
  if (loyalty <= 20) {
    return LoyaltyBand.fractured;
  }
  if (loyalty <= 40) {
    return LoyaltyBand.susceptible;
  }
  if (loyalty <= 60) {
    return LoyaltyBand.wavering;
  }
  if (loyalty <= 80) {
    return LoyaltyBand.loyal;
  }
  return LoyaltyBand.steadfast;
}

@immutable
class Square {
  const Square(this.row, this.col);

  final int row;
  final int col;

  @override
  bool operator ==(Object other) {
    return other is Square && other.row == row && other.col == col;
  }

  @override
  int get hashCode => Object.hash(row, col);
}

class ChessMove {
  const ChessMove({
    required this.from,
    required this.to,
    this.isCapture = false,
    this.isEnPassant = false,
    this.isCastle = false,
    this.isPromotion = false,
  });

  final Square from;
  final Square to;
  final bool isCapture;
  final bool isEnPassant;
  final bool isCastle;
  final bool isPromotion;
}

class ChessPiece {
  ChessPiece({
    required this.id,
    required this.type,
    required this.color,
    required this.countryId,
    required this.loyalty,
    required this.fairPrice,
    this.hasMoved = false,
    this.personalityId,
    this.characterId,
    this.newlyPurchased = false,
  });

  final String id;
  PieceType type;
  PieceColor color;
  String countryId;
  int? loyalty;
  final int? fairPrice;
  bool hasMoved;
  String? personalityId;
  final String? characterId;
  bool newlyPurchased;

  ChessPiece copy() {
    return ChessPiece(
      id: id,
      type: type,
      color: color,
      countryId: countryId,
      loyalty: loyalty,
      fairPrice: fairPrice,
      hasMoved: hasMoved,
      personalityId: personalityId,
      characterId: characterId,
      newlyPurchased: newlyPurchased,
    );
  }
}

class ChancePreview {
  const ChancePreview({
    required this.valid,
    required this.reason,
    required this.finalChance,
    required this.baseChance,
    required this.goldModifier,
    required this.contractModifier,
    required this.attackerModifier,
    required this.loyalty,
    required this.loyaltyModifier,
    required this.floor,
    required this.cap,
    this.automatic = false,
    this.treasureModifier = 0,
    this.ringTokenApplied = false,
    this.actualOfferGold = 0,
    this.effectiveOfferGold = 0,
    this.countryOfferPriceAdjustment = 0,
    this.countryChanceModifier = 0,
    this.targetExposed = false,
  });

  final bool valid;
  final String reason;
  final int finalChance;
  final int baseChance;
  final int goldModifier;
  final int contractModifier;
  final int attackerModifier;
  final int? loyalty;
  final int loyaltyModifier;
  final int floor;
  final int cap;
  final bool automatic;
  final int treasureModifier;
  final bool ringTokenApplied;
  final int actualOfferGold;
  final int effectiveOfferGold;
  final int countryOfferPriceAdjustment;
  final int countryChanceModifier;
  final bool targetExposed;
}

class OfferResult {
  const OfferResult({
    required this.success,
    required this.roll,
    required this.chance,
    required this.paid,
    required this.refund,
    required this.targetName,
    this.targetType = PieceType.pawn,
    this.targetCountryId = 'neutral',
    this.targetColor = PieceColor.black,
    this.resolutionKind = OfferResolutionKind.rolled,
    this.publicReaction = OfferReaction.accepted,
    this.loyaltyBefore,
    this.loyaltyAfter,
    this.buyerHadExactIntel = false,
    this.treasureModifier = 0,
    this.ringTokenConsumed = false,
  });

  final bool success;
  final int? roll;
  final int chance;
  final int paid;
  final int refund;
  final String targetName;
  final PieceType targetType;
  final String targetCountryId;
  final PieceColor targetColor;
  final OfferResolutionKind resolutionKind;
  final OfferReaction publicReaction;
  final int? loyaltyBefore;
  final int? loyaltyAfter;
  final bool buyerHadExactIntel;
  final int treasureModifier;
  final bool ringTokenConsumed;
}
