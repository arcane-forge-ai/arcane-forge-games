import 'package:flutter/foundation.dart';

import 'chess_models.dart';

@immutable
class PresentedPiece {
  const PresentedPiece({
    required this.id,
    required this.type,
    required this.color,
    required this.countryId,
    required this.loyalty,
    required this.fairPrice,
    required this.hasMoved,
    required this.personalityId,
    required this.newlyPurchased,
    required this.loyaltyBand,
  });

  factory PresentedPiece.fromPiece(
    ChessPiece piece, {
    LoyaltyBand? loyaltyBand,
  }) {
    return PresentedPiece(
      id: piece.id,
      type: piece.type,
      color: piece.color,
      countryId: piece.countryId,
      loyalty: piece.loyalty,
      fairPrice: piece.fairPrice,
      hasMoved: piece.hasMoved,
      personalityId: piece.personalityId,
      newlyPurchased: piece.newlyPurchased,
      loyaltyBand: loyaltyBand,
    );
  }

  final String id;
  final PieceType type;
  final PieceColor color;
  final String countryId;
  final int? loyalty;
  final int? fairPrice;
  final bool hasMoved;
  final String? personalityId;
  final bool newlyPurchased;
  final LoyaltyBand? loyaltyBand;

  ChessPiece toChessPiece() {
    return ChessPiece(
      id: id,
      type: type,
      color: color,
      countryId: countryId,
      loyalty: loyalty,
      fairPrice: fairPrice,
      hasMoved: hasMoved,
      personalityId: personalityId,
      newlyPurchased: newlyPurchased,
    );
  }
}

enum BoardMotionKind { chessMove, castle, redeploy }

@immutable
class PieceMotion {
  const PieceMotion({
    required this.piece,
    required this.from,
    required this.to,
  });

  final PresentedPiece piece;
  final Square from;
  final Square to;
}

@immutable
class BoardMotionEvent {
  const BoardMotionEvent({
    required this.serial,
    required this.kind,
    required this.motions,
    this.capturedPiece,
    this.capturedSquare,
  });

  final int serial;
  final BoardMotionKind kind;
  final List<PieceMotion> motions;
  final PresentedPiece? capturedPiece;
  final Square? capturedSquare;
}

@immutable
class BetrayalTransformEvent {
  const BetrayalTransformEvent({
    required this.serial,
    required this.square,
    required this.before,
    required this.after,
  });

  final int serial;
  final Square square;
  final PresentedPiece before;
  final PresentedPiece after;

  BetrayalTransformEvent withSerial(int value) {
    return BetrayalTransformEvent(
      serial: value,
      square: square,
      before: before,
      after: after,
    );
  }
}
