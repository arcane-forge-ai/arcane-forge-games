import java.util.Properties

plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

val signingPropertiesFile = rootProject.file("key.properties")
val signingProperties = Properties()
if (signingPropertiesFile.exists()) {
    signingPropertiesFile.inputStream().use(signingProperties::load)
}

fun signingValue(name: String): String? =
    signingProperties.getProperty(name)?.trim()?.takeIf { it.isNotEmpty() }
        ?: System.getenv(
            "CRAZY_CHESS_ANDROID_${name.replace(Regex("([a-z])([A-Z])"), "$1_$2").uppercase()}"
        )
            ?.trim()
            ?.takeIf { it.isNotEmpty() }

val storeFileValue = signingValue("storeFile")
val storePasswordValue = signingValue("storePassword")
val keyAliasValue = signingValue("keyAlias")
val keyPasswordValue = signingValue("keyPassword")
val releaseSigningConfigured = listOf(
    storeFileValue,
    storePasswordValue,
    keyAliasValue,
    keyPasswordValue,
).all { it != null }
val allowDebugSigning =
    System.getenv("CRAZY_CHESS_ALLOW_DEBUG_SIGNING")?.lowercase() == "true"
val releaseBuildRequested = gradle.startParameter.taskNames.any {
    it.contains("release", ignoreCase = true)
}
val configuredAndroidAbis = System.getenv("CRAZY_CHESS_ANDROID_ABIS")
    ?.split(',')
    ?.map(String::trim)
    ?.filter(String::isNotEmpty)
    ?.takeIf { it.isNotEmpty() }

if (releaseBuildRequested && !releaseSigningConfigured && !allowDebugSigning) {
    throw GradleException(
        "Android release signing is not configured. Copy " +
            "android/key.properties.example to android/key.properties and " +
            "configure an upload keystore. Set " +
            "CRAZY_CHESS_ALLOW_DEBUG_SIGNING=true only for local preview builds.",
    )
}

android {
    namespace = "ai.arcaneforge.crazychess"
    compileSdk = 36
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "ai.arcaneforge.crazy_chess"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = 36
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        if (configuredAndroidAbis != null) {
            ndk {
                abiFilters.clear()
                abiFilters.addAll(configuredAndroidAbis)
            }
        }
    }

    if (configuredAndroidAbis != null && "x86_64" !in configuredAndroidAbis) {
        packaging {
            jniLibs {
                excludes += "**/x86_64/**"
            }
        }
    }

    signingConfigs {
        if (releaseSigningConfigured) {
            create("release") {
                keyAlias = keyAliasValue
                keyPassword = keyPasswordValue
                storeFile = rootProject.file(storeFileValue!!)
                storePassword = storePasswordValue
            }
        }
    }

    buildTypes {
        release {
            signingConfig = if (releaseSigningConfigured) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }
}

flutter {
    source = "../.."
}
