package ai.arcaneforge.crazychess

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
