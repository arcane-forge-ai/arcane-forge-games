import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const rules = ChessRulesService();

  ChessPiece piece(PieceType type, PieceColor color) {
    return ChessPiece(
      id: '${color.name}-${type.name}',
      type: type,
      color: color,
      countryId: 'mercantile',
      loyalty: null,
      fairPrice: null,
    );
  }

  List<List<ChessPiece?>> emptyBoard() =>
      List.generate(8, (_) => List<ChessPiece?>.filled(8, null));

  test('shared geometry covers sliding, jumping, and attacks', () {
    final board = emptyBoard();
    board[4][3] = piece(PieceType.queen, PieceColor.white);
    board[2][3] = piece(PieceType.pawn, PieceColor.black);
    board[4][6] = piece(PieceType.pawn, PieceColor.white);

    final moves = rules.pseudoMoves(board: board, from: const Square(4, 3));

    expect(
      moves.any((move) => move.to == const Square(2, 3) && move.isCapture),
      isTrue,
    );
    expect(moves.any((move) => move.to == const Square(4, 6)), isFalse);
    expect(
      rules.pieceAttacks(
        board: board,
        from: const Square(4, 3),
        target: const Square(2, 3),
      ),
      isTrue,
    );
  });

  test('en passant is explicitly disabled for survival geometry', () {
    final board = emptyBoard();
    board[3][3] = piece(PieceType.pawn, PieceColor.white);
    board[3][4] = piece(PieceType.pawn, PieceColor.black);

    final disabled = rules.pseudoMoves(
      board: board,
      from: const Square(3, 3),
      enPassantSquare: const Square(2, 4),
    );
    final enabled = rules.pseudoMoves(
      board: board,
      from: const Square(3, 3),
      enPassantSquare: const Square(2, 4),
      allowEnPassant: true,
    );

    expect(disabled.any((move) => move.isEnPassant), isFalse);
    expect(enabled.any((move) => move.isEnPassant), isTrue);
  });
}
