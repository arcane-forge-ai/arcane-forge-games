import 'dart:math' as math;

import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemoryProfileStore implements LastPieceProfileStore {
  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}

LastPieceSessionController controllerFor({int randomSeed = 7}) {
  return LastPieceSessionController(
    random: math.Random(randomSeed),
    profileRepository: LastPieceProfileRepository(store: _MemoryProfileStore()),
  );
}

void main() {
  test('capture has priority over a due spawn and ends the run', () async {
    final controller = controllerFor()..startRun(runSeed: 20);
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: const [
        LastPieceUnit(id: 'rook', type: PieceType.rook, square: Square(4, 0)),
      ],
      phasesSinceSpawn: 2,
      forcedScore: 1300,
    );

    await controller.debugRunEnemyPhase();

    expect(controller.lastEnemyAction, LastPieceEnemyAction.capture);
    expect(controller.phase, LastPieceRunPhase.gameOver);
    expect(controller.result?.endReason, LastPieceEndReason.captured);
    expect(controller.enemies, hasLength(1));
    expect(controller.currentSpawnBatchSize, 4);
  });

  test('a due fair batch is the only enemy action in its phase', () async {
    final controller = controllerFor()..startRun(runSeed: 21);
    const original = LastPieceUnit(
      id: 'pawn',
      type: PieceType.pawn,
      square: Square(0, 0),
    );
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: const [original],
      phasesSinceSpawn: 2,
      forcedScore: 300,
    );

    await controller.debugRunEnemyPhase();

    expect(controller.lastEnemyAction, LastPieceEnemyAction.spawn);
    expect(controller.enemies, hasLength(3));
    expect(controller.presentationSteps.map((step) => step.kind), [
      LastPiecePresentationKind.spawn,
      LastPiecePresentationKind.spawn,
    ]);
    expect(
      controller.presentationSteps.map((step) => step.frame.enemies.length),
      [1, 2],
    );
    expect(
      controller.enemies.firstWhere((enemy) => enemy.id == 'pawn').square,
      original.square,
    );
    expect(controller.survivedPhases, 1);
    expect(controller.score, 305);
  });

  test('an empty enemy tide uses the current replacement batch', () async {
    final controller = controllerFor()..startRun(runSeed: 211);
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: const [],
      forcedScore: 700,
    );

    await controller.debugRunEnemyPhase();

    expect(controller.lastEnemyAction, LastPieceEnemyAction.spawn);
    expect(controller.enemies, hasLength(3));
    expect(controller.presentationSteps, hasLength(3));
    expect(controller.survivedPhases, 1);
    expect(controller.score, 705);
  });

  test('spawn batch size follows every score boundary', () {
    final controller = controllerFor()..startRun(runSeed: 212);
    const expected = <int, int>{
      299: 1,
      300: 2,
      699: 2,
      700: 3,
      1199: 3,
      1200: 3,
      1299: 3,
      1300: 4,
      1400: 5,
    };

    for (final entry in expected.entries) {
      controller.debugReplaceBoard(
        playerUnit: controller.player,
        enemyUnits: controller.enemies,
        forcedScore: entry.key,
      );
      expect(
        controller.currentSpawnBatchSize,
        entry.value,
        reason: 'score ${entry.key}',
      );
    }
  });

  test('a partial fair batch does not add a hunt action', () async {
    final controller = controllerFor()..startRun(runSeed: 213);
    const playerSquare = Square(4, 3);
    const finalEmptySquare = Square(7, 7);
    final enemies = <LastPieceUnit>[
      for (var row = 0; row < 8; row++)
        for (var col = 0; col < 8; col++)
          if (Square(row, col) != playerSquare &&
              Square(row, col) != finalEmptySquare)
            LastPieceUnit(
              id: 'enemy-$row-$col',
              type: switch ((row, col)) {
                (3, 2) || (3, 4) => PieceType.knight,
                (2, 2) || (2, 4) => PieceType.rook,
                _ => PieceType.pawn,
              },
              square: Square(row, col),
            ),
    ];
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.king,
        square: playerSquare,
      ),
      enemyUnits: enemies,
      phasesSinceSpawn: 2,
      forcedScore: 300,
    );

    await controller.debugRunEnemyPhase();

    expect(controller.lastEnemyAction, LastPieceEnemyAction.spawn);
    expect(controller.enemies, hasLength(63));
    expect(controller.presentationSteps, hasLength(1));
    expect(
      controller.presentationSteps.single.kind,
      LastPiecePresentationKind.spawn,
    );
    expect(controller.eventLog, isNot(contains(contains('hunted instead'))));
  });

  test('a zero-spawn due batch falls back to one hunt action', () async {
    final controller = controllerFor()..startRun(runSeed: 214);
    const playerSquare = Square(0, 3);
    final enemies = <LastPieceUnit>[
      for (var row = 0; row < 8; row++)
        for (var col = 0; col < 8; col++)
          if (Square(row, col) != playerSquare)
            LastPieceUnit(
              id: 'enemy-$row-$col',
              type: PieceType.pawn,
              square: Square(row, col),
            ),
    ];
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: playerSquare,
      ),
      enemyUnits: enemies,
      phasesSinceSpawn: 2,
      forcedScore: 300,
    );

    await controller.debugRunEnemyPhase();

    expect(controller.lastEnemyAction, LastPieceEnemyAction.hunt);
    expect(controller.enemies, hasLength(63));
    expect(controller.presentationSteps, isEmpty);
    expect(controller.eventLog, contains(contains('hunted instead')));
  });

  test('seeded hunting produces the same move', () async {
    final first = controllerFor()..startRun(runSeed: 99);
    final second = controllerFor()..startRun(runSeed: 99);
    const state = [
      LastPieceUnit(id: 'knight', type: PieceType.knight, square: Square(0, 0)),
      LastPieceUnit(
        id: 'second-knight',
        type: PieceType.knight,
        square: Square(0, 7),
      ),
    ];
    for (final controller in [first, second]) {
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: state,
      );
      await controller.debugRunEnemyPhase();
    }

    expect(
      first.enemies.map((enemy) => enemy.square),
      second.enemies.map((enemy) => enemy.square),
    );
    expect(first.lastEnemyAction, LastPieceEnemyAction.hunt);
  });

  test('population grows beyond the earlier cap concept', () {
    final controller = controllerFor()..startRun(runSeed: 44);
    final enemies = <LastPieceUnit>[
      for (var col = 0; col < 8; col++)
        LastPieceUnit(
          id: 'row-zero-$col',
          type: PieceType.pawn,
          square: Square(0, col),
        ),
      const LastPieceUnit(
        id: 'ninth',
        type: PieceType.pawn,
        square: Square(1, 0),
      ),
    ];
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: enemies,
    );

    expect(controller.debugAttemptSpawn(), isTrue);
    expect(controller.enemies.length, greaterThan(9));
  });

  test('a full board rejects spawn without an enemy cap', () {
    final controller = controllerFor()..startRun(runSeed: 45);
    const playerSquare = Square(4, 3);
    final enemies = <LastPieceUnit>[
      for (var row = 0; row < 8; row++)
        for (var col = 0; col < 8; col++)
          if (Square(row, col) != playerSquare)
            LastPieceUnit(
              id: 'enemy-$row-$col',
              type: PieceType.pawn,
              square: Square(row, col),
            ),
    ];
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: playerSquare,
      ),
      enemyUnits: enemies,
    );

    expect(controller.debugAttemptSpawn(), isFalse);
    expect(controller.enemies, hasLength(63));
  });

  test('all three score milestones keep the run alive', () async {
    final controller = controllerFor()..startRun(runSeed: 46);
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: const [
        LastPieceUnit(id: 'pawn', type: PieceType.pawn, square: Square(0, 0)),
      ],
      forcedScore: 295,
    );

    await controller.debugRunEnemyPhase();

    expect(controller.score, 300);
    expect(controller.stars, 1);
    expect(controller.phase, LastPieceRunPhase.playing);
    expect(controller.profile.unlockedLevelIds, contains('002'));
    expect(controller.milestoneBanner, contains('LEVEL PASSED'));

    controller.debugReplaceBoard(
      playerUnit: controller.player,
      enemyUnits: const [
        LastPieceUnit(
          id: 'pawn-reset',
          type: PieceType.pawn,
          square: Square(0, 0),
        ),
      ],
      forcedScore: 1195,
    );
    await controller.debugRunEnemyPhase();

    expect(controller.stars, 3);
    expect(controller.phase, LastPieceRunPhase.playing);
  });

  test(
    'transformation tiles support Queen to Knight and Knight to Pawn',
    () async {
      final controller = controllerFor()..startRun(runSeed: 47);
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [],
      );
      controller.debugAddRewardTile(
        const LastPieceRewardTile.transformation(
          id: 'queen-to-knight',
          square: Square(3, 3),
          targetRole: PieceType.knight,
        ),
      );

      expect(await controller.movePlayer(const Square(3, 3)), isTrue);
      expect(controller.player.type, PieceType.knight);

      controller.debugReplaceBoard(
        playerUnit: controller.player,
        enemyUnits: const [],
      );
      controller.debugAddRewardTile(
        const LastPieceRewardTile.transformation(
          id: 'knight-to-pawn',
          square: Square(1, 4),
          targetRole: PieceType.pawn,
        ),
      );
      expect(await controller.movePlayer(const Square(1, 4)), isTrue);
      expect(controller.player.type, PieceType.pawn);
      expect(controller.transformations, 2);
    },
  );

  test('generated transformations exclude the same role and immobile Pawn', () {
    var transformationsSeen = 0;
    for (var seed = 0; seed < 30; seed++) {
      final controller = controllerFor()..startRun(runSeed: seed);
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [],
      );
      controller.debugAttemptRewardTile();
      for (final tile in controller.rewardTiles) {
        if (tile.kind != LastPieceRewardKind.transformation) {
          continue;
        }
        transformationsSeen += 1;
        expect(tile.targetRole, isNot(PieceType.queen));
        if (tile.targetRole == PieceType.pawn) {
          expect(tile.square.row, isNot(0));
        }
      }
    }
    expect(transformationsSeen, greaterThan(0));
  });

  test('enemies can occupy a reward tile without activating it', () async {
    final controller = controllerFor()..startRun(runSeed: 48);
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: const [
        LastPieceUnit(id: 'pawn', type: PieceType.pawn, square: Square(0, 0)),
      ],
    );
    controller.debugAddRewardTile(
      const LastPieceRewardTile.score(
        id: 'blocked-score',
        square: Square(0, 0),
        scoreValue: 100,
      ),
    );

    await controller.debugRunEnemyPhase();

    expect(controller.tilePoints, 0);
    expect(
      controller.rewardTiles.any((tile) => tile.id == 'blocked-score'),
      isTrue,
    );
  });

  test('back-rank Pawn promotion remains a separate chooser', () async {
    final controller = controllerFor()..startRun(runSeed: 49);
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.pawn,
        square: Square(1, 0),
      ),
      enemyUnits: const [],
    );

    expect(await controller.movePlayer(const Square(0, 0)), isTrue);
    expect(controller.phase, LastPieceRunPhase.promotion);

    await controller.choosePromotion(PieceType.queen);

    expect(controller.player.type, PieceType.queen);
    expect(controller.phase, LastPieceRunPhase.playing);
  });

  test('retirement records a result without undoing the pass', () async {
    final controller = controllerFor()..startRun(runSeed: 50);
    controller.debugReplaceBoard(
      playerUnit: controller.player,
      enemyUnits: controller.enemies,
      forcedScore: 300,
      forcedSurvivedPhases: 10,
    );

    await controller.retire();

    expect(controller.result?.endReason, LastPieceEndReason.retired);
    expect(controller.result?.stars, 1);
    expect(controller.profile.unlockedLevelIds, contains('002'));
  });
}
