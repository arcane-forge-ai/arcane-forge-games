import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemoryProfileStore implements LastPieceProfileStore {
  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}

void main() {
  test('corrupt saves fall back to level 001 unlocked', () async {
    final store = _MemoryProfileStore()..value = '{broken';
    final repository = LastPieceProfileRepository(store: store);

    final profile = await repository.load();

    expect(profile.unlockedLevelIds, {'001'});
    expect(profile.levelRecords, isEmpty);
  });

  test('pass unlocks sequentially and survives repository restart', () async {
    final store = _MemoryProfileStore();
    final repository = LastPieceProfileRepository(store: store);
    final catalog = LastPieceLevelCatalog.defaults;
    final profile = await repository.load();

    await repository.persistPassUnlock(
      profile: profile,
      catalog: catalog,
      levelId: '001',
    );
    final reloaded = await LastPieceProfileRepository(store: store).load();

    expect(reloaded.unlockedLevelIds, containsAll(['001', '002']));
    expect(reloaded.unlockedLevelIds, isNot(contains('003')));
  });

  test(
    'familiarity is country-separated and first-pass bonus is idempotent',
    () async {
      final store = _MemoryProfileStore();
      final repository = LastPieceProfileRepository(store: store);
      final catalog = LastPieceLevelCatalog.defaults;
      final profile = LastPieceProfile.fresh();
      final level = catalog.byId('001');

      final first = await repository.recordRun(
        profile: profile,
        catalog: catalog,
        level: level,
        countryId: 'mercantile',
        score: 300,
        stars: 1,
        survivedPhases: 10,
        capturePoints: 20,
        tilePoints: 0,
      );
      final second = await repository.recordRun(
        profile: profile,
        catalog: catalog,
        level: level,
        countryId: 'mercantile',
        score: 300,
        stars: 1,
        survivedPhases: 10,
        capturePoints: 20,
        tilePoints: 0,
      );
      final belowPass = await repository.recordRun(
        profile: profile,
        catalog: catalog,
        level: level,
        countryId: 'iron',
        score: 100,
        stars: 0,
        survivedPhases: 10,
        capturePoints: 40,
        tilePoints: 0,
      );

      expect(first.firstPassBonusAwarded, 20);
      expect(first.familiarityGained, 31);
      expect(first.newRewardIds, contains('mercantile:chronicle1'));
      expect(first.newRewardIds, contains('mercantile:music_court'));
      expect(second.firstPassBonusAwarded, 0);
      expect(second.familiarityGained, 11);
      expect(second.totalFamiliarity, 42);
      expect(belowPass.familiarityGained, 6);
      expect(profile.countryFamiliarity['mercantile'], 42);
      expect(profile.countryFamiliarity['iron'], 6);
    },
  );

  test('gallery reward unlocks once at Familiarity 100', () async {
    final store = _MemoryProfileStore();
    final repository = LastPieceProfileRepository(store: store);
    final catalog = LastPieceLevelCatalog.defaults;
    final profile = LastPieceProfile.fresh()..countryFamiliarity['spy'] = 99;

    final update = await repository.recordRun(
      profile: profile,
      catalog: catalog,
      level: catalog.byId('001'),
      countryId: 'spy',
      score: 300,
      stars: 1,
      survivedPhases: 1,
      capturePoints: 0,
      tilePoints: 0,
    );

    expect(update.totalFamiliarity, 120);
    expect(update.newRewardIds, contains('spy:gallery1'));
    expect(update.newRewardIds, contains('spy:music_battle'));
    expect(profile.rewardUnlockIds, contains('spy:chronicle1'));
    expect(profile.rewardUnlockIds, contains('spy:music_court'));
  });

  test('schema migration backfills music rewards from Familiarity', () async {
    final store = _MemoryProfileStore()
      ..value = '''
        {
          "schemaVersion": 1,
          "unlockedLevelIds": ["001"],
          "levelRecords": {},
          "countryFamiliarity": {"mercantile": 25, "spy": 100},
          "firstPassedLevelIds": [],
          "rewardUnlockIds": []
        }
      ''';

    final profile = await LastPieceProfileRepository(store: store).load();

    expect(profile.schemaVersion, LastPieceProfile.currentSchemaVersion);
    expect(profile.rewardUnlockIds, contains('mercantile:music_court'));
    expect(profile.rewardUnlockIds, isNot(contains('mercantile:music_battle')));
    expect(profile.rewardUnlockIds, contains('spy:music_court'));
    expect(profile.rewardUnlockIds, contains('spy:music_battle'));
  });
}
