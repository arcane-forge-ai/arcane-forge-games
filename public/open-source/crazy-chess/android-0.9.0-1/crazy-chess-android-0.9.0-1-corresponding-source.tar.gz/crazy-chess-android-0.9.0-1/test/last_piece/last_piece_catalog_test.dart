import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('bundled catalog has stable sequential launch IDs', () async {
    final catalog = await LastPieceLevelCatalog.loadBundled();

    expect(catalog.version, 1);
    expect(catalog.levels.map((level) => level.id), ['001', '002', '003']);
    expect(catalog.byId('001').prerequisiteId, isNull);
    expect(catalog.byId('002').prerequisiteId, '001');
    expect(catalog.byId('003').prerequisiteId, '002');
    expect(catalog.byId('003').enemyWeights[PieceType.queen], 10);
    expect(catalog.byId('003').title, 'The Last King');
    expect(catalog.byId('003').startingPiece, PieceType.king);
    expect(catalog.byId('003').startingSquare, const Square(4, 3));
    expect(catalog.byId('003').presentationTag, 'last-king');
    expect(catalog.byId('001').scoreMilestones, [300, 700, 1200]);

    final fallback = LastPieceLevelCatalog.defaults.byId('003');
    expect(fallback.title, 'The Last King');
    expect(fallback.startingPiece, PieceType.king);
    expect(fallback.startingSquare, const Square(4, 3));
  });

  test('bundled Simplified Chinese catalog localizes The Last King', () async {
    final catalog = await LastPieceLevelCatalog.loadBundled(
      locale: const Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hans'),
    );

    expect(catalog.byId('003').title, '最后的王');
    expect(catalog.byId('003').startingPiece, PieceType.king);
  });

  test('catalog rejects reordering before a prerequisite', () {
    const source = '''
      {
        "version": 2,
        "levels": [
          {
            "id": "002",
            "title": "Out of order",
            "prerequisiteId": "001",
            "startingState": {"piece": "queen", "square": "d4"},
            "initialEnemies": 1,
            "spawnInterval": 3,
            "enemyWeights": {"pawn": 100},
            "scoreMilestones": [300, 700, 1200],
            "rewardTileInterval": 4,
            "maxRewardTiles": 2,
            "firstPassBonus": 20,
            "presentationTag": "test"
          }
        ]
      }
    ''';

    expect(
      () => LastPieceLevelCatalog.fromJsonString(source),
      throwsFormatException,
    );
  });
}
