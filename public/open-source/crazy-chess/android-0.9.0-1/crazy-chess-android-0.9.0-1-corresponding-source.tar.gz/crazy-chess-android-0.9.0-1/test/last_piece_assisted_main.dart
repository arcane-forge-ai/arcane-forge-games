import 'dart:async';
import 'dart:math' as math;

import 'package:crazy_chess/app/responsive_game_viewport.dart';
import 'package:crazy_chess/app/theme.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/last_piece/last_piece_models.dart';
import 'package:crazy_chess/last_piece/last_piece_profile.dart';
import 'package:crazy_chess/last_piece/last_piece_session_controller.dart';
import 'package:crazy_chess/ui/last_piece/last_piece_flow_screens.dart';
import 'package:crazy_chess/ui/last_piece/last_piece_presentation_coordinator.dart';
import 'package:crazy_chess/ui/menu/remaining_flow_screens.dart';
import 'package:flutter/material.dart';

class _AssistedProfileStore implements LastPieceProfileStore {
  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = Uri.base.queryParameters['state'] ?? 'runStart';
  final country = Uri.base.queryParameters['country'] ?? 'mercantile';
  final slowMove = const {
    'playerTravel',
    'huntMotion',
    'captureMotion',
  }.contains(state);
  final slowTransform = state == 'downgradeMid';
  final slowSpawn = state == 'spawnMotion';
  final controller = LastPieceSessionController(
    random: math.Random(20260731),
    profileRepository: LastPieceProfileRepository(
      store: _AssistedProfileStore(),
    ),
  )..selectCountry(country);
  final presentationCoordinator = LastPiecePresentationCoordinator(
    controller: controller,
    moveDuration: slowMove
        ? const Duration(seconds: 8)
        : slowTransform
        ? const Duration(milliseconds: 1)
        : const Duration(milliseconds: 400),
    transformDuration: slowTransform
        ? const Duration(seconds: 8)
        : const Duration(milliseconds: 480),
    spawnDuration: slowSpawn
        ? const Duration(seconds: 8)
        : const Duration(milliseconds: 320),
  );
  controller.startRun(runSeed: 20260731);

  Widget screen;
  switch (state) {
    case 'captureVisual':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'capture-target',
            type: PieceType.pawn,
            square: Square(3, 3),
          ),
        ],
      );
      Timer(const Duration(milliseconds: 3500), () {
        unawaited(controller.movePlayer(const Square(3, 3)));
      });
      screen = _run(controller, presentationCoordinator);
      break;
    case 'captureInput':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'capture-target',
            type: PieceType.pawn,
            square: Square(3, 3),
          ),
        ],
      );
      screen = _run(controller, presentationCoordinator, interactive: true);
      break;
    case 'playerTravel':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'opening-pawn',
            type: PieceType.pawn,
            square: Square(0, 0),
          ),
        ],
      );
      await controller.movePlayer(const Square(3, 3));
      screen = _run(controller, presentationCoordinator);
      break;
    case 'spawnMotion':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'opening-pawn',
            type: PieceType.pawn,
            square: Square(0, 0),
          ),
        ],
        phasesSinceSpawn: 2,
      );
      await controller.debugRunEnemyPhase();
      screen = _run(controller, presentationCoordinator);
      break;
    case 'spawnTier1':
      await _prepareSpawnTier(controller, score: 0);
      screen = _run(controller, presentationCoordinator);
      break;
    case 'spawnTier2':
      await _prepareSpawnTier(controller, score: 300);
      screen = _run(controller, presentationCoordinator);
      break;
    case 'spawnTier3':
      await _prepareSpawnTier(controller, score: 700);
      screen = _run(controller, presentationCoordinator);
      break;
    case 'spawnTier4':
      await _prepareSpawnTier(controller, score: 1300);
      screen = _run(controller, presentationCoordinator);
      break;
    case 'kingStart':
      controller.profile.unlockedLevelIds.add('003');
      controller.selectLevel('003');
      controller.startRun(levelId: '003', runSeed: 20260816);
      screen = _run(controller, presentationCoordinator);
      break;
    case 'huntMotion':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'hunter',
            type: PieceType.knight,
            square: Square(0, 0),
          ),
        ],
      );
      await controller.debugRunEnemyPhase();
      screen = _run(controller, presentationCoordinator);
      break;
    case 'captureMotion':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'capturing-rook',
            type: PieceType.rook,
            square: Square(4, 0),
          ),
        ],
      );
      await controller.debugRunEnemyPhase();
      screen = _run(controller, presentationCoordinator);
      break;
    case 'downgradeMid':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'opening-pawn',
            type: PieceType.pawn,
            square: Square(0, 0),
          ),
        ],
      );
      controller.debugAddRewardTile(
        const LastPieceRewardTile.transformation(
          id: 'queen-to-knight',
          square: Square(3, 3),
          targetRole: PieceType.knight,
        ),
      );
      await controller.movePlayer(const Square(3, 3));
      screen = _run(controller, presentationCoordinator);
      break;
    case 'firstSpawn':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'opening-pawn',
            type: PieceType.pawn,
            square: Square(0, 0),
          ),
        ],
        phasesSinceSpawn: 2,
      );
      await controller.debugRunEnemyPhase();
      screen = _run(controller, presentationCoordinator);
      break;
    case 'hunt':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'hunter',
            type: PieceType.knight,
            square: Square(0, 0),
          ),
        ],
      );
      await controller.debugRunEnemyPhase();
      screen = _run(controller, presentationCoordinator);
      break;
    case 'scoreTile':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [],
      );
      controller.debugAddRewardTile(
        const LastPieceRewardTile.score(
          id: 'score-100',
          square: Square(3, 3),
          scoreValue: 100,
        ),
      );
      await controller.movePlayer(const Square(3, 3));
      screen = _run(controller, presentationCoordinator);
      break;
    case 'downgrade':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [],
      );
      controller.debugAddRewardTile(
        const LastPieceRewardTile.transformation(
          id: 'queen-to-knight',
          square: Square(3, 3),
          targetRole: PieceType.knight,
        ),
      );
      await controller.movePlayer(const Square(3, 3));
      screen = _run(controller, presentationCoordinator);
      break;
    case 'pass':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'pass-pawn',
            type: PieceType.pawn,
            square: Square(0, 0),
          ),
        ],
        forcedScore: 295,
      );
      await controller.debugRunEnemyPhase();
      screen = _run(controller, presentationCoordinator);
      break;
    case 'dense':
      final enemies = <LastPieceUnit>[
        for (var col = 0; col < 8; col++)
          LastPieceUnit(
            id: 'rank-eight-$col',
            type: PieceType.pawn,
            square: Square(0, col),
          ),
        for (var col = 0; col < 8; col++)
          LastPieceUnit(
            id: 'rank-seven-$col',
            type: PieceType.knight,
            square: Square(1, col),
          ),
        for (var col = 0; col < 4; col++)
          LastPieceUnit(
            id: 'rank-six-$col',
            type: PieceType.rook,
            square: Square(2, col),
          ),
      ];
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(5, 4),
        ),
        enemyUnits: enemies,
        forcedScore: 1240,
        forcedSurvivedPhases: 86,
      );
      controller.debugAddRewardTile(
        const LastPieceRewardTile.score(
          id: 'dense-score',
          square: Square(4, 6),
          scoreValue: 100,
        ),
      );
      controller.debugAddRewardTile(
        const LastPieceRewardTile.transformation(
          id: 'dense-transform',
          square: Square(5, 6),
          targetRole: PieceType.pawn,
        ),
      );
      screen = _run(controller, presentationCoordinator);
      break;
    case 'defeat':
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'capturing-rook',
            type: PieceType.rook,
            square: Square(4, 0),
          ),
        ],
      );
      await controller.debugRunEnemyPhase();
      screen = _results(controller);
      break;
    case 'passResults':
      controller.debugReplaceBoard(
        playerUnit: controller.player,
        enemyUnits: controller.enemies,
        forcedScore: 735,
        forcedSurvivedPhases: 44,
      );
      await controller.retire();
      screen = _results(controller);
      break;
    case 'chronicle':
      controller.profile.countryFamiliarity[country] = 25;
      controller.profile.rewardUnlockIds.add('$country:chronicle1');
      screen = _court(controller, country);
      break;
    case 'gallery':
      controller.profile.countryFamiliarity[country] = 100;
      controller.profile.rewardUnlockIds.addAll({
        '$country:chronicle1',
        '$country:gallery1',
      });
      screen = _court(controller, country);
      break;
    default:
      screen = _run(controller, presentationCoordinator);
      break;
  }

  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: buildCrazyChessTheme(),
      home: Scaffold(body: ResponsiveGameViewport(child: screen)),
    ),
  );
}

Future<void> _prepareSpawnTier(
  LastPieceSessionController controller, {
  required int score,
}) async {
  controller.debugReplaceBoard(
    playerUnit: const LastPieceUnit(
      id: 'player',
      type: PieceType.queen,
      square: Square(4, 3),
    ),
    enemyUnits: const [
      LastPieceUnit(
        id: 'opening-pawn',
        type: PieceType.pawn,
        square: Square(0, 0),
      ),
    ],
    phasesSinceSpawn: 2,
    forcedScore: score,
  );
  await controller.debugRunEnemyPhase();
}

Widget _run(
  LastPieceSessionController controller,
  LastPiecePresentationCoordinator presentationCoordinator, {
  bool interactive = false,
}) {
  return AnimatedBuilder(
    animation: Listenable.merge([controller, presentationCoordinator]),
    builder: (context, _) => LastPieceRunScreen(
      controller: controller,
      presentationCoordinator: presentationCoordinator,
      onMove: interactive
          ? (square) => unawaited(controller.movePlayer(square))
          : (_) {},
      onPromotion: (_) {},
      onRetire: () {},
      onBackToLadder: () {},
    ),
  );
}

Widget _results(LastPieceSessionController controller) {
  return LastPieceResultsScreen(
    controller: controller,
    onRetry: () {},
    onNextLevel: controller.profile.unlockedLevelIds.contains('002')
        ? () {}
        : null,
    onLadder: () {},
    onCourtDorm: () {},
    onLobby: () {},
  );
}

Widget _court(LastPieceSessionController controller, String countryId) {
  return CourtDormScreen(
    lastPieceController: controller,
    countryId: countryId,
    onCountryChanged: (_) {},
    onLobby: () {},
    onCollection: () {},
    onProfile: () {},
    onLoadout: () {},
    onRecords: () {},
    onRules: () {},
    onSettings: () {},
  );
}
