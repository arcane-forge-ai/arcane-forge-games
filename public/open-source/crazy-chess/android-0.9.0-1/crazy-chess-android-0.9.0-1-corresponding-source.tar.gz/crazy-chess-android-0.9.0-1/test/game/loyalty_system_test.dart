import 'dart:math' as math;

import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

class _BoundRandom implements math.Random {
  const _BoundRandom(this.maximum);

  final bool maximum;

  @override
  bool nextBool() => maximum;

  @override
  double nextDouble() => maximum ? .999999 : 0;

  @override
  int nextInt(int max) => maximum ? max - 1 : 0;
}

class _ScriptedRandom implements math.Random {
  final List<int> _values = <int>[];

  void enqueue(int value) => _values.add(value);

  @override
  bool nextBool() => false;

  @override
  double nextDouble() => 0;

  @override
  int nextInt(int max) {
    if (_values.isEmpty) {
      return 0;
    }
    return _values.removeAt(0).clamp(0, max - 1);
  }
}

GameController _controller({
  required _ScriptedRandom random,
  String whiteCountry = 'spy',
  String blackCountry = 'mercantile',
}) {
  final controller = GameController(random: random)
    ..setupWhiteCountryId = whiteCountry
    ..setupBlackCountryId = blackCountry
    ..startNewGame();
  controller.gold[PieceColor.white] = 200;
  return controller;
}

ChessPiece _openOffer(
  GameController controller, {
  PieceType type = PieceType.pawn,
  String countryId = 'mercantile',
  int loyalty = 60,
  int fairPrice = 10,
  int offer = 10,
  String? personalityId,
}) {
  const square = Square(1, 0);
  final piece = ChessPiece(
    id: 'loyalty-target',
    type: type,
    color: PieceColor.black,
    countryId: countryId,
    loyalty: loyalty,
    fairPrice: fairPrice,
    personalityId: personalityId,
  );
  controller.board[square.row][square.col] = piece;
  controller.tapSquare(square);
  controller.openOfferForSelected();
  controller.setOfferGold(offer);
  return piece;
}

void main() {
  group('starting loyalty', () {
    final cases = <(String, PieceType, int, int)>[
      ('mercantile', PieceType.pawn, 45, 55),
      ('spy', PieceType.queen, 55, 65),
      ('horse', PieceType.bishop, 55, 65),
      ('horse', PieceType.knight, 55, 65),
      ('iron', PieceType.bishop, 65, 75),
      ('iron', PieceType.pawn, 80, 90),
      ('iron', PieceType.rook, 80, 90),
    ];

    for (final entry in cases) {
      test('${entry.$1} ${entry.$2.name} uses its inclusive range', () {
        expect(
          randomStartingLoyalty(entry.$1, entry.$2, const _BoundRandom(false)),
          entry.$3,
        );
        expect(
          randomStartingLoyalty(entry.$1, entry.$2, const _BoundRandom(true)),
          entry.$4,
        );
      });
    }

    test('Kings never receive loyalty', () {
      expect(
        randomStartingLoyalty('iron', PieceType.king, const _BoundRandom(true)),
        isNull,
      );
    });
  });

  test('coarse bands snap to the approved boundaries', () {
    expect(loyaltyBandFor(100), LoyaltyBand.steadfast);
    expect(loyaltyBandFor(81), LoyaltyBand.steadfast);
    expect(loyaltyBandFor(80), LoyaltyBand.loyal);
    expect(loyaltyBandFor(61), LoyaltyBand.loyal);
    expect(loyaltyBandFor(60), LoyaltyBand.wavering);
    expect(loyaltyBandFor(41), LoyaltyBand.wavering);
    expect(loyaltyBandFor(40), LoyaltyBand.susceptible);
    expect(loyaltyBandFor(21), LoyaltyBand.susceptible);
    expect(loyaltyBandFor(20), LoyaltyBand.fractured);
    expect(loyaltyBandFor(1), LoyaltyBand.fractured);
    expect(loyaltyBandFor(0), LoyaltyBand.broken);
  });

  test('humiliation thresholds exclude their exact boundary', () {
    expect(
      isHumiliatingOffer(
        offer: 4,
        fairPrice: 10,
        profile: loyaltyProfileFor('mercantile', PieceType.pawn),
      ),
      isTrue,
    );
    expect(
      isHumiliatingOffer(
        offer: 5,
        fairPrice: 10,
        profile: loyaltyProfileFor('mercantile', PieceType.pawn),
      ),
      isFalse,
    );
    expect(
      isHumiliatingOffer(
        offer: 14,
        fairPrice: 20,
        profile: loyaltyProfileFor('iron', PieceType.bishop),
      ),
      isTrue,
    );
    expect(
      isHumiliatingOffer(
        offer: 15,
        fairPrice: 20,
        profile: loyaltyProfileFor('iron', PieceType.bishop),
      ),
      isFalse,
    );
    expect(
      isHumiliatingOffer(
        offer: 9,
        fairPrice: 10,
        profile: loyaltyProfileFor('iron', PieceType.rook),
      ),
      isTrue,
    );
    expect(
      isHumiliatingOffer(
        offer: 10,
        fairPrice: 10,
        profile: loyaltyProfileFor('iron', PieceType.rook),
      ),
      isFalse,
    );
  });

  test('humiliation rallies use ordinary and Iron amounts with clamping', () {
    final cases = <(String, PieceType, int, int, int, int)>[
      ('mercantile', PieceType.pawn, 50, 10, 4, 58),
      ('iron', PieceType.bishop, 50, 20, 14, 60),
      ('iron', PieceType.rook, 95, 10, 9, 100),
    ];

    for (final entry in cases) {
      final random = _ScriptedRandom();
      final controller = _controller(random: random, blackCountry: entry.$1);
      addTearDown(controller.dispose);
      final target = _openOffer(
        controller,
        type: entry.$2,
        countryId: entry.$1,
        loyalty: entry.$3,
        fairPrice: entry.$4,
        offer: entry.$5,
      );

      controller.confirmOffer();

      expect(controller.lastOfferResult!.success, isFalse);
      expect(
        controller.lastOfferResult!.resolutionKind,
        OfferResolutionKind.humiliated,
      );
      expect(controller.lastOfferResult!.roll, isNull);
      expect(target.loyalty, entry.$6);
    }
  });

  test('pressure and near-miss tiers include every boundary', () {
    expect(failedOfferBasePressure(offer: 5, fairPrice: 10), 6);
    expect(failedOfferBasePressure(offer: 9, fairPrice: 10), 6);
    expect(failedOfferBasePressure(offer: 10, fairPrice: 10), 12);
    expect(failedOfferBasePressure(offer: 14, fairPrice: 10), 12);
    expect(failedOfferBasePressure(offer: 15, fairPrice: 10), 18);

    expect(nearMissPressureBonus(1), 12);
    expect(nearMissPressureBonus(5), 12);
    expect(nearMissPressureBonus(6), 8);
    expect(nearMissPressureBonus(15), 8);
    expect(nearMissPressureBonus(16), 4);
    expect(nearMissPressureBonus(30), 4);
    expect(nearMissPressureBonus(31), 0);
  });

  test('lower loyalty monotonically increases unclamped chance', () {
    final random = _ScriptedRandom();
    final controller = _controller(random: random);
    addTearDown(controller.dispose);
    final target = _openOffer(
      controller,
      type: PieceType.rook,
      loyalty: 80,
      fairPrice: 22,
      offer: 22,
    );
    final loyalChance = controller
        .calculateChance(includeHidden: true)
        .finalChance;
    target.loyalty = 20;
    final fracturedChance = controller
        .calculateChance(includeHidden: true)
        .finalChance;

    expect(fracturedChance, greaterThan(loyalChance));
    expect(loyaltyChanceModifier(80), -12);
    expect(loyaltyChanceModifier(60), 0);
    expect(loyaltyChanceModifier(20), 24);
  });

  test('a one-point near miss applies base plus maximum bonus pressure', () {
    final random = _ScriptedRandom();
    final controller = _controller(random: random);
    addTearDown(controller.dispose);
    final target = _openOffer(
      controller,
      type: PieceType.rook,
      loyalty: 60,
      fairPrice: 22,
      offer: 22,
    );
    expect(controller.calculateChance(includeHidden: true).finalChance, 20);
    random.enqueue(20);

    controller.confirmOffer();

    expect(controller.lastOfferResult!.roll, 21);
    expect(controller.lastOfferResult!.success, isFalse);
    expect(target.loyalty, 36);
    expect(controller.eventLog.first, isNot(contains('Roll')));
    expect(controller.eventLog.first, isNot(contains('chance')));
    expect(controller.eventLog.first, isNot(contains('fair price')));
    expect(controller.eventLog.first, isNot(contains('60')));
    expect(controller.eventLog.first, contains('Tempted'));
  });

  test(
    'a failed roll can reach zero but only the next legal offer is automatic',
    () {
      final random = _ScriptedRandom();
      final controller = _controller(random: random);
      addTearDown(controller.dispose);
      final target = _openOffer(
        controller,
        loyalty: 5,
        fairPrice: 10,
        offer: 5,
      );
      random.enqueue(99);

      controller.confirmOffer();

      expect(controller.lastOfferResult!.success, isFalse);
      expect(
        controller.lastOfferResult!.resolutionKind,
        OfferResolutionKind.rolled,
      );
      expect(target.loyalty, 0);
      expect(controller.pieceAt(const Square(1, 0)), same(target));

      controller
        ..turn = PieceColor.white
        ..phase = GamePhase.playing
        ..tapSquare(const Square(1, 0))
        ..openOfferForSelected()
        ..setOfferGold(1)
        ..confirmOffer();

      expect(controller.lastOfferResult!.success, isTrue);
      expect(
        controller.lastOfferResult!.resolutionKind,
        OfferResolutionKind.automatic,
      );
      expect(controller.lastOfferResult!.roll, isNull);
    },
  );

  test('zero loyalty bypasses d100 and then ends turn', () {
    final random = _ScriptedRandom();
    final controller = _controller(random: random);
    addTearDown(controller.dispose);
    _openOffer(
      controller,
      type: PieceType.queen,
      loyalty: 0,
      fairPrice: 40,
      offer: 1,
    );
    controller.board[7][1] = null;
    controller.board[7][6] = null;
    final goldBefore = controller.gold[PieceColor.white]!;

    controller.confirmOffer();

    expect(controller.phase, GamePhase.redeploy);
    expect(
      controller.lastOfferResult!.resolutionKind,
      OfferResolutionKind.automatic,
    );
    expect(controller.lastOfferResult!.roll, isNull);
    expect(controller.gold[PieceColor.white], goldBefore - 1);

    controller.placeRedeploy(controller.legalRedeploySquares().first);
    expect(controller.turn, PieceColor.black);
  });

  test('purchase resets loyalty while copy and role changes preserve it', () {
    final random = _ScriptedRandom();
    final controller = _controller(
      random: random,
      whiteCountry: 'iron',
      blackCountry: 'mercantile',
    );
    addTearDown(controller.dispose);
    final target = _openOffer(
      controller,
      type: PieceType.rook,
      loyalty: 0,
      fairPrice: 22,
      offer: 1,
    );
    expect(target.copy().loyalty, 0);
    target.type = PieceType.bishop;
    expect(target.loyalty, 0);
    target.type = PieceType.rook;
    random.enqueue(10);

    controller.confirmOffer();

    expect(controller.redeployPiece!.loyalty, 90);
    final resetLoyalty = controller.redeployPiece!.loyalty;
    controller.redeployPiece!.type = PieceType.queen;
    expect(controller.redeployPiece!.loyalty, resetLoyalty);
  });

  test('movement and promotion retain loyalty', () {
    final moveRandom = _ScriptedRandom();
    final movement = _controller(random: moveRandom);
    addTearDown(movement.dispose);
    final movingPawn = movement.pieceAt(const Square(6, 0))!;
    final movingLoyalty = movingPawn.loyalty;
    movement.makeMove(const ChessMove(from: Square(6, 0), to: Square(5, 0)));
    expect(movement.pieceAt(const Square(5, 0))!.loyalty, movingLoyalty);

    final promotionRandom = _ScriptedRandom();
    final promotion = _controller(random: promotionRandom);
    addTearDown(promotion.dispose);
    promotion.board[0][3] = null;
    promotion.board[1][3] = ChessPiece(
      id: 'promotion-loyalty',
      type: PieceType.pawn,
      color: PieceColor.white,
      countryId: 'spy',
      loyalty: 37,
      fairPrice: 6,
    );
    promotion.makeMove(
      const ChessMove(from: Square(1, 3), to: Square(0, 3), isPromotion: true),
    );
    promotion.choosePromotion(PieceType.queen);
    expect(promotion.pieceAt(const Square(0, 3))!.loyalty, 37);
  });

  test('Mercantile refunds apply to humiliation and rolled failure', () {
    final humiliationRandom = _ScriptedRandom();
    final humiliation = _controller(
      random: humiliationRandom,
      whiteCountry: 'mercantile',
    );
    addTearDown(humiliation.dispose);
    _openOffer(humiliation, loyalty: 60, fairPrice: 10, offer: 4);
    final humiliationGold = humiliation.gold[PieceColor.white]!;
    humiliation.confirmOffer();
    expect(humiliation.lastOfferResult!.refund, 1);
    expect(humiliation.gold[PieceColor.white], humiliationGold - 3);

    final rollRandom = _ScriptedRandom();
    final rolled = _controller(random: rollRandom, whiteCountry: 'mercantile');
    addTearDown(rolled.dispose);
    _openOffer(rolled, loyalty: 100, fairPrice: 10, offer: 10);
    rollRandom.enqueue(99);
    final rolledGold = rolled.gold[PieceColor.white]!;
    rolled.confirmOffer();
    expect(rolled.lastOfferResult!.resolutionKind, OfferResolutionKind.rolled);
    expect(rolled.lastOfferResult!.refund, 3);
    expect(rolled.gold[PieceColor.white], rolledGold - 7);
  });

  test('Iron subtracts 25 gold from effective offer without changing caps', () {
    final random = _ScriptedRandom();
    final controller = _controller(random: random, blackCountry: 'iron');
    addTearDown(controller.dispose);
    _openOffer(
      controller,
      type: PieceType.pawn,
      countryId: 'iron',
      loyalty: 60,
      fairPrice: 10,
      offer: 30,
    );
    final pawnPreview = controller.calculateChance(includeHidden: true);
    expect(pawnPreview.actualOfferGold, 30);
    expect(pawnPreview.effectiveOfferGold, 5);
    expect(pawnPreview.countryOfferPriceAdjustment, -25);
    expect(pawnPreview.cap, chanceCaps[PieceType.pawn]);

    controller.cancelOffer();
    _openOffer(
      controller,
      type: PieceType.rook,
      countryId: 'iron',
      loyalty: 60,
      fairPrice: 10,
      offer: 30,
    );
    final rookPreview = controller.calculateChance(includeHidden: true);
    expect(rookPreview.effectiveOfferGold, 5);
    expect(rookPreview.cap, chanceCaps[PieceType.rook]);
  });

  test('Spy reveal is offer-scoped and retains its same-turn bonus', () {
    final random = _ScriptedRandom();
    final controller = _controller(random: random);
    addTearDown(controller.dispose);
    final target = _openOffer(
      controller,
      type: PieceType.rook,
      loyalty: 60,
      fairPrice: 22,
      offer: 22,
    );
    final hiddenChance = controller
        .calculateChance(includeHidden: true)
        .finalChance;

    expect(
      controller.loyaltyIntelligenceFor(target),
      LoyaltyIntelligence.coarse,
    );
    controller.revealOfferChance();
    expect(
      controller.loyaltyIntelligenceFor(target),
      LoyaltyIntelligence.exact,
    );
    expect(
      controller.calculateChance(includeHidden: true).finalChance,
      hiddenChance + countries['spy']!.spyRevealBonus,
    );

    controller.cancelOffer();
    expect(
      controller.loyaltyIntelligenceFor(target),
      LoyaltyIntelligence.coarse,
    );
    expect(controller.visibleExactLoyaltyForActiveCourt(target), isNull);
  });
}
