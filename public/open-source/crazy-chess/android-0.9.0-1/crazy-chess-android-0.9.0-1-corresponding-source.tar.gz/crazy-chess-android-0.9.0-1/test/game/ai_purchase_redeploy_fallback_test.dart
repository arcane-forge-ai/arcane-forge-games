import 'package:crazy_chess/battlefield/battlefield_models.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/game/game_controller.dart';
import 'package:crazy_chess/game/scenario_setup.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('in-place settlement restores the converted piece without motion', () {
    final controller = _purchasedRook();
    addTearDown(controller.dispose);
    controller
      ..specialTilesEnabled = true
      ..replaceSpecialTilesForTesting(const <SpecialTileState>[
        SpecialTileState(
          square: Square(4, 3),
          type: SpecialTileType.visibleTrap,
          pairId: 1,
        ),
      ]);

    final resolution = controller.resolvePendingPurchaseInPlace();

    expect(resolution, AiRedeployResolution.inPlace);
    expect(controller.pieceAt(const Square(4, 3))?.id, 'white_rook_target');
    expect(controller.pieceAt(const Square(4, 3))?.color, PieceColor.black);
    expect(controller.lastBoardMotionEvent, isNull);
    expect(controller.lastBattlefieldEvent, isNull);
    expect(
      controller.specialTileAt(const Square(4, 3))?.type,
      SpecialTileType.visibleTrap,
    );
    expect(controller.phase, GamePhase.playing);
    expect(controller.turn, PieceColor.white);
    expect(controller.completedActionCount, 1);
  });

  test('in-place settlement refunds an invalid occupied origin', () {
    final controller = _purchasedRook();
    addTearDown(controller.dispose);
    controller.board[4][3] = _piece(
      id: 'unexpected_blocker',
      type: PieceType.pawn,
      color: PieceColor.black,
    );
    final goldAfterOffer = controller.gold[PieceColor.black]!;

    final resolution = controller.resolvePendingPurchaseInPlace();

    expect(resolution, AiRedeployResolution.cancelledAndRefunded);
    expect(controller.gold[PieceColor.black], goldAfterOffer + 1);
    expect(controller.pieceAt(const Square(4, 3))?.id, 'white_rook_target');
    expect(controller.pieceAt(const Square(4, 3))?.color, PieceColor.white);
    expect(controller.lastCancelledPurchasePieceId, 'white_rook_target');
    expect(controller.phase, GamePhase.playing);
    expect(controller.turn, PieceColor.white);
  });

  test('AI redeploy uses an ordinary preferred square first', () {
    final controller = _purchasedRook();
    addTearDown(controller.dispose);
    final preferred = controller.legalRedeploySquares().first;

    final resolution = controller.resolveAiPurchaseRedeploy(
      preferredSquare: preferred,
    );

    expect(resolution, AiRedeployResolution.normal);
    expect(controller.pieceAt(preferred)?.id, 'white_rook_target');
    expect(controller.phase, isNot(GamePhase.redeploy));
    expect(controller.completedActionCount, 1);
  });

  test('AI redeploy may relax only immediate check when crowded', () {
    final controller = _purchasedRook();
    addTearDown(controller.dispose);
    _fillBlackHalf(controller, except: const Square(3, 7));
    expect(controller.legalRedeploySquares(), isEmpty);

    final resolution = controller.resolveAiPurchaseRedeploy();

    expect(resolution, AiRedeployResolution.immediateCheckRelaxed);
    expect(controller.pieceAt(const Square(3, 7))?.id, 'white_rook_target');
    expect(controller.isKingInCheck(PieceColor.white), isTrue);
    expect(controller.isKingInCheck(PieceColor.black), isFalse);
    expect(controller.phase, isNot(GamePhase.redeploy));
  });

  test('AI redeploy falls back to the vacated original square', () {
    final controller = _purchasedRook();
    addTearDown(controller.dispose);
    _fillBlackHalf(controller);

    final resolution = controller.resolveAiPurchaseRedeploy();

    expect(resolution, AiRedeployResolution.originalSquare);
    expect(controller.pieceAt(const Square(4, 3))?.id, 'white_rook_target');
    expect(controller.pieceAt(const Square(4, 3))?.color, PieceColor.black);
    expect(controller.phase, isNot(GamePhase.redeploy));
  });

  test('AI cancels and refunds a purchase when every placement fails', () {
    final controller = _purchasedRook();
    addTearDown(controller.dispose);
    _fillBlackHalf(controller);
    controller.board[4][3] = _piece(
      id: 'unexpected_blocker',
      type: PieceType.pawn,
      color: PieceColor.black,
    );
    final goldAfterOffer = controller.gold[PieceColor.black]!;

    final resolution = controller.resolveAiPurchaseRedeploy();

    expect(resolution, AiRedeployResolution.cancelledAndRefunded);
    expect(controller.gold[PieceColor.black], goldAfterOffer + 1);
    expect(controller.pieceAt(const Square(4, 3))?.id, 'white_rook_target');
    expect(controller.pieceAt(const Square(4, 3))?.color, PieceColor.white);
    expect(controller.lastCancelledPurchasePieceId, 'white_rook_target');
    expect(controller.phase, isNot(GamePhase.redeploy));
    expect(controller.completedActionCount, 1);
    expect(controller.fullEventLog.last, contains('purchase was cancelled'));
  });
}

GameController _purchasedRook() {
  final controller = GameController(battlefieldSeed: 41);
  controller.startScenario(
    ScenarioGameSetup(
      id: 'ai-redeploy-fallback',
      whiteCountryId: 'ashen',
      blackCountryId: 'iron',
      turn: PieceColor.black,
      battlefieldId: BattlefieldId.classic,
      battlefieldSeed: 41,
      whiteGold: 20,
      blackGold: 20,
      merchantSpeed: 4,
      economyEnabled: true,
      merchantEnabled: false,
      specialTilesEnabled: false,
      pieces: <ScenarioPiecePlacement>[
        ScenarioPiecePlacement(
          square: const Square(7, 7),
          piece: _piece(
            id: 'white_king',
            type: PieceType.king,
            color: PieceColor.white,
            loyalty: null,
            fairPrice: null,
          ),
        ),
        ScenarioPiecePlacement(
          square: const Square(0, 0),
          piece: _piece(
            id: 'black_king',
            type: PieceType.king,
            color: PieceColor.black,
            loyalty: null,
            fairPrice: null,
          ),
        ),
        ScenarioPiecePlacement(
          square: const Square(4, 3),
          piece: _piece(
            id: 'white_rook_target',
            type: PieceType.rook,
            color: PieceColor.white,
            loyalty: 0,
            fairPrice: 22,
          ),
        ),
      ],
    ),
  );
  controller
    ..selectedSquare = const Square(4, 3)
    ..openOfferForSelected()
    ..setOfferGold(1)
    ..confirmOffer()
    ..dismissLastOfferResult();
  expect(controller.phase, GamePhase.redeploy);
  return controller;
}

void _fillBlackHalf(GameController controller, {Square? except}) {
  var serial = 0;
  for (var row = 0; row <= 3; row++) {
    for (var col = 0; col < 8; col++) {
      final square = Square(row, col);
      if (square == except || controller.pieceAt(square) != null) continue;
      controller.board[row][col] = _piece(
        id: 'black_blocker_${serial++}',
        type: PieceType.pawn,
        color: PieceColor.black,
      );
    }
  }
}

ChessPiece _piece({
  required String id,
  required PieceType type,
  required PieceColor color,
  int? loyalty = 60,
  int? fairPrice = 6,
}) => ChessPiece(
  id: id,
  type: type,
  color: color,
  countryId: color == PieceColor.white ? 'ashen' : 'iron',
  loyalty: loyalty,
  fairPrice: fairPrice,
);
