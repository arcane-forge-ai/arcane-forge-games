import 'dart:math' as math;

import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

class _ZeroRandom implements math.Random {
  @override
  bool nextBool() => false;

  @override
  double nextDouble() => 0;

  @override
  int nextInt(int max) => 0;
}

class _MaximumRandom implements math.Random {
  @override
  bool nextBool() => true;

  @override
  double nextDouble() => .999999;

  @override
  int nextInt(int max) => max - 1;
}

void main() {
  test('fair-price bands include their documented boundaries', () {
    for (final entry in fairPriceBands.entries) {
      expect(randomFairPrice(entry.key, _ZeroRandom()), entry.value.minimum);
      expect(randomFairPrice(entry.key, _MaximumRandom()), entry.value.maximum);
    }
    expect(randomFairPrice(PieceType.king, _ZeroRandom()), isNull);
  });

  test('seeded controllers assign deterministic per-piece prices', () {
    List<int?> snapshot(int seed) {
      final controller = GameController(random: math.Random(seed));
      addTearDown(controller.dispose);
      controller.startNewGame();
      return [
        for (final row in controller.board)
          for (final piece in row)
            if (piece != null) piece.fairPrice,
      ];
    }

    final first = snapshot(20260729);
    final second = snapshot(20260729);
    final differentSeed = snapshot(20260730);

    expect(first, second);
    expect(first, isNot(differentSeed));
  });

  test('every starting non-King receives an in-band price', () {
    final controller = GameController(random: math.Random(7));
    addTearDown(controller.dispose);
    controller.startNewGame();

    for (final row in controller.board) {
      for (final piece in row) {
        if (piece == null) {
          continue;
        }
        final band = fairPriceBands[piece.type];
        if (piece.type == PieceType.king) {
          expect(piece.fairPrice, isNull);
        } else {
          expect(
            piece.fairPrice,
            inInclusiveRange(band!.minimum, band.maximum),
          );
        }
      }
    }
  });

  test('price survives copy, purchase, and later role changes', () {
    final controller = GameController(random: _ZeroRandom());
    addTearDown(controller.dispose);
    controller.startNewGame();
    const target = Square(1, 0);
    final original = controller.pieceAt(target)!;
    final assignedPrice = original.fairPrice;

    expect(original.copy().fairPrice, assignedPrice);

    controller.tapSquare(target);
    controller.openOfferForSelected();
    controller.confirmOffer();

    expect(controller.redeployPiece, isNotNull);
    expect(controller.redeployPiece!.fairPrice, assignedPrice);

    controller.redeployPiece!.type = PieceType.queen;
    expect(controller.redeployPiece!.fairPrice, assignedPrice);
    controller.redeployPiece!.type = PieceType.pawn;
    expect(controller.redeployPiece!.fairPrice, assignedPrice);
  });

  test(
    'offer default uses the public anchor while chance uses stored price',
    () {
      ChancePreview previewFor(int price) {
        final controller = GameController(random: math.Random(5))
          ..setupBlackCountryId = 'mercantile';
        addTearDown(controller.dispose);
        controller.startNewGame();
        const target = Square(1, 0);
        controller.board[target.row][target.col] = ChessPiece(
          id: 'priced-pawn-$price',
          type: PieceType.pawn,
          color: PieceColor.black,
          countryId: controller.blackCountryId,
          loyalty: 60,
          fairPrice: price,
        );
        controller.tapSquare(target);
        controller.openOfferForSelected();
        expect(controller.offerGold, fairPriceAnchors[PieceType.pawn]);
        return controller.calculateChance(includeHidden: false);
      }

      final lowerPrice = previewFor(5);
      final higherPrice = previewFor(7);

      expect(lowerPrice.goldModifier, greaterThan(higherPrice.goldModifier));
    },
  );

  test('only the active Spy court can read a purchasable enemy price', () {
    final spy = GameController(random: math.Random(9))
      ..setupWhiteCountryId = 'spy'
      ..setupBlackCountryId = 'mercantile'
      ..startNewGame();
    addTearDown(spy.dispose);
    final enemy = spy.pieceAt(const Square(1, 0))!;
    final friendly = spy.pieceAt(const Square(6, 0))!;

    expect(spy.visibleFairPriceForActiveCourt(enemy), enemy.fairPrice);
    expect(spy.visibleFairPriceForActiveCourt(friendly), isNull);

    final mercantile = GameController(random: math.Random(9))
      ..setupWhiteCountryId = 'mercantile'
      ..setupBlackCountryId = 'spy'
      ..startNewGame();
    addTearDown(mercantile.dispose);
    final spyEnemy = mercantile.pieceAt(const Square(1, 0))!;

    expect(mercantile.visibleFairPriceForActiveCourt(spyEnemy), isNull);
  });
}
