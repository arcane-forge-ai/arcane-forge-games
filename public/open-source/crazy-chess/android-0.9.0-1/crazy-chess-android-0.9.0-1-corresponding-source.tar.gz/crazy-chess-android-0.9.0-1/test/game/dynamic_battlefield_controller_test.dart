import 'dart:math' as math;

import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('dynamic battlefield controller integration', () {
    test('selected battlefield initializes a seeded mirrored pair', () {
      final controller = _controller(BattlefieldId.verdantPastures);
      addTearDown(controller.dispose);

      expect(controller.battlefieldId, BattlefieldId.verdantPastures);
      expect(controller.specialTiles, hasLength(2));
      expect(
        controller.specialTiles.last.square,
        mirroredSquare(controller.specialTiles.first.square),
      );
      expect(controller.activeBattlefieldSeed, 31415);
    });

    test(
      'charged shrine transforms a non-king in place and preserves state',
      () {
        final controller = _controller(BattlefieldId.verdantPastures);
        addTearDown(controller.dispose);
        const from = Square(6, 4);
        const to = Square(5, 4);
        final piece = controller.pieceAt(from)!;
        final identity = piece.id;
        final loyalty = piece.loyalty;
        final fairPrice = piece.fairPrice;
        final country = piece.countryId;
        controller.replaceSpecialTilesForTesting(<SpecialTileState>[
          SpecialTileState(
            square: to,
            type: SpecialTileType.knightShrine,
            pairId: 1,
            progress: 2,
            occupantPieceId: piece.id,
          ),
        ]);

        _move(controller, from, to);

        final transformed = controller.pieceAt(to)!;
        expect(transformed.id, identity);
        expect(transformed.type, PieceType.knight);
        expect(transformed.color, PieceColor.white);
        expect(transformed.countryId, country);
        expect(transformed.loyalty, loyalty);
        expect(transformed.fairPrice, fairPrice);
        expect(transformed.hasMoved, isTrue);
        expect(controller.specialTileAt(to), isNull);
        expect(controller.turn, PieceColor.black);
      },
    );

    test('chest pays its occupant court and disappears', () {
      final controller = _controller(BattlefieldId.gildedBazaar);
      addTearDown(controller.dispose);
      const from = Square(6, 3);
      const to = Square(5, 3);
      final piece = controller.pieceAt(from)!;
      final before = controller.gold[PieceColor.white]!;
      controller.replaceSpecialTilesForTesting(<SpecialTileState>[
        SpecialTileState(
          square: to,
          type: SpecialTileType.treasureChest,
          pairId: 2,
          progress: 1,
          occupantPieceId: piece.id,
          occupantTurnMask: 2,
        ),
      ]);

      _move(controller, from, to);

      final event = controller.lastBattlefieldEvent!;
      expect(event.type, BattlefieldEventType.treasureFound);
      expect(event.goldAmount, inInclusiveRange(8, 50));
      expect(controller.gold[PieceColor.white], before + event.goldAmount);
      expect(controller.specialTileAt(to), isNull);
    });

    test('Diamond Ring tile grants a stackable court token', () {
      final controller = _controller(BattlefieldId.gildedBazaar);
      addTearDown(controller.dispose);
      const from = Square(6, 2);
      const to = Square(5, 2);
      final piece = controller.pieceAt(from)!;
      controller.diamondRingTokens[PieceColor.white] = 2;
      controller.replaceSpecialTilesForTesting(<SpecialTileState>[
        SpecialTileState(
          square: to,
          type: SpecialTileType.diamondRing,
          pairId: 3,
          progress: 2,
          occupantPieceId: piece.id,
        ),
      ]);

      _move(controller, from, to);

      expect(controller.diamondRingTokens[PieceColor.white], 3);
      expect(
        controller.lastBattlefieldEvent!.type,
        BattlefieldEventType.diamondRingFound,
      );
    });

    test('trap removes a non-king before the next turn is evaluated', () {
      final controller = _controller(BattlefieldId.ruinedCauseway);
      addTearDown(controller.dispose);
      const from = Square(6, 1);
      const to = Square(5, 1);
      final piece = controller.pieceAt(from)!;
      controller.replaceSpecialTilesForTesting(<SpecialTileState>[
        SpecialTileState(
          square: to,
          type: SpecialTileType.visibleTrap,
          pairId: 4,
          progress: 1,
          occupantPieceId: piece.id,
          occupantTurnMask: 2,
        ),
      ]);

      _move(controller, from, to);

      expect(controller.pieceAt(to), isNull);
      expect(controller.phase, GamePhase.playing);
      expect(controller.turn, PieceColor.black);
      expect(
        controller.lastBattlefieldEvent!.type,
        BattlefieldEventType.trapTriggered,
      );
    });

    test('trap killing a king ends the match without handing off the turn', () {
      final controller = _controller(BattlefieldId.ruinedCauseway);
      addTearDown(controller.dispose);
      const from = Square(7, 4);
      const to = Square(6, 4);
      controller.board[to.row][to.col] = null;
      final king = controller.pieceAt(from)!;
      controller.replaceSpecialTilesForTesting(<SpecialTileState>[
        SpecialTileState(
          square: to,
          type: SpecialTileType.visibleTrap,
          pairId: 5,
          progress: 1,
          occupantPieceId: king.id,
          occupantTurnMask: 2,
        ),
      ]);

      _move(controller, from, to);

      expect(controller.phase, GamePhase.gameOver);
      expect(controller.winner, PieceColor.black);
      expect(controller.gameEndReason, GameEndReason.kingTrapfall);
      expect(controller.resolvedGameEndReason, GameEndReason.kingTrapfall);
      expect(controller.turn, PieceColor.white);
      expect(controller.completedActionCount, 1);
      expect(controller.pieceAt(to), isNull);
      expect(controller.lastBattlefieldEvent?.pieceId, king.id);
      expect(controller.eventLog.first, contains('KING TRAPFALL'));
    });

    test('Chaos Crucible awakens after the third completed action', () {
      final controller = _controller(BattlefieldId.chaosCrucible);
      addTearDown(controller.dispose);

      expect(controller.specialTiles, isEmpty);
      _move(controller, const Square(6, 4), const Square(4, 4));
      expect(controller.specialTiles, isEmpty);
      _move(controller, const Square(1, 4), const Square(3, 4));
      expect(controller.specialTiles, isEmpty);
      _move(controller, const Square(7, 6), const Square(5, 5));

      expect(controller.specialTiles, hasLength(2));
      expect(
        controller.specialTiles.last.square,
        mirroredSquare(controller.specialTiles.first.square),
      );
      expect(
        controller.lastBattlefieldEvent!.type,
        BattlefieldEventType.tilesSpawned,
      );
    });

    test('active special tiles are forbidden betrayal redeploy squares', () {
      final controller = _controller(BattlefieldId.gildedBazaar);
      addTearDown(controller.dispose);
      const blocked = Square(4, 4);
      controller.replaceSpecialTilesForTesting(const <SpecialTileState>[
        SpecialTileState(
          square: blocked,
          type: SpecialTileType.treasureChest,
          pairId: 7,
        ),
      ]);
      controller
        ..phase = GamePhase.redeploy
        ..redeployPiece = _piece(
          id: 'bought',
          type: PieceType.bishop,
          color: PieceColor.white,
        )
        ..redeployOriginalSquare = const Square(1, 3);

      expect(controller.isLegalRedeploy(blocked), isFalse);
      expect(controller.legalRedeploySquares(), isNot(contains(blocked)));
    });
  });

  group('Diamond Ring and Loyalty integration', () {
    test(
      'ring adds 50 to an eligible rolled queen offer and raises cap to 90',
      () {
        final controller = _controller(BattlefieldId.gildedBazaar);
        addTearDown(controller.dispose);
        controller
          ..gold[PieceColor.white] = 200
          ..diamondRingTokens[PieceColor.white] = 0;
        _openQueenOffer(controller, loyalty: 60, offer: 40);
        final withoutRing = controller
            .calculateChance(includeHidden: true)
            .finalChance;
        controller.diamondRingTokens[PieceColor.white] = 1;

        final preview = controller.calculateChance(includeHidden: true);

        expect(preview.valid, isTrue);
        expect(preview.ringTokenApplied, isTrue);
        expect(preview.treasureModifier, 50);
        expect(preview.cap, 90);
        expect(preview.finalChance, withoutRing + 50);
      },
    );

    test('eligible rolled queen offer consumes one ring on win or loss', () {
      final controller = _controller(BattlefieldId.gildedBazaar);
      addTearDown(controller.dispose);
      controller
        ..gold[PieceColor.white] = 200
        ..diamondRingTokens[PieceColor.white] = 2;
      _openQueenOffer(controller, loyalty: 60, offer: 40);

      controller.confirmOffer();

      expect(controller.diamondRingTokens[PieceColor.white], 1);
      expect(controller.lastOfferResult!.ringTokenConsumed, isTrue);
      expect(controller.lastOfferResult!.treasureModifier, 50);
    });

    test('automatic and humiliating queen offers do not consume a ring', () {
      final automatic = _controller(BattlefieldId.gildedBazaar);
      addTearDown(automatic.dispose);
      automatic
        ..gold[PieceColor.white] = 200
        ..diamondRingTokens[PieceColor.white] = 1;
      _openQueenOffer(automatic, loyalty: 0, offer: 40);
      expect(
        automatic.calculateChance(includeHidden: true).ringTokenApplied,
        isFalse,
      );
      automatic.confirmOffer();
      expect(automatic.diamondRingTokens[PieceColor.white], 1);

      final humiliated = _controller(BattlefieldId.gildedBazaar);
      addTearDown(humiliated.dispose);
      humiliated
        ..gold[PieceColor.white] = 200
        ..diamondRingTokens[PieceColor.white] = 1;
      _openQueenOffer(humiliated, loyalty: 60, offer: 10);
      expect(
        humiliated.calculateChance(includeHidden: true).ringTokenApplied,
        isFalse,
      );
      humiliated.confirmOffer();
      expect(humiliated.diamondRingTokens[PieceColor.white], 1);
      expect(
        humiliated.lastOfferResult!.resolutionKind,
        OfferResolutionKind.humiliated,
      );
    });
  });
}

GameController _controller(BattlefieldId battlefield) {
  return GameController(random: math.Random(20260730), battlefieldSeed: 31415)
    ..setupBattlefieldId = battlefield
    ..startNewGame();
}

void _move(GameController controller, Square from, Square to) {
  final move = controller
      .legalMovesFrom(from)
      .singleWhere((candidate) => candidate.to == to);
  controller.makeMove(move);
}

void _openQueenOffer(
  GameController controller, {
  required int loyalty,
  required int offer,
}) {
  const target = Square(1, 0);
  controller.board[target.row][target.col] = _piece(
    id: 'ring-target',
    type: PieceType.queen,
    color: PieceColor.black,
    countryId: 'mercantile',
    loyalty: loyalty,
    fairPrice: 40,
  );
  controller.tapSquare(target);
  controller.openOfferForSelected();
  controller.setOfferGold(offer);
}

ChessPiece _piece({
  required String id,
  required PieceType type,
  required PieceColor color,
  String? countryId,
  int? loyalty = 60,
  int? fairPrice = 12,
}) {
  return ChessPiece(
    id: id,
    type: type,
    color: color,
    countryId: countryId ?? (color == PieceColor.white ? 'mercantile' : 'iron'),
    loyalty: loyalty,
    fairPrice: fairPrice,
  );
}
