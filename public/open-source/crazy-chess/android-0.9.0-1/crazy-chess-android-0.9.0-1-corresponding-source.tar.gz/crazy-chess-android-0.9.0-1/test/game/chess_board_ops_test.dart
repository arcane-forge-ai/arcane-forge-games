import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/game/chess_board_ops.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const ops = ChessBoardOps();

  ChessPiece piece(
    String id,
    PieceType type,
    PieceColor color, {
    bool hasMoved = false,
  }) {
    return ChessPiece(
      id: id,
      type: type,
      color: color,
      countryId: 'test',
      loyalty: null,
      fairPrice: null,
      hasMoved: hasMoved,
    );
  }

  List<List<ChessPiece?>> emptyBoard() => List<List<ChessPiece?>>.generate(
    8,
    (_) => List<ChessPiece?>.filled(8, null),
  );

  test('clone creates independent pieces and finds the requested king', () {
    final board = emptyBoard();
    board[7][4] = piece('white-king', PieceType.king, PieceColor.white);

    final copy = ops.clone(board);
    copy[7][4]!.countryId = 'changed';

    expect(board[7][4]!.countryId, 'test');
    expect(ops.kingSquare(copy, PieceColor.white), const Square(7, 4));
    expect(ops.kingSquare(copy, PieceColor.black), isNull);
  });

  test('applyMove handles en passant and an explicit promotion', () {
    final board = emptyBoard();
    board[3][4] = piece('white-pawn', PieceType.pawn, PieceColor.white);
    board[3][5] = piece('black-pawn', PieceType.pawn, PieceColor.black);

    ops.applyMove(
      board,
      const ChessMove(
        from: Square(3, 4),
        to: Square(2, 5),
        isCapture: true,
        isEnPassant: true,
        isPromotion: true,
      ),
      promotionOverride: PieceType.queen,
    );

    expect(board[3][4], isNull);
    expect(board[3][5], isNull);
    expect(board[2][5]!.type, PieceType.queen);
    expect(board[2][5]!.hasMoved, isTrue);
  });

  test('applyMove relocates the rook when castling', () {
    final board = emptyBoard();
    board[7][4] = piece('king', PieceType.king, PieceColor.white);
    board[7][7] = piece('rook', PieceType.rook, PieceColor.white);

    ops.applyMove(
      board,
      const ChessMove(from: Square(7, 4), to: Square(7, 6), isCastle: true),
    );

    expect(board[7][6]!.id, 'king');
    expect(board[7][5]!.id, 'rook');
    expect(board[7][7], isNull);
    expect(board[7][5]!.hasMoved, isTrue);
  });
}
