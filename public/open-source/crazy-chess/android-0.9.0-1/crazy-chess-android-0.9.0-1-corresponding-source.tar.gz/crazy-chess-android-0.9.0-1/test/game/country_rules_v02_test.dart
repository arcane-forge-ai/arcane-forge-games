import 'dart:math' as math;

import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/game/scenario_setup.dart';
import 'package:flutter_test/flutter_test.dart';

GameController _controller({
  required String whiteCountry,
  required String blackCountry,
}) {
  return GameController(random: math.Random(17))
    ..setupWhiteCountryId = whiteCountry
    ..setupBlackCountryId = blackCountry
    ..startNewGame();
}

ChessPiece _piece({
  required String id,
  required PieceType type,
  required PieceColor color,
  required String countryId,
  int? loyalty = 60,
  int? fairPrice,
}) {
  return ChessPiece(
    id: id,
    type: type,
    color: color,
    countryId: countryId,
    loyalty: type == PieceType.king ? null : loyalty,
    fairPrice: type == PieceType.king
        ? null
        : fairPrice ?? fairPriceAnchors[type],
  );
}

void _openOffer(GameController controller, Square square, {required int gold}) {
  controller
    ..tapSquare(square)
    ..openOfferForSelected()
    ..setOfferGold(gold);
}

void _clearBoard(GameController controller) {
  for (final row in controller.board) {
    for (var col = 0; col < row.length; col++) {
      row[col] = null;
    }
  }
  controller.board[7][4] = _piece(
    id: 'white-king',
    type: PieceType.king,
    color: PieceColor.white,
    countryId: controller.whiteCountry.id,
  );
  controller.board[0][4] = _piece(
    id: 'black-king',
    type: PieceType.king,
    color: PieceColor.black,
    countryId: controller.blackCountry.id,
  );
}

void main() {
  group('match economy settings', () {
    test('countries modify the chosen starting-gold setting', () {
      final controller = GameController(random: math.Random(1))
        ..setupWhiteCountryId = 'mercantile'
        ..setupBlackCountryId = 'iron'
        ..setStartingGold(14)
        ..setMerchantPayout(12)
        ..startNewGame();
      addTearDown(controller.dispose);

      expect(controller.gold[PieceColor.white], 18);
      expect(controller.gold[PieceColor.black], 14);
      expect(controller.merchantPayout, 12);
    });

    test('merchant payout composes receiver and opponent modifiers', () {
      final iron = _controller(whiteCountry: 'spy', blackCountry: 'iron');
      addTearDown(iron.dispose);
      iron
        ..setMerchantPayout(12)
        ..merchantPayout = 12
        ..merchantPosition = 15
        ..merchantDirection = 1;
      final ironGold = iron.gold[PieceColor.black]!;
      iron.makeMove(const ChessMove(from: Square(6, 0), to: Square(5, 0)));
      expect(iron.gold[PieceColor.black], ironGold + 9);

      final mercantile = _controller(
        whiteCountry: 'mercantile',
        blackCountry: 'spy',
      );
      addTearDown(mercantile.dispose);
      mercantile
        ..merchantPayout = 12
        ..merchantPosition = 1
        ..merchantDirection = -1
        ..turn = PieceColor.black;
      final mercantileGold = mercantile.gold[PieceColor.white]!;
      mercantile.makeMove(
        const ChessMove(from: Square(1, 0), to: Square(2, 0)),
      );
      expect(mercantile.gold[PieceColor.white], mercantileGold + 14);
    });
  });

  test('Iron applies a literal -25 effective-offer penalty to every role', () {
    for (final type in const [
      PieceType.pawn,
      PieceType.knight,
      PieceType.bishop,
      PieceType.rook,
      PieceType.queen,
    ]) {
      final controller = _controller(whiteCountry: 'spy', blackCountry: 'iron');
      addTearDown(controller.dispose);
      controller.gold[PieceColor.white] = 100;
      const target = Square(3, 3);
      controller.board[target.row][target.col] = _piece(
        id: 'iron-${type.name}',
        type: type,
        color: PieceColor.black,
        countryId: 'iron',
        fairPrice: 20,
      );
      _openOffer(controller, target, gold: 20);

      final preview = controller.calculateChance(includeHidden: true);
      expect(preview.actualOfferGold, 20, reason: type.name);
      expect(preview.effectiveOfferGold, -5, reason: type.name);
      expect(preview.countryOfferPriceAdjustment, -25, reason: type.name);
      expect(preview.cap, chanceCaps[type], reason: type.name);
    }
  });

  group('Horse Kingdom', () {
    ChancePreview knightOffer({
      required String buyer,
      required String defender,
    }) {
      final controller = _controller(
        whiteCountry: buyer,
        blackCountry: defender,
      );
      addTearDown(controller.dispose);
      controller.gold[PieceColor.white] = 100;
      const target = Square(3, 3);
      controller.board[target.row][target.col] = _piece(
        id: '$buyer-$defender-knight',
        type: PieceType.knight,
        color: PieceColor.black,
        countryId: defender,
        fairPrice: 14,
      );
      _openOffer(controller, target, gold: 14);
      return controller.calculateChance(includeHidden: true);
    }

    test('buyer and defender use fair-price adjustments that can cancel', () {
      final offense = knightOffer(buyer: 'horse', defender: 'mercantile');
      expect(offense.countryOfferPriceAdjustment, 7);
      expect(offense.effectiveOfferGold, 21);
      expect(offense.cap, 90);

      final defense = knightOffer(buyer: 'mercantile', defender: 'horse');
      expect(defense.countryOfferPriceAdjustment, -7);
      expect(defense.effectiveOfferGold, 7);

      final mirror = knightOffer(buyer: 'horse', defender: 'horse');
      expect(mirror.countryOfferPriceAdjustment, 0);
      expect(mirror.effectiveOfferGold, 14);
      expect(mirror.cap, 90);
    });

    test('only a Horse-controlled Knight capture shocks enemy loyalty', () {
      final controller = _controller(
        whiteCountry: 'horse',
        blackCountry: 'mercantile',
      );
      addTearDown(controller.dispose);
      final survivor = controller.pieceAt(const Square(1, 0))!..loyalty = 37;
      controller.board[4][4] = _piece(
        id: 'horse-raider',
        type: PieceType.knight,
        color: PieceColor.white,
        countryId: 'horse',
      );
      controller.board[2][5] = _piece(
        id: 'capture-target',
        type: PieceType.pawn,
        color: PieceColor.black,
        countryId: 'mercantile',
      );

      controller.makeMove(
        const ChessMove(from: Square(4, 4), to: Square(2, 5), isCapture: true),
      );

      expect(survivor.loyalty, 27);
      expect(controller.pieceAt(const Square(0, 4))!.loyalty, isNull);
    });
  });

  group('Corsair Freeholds', () {
    test('a capture transfers up to six gold and never goes negative', () {
      final controller = _controller(
        whiteCountry: 'corsair',
        blackCountry: 'mercantile',
      );
      addTearDown(controller.dispose);
      controller.gold
        ..[PieceColor.white] = 10
        ..[PieceColor.black] = 4;
      controller.board[4][4] = _piece(
        id: 'corsair-capturer',
        type: PieceType.rook,
        color: PieceColor.white,
        countryId: 'corsair',
      );
      controller.board[4][5] = _piece(
        id: 'corsair-target',
        type: PieceType.pawn,
        color: PieceColor.black,
        countryId: 'mercantile',
      );

      controller.makeMove(
        const ChessMove(from: Square(4, 4), to: Square(4, 5), isCapture: true),
      );

      expect(controller.gold[PieceColor.white], 14);
      expect(controller.gold[PieceColor.black], 0);
    });

    test('capture theft is disabled with the scenario economy', () {
      final controller = _controller(
        whiteCountry: 'corsair',
        blackCountry: 'mercantile',
      );
      addTearDown(controller.dispose);
      controller
        ..economyEnabled = false
        ..gold[PieceColor.white] = 10
        ..gold[PieceColor.black] = 10;
      controller.board[4][4] = _piece(
        id: 'corsair-no-economy',
        type: PieceType.rook,
        color: PieceColor.white,
        countryId: 'corsair',
      );
      controller.board[4][5] = _piece(
        id: 'corsair-no-economy-target',
        type: PieceType.pawn,
        color: PieceColor.black,
        countryId: 'mercantile',
      );

      controller.makeMove(
        const ChessMove(from: Square(4, 4), to: Square(4, 5), isCapture: true),
      );

      expect(controller.gold[PieceColor.white], 10);
      expect(controller.gold[PieceColor.black], 10);
    });
  });

  group('Sunlit Synod', () {
    test('a Bishop attack exposes exact loyalty and adds 25 chance', () {
      final controller = _controller(
        whiteCountry: 'sunlit',
        blackCountry: 'mercantile',
      );
      addTearDown(controller.dispose);
      _clearBoard(controller);
      controller.gold[PieceColor.white] = 100;
      controller.board[4][1] = _piece(
        id: 'sunlit-bishop',
        type: PieceType.bishop,
        color: PieceColor.white,
        countryId: 'sunlit',
      );
      const target = Square(2, 3);
      final enemy = _piece(
        id: 'exposed-rook',
        type: PieceType.rook,
        color: PieceColor.black,
        countryId: 'mercantile',
        loyalty: 63,
        fairPrice: 22,
      );
      controller.board[target.row][target.col] = enemy;
      _openOffer(controller, target, gold: 22);

      final exposed = controller.calculateChance(includeHidden: true);
      expect(controller.visibleExactLoyaltyForActiveCourt(enemy), 63);
      expect(exposed.targetExposed, isTrue);
      expect(exposed.countryChanceModifier, 25);

      controller.board[4][1] = null;
      controller.board[4][0] = _piece(
        id: 'sunlit-bishop-moved',
        type: PieceType.bishop,
        color: PieceColor.white,
        countryId: 'sunlit',
      );
      final hidden = controller.calculateChance(includeHidden: true);
      expect(controller.visibleExactLoyaltyForActiveCourt(enemy), isNull);
      expect(hidden.targetExposed, isFalse);
      expect(exposed.finalChance, hidden.finalChance + 25);
    });

    test('final-Bishop capture halves, then promotion restores loyalty', () {
      final controller = _controller(
        whiteCountry: 'sunlit',
        blackCountry: 'mercantile',
      );
      addTearDown(controller.dispose);
      final ally = controller.pieceAt(const Square(6, 0))!..loyalty = 81;
      final finalBishop = controller.pieceAt(const Square(7, 5))!;
      controller.board[7][2] = null;
      controller.board[7][5] = null;
      controller.board[4][4] = finalBishop;
      controller.board[2][2] = _piece(
        id: 'bishop-capturer',
        type: PieceType.rook,
        color: PieceColor.black,
        countryId: 'mercantile',
      );
      controller.turn = PieceColor.black;

      controller.makeMove(
        const ChessMove(from: Square(2, 2), to: Square(4, 4), isCapture: true),
      );
      expect(ally.loyalty, 41);

      controller.board[0][0] = _piece(
        id: 'sunlit-promote',
        type: PieceType.pawn,
        color: PieceColor.white,
        countryId: 'sunlit',
        loyalty: 30,
      );
      controller
        ..turn = PieceColor.white
        ..phase = GamePhase.promotion
        ..pendingPromotionSquare = const Square(0, 0)
        ..choosePromotion(PieceType.bishop);
      expect(ally.loyalty, 82);
    });

    test('purchasing the final enemy Bishop applies loss after redeploy', () {
      final controller = _controller(
        whiteCountry: 'mercantile',
        blackCountry: 'sunlit',
      );
      addTearDown(controller.dispose);
      controller.gold[PieceColor.white] = 100;
      final ally = controller.pieceAt(const Square(1, 1))!..loyalty = 81;
      final finalBishop = controller.pieceAt(const Square(0, 5))!..loyalty = 0;
      controller.board[0][2] = null;
      controller.board[0][5] = null;
      const target = Square(2, 5);
      controller.board[target.row][target.col] = finalBishop;
      _openOffer(controller, target, gold: 1);

      controller.confirmOffer();
      expect(controller.phase, GamePhase.redeploy);
      expect(ally.loyalty, 81);
      controller.placeRedeploy(controller.legalRedeploySquares().first);

      expect(ally.loyalty, 41);
    });

    test('a scenario authored with zero Bishops arms without a free bonus', () {
      final controller = GameController(random: math.Random(4));
      addTearDown(controller.dispose);
      final ally = _piece(
        id: 'authored-ally',
        type: PieceType.pawn,
        color: PieceColor.white,
        countryId: 'sunlit',
        loyalty: 81,
      );
      final promote = _piece(
        id: 'authored-promotion',
        type: PieceType.pawn,
        color: PieceColor.white,
        countryId: 'sunlit',
        loyalty: 30,
      );
      controller.startScenario(
        ScenarioGameSetup(
          id: 'sunlit-zero-bishops',
          whiteCountryId: 'sunlit',
          blackCountryId: 'mercantile',
          turn: PieceColor.white,
          battlefieldId: BattlefieldId.classic,
          battlefieldSeed: 1,
          whiteGold: 10,
          blackGold: 10,
          merchantSpeed: 4,
          economyEnabled: true,
          merchantEnabled: false,
          specialTilesEnabled: false,
          pieces: [
            ScenarioPiecePlacement(
              square: const Square(7, 4),
              piece: _piece(
                id: 'authored-white-king',
                type: PieceType.king,
                color: PieceColor.white,
                countryId: 'sunlit',
              ),
            ),
            ScenarioPiecePlacement(
              square: const Square(0, 4),
              piece: _piece(
                id: 'authored-black-king',
                type: PieceType.king,
                color: PieceColor.black,
                countryId: 'mercantile',
              ),
            ),
            ScenarioPiecePlacement(square: const Square(6, 0), piece: ally),
            ScenarioPiecePlacement(square: const Square(0, 0), piece: promote),
          ],
        ),
      );
      controller
        ..phase = GamePhase.promotion
        ..pendingPromotionSquare = const Square(0, 0)
        ..choosePromotion(PieceType.bishop);

      expect(ally.loyalty, 81);
      expect(promote.loyalty, 30);
    });
  });
}
