import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/game_controller_test_driver.dart';

void main() {
  group('board presentation events', () {
    test('capture snapshots movement and keeps the target identity', () {
      final controller = GameController();
      addTearDown(controller.dispose);
      final driver = GameControllerTestDriver(controller)..startGame();

      driver.move('e2', 'e4');
      driver.move('d7', 'd5');
      final capturedId = controller.pieceAt(const Square(3, 3))!.id;
      driver.move('e4', 'd5');

      final event = controller.lastBoardMotionEvent!;
      expect(event.kind, BoardMotionKind.chessMove);
      expect(event.motions, hasLength(1));
      expect(event.motions.single.from, const Square(4, 4));
      expect(event.motions.single.to, const Square(3, 3));
      expect(event.capturedSquare, const Square(3, 3));
      expect(event.capturedPiece?.id, capturedId);
      expect(event.capturedPiece?.color, PieceColor.black);
      expect(controller.pieceAt(const Square(3, 3))?.color, PieceColor.white);
    });

    test('castling snapshots King and Rook as one presentation event', () {
      final controller = GameController()..startNewGame();
      addTearDown(controller.dispose);
      controller.board[7][5] = null;
      controller.board[7][6] = null;

      controller.makeMove(
        const ChessMove(from: Square(7, 4), to: Square(7, 6), isCastle: true),
      );

      final event = controller.lastBoardMotionEvent!;
      expect(event.kind, BoardMotionKind.castle);
      expect(event.motions, hasLength(2));
      expect(
        event.motions.map((motion) => motion.piece.type),
        containsAll(<PieceType>[PieceType.king, PieceType.rook]),
      );
      expect(event.motions.last.from, const Square(7, 7));
      expect(event.motions.last.to, const Square(7, 5));
    });

    test('en passant preserves the captured pawn square for impact', () {
      final controller = GameController();
      addTearDown(controller.dispose);
      final driver = GameControllerTestDriver(controller)..startGame();
      driver.move('e2', 'e4');
      driver.move('a7', 'a6');
      driver.move('e4', 'e5');
      driver.move('d7', 'd5');
      final capturedId = controller.pieceAt(const Square(3, 3))!.id;

      driver.move('e5', 'd6');

      final event = controller.lastBoardMotionEvent!;
      expect(event.capturedPiece?.id, capturedId);
      expect(event.capturedSquare, const Square(3, 3));
      expect(event.motions.single.to, const Square(2, 3));
    });

    test(
      'betrayal transforms on dismissal before confirmed redeploy travel',
      () {
        final controller = GameController();
        addTearDown(controller.dispose);
        controller.startNewGame();
        const target = Square(1, 0);
        final targetPiece = controller.pieceAt(target)!..loyalty = 0;
        final originalId = targetPiece.id;

        controller.tapSquare(target);
        controller.openOfferForSelected();
        controller.setOfferGold(1);
        controller.confirmOffer();

        expect(controller.lastOfferResult?.success, isTrue);
        expect(controller.lastBetrayalTransformEvent, isNull);
        expect(controller.redeployPiece?.id, originalId);

        controller.dismissLastOfferResult();

        final betrayal = controller.lastBetrayalTransformEvent!;
        expect(betrayal.square, target);
        expect(betrayal.before.id, originalId);
        expect(betrayal.before.color, PieceColor.black);
        expect(betrayal.before.countryId, 'iron');
        expect(betrayal.after.color, PieceColor.white);
        expect(betrayal.after.countryId, 'mercantile');

        final destination = controller.legalRedeploySquares().first;
        controller.placeRedeploy(destination);

        final redeploy = controller.lastBoardMotionEvent!;
        expect(redeploy.kind, BoardMotionKind.redeploy);
        expect(redeploy.motions.single.piece.id, originalId);
        expect(redeploy.motions.single.from, target);
        expect(redeploy.motions.single.to, destination);
      },
    );
  });

  testWidgets('presentation coordinator holds and releases timed movement', (
    tester,
  ) async {
    final controller = GameController()..startNewGame();
    final coordinator = BoardPresentationCoordinator(controller: controller);
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);

    controller.makeMove(
      controller
          .legalMovesFrom(const Square(6, 4))
          .singleWhere((move) => move.to == const Square(4, 4)),
    );

    expect(coordinator.isBusy, isTrue);
    expect(coordinator.activeMotion, isNotNull);
    await tester.pump(const Duration(milliseconds: 399));
    expect(coordinator.isBusy, isTrue);
    await tester.pump(const Duration(milliseconds: 1));
    expect(coordinator.isBusy, isFalse);
    expect(
      coordinator.lastCompletedMotion?.motions.single.to,
      const Square(4, 4),
    );
  });

  testWidgets('reduced motion resolves immediately with static move memory', (
    tester,
  ) async {
    final controller = GameController()..startNewGame();
    final coordinator = BoardPresentationCoordinator(controller: controller)
      ..setReducedMotion(true);
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);

    controller.makeMove(
      controller
          .legalMovesFrom(const Square(6, 4))
          .singleWhere((move) => move.to == const Square(4, 4)),
    );
    await tester.pump();

    expect(coordinator.isBusy, isFalse);
    expect(coordinator.lastCompletedMotion, isNotNull);
    expect(coordinator.reducedMotion, isTrue);
  });
}
