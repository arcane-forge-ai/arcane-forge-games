import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemoryIndexStore implements TitleBackgroundIndexStore {
  int? value;
  bool fail = false;

  @override
  Future<int?> readNextIndex() async {
    if (fail) {
      throw StateError('storage unavailable');
    }
    return value;
  }

  @override
  Future<void> writeNextIndex(int value) async {
    if (fail) {
      throw StateError('storage unavailable');
    }
    this.value = value;
  }
}

void main() {
  test('launch backgrounds rotate A to B to C and wrap', () async {
    final store = _MemoryIndexStore();
    final rotation = TitleBackgroundRotation(store: store);

    expect(
      await rotation.selectForLaunch(),
      TitleBackgroundRotation.backgrounds[0],
    );
    expect(
      await rotation.selectForLaunch(),
      TitleBackgroundRotation.backgrounds[1],
    );
    expect(
      await rotation.selectForLaunch(),
      TitleBackgroundRotation.backgrounds[2],
    );
    expect(
      await rotation.selectForLaunch(),
      TitleBackgroundRotation.backgrounds[0],
    );
  });

  test('storage failure deterministically falls back to candidate A', () async {
    final store = _MemoryIndexStore()..fail = true;
    final rotation = TitleBackgroundRotation(store: store);

    expect(
      await rotation.selectForLaunch(),
      TitleBackgroundRotation.backgrounds.first,
    );
  });
}
