from __future__ import annotations

from pathlib import Path
import plistlib
import unittest
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[1]
ANDROID_NS = "http://schemas.android.com/apk/res/android"
ANDROID = f"{{{ANDROID_NS}}}"


class MobileOrientationConfigTest(unittest.TestCase):
    def test_android_uses_sensor_landscape_for_the_game_activity(self) -> None:
        manifest = ET.parse(
            ROOT / "android" / "app" / "src" / "main" / "AndroidManifest.xml"
        ).getroot()

        landscape_feature = manifest.find(
            f"uses-feature[@{ANDROID}name='android.hardware.screen.landscape']"
        )
        self.assertIsNotNone(landscape_feature)
        self.assertEqual(landscape_feature.get(f"{ANDROID}required"), "true")

        application = manifest.find("application")
        self.assertIsNotNone(application)
        self.assertEqual(application.get(f"{ANDROID}appCategory"), "game")

        main_activity = next(
            activity
            for activity in application.findall("activity")
            if activity.get(f"{ANDROID}name") == ".MainActivity"
        )
        self.assertEqual(
            main_activity.get(f"{ANDROID}screenOrientation"),
            "sensorLandscape",
        )

    def test_iphone_is_landscape_only_while_ipad_remains_adaptive(self) -> None:
        with (ROOT / "ios" / "Runner" / "Info.plist").open("rb") as source:
            info = plistlib.load(source)

        self.assertEqual(
            info["UISupportedInterfaceOrientations"],
            [
                "UIInterfaceOrientationLandscapeLeft",
                "UIInterfaceOrientationLandscapeRight",
            ],
        )
        self.assertEqual(
            info["UISupportedInterfaceOrientations~ipad"],
            [
                "UIInterfaceOrientationPortrait",
                "UIInterfaceOrientationPortraitUpsideDown",
                "UIInterfaceOrientationLandscapeLeft",
                "UIInterfaceOrientationLandscapeRight",
            ],
        )
        self.assertNotIn("UIRequiresFullScreen", info)

    def test_flutter_startup_does_not_override_native_orientation(self) -> None:
        main_source = (ROOT / "lib" / "main.dart").read_text(encoding="utf-8")
        self.assertNotIn("setPreferredOrientations", main_source)


if __name__ == "__main__":
    unittest.main()
