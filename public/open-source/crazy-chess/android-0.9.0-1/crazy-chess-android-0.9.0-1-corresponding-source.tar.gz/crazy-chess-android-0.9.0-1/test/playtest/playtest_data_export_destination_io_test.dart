import 'dart:io';
import 'dart:typed_data';

import 'package:crazy_chess/playtest/playtest_data_export_destination_io.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test(
    'native destination writes atomically and preserves existing exports',
    () async {
      final downloads = await Directory.systemTemp.createTemp(
        'playtest-downloads-',
      );
      addTearDown(() async {
        if (await downloads.exists()) await downloads.delete(recursive: true);
      });
      final destination = IoPlaytestExportDestination(
        downloadsDirectoryProvider: () async => downloads,
      );
      final bytes = Uint8List.fromList(<int>[80, 75, 3, 4]);

      final first = await destination.write(
        fileName: 'bundle.zip',
        bytes: bytes,
      );
      final second = await destination.write(
        fileName: 'bundle.zip',
        bytes: bytes,
      );

      expect(first, '${downloads.path}/bundle.zip');
      expect(second, '${downloads.path}/bundle-2.zip');
      expect(await File(first).readAsBytes(), bytes);
      expect(await File(second).readAsBytes(), bytes);
      expect(
        await downloads
            .list()
            .where((entity) => entity.path.endsWith('.tmp'))
            .toList(),
        isEmpty,
      );
    },
  );
}
