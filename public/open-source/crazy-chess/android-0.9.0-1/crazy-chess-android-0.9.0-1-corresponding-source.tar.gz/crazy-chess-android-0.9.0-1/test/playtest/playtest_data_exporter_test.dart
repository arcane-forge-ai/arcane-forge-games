import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store_io.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_metrics.dart';
import 'package:crazy_chess/playtest/playtest_data_exporter.dart';
import 'package:crazy_chess/playtest/playtest_diagnostics.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemoryDestination implements PlaytestExportDestination {
  String? fileName;
  Uint8List? bytes;

  @override
  Future<String> write({
    required String fileName,
    required Uint8List bytes,
  }) async {
    this.fileName = fileName;
    this.bytes = bytes;
    return '/Downloads/$fileName';
  }
}

void main() {
  test(
    'export joins runs and metrics, adds logs, and excludes binary data',
    () async {
      const secret = 'preview-secret-123';
      final root = await Directory.systemTemp.createTemp('playtest-export-');
      addTearDown(() async {
        if (await root.exists()) await root.delete(recursive: true);
      });
      final archiveStore = IoLivingCampaignArchiveStore(
        rootProvider: () async => root,
      );
      final now = DateTime(2026, 8, 17, 14, 22, 3);
      final source = LivingCampaignFixedOpener.create(
        runId: 'run_export',
        now: now,
      ).copyWith(campaignTitle: 'Secret marker $secret');
      await archiveStore.writeRun(source);
      await archiveStore.writeTimingMetrics(
        LivingCampaignRunTimingMetrics.empty(
          runId: source.runId,
          now: now,
        ).recordElapsed(
          elapsed: const Duration(minutes: 7),
          bucket: LivingCampaignTimingBucket.battleActive,
          chapterNumber: 1,
          at: now.add(const Duration(minutes: 7)),
        ),
      );
      await archiveStore.writeBinary(
        runId: source.runId,
        fileName: 'portrait.webp',
        bytes: Uint8List.fromList(<int>[1, 2, 3, 4]),
      );
      final diagnostics = MemoryPlaytestDiagnostics(now: () => now);
      diagnostics.record(
        'test_error',
        message: 'apiKey=$secret at /Users/alice/CrazyChess',
      );
      final destination = _MemoryDestination();
      final exporter = PlaytestDataExporter(
        archive: archiveStore,
        diagnostics: diagnostics,
        destination: destination,
        now: () => now,
        secretsProvider: () => const <String>[secret],
      );

      final result = await exporter.export();

      expect(result.runCount, 1);
      expect(result.metricsCount, 1);
      expect(result.diagnosticFileCount, 1);
      expect(result.fileName, 'crazy-chess-playtest-data-20260817-142203.zip');
      expect(result.filePath, '/Downloads/${result.fileName}');

      final decoded = ZipDecoder().decodeBytes(destination.bytes!);
      final names = decoded.files.map((file) => file.name).toSet();
      expect(names, contains('manifest.json'));
      expect(names, contains('runs/run_export.json'));
      expect(names, contains('metrics/run_export.json'));
      expect(names, contains('diagnostics/session-memory.jsonl'));
      expect(names.any((name) => name.contains('portrait')), isFalse);

      final manifest = _jsonFile(decoded, 'manifest.json');
      expect((manifest['runs']! as Map)['count'], 1);
      expect((manifest['metrics']! as Map)['count'], 1);
      expect((manifest['privacy']! as Map)['credentialsIncluded'], isFalse);
      expect((manifest['privacy']! as Map)['portraitsIncluded'], isFalse);

      final exportedRun = _textFile(decoded, 'runs/run_export.json');
      final exportedLog = _textFile(
        decoded,
        'diagnostics/session-memory.jsonl',
      );
      expect(exportedRun, isNot(contains(secret)));
      expect(exportedRun, contains('[REDACTED]'));
      expect(exportedLog, isNot(contains(secret)));
      expect(exportedLog, contains('/Users/<redacted>/CrazyChess'));
    },
  );
}

Map<String, Object?> _jsonFile(Archive archive, String name) =>
    Map<String, Object?>.from(jsonDecode(_textFile(archive, name)) as Map);

String _textFile(Archive archive, String name) {
  final file = archive.files.singleWhere((entry) => entry.name == name);
  return utf8.decode(file.content);
}
