import 'dart:convert';
import 'dart:io';

import 'package:crazy_chess/playtest/playtest_diagnostics_io.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('native diagnostics writes bounded redacted JSONL snapshots', () async {
    final root = await Directory.systemTemp.createTemp('playtest-diagnostics-');
    addTearDown(() async {
      if (await root.exists()) await root.delete(recursive: true);
    });
    final logger = IoPlaytestDiagnostics(
      rootProvider: () async => root,
      now: () => DateTime.utc(2026, 8, 17, 15, 0),
      maxFiles: 2,
      maxFileBytes: 1024,
    );

    logger.record(
      'platform_error',
      message: 'authorization=Bearer abc123 /Users/tester/game.dart',
      data: const <String, Object?>{'apiKey': 'raw-secret', 'inputTokens': 42},
    );
    await logger.flush();
    final snapshots = await logger.snapshotFiles();

    expect(snapshots, hasLength(1));
    final text = utf8.decode(snapshots.single.bytes);
    final entry = jsonDecode(text.trim()) as Map<String, Object?>;
    expect(entry['event'], 'platform_error');
    expect(text, isNot(contains('abc123')));
    expect(text, isNot(contains('raw-secret')));
    expect(text, isNot(contains('/Users/tester')));
    expect(text, contains('/Users/<redacted>'));
    expect(text, contains('"inputTokens":42'));
  });
}
