import 'dart:convert';
import 'dart:io';

import 'package:crazy_chess/app/app_locale_controller.dart';
import 'package:crazy_chess/app/theme.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/last_piece/last_piece_catalog.dart';
import 'package:crazy_chess/l10n/localized_message.dart';
import 'package:crazy_chess/l10n/runtime_game_locale.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store_io.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_demo_gateway.dart';
import 'package:crazy_chess/living_campaign/living_campaign_locale_contract.dart';
import 'package:crazy_chess/living_campaign/living_campaign_migrations.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_v2_backend.dart';
import 'package:crazy_chess/living_campaign/living_campaign_v2_schemas.dart';
import 'package:crazy_chess/story/story_catalog.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  tearDown(() => RuntimeGameLocale.setLocale(const Locale('en')));

  group('application locale', () {
    test(
      'fresh installs default to English regardless of system locale',
      () async {
        final controller = AppLocaleController(
          store: MemoryAppLanguagePreferenceStore(),
        );
        addTearDown(controller.dispose);

        await controller.load();

        expect(controller.preference, AppLanguagePreference.english);
        expect(
          controller.effectiveLocale(const <Locale>[Locale('zh', 'CN')]),
          AppLocaleController.englishLocale,
        );
      },
    );

    test(
      'an explicitly saved system preference still follows the system',
      () async {
        final controller = AppLocaleController(
          store: MemoryAppLanguagePreferenceStore('system'),
        );
        addTearDown(controller.dispose);

        await controller.load();

        expect(controller.preference, AppLanguagePreference.system);
        expect(
          controller.effectiveLocale(const <Locale>[Locale('zh', 'CN')]),
          AppLocaleController.simplifiedChineseLocale,
        );
      },
    );

    test('resolves only supported Simplified Chinese system locales', () {
      expect(
        AppLocaleController.resolveSystemLocales(const <Locale>[
          Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hans'),
        ]),
        AppLocaleController.simplifiedChineseLocale,
      );
      expect(
        AppLocaleController.resolveSystemLocales(const <Locale>[
          Locale('zh', 'CN'),
        ]),
        AppLocaleController.simplifiedChineseLocale,
      );
      expect(
        AppLocaleController.resolveSystemLocales(const <Locale>[
          Locale('zh', 'SG'),
        ]),
        AppLocaleController.simplifiedChineseLocale,
      );
      expect(
        AppLocaleController.resolveSystemLocales(const <Locale>[
          Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hant'),
          Locale('en'),
        ]),
        AppLocaleController.englishLocale,
      );
      expect(
        AppLocaleController.resolveSystemLocales(const <Locale>[
          Locale('zh', 'TW'),
        ]),
        AppLocaleController.englishLocale,
      );
    });

    test(
      'loads and persists a saved override that wins over the system',
      () async {
        final store = MemoryAppLanguagePreferenceStore('zh-Hans');
        final controller = AppLocaleController(store: store);
        addTearDown(controller.dispose);

        await controller.load();
        expect(
          controller.effectiveLocale(const <Locale>[Locale('en')]),
          AppLocaleController.simplifiedChineseLocale,
        );

        await controller.setPreference(AppLanguagePreference.english);
        expect(store.value, 'en');
        expect(
          controller.effectiveLocale(const <Locale>[Locale('zh', 'CN')]),
          AppLocaleController.englishLocale,
        );
      },
    );

    test('selects Noto Sans SC and Chinese text metrics for Chinese', () {
      final english = buildCrazyChessTheme();
      final chinese = buildCrazyChessTheme(
        locale: AppLocaleController.simplifiedChineseLocale,
      );

      expect(english.textTheme.bodyMedium!.fontFamily, 'Avenir Next');
      expect(chinese.textTheme.bodyMedium!.fontFamily, 'Noto Sans SC');
      expect(chinese.textTheme.bodyMedium!.height, 1.45);
      expect(chinese.textTheme.bodyMedium!.letterSpacing, 0);
    });
  });

  group('checked-in localization data', () {
    test('English and zh-Hans ARBs have identical complete message keys', () {
      final english = _jsonFile('lib/l10n/app_en.arb');
      final chinese = _jsonFile('lib/l10n/app_zh_Hans.arb');
      final englishKeys = english.keys
          .where((key) => !key.startsWith('@'))
          .toSet();
      final chineseKeys = chinese.keys
          .where((key) => !key.startsWith('@'))
          .toSet();

      expect(chineseKeys, englishKeys);
      for (final key in chineseKeys) {
        expect((chinese[key]! as String).trim(), isNotEmpty, reason: key);
      }
    });

    test('Story overlay has exact ID parity and all 196 dialogue lines', () {
      final source = _jsonFile(StoryCatalog.assetPath);
      final overlay = _jsonFile(StoryCatalog.simplifiedChineseOverlayAssetPath);
      final sourceCharacters = (source['characters']! as List<Object?>)
          .cast<Map<String, Object?>>();
      final sourceMissions = (source['missions']! as List<Object?>)
          .cast<Map<String, Object?>>();
      final sourceLines = (source['scenes']! as List<Object?>)
          .cast<Map<String, Object?>>()
          .expand(
            (scene) =>
                (scene['lines']! as List<Object?>).cast<Map<String, Object?>>(),
          )
          .toList();
      final characterCopy = (overlay['characters']! as Map<String, Object?>);
      final missionCopy = (overlay['missions']! as Map<String, Object?>);
      final dialogueCopy = (overlay['dialogue']! as Map<String, Object?>);

      expect(
        characterCopy.keys.toSet(),
        sourceCharacters.map((item) => item['id']! as String).toSet(),
      );
      expect(
        missionCopy.keys.toSet(),
        sourceMissions.map((item) => item['id']! as String).toSet(),
      );
      expect(sourceLines, hasLength(196));
      expect(dialogueCopy, hasLength(196));
      expect(
        dialogueCopy.keys.toSet(),
        sourceLines.map((item) => item['id']! as String).toSet(),
      );

      final catalog = StoryCatalog.fromJsonString(
        File(StoryCatalog.assetPath).readAsStringSync(),
        overlaySource: File(
          StoryCatalog.simplifiedChineseOverlayAssetPath,
        ).readAsStringSync(),
      );
      expect(catalog.campaign.title, contains('王冠'));
      expect(catalog.campaign.scenes.first.lines.first.text, contains('西门'));
    });

    test('Last Piece overlay has exact ID parity', () {
      final source = _jsonFile('assets/data/last_piece_levels.v1.json');
      final overlay = _jsonFile(
        'assets/data/last_piece_levels.zh-Hans.v1.json',
      );
      final sourceLevels = (source['levels']! as List<Object?>)
          .cast<Map<String, Object?>>();
      final localizedLevels = overlay['levels']! as Map<String, Object?>;

      expect(
        localizedLevels.keys.toSet(),
        sourceLevels.map((level) => level['id']! as String).toSet(),
      );
      final catalog = LastPieceLevelCatalog.fromJsonString(
        File('assets/data/last_piece_levels.v1.json').readAsStringSync(),
        overlaySource: File(
          'assets/data/last_piece_levels.zh-Hans.v1.json',
        ).readAsStringSync(),
      );
      expect(catalog.byId('001').title, '初次合围');
    });
  });

  group('localized gameplay records', () {
    test('preserves an English diagnostic while resolving Chinese copy', () {
      const diagnostic = 'White Knight moved b1 to c3.';
      final record = LocalizedMessageRecord.fromEnglish(diagnostic);

      expect(record.debugEnglish, diagnostic);
      expect(record.resolve(), diagnostic);

      RuntimeGameLocale.setLocale(AppLocaleController.simplifiedChineseLocale);
      expect(record.resolve(), '白方马从 b1 移动至 c3。');
    });
  });

  group('Living Campaign content locale', () {
    test('V4 archives and provenance migrate deterministically to English', () {
      final now = DateTime.utc(2026, 8, 16);
      final record = LivingGenerationRecord(
        recordId: 'record-1',
        stage: LivingGenerationStage.chronicler,
        attempt: 1,
        status: LivingGenerationStatus.completed,
        model: 'fixture-model',
        startedAt: now,
        finishedAt: now,
        requestPayload: const <String, Object?>{'prompt': 'legacy'},
        responsePayload: const <String, Object?>{'title': 'Legacy'},
        inputTokens: 12,
      );
      final source = LivingCampaignFixedOpener.create(
        runId: 'legacy-v4',
        now: now,
      ).copyWith(generationRecords: <LivingGenerationRecord>[record]).toJson();
      source['schemaVersion'] = 4;
      source.remove('contentLocale');
      for (final value in source['generationRecords']! as List<Object?>) {
        (value! as Map<String, Object?>).remove('contentLocale');
      }

      final migrated = LivingCampaignRunCodec.decode(source);

      expect(migrated.schemaVersion, 5);
      expect(migrated.contentLocale, LivingContentLocale.english);
      expect(migrated.generationRecords.single.contentLocale, 'en');
      expect(migrated.campaignTitle, LivingCampaignFixedOpener.campaignTitle);
    });

    test('new Chinese runs pin localized prose and stable mechanics', () {
      final english = LivingCampaignFixedOpener.create(
        runId: 'english',
        now: DateTime.utc(2026, 8, 16),
      );
      final chinese = LivingCampaignFixedOpener.create(
        runId: 'chinese',
        now: DateTime.utc(2026, 8, 16),
        contentLocale: LivingContentLocale.simplifiedChinese,
      );

      expect(chinese.contentLocale, LivingContentLocale.simplifiedChinese);
      expect(chinese.campaignTitle, contains('王冠'));
      expect(chinese.prologue, contains('王庭'));
      expect(
        chinese.chapterPackages.single.pieces.map((piece) => piece.toJson()),
        english.chapterPackages.single.pieces.map((piece) => piece.toJson()),
      );
      expect(
        chinese.chapterPackages.single.objective.type,
        english.chapterPackages.single.objective.type,
      );
    });

    test('Chinese prompt contract and response validator enforce prose', () {
      final prompt = LivingCampaignLocaleContract.append(
        'Generate JSON.',
        LivingContentLocale.simplifiedChinese,
      );
      expect(prompt, contains('contentLocale is `zh-Hans`'));
      expect(prompt, contains('JSON keys'));
      expect(prompt, contains('a4'));

      expect(
        LivingChineseContentValidator.validateResponse(const <String, Object?>{
          'title': 'English only',
        }, LivingContentLocale.simplifiedChinese),
        isNotEmpty,
      );
      expect(
        LivingChineseContentValidator.validateResponse(const <String, Object?>{
          'title': '灰烬之后',
        }, LivingContentLocale.simplifiedChinese),
        isEmpty,
      );
    });

    test(
      'deterministic gateway returns validator-clean Chinese fixtures',
      () async {
        final gateway = LivingCampaignDemoGateway(responseDelay: Duration.zero);
        final prologue = await gateway.chatJson(
          systemPrompt: LivingCampaignLocaleContract.append(
            'Generate prologue JSON.',
            LivingContentLocale.simplifiedChinese,
          ),
          userPayload: const <String, Object?>{
            'initialCanon': <String, Object?>{},
          },
        );
        expect(prologue.value['campaignTitle'], contains('王冠'));
        expect(
          LivingChineseContentValidator.validateResponse(
            prologue.value,
            LivingContentLocale.simplifiedChinese,
          ),
          isEmpty,
        );

        final director = await gateway.chatJson(
          systemPrompt: LivingCampaignLocaleContract.append(
            'Generate director JSON.',
            LivingContentLocale.simplifiedChinese,
          ),
          userPayload: const <String, Object?>{
            'runId': 'fixture-zh',
            'basedOnMissionNumber': 1,
            'nextMissionNumber': 2,
            'eligibleAllies': <Object?>[
              <String, Object?>{'characterId': 'char_ysra'},
            ],
          },
          jsonSchemaName: LivingCampaignV2Schemas.directorName,
        );
        expect(director.value['title'], '灰烬钟鸣');
        expect(
          LivingChineseContentValidator.validateResponse(
            director.value,
            LivingContentLocale.simplifiedChinese,
          ),
          isEmpty,
        );
      },
    );

    test(
      'deterministic Chinese Chronicler fixture is accepted end to end',
      () async {
        final temp = await Directory.systemTemp.createTemp(
          'living-chinese-closure-',
        );
        addTearDown(() => temp.delete(recursive: true));
        final archive = IoLivingCampaignArchiveStore(
          rootProvider: () async => temp,
        );
        final now = DateTime.utc(2026, 8, 16);
        final run = LivingCampaignFixedOpener.create(
          runId: 'fixture-zh-closure',
          now: now,
          contentLocale: LivingContentLocale.simplifiedChinese,
        );
        final outcome = LivingBattleOutcomeSnapshot(
          chapterNumber: 1,
          chapterId: 'living_m01',
          result: LivingBattleResult.victory,
          endReason: GameEndReason.checkmate,
          objectiveType: run.chapterPackages.first.objective.type,
          objectiveCompleted: true,
          completedTurns: 12,
          goldBefore: 10,
          goldAfterBattle: 12,
          survivingPieceIds: const <String>[
            'ashen_rook_ysra',
            'ashen_bishop_veyl',
            'ashen_king_orsain',
            'ashen_knight_cael',
          ],
          capturedPieces: const <LivingCapturedPieceOutcome>[],
          purchasedPieceIds: const <String>[],
          missionRoleChanges: const <String, PieceType>{},
          matchLog: const <String>['灰烬王庭在十二个行动后取得胜利。'],
        );
        final backend = LivingCampaignV2Backend(
          gateway: LivingCampaignDemoGateway(responseDelay: Duration.zero),
          archive: archive,
          generatePortraits: false,
          customContextTokens: 256000,
          persistenceDomain: LivingCampaignPersistenceDomain.closureText,
        );

        final result = await backend.generateChapterClosureText(
          run: run,
          outcome: outcome,
        );

        expect(
          result.completed,
          isTrue,
          reason: result.run.generationRecords
              .expand((record) => record.validationIssues)
              .join('\n'),
        );
        expect(result.run.missionMemories.single.battleSummary, contains('战斗'));
        expect(
          result.run.aftermathScenesByChapterId['living_m01']!.lines,
          isNotEmpty,
        );
      },
    );
  });
}

Map<String, Object?> _jsonFile(String path) =>
    jsonDecode(File(path).readAsStringSync()) as Map<String, Object?>;
