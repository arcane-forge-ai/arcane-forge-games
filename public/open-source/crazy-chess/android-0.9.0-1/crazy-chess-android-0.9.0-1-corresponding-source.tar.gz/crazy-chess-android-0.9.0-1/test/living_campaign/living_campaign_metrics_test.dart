import 'package:crazy_chess/living_campaign/living_campaign_metrics.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('run and chapter metrics accumulate exact foreground buckets', () {
    final startedAt = DateTime.utc(2026, 8, 17, 8);
    final metrics =
        LivingCampaignRunTimingMetrics.empty(
              runId: 'run-metrics',
              now: startedAt,
            )
            .markChapterOpened(chapterNumber: 1, at: startedAt)
            .recordElapsed(
              elapsed: const Duration(seconds: 12),
              bucket: LivingCampaignTimingBucket.narrativeReading,
              chapterNumber: 1,
              at: startedAt.add(const Duration(seconds: 12)),
            )
            .recordElapsed(
              elapsed: const Duration(seconds: 30),
              bucket: LivingCampaignTimingBucket.battleActive,
              chapterNumber: 1,
              at: startedAt.add(const Duration(seconds: 42)),
            )
            .recordElapsed(
              elapsed: const Duration(seconds: 4),
              bucket: null,
              chapterNumber: 1,
              at: startedAt.add(const Duration(seconds: 46)),
            );

    expect(metrics.foregroundActiveMs, 46000);
    expect(metrics.narrativeReadingMs, 12000);
    expect(metrics.battleActiveMs, 30000);
    expect(metrics.categorizedActiveMs, 42000);
    expect(metrics.chapters[1]!.foregroundActiveMs, 46000);
    expect(metrics.chapters[1]!.firstOpenedAt, startedAt);
  });

  test(
    'timing metrics JSON round-trips and defaults missing fields to zero',
    () {
      final now = DateTime.utc(2026, 8, 17, 9);
      final source =
          LivingCampaignRunTimingMetrics.empty(
            runId: 'run-codec',
            now: now,
          ).recordElapsed(
            elapsed: const Duration(milliseconds: 2500),
            bucket: LivingCampaignTimingBucket.aiWait,
            chapterNumber: 2,
            at: now.add(const Duration(milliseconds: 2500)),
          );

      final decoded = LivingCampaignRunTimingMetrics.fromJson(source.toJson());
      expect(decoded.toJson(), source.toJson());

      final legacy = LivingCampaignRunTimingMetrics.fromJson(<String, Object?>{
        'runId': 'legacy-run',
        'createdAt': now.toIso8601String(),
        'chapters': <String, Object?>{},
      });
      expect(legacy.schemaVersion, 1);
      expect(legacy.foregroundActiveMs, 0);
      expect(legacy.chapters, isEmpty);
    },
  );
}
