@Tags(<String>['live'])
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:crazy_chess/battlefield/battlefield_models.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store_io.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_prompt_library.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:crazy_chess/living_campaign/living_campaign_v2_backend.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;

const _runLive = bool.fromEnvironment('RUN_LIVING_CAMPAIGN_V2_SEEDREAM_TEST');
const _apiKey = String.fromEnvironment('ARK_API_KEY');
const _baseUrl = String.fromEnvironment(
  'ARK_BASE_URL',
  defaultValue: LivingCampaignSettings.defaultBaseUrl,
);
const _textModel = String.fromEnvironment(
  'LIVING_CAMPAIGN_TEXT_MODEL',
  defaultValue: LivingCampaignSettings.defaultTextModel,
);
const _imageModel = String.fromEnvironment(
  'LIVING_CAMPAIGN_IMAGE_MODEL',
  defaultValue: LivingCampaignSettings.defaultImageModel,
);
const _outputRoot = String.fromEnvironment(
  'LIVING_CAMPAIGN_V2_SEEDREAM_OUTPUT',
);
const _json = JsonEncoder.withIndent('  ');

void main() {
  test(
    'one Seedream call passes the production V2 portrait path',
    () async {
      expect(_apiKey, isNotEmpty, reason: 'ARK_API_KEY was not injected.');
      expect(
        _outputRoot,
        isNotEmpty,
        reason: 'A unique LIVING_CAMPAIGN_V2_SEEDREAM_OUTPUT is required.',
      );
      final output = _validatedOutputDirectory(_outputRoot);
      expect(
        await output.exists(),
        isFalse,
        reason: 'Seedream evidence directories are one-shot. Use a new path.',
      );
      await output.create(recursive: true);
      final startedAt = DateTime.now().toUtc();
      await _writeJson(
        File(p.join(output.path, 'attempt-started.json')),
        <String, Object?>{
          'kind': 'living-campaign-v2-seedream-runtime-test',
          'authorizedRealSeedreamCalls': 1,
          'paidTextCalls': 0,
          'automaticRetries': false,
          'imageModel': _imageModel,
          'startedAt': startedAt.toIso8601String(),
        },
      );

      final archiveRoot = Directory(p.join(output.path, 'archive'));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => archiveRoot,
      );
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: _apiKey,
          baseUrl: _baseUrl,
          textModel: _textModel,
          imageModel: _imageModel,
        ),
      );
      final run = LivingCampaignFixedOpener.create(
        runId: 'seedream-runtime-evidence',
        now: startedAt,
      );
      final outcome = _outcome(run);
      final gateway = _SeedreamTestGateway(
        real: DoubaoLivingCampaignV2Gateway(
          client,
          loadPortraitStyleReferences: _loadStyleReferences,
        ),
        textResponses: <Map<String, Object?>>[
          _memory(run.runId),
          _director(run.runId),
          _builder(run.runId),
        ],
      );
      final backend = LivingCampaignV2Backend(
        gateway: gateway,
        archive: archive,
        promptLibrary: const _FilePromptLibrary(),
      );

      Map<String, Object?> report;
      var detailedReportWritten = false;
      try {
        final result = await backend.generateNextChapter(
          run: run,
          outcome: outcome,
        );
        final checkpoint = result
            .run
            .portraitCheckpointsByCharacterId['char_seedream_watcher'];
        final failures = <String>[
          if (!result.completed)
            result.message ?? 'Generation did not complete.',
          if (gateway.portraitCalls != 1)
            'Expected exactly one Seedream call; saw ${gateway.portraitCalls}.',
          if (gateway.fakeTextCalls != 3)
            'Expected three deterministic fake text stages.',
          if (checkpoint == null) 'Portrait checkpoint was not persisted.',
          if (checkpoint != null &&
              checkpoint.status != LivingPortraitStatus.ready)
            'Portrait checkpoint ended as ${checkpoint.status.name}.',
          if (checkpoint?.sourceReference == null)
            'Provider source was not archived.',
          if (checkpoint?.processedReference == null)
            'Processed portrait was not archived.',
        ];
        Uint8List? processed;
        Uint8List? source;
        if (checkpoint?.processedReference != null) {
          processed = await archive.readBinary(checkpoint!.processedReference!);
        }
        if (checkpoint?.sourceReference != null) {
          source = await archive.readBinary(checkpoint!.sourceReference!);
        }
        if (processed == null || processed.isEmpty) {
          failures.add('Processed portrait bytes are missing.');
        } else {
          final codec = await ui.instantiateImageCodec(processed);
          final frame = await codec.getNextFrame();
          if (frame.image.width < 512 || frame.image.height < 512) {
            failures.add('Flutter decoded a portrait smaller than 512 px.');
          }
          frame.image.dispose();
          codec.dispose();
        }
        if (source == null || source.isEmpty) {
          failures.add('Provider source bytes are missing.');
        }
        final reloaded = await archive.readRun(run.runId);
        final reloadedCheckpoint =
            reloaded?.portraitCheckpointsByCharacterId['char_seedream_watcher'];
        if (reloadedCheckpoint?.status != LivingPortraitStatus.ready) {
          failures.add('Reload persistence did not preserve ready portrait.');
        }
        await _writeJson(
          File(p.join(output.path, 'initial-fixture.json')),
          run.toJson(),
        );
        await _writeJson(
          File(p.join(output.path, 'synthetic-outcome.json')),
          outcome.toJson(),
        );
        await _writeJson(
          File(p.join(output.path, 'final-run.json')),
          result.run.toJson(),
        );
        final portraitRecord = result.run.generationRecords
            .where((record) => record.stage == LivingGenerationStage.portrait)
            .lastOrNull;
        final secretLeaks = await _findSecretLeaks(output, _apiKey);
        if (secretLeaks.isNotEmpty) {
          failures.add('Secret leakage detected in ${secretLeaks.join(', ')}.');
        }
        final finishedAt = DateTime.now().toUtc();
        report = <String, Object?>{
          'kind': 'living-campaign-v2-seedream-runtime-test-report',
          'passed': failures.isEmpty,
          'startedAt': startedAt.toIso8601String(),
          'finishedAt': finishedAt.toIso8601String(),
          'durationMs': finishedAt.difference(startedAt).inMilliseconds,
          'imageModel': _imageModel,
          'paidTextCalls': 0,
          'realSeedreamCalls': gateway.portraitCalls,
          'fakeTextStages': gateway.fakeTextCalls,
          'automaticRetries': false,
          'requestId': portraitRecord?.providerRequestId,
          'seed': checkpoint?.seed,
          'promptAsset': checkpoint?.promptAsset,
          'styleReferenceHashes': checkpoint?.referenceHashes ?? const [],
          'sourceReference': checkpoint?.sourceReference,
          'processedReference': checkpoint?.processedReference,
          'checkpointStatus': checkpoint?.status.name,
          'errorCode': checkpoint?.errorCode,
          'errorMessage': checkpoint?.errorMessage,
          if (source != null) 'sourceSha256': sha256.convert(source).toString(),
          if (processed != null)
            'processedSha256': sha256.convert(processed).toString(),
          'reloadPersisted': reloadedCheckpoint != null,
          'reloadCheckpointStatus': reloadedCheckpoint?.status.name,
          'secretLeakFiles': secretLeaks,
          'failures': failures,
        };
        await _writeReports(output, report);
        detailedReportWritten = true;
        expect(
          failures,
          isEmpty,
          reason: 'Review ${p.join(output.path, 'report.html')}',
        );
      } on Object catch (error, stackTrace) {
        if (detailedReportWritten) {
          rethrow;
        }
        final finishedAt = DateTime.now().toUtc();
        report = <String, Object?>{
          'kind': 'living-campaign-v2-seedream-runtime-test-report',
          'passed': false,
          'startedAt': startedAt.toIso8601String(),
          'finishedAt': finishedAt.toIso8601String(),
          'durationMs': finishedAt.difference(startedAt).inMilliseconds,
          'imageModel': _imageModel,
          'paidTextCalls': 0,
          'realSeedreamCalls': gateway.portraitCalls,
          'automaticRetries': false,
          'failures': <String>['$error'],
          'stackTrace': '$stackTrace',
        };
        await _writeReports(output, report);
        rethrow;
      } finally {
        client.close();
      }
    },
    skip: !_runLive,
    timeout: const Timeout(Duration(minutes: 7)),
  );
}

class _FilePromptLibrary implements LivingCampaignPromptLibrary {
  const _FilePromptLibrary();

  @override
  Future<String> load(LivingCampaignPrompt prompt) async {
    final source = (await File(prompt.assetPath).readAsString()).trim();
    if (source.isEmpty) {
      throw StateError('Living Campaign prompt is blank: ${prompt.assetPath}');
    }
    return source;
  }
}

class _SeedreamTestGateway implements LivingCampaignV2Gateway {
  _SeedreamTestGateway({required this.real, required this.textResponses});

  final DoubaoLivingCampaignV2Gateway real;
  final List<Map<String, Object?>> textResponses;
  int fakeTextCalls = 0;
  int portraitCalls = 0;

  @override
  String get textModel => real.textModel;

  @override
  String get imageModel => real.imageModel;

  @override
  Future<DoubaoTokenizationResult> countTextTokens(
    Iterable<String> values,
  ) async => DoubaoTokenizationResult(
    totalTokens: values.fold<int>(0, (sum, value) => sum + value.length ~/ 2),
    requestId: 'fake-token-count',
    model: textModel,
  );

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    required Map<String, Object?> jsonSchema,
    required String jsonSchemaName,
    required int maxTokens,
    required double temperature,
    DoubaoStreamProgressCallback? onProgress,
  }) async {
    fakeTextCalls++;
    final value = textResponses.removeAt(0);
    return DoubaoJsonResponse(
      value: value,
      requestId: 'fake-text-$fakeTextCalls',
      model: textModel,
      usage: const <String, Object?>{},
      redactedRawResponse: 'fake deterministic text stage',
      rawContent: jsonEncode(value),
      finishReason: 'stop',
    );
  }

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) {
    portraitCalls++;
    return real.generatePortrait(
      prompt: prompt,
      seed: seed,
      referenceImages: referenceImages,
      onSourceDownloaded: onSourceDownloaded,
    );
  }

  @override
  Future<DoubaoChapterArtResult> generateChapterEndingArt({
    required String prompt,
    required int seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) => real.generateChapterEndingArt(
    prompt: prompt,
    seed: seed,
    referenceImages: referenceImages,
    onSourceDownloaded: onSourceDownloaded,
  );

  @override
  Future<List<Uint8List>> loadPortraitStyleReferences() =>
      real.loadPortraitStyleReferences();
}

Future<List<Uint8List>> _loadStyleReferences() async {
  const paths = <String>[
    'assets/runtime/pieces/characters/living/orsain_half_body.webp',
    'assets/runtime/pieces/characters/living/ysra_half_body.webp',
    'assets/runtime/pieces/characters/living/veyl_half_body.webp',
    'assets/runtime/pieces/characters/living/cael_half_body.webp',
  ];
  return Future.wait(paths.map((path) => File(path).readAsBytes()));
}

LivingBattleOutcomeSnapshot _outcome(LivingCampaignRun run) =>
    LivingBattleOutcomeSnapshot(
      chapterNumber: 1,
      chapterId: 'living_m01',
      result: LivingBattleResult.victory,
      endReason: GameEndReason.checkmate,
      objectiveType: run.chapterPackages.first.objective.type,
      objectiveCompleted: true,
      completedTurns: 14,
      goldBefore: 10,
      goldAfterBattle: 12,
      survivingPieceIds: const <String>[
        'ashen_rook_ysra',
        'ashen_bishop_veyl',
        'ashen_king_orsain',
        'ashen_knight_cael',
      ],
      capturedPieces: const <LivingCapturedPieceOutcome>[],
      purchasedPieceIds: const <String>[],
      missionRoleChanges: const <String, PieceType>{},
      matchLog: const <String>[
        'Turn 4: Ysra secured the western causeway.',
        'Turn 14: Orsain checkmated the rival King.',
      ],
    );

Map<String, Object?> _memory(String runId) => <String, Object?>{
  'schemaVersion': 2,
  'runId': runId,
  'missionNumber': 1,
  'missionId': 'living_m01',
  'setupSummary':
      'The Ashen Court faced a rival claimant on the Ruined Causeway and chose to clear the road without slaughter.',
  'battleSummary':
      'Orsain won the crossing with every advanced ally alive and carried the unfinished crown onward.',
  'characterIds': <String>[
    'char_orsain',
    'char_ysra',
    'char_veyl',
    'char_cael',
  ],
  'keyEventIds': <String>['living_m01_result'],
};

Map<String, Object?> _director(String runId) => <String, Object?>{
  'schemaVersion': 2,
  'runId': runId,
  'basedOnMissionNumber': 1,
  'nextMissionNumber': 2,
  'title': 'The Watcher at the Ash Gate',
  'subtitle': 'A closed helm watches the road beyond the fire.',
  'background':
      'Beyond the causeway, a solitary gate commander bars the Ashen Court from the next valley.',
  'dialogue': <Object?>[
    <String, Object?>{
      'lineId': 'm02_line_01',
      'speakerId': 'char_seedream_watcher',
      'side': 'left',
      'text': 'The gate opens only for a crown that can defend its name.',
    },
    <String, Object?>{
      'lineId': 'm02_line_02',
      'speakerId': 'char_orsain',
      'side': 'right',
      'text': 'Then test the court, not the ashes behind it.',
    },
  ],
  'objectiveType': 'surviveRounds',
  'objectiveLabel': 'Hold the Ash Gate for six completed actions',
  'surviveRounds': 6,
  'participantCharacterIds': <String>[
    'char_orsain',
    'char_ysra',
    'char_veyl',
    'char_cael',
  ],
  'enemyNamedCharacterIds': <String>['char_seedream_watcher'],
  'statusChanges': <Object?>[],
  'newCharacter': <String, Object?>{
    'name': 'The Ash Gate Watcher',
    'characterId': 'char_seedream_watcher',
    'pieceId': 'piece_seedream_watcher',
    'pieceType': 'rook',
    'status': 'enemy',
    'recruitable': false,
    'description': 'A disciplined gate commander whose allegiance is unknown.',
    'loyalty': 72,
    'portraitPrompt':
        'An original adult Rook commander in layered ash-black plate and tarnished bronze, closed rectangular helm with a narrow blue-gray eye slit, broad defensive silhouette, restrained rust-red sash, no heraldry, holding a short tower shield low enough to keep the face area unobstructed.',
  },
  'pressureTier': 'pressured',
  'rewardTier': 20,
  'finaleKind': 'none',
  'campaignComplete': false,
};

Map<String, Object?> _builder(String runId) => <String, Object?>{
  'schemaVersion': 2,
  'runId': runId,
  'missionNumber': 2,
  'blackCountryId': 'iron',
  'startingTurn': 'white',
  'battlefieldId': BattlefieldId.ruinedCauseway.name,
  'seed': 2202,
  'blackGold': 16,
  'merchantSpeed': 4,
  'enemyPieces': <Object?>[
    <String, Object?>{
      'pieceId': 'm02_enemy_king',
      'pieceType': 'king',
      'color': 'black',
      'square': 'e8',
      'countryId': 'iron',
    },
    <String, Object?>{
      'pieceId': 'piece_seedream_watcher',
      'pieceType': 'rook',
      'color': 'black',
      'square': 'a7',
      'countryId': 'iron',
      'loyalty': 72,
      'fairPrice': 22,
      'characterId': 'char_seedream_watcher',
    },
    <String, Object?>{
      'pieceId': 'm02_enemy_pawn',
      'pieceType': 'pawn',
      'color': 'black',
      'square': 'd6',
      'countryId': 'iron',
      'loyalty': 60,
      'fairPrice': 6,
    },
  ],
};

Directory _validatedOutputDirectory(String raw) {
  final normalized = p.normalize(p.absolute(raw));
  final testResult = p.normalize(p.absolute('test_result'));
  if (!p.isWithin(testResult, normalized)) {
    throw ArgumentError('Seedream output must be inside test_result/.');
  }
  return Directory(normalized);
}

Future<void> _writeJson(File file, Object? value) async {
  await file.parent.create(recursive: true);
  await file.writeAsString('${_json.convert(value)}\n', flush: true);
}

Future<void> _writeReports(
  Directory output,
  Map<String, Object?> report,
) async {
  await _writeJson(File(p.join(output.path, 'report.json')), report);
  final passed = report['passed'] == true;
  final markdown =
      '''# Living Campaign V2 Seedream Runtime Test

Status: **${passed ? 'PASS' : 'FAIL'}**

- Real Seedream calls: ${report['realSeedreamCalls']}
- Paid text calls: ${report['paidTextCalls']}
- Automatic retries: ${report['automaticRetries']}
- Model: ${report['imageModel']}
- Request ID: ${report['requestId'] ?? 'unavailable'}
- Source: `${report['sourceReference'] ?? 'unavailable'}`
- Processed: `${report['processedReference'] ?? 'unavailable'}`

## Failures

${(report['failures'] as List<Object?>? ?? const <Object?>[]).isEmpty ? '- None.' : (report['failures'] as List<Object?>).map((value) => '- $value').join('\n')}
''';
  await File(
    p.join(output.path, 'report.md'),
  ).writeAsString(markdown, flush: true);
  final escaped = const HtmlEscape().convert(markdown);
  final html =
      '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Seedream Runtime Test</title><style>:root{color-scheme:dark}body{margin:0;background:#090b0f;color:#eadfc8;font:16px/1.6 system-ui}main{max-width:980px;margin:auto;padding:48px}pre{white-space:pre-wrap;background:#111820;border:1px solid #4e3b22;border-radius:14px;padding:24px;color:#eadfc8}h1{color:#efc86f}</style></head><body><main><h1>Living Campaign V2 Seedream Runtime Test</h1><pre>$escaped</pre></main></body></html>''';
  await File(
    p.join(output.path, 'report.html'),
  ).writeAsString(html, flush: true);
}

Future<List<String>> _findSecretLeaks(Directory root, String secret) async {
  if (secret.isEmpty) return const <String>[];
  final leaks = <String>[];
  await for (final entity in root.list(recursive: true)) {
    if (entity is! File) continue;
    final extension = p.extension(entity.path).toLowerCase();
    if (!const <String>{'.json', '.md', '.html', '.txt'}.contains(extension)) {
      continue;
    }
    final content = await entity.readAsString();
    if (content.contains(secret)) leaks.add(p.relative(entity.path));
  }
  return leaks;
}
