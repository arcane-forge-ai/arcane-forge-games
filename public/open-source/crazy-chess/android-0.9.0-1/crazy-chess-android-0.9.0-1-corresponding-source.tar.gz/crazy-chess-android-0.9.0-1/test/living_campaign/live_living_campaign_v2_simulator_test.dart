@Tags(<String>['live'])
library;

import 'dart:convert';
import 'dart:io';

import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store_io.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_prompt_library.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:crazy_chess/living_campaign/living_campaign_v2_backend.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;

const _runLive = bool.fromEnvironment('RUN_LIVING_CAMPAIGN_V2_LIVE_SIMULATOR');
const _apiKey = String.fromEnvironment('ARK_API_KEY');
const _baseUrl = String.fromEnvironment(
  'ARK_BASE_URL',
  defaultValue: LivingCampaignSettings.defaultBaseUrl,
);
const _textModel = String.fromEnvironment(
  'LIVING_CAMPAIGN_TEXT_MODEL',
  defaultValue: LivingCampaignSettings.defaultTextModel,
);
const _outputRoot = String.fromEnvironment(
  'LIVING_CAMPAIGN_V2_SIMULATOR_OUTPUT',
);
const _scenarioFilter = String.fromEnvironment(
  'LIVING_CAMPAIGN_V2_SIMULATOR_SCENARIO',
);

const _json = JsonEncoder.withIndent('  ');

void main() {
  test(
    'three paid Ark campaigns generate legal M02 and M03 packages',
    () async {
      expect(_apiKey, isNotEmpty, reason: 'ARK_API_KEY was not injected.');
      expect(
        _outputRoot,
        isNotEmpty,
        reason: 'A unique LIVING_CAMPAIGN_V2_SIMULATOR_OUTPUT is required.',
      );
      final output = _validatedOutputDirectory(_outputRoot);
      expect(
        await output.exists(),
        isFalse,
        reason:
            'The paid simulator output directory already exists. Use a new '
            'timestamped directory; evidence directories are one-shot.',
      );
      await output.create(recursive: true);
      final selectedScenarios = _scenarioFilter.isEmpty
          ? _Scenario.values
          : _Scenario.values
                .where((scenario) => scenario.slug == _scenarioFilter)
                .toList(growable: false);
      expect(
        selectedScenarios,
        isNotEmpty,
        reason: 'Unknown LIVING_CAMPAIGN_V2_SIMULATOR_SCENARIO.',
      );
      await _writeJson(
        File(p.join(output.path, 'attempt-started.json')),
        <String, Object?>{
          'kind': 'living-campaign-v2-live-simulator',
          'authorized': true,
          'campaigns': selectedScenarios.length,
          'generatedMissionsPerCampaign': 2,
          'primaryPaidTextRequests': selectedScenarios.length * 6,
          if (_scenarioFilter.isNotEmpty)
            'diagnosticScenarioFilter': _scenarioFilter,
          'repairPolicy': 'one complete-invalid repair per stage',
          'transportRetries': false,
          'portraitRequests': false,
          'model': _textModel,
          'thinking': const <String, Object?>{'type': 'disabled'},
          'startedAt': DateTime.now().toUtc().toIso8601String(),
        },
      );

      final startedAt = DateTime.now().toUtc();
      final results = <_CampaignResult>[];
      for (final scenario in selectedScenarios) {
        try {
          results.add(await _runCampaign(output, scenario));
        } on Object catch (error, stackTrace) {
          results.add(
            _CampaignResult(
              scenario: scenario,
              passed: false,
              warnings: const <String>[],
              failures: <String>['$error'],
              paidRequests: 0,
              duration: Duration.zero,
              usage: const <String, Object?>{},
            ),
          );
          await _writeText(
            File(p.join(output.path, '${scenario.slug}-terminal-error.txt')),
            '$error\n\n$stackTrace\n',
          );
        }
      }

      final secretLeaks = await _findSecretLeaks(output, _apiKey);
      final failures = <String>[
        for (final result in results) ...result.failures,
        if (secretLeaks.isNotEmpty)
          'Secret leakage detected in: ${secretLeaks.join(', ')}',
      ];
      final finishedAt = DateTime.now().toUtc();
      final report = <String, Object?>{
        'kind': 'living-campaign-v2-live-simulator-report',
        'passed': failures.isEmpty && results.every((result) => result.passed),
        'model': _textModel,
        'startedAt': startedAt.toIso8601String(),
        'finishedAt': finishedAt.toIso8601String(),
        'durationMs': finishedAt.difference(startedAt).inMilliseconds,
        'campaigns': results.map((result) => result.toJson()).toList(),
        'summary': <String, Object?>{
          'campaignsPassed': results.where((result) => result.passed).length,
          'campaignsFailed': results.where((result) => !result.passed).length,
          'paidTextRequests': results.fold<int>(
            0,
            (sum, result) => sum + result.paidRequests,
          ),
          'warnings': results.fold<int>(
            0,
            (sum, result) => sum + result.warnings.length,
          ),
          'failures': failures,
          'secretLeakFiles': secretLeaks,
        },
      };
      await _writeJson(File(p.join(output.path, 'report.json')), report);
      final markdown = _renderMarkdownReport(report, results);
      await _writeText(File(p.join(output.path, 'report.md')), markdown);
      await _writeText(
        File(p.join(output.path, 'report.html')),
        _renderHtmlReport(report, results),
      );

      expect(
        failures,
        isEmpty,
        reason: 'Review ${p.join(output.path, 'report.html')}',
      );
      expect(
        results,
        everyElement(
          isA<_CampaignResult>().having(
            (result) => result.passed,
            'passed',
            isTrue,
          ),
        ),
      );
    },
    skip: !_runLive,
    timeout: const Timeout(Duration(hours: 2)),
  );
}

enum _Scenario {
  cleanVictory('clean-victory', 'Clean victory'),
  defeatRecovery('defeat-recovery', 'Defeat and recovery'),
  costlyAllegiance('costly-allegiance', 'Costly allegiance');

  const _Scenario(this.slug, this.label);

  final String slug;
  final String label;
}

Future<_CampaignResult> _runCampaign(
  Directory outputRoot,
  _Scenario scenario,
) async {
  final stopwatch = Stopwatch()..start();
  final directory = Directory(p.join(outputRoot.path, scenario.slug));
  await directory.create(recursive: true);
  final runId = 'sim_${scenario.slug.replaceAll('-', '_')}_20260809';
  final initial = LivingCampaignFixedOpener.create(
    runId: runId,
    now: DateTime.utc(2026, 8, 9),
  );
  await _writeJson(
    File(p.join(directory.path, 'initial-fixture.json')),
    initial.toJson(),
  );

  final debugLog = File(p.join(directory.path, 'debug-stream.log'));
  final debugSink = debugLog.openWrite();
  final client = DoubaoClient(
    settings: const LivingCampaignSettings(
      apiKey: _apiKey,
      baseUrl: _baseUrl,
      textModel: _textModel,
    ),
    debugLogger: (line) {
      final prefixed = '[${scenario.slug}] $line';
      // ignore: avoid_print
      print(prefixed);
      debugSink.writeln(prefixed);
    },
  );
  final archive = IoLivingCampaignArchiveStore(
    rootProvider: () async => Directory(p.join(directory.path, 'archive')),
  );
  final checkpoints = <Map<String, Object?>>[];
  final backend = LivingCampaignV2Backend(
    gateway: DoubaoLivingCampaignV2Gateway(client),
    archive: archive,
    promptLibrary: const _FilePromptLibrary(),
    generatePortraits: false,
    onProgress: (run) {
      final checkpoint = run.v2GenerationCheckpoint;
      checkpoints.add(<String, Object?>{
        'capturedAt': DateTime.now().toUtc().toIso8601String(),
        'activeChapterNumber': run.activeChapterNumber,
        'job': run.generationJob?.toJson(),
        'checkpoint': checkpoint?.toJson(),
        'generationRecordCount': run.generationRecords.length,
      });
    },
  );
  final warnings = <String>[];
  final failures = <String>[];
  LivingCampaignRun run = initial;
  try {
    final m01Outcome = _m01Outcome(run, scenario);
    await _writeJson(
      File(p.join(directory.path, 'synthetic-m01-outcome.json')),
      m01Outcome.toJson(),
    );
    final m02Result = await backend.generateNextChapter(
      run: run,
      outcome: m01Outcome,
    );
    run = m02Result.run;
    if (!m02Result.completed || run.activeChapterNumber != 2) {
      throw StateError(
        'M02 generation failed: ${m02Result.message ?? 'unknown failure'}',
      );
    }
    _validateScenarioAfterM01(scenario, run, failures);
    _collectRepairWarnings(run.generationRecords, warnings);
    final m02 = run.chapterPackages.last;
    _validateGeneratedMission(run, m02, failures);
    await _writeJson(
      File(p.join(directory.path, 'generated-m02.json')),
      m02.toJson(),
    );
    await _writeJson(
      File(p.join(directory.path, 'state-after-m02-generation.json')),
      run.toJson(),
    );

    final m02Outcome = _generatedOutcome(run, m02, scenario);
    await _writeJson(
      File(p.join(directory.path, 'synthetic-m02-outcome.json')),
      m02Outcome.toJson(),
    );
    final beforeSecondGenerationRecords = run.generationRecords.length;
    final m03Result = await backend.generateNextChapter(
      run: run,
      outcome: m02Outcome,
    );
    run = m03Result.run;
    if (!m03Result.completed || run.activeChapterNumber != 3) {
      throw StateError(
        'M03 generation failed: ${m03Result.message ?? 'unknown failure'}',
      );
    }
    _collectRepairWarnings(
      run.generationRecords.skip(beforeSecondGenerationRecords),
      warnings,
    );
    final m03 = run.chapterPackages.last;
    _validateGeneratedMission(run, m03, failures);
    _validateContinuity(run, failures);
    await _writeJson(
      File(p.join(directory.path, 'generated-m03.json')),
      m03.toJson(),
    );
    await _writeJson(
      File(p.join(directory.path, 'final-registry.json')),
      <String, Object?>{
        'runId': run.runId,
        'namedPiecesByName': run.namedPiecesByName.map(
          (key, value) => MapEntry(key, value.toJson()),
        ),
        'missionMemories': run.missionMemories
            .map((memory) => memory.toJson())
            .toList(),
        'historyDigests': run.historyDigests
            .map((digest) => digest.toJson())
            .toList(),
        'gold': run.canon.gold,
      },
    );
    await _writeJson(
      File(p.join(directory.path, 'accepted-checkpoints.json')),
      <String, Object?>{'snapshots': checkpoints},
    );
    await _writeStageArtifacts(directory, run.generationRecords);
  } on Object catch (error) {
    failures.add('$error');
    final latest = await archive.readRun(run.runId);
    if (latest != null) {
      run = latest;
      await _writeStageArtifacts(directory, run.generationRecords);
      await _writeJson(
        File(p.join(directory.path, 'failed-run.json')),
        run.toJson(),
      );
    }
  } finally {
    client.close();
    await debugSink.flush();
    await debugSink.close();
    stopwatch.stop();
  }

  final records = run.generationRecords;
  final primary = records.where((record) => record.attempt == 1).length;
  final repairs = records.where((record) => record.attempt > 1).length;
  if (primary != 6) {
    failures.add('Expected 6 primary stage calls, observed $primary.');
  }
  if (repairs > 6) {
    failures.add('Observed more than one repair per primary stage.');
  }
  if (records.any((record) => record.stage == LivingGenerationStage.portrait)) {
    failures.add('The backend simulator issued a forbidden portrait request.');
  }
  final usage = _sumUsage(records);
  final ledger = <String, Object?>{
    'scenario': scenario.slug,
    'primaryRequests': primary,
    'repairRequests': repairs,
    'totalPaidTextRequests': records.length,
    'requests': records
        .map(
          (record) => <String, Object?>{
            'recordId': record.recordId,
            'stage': record.stage.name,
            'attempt': record.attempt,
            'status': record.status.name,
            'requestId': record.providerRequestId,
            'finishReason': record.finishReason,
            'durationMs': record.durationMs,
            'usage': record.usage,
            'repairsRecordId': record.repairsRecordId,
          },
        )
        .toList(),
  };
  await _writeJson(File(p.join(directory.path, 'request-ledger.json')), ledger);

  return _CampaignResult(
    scenario: scenario,
    passed: failures.isEmpty,
    warnings: warnings,
    failures: failures,
    paidRequests: records.length,
    duration: stopwatch.elapsed,
    usage: usage,
  );
}

class _FilePromptLibrary implements LivingCampaignPromptLibrary {
  const _FilePromptLibrary();

  @override
  Future<String> load(LivingCampaignPrompt prompt) async {
    final source = await File(prompt.assetPath).readAsString();
    final normalized = source.trim();
    if (normalized.isEmpty) {
      throw StateError('Living Campaign prompt is blank: ${prompt.assetPath}');
    }
    return normalized;
  }
}

LivingBattleOutcomeSnapshot _m01Outcome(
  LivingCampaignRun run,
  _Scenario scenario,
) {
  final chapter = run.chapterPackages.single;
  final allWhite = chapter.pieces
      .where((piece) => piece.color == PieceColor.white)
      .map((piece) => piece.pieceId)
      .toList();
  switch (scenario) {
    case _Scenario.cleanVictory:
      return LivingBattleOutcomeSnapshot(
        chapterNumber: 1,
        chapterId: chapter.chapterId,
        result: LivingBattleResult.victory,
        endReason: GameEndReason.checkmate,
        objectiveType: chapter.objective.type,
        pressureTier: chapter.pressureTier,
        objectiveCompleted: true,
        completedTurns: 18,
        goldBefore: chapter.whiteGold,
        goldAfterBattle: 14,
        survivingPieceIds: allWhite,
        capturedPieces: const <LivingCapturedPieceOutcome>[],
        purchasedPieceIds: const <String>[],
        missionRoleChanges: const <String, PieceType>{},
        matchLog: const <String>[
          'Action 1: Ysra secured the western causeway.',
          'Action 7: Veyl opened a route through the center.',
          'Action 18: Orsain forced the rival King into checkmate.',
        ],
      );
    case _Scenario.defeatRecovery:
      return LivingBattleOutcomeSnapshot(
        chapterNumber: 1,
        chapterId: chapter.chapterId,
        result: LivingBattleResult.defeat,
        endReason: GameEndReason.checkmate,
        objectiveType: chapter.objective.type,
        pressureTier: chapter.pressureTier,
        objectiveCompleted: false,
        completedTurns: 16,
        goldBefore: chapter.whiteGold,
        goldAfterBattle: 8,
        survivingPieceIds: allWhite,
        capturedPieces: const <LivingCapturedPieceOutcome>[],
        purchasedPieceIds: const <String>[],
        missionRoleChanges: const <String, PieceType>{},
        matchLog: const <String>[
          'Action 4: The rival line sealed the eastern crossing.',
          'Action 16: Orsain was checkmated but escaped the field alive.',
        ],
      );
    case _Scenario.costlyAllegiance:
      return LivingBattleOutcomeSnapshot(
        chapterNumber: 1,
        chapterId: chapter.chapterId,
        result: LivingBattleResult.victory,
        endReason: GameEndReason.checkmate,
        objectiveType: chapter.objective.type,
        pressureTier: chapter.pressureTier,
        objectiveCompleted: true,
        completedTurns: 22,
        goldBefore: chapter.whiteGold,
        goldAfterBattle: 6,
        survivingPieceIds: <String>[
          ...allWhite.where((id) => id != 'ashen_knight_cael'),
          'enemy_rook_a8',
        ],
        capturedPieces: const <LivingCapturedPieceOutcome>[
          LivingCapturedPieceOutcome(
            pieceId: 'ashen_knight_cael',
            pieceType: PieceType.knight,
            ownerBeforeBattle: LivingAllegiance.player,
            capturedByPieceId: 'enemy_knight_g8',
            wasActuallyCaptured: true,
            characterId: 'char_cael',
          ),
        ],
        purchasedPieceIds: const <String>['enemy_rook_a8'],
        purchasedPieces: const <LivingPurchasedPieceOutcome>[
          LivingPurchasedPieceOutcome(
            pieceId: 'enemy_rook_a8',
            pieceType: PieceType.rook,
            originCountryId: 'ashen',
            loyalty: 35,
          ),
        ],
        purchaseEvents: const <LivingPurchaseEventOutcome>[
          LivingPurchaseEventOutcome(
            pieceId: 'enemy_rook_a8',
            pieceType: PieceType.rook,
            fromAllegiance: LivingAllegiance.enemy,
            toAllegiance: LivingAllegiance.player,
            completedActionNumber: 17,
          ),
        ],
        missionRoleChanges: const <String, PieceType>{},
        matchLog: const <String>[
          'Action 9: Cael was taken while holding the broken center.',
          'Action 17: Ysra bought the rival Rook away from its claimant.',
          'Action 22: Orsain completed the checkmate at heavy cost.',
        ],
      );
  }
}

LivingBattleOutcomeSnapshot _generatedOutcome(
  LivingCampaignRun run,
  LivingChapterPackage chapter,
  _Scenario scenario,
) {
  final white = chapter.pieces
      .where((piece) => piece.color == PieceColor.white)
      .toList();
  final black = chapter.pieces
      .where((piece) => piece.color == PieceColor.black)
      .toList();
  final victory = scenario != _Scenario.costlyAllegiance;
  final captured = <LivingCapturedPieceOutcome>[];
  if (victory) {
    final target = black
        .where((piece) => piece.pieceType != PieceType.king)
        .firstOrNull;
    if (target != null) {
      captured.add(
        LivingCapturedPieceOutcome(
          pieceId: target.pieceId,
          pieceType: target.pieceType,
          ownerBeforeBattle: LivingAllegiance.enemy,
          capturedByPieceId: white.first.pieceId,
          wasActuallyCaptured: true,
          characterId: target.characterId,
        ),
      );
    }
  }
  return LivingBattleOutcomeSnapshot(
    chapterNumber: chapter.chapterNumber,
    chapterId: chapter.chapterId,
    result: victory ? LivingBattleResult.victory : LivingBattleResult.defeat,
    endReason: victory ? GameEndReason.none : GameEndReason.stalemate,
    objectiveType: chapter.objective.type,
    pressureTier: chapter.pressureTier,
    objectiveCompleted: victory,
    completedTurns: victory ? 20 : 15,
    goldBefore: chapter.whiteGold,
    goldAfterBattle: victory
        ? chapter.whiteGold + 3
        : (chapter.whiteGold - 2).clamp(0, chapter.whiteGold).toInt(),
    survivingPieceIds: white.map((piece) => piece.pieceId).toList(),
    capturedPieces: captured,
    purchasedPieceIds: const <String>[],
    missionRoleChanges: const <String, PieceType>{},
    matchLog: <String>[
      'Action 3: The Ashen formation met the generated enemy line.',
      victory
          ? 'Action 20: The mission objective was secured with the named allies alive.'
          : 'Action 15: The court withdrew after failing the mission objective; Orsain remained alive.',
    ],
  );
}

void _validateScenarioAfterM01(
  _Scenario scenario,
  LivingCampaignRun run,
  List<String> failures,
) {
  if (run.status != LivingRunStatus.active || run.epilogue != null) {
    failures.add('${scenario.label} ended before M02 was played.');
  }
  final ysra = run.namedPiecesByName['Dame Ysra Stonehand'];
  switch (scenario) {
    case _Scenario.cleanVictory:
      if (ysra?.loyalty != 80 || run.canon.gold != 24) {
        failures.add('Clean victory did not apply Loyalty and Gold correctly.');
      }
    case _Scenario.defeatRecovery:
      if (ysra?.loyalty != 60 || run.canon.gold != 8) {
        failures.add(
          'Ordinary defeat changed Loyalty or granted victory Gold.',
        );
      }
    case _Scenario.costlyAllegiance:
      final cael = run.namedPiecesByName['Cael of No Banner'];
      final turncoat = run.namedPiecesByName.values.where(
        (record) => record.pieceId == 'enemy_rook_a8',
      );
      if (cael == null ||
          !const <LivingNamedPieceStatus>{
            LivingNamedPieceStatus.dead,
            LivingNamedPieceStatus.missing,
          }.contains(cael.status)) {
        failures.add('Costly victory did not apply Cael\'s seeded fate.');
      }
      if (turncoat.length != 1 || turncoat.single.loyalty != 55) {
        failures.add('Purchased Rook did not reset then gain victory Loyalty.');
      }
  }
}

void _validateGeneratedMission(
  LivingCampaignRun run,
  LivingChapterPackage chapter,
  List<String> failures,
) {
  final issues = const LivingCampaignV2Validator().validateChapter(chapter);
  if (issues.isNotEmpty) failures.addAll(issues);
  if (chapter.briefing.trim().isEmpty || chapter.dialogue.length < 2) {
    failures.add('${chapter.chapterId} is missing story or conversation.');
  }
  final known = run.namedPiecesByName.values
      .map((record) => record.characterId)
      .toSet();
  if (chapter.dialogue.any((line) => !known.contains(line.speakerId))) {
    failures.add('${chapter.chapterId} dialogue contains a stale speaker ID.');
  }
  final whiteAdvanced = chapter.pieces.where(
    (piece) =>
        piece.color == PieceColor.white && piece.pieceType != PieceType.pawn,
  );
  final whitePawns = chapter.pieces.where(
    (piece) =>
        piece.color == PieceColor.white && piece.pieceType == PieceType.pawn,
  );
  if (whiteAdvanced.length != whitePawns.length || whiteAdvanced.length > 8) {
    failures.add(
      '${chapter.chapterId} has an invalid renewable Pawn formation.',
    );
  }
  for (final advanced in whiteAdvanced) {
    if (!whitePawns.any(
      (pawn) =>
          pawn.square.row == advanced.square.row - 1 &&
          pawn.square.col == advanced.square.col,
    )) {
      failures.add(
        '${chapter.chapterId} has a Pawn outside its advanced file.',
      );
    }
  }
  final blackPawns = chapter.pieces.where(
    (piece) =>
        piece.color == PieceColor.black && piece.pieceType == PieceType.pawn,
  );
  if (blackPawns.length > 8) {
    failures.add('${chapter.chapterId} generated more than eight enemy Pawns.');
  }
}

void _validateContinuity(LivingCampaignRun run, List<String> failures) {
  if (run.chapterPackages.map((chapter) => chapter.chapterNumber).join(',') !=
      '1,2,3') {
    failures.add('Generated mission sequence is not M01 → M02 → M03.');
  }
  if (run.missionMemories.map((memory) => memory.missionNumber).join(',') !=
      '1,2') {
    failures.add('Mission memories do not preserve M01 and M02 in order.');
  }
  if (run.battleOutcomes.map((outcome) => outcome.chapterNumber).join(',') !=
      '1,2') {
    failures.add('Battle outcomes do not preserve M01 and M02 in order.');
  }
  if (run.namedPiecesByName.values.any(
    (record) => record.pieceType == PieceType.pawn,
  )) {
    failures.add('A Pawn leaked into the persistent named-piece registry.');
  }
  final ids = run.namedPiecesByName.values
      .map((record) => record.characterId)
      .toList();
  if (ids.length != ids.toSet().length) {
    failures.add('The final registry contains duplicate character IDs.');
  }
}

void _collectRepairWarnings(
  Iterable<LivingGenerationRecord> records,
  List<String> warnings,
) {
  for (final record in records.where((record) => record.attempt > 1)) {
    warnings.add(
      '${record.stage.name} passed after repair of ${record.repairsRecordId}.',
    );
  }
}

Future<void> _writeStageArtifacts(
  Directory campaign,
  List<LivingGenerationRecord> records,
) async {
  final root = Directory(p.join(campaign.path, 'stages'));
  await root.create(recursive: true);
  for (var index = 0; index < records.length; index += 1) {
    final record = records[index];
    final stage = Directory(
      p.join(
        root.path,
        '${(index + 1).toString().padLeft(2, '0')}-${record.stage.name}-attempt-${record.attempt}',
      ),
    );
    await stage.create(recursive: true);
    await _writeJson(
      File(p.join(stage.path, 'request.json')),
      record.requestPayload,
    );
    await _writeText(File(p.join(stage.path, 'raw-sse.txt')), record.rawSse);
    await _writeText(
      File(p.join(stage.path, 'raw-final-answer.txt')),
      record.rawContent,
    );
    await _writeJson(
      File(p.join(stage.path, 'parsed.json')),
      record.responsePayload,
    );
    await _writeJson(
      File(p.join(stage.path, 'schema-validation.json')),
      <String, Object?>{
        'providerStrictJsonSchema': true,
        'parsedJsonObject': record.responsePayload.isNotEmpty,
      },
    );
    await _writeJson(
      File(p.join(stage.path, 'semantic-validation.json')),
      <String, Object?>{
        'passed':
            record.validationIssues.isEmpty &&
            record.status == LivingGenerationStatus.completed,
        'issues': record.validationIssues,
        'errorCode': record.errorCode,
        'errorMessage': record.errorMessage,
      },
    );
    await _writeJson(
      File(p.join(stage.path, 'metadata.json')),
      <String, Object?>{
        'recordId': record.recordId,
        'stage': record.stage.name,
        'attempt': record.attempt,
        'status': record.status.name,
        'requestId': record.providerRequestId,
        'transport': record.transportType,
        'timeToFirstEventMs': record.timeToFirstEventMs,
        'durationMs': record.durationMs,
        'finishReason': record.finishReason,
        'usage': record.usage,
        'repairsRecordId': record.repairsRecordId,
      },
    );
  }
}

Map<String, Object?> _sumUsage(List<LivingGenerationRecord> records) {
  var prompt = 0;
  var completion = 0;
  var total = 0;
  for (final record in records) {
    prompt += (record.usage['prompt_tokens'] as num?)?.toInt() ?? 0;
    completion += (record.usage['completion_tokens'] as num?)?.toInt() ?? 0;
    total += (record.usage['total_tokens'] as num?)?.toInt() ?? 0;
  }
  return <String, Object?>{
    'promptTokens': prompt,
    'completionTokens': completion,
    'totalTokens': total,
  };
}

Directory _validatedOutputDirectory(String value) {
  final workspace = p.normalize(Directory.current.absolute.path);
  final absolute = p.normalize(p.absolute(value));
  final expectedRoot = p.normalize(p.join(workspace, 'test_result'));
  if (!p.isWithin(expectedRoot, absolute) || p.basename(absolute).isEmpty) {
    throw ArgumentError(
      'Simulator output must be a unique child of $expectedRoot.',
    );
  }
  return Directory(absolute);
}

Future<List<String>> _findSecretLeaks(Directory root, String secret) async {
  if (secret.isEmpty) return const <String>[];
  final leaks = <String>[];
  await for (final entity in root.list(recursive: true)) {
    if (entity is! File) continue;
    final bytes = await entity.readAsBytes();
    if (utf8.decode(bytes, allowMalformed: true).contains(secret)) {
      leaks.add(p.relative(entity.path, from: root.path));
    }
  }
  return leaks;
}

String _renderMarkdownReport(
  Map<String, Object?> report,
  List<_CampaignResult> results,
) {
  final buffer = StringBuffer()
    ..writeln('# Living Campaign V2 Live Simulator')
    ..writeln()
    ..writeln('Overall: **${report['passed'] == true ? 'PASS' : 'FAIL'}**')
    ..writeln()
    ..writeln(
      '| Campaign | Result | Paid calls | Repairs/warnings | Duration | Tokens |',
    )
    ..writeln('|---|---:|---:|---:|---:|---:|');
  for (final result in results) {
    buffer.writeln(
      '| ${result.scenario.label} | ${result.passed ? 'PASS' : 'FAIL'} | '
      '${result.paidRequests} | ${result.warnings.length} | '
      '${result.duration.inSeconds}s | ${result.usage['totalTokens'] ?? 0} |',
    );
  }
  buffer
    ..writeln()
    ..writeln('## Warnings and failures')
    ..writeln();
  for (final result in results) {
    buffer.writeln('### ${result.scenario.label}');
    if (result.warnings.isEmpty && result.failures.isEmpty) {
      buffer.writeln('- None.');
    }
    for (final warning in result.warnings) {
      buffer.writeln('- Warning: $warning');
    }
    for (final failure in result.failures) {
      buffer.writeln('- Failure: $failure');
    }
    buffer.writeln();
  }
  return buffer.toString();
}

String _renderHtmlReport(
  Map<String, Object?> report,
  List<_CampaignResult> results,
) {
  final rows = results
      .map(
        (result) =>
            '''
    <tr><td>${_escape(result.scenario.label)}</td>
    <td class="${result.passed ? 'pass' : 'fail'}">${result.passed ? 'PASS' : 'FAIL'}</td>
    <td>${result.paidRequests}</td><td>${result.warnings.length}</td>
    <td>${result.duration.inSeconds}s</td><td>${result.usage['totalTokens'] ?? 0}</td></tr>''',
      )
      .join();
  final details = results
      .map(
        (result) =>
            '''
    <section><h2>${_escape(result.scenario.label)}</h2>
    ${result.warnings.map((value) => '<p class="warn">Warning: ${_escape(value)}</p>').join()}
    ${result.failures.map((value) => '<p class="fail">Failure: ${_escape(value)}</p>').join()}
    ${result.warnings.isEmpty && result.failures.isEmpty ? '<p>No warnings or failures.</p>' : ''}</section>''',
      )
      .join();
  return '''<!doctype html><html lang="en"><head><meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Living Campaign V2 Live Simulator</title><style>
  :root{color-scheme:dark}body{margin:0;background:#090c12;color:#e8e2d2;font:16px/1.55 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:48px 28px}h1,h2{font-family:Georgia,serif;color:#f2c66d}section,table{background:#111722;border:1px solid #4b3a1d;border-radius:14px;padding:20px;margin:20px 0}table{width:100%;border-collapse:collapse}th,td{padding:12px;border-bottom:1px solid #28303d;text-align:left}.pass{color:#7ee2a8}.fail{color:#ff8d8d}.warn{color:#f4cf76}code{color:#cbd7ff}</style></head>
  <body><main><h1>Living Campaign V2 Live Simulator</h1>
  <p>Overall: <strong class="${report['passed'] == true ? 'pass' : 'fail'}">${report['passed'] == true ? 'PASS' : 'FAIL'}</strong></p>
  <table><thead><tr><th>Campaign</th><th>Result</th><th>Paid calls</th><th>Warnings</th><th>Duration</th><th>Tokens</th></tr></thead><tbody>$rows</tbody></table>
  $details</main></body></html>''';
}

String _escape(Object? value) => value
    .toString()
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');

Future<void> _writeJson(File file, Map<String, Object?> value) =>
    _writeText(file, '${_json.convert(value)}\n');

Future<void> _writeText(File file, String value) async {
  await file.parent.create(recursive: true);
  await file.writeAsString(value, flush: true);
}

class _CampaignResult {
  const _CampaignResult({
    required this.scenario,
    required this.passed,
    required this.warnings,
    required this.failures,
    required this.paidRequests,
    required this.duration,
    required this.usage,
  });

  final _Scenario scenario;
  final bool passed;
  final List<String> warnings;
  final List<String> failures;
  final int paidRequests;
  final Duration duration;
  final Map<String, Object?> usage;

  Map<String, Object?> toJson() => <String, Object?>{
    'scenario': scenario.slug,
    'label': scenario.label,
    'passed': passed,
    'warnings': warnings,
    'failures': failures,
    'paidRequests': paidRequests,
    'durationMs': duration.inMilliseconds,
    'usage': usage,
  };
}
