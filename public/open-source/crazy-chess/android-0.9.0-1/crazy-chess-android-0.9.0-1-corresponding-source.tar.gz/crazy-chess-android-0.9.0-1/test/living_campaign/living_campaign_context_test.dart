import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_context.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test(
    'complete context carries the entire structured canon without a cap',
    () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-context',
        now: DateTime.utc(2026, 8, 5),
      );
      final projection = const LivingCanonContextBuilder().complete(
        canon: run.canon,
        outcome: _outcome(),
      );

      expect(projection.compacted, isFalse);
      expect(projection.payload['canon'], run.canon.toJson());
      expect(
        (projection.payload['continuityContract']!
            as Map)['arbitraryRollingSummaryCap'],
        isFalse,
      );
    },
  );

  test(
    'provider fallback uses lossless tuples and validated source hashes',
    () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-context',
        now: DateTime.utc(2026, 8, 5),
      );
      final builder = const LivingCanonContextBuilder();
      final projection = builder.losslessEventTupleProjection(
        canon: run.canon,
        outcome: _outcome(),
        createdAt: DateTime.utc(2026, 8, 5, 1),
      );
      final projectedCanon = projection.payload['canon']! as Map;
      final tuples = projectedCanon['eventLedgerTuples']! as List;

      expect(projection.compacted, isTrue);
      expect(projectedCanon, isNot(contains('eventLedger')));
      expect(tuples, hasLength(run.canon.eventLedger.length));
      expect(tuples.first[0], run.canon.eventLedger.first.eventId);
      expect(tuples.first[4], run.canon.eventLedger.first.description);
      expect(projection.canon.memoryEpochs, hasLength(1));
      expect(
        builder.validateMemoryEpoch(
          projection.canon.memoryEpochs.single,
          run.canon,
        ),
        isEmpty,
      );
    },
  );
}

LivingBattleOutcomeSnapshot _outcome() => const LivingBattleOutcomeSnapshot(
  chapterNumber: 1,
  chapterId: 'living_m01',
  result: LivingBattleResult.victory,
  endReason: GameEndReason.checkmate,
  objectiveType: LivingObjectiveType.checkmate,
  objectiveCompleted: true,
  completedTurns: 12,
  goldBefore: 10,
  goldAfterBattle: 12,
  survivingPieceIds: <String>[
    'ashen_king_orsain',
    'ashen_rook_ysra',
    'ashen_bishop_veyl',
    'ashen_knight_cael',
    'ashen_pawn_d',
    'ashen_pawn_e',
    'ashen_pawn_f',
  ],
  capturedPieces: <LivingCapturedPieceOutcome>[],
  purchasedPieceIds: <String>[],
  missionRoleChanges: <String, PieceType>{},
);
