import 'dart:io';
import 'dart:typed_data';

import 'package:crazy_chess/living_campaign/living_campaign_archive_store.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store_io.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_metrics.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test(
    'native archive persists runs, metrics, and binaries and deletes exact run',
    () async {
      final root = await Directory.systemTemp.createTemp(
        'living-campaign-test-',
      );
      addTearDown(() async {
        if (await root.exists()) {
          await root.delete(recursive: true);
        }
      });
      final store = IoLivingCampaignArchiveStore(
        rootProvider: () async => root,
      );
      final run = LivingCampaignFixedOpener.create(
        runId: 'run_archive',
        now: DateTime.utc(2026, 8, 5),
      );

      await store.writeRun(run);
      final metrics =
          LivingCampaignRunTimingMetrics.empty(
            runId: run.runId,
            now: run.createdAt,
          ).recordElapsed(
            elapsed: const Duration(seconds: 9),
            bucket: LivingCampaignTimingBucket.narrativeReading,
            chapterNumber: 1,
            at: run.createdAt.add(const Duration(seconds: 9)),
          );
      await store.writeTimingMetrics(metrics);
      final portraitReference = await store.writeBinary(
        runId: run.runId,
        fileName: 'portrait.png',
        bytes: Uint8List.fromList(<int>[1, 2, 3, 4]),
      );

      expect((await store.readRun(run.runId))!.toJson(), run.toJson());
      expect(
        (await store.readTimingMetrics(run.runId))!.toJson(),
        metrics.toJson(),
      );
      expect(await store.readBinary(portraitReference), <int>[1, 2, 3, 4]);
      expect((await store.listRuns()).single.runId, run.runId);
      expect(await store.storageBytes(), greaterThan(4));

      await store.deleteRun(run.runId);
      expect(await store.readRun(run.runId), isNull);
      expect(await store.readTimingMetrics(run.runId), isNull);
      expect(await store.listRuns(), isEmpty);
    },
  );

  test('native archive rejects path traversal identifiers', () async {
    final root = await Directory.systemTemp.createTemp('living-campaign-test-');
    addTearDown(() async {
      if (await root.exists()) await root.delete(recursive: true);
    });
    final store = IoLivingCampaignArchiveStore(rootProvider: () async => root);

    expect(() => store.readRun('../other'), throwsArgumentError);
    expect(
      () => store.writeBinary(
        runId: 'safe',
        fileName: '../portrait.png',
        bytes: Uint8List(0),
      ),
      throwsArgumentError,
    );
  });

  test(
    'per-run mutation coordinator serializes concurrent owned writes',
    () async {
      final root = await Directory.systemTemp.createTemp(
        'living-campaign-coordinator-',
      );
      addTearDown(() async {
        if (await root.exists()) await root.delete(recursive: true);
      });
      final store = IoLivingCampaignArchiveStore(
        rootProvider: () async => root,
      );
      final source = LivingCampaignFixedOpener.create(
        runId: 'run-coordinator',
        now: DateTime.utc(2026, 8, 11),
      );
      await store.writeRun(source);
      final coordinator = LivingCampaignRunMutationCoordinator.forArchive(
        store,
      );

      await Future.wait(<Future<Object?>>[
        coordinator.mutate(
          runId: source.runId,
          seed: source,
          mutation: (latest) =>
              latest.copyWith(campaignTitle: 'The Remembered Field'),
        ),
        coordinator.mutate(
          runId: source.runId,
          seed: source,
          mutation: (latest) => latest.copyWith(
            storyPromise: 'The survivors carry both records forward.',
          ),
        ),
      ]);

      final merged = await store.readRun(source.runId);
      expect(merged!.campaignTitle, 'The Remembered Field');
      expect(merged.storyPromise, 'The survivors carry both records forward.');
    },
  );

  test(
    'schema V2 initialization removes only incompatible campaign data',
    () async {
      final root = await Directory.systemTemp.createTemp('living-campaign-v1-');
      addTearDown(() async {
        if (await root.exists()) await root.delete(recursive: true);
      });
      final runs = Directory('${root.path}/runs')..createSync(recursive: true);
      final portraits = Directory('${root.path}/portraits')
        ..createSync(recursive: true);
      final metrics = Directory('${root.path}/metrics')
        ..createSync(recursive: true);
      final unrelated = File('${root.path}/unrelated-setting.txt')
        ..writeAsStringSync('preserve me');
      File('${runs.path}/legacy.json').writeAsStringSync('{}');
      File('${portraits.path}/legacy.png').writeAsBytesSync(<int>[1, 2, 3]);
      File('${metrics.path}/legacy.json').writeAsStringSync('{}');

      final store = IoLivingCampaignArchiveStore(
        rootProvider: () async => root,
      );
      await store.initialize();

      expect(await runs.list().toList(), isEmpty);
      expect(await portraits.list().toList(), isEmpty);
      expect(await metrics.list().toList(), isEmpty);
      expect(await unrelated.readAsString(), 'preserve me');
      expect(
        await File('${root.path}/storage-schema-version').readAsString(),
        '2\n',
      );
    },
  );
}
