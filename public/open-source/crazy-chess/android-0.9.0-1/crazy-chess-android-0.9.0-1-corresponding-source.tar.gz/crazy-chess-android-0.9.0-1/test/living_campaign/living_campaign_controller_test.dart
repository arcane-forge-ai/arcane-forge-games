import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:crazy_chess/ai/chess_engine.dart';
import 'package:crazy_chess/battlefield/battlefield_models.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/game/game_controller.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store_io.dart';
import 'package:crazy_chess/living_campaign/living_campaign_controller.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_generation_service.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_v2_backend.dart';
import 'package:crazy_chess/living_campaign/living_portrait_resolver.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/fake_chess_engine.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'initialize persists authored portrait backfill for existing runs',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-backfill-');
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      await archive.initialize();
      final source = LivingCampaignFixedOpener.create(
        runId: 'existing-run',
        now: DateTime.utc(2026, 8, 9),
      );
      final json = source.toJson();
      final named = Map<String, Object?>.from(
        json['namedPiecesByName']! as Map,
      );
      for (final name in const <String>[
        'Lady Maelin Cinderveil',
        'Warden Hadrik Emberwall',
        'Sister Neris of the Last Bell',
        'Ser Tavian Greyspur',
      ]) {
        named[name] = Map<String, Object?>.from(named[name]! as Map)
          ..remove('portraitPath');
      }
      json['namedPiecesByName'] = named;
      await archive.writeRun(LivingCampaignRun.fromJson(json));

      final game = GameController();
      addTearDown(game.dispose);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: true),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
      );
      addTearDown(() => _disposeLivingController(controller));

      await controller.initialize();

      final persisted = await archive.readRun('existing-run');
      expect(
        persisted!.namedPiecesByName['Lady Maelin Cinderveil']!.portraitPath,
        LivingPortraitFallbackResolver.maelinAsset,
      );
      expect(
        persisted.namedPiecesByName['Warden Hadrik Emberwall']!.portraitPath,
        LivingPortraitFallbackResolver.hadrikAsset,
      );
      expect(
        persisted
            .namedPiecesByName['Sister Neris of the Last Bell']!
            .portraitPath,
        LivingPortraitFallbackResolver.nerisAsset,
      );
      expect(
        persisted.namedPiecesByName['Ser Tavian Greyspur']!.portraitPath,
        LivingPortraitFallbackResolver.tavianAsset,
      );
    },
  );

  test(
    'missing run-local fixed portrait falls through to authored art',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-portrait-order-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final game = GameController();
      addTearDown(game.dispose);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: true),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
      );
      addTearDown(() => _disposeLivingController(controller));
      await controller.initialize();
      final run = LivingCampaignFixedOpener.create(
        runId: 'portrait-order',
        now: DateTime.utc(2026, 8, 10),
      );
      controller.activeRun = run.copyWith(
        canon: run.canon.copyWith(
          charactersById: <String, LivingCharacter>{
            ...run.canon.charactersById,
            'char_maelin_cinderveil': const LivingCharacter(
              characterId: 'char_maelin_cinderveil',
              originalName: 'Lady Maelin Cinderveil',
              originalIdentity: 'An Ashen claimant.',
              basePieceType: PieceType.queen,
              lifeState: LivingLifeState.alive,
              whereabouts: LivingWhereabouts.withCourt,
              allegiance: LivingAllegiance.player,
              firstChapter: 2,
              lastChapter: 2,
              portraitPath: 'missing://run-local.webp',
            ),
          },
        ),
      );

      final bytes = await controller.portraitBytes('char_maelin_cinderveil');

      expect(bytes, isNotNull);
      expect(bytes, isNotEmpty);
    },
  );

  test(
    'new run persists fixed M01 immediately without an Ark request',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-controller-');
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final game = GameController();
      addTearDown(game.dispose);
      var prologueCalls = 0;
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async {
          prologueCalls++;
          return LivingGenerationResult(run: run, completed: false);
        },
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        clock: () => DateTime.utc(2026, 8, 5, 6),
      );
      addTearDown(() => _disposeLivingController(controller));

      await controller.initialize();
      expect(controller.phase, LivingCampaignPhase.hub);

      final handle = await controller.startNewRun();
      expect(controller.phase, LivingCampaignPhase.hub);
      expect(handle, isNull);
      expect(prologueCalls, 0);
      expect(controller.isGenerationRunning, isFalse);
      expect(controller.canContinueStory, isTrue);
      expect(
        controller.activeRun!.campaignTitle,
        LivingCampaignFixedOpener.campaignTitle,
      );
      expect(controller.activeChapter!.title, 'The Ashen Divide');
      expect(
        controller.activeChapter!.subtitle,
        'One crown. One road out. No uncontested heir.',
      );
      expect(controller.activeChapter!.dialogue, hasLength(12));
      expect(
        controller.activeChapter!.pieces.map((piece) => piece.square),
        containsAll(const <Square>[
          Square(7, 0),
          Square(7, 2),
          Square(7, 4),
          Square(7, 6),
          Square(6, 0),
          Square(6, 2),
          Square(6, 4),
          Square(6, 6),
        ]),
      );

      controller.openActiveRun();
      expect(controller.phase, LivingCampaignPhase.prologue);
      controller.continueFromPrologue();
      expect(controller.phase, LivingCampaignPhase.dialogue);
      expect(controller.dialogueIndex, 0);
      controller.skipDialogue();
      expect(controller.phase, LivingCampaignPhase.briefing);
      controller.startBattle();

      expect(controller.phase, LivingCampaignPhase.battle);
      expect(game.activeScenarioId, 'living_m01');
      expect(game.activeBattlefieldSeed, 1101);
      expect(game.whiteCountryId, 'ashen');
      expect(game.blackCountryId, 'ashen');
    },
  );

  test(
    'local timing metrics track foreground chapter phases exactly',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-timing-');
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final game = GameController();
      addTearDown(game.dispose);
      var now = DateTime.utc(2026, 8, 17, 10);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: true),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        clock: () => now,
      );
      addTearDown(() => _disposeLivingController(controller));

      await controller.initialize();
      await controller.startNewRun();
      final runId = controller.activeRun!.runId;

      now = now.add(const Duration(seconds: 2));
      controller.phase = LivingCampaignPhase.prologue;
      now = now.add(const Duration(seconds: 10));
      controller.phase = LivingCampaignPhase.battle;
      now = now.add(const Duration(seconds: 30));
      controller.phase = LivingCampaignPhase.outcomeAcknowledgement;
      now = now.add(const Duration(seconds: 5));
      controller.setAppForeground(false);
      now = now.add(const Duration(seconds: 20));
      controller.phase = LivingCampaignPhase.chapterEnding;
      controller.setAppForeground(true);
      controller.setSessionVisible(false);
      now = now.add(const Duration(seconds: 11));
      controller.setSessionVisible(true);
      now = now.add(const Duration(seconds: 3));
      await controller.flushTimingMetrics();

      final metrics = await archive.readTimingMetrics(runId);
      expect(metrics, isNotNull);
      expect(metrics!.foregroundActiveMs, 50000);
      expect(metrics.narrativeReadingMs, 10000);
      expect(metrics.battleActiveMs, 30000);
      expect(metrics.aiWaitMs, 0);
      expect(metrics.resultsReviewMs, 8000);
      expect(metrics.chapters[1]!.foregroundActiveMs, 50000);
      expect(
        metrics.chapters[1]!.firstOpenedAt,
        DateTime.utc(2026, 8, 17, 10, 0, 2),
      );
      expect(
        metrics.chapters[1]!.firstBattleStartedAt,
        DateTime.utc(2026, 8, 17, 10, 0, 12),
      );
      expect(
        metrics.chapters[1]!.latestBattleEndedAt,
        DateTime.utc(2026, 8, 17, 10, 0, 42),
      );
      expect(
        metrics.chapters[1]!.firstCompletedAt,
        DateTime.utc(2026, 8, 17, 10, 1, 7),
      );
    },
  );

  test('paid generation on the hub counts as foreground AI wait', () async {
    final temp = await Directory.systemTemp.createTemp('living-ai-wait-');
    addTearDown(() => temp.delete(recursive: true));
    final archive = IoLivingCampaignArchiveStore(
      rootProvider: () async => temp,
    );
    final game = GameController();
    addTearDown(game.dispose);
    final gate = Completer<void>();
    var now = DateTime.utc(2026, 8, 17, 11);
    final controller = LivingCampaignController(
      gameController: game,
      archive: archive,
      generatePrologue: (run) async {
        await gate.future;
        return LivingGenerationResult(
          run: run.copyWith(clearGenerationJob: true),
          completed: true,
        );
      },
      generateNextChapter: (run, outcome) async =>
          LivingGenerationResult(run: run, completed: false),
      clock: () => now,
    );
    addTearDown(() => _disposeLivingController(controller));

    await controller.initialize();
    await controller.startNewRun();
    final runId = controller.activeRun!.runId;
    controller.activeRun = controller.activeRun!.copyWith(
      generationJob: LivingGenerationJob(
        jobId: 'timing-resume',
        stage: LivingGenerationStage.prologue,
        status: LivingGenerationStatus.awaitingResume,
        attempt: 1,
        createdAt: now,
        updatedAt: now,
      ),
    );

    final handle = await controller.resumeGeneration();
    expect(handle, isNotNull);
    expect(controller.phase, LivingCampaignPhase.hub);
    now = now.add(const Duration(seconds: 12));
    controller.setAppForeground(false);
    now = now.add(const Duration(seconds: 5));
    gate.complete();
    await handle!.completion;
    controller.setAppForeground(true);
    now = now.add(const Duration(seconds: 3));
    await controller.flushTimingMetrics();

    final metrics = await archive.readTimingMetrics(runId);
    expect(metrics!.foregroundActiveMs, 15000);
    expect(metrics.aiWaitMs, 12000);
    expect(metrics.chapters[1]!.aiWaitMs, 12000);
  });

  test(
    'restart converts an in-flight paid request to explicit resume',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-resume-');
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final now = DateTime.utc(2026, 8, 5, 7);
      final source = _committedRun(runId: 'run-interrupted', now: now).copyWith(
        generationJob: LivingGenerationJob(
          jobId: 'job-interrupted',
          stage: LivingGenerationStage.chronicler,
          status: LivingGenerationStatus.running,
          attempt: 1,
          createdAt: now,
          updatedAt: now,
        ),
      );
      await archive.writeRun(source);
      final game = GameController();
      addTearDown(game.dispose);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        clock: () => now.add(const Duration(minutes: 2)),
      );
      addTearDown(() => _disposeLivingController(controller));

      await controller.initialize();

      expect(controller.phase, LivingCampaignPhase.hub);
      expect(controller.hasInterruptedGeneration, isTrue);
      expect(
        controller.activeRun!.generationJob!.status,
        LivingGenerationStatus.awaitingResume,
      );
      expect(controller.activeRun!.generationJob!.errorCode, 'interrupted');
      expect(controller.retryGenerationLabel, 'Recall the Battle Again');
    },
  );

  test(
    'restart converts only portrait work to non-blocking fallback',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-portrait-restart-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final now = DateTime.utc(2026, 8, 10, 1);
      final source = _portraitCheckpointRun(
        runId: 'run-portrait-interrupted',
        now: now,
        status: LivingPortraitStatus.generating,
        generationJob: LivingGenerationJob(
          jobId: 'portrait-job',
          stage: LivingGenerationStage.portrait,
          status: LivingGenerationStatus.running,
          attempt: 1,
          createdAt: now,
          updatedAt: now,
        ),
      );
      await archive.writeRun(source);
      final game = GameController();
      addTearDown(game.dispose);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        clock: () => now.add(const Duration(minutes: 2)),
      );
      addTearDown(() => _disposeLivingController(controller));

      await controller.initialize();

      expect(controller.activeRun!.generationJob, isNull);
      expect(controller.hasInterruptedGeneration, isFalse);
      expect(controller.hasPortraitAttention, isTrue);
      expect(controller.portraitStatusLabel, 'A FACE YET UNSEEN');
      expect(controller.canContinueStory, isTrue);
      expect(
        controller
            .activeRun!
            .portraitCheckpointsByCharacterId['char_generated_rook']!
            .status,
        LivingPortraitStatus.awaitingRetry,
      );
    },
  );

  test(
    'explicit portrait retry locks battle entry and uses one task',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-portrait-retry-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final now = DateTime.utc(2026, 8, 10, 2);
      final source = _portraitCheckpointRun(
        runId: 'run-portrait-retry',
        now: now,
        status: LivingPortraitStatus.awaitingRetry,
      );
      await archive.writeRun(source);
      final result = Completer<LivingGenerationResult>();
      var calls = 0;
      final game = GameController();
      addTearDown(game.dispose);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        generatePortrait: (run, characterId) {
          calls++;
          expect(characterId, 'char_generated_rook');
          return result.future;
        },
        clock: () => now.add(const Duration(minutes: 3)),
      );
      addTearDown(() => _disposeLivingController(controller));
      await controller.initialize();

      final handle = await controller.retryPortrait();
      final duplicate = await controller.retryPortrait();

      expect(handle, isNotNull);
      expect(duplicate, same(handle));
      expect(calls, 1);
      expect(controller.isPortraitRunning, isTrue);
      expect(controller.canContinueStory, isFalse);
      expect(controller.canStartNewRun, isFalse);
      expect(controller.canAbandonActiveRun, isFalse);
      expect(controller.portraitStatusLabel, 'A NEW FACE EMERGES');

      final checkpoint = source
          .portraitCheckpointsByCharacterId['char_generated_rook']!
          .copyWith(
            status: LivingPortraitStatus.ready,
            updatedAt: now.add(const Duration(minutes: 4)),
            processedReference: 'memory://portrait.png',
            clearFailure: true,
          );
      result.complete(
        LivingGenerationResult(
          run: source.copyWith(
            updatedAt: now.add(const Duration(minutes: 4)),
            clearGenerationJob: true,
            portraitCheckpointsByCharacterId:
                <String, LivingPortraitCheckpoint>{
                  checkpoint.characterId: checkpoint,
                },
          ),
          completed: true,
        ),
      );
      await handle!.completion;

      expect(controller.isGenerationRunning, isFalse);
      expect(controller.canContinueStory, isTrue);
      expect(controller.hasPortraitAttention, isFalse);
    },
  );

  test(
    'continue commits once, starts closure text and art together, then reveals the ending',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-chapter-art-flow-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final now = DateTime.utc(2026, 8, 11, 1);
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-chapter-art-flow',
        now: now,
      );
      final outcome = _fixedOutcome(run);
      final textCompletion = Completer<LivingGenerationResult>();
      final artCompletion = Completer<LivingGenerationResult>();
      LivingCampaignRun? committedRequest;
      var textCalls = 0;
      var artCalls = 0;
      final game = GameController();
      addTearDown(game.dispose);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        generateChapterClosureText: (committed, requestedOutcome) {
          textCalls++;
          committedRequest = committed;
          expect(requestedOutcome.chapterId, outcome.chapterId);
          return textCompletion.future;
        },
        generateChapterArt: (committed, requestedOutcome) {
          artCalls++;
          committedRequest = committed;
          expect(requestedOutcome.chapterId, outcome.chapterId);
          return artCompletion.future;
        },
        clock: () => now,
      );
      addTearDown(() => _disposeLivingController(controller));
      await controller.initialize();
      controller
        ..activeRun = run
        ..pendingOutcome = outcome
        ..phase = LivingCampaignPhase.outcomeAcknowledgement;

      await controller.continueFromOutcome();
      while (textCalls == 0 || artCalls == 0) {
        await Future<void>.delayed(Duration.zero);
      }

      expect(controller.phase, LivingCampaignPhase.chapterClosureLoading);
      expect(controller.isChapterClosureTextRunning, isTrue);
      expect(controller.isChapterArtRunning, isTrue);
      expect(controller.isPaidRequestRunning, isTrue);
      expect(controller.canStartNewRun, isFalse);
      expect(
        committedRequest!.battleOutcomes.single.chapterId,
        outcome.chapterId,
      );
      expect(committedRequest!.v2GenerationCheckpoint, isNotNull);
      await controller.continueFromOutcome();
      expect(textCalls, 1);
      expect(artCalls, 1);

      final textReady = _closureTextReady(
        committedRequest!,
        outcome: outcome,
        now: now,
      );
      await archive.writeRun(textReady);
      textCompletion.complete(
        LivingGenerationResult(run: textReady, completed: true),
      );
      while (controller.phase != LivingCampaignPhase.aftermathDialogue) {
        await Future<void>.delayed(Duration.zero);
      }
      while (controller.isChapterClosureTextRunning) {
        await Future<void>.delayed(Duration.zero);
      }

      final checkpoint = LivingChapterEndingArtCheckpoint(
        runId: run.runId,
        chapterId: outcome.chapterId,
        chapterNumber: outcome.chapterNumber,
        attempt: 1,
        seed: LivingChapterArtSeed.derive(
          runId: run.runId,
          chapterId: outcome.chapterId,
          attempt: 1,
        ),
        status: LivingChapterArtStatus.ready,
        promptAsset: 'assets/prompts/living_campaign/chapter_ending_art.md',
        processedReference: 'memory://chapter-ending.png',
        createdAt: now,
        updatedAt: now,
      );
      final latest = (await archive.readRun(run.runId))!;
      final closure = latest
          .chapterClosureCheckpointsByChapterId[outcome.chapterId]!
          .copyWith(
            imageStatus: LivingClosureTaskStatus.ready,
            updatedAt: now,
            clearImageFailure: true,
          );
      final artReady = latest.copyWith(
        chapterClosureCheckpointsByChapterId:
            <String, LivingChapterClosureCheckpoint>{
              outcome.chapterId: closure,
            },
        chapterArtCheckpointsByChapterId:
            <String, LivingChapterEndingArtCheckpoint>{
              outcome.chapterId: checkpoint,
            },
      );
      await archive.writeRun(artReady);
      artCompletion.complete(
        LivingGenerationResult(run: artReady, completed: true),
      );
      while (controller.isChapterArtRunning) {
        await Future<void>.delayed(Duration.zero);
      }
      controller.advanceAftermath();

      expect(controller.phase, LivingCampaignPhase.chapterEnding);
      expect(controller.isChapterArtRunning, isFalse);
      expect(
        controller.activeChapterArtCheckpoint?.status,
        LivingChapterArtStatus.ready,
      );
      expect(controller.pendingOutcome?.chapterId, outcome.chapterId);
    },
  );

  test(
    'relaunch turns in-flight chapter art into explicit retry fallback',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-chapter-art-relaunch-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final now = DateTime.utc(2026, 8, 11, 2);
      final committed = _committedRun(
        runId: 'run-chapter-art-relaunch',
        now: now,
      );
      final outcome = committed.battleOutcomes.single;
      await archive.writeRun(
        committed.copyWith(
          chapterArtCheckpointsByChapterId:
              <String, LivingChapterEndingArtCheckpoint>{
                outcome.chapterId: LivingChapterEndingArtCheckpoint(
                  runId: committed.runId,
                  chapterId: outcome.chapterId,
                  chapterNumber: outcome.chapterNumber,
                  attempt: 1,
                  seed: 42,
                  status: LivingChapterArtStatus.generating,
                  promptAsset:
                      'assets/prompts/living_campaign/chapter_ending_art.md',
                  createdAt: now,
                  updatedAt: now,
                ),
              },
        ),
      );
      final game = GameController();
      addTearDown(game.dispose);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        clock: () => now.add(const Duration(minutes: 3)),
      );
      addTearDown(() => _disposeLivingController(controller));

      await controller.initialize();

      expect(controller.phase, LivingCampaignPhase.chapterEnding);
      expect(controller.pendingOutcome?.chapterId, outcome.chapterId);
      expect(
        controller.activeChapterArtCheckpoint?.status,
        LivingChapterArtStatus.awaitingRetry,
      );
      expect(controller.activeChapterArtCheckpoint?.errorCode, 'interrupted');
      expect(controller.isPaidRequestRunning, isFalse);
    },
  );

  test('art-first closure waits for words before showing aftermath', () async {
    final temp = await Directory.systemTemp.createTemp(
      'living-closure-art-first-',
    );
    addTearDown(() => temp.delete(recursive: true));
    final archive = IoLivingCampaignArchiveStore(
      rootProvider: () async => temp,
    );
    final now = DateTime.utc(2026, 8, 11, 3);
    final run = LivingCampaignFixedOpener.create(
      runId: 'run-closure-art-first',
      now: now,
    );
    final outcome = _fixedOutcome(run);
    final textCompletion = Completer<LivingGenerationResult>();
    final artCompletion = Completer<LivingGenerationResult>();
    final game = GameController();
    addTearDown(game.dispose);
    final controller = LivingCampaignController(
      gameController: game,
      archive: archive,
      generatePrologue: (run) async =>
          LivingGenerationResult(run: run, completed: false),
      generateNextChapter: (run, outcome) async =>
          LivingGenerationResult(run: run, completed: false),
      generateChapterClosureText: (run, outcome) => textCompletion.future,
      generateChapterArt: (run, outcome) => artCompletion.future,
      clock: () => now,
    );
    addTearDown(() => _disposeLivingController(controller));
    await controller.initialize();
    controller
      ..activeRun = run
      ..pendingOutcome = outcome
      ..phase = LivingCampaignPhase.outcomeAcknowledgement;

    await controller.continueFromOutcome();
    final prepared = (await archive.readRun(run.runId))!;
    final pendingClosure =
        prepared.chapterClosureCheckpointsByChapterId[outcome.chapterId]!;
    final artCheckpoint = LivingChapterEndingArtCheckpoint(
      runId: run.runId,
      chapterId: outcome.chapterId,
      chapterNumber: outcome.chapterNumber,
      attempt: 1,
      seed: 42,
      status: LivingChapterArtStatus.ready,
      promptAsset: 'assets/prompts/living_campaign/chapter_ending_art.md',
      processedReference: 'memory://art-first.webp',
      createdAt: now,
      updatedAt: now,
    );
    final artReady = prepared.copyWith(
      chapterClosureCheckpointsByChapterId:
          <String, LivingChapterClosureCheckpoint>{
            outcome.chapterId: pendingClosure.copyWith(
              imageStatus: LivingClosureTaskStatus.ready,
              updatedAt: now,
            ),
          },
      chapterArtCheckpointsByChapterId:
          <String, LivingChapterEndingArtCheckpoint>{
            outcome.chapterId: artCheckpoint,
          },
    );
    await archive.writeRun(artReady);
    artCompletion.complete(
      LivingGenerationResult(run: artReady, completed: true),
    );
    while (controller.isChapterArtRunning) {
      await Future<void>.delayed(Duration.zero);
    }

    expect(controller.phase, LivingCampaignPhase.chapterClosureLoading);
    expect(controller.isChapterClosureTextRunning, isTrue);

    final latest = (await archive.readRun(run.runId))!;
    final textReady = _closureTextReady(latest, outcome: outcome, now: now);
    await archive.writeRun(textReady);
    textCompletion.complete(
      LivingGenerationResult(run: textReady, completed: true),
    );
    while (controller.isChapterClosureTextRunning) {
      await Future<void>.delayed(Duration.zero);
    }

    expect(controller.phase, LivingCampaignPhase.aftermathDialogue);
    controller.skipAftermath();
    expect(controller.phase, LivingCampaignPhase.chapterEnding);
  });

  test(
    'aftermath hides provider art failures behind story-world copy',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-closure-story-warning-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final now = DateTime.utc(2026, 8, 11, 3, 30);
      final committed = _committedRun(
        runId: 'run-closure-story-warning',
        now: now,
      );
      final outcome = committed.battleOutcomes.single;
      final textReady = _closureTextReady(
        committed,
        outcome: outcome,
        now: now,
      );
      final closure = textReady
          .chapterClosureCheckpointsByChapterId[outcome.chapterId]!
          .copyWith(
            imageStatus: LivingClosureTaskStatus.awaitingRetry,
            imageErrorCode: 'provider_timeout',
            imageErrorMessage: 'Ark timed out while painting the final scene.',
            updatedAt: now,
          );
      final run = textReady.copyWith(
        chapterClosureCheckpointsByChapterId:
            <String, LivingChapterClosureCheckpoint>{
              outcome.chapterId: closure,
            },
      );
      final game = GameController();
      addTearDown(game.dispose);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        clock: () => now,
      );
      addTearDown(() => _disposeLivingController(controller));
      await controller.initialize();
      controller
        ..activeRun = run
        ..pendingOutcome = outcome
        ..phase = LivingCampaignPhase.aftermathDialogue;

      controller.skipAftermath();

      expect(controller.phase, LivingCampaignPhase.chapterEnding);
      expect(controller.message, 'The final moment remains beyond sight.');
      expect(controller.message, isNot(contains('Ark')));
      expect(controller.message, isNot(contains('painting')));
    },
  );

  test('relaunch interrupts both closure children without retrying', () async {
    final temp = await Directory.systemTemp.createTemp(
      'living-closure-relaunch-',
    );
    addTearDown(() => temp.delete(recursive: true));
    final archive = IoLivingCampaignArchiveStore(
      rootProvider: () async => temp,
    );
    final now = DateTime.utc(2026, 8, 11, 4);
    final committed = _committedRun(runId: 'run-closure-relaunch', now: now);
    final outcome = committed.battleOutcomes.single;
    final closure = LivingChapterClosureCheckpoint(
      runId: committed.runId,
      chapterId: outcome.chapterId,
      chapterNumber: outcome.chapterNumber,
      closureId: 'closure-relaunch',
      textTaskId: 'text-relaunch',
      imageTaskId: 'image-relaunch',
      textAttempt: 1,
      imageAttempt: 1,
      textStatus: LivingClosureTaskStatus.running,
      imageStatus: LivingClosureTaskStatus.running,
      createdAt: now,
      updatedAt: now,
    );
    await archive.writeRun(
      committed.copyWith(
        chapterClosureCheckpointsByChapterId:
            <String, LivingChapterClosureCheckpoint>{
              outcome.chapterId: closure,
            },
        chapterArtCheckpointsByChapterId:
            <String, LivingChapterEndingArtCheckpoint>{
              outcome.chapterId: LivingChapterEndingArtCheckpoint(
                runId: committed.runId,
                chapterId: outcome.chapterId,
                chapterNumber: outcome.chapterNumber,
                attempt: 1,
                seed: 42,
                status: LivingChapterArtStatus.generating,
                promptAsset:
                    'assets/prompts/living_campaign/chapter_ending_art.md',
                createdAt: now,
                updatedAt: now,
              ),
            },
      ),
    );
    var textCalls = 0;
    var artCalls = 0;
    final game = GameController();
    addTearDown(game.dispose);
    final controller = LivingCampaignController(
      gameController: game,
      archive: archive,
      generatePrologue: (run) async =>
          LivingGenerationResult(run: run, completed: false),
      generateNextChapter: (run, outcome) async =>
          LivingGenerationResult(run: run, completed: false),
      generateChapterClosureText: (run, outcome) async {
        textCalls++;
        return LivingGenerationResult(run: run, completed: false);
      },
      generateChapterArt: (run, outcome) async {
        artCalls++;
        return LivingGenerationResult(run: run, completed: false);
      },
      clock: () => now.add(const Duration(minutes: 1)),
    );
    addTearDown(() => _disposeLivingController(controller));

    await controller.initialize();

    final restored = controller
        .activeRun!
        .chapterClosureCheckpointsByChapterId[outcome.chapterId]!;
    expect(restored.textStatus, LivingClosureTaskStatus.awaitingRetry);
    expect(restored.imageStatus, LivingClosureTaskStatus.awaitingRetry);
    expect(
      controller.activeChapterArtCheckpoint?.status,
      LivingChapterArtStatus.awaitingRetry,
    );
    expect(controller.phase, LivingCampaignPhase.chapterEnding);
    expect(textCalls, 0);
    expect(artCalls, 0);
  });

  test('fixed M01 is the opening gate and needs no generated prose', () async {
    final temp = await Directory.systemTemp.createTemp('living-opening-gate-');
    addTearDown(() => temp.delete(recursive: true));
    final archive = IoLivingCampaignArchiveStore(
      rootProvider: () async => temp,
    );
    final game = GameController();
    addTearDown(game.dispose);
    final controller = LivingCampaignController(
      gameController: game,
      archive: archive,
      generatePrologue: (run) async =>
          LivingGenerationResult(run: run, completed: false),
      generateNextChapter: (run, outcome) async =>
          LivingGenerationResult(run: run, completed: false),
    );
    addTearDown(() => _disposeLivingController(controller));
    await controller.initialize();
    controller.activeRun = LivingCampaignFixedOpener.create(
      runId: 'fixed-opening',
      now: DateTime.utc(2026, 8, 6),
    );

    expect(controller.openingReady, isTrue);
    expect(controller.canContinueStory, isTrue);
    controller.openActiveRun();
    expect(controller.phase, LivingCampaignPhase.prologue);
  });

  test(
    'one background task snapshots settings and completion preserves navigation',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-async-race-');
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final game = GameController();
      addTearDown(game.dispose);
      final generation = Completer<LivingGenerationResult>();
      var factoryCalls = 0;
      var generationCalls = 0;
      var model = 'model-before-start';
      LivingCampaignRun? requestedRun;
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        snapshotNextChapterGenerator: () {
          factoryCalls++;
          final capturedModel = model;
          return (run, outcome) {
            generationCalls++;
            requestedRun = run;
            expect(capturedModel, 'model-before-start');
            return generation.future;
          };
        },
        generationSettingsSnapshot: () => <String, Object?>{'model': model},
      );
      addTearDown(() => _disposeLivingController(controller));
      await controller.initialize();

      await controller.startNewRun();
      final outcome = _fixedOutcome(controller.activeRun!);
      final committed = const LivingCampaignOutcomeReducer().apply(
        run: controller.activeRun!,
        outcome: outcome,
        now: DateTime.utc(2026, 8, 11),
      );
      final ready = _closureTextReady(
        committed,
        outcome: outcome,
        now: DateTime.utc(2026, 8, 11),
      );
      await archive.writeRun(ready);
      controller
        ..activeRun = ready
        ..pendingOutcome = outcome;
      final firstHandle = await controller.generateFollowingChapter();
      model = 'model-after-start';
      final duplicateHandle = await controller.generateFollowingChapter();

      expect(factoryCalls, 1);
      expect(generationCalls, 1);
      expect(duplicateHandle, same(firstHandle));
      expect(controller.isGenerationRunning, isTrue);
      expect(
        controller.activeRun!.generationJob!.settingsSnapshot['model'],
        'model-before-start',
      );
      final archived = await archive.readRun(controller.activeRun!.runId);
      expect(
        archived!.generationJob!.settingsSnapshot['model'],
        'model-before-start',
      );

      controller.phase = LivingCampaignPhase.history;
      generation.complete(
        LivingGenerationResult(
          run: _completeWithGeneratedMission(requestedRun!),
          completed: true,
        ),
      );
      await firstHandle!.completion;

      expect(controller.phase, LivingCampaignPhase.history);
      expect(controller.directorStatus, LivingDirectorStatus.ready);
      expect(controller.directorNoticeSerial, 1);
    },
  );

  test(
    'explicit retry returns before the replacement request completes',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-retry-');
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final now = DateTime.utc(2026, 8, 5, 8);
      final source = _committedRun(runId: 'run-retry', now: now).copyWith(
        generationJob: LivingGenerationJob(
          jobId: 'old-job',
          stage: LivingGenerationStage.chronicler,
          status: LivingGenerationStatus.awaitingResume,
          attempt: 1,
          createdAt: now,
          updatedAt: now,
          errorCode: 'stream_idle_timeout',
          errorMessage: 'The stream stopped.',
        ),
      );
      await archive.writeRun(source);
      final game = GameController();
      addTearDown(game.dispose);
      final generation = Completer<LivingGenerationResult>();
      LivingCampaignRun? requestedRun;
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) {
          requestedRun = run;
          return generation.future;
        },
        clock: () => now.add(const Duration(minutes: 3)),
      );
      addTearDown(() => _disposeLivingController(controller));
      await controller.initialize();

      final handle = await controller.resumeGeneration();

      expect(controller.phase, LivingCampaignPhase.hub);
      expect(controller.isGenerationRunning, isTrue);
      expect(handle, isNotNull);
      expect(controller.activeRun!.generationJob!.jobId, isNot('old-job'));
      expect(controller.retryGenerationLabel, 'Recall the Battle Again');
      await Future<void>.delayed(Duration.zero);

      generation.complete(
        LivingGenerationResult(
          run: _completeWithGeneratedMission(requestedRun!),
          completed: true,
        ),
      );
      await handle!.completion;
      expect(controller.canContinueStory, isTrue);
    },
  );

  test(
    'stale progress is ignored and disposal leaves durable explicit recovery',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-disposal-recovery-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final game = GameController();
      addTearDown(game.dispose);
      final generation = Completer<LivingGenerationResult>();
      LivingCampaignRun? requestedRun;
      final now = DateTime.utc(2026, 8, 6, 10);
      final source = _committedRun(runId: 'run-disposal-recovery', now: now);
      await archive.writeRun(source);
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) {
          requestedRun = run;
          return generation.future;
        },
        clock: () => now,
      );
      await controller.initialize();
      controller.activeRun = source.copyWith(
        generationJob: LivingGenerationJob(
          jobId: 'interrupted-before-test',
          stage: LivingGenerationStage.chronicler,
          status: LivingGenerationStatus.awaitingResume,
          attempt: 1,
          createdAt: now,
          updatedAt: now,
        ),
      );
      final handle = await controller.resumeGeneration();
      expect(handle, isNotNull);
      await Future<void>.delayed(Duration.zero);

      final accepted = requestedRun!;
      final staleJobJson = accepted.generationJob!.toJson()
        ..['jobId'] = 'stale-job';
      final stale = accepted.copyWith(
        generationJob: LivingGenerationJob.fromJson(staleJobJson),
      );
      controller.acceptGenerationProgress(stale);
      expect(controller.activeRun!.generationJob!.jobId, handle!.jobId);

      final progress = <LivingCampaignRun>[];
      final subscription = handle.onProgress(progress.add);
      addTearDown(subscription.cancel);
      final matching = accepted.copyWith(
        generationJob: accepted.generationJob!.copyWith(
          lastActivityAt: now.add(const Duration(seconds: 1)),
          receivedContentCharacters: 42,
        ),
      );
      controller.acceptGenerationProgress(matching);
      expect(progress.single.generationJob!.receivedContentCharacters, 42);

      await _disposeLivingController(controller);
      generation.complete(
        LivingGenerationResult(
          run: _completeWithGeneratedMission(accepted),
          completed: true,
        ),
      );
      await handle.completion;

      final persisted = await archive.readRun(accepted.runId);
      expect(persisted!.generationJob!.status, LivingGenerationStatus.running);

      final restartedGame = GameController();
      addTearDown(restartedGame.dispose);
      final restarted = LivingCampaignController(
        gameController: restartedGame,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) async =>
            LivingGenerationResult(run: run, completed: false),
        clock: () => now.add(const Duration(minutes: 1)),
      );
      addTearDown(() => _disposeLivingController(restarted));
      await restarted.initialize();
      expect(
        restarted.activeRun!.generationJob!.status,
        LivingGenerationStatus.awaitingResume,
      );
      expect(restarted.retryGenerationLabel, 'Recall the Battle Again');
    },
  );

  test(
    'a failed explicit retry never auto-retries and can be retried again',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-failed-retry-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final now = DateTime.utc(2026, 8, 6, 11);
      final source = _committedRun(runId: 'run-failed-retry', now: now)
          .copyWith(
            generationJob: LivingGenerationJob(
              jobId: 'interrupted-job',
              stage: LivingGenerationStage.chronicler,
              status: LivingGenerationStatus.awaitingResume,
              attempt: 1,
              createdAt: now,
              updatedAt: now,
            ),
          );
      await archive.writeRun(source);
      final game = GameController();
      addTearDown(game.dispose);
      var calls = 0;
      final controller = LivingCampaignController(
        gameController: game,
        archive: archive,
        generatePrologue: (run) async =>
            LivingGenerationResult(run: run, completed: false),
        generateNextChapter: (run, outcome) async {
          calls++;
          if (calls == 1) {
            return LivingGenerationResult(
              run: run.copyWith(
                generationJob: run.generationJob!.copyWith(
                  status: LivingGenerationStatus.awaitingResume,
                  errorCode: 'stream_incomplete',
                  errorMessage: 'The retry ended before DONE.',
                ),
              ),
              completed: false,
              message: 'The retry ended before DONE.',
            );
          }
          return LivingGenerationResult(
            run: _completeWithGeneratedMission(run),
            completed: true,
          );
        },
        clock: () => now.add(const Duration(minutes: 5)),
      );
      addTearDown(() => _disposeLivingController(controller));
      await controller.initialize();

      final failedHandle = await controller.resumeGeneration();
      await failedHandle!.completion;
      expect(calls, 1);
      expect(controller.isGenerationRunning, isFalse);
      expect(controller.directorStatus, LivingDirectorStatus.interrupted);
      expect(
        controller.activeRun!.generationJob!.errorCode,
        'stream_incomplete',
      );

      final successfulHandle = await controller.resumeGeneration();
      expect(successfulHandle!.jobId, isNot(failedHandle.jobId));
      await successfulHandle.completion;
      expect(calls, 2);
      expect(controller.directorStatus, LivingDirectorStatus.ready);
    },
  );

  test('completed and abandoned archives can be inspected locally', () async {
    final temp = await Directory.systemTemp.createTemp('living-inspect-');
    addTearDown(() => temp.delete(recursive: true));
    final archive = IoLivingCampaignArchiveStore(
      rootProvider: () async => temp,
    );
    final now = DateTime.utc(2026, 8, 6);
    final archived = LivingCampaignFixedOpener.create(
      runId: 'run-archived',
      now: now,
    ).copyWith(status: LivingRunStatus.abandoned, completedAt: now);
    await archive.writeRun(archived);
    final game = GameController();
    addTearDown(game.dispose);
    final controller = LivingCampaignController(
      gameController: game,
      archive: archive,
      generatePrologue: (run) async =>
          LivingGenerationResult(run: run, completed: false),
      generateNextChapter: (run, outcome) async =>
          LivingGenerationResult(run: run, completed: false),
    );
    addTearDown(() => _disposeLivingController(controller));

    await controller.initialize();
    expect(controller.storageBytes, greaterThan(0));
    await controller.inspectRun(archived.runId);

    expect(controller.phase, LivingCampaignPhase.history);
    expect(controller.inspectedRun!.runId, archived.runId);
    expect(controller.inspectedRun!.status, LivingRunStatus.abandoned);
    controller.closeHistory();
    expect(controller.phase, LivingCampaignPhase.hub);
  });

  test(
    'reach accepts any advanced ally and survival uses complete rounds',
    () async {
      final reach = await _runtimeController(
        objective: const LivingMissionObjective(
          type: LivingObjectiveType.reachEscape,
          label: 'Reach b1.',
          targetSquare: Square(7, 1),
        ),
      );
      reach.gameController.makeMove(
        const ChessMove(from: Square(7, 0), to: Square(7, 1)),
      );
      reach.evaluateAfterPresentation();
      expect(reach.pendingOutcome?.objectiveCompleted, isTrue);
      expect(reach.pendingOutcome?.completedTurns, 1);

      final survive = await _runtimeController(
        objective: const LivingMissionObjective(
          type: LivingObjectiveType.surviveRounds,
          label: 'Survive one full round.',
          surviveRounds: 1,
        ),
      );
      survive.gameController.makeMove(
        const ChessMove(from: Square(7, 0), to: Square(7, 1)),
      );
      survive.evaluateAfterPresentation();
      expect(survive.phase, LivingCampaignPhase.battle);
      expect(survive.gameController.completedActionCount, 1);
      expect(survive.gameController.completedRoundCount, 0);
      survive.gameController.makeMove(
        const ChessMove(from: Square(0, 4), to: Square(0, 5)),
      );
      survive.evaluateAfterPresentation();
      expect(survive.pendingOutcome?.objectiveCompleted, isTrue);
      expect(survive.pendingOutcome?.completedTurns, 2);
      expect(survive.pendingOutcome?.completedRoundCount, 1);
    },
  );

  test(
    'neutralize requires the marked target capture or purchase event',
    () async {
      final controller = await _runtimeController(
        objective: const LivingMissionObjective(
          type: LivingObjectiveType.neutralizeTarget,
          label: 'Neutralize the marked pawn.',
          targetPieceId: 'marked_pawn',
        ),
      );
      controller.gameController.board[6][0] = null;
      controller.evaluateAfterPresentation();
      expect(controller.phase, LivingCampaignPhase.battle);

      controller.retryBattle();
      controller.gameController.makeMove(
        const ChessMove(from: Square(7, 0), to: Square(6, 0)),
      );
      controller.evaluateAfterPresentation();
      expect(controller.pendingOutcome?.objectiveCompleted, isTrue);
      expect(
        controller.pendingOutcome?.capturedPieces.single.pieceId,
        'marked_pawn',
      );
    },
  );

  test('rescue requires purchase plus legal extraction', () async {
    final controller = await _runtimeController(
      objective: const LivingMissionObjective(
        type: LivingObjectiveType.rescueRecover,
        label: 'Recover the marked pawn at b1.',
        targetSquare: Square(7, 1),
        targetPieceId: 'marked_pawn',
      ),
      targetLoyalty: 0,
    );
    final game = controller.gameController;
    game.selectedSquare = const Square(6, 0);
    game.openOfferForSelected();
    game.setOfferGold(1);
    game.confirmOffer();
    game.dismissLastOfferResult();
    game.placeRedeploy(const Square(7, 1));
    controller.evaluateAfterPresentation();

    expect(controller.pendingOutcome?.objectiveCompleted, isTrue);
    expect(
      controller.pendingOutcome?.purchasedPieceIds,
      contains('marked_pawn'),
    );
    expect(controller.pendingOutcome?.completedTurns, 1);
  });

  test(
    'player King Trapfall overrides a simultaneously satisfied objective',
    () async {
      final controller = await _runtimeController(
        objective: const LivingMissionObjective(
          type: LivingObjectiveType.reachEscape,
          label: 'Hold a1.',
          targetSquare: Square(7, 0),
          targetPieceId: 'ashen_rook_ysra',
        ),
      );
      final game = controller.gameController;
      game.board[7][4] = null;
      game.completedActionCount = 1;
      game.lastBattlefieldEvent = const BattlefieldEvent(
        serial: 1,
        type: BattlefieldEventType.trapTriggered,
        message: 'The player King fell into a trap.',
        pieceColor: PieceColor.white,
        pieceId: 'ashen_king_orsain',
      );
      game
        ..winner = PieceColor.black
        ..gameEndReason = GameEndReason.kingTrapfall
        ..phase = GamePhase.gameOver;
      controller.evaluateAfterPresentation();

      expect(controller.pendingOutcome?.result, LivingBattleResult.defeat);
      expect(controller.pendingOutcome?.objectiveCompleted, isFalse);
      expect(
        controller.pendingOutcome?.kingTrapfallPieceId,
        'ashen_king_orsain',
      );
    },
  );

  test('generated enemy offer pauses then transforms in place', () async {
    final engine = FakeChessEngine(defaultMove: 'e8d8');
    final controller = await _runtimeController(
      objective: const LivingMissionObjective(
        type: LivingObjectiveType.surviveRounds,
        label: 'Survive eight completed actions.',
        surviveRounds: 8,
      ),
      startingTurn: PieceColor.black,
      targetLoyalty: 0,
      playerRookLoyalty: 0,
      seed: _seedForFirstPurchaseRoll(hit: true),
      moveEngine: engine,
    );
    final game = controller.gameController;
    const originalSquare = Square(7, 0);

    await controller.makeEnemyMove();

    expect(game.lastOfferResult?.success, isTrue);
    expect(game.phase, GamePhase.redeploy);
    expect(game.turn, PieceColor.black);
    expect(game.pieceAt(originalSquare), isNull);
    expect(engine.requests, isEmpty);

    final resolution = game.resolvePendingPurchaseInPlace();

    expect(resolution, AiRedeployResolution.inPlace);
    expect(game.phase, GamePhase.playing);
    expect(game.turn, PieceColor.white);
    expect(game.pieceAt(originalSquare)?.id, 'ashen_rook_ysra');
    expect(game.pieceAt(originalSquare)?.color, PieceColor.black);
    expect(game.lastBetrayalTransformEvent?.after.id, 'ashen_rook_ysra');
    expect(game.lastBoardMotionEvent, isNull);
    controller.debugResolveActiveBattleAsVictory();
    final purchase = controller.pendingOutcome!.purchaseEvents.single;
    expect(purchase.pieceId, 'ashen_rook_ysra');
    expect(purchase.fromAllegiance, LivingAllegiance.player);
    expect(purchase.toAllegiance, LivingAllegiance.enemy);
    expect(purchase.characterId, 'char_ysra');
  });

  test('purchase miss requests Chapter 1 Stockfish at 1320 Elo', () async {
    final engine = FakeChessEngine(defaultMove: 'e8d8');
    final controller = await _runtimeController(
      objective: const LivingMissionObjective(
        type: LivingObjectiveType.surviveRounds,
        label: 'Survive eight completed actions.',
        surviveRounds: 8,
      ),
      startingTurn: PieceColor.black,
      seed: _seedForFirstPurchaseRoll(hit: false),
      moveEngine: engine,
    );

    await controller.makeEnemyMove();

    expect(engine.newGameCalls, 1);
    expect(engine.requests, hasLength(1));
    expect(engine.requests.single.targetElo, 1320);
    expect(controller.gameController.turn, PieceColor.white);
  });

  test('Living strength grows through Chapter 19 then becomes full', () {
    expect(LivingCampaignController.livingCampaignTargetElo(1), 1320);
    expect(LivingCampaignController.livingCampaignTargetElo(8), 2020);
    expect(LivingCampaignController.livingCampaignTargetElo(19), 3120);
    expect(LivingCampaignController.livingCampaignTargetElo(20), isNull);
    expect(LivingCampaignController.livingCampaignTargetElo(200), isNull);
  });

  test('Stockfish request excludes an avoidable visible Trap', () async {
    final engine = FakeChessEngine(defaultMove: 'e8f8');
    final controller = await _runtimeController(
      objective: const LivingMissionObjective(
        type: LivingObjectiveType.surviveRounds,
        label: 'Survive eight completed actions.',
        surviveRounds: 8,
      ),
      startingTurn: PieceColor.black,
      seed: _seedForFirstPurchaseRoll(hit: false),
      moveEngine: engine,
    );
    controller.gameController
        .replaceSpecialTilesForTesting(const <SpecialTileState>[
          SpecialTileState(
            square: Square(0, 3),
            type: SpecialTileType.visibleTrap,
            pairId: 1,
          ),
        ]);

    await controller.makeEnemyMove();

    expect(engine.requests.single.legalMoves, isNot(contains('e8d8')));
    expect(engine.requests.single.legalMoves, contains('e8f8'));
  });

  test('stale Stockfish response is rejected without moving', () async {
    late LivingCampaignController controller;
    final engine = FakeChessEngine(defaultMove: 'e8d8')
      ..onBestMove = (_) async {
        controller.gameController.turn = PieceColor.white;
        return const EngineMove(uci: 'e8d8');
      };
    controller = await _runtimeController(
      objective: const LivingMissionObjective(
        type: LivingObjectiveType.surviveRounds,
        label: 'Survive eight completed actions.',
        surviveRounds: 8,
      ),
      startingTurn: PieceColor.black,
      seed: _seedForFirstPurchaseRoll(hit: false),
      moveEngine: engine,
    );

    await controller.makeEnemyMove();

    expect(engine.requests, hasLength(1));
    expect(
      controller.gameController.pieceAt(const Square(0, 4))?.id,
      'enemy_king',
    );
    expect(controller.gameController.pieceAt(const Square(0, 3)), isNull);
  });

  test(
    'Stockfish failure disables the engine for the rest of the battle',
    () async {
      final engine = FakeChessEngine(defaultMove: 'e8d8')
        ..onBestMove = (_) async => throw StateError('engine failed');
      final controller = await _runtimeController(
        objective: const LivingMissionObjective(
          type: LivingObjectiveType.surviveRounds,
          label: 'Survive eight completed actions.',
          surviveRounds: 8,
        ),
        startingTurn: PieceColor.black,
        seed: _seedForFirstPurchaseRoll(hit: false),
        moveEngine: engine,
      );

      await controller.makeEnemyMove();
      expect(engine.requests, hasLength(1));

      final game = controller.gameController;
      game
        ..economyEnabled = false
        ..turn = PieceColor.black
        ..phase = GamePhase.playing;
      await controller.makeEnemyMove();

      expect(engine.requests, hasLength(1));

      engine.onBestMove = null;
      controller.startBattle();
      controller.gameController.economyEnabled = false;
      await controller.makeEnemyMove();

      expect(engine.requests, hasLength(2));
      expect(engine.newGameCalls, 2);
    },
  );
}

LivingCampaignRun _committedRun({
  required String runId,
  required DateTime now,
}) {
  final run = LivingCampaignFixedOpener.create(runId: runId, now: now);
  return const LivingCampaignOutcomeReducer().apply(
    run: run,
    outcome: _fixedOutcome(run),
    now: now,
  );
}

LivingBattleOutcomeSnapshot _fixedOutcome(LivingCampaignRun run) =>
    LivingBattleOutcomeSnapshot(
      chapterNumber: 1,
      chapterId: 'living_m01',
      result: LivingBattleResult.victory,
      endReason: GameEndReason.checkmate,
      objectiveType: run.chapterPackages.first.objective.type,
      objectiveCompleted: true,
      completedTurns: 12,
      goldBefore: 10,
      goldAfterBattle: 12,
      survivingPieceIds: const <String>[
        'ashen_rook_ysra',
        'ashen_bishop_veyl',
        'ashen_king_orsain',
        'ashen_knight_cael',
      ],
      capturedPieces: const <LivingCapturedPieceOutcome>[],
      purchasedPieceIds: const <String>[],
      missionRoleChanges: const <String, PieceType>{},
      matchLog: const <String>[
        'Ysra opened the road while Orsain held the center.',
        'The enemy King was checkmated after twelve completed actions.',
      ],
    );

LivingCampaignRun _closureTextReady(
  LivingCampaignRun run, {
  required LivingBattleOutcomeSnapshot outcome,
  required DateTime now,
}) {
  final existing = run.chapterClosureCheckpointsByChapterId[outcome.chapterId];
  final checkpoint =
      existing ??
      LivingChapterClosureCheckpoint(
        runId: run.runId,
        chapterId: outcome.chapterId,
        chapterNumber: outcome.chapterNumber,
        closureId: 'closure_${outcome.chapterId}',
        textTaskId: 'closure_text_${outcome.chapterId}',
        imageTaskId: 'closure_image_${outcome.chapterId}',
        textAttempt: 1,
        imageAttempt: 1,
        textStatus: LivingClosureTaskStatus.ready,
        imageStatus: LivingClosureTaskStatus.ready,
        createdAt: now,
        updatedAt: now,
      );
  final memory = LivingMissionMemory(
    runId: run.runId,
    missionNumber: outcome.chapterNumber,
    missionId: outcome.chapterId,
    setupSummary: 'The Ashen Court contested the causeway and named its road.',
    battleSummary: 'The court won the road and counted the cost in silence.',
    characterIds: const <String>[
      'char_orsain',
      'char_ysra',
      'char_veyl',
      'char_cael',
    ],
    keyEventIds: <String>['${outcome.chapterId}_result'],
  );
  final closures = Map<String, LivingChapterClosureCheckpoint>.from(
    run.chapterClosureCheckpointsByChapterId,
  );
  closures[outcome.chapterId] = checkpoint.copyWith(
    textStatus: LivingClosureTaskStatus.ready,
    imageStatus: existing?.imageStatus ?? LivingClosureTaskStatus.ready,
    updatedAt: now,
    clearTextFailure: true,
  );
  return run.copyWith(
    updatedAt: now,
    missionMemories:
        run.missionMemories.any(
          (candidate) => candidate.missionId == outcome.chapterId,
        )
        ? run.missionMemories
        : <LivingMissionMemory>[...run.missionMemories, memory],
    aftermathScenesByChapterId: <String, LivingAftermathScene>{
      ...run.aftermathScenesByChapterId,
      outcome.chapterId: LivingAftermathScene(
        runId: run.runId,
        missionNumber: outcome.chapterNumber,
        missionId: outcome.chapterId,
        lines: const <LivingAftermathLine>[
          LivingAftermathLine(
            lineId: 'aftermath_01',
            speakerId: 'char_orsain',
            side: 'left',
            text: 'The road remembers every hand that held it.',
          ),
        ],
      ),
    },
    chapterClosureCheckpointsByChapterId: closures,
    v2GenerationCheckpoint:
        (run.v2GenerationCheckpoint ??
                LivingV2GenerationCheckpoint(
                  outcomeMissionId: outcome.chapterId,
                ))
            .copyWith(missionMemory: memory),
  );
}

LivingCampaignRun _portraitCheckpointRun({
  required String runId,
  required DateTime now,
  required LivingPortraitStatus status,
  LivingGenerationJob? generationJob,
}) {
  final committed = _committedRun(runId: runId, now: now);
  final ready = _completeWithGeneratedMission(committed);
  final checkpoint = LivingPortraitCheckpoint(
    runId: runId,
    missionId: 'living_m02',
    missionNumber: 2,
    characterId: 'char_generated_rook',
    attempt: 1,
    seed: 42,
    status: status,
    appearanceBrief: 'An unknown armored Rook commander.',
    promptAsset: 'assets/prompts/living_campaign/portrait.md',
    createdAt: now,
    updatedAt: now,
    errorCode: status == LivingPortraitStatus.awaitingRetry
        ? 'portrait_timeout'
        : null,
    errorMessage: status == LivingPortraitStatus.awaitingRetry
        ? 'Portrait timed out.'
        : null,
  );
  return ready.copyWith(
    generationJob: generationJob,
    portraitCheckpointsByCharacterId: <String, LivingPortraitCheckpoint>{
      checkpoint.characterId: checkpoint,
    },
  );
}

LivingCampaignRun _completeWithGeneratedMission(LivingCampaignRun run) {
  final json = Map<String, Object?>.from(run.chapterPackages.first.toJson())
    ..['basedOnRevision'] = run.canon.revision
    ..['chapterNumber'] = 2
    ..['chapterId'] = 'living_m02'
    ..['title'] = 'The Road Remembers'
    ..['subtitle'] = 'A generated mission waits without stealing focus.'
    ..['briefing'] = 'Secure the next crossing and preserve the court.'
    ..['portraitCharacterId'] = 'char_generated_rook'
    ..['portraitPrompt'] = 'An unknown armored Rook commander.';
  final chapter = LivingChapterPackage.fromJson(json);
  return run.copyWith(
    activeChapterNumber: 2,
    chapterPackages: <LivingChapterPackage>[...run.chapterPackages, chapter],
    clearGenerationJob: true,
    clearV2GenerationCheckpoint: true,
  );
}

Future<LivingCampaignController> _runtimeController({
  required LivingMissionObjective objective,
  PieceColor startingTurn = PieceColor.white,
  int targetLoyalty = 60,
  int playerRookLoyalty = 60,
  int seed = 41,
  int chapterNumber = 1,
  ChessEngine? moveEngine,
}) async {
  final temp = await Directory.systemTemp.createTemp('living-runtime-');
  final archive = IoLivingCampaignArchiveStore(rootProvider: () async => temp);
  final game = GameController();
  final now = DateTime.utc(2026, 8, 6, 9);
  final base = LivingCampaignFixedOpener.create(
    runId: 'runtime-${temp.path.hashCode.abs()}',
    now: now,
  );
  final chapter = LivingChapterPackage(
    schemaVersion: 1,
    runId: base.runId,
    basedOnRevision: 0,
    chapterNumber: chapterNumber,
    chapterId: 'runtime_chapter',
    title: 'Runtime Contract',
    subtitle: 'A focused objective test',
    briefing: 'Verify the generated battle contract.',
    objective: objective,
    whiteCountryId: 'ashen',
    blackCountryId: 'ashen',
    startingTurn: startingTurn,
    battlefieldId: BattlefieldId.classic,
    seed: seed,
    economyEnabled: true,
    merchantEnabled: false,
    specialTilesEnabled: false,
    whiteGold: 10,
    blackGold: 20,
    merchantSpeed: 4,
    pieces: <LivingMissionPiece>[
      const LivingMissionPiece(
        pieceId: 'ashen_king_orsain',
        pieceType: PieceType.king,
        color: PieceColor.white,
        square: Square(7, 4),
        countryId: 'ashen',
        loyalty: null,
        fairPrice: null,
        characterId: 'char_orsain',
      ),
      LivingMissionPiece(
        pieceId: 'ashen_rook_ysra',
        pieceType: PieceType.rook,
        color: PieceColor.white,
        square: const Square(7, 0),
        countryId: 'ashen',
        loyalty: playerRookLoyalty,
        fairPrice: 8,
        characterId: 'char_ysra',
      ),
      const LivingMissionPiece(
        pieceId: 'enemy_king',
        pieceType: PieceType.king,
        color: PieceColor.black,
        square: Square(0, 4),
        countryId: 'ashen',
        loyalty: null,
        fairPrice: null,
      ),
      LivingMissionPiece(
        pieceId: 'marked_pawn',
        pieceType: PieceType.pawn,
        color: PieceColor.black,
        square: const Square(6, 0),
        countryId: 'ashen',
        loyalty: targetLoyalty,
        fairPrice: 1,
      ),
    ],
    reservePieceIds: const <String>[],
    dialogue: const <LivingDialogueLine>[],
    aiAggression: 1,
    aiDefense: .5,
    aiObjectivePressure: 1,
    aiTileAppetite: .5,
  );
  final controller = LivingCampaignController(
    gameController: game,
    moveEngine: moveEngine,
    archive: archive,
    generatePrologue: (run) async =>
        LivingGenerationResult(run: run, completed: true),
    generateNextChapter: (run, outcome) async =>
        LivingGenerationResult(run: run, completed: false),
    clock: () => now,
  );
  await controller.initialize();
  controller.activeRun = base.copyWith(
    chapterPackages: <LivingChapterPackage>[chapter],
  );
  controller.startBattle();
  addTearDown(() async {
    await controller.flushTimingMetrics();
    controller.dispose();
    game.dispose();
    await moveEngine?.dispose();
    await temp.delete(recursive: true);
  });
  return controller;
}

int _seedForFirstPurchaseRoll({required bool hit}) {
  for (var seed = 0; seed < 10000; seed++) {
    if ((math.Random(seed).nextDouble() < .10) == hit) {
      return seed;
    }
  }
  throw StateError('Could not find a deterministic purchase seed.');
}

Future<void> _disposeLivingController(
  LivingCampaignController controller,
) async {
  await controller.flushTimingMetrics();
  controller.dispose();
}
