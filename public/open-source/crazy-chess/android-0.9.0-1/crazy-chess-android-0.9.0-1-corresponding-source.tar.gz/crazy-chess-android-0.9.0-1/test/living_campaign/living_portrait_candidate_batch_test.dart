@Tags(<String>['live'])
library;

import 'dart:convert';
import 'dart:io';

import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;

const _run = bool.fromEnvironment('RUN_LIVING_PORTRAIT_CANDIDATE_BATCH');
const _outputPath = String.fromEnvironment('LIVING_PORTRAIT_BATCH_OUTPUT');
const _sourceRoot = 'assets/generated/living_campaign/v2/candidates';
const _promptLedger =
    'test_result/20260810-003229_living-campaign-v2-portrait-generation/prompts.md';
const _json = JsonEncoder.withIndent('  ');

void main() {
  test(
    'processes and inventories all 22 GPT Image portrait candidates',
    () async {
      final output = Directory(p.absolute(_outputPath));
      expect(_outputPath, isNotEmpty);
      expect(p.isWithin(p.absolute('test_result'), output.path), isTrue);
      await output.create(recursive: true);

      final records = <Map<String, Object?>>[];
      for (final candidate in _candidates) {
        final source = File(
          p.join(
            _sourceRoot,
            candidate.directory,
            '${candidate.id}_source.png',
          ),
        );
        final record = <String, Object?>{
          'candidateId': candidate.id,
          'rootId': candidate.rootId,
          'rootLabel': candidate.rootLabel,
          'category': candidate.category,
          'variant': candidate.variant,
          'provider': 'gpt-image',
          'generationId': candidate.generationId,
          'promptLedger': _promptLedger,
          'promptAnchor': candidate.id,
          'sourcePath': source.path,
          'reviewStatus': 'awaiting_owner_selection',
        };
        try {
          final sourceBytes = await source.readAsBytes();
          final sourceImage = img.decodeImage(sourceBytes);
          record.addAll(<String, Object?>{
            'sourceSha256': sha256.convert(sourceBytes).toString(),
            'sourceWidth': sourceImage?.width,
            'sourceHeight': sourceImage?.height,
          });
          final processed = LivingPortraitProcessor().process(sourceBytes);
          final processedFile = File(
            p.join(source.parent.path, '${candidate.id}.png'),
          );
          await processedFile.writeAsBytes(processed.bytes, flush: true);
          final decoded = img.decodePng(processed.bytes)!;
          var transparent = 0;
          var opaqueMagenta = 0;
          for (final pixel in decoded) {
            if (pixel.a < 32) transparent++;
            if (pixel.a >= 32 &&
                pixel.r > 170 &&
                pixel.b > 170 &&
                pixel.g < 125) {
              opaqueMagenta++;
            }
          }
          final pixels = decoded.width * decoded.height;
          final magentaRatio = opaqueMagenta / pixels;
          record.addAll(<String, Object?>{
            'processedPath': processedFile.path,
            'processedSha256': sha256.convert(processed.bytes).toString(),
            'transparentRatio': transparent / pixels,
            'opaqueMagentaRatio': magentaRatio,
            'validationStatus': magentaRatio <= .001 ? 'valid' : 'invalid',
            if (magentaRatio > .001)
              'validationError':
                  'Opaque magenta spill exceeds the 0.1% review threshold.',
          });
        } on LivingProviderException catch (error) {
          record.addAll(<String, Object?>{
            'validationStatus': 'invalid',
            'validationErrorCode': error.code,
            'validationError': error.safeMessage,
          });
        } on Object catch (error) {
          record.addAll(<String, Object?>{
            'validationStatus': 'invalid',
            'validationErrorCode': 'candidate_processing_failed',
            'validationError': '$error',
          });
        }
        records.add(record);
      }

      final missing = records
          .where((record) => record['sourceSha256'] == null)
          .map((record) => record['candidateId'])
          .toList();
      final valid = records
          .where((record) => record['validationStatus'] == 'valid')
          .length;
      final report = <String, Object?>{
        'schemaVersion': 1,
        'collectionId': 'living_campaign_v2_portrait_candidates',
        'status': 'awaiting_owner_selection',
        'provider': 'gpt-image',
        'expectedCandidateCount': 22,
        'sourceCandidateCount': records.length - missing.length,
        'validCandidateCount': valid,
        'invalidCandidateCount': records.length - valid,
        'promotedCandidateCount': 0,
        'referencePaths': const <String>[
          'assets/runtime/pieces/characters/living/orsain_half_body.webp',
          'assets/runtime/pieces/characters/living/ysra_half_body.webp',
          'assets/runtime/pieces/characters/living/veyl_half_body.webp',
          'assets/runtime/pieces/characters/living/cael_half_body.webp',
        ],
        'referenceSha256': const <String>[
          'af39f6dfc61fa4034eebcbeaa9e65cee99496fadf9070949ca90fcba80402bd2',
          'ea773ea96500a3fffd79ceff9e9014b901aa152d675b573507ce1783bff9c6b9',
          'ff838a250942f5df56d4b3c800e1261a77c620ad0a8a984dbe647b127f3767b0',
          'bf105a4506297f6056bd67b972b432ac3f9d0da6ee1384db10d42b13e9562719',
        ],
        'promptLedger': _promptLedger,
        'missingCandidates': missing,
        'candidates': records,
      };
      await File(
        p.join(output.path, 'generation-records.json'),
      ).writeAsString('${_json.convert(report)}\n', flush: true);
      await _writeContactSheets(output, records, report);

      expect(records, hasLength(22));
      expect(missing, isEmpty);
    },
    skip: !_run,
  );
}

Future<void> _writeContactSheets(
  Directory output,
  List<Map<String, Object?>> records,
  Map<String, Object?> report,
) async {
  final markdown = StringBuffer()
    ..writeln('# Living Campaign V2 Portrait Candidate Review')
    ..writeln()
    ..writeln('Status: **AWAITING OWNER SELECTION**')
    ..writeln()
    ..writeln('- Sources retained: ${report['sourceCandidateCount']}/22')
    ..writeln(
      '- Deterministically processed: ${report['validCandidateCount']}/22',
    )
    ..writeln('- Validation warnings: ${report['invalidCandidateCount']}/22')
    ..writeln('- Promoted: 0')
    ..writeln()
    ..writeln(
      'Select one candidate for each fixed recruit and each fallback class. '
      'Candidates marked invalid remain preserved but must not be promoted.',
    );
  final htmlCards = StringBuffer();
  for (final root in _rootOrder) {
    final candidates = records.where((record) => record['rootId'] == root);
    final label = candidates.first['rootLabel'];
    markdown
      ..writeln()
      ..writeln('## $label')
      ..writeln();
    htmlCards.writeln(
      '<section><h2>${const HtmlEscape().convert('$label')}</h2><div class="grid">',
    );
    for (final record in candidates) {
      final valid = record['validationStatus'] == 'valid';
      final selectedPath = valid
          ? record['processedPath'] as String
          : record['sourcePath'] as String;
      final relative = p.relative(p.absolute(selectedPath), from: output.path);
      final id = record['candidateId'];
      final status = valid
          ? 'VALID · AWAITING SELECTION'
          : 'INVALID · REVIEW ONLY';
      markdown
        ..writeln('### ${record['variant']} — `$id`')
        ..writeln()
        ..writeln('![${record['rootLabel']} ${record['variant']}]($relative)')
        ..writeln()
        ..writeln('- Status: **$status**')
        ..writeln('- Generation: `${record['generationId']}`')
        ..writeln('- Source SHA-256: `${record['sourceSha256']}`');
      if (!valid) {
        markdown.writeln('- Validation: ${record['validationError']}');
      }
      final escapedLabel = const HtmlEscape().convert(
        '${record['variant']} · $status',
      );
      final escapedError = const HtmlEscape().convert(
        valid ? '' : '${record['validationError']}',
      );
      htmlCards.writeln(
        '<article class="${valid ? 'valid' : 'invalid'}"><img src="${Uri.file(relative).toString()}" alt="$escapedLabel"><h3>$escapedLabel</h3><code>$id</code>${escapedError.isEmpty ? '' : '<p>$escapedError</p>'}</article>',
      );
    }
    htmlCards.writeln('</div></section>');
  }
  await File(
    p.join(output.path, 'contact-sheet.md'),
  ).writeAsString('$markdown', flush: true);
  final html =
      '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Living Campaign V2 Portrait Review</title><style>:root{color-scheme:dark;--bg:#080a0e;--panel:#121820;--ink:#eadfc8;--gold:#e4bb62;--line:#554021}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 20% 0,#242018 0,transparent 30%),var(--bg);color:var(--ink);font:15px/1.55 system-ui}main{max-width:1320px;margin:auto;padding:48px 24px 80px}h1,h2{font-family:Georgia,serif;color:#f0d28e}h1{font-size:42px;margin-bottom:6px}h2{margin-top:44px;border-bottom:1px solid var(--line);padding-bottom:8px}.summary{padding:18px;border:1px solid var(--line);background:#11161d;border-radius:14px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px}article{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px}article.invalid{border-color:#a65045}img{display:block;width:100%;aspect-ratio:2/3;object-fit:contain;background:linear-gradient(45deg,#202a32 25%,#26313a 25%,#26313a 50%,#202a32 50%,#202a32 75%,#26313a 75%);background-size:24px 24px;border-radius:9px}h3{color:var(--gold);font-size:15px}code{color:#cdbb9a}</style></head><body><main><h1>Living Campaign V2 Portrait Candidate Review</h1><div class="summary"><strong>AWAITING OWNER SELECTION</strong><br>22/22 sources retained · ${report['validCandidateCount']} processed valid · ${report['invalidCandidateCount']} review-only warnings · 0 promoted</div>$htmlCards</main></body></html>''';
  await File(
    p.join(output.path, 'contact-sheet.html'),
  ).writeAsString(html, flush: true);
}

const _rootOrder = <String>[
  'maelin',
  'hadrik',
  'neris',
  'tavian',
  'fallback_king',
  'fallback_queen',
  'fallback_rook',
  'fallback_bishop',
  'fallback_knight',
];

class _Candidate {
  const _Candidate({
    required this.id,
    required this.rootId,
    required this.rootLabel,
    required this.category,
    required this.variant,
    required this.directory,
    required this.generationId,
  });
  final String id;
  final String rootId;
  final String rootLabel;
  final String category;
  final String variant;
  final String directory;
  final String generationId;
}

const _candidates = <_Candidate>[
  _Candidate(
    id: 'maelin_a',
    rootId: 'maelin',
    rootLabel: 'Lady Maelin Cinderveil · Queen',
    category: 'fixed_recruit',
    variant: 'A',
    directory: 'maelin',
    generationId: 'exec-736088a3-1aef-4577-aa43-72854fd03379',
  ),
  _Candidate(
    id: 'maelin_b',
    rootId: 'maelin',
    rootLabel: 'Lady Maelin Cinderveil · Queen',
    category: 'fixed_recruit',
    variant: 'B',
    directory: 'maelin',
    generationId: 'exec-155d0880-1829-4f03-8aba-b46ea36c8f9f',
  ),
  _Candidate(
    id: 'maelin_c',
    rootId: 'maelin',
    rootLabel: 'Lady Maelin Cinderveil · Queen',
    category: 'fixed_recruit',
    variant: 'C',
    directory: 'maelin',
    generationId: 'exec-95e7f221-bed5-4618-a0b7-1a695112e089',
  ),
  _Candidate(
    id: 'hadrik_a',
    rootId: 'hadrik',
    rootLabel: 'Warden Hadrik Emberwall · Rook',
    category: 'fixed_recruit',
    variant: 'A',
    directory: 'hadrik',
    generationId: 'exec-b82141c3-f2e2-493f-90c7-c1249ec7be5f',
  ),
  _Candidate(
    id: 'hadrik_b',
    rootId: 'hadrik',
    rootLabel: 'Warden Hadrik Emberwall · Rook',
    category: 'fixed_recruit',
    variant: 'B',
    directory: 'hadrik',
    generationId: 'exec-f8b19367-e96d-4378-bc12-e923bfc41d42',
  ),
  _Candidate(
    id: 'hadrik_c',
    rootId: 'hadrik',
    rootLabel: 'Warden Hadrik Emberwall · Rook',
    category: 'fixed_recruit',
    variant: 'C',
    directory: 'hadrik',
    generationId: 'exec-da613ae7-a503-40a3-a411-5ec0dbcd9ff3',
  ),
  _Candidate(
    id: 'neris_a',
    rootId: 'neris',
    rootLabel: 'Sister Neris of the Last Bell · Bishop',
    category: 'fixed_recruit',
    variant: 'A',
    directory: 'neris',
    generationId: 'exec-0c226281-a7b9-4929-952b-b63999eead38',
  ),
  _Candidate(
    id: 'neris_b',
    rootId: 'neris',
    rootLabel: 'Sister Neris of the Last Bell · Bishop',
    category: 'fixed_recruit',
    variant: 'B',
    directory: 'neris',
    generationId: 'exec-dc4bec2a-6607-4987-9282-7b57a8a5beb0',
  ),
  _Candidate(
    id: 'neris_c',
    rootId: 'neris',
    rootLabel: 'Sister Neris of the Last Bell · Bishop',
    category: 'fixed_recruit',
    variant: 'C',
    directory: 'neris',
    generationId: 'exec-c49141d0-fc6c-4786-b487-27d942c08af8',
  ),
  _Candidate(
    id: 'tavian_a',
    rootId: 'tavian',
    rootLabel: 'Ser Tavian Greyspur · Knight',
    category: 'fixed_recruit',
    variant: 'A',
    directory: 'tavian',
    generationId: 'exec-21e83665-5dd1-41d1-909b-5cf3c4b53b20',
  ),
  _Candidate(
    id: 'tavian_b',
    rootId: 'tavian',
    rootLabel: 'Ser Tavian Greyspur · Knight',
    category: 'fixed_recruit',
    variant: 'B',
    directory: 'tavian',
    generationId: 'exec-36e3bad9-b22e-4542-80c0-580223378171',
  ),
  _Candidate(
    id: 'tavian_c',
    rootId: 'tavian',
    rootLabel: 'Ser Tavian Greyspur · Knight',
    category: 'fixed_recruit',
    variant: 'C',
    directory: 'tavian',
    generationId: 'exec-521dfc60-3aa6-4b9f-9e66-2bdf2b48dc3f',
  ),
  _Candidate(
    id: 'fallback_king_a',
    rootId: 'fallback_king',
    rootLabel: 'Unknown King · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'A',
    directory: 'fallback_king',
    generationId: 'exec-cb541416-7d52-4c22-a5c5-e8ac736d1367',
  ),
  _Candidate(
    id: 'fallback_king_b',
    rootId: 'fallback_king',
    rootLabel: 'Unknown King · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'B',
    directory: 'fallback_king',
    generationId: 'exec-71cfd550-f6f5-4f36-86ba-b7c969416492',
  ),
  _Candidate(
    id: 'fallback_queen_a',
    rootId: 'fallback_queen',
    rootLabel: 'Unknown Queen · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'A',
    directory: 'fallback_queen',
    generationId: 'exec-c6cf37ca-e9fa-4dac-8f02-31cd4f4a087f',
  ),
  _Candidate(
    id: 'fallback_queen_b',
    rootId: 'fallback_queen',
    rootLabel: 'Unknown Queen · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'B',
    directory: 'fallback_queen',
    generationId: 'exec-3402d74d-af4a-4101-9198-72902fcfcaa8',
  ),
  _Candidate(
    id: 'fallback_rook_a',
    rootId: 'fallback_rook',
    rootLabel: 'Unknown Rook · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'A',
    directory: 'fallback_rook',
    generationId: 'exec-aa46130b-88bd-4582-bf48-267564a302a9',
  ),
  _Candidate(
    id: 'fallback_rook_b',
    rootId: 'fallback_rook',
    rootLabel: 'Unknown Rook · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'B',
    directory: 'fallback_rook',
    generationId: 'exec-088f1049-7784-41f2-9480-b115cc47f2e6',
  ),
  _Candidate(
    id: 'fallback_bishop_a',
    rootId: 'fallback_bishop',
    rootLabel: 'Unknown Bishop · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'A',
    directory: 'fallback_bishop',
    generationId: 'exec-d101e4e4-446e-485f-a24a-f4cb2c58c5d1',
  ),
  _Candidate(
    id: 'fallback_bishop_b',
    rootId: 'fallback_bishop',
    rootLabel: 'Unknown Bishop · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'B',
    directory: 'fallback_bishop',
    generationId: 'exec-b6911b0a-1583-45f7-a2f6-bd93966b0611',
  ),
  _Candidate(
    id: 'fallback_knight_a',
    rootId: 'fallback_knight',
    rootLabel: 'Unknown Knight · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'A',
    directory: 'fallback_knight',
    generationId: 'exec-0b59ce08-2175-4a14-ba82-4665c5d5c9a0',
  ),
  _Candidate(
    id: 'fallback_knight_b',
    rootId: 'fallback_knight',
    rootLabel: 'Unknown Knight · Fallback',
    category: 'identity_neutral_fallback',
    variant: 'B',
    directory: 'fallback_knight',
    generationId: 'exec-bc2c7c6f-fa8a-43a9-9608-5f74c67b86e2',
  ),
];
