import 'dart:convert';

import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_migrations.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_validator.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Living Campaign fixed opener', () {
    test('creates the approved deterministic Ashen Court setup', () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-test',
        now: DateTime.utc(2026, 8, 5),
      );

      expect(run.status, LivingRunStatus.active);
      expect(run.canon.gold, 10);
      expect(run.canon.playerRosterByPieceId, hasLength(4));
      expect(run.canon.charactersById.keys, {
        'char_orsain',
        'char_ysra',
        'char_veyl',
        'char_cael',
      });
      expect(
        run.canon.charactersById.map(
          (id, character) => MapEntry(id, character.portraitPath),
        ),
        <String, String>{
          'char_orsain':
              'assets/runtime/pieces/characters/living/orsain_half_body.webp',
          'char_ysra':
              'assets/runtime/pieces/characters/living/ysra_half_body.webp',
          'char_veyl':
              'assets/runtime/pieces/characters/living/veyl_half_body.webp',
          'char_cael':
              'assets/runtime/pieces/characters/living/cael_half_body.webp',
        },
      );
      final chapter = run.chapterPackages.single;
      expect(chapter.chapterId, 'living_m01');
      expect(chapter.seed, 1101);
      expect(chapter.whiteGold, 10);
      expect(chapter.blackGold, 10);
      expect(chapter.merchantSpeed, 4);
      expect(chapter.whiteCountryId, 'ashen');
      expect(chapter.blackCountryId, 'ashen');
      expect(chapter.pieces, hasLength(16));
      expect(
        chapter.pieces
            .where((piece) => piece.color == PieceColor.white)
            .map((piece) => livingSquareName(piece.square)),
        containsAll(<String>['a1', 'c1', 'e1', 'g1', 'a2', 'c2', 'e2', 'g2']),
      );
      expect(
        const LivingCampaignValidator().validateChapterPackage(
          canon: run.canon,
          intent: const LivingNextChapterIntent(
            chapterNumber: 1,
            conflict: 'The fixed opener',
            objectiveType: LivingObjectiveType.checkmate,
            pressureTier: 'even',
            rewardTier: 10,
            finaleKind: LivingFinaleKind.none,
            essentialBeats: <String>[],
          ),
          package: chapter,
        ),
        isEmpty,
      );
    });

    test('run JSON round trip preserves complete structured canon', () {
      final base = LivingCampaignFixedOpener.create(
        runId: 'run-json',
        now: DateTime.utc(2026, 8, 5, 12),
      );
      final checkpoint = LivingPortraitCheckpoint(
        runId: base.runId,
        missionId: 'living_m02',
        missionNumber: 2,
        characterId: 'char_new_rook',
        attempt: 1,
        seed: 7788,
        status: LivingPortraitStatus.awaitingRetry,
        appearanceBrief: 'An ash-armored Rook with a closed helm.',
        promptAsset: 'assets/prompts/living_campaign/portrait.md',
        finalPrompt: 'Locked portrait contract and appearance brief.',
        referenceHashes: const <String>['reference-sha256'],
        sourceReference: 'memory://source.bin',
        providerRequestId: 'image-request-id',
        durationMs: 4000,
        errorCode: 'interrupted',
        errorMessage: 'Portrait generation was interrupted.',
        createdAt: DateTime.utc(2026, 8, 5, 12, 1),
        updatedAt: DateTime.utc(2026, 8, 5, 12, 2),
      );
      final source = base.copyWith(
        portraitCheckpointsByCharacterId: <String, LivingPortraitCheckpoint>{
          checkpoint.characterId: checkpoint,
        },
      );
      final decoded = jsonDecode(jsonEncode(source.toJson()));
      final restored = LivingCampaignRun.fromJson(
        Map<String, Object?>.from(decoded as Map),
      );

      expect(restored.toJson(), source.toJson());
    });

    test(
      'pre-version archives migrate deterministically to schema V2 defaults',
      () {
        final source = LivingCampaignFixedOpener.create(
          runId: 'run-legacy',
          now: DateTime.utc(2026, 8, 5, 12),
        );
        final legacy = Map<String, Object?>.from(source.toJson())
          ..remove('schemaVersion')
          ..remove('campaignTitle')
          ..remove('storyPromise')
          ..remove('generationRecords')
          ..remove('namedPiecesByName')
          ..remove('missionMemories')
          ..remove('historyDigests');
        final canon = Map<String, Object?>.from(legacy['canon']! as Map)
          ..remove('schemaVersion');
        legacy['canon'] = canon;
        final chapters = (legacy['chapterPackages']! as List<Object?>)
            .map(
              (value) => Map<String, Object?>.from(value! as Map)
                ..remove('schemaVersion')
                ..remove('pressureTier'),
            )
            .toList();
        legacy['chapterPackages'] = chapters;
        final before = jsonEncode(legacy);

        final first = LivingCampaignRunCodec.decode(legacy);
        final second = LivingCampaignRunCodec.decode(legacy);

        expect(first.schemaVersion, 5);
        expect(first.contentLocale, LivingContentLocale.english);
        expect(first.campaignTitle, 'Living Campaign');
        expect(first.storyPromise, isEmpty);
        expect(first.namedPiecesByName, isEmpty);
        expect(first.missionMemories, isEmpty);
        expect(first.historyDigests, isEmpty);
        expect(jsonEncode(first.toJson()), jsonEncode(second.toJson()));
        expect(
          jsonEncode(legacy),
          before,
          reason: 'Migration must not mutate input.',
        );
      },
    );

    test('future archive schema is rejected instead of guessed', () {
      final source = LivingCampaignFixedOpener.create(
        runId: 'run-future',
        now: DateTime.utc(2026, 8, 5, 12),
      ).toJson();
      source['schemaVersion'] = 6;

      expect(
        () => LivingCampaignRunCodec.decode(source),
        throwsA(isA<FormatException>()),
      );
    });

    test('schema V3 turncoat labels migrate to story-world pending names', () {
      final source = LivingCampaignFixedOpener.create(
        runId: 'run-turncoat-migration',
        now: DateTime.utc(2026, 8, 11),
      ).toJson();
      source['schemaVersion'] = 3;
      source.remove('aftermathScenesByChapterId');
      source.remove('identityAssignmentsByCharacterId');
      source.remove('chapterClosureCheckpointsByChapterId');
      final named = Map<String, Object?>.from(
        source['namedPiecesByName']! as Map,
      );
      final ysra = Map<String, Object?>.from(
        named.remove('Dame Ysra Stonehand')! as Map,
      )..['name'] = 'Turncoat Rook Enemy Rook A8';
      named['Turncoat Rook Enemy Rook A8'] = ysra;
      source['namedPiecesByName'] = named;
      final canon = Map<String, Object?>.from(source['canon']! as Map);
      final characters = Map<String, Object?>.from(
        canon['charactersById']! as Map,
      );
      characters['char_ysra'] = Map<String, Object?>.from(
        characters['char_ysra']! as Map,
      )..['originalName'] = 'Turncoat Rook Enemy Rook A8';
      canon['charactersById'] = characters;
      source['canon'] = canon;

      final migrated = LivingCampaignRunCodec.decode(source);
      final record = migrated.namedPiecesByName['The Turncoat Rook'];

      expect(record, isNotNull);
      expect(record!.needsNaming, isTrue);
      expect(
        migrated.canon.charactersById['char_ysra']!.originalName,
        'The Turncoat Rook',
      );
      expect(
        migrated.canon.charactersById['char_ysra']!.aliases,
        contains('Turncoat Rook Enemy Rook A8'),
      );
    });
  });

  group('Living Campaign atomic Director patch', () {
    test('applies a valid patch and client-controlled reward atomically', () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-patch',
        now: DateTime.utc(2026, 8, 5),
      );
      final outcome = _outcome(runId: run.runId);
      final patch = _patch(runId: run.runId);

      final next = const LivingCampaignValidator().applyDirectorPatch(
        canon: run.canon,
        outcome: outcome,
        patch: patch,
      );

      expect(next.revision, 1);
      expect(next.gold, 22);
      expect(next.chapterLedger.single.oneLineSummary, isNotEmpty);
      expect(next.eventLedger.last.eventId, 'event_ch1_won');
    });

    test('rejects stale revisions without changing source canon', () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-stale',
        now: DateTime.utc(2026, 8, 5),
      );
      final sourceJson = run.canon.toJson();
      final patch = _patch(runId: run.runId, basedOnRevision: 9);

      expect(
        () => const LivingCampaignValidator().applyDirectorPatch(
          canon: run.canon,
          outcome: _outcome(runId: run.runId),
          patch: patch,
        ),
        throwsA(isA<LivingCampaignValidationException>()),
      );
      expect(run.canon.toJson(), sourceJson);
    });

    test('rejects killing a noncaptured character', () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-death',
        now: DateTime.utc(2026, 8, 5),
      );
      final base = _patch(runId: run.runId);
      final patch = LivingDirectorPatch(
        schemaVersion: base.schemaVersion,
        runId: base.runId,
        basedOnRevision: base.basedOnRevision,
        completedChapter: base.completedChapter,
        addCharacters: base.addCharacters,
        addEvents: <LivingCanonEvent>[
          ...base.addEvents,
          const LivingCanonEvent(
            eventId: 'event_invalid_death',
            chapterNumber: 1,
            type: LivingEventType.killed,
            subjectIds: <String>['char_ysra'],
            description: 'An invalid unsupported death.',
          ),
        ],
        addCanonFacts: base.addCanonFacts,
        openStoryThreads: base.openStoryThreads,
        characterTransitions: const <LivingCharacterTransition>[
          LivingCharacterTransition(
            characterId: 'char_ysra',
            chapterNumber: 1,
            causalEventId: 'event_invalid_death',
            expectedLifeState: LivingLifeState.alive,
            expectedWhereabouts: LivingWhereabouts.withCourt,
            expectedAllegiance: LivingAllegiance.player,
            nextLifeState: LivingLifeState.dead,
            nextWhereabouts: LivingWhereabouts.unknown,
            nextAllegiance: LivingAllegiance.player,
          ),
        ],
        advanceStoryThreads: base.advanceStoryThreads,
        resolveStoryThreads: base.resolveStoryThreads,
        relationshipChanges: base.relationshipChanges,
        nextChapterIntent: base.nextChapterIntent,
      );

      expect(
        () => const LivingCampaignValidator().applyDirectorPatch(
          canon: run.canon,
          outcome: _outcome(runId: run.runId),
          patch: patch,
        ),
        throwsA(
          isA<LivingCampaignValidationException>().having(
            (error) => error.issues.join(' '),
            'issues',
            contains('capture-eligible'),
          ),
        ),
      );
    });

    test('renewable Pawns cannot be elevated into persistent named pieces', () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-name',
        now: DateTime.utc(2026, 8, 5),
      );
      final base = _patch(runId: run.runId);
      final patch = LivingDirectorPatch(
        schemaVersion: base.schemaVersion,
        runId: base.runId,
        basedOnRevision: base.basedOnRevision,
        completedChapter: base.completedChapter,
        addCharacters: const <LivingCharacter>[
          LivingCharacter(
            characterId: 'char_ember',
            originalName: 'Ember of the Ford',
            originalIdentity: 'The Ashen Pawn who held the center',
            basePieceType: PieceType.pawn,
            linkedPieceId: 'ashen_pawn_e',
            lifeState: LivingLifeState.alive,
            whereabouts: LivingWhereabouts.withCourt,
            allegiance: LivingAllegiance.player,
            firstChapter: 1,
            lastChapter: 1,
          ),
        ],
        addEvents: <LivingCanonEvent>[
          ...base.addEvents,
          const LivingCanonEvent(
            eventId: 'event_ember_named',
            chapterNumber: 1,
            type: LivingEventType.named,
            subjectIds: <String>['char_ember'],
            description: 'The court named Ember after the battle.',
          ),
        ],
        addCanonFacts: base.addCanonFacts,
        openStoryThreads: base.openStoryThreads,
        characterTransitions: base.characterTransitions,
        advanceStoryThreads: base.advanceStoryThreads,
        resolveStoryThreads: base.resolveStoryThreads,
        relationshipChanges: base.relationshipChanges,
        nextChapterIntent: const LivingNextChapterIntent(
          chapterNumber: 2,
          conflict: 'The center remembers a new name.',
          objectiveType: LivingObjectiveType.surviveRounds,
          pressureTier: 'even',
          rewardTier: 10,
          finaleKind: LivingFinaleKind.none,
          essentialBeats: <String>['Recognize Ember'],
          newCharacterId: 'char_ember',
        ),
      );

      expect(
        () => const LivingCampaignValidator().applyDirectorPatch(
          canon: run.canon,
          outcome: _outcome(runId: run.runId),
          patch: patch,
        ),
        throwsA(
          isA<LivingCampaignValidationException>().having(
            (error) => error.issues.join(' '),
            'issues',
            contains('unknown piece ashen_pawn_e'),
          ),
        ),
      );
    });

    test(
      'a verified purchased piece can join the persistent player roster',
      () {
        final run = LivingCampaignFixedOpener.create(
          runId: 'run-purchase',
          now: DateTime.utc(2026, 8, 5),
        );
        final outcome = LivingBattleOutcomeSnapshot(
          chapterNumber: 1,
          chapterId: 'living_m01',
          result: LivingBattleResult.victory,
          endReason: GameEndReason.checkmate,
          objectiveType: LivingObjectiveType.checkmate,
          objectiveCompleted: true,
          completedTurns: 18,
          goldBefore: 10,
          goldAfterBattle: 4,
          survivingPieceIds: run.canon.playerRosterByPieceId.keys.toList(),
          capturedPieces: const <LivingCapturedPieceOutcome>[],
          purchasedPieceIds: const <String>['enemy_pawn_d7'],
          purchasedPieces: const <LivingPurchasedPieceOutcome>[
            LivingPurchasedPieceOutcome(
              pieceId: 'enemy_pawn_d7',
              pieceType: PieceType.pawn,
              originCountryId: 'ashen',
            ),
          ],
          missionRoleChanges: const <String, PieceType>{},
        );
        final base = _patch(runId: run.runId);
        final patch = LivingDirectorPatch(
          schemaVersion: base.schemaVersion,
          runId: base.runId,
          basedOnRevision: base.basedOnRevision,
          addRosterPieces: const <LivingRosterPiece>[
            LivingRosterPiece(
              pieceId: 'enemy_pawn_d7',
              basePieceType: PieceType.pawn,
              origin: 'Purchased from the rival Ashen formation in Chapter 1',
              lifeState: LivingLifeState.alive,
              whereabouts: LivingWhereabouts.withCourt,
              allegiance: LivingAllegiance.player,
              rosterPosition: LivingRosterPosition.active,
            ),
          ],
          completedChapter: base.completedChapter,
          addCharacters: base.addCharacters,
          addEvents: base.addEvents,
          addCanonFacts: base.addCanonFacts,
          openStoryThreads: base.openStoryThreads,
          characterTransitions: base.characterTransitions,
          advanceStoryThreads: base.advanceStoryThreads,
          resolveStoryThreads: base.resolveStoryThreads,
          relationshipChanges: base.relationshipChanges,
          nextChapterIntent: base.nextChapterIntent,
        );

        final next = const LivingCampaignValidator().applyDirectorPatch(
          canon: run.canon,
          outcome: outcome,
          patch: patch,
        );

        expect(next.playerRosterByPieceId, contains('enemy_pawn_d7'));
        expect(
          next.playerRosterByPieceId['enemy_pawn_d7']!.basePieceType,
          PieceType.pawn,
        );
      },
    );

    test('a named purchased piece joins with reciprocal stable identity', () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-named-purchase',
        now: DateTime.utc(2026, 8, 5),
      );
      final outcome = LivingBattleOutcomeSnapshot(
        chapterNumber: 1,
        chapterId: 'living_m01',
        result: LivingBattleResult.victory,
        endReason: GameEndReason.checkmate,
        objectiveType: LivingObjectiveType.checkmate,
        objectiveCompleted: true,
        completedTurns: 18,
        goldBefore: 10,
        goldAfterBattle: 4,
        survivingPieceIds: run.canon.playerRosterByPieceId.keys.toList(),
        capturedPieces: const <LivingCapturedPieceOutcome>[],
        purchasedPieceIds: const <String>['enemy_bishop_c8'],
        purchasedPieces: const <LivingPurchasedPieceOutcome>[
          LivingPurchasedPieceOutcome(
            pieceId: 'enemy_bishop_c8',
            pieceType: PieceType.bishop,
            originCountryId: 'ashen',
            characterId: 'char_sable_witness',
          ),
        ],
        missionRoleChanges: const <String, PieceType>{},
      );
      final base = _patch(runId: run.runId);
      final patch = LivingDirectorPatch(
        schemaVersion: base.schemaVersion,
        runId: base.runId,
        basedOnRevision: base.basedOnRevision,
        addRosterPieces: const <LivingRosterPiece>[
          LivingRosterPiece(
            pieceId: 'enemy_bishop_c8',
            basePieceType: PieceType.bishop,
            characterId: 'char_sable_witness',
            origin: 'Purchased from the rival court in Chapter 1',
            lifeState: LivingLifeState.alive,
            whereabouts: LivingWhereabouts.withCourt,
            allegiance: LivingAllegiance.player,
            rosterPosition: LivingRosterPosition.active,
          ),
        ],
        completedChapter: base.completedChapter,
        addCharacters: const <LivingCharacter>[
          LivingCharacter(
            characterId: 'char_sable_witness',
            originalName: 'The Sable Witness',
            originalIdentity: 'A rival Bishop purchased after the causeway',
            basePieceType: PieceType.bishop,
            linkedPieceId: 'enemy_bishop_c8',
            lifeState: LivingLifeState.alive,
            whereabouts: LivingWhereabouts.withCourt,
            allegiance: LivingAllegiance.player,
            firstChapter: 1,
            lastChapter: 1,
          ),
        ],
        addEvents: <LivingCanonEvent>[
          ...base.addEvents,
          const LivingCanonEvent(
            eventId: 'event_sable_witness_joined',
            chapterNumber: 1,
            type: LivingEventType.joined,
            subjectIds: <String>['char_sable_witness'],
            description: 'The Sable Witness joined the Ashen Court.',
          ),
        ],
        addCanonFacts: base.addCanonFacts,
        openStoryThreads: base.openStoryThreads,
        characterTransitions: base.characterTransitions,
        advanceStoryThreads: base.advanceStoryThreads,
        resolveStoryThreads: base.resolveStoryThreads,
        relationshipChanges: base.relationshipChanges,
        nextChapterIntent: const LivingNextChapterIntent(
          chapterNumber: 2,
          conflict: 'The new witness names the next danger.',
          objectiveType: LivingObjectiveType.surviveRounds,
          pressureTier: 'even',
          rewardTier: 10,
          finaleKind: LivingFinaleKind.none,
          essentialBeats: <String>['Interrogate the Sable Witness.'],
          newCharacterId: 'char_sable_witness',
        ),
      );

      final next = const LivingCampaignValidator().applyDirectorPatch(
        canon: run.canon,
        outcome: outcome,
        patch: patch,
      );

      expect(
        next.playerRosterByPieceId['enemy_bishop_c8']!.characterId,
        'char_sable_witness',
      );
      expect(
        next.charactersById['char_sable_witness']!.linkedPieceId,
        'enemy_bishop_c8',
      );
    });

    test('only a previously locked finale can seal canon with an epilogue', () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-finale',
        now: DateTime.utc(2026, 8, 5),
      );
      final finaleCanon = run.canon.copyWith(
        chapterLedger: const <LivingChapterRecord>[
          LivingChapterRecord(
            chapterNumber: 1,
            chapterId: 'living_m01',
            title: 'The Ashen Divide',
            oneLineSummary: 'The court crossed the first ruined causeway.',
            objectiveType: LivingObjectiveType.checkmate,
            result: LivingBattleResult.victory,
            eventIds: <String>[],
            finaleKind: LivingFinaleKind.none,
          ),
          LivingChapterRecord(
            chapterNumber: 2,
            chapterId: 'living_m02',
            title: 'The Final Road Opens',
            oneLineSummary: 'The court chose to face its last enemy at dawn.',
            objectiveType: LivingObjectiveType.surviveRounds,
            result: LivingBattleResult.victory,
            eventIds: <String>[],
            finaleKind: LivingFinaleKind.hopeful,
          ),
        ],
      );
      const outcome = LivingBattleOutcomeSnapshot(
        chapterNumber: 3,
        chapterId: 'living_m03',
        result: LivingBattleResult.victory,
        endReason: GameEndReason.checkmate,
        objectiveType: LivingObjectiveType.neutralizeTarget,
        pressureTier: 'severe',
        objectiveCompleted: true,
        completedTurns: 24,
        goldBefore: 10,
        goldAfterBattle: 20,
        survivingPieceIds: <String>['ashen_king_orsain'],
        capturedPieces: <LivingCapturedPieceOutcome>[],
        purchasedPieceIds: <String>[],
        missionRoleChanges: <String, PieceType>{},
      );
      final patch = LivingDirectorPatch(
        schemaVersion: 1,
        runId: run.runId,
        basedOnRevision: 0,
        campaignComplete: true,
        epilogue: List<String>.filled(
          3,
          'The crown survived, but it no longer meant what Orsain believed at '
          'the causeway. Each survivor carried a different piece of dawn. ',
        ).join(),
        completedChapter: const LivingCompletedChapterPatch(
          chapterNumber: 3,
          chapterId: 'living_m03',
          title: 'A Crown Rewritten',
          oneLineSummary: 'The court survived the finale and remade its oath.',
        ),
        addCharacters: const <LivingCharacter>[],
        addEvents: const <LivingCanonEvent>[
          LivingCanonEvent(
            eventId: 'event_finale_won',
            chapterNumber: 3,
            type: LivingEventType.epilogue,
            subjectIds: <String>['char_orsain'],
            description: 'The hopeful finale ended in a remade oath.',
          ),
        ],
        addCanonFacts: const <LivingCanonFact>[],
        openStoryThreads: const <LivingStoryThread>[],
        characterTransitions: const <LivingCharacterTransition>[],
        advanceStoryThreads: const <LivingThreadChange>[],
        resolveStoryThreads: const <LivingThreadChange>[],
        relationshipChanges: const <LivingRelationshipChange>[],
        nextChapterIntent: const LivingNextChapterIntent(
          chapterNumber: 4,
          conflict: 'Terminal intent is ignored after the sealed finale.',
          objectiveType: LivingObjectiveType.surviveRounds,
          pressureTier: 'even',
          rewardTier: 10,
          finaleKind: LivingFinaleKind.none,
          essentialBeats: <String>[],
        ),
      );

      final sealed = const LivingCampaignValidator().applyDirectorPatch(
        canon: finaleCanon,
        outcome: outcome,
        patch: patch,
      );

      expect(sealed.revision, 1);
      expect(sealed.chapterLedger.last.finaleKind, LivingFinaleKind.hopeful);
      expect(sealed.gold, 55);
    });

    test('identified player King Trapfall can seal an early tragic ending', () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-early-trapfall',
        now: DateTime.utc(2026, 8, 6),
      );
      const outcome = LivingBattleOutcomeSnapshot(
        chapterNumber: 1,
        chapterId: 'living_m01',
        result: LivingBattleResult.defeat,
        endReason: GameEndReason.kingTrapfall,
        objectiveType: LivingObjectiveType.checkmate,
        objectiveCompleted: false,
        completedTurns: 7,
        goldBefore: 10,
        goldAfterBattle: 9,
        survivingPieceIds: <String>[
          'ashen_rook_ysra',
          'ashen_bishop_veyl',
          'ashen_knight_cael',
          'ashen_pawn_d',
          'ashen_pawn_e',
          'ashen_pawn_f',
        ],
        capturedPieces: <LivingCapturedPieceOutcome>[],
        purchasedPieceIds: <String>[],
        missionRoleChanges: <String, PieceType>{},
        kingTrapfallPieceId: 'ashen_king_orsain',
      );
      final patch = LivingDirectorPatch(
        schemaVersion: 1,
        runId: run.runId,
        basedOnRevision: 0,
        campaignComplete: true,
        epilogue: List<String>.filled(
          3,
          'The causeway swallowed Orsain and the unfinished crown with him. '
          'The surviving court carried his name into a colder age, unable to '
          'pretend that every road permits another battle. ',
        ).join(),
        completedChapter: const LivingCompletedChapterPatch(
          chapterNumber: 1,
          chapterId: 'living_m01',
          title: 'The Crown Beneath the Causeway',
          oneLineSummary: 'Orsain fell to the causeway trap and the run ended.',
        ),
        addCharacters: const <LivingCharacter>[],
        addEvents: const <LivingCanonEvent>[
          LivingCanonEvent(
            eventId: 'event_orsain_trapfall',
            chapterNumber: 1,
            type: LivingEventType.killed,
            subjectIds: <String>['char_orsain'],
            description: 'Orsain was killed by a battlefield Trap.',
          ),
        ],
        addCanonFacts: const <LivingCanonFact>[],
        openStoryThreads: const <LivingStoryThread>[],
        characterTransitions: const <LivingCharacterTransition>[
          LivingCharacterTransition(
            characterId: 'char_orsain',
            expectedLifeState: LivingLifeState.alive,
            expectedWhereabouts: LivingWhereabouts.withCourt,
            expectedAllegiance: LivingAllegiance.player,
            nextLifeState: LivingLifeState.dead,
            nextWhereabouts: LivingWhereabouts.missing,
            nextAllegiance: LivingAllegiance.player,
            chapterNumber: 1,
            causalEventId: 'event_orsain_trapfall',
          ),
        ],
        advanceStoryThreads: const <LivingThreadChange>[],
        resolveStoryThreads: const <LivingThreadChange>[],
        relationshipChanges: const <LivingRelationshipChange>[],
        nextChapterIntent: const LivingNextChapterIntent(
          chapterNumber: 2,
          conflict: 'Terminal intent is ignored after the Trapfall ending.',
          objectiveType: LivingObjectiveType.surviveRounds,
          pressureTier: 'even',
          rewardTier: 10,
          finaleKind: LivingFinaleKind.none,
          essentialBeats: <String>[],
        ),
      );

      final sealed = const LivingCampaignValidator().applyDirectorPatch(
        canon: run.canon,
        outcome: outcome,
        patch: patch,
      );

      expect(sealed.chapterLedger.single.finaleKind, LivingFinaleKind.tragic);
      expect(
        sealed.charactersById['char_orsain']?.lifeState,
        LivingLifeState.dead,
      );
      expect(
        sealed.playerRosterByPieceId['ashen_king_orsain']?.rosterPosition,
        LivingRosterPosition.former,
      );
    });

    test('Trapfall cannot kill a different King identity', () {
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-wrong-trapfall',
        now: DateTime.utc(2026, 8, 6),
      );
      const outcome = LivingBattleOutcomeSnapshot(
        chapterNumber: 1,
        chapterId: 'living_m01',
        result: LivingBattleResult.defeat,
        endReason: GameEndReason.kingTrapfall,
        objectiveType: LivingObjectiveType.checkmate,
        objectiveCompleted: false,
        completedTurns: 7,
        goldBefore: 10,
        goldAfterBattle: 9,
        survivingPieceIds: <String>[],
        capturedPieces: <LivingCapturedPieceOutcome>[],
        purchasedPieceIds: <String>[],
        missionRoleChanges: <String, PieceType>{},
        kingTrapfallPieceId: 'enemy_king',
      );
      final base = _patch(runId: run.runId);
      final patch = LivingDirectorPatch(
        schemaVersion: base.schemaVersion,
        runId: base.runId,
        basedOnRevision: base.basedOnRevision,
        campaignComplete: true,
        epilogue: List<String>.filled(
          3,
          'The false chronicle claimed that Orsain fell beneath the causeway, '
          'but the verified battlefield record named a different King. ',
        ).join(),
        completedChapter: base.completedChapter,
        addCharacters: base.addCharacters,
        addEvents: base.addEvents,
        addCanonFacts: base.addCanonFacts,
        openStoryThreads: base.openStoryThreads,
        characterTransitions: base.characterTransitions,
        advanceStoryThreads: base.advanceStoryThreads,
        resolveStoryThreads: base.resolveStoryThreads,
        relationshipChanges: base.relationshipChanges,
        nextChapterIntent: base.nextChapterIntent,
      );

      expect(
        () => const LivingCampaignValidator().applyDirectorPatch(
          canon: run.canon,
          outcome: outcome,
          patch: patch,
        ),
        throwsA(
          isA<LivingCampaignValidationException>().having(
            (error) => error.issues.join(' '),
            'issues',
            contains('canonical player King'),
          ),
        ),
      );
    });
  });

  group('Living Campaign generated-content contract', () {
    late LivingCampaignRun run;
    late LivingNextChapterIntent fixedIntent;

    setUp(() {
      run = LivingCampaignFixedOpener.create(
        runId: 'run-contract',
        now: DateTime.utc(2026, 8, 6),
      );
      fixedIntent = const LivingNextChapterIntent(
        chapterNumber: 1,
        conflict: 'Cross the Ruined Causeway.',
        objectiveType: LivingObjectiveType.checkmate,
        pressureTier: 'even',
        rewardTier: 10,
        finaleKind: LivingFinaleKind.none,
        essentialBeats: <String>[],
      );
    });

    test('requires all three mission systems and forbids reserves', () {
      final package = _mutatePackage(run.chapterPackages.single, (json) {
        json['economyEnabled'] = false;
        json['merchantEnabled'] = false;
        json['specialTilesEnabled'] = false;
        json['reservePieceIds'] = <String>['ashen_pawn_d'];
      });

      final issues = const LivingCampaignValidator().validateChapterPackage(
        canon: run.canon,
        intent: fixedIntent,
        package: package,
      );

      expect(issues.join(' '), contains('must remain enabled'));
      expect(issues.join(' '), contains('does not support mission reserves'));
    });

    test(
      'deploys only alive active player pieces currently with the court',
      () {
        final roster = Map<String, LivingRosterPiece>.from(
          run.canon.playerRosterByPieceId,
        );
        roster['ashen_rook_ysra'] = roster['ashen_rook_ysra']!.copyWith(
          lifeState: LivingLifeState.wounded,
          whereabouts: LivingWhereabouts.reserve,
          rosterPosition: LivingRosterPosition.reserve,
        );

        final issues = const LivingCampaignValidator().validateChapterPackage(
          canon: run.canon.copyWith(playerRosterByPieceId: roster),
          intent: fixedIntent,
          package: run.chapterPackages.single,
        );

        expect(issues.join(' '), contains('Unavailable player piece'));
      },
    );

    test('rejects unsafe ids and malformed or ungrounded dialogue', () {
      final package = _mutatePackage(run.chapterPackages.single, (json) {
        json['chapterId'] = '../unsafe';
        json['dialogue'] = <Object?>[
          <String, Object?>{
            'lineId': 'duplicate_line',
            'speakerId': 'char_missing',
            'side': 'center',
            'text': '',
          },
          <String, Object?>{
            'lineId': 'duplicate_line',
            'speakerId': 'char_orsain',
            'side': 'left',
            'text': 'A valid second line cannot rescue the duplicate id.',
          },
        ];
      });

      final issues = const LivingCampaignValidator().validateChapterPackage(
        canon: run.canon,
        intent: fixedIntent,
        package: package,
      );
      final message = issues.join(' ');

      expect(message, contains('safe id'));
      expect(message, contains('invalid or duplicated'));
      expect(message, contains('invalid side'));
      expect(message, contains('has no text'));
      expect(message, contains('unknown speaker'));
    });

    test('rescue targets begin on the enemy side', () {
      final package = _mutatePackage(run.chapterPackages.single, (json) {
        json['objective'] = <String, Object?>{
          'type': LivingObjectiveType.rescueRecover.name,
          'label': 'Rescue Ysra and reach a8.',
          'targetPieceId': 'ashen_rook_ysra',
          'targetSquare': 'a8',
        };
      });
      const intent = LivingNextChapterIntent(
        chapterNumber: 1,
        conflict: 'Recover a stranded survivor.',
        objectiveType: LivingObjectiveType.rescueRecover,
        pressureTier: 'even',
        rewardTier: 10,
        finaleKind: LivingFinaleKind.none,
        essentialBeats: <String>[],
      );

      final issues = const LivingCampaignValidator().validateChapterPackage(
        canon: run.canon,
        intent: intent,
        package: package,
      );

      expect(issues.join(' '), contains('must begin on the enemy side'));
    });

    test('canon cross-references cannot silently invent participants', () {
      final json = jsonDecode(jsonEncode(run.canon.toJson()));
      final canonJson = Map<String, Object?>.from(json as Map);
      final threads = Map<String, Object?>.from(
        canonJson['storyThreadsById']! as Map,
      );
      final threadId = threads.keys.first;
      final thread = Map<String, Object?>.from(threads[threadId]! as Map);
      thread['participantIds'] = <String>['char_never_existed'];
      threads[threadId] = thread;
      canonJson['storyThreadsById'] = threads;

      final issues = const LivingCampaignValidator().validateCanon(
        LivingCanonState.fromJson(canonJson),
      );

      expect(issues.join(' '), contains('unknown participant'));
    });

    test('Director must lock a non-checkmate conflict with story beats', () {
      final json = _patch(runId: run.runId).toJson();
      final intent = Map<String, Object?>.from(
        json['nextChapterIntent']! as Map,
      );
      intent['conflict'] = '';
      intent['objectiveType'] = LivingObjectiveType.checkmate.name;
      intent['essentialBeats'] = <String>[];
      json['nextChapterIntent'] = intent;

      expect(
        () => const LivingCampaignValidator().applyDirectorPatch(
          canon: run.canon,
          outcome: _outcome(runId: run.runId),
          patch: LivingDirectorPatch.fromJson(json),
        ),
        throwsA(
          isA<LivingCampaignValidationException>().having(
            (error) => error.issues.join(' '),
            'issues',
            allOf(
              contains('essential beat'),
              contains('cannot lock checkmate'),
            ),
          ),
        ),
      );
    });
  });
}

LivingChapterPackage _mutatePackage(
  LivingChapterPackage source,
  void Function(Map<String, Object?> json) mutate,
) {
  final decoded = jsonDecode(jsonEncode(source.toJson()));
  final json = Map<String, Object?>.from(decoded as Map);
  mutate(json);
  return LivingChapterPackage.fromJson(json);
}

LivingBattleOutcomeSnapshot _outcome({required String runId}) {
  return const LivingBattleOutcomeSnapshot(
    chapterNumber: 1,
    chapterId: 'living_m01',
    result: LivingBattleResult.victory,
    endReason: GameEndReason.checkmate,
    objectiveType: LivingObjectiveType.checkmate,
    objectiveCompleted: true,
    completedTurns: 18,
    goldBefore: 10,
    goldAfterBattle: 12,
    survivingPieceIds: <String>[
      'ashen_king_orsain',
      'ashen_rook_ysra',
      'ashen_bishop_veyl',
      'ashen_knight_cael',
      'ashen_pawn_d',
      'ashen_pawn_e',
      'ashen_pawn_f',
    ],
    capturedPieces: <LivingCapturedPieceOutcome>[],
    purchasedPieceIds: <String>[],
    missionRoleChanges: <String, PieceType>{},
  );
}

LivingDirectorPatch _patch({required String runId, int basedOnRevision = 0}) {
  return LivingDirectorPatch(
    schemaVersion: 1,
    runId: runId,
    basedOnRevision: basedOnRevision,
    completedChapter: const LivingCompletedChapterPatch(
      chapterNumber: 1,
      chapterId: 'living_m01',
      title: 'The Ashen Divide',
      oneLineSummary:
          'Orsain broke the rival shield and carried seven survivors onward.',
    ),
    addCharacters: const <LivingCharacter>[],
    addEvents: const <LivingCanonEvent>[
      LivingCanonEvent(
        eventId: 'event_ch1_won',
        chapterNumber: 1,
        type: LivingEventType.battleWon,
        subjectIds: <String>['char_orsain'],
        description: 'The Ashen Court won the first battle.',
      ),
    ],
    addCanonFacts: const <LivingCanonFact>[],
    openStoryThreads: const <LivingStoryThread>[],
    characterTransitions: const <LivingCharacterTransition>[],
    advanceStoryThreads: const <LivingThreadChange>[],
    resolveStoryThreads: const <LivingThreadChange>[],
    relationshipChanges: const <LivingRelationshipChange>[],
    nextChapterIntent: const LivingNextChapterIntent(
      chapterNumber: 2,
      conflict: 'The survivors meet the consequence of their victory.',
      objectiveType: LivingObjectiveType.surviveRounds,
      pressureTier: 'even',
      rewardTier: 10,
      finaleKind: LivingFinaleKind.none,
      essentialBeats: <String>['Carry the result forward'],
    ),
  );
}
