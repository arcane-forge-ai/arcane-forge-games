import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemorySettingsStore implements LivingCampaignSettingsStore {
  String? value;

  @override
  Future<void> clear() async => value = null;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async => this.value = value;
}

void main() {
  test('developer env overrides saved settings field by field', () {
    final effective = EffectiveLivingCampaignSettings.resolve(
      saved: const LivingCampaignSettings(
        apiKey: 'player-key',
        baseUrl: 'https://player.example/api/v3/',
        textModel: 'player-text',
        imageModel: 'player-image',
      ),
      developer: const LivingDeveloperEnvironment(
        apiKey: 'developer-key',
        textModel: 'developer-text',
      ),
    );

    expect(effective.values.apiKey, 'developer-key');
    expect(effective.values.baseUrl, 'https://player.example/api/v3');
    expect(effective.values.textModel, 'developer-text');
    expect(effective.values.imageModel, 'player-image');
    expect(effective.sources['apiKey'], LivingSettingSource.developerEnv);
    expect(effective.sources['baseUrl'], LivingSettingSource.player);
  });

  test('dotenv parser accepts provider and diagnostic developer fields', () {
    final environment = LivingDeveloperEnvironment.fromDotEnv('''
# ignored comment
export ARK_API_KEY="developer-key"
ARK_BASE_URL=https://ark.example/api/v3/
LIVING_CAMPAIGN_TEXT_MODEL=developer-text
LIVING_CAMPAIGN_IMAGE_MODEL='developer-image'
LIVING_TEXT_LOG_LEVEL=summary
LIVING_IMAGE_LOG_LEVEL=full
LIVING_LOG_STAGES=director,chapter_art
UNRELATED_SECRET=must-not-load
''');

    expect(environment.apiKey, 'developer-key');
    expect(environment.baseUrl, 'https://ark.example/api/v3/');
    expect(environment.textModel, 'developer-text');
    expect(environment.imageModel, 'developer-image');
    expect(environment.textLogLevel, 'summary');
    expect(environment.imageLogLevel, 'full');
    expect(environment.logStages, 'director,chapter_art');
    expect(environment.toString(), isNot(contains('must-not-load')));
  });

  test('developer diagnostics override saved levels and stage filters', () {
    final effective = EffectiveLivingCampaignSettings.resolve(
      saved: const LivingCampaignSettings(
        textLogLevel: LivingLogLevel.full,
        imageLogLevel: LivingLogLevel.off,
        logStages: <String>{'builder'},
      ),
      developer: const LivingDeveloperEnvironment(
        textLogLevel: 'summary',
        imageLogLevel: 'full',
        logStages: 'director, chapter_art',
      ),
    );

    expect(effective.values.textLogLevel, LivingLogLevel.summary);
    expect(effective.values.imageLogLevel, LivingLogLevel.full);
    expect(effective.values.logStages, <String>{'director', 'chapter_art'});
    expect(effective.sources['textLogLevel'], LivingSettingSource.developerEnv);
    expect(effective.sources['logStages'], LivingSettingSource.developerEnv);
  });

  test(
    'controller loads workspace env before resolving saved settings',
    () async {
      final store = _MemorySettingsStore();
      final repository = LivingCampaignSettingsRepository(store: store);
      await repository.save(
        const LivingCampaignSettings(
          apiKey: 'player-key',
          textModel: 'player-text',
        ),
      );
      final controller = LivingCampaignSettingsController(
        repository: repository,
        developerEnvironmentLoader: () async =>
            const LivingDeveloperEnvironment(
              apiKey: 'developer-key',
              textModel: 'developer-text',
            ),
      );
      addTearDown(controller.dispose);

      await controller.initialize();

      expect(controller.saved.apiKey, 'player-key');
      expect(controller.effective.values.apiKey, 'developer-key');
      expect(controller.effective.values.textModel, 'developer-text');
      expect(
        controller.effective.sources['apiKey'],
        LivingSettingSource.developerEnv,
      );
    },
  );

  test('repository persists key alongside ordinary settings', () async {
    final store = _MemorySettingsStore();
    final repository = LivingCampaignSettingsRepository(store: store);
    const settings = LivingCampaignSettings(
      apiKey: 'local-unencrypted-key',
      textModel: 'text-model',
      textLogLevel: LivingLogLevel.summary,
      imageLogLevel: LivingLogLevel.full,
      logStages: <String>{'director', 'chapter_art'},
    );

    await repository.save(settings);
    expect((await repository.load()).apiKey, 'local-unencrypted-key');

    await repository.deleteApiKey(current: await repository.load());
    final withoutKey = await repository.load();
    expect(withoutKey.apiKey, isEmpty);
    expect(withoutKey.textModel, 'text-model');
    expect(withoutKey.textLogLevel, LivingLogLevel.summary);
    expect(withoutKey.imageLogLevel, LivingLogLevel.full);
    expect(withoutKey.logStages, <String>{'director', 'chapter_art'});
  });

  test('broken settings fall back to built-in defaults', () async {
    final store = _MemorySettingsStore()..value = '{broken';
    final settings = await LivingCampaignSettingsRepository(
      store: store,
    ).load();

    expect(settings.apiKey, isEmpty);
    expect(settings.baseUrl, LivingCampaignSettings.defaultBaseUrl);
    expect(settings.textModel, LivingCampaignSettings.defaultTextModel);
    expect(settings.imageModel, LivingCampaignSettings.defaultImageModel);
    expect(settings.textLogLevel, LivingLogLevel.off);
    expect(settings.imageLogLevel, LivingLogLevel.off);
  });

  test('preview bundle is isolated from developer and player keys', () {
    final effective = EffectiveLivingCampaignSettings.resolve(
      saved: const LivingCampaignSettings(apiKey: 'player-key'),
      developer: const LivingDeveloperEnvironment(apiKey: 'developer-key'),
      preview: const PreviewBuildConfig(
        enabled: true,
        label: 'Preview 1',
        apiKey: 'preview-key',
      ),
    );

    expect(effective.values.apiKey, 'preview-key');
    expect(effective.sources['apiKey'], LivingSettingSource.previewBundle);
    expect(effective.isDeveloperOverride('apiKey'), isFalse);
    expect(effective.isPreviewBundle('apiKey'), isTrue);
  });

  test('enabled preview never falls back when its key is missing', () {
    final effective = EffectiveLivingCampaignSettings.resolve(
      saved: const LivingCampaignSettings(apiKey: 'player-key'),
      developer: const LivingDeveloperEnvironment(apiKey: 'developer-key'),
      preview: const PreviewBuildConfig(enabled: true, apiKey: ''),
    );

    expect(effective.values.apiKey, isEmpty);
    expect(effective.sources['apiKey'], LivingSettingSource.previewBundle);
  });

  test('controller never persists the bundled preview key', () async {
    final store = _MemorySettingsStore();
    final repository = LivingCampaignSettingsRepository(store: store);
    await repository.save(const LivingCampaignSettings(apiKey: 'player-key'));
    final controller = LivingCampaignSettingsController(
      repository: repository,
      developerEnvironment: const LivingDeveloperEnvironment(
        apiKey: 'developer-key',
      ),
      previewBuildConfig: const PreviewBuildConfig(
        enabled: true,
        label: 'Preview 1',
        apiKey: 'preview-secret',
      ),
    );
    addTearDown(controller.dispose);

    await controller.initialize();
    expect(controller.effective.values.apiKey, 'preview-secret');
    expect((await repository.load()).apiKey, 'player-key');
    expect(store.value, isNot(contains('preview-secret')));
  });
}
