import 'dart:async';
import 'dart:typed_data';

import 'package:crazy_chess/battlefield/battlefield_models.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_metrics.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_prompt_library.dart';
import 'package:crazy_chess/living_campaign/living_campaign_v2_backend.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Living Campaign V2 fixed opener', () {
    test('uses the approved fixed M01 board and mission-only Pawns', () {
      final run = _fixedRun();
      final chapter = run.chapterPackages.single;
      final bySquare = <String, LivingMissionPiece>{
        for (final piece in chapter.pieces)
          livingSquareName(piece.square): piece,
      };

      expect(chapter.title, 'The Ashen Divide');
      expect(chapter.subtitle, 'One crown. One road out. No uncontested heir.');
      expect(chapter.dialogue, hasLength(12));
      const expected = <String, PieceType>{
        'a1': PieceType.rook,
        'c1': PieceType.bishop,
        'e1': PieceType.king,
        'g1': PieceType.knight,
        'a2': PieceType.pawn,
        'c2': PieceType.pawn,
        'e2': PieceType.pawn,
        'g2': PieceType.pawn,
        'a8': PieceType.rook,
        'c8': PieceType.bishop,
        'e8': PieceType.king,
        'g8': PieceType.knight,
        'a7': PieceType.pawn,
        'c7': PieceType.pawn,
        'e7': PieceType.pawn,
        'g7': PieceType.pawn,
      };
      for (final entry in expected.entries) {
        expect(bySquare[entry.key]?.pieceType, entry.value, reason: entry.key);
      }
      expect(
        run.namedPiecesByName.values,
        everyElement(
          isA<LivingNamedPieceRecord>().having(
            (record) => record.pieceType,
            'pieceType',
            isNot(PieceType.pawn),
          ),
        ),
      );
      expect(
        run.canon.playerRosterByPieceId.values,
        everyElement(
          isA<LivingRosterPiece>().having(
            (piece) => piece.basePieceType,
            'basePieceType',
            isNot(PieceType.pawn),
          ),
        ),
      );
    });
  });

  group('Living Campaign V2 deterministic state rules', () {
    test('portrait seeds use stable SHA-256 inputs including attempt', () {
      final first = LivingPortraitSeed.derive(
        runId: 'run-a',
        missionId: 'living_m02',
        characterId: 'char-new',
        attempt: 1,
      );
      expect(
        LivingPortraitSeed.derive(
          runId: 'run-a',
          missionId: 'living_m02',
          characterId: 'char-new',
          attempt: 1,
        ),
        first,
      );
      expect(
        LivingPortraitSeed.derive(
          runId: 'run-a',
          missionId: 'living_m02',
          characterId: 'char-new',
          attempt: 2,
        ),
        isNot(first),
      );
      expect(first, inInclusiveRange(1, 0x7fffffff));
    });

    const reducer = LivingCampaignOutcomeReducer();

    test('SHA-256 fate is stable and exercises both 50/50 branches', () {
      final seen = <LivingNamedPieceStatus>{};
      for (var index = 0; index < 1000 && seen.length < 2; index += 1) {
        final status = reducer.fateFor(
          runId: 'run_fate_$index',
          missionId: 'living_m01',
          characterName: 'Cael of No Banner',
          eventType: 'capture',
        );
        expect(
          reducer.fateFor(
            runId: 'run_fate_$index',
            missionId: 'living_m01',
            characterName: 'Cael of No Banner',
            eventType: 'capture',
          ),
          status,
        );
        seen.add(status);
      }

      expect(seen, <LivingNamedPieceStatus>{
        LivingNamedPieceStatus.dead,
        LivingNamedPieceStatus.missing,
      });
    });

    test('victory awards surviving advanced allies and preserves Pawns', () {
      final run = _fixedRun();
      final next = reducer.apply(
        run: run,
        outcome: _m01Outcome(pressureTier: 'pressured'),
        now: DateTime.utc(2026, 8, 9, 1),
      );

      expect(next.namedPiecesByName['Dame Ysra Stonehand']!.loyalty, 80);
      expect(next.namedPiecesByName['Brother Veyl the Unshriven']!.loyalty, 80);
      expect(next.namedPiecesByName['Cael of No Banner']!.loyalty, 80);
      expect(next.namedPiecesByName['King Orsain Ashcrown']!.loyalty, isNull);
      expect(next.canon.gold, 33);
      expect(next.battleOutcomes, hasLength(1));
      expect(next.v2GenerationCheckpoint, isNotNull);
      expect(
        next.namedPiecesByName.values.any(
          (record) => record.pieceType == PieceType.pawn,
        ),
        isFalse,
      );
    });

    test('purchase reset applies before the victory Loyalty bonus', () {
      final base = _fixedRun();
      final named = Map<String, LivingNamedPieceRecord>.from(
        base.namedPiecesByName,
      );
      named['Warden Hadrik Emberwall'] = named['Warden Hadrik Emberwall']!
          .copyWith(status: LivingNamedPieceStatus.enemy);
      final run = base.copyWith(namedPiecesByName: named);
      final outcome = LivingBattleOutcomeSnapshot(
        chapterNumber: 1,
        chapterId: 'living_m01',
        result: LivingBattleResult.victory,
        endReason: GameEndReason.checkmate,
        objectiveType: LivingObjectiveType.checkmate,
        objectiveCompleted: true,
        completedTurns: 14,
        goldBefore: 10,
        goldAfterBattle: 9,
        survivingPieceIds: <String>[
          ..._m01Outcome().survivingPieceIds,
          'ashen_rook_hadrik',
        ],
        capturedPieces: const <LivingCapturedPieceOutcome>[],
        purchasedPieceIds: const <String>['ashen_rook_hadrik'],
        purchasedPieces: const <LivingPurchasedPieceOutcome>[
          LivingPurchasedPieceOutcome(
            pieceId: 'ashen_rook_hadrik',
            pieceType: PieceType.rook,
            originCountryId: 'ashen',
            characterId: 'char_hadrik_emberwall',
            loyalty: 30,
          ),
        ],
        purchaseEvents: const <LivingPurchaseEventOutcome>[
          LivingPurchaseEventOutcome(
            pieceId: 'ashen_rook_hadrik',
            pieceType: PieceType.rook,
            fromAllegiance: LivingAllegiance.enemy,
            toAllegiance: LivingAllegiance.player,
            completedActionNumber: 10,
            characterId: 'char_hadrik_emberwall',
          ),
        ],
        missionRoleChanges: const <String, PieceType>{},
      );

      final next = reducer.apply(
        run: run,
        outcome: outcome,
        now: DateTime.utc(2026, 8, 9, 1),
      );

      expect(
        next.namedPiecesByName['Warden Hadrik Emberwall']!.status,
        LivingNamedPieceStatus.ally,
      );
      expect(next.namedPiecesByName['Warden Hadrik Emberwall']!.loyalty, 50);
    });

    test(
      'Player King Trapfall ends the run while ordinary defeat does not',
      () {
        final run = _fixedRun();
        final ordinary = reducer.apply(
          run: run,
          outcome: _m01Outcome(
            result: LivingBattleResult.defeat,
            endReason: GameEndReason.checkmate,
            objectiveCompleted: false,
          ),
          now: DateTime.utc(2026, 8, 9, 1),
        );
        expect(ordinary.status, LivingRunStatus.active);
        expect(ordinary.epilogue, isNull);

        final trapfall = reducer.apply(
          run: run,
          outcome: _m01Outcome(
            result: LivingBattleResult.trapfall,
            endReason: GameEndReason.kingTrapfall,
            objectiveCompleted: false,
            kingTrapfallPieceId: 'ashen_king_orsain',
            survivingPieceIds: const <String>[
              'ashen_rook_ysra',
              'ashen_bishop_veyl',
              'ashen_knight_cael',
            ],
          ),
          now: DateTime.utc(2026, 8, 9, 1),
        );
        expect(trapfall.status, LivingRunStatus.completed);
        expect(trapfall.epilogue, isNotEmpty);
        expect(
          trapfall.namedPiecesByName['King Orsain Ashcrown']!.status,
          LivingNamedPieceStatus.dead,
        );
      },
    );
  });

  group('Living Campaign V3 ascension and pending identity rules', () {
    const reducer = LivingCampaignOutcomeReducer();

    LivingBattleOutcomeSnapshot outcomeWithStates({
      required LivingBattleResult result,
      required List<LivingPieceEndState> states,
    }) {
      final base = _m01Outcome(result: result);
      return LivingBattleOutcomeSnapshot.fromJson(<String, Object?>{
        ...base.toJson(),
        'result': result.name,
        'pieceEndStates': states.map((state) => state.toJson()).toList(),
      });
    }

    LivingPieceEndState ascension({
      required String pieceId,
      PieceColor startingColor = PieceColor.white,
      PieceColor endingColor = PieceColor.white,
      bool captured = false,
      int loyalty = 35,
      PieceType promotedType = PieceType.queen,
    }) => LivingPieceEndState(
      pieceId: pieceId,
      startingType: PieceType.pawn,
      startingColor: startingColor,
      startingSquare: startingColor == PieceColor.white
          ? const Square(6, 0)
          : const Square(1, 0),
      endingType: promotedType,
      endingColor: endingColor,
      endingSquare: captured ? null : const Square(0, 0),
      endingLoyalty: loyalty,
      wasCaptured: captured,
      wasPurchased: startingColor != endingColor,
      wasPromoted: true,
    );

    test('surviving White promotion becomes stable named advanced ally', () {
      final outcome = outcomeWithStates(
        result: LivingBattleResult.victory,
        states: <LivingPieceEndState>[
          ascension(pieceId: 'living_m01_white_pawn_a2'),
        ],
      );
      final first = reducer.apply(
        run: _fixedRun('run_ascension'),
        outcome: outcome,
        now: DateTime.utc(2026, 8, 11),
      );
      final second = reducer.apply(
        run: _fixedRun('run_ascension'),
        outcome: outcome,
        now: DateTime.utc(2026, 8, 11),
      );
      final ascended = first.namedPiecesByName.values.singleWhere(
        (record) => record.pieceId == 'living_m01_white_pawn_a2',
      );
      final repeated = second.namedPiecesByName.values.singleWhere(
        (record) => record.pieceId == 'living_m01_white_pawn_a2',
      );

      expect(ascended.name, 'The Ascended Queen');
      expect(ascended.characterId, repeated.characterId);
      expect(ascended.pieceType, PieceType.queen);
      expect(ascended.status, LivingNamedPieceStatus.ally);
      expect(ascended.needsNaming, isTrue);
      expect(ascended.loyalty, 55, reason: '35 battle-end + 20 victory');
    });

    test('defeat keeps ascension but grants no victory Loyalty', () {
      final next = reducer.apply(
        run: _fixedRun('run_ascension_defeat'),
        outcome: outcomeWithStates(
          result: LivingBattleResult.defeat,
          states: <LivingPieceEndState>[
            ascension(pieceId: 'living_m01_white_pawn_a2'),
          ],
        ),
        now: DateTime.utc(2026, 8, 11),
      );
      final ascended = next.namedPiecesByName.values.singleWhere(
        (record) => record.pieceId == 'living_m01_white_pawn_a2',
      );
      expect(ascended.loyalty, 35);
      expect(next.status, LivingRunStatus.active);
    });

    test('captured or Black-ending promotions remain non-persistent', () {
      for (final state in <LivingPieceEndState>[
        ascension(pieceId: 'captured_pawn', captured: true),
        ascension(pieceId: 'black_ending_pawn', endingColor: PieceColor.black),
      ]) {
        final next = reducer.apply(
          run: _fixedRun('run_${state.pieceId}'),
          outcome: outcomeWithStates(
            result: LivingBattleResult.victory,
            states: <LivingPieceEndState>[state],
          ),
          now: DateTime.utc(2026, 8, 11),
        );
        expect(
          next.namedPiecesByName.values.any(
            (record) => record.pieceId == state.pieceId,
          ),
          isFalse,
          reason: state.pieceId,
        );
      }
    });

    test('multiple and purchased-enemy Pawn ascensions persist together', () {
      final next = reducer.apply(
        run: _fixedRun('run_multi_ascension'),
        outcome: outcomeWithStates(
          result: LivingBattleResult.victory,
          states: <LivingPieceEndState>[
            ascension(pieceId: 'white_pawn_a'),
            ascension(pieceId: 'white_pawn_b', promotedType: PieceType.knight),
            ascension(
              pieceId: 'captured_enemy_pawn',
              startingColor: PieceColor.black,
              endingColor: PieceColor.white,
              promotedType: PieceType.rook,
              loyalty: 20,
            ),
          ],
        ),
        now: DateTime.utc(2026, 8, 11),
      );
      final pending = next.namedPiecesByName.values
          .where((record) => record.needsNaming)
          .toList();
      expect(pending, hasLength(3));
      expect(pending.map((record) => record.characterId).toSet(), hasLength(3));
      expect(
        pending
            .singleWhere((record) => record.pieceId == 'captured_enemy_pawn')
            .loyalty,
        40,
      );
    });
  });

  group('Living Campaign V2 deployment and validation', () {
    test('engine places advanced allies and one Pawn immediately ahead', () {
      final pieces = const LivingCampaignDeployment().buildPlayerPieces(
        run: _fixedRun(),
        participantCharacterIds: const <String>[
          'char_cael',
          'char_orsain',
          'char_ysra',
          'char_veyl',
        ],
      );
      final advanced = pieces
          .where((piece) => piece.pieceType != PieceType.pawn)
          .toList();
      final pawns = pieces
          .where((piece) => piece.pieceType == PieceType.pawn)
          .toList();

      expect(advanced, hasLength(4));
      expect(pawns, hasLength(4));
      expect(
        advanced
            .singleWhere((piece) => piece.pieceType == PieceType.king)
            .square,
        const Square(7, 4),
      );
      for (final piece in advanced) {
        expect(
          pawns.any(
            (pawn) =>
                pawn.square.row == piece.square.row - 1 &&
                pawn.square.col == piece.square.col,
          ),
          isTrue,
        );
      }
    });

    test(
      'Builder permits dynamic Pawn count and treats enemy-half placement as guidance',
      () {
        final run = _fixedRun();
        final director = _director(run.runId, missionNumber: 2);
        final valid = _builder(run.runId, missionNumber: 2, pawnCount: 0);
        final validator = const LivingCampaignV2Validator();
        expect(
          validator.validateBuilder(
            builder: valid,
            director: director,
            run: run,
          ),
          isEmpty,
        );

        final invalid = _builder(run.runId, missionNumber: 2, pawnCount: 9);
        expect(
          validator
              .validateBuilder(builder: invalid, director: director, run: run)
              .join(' '),
          contains('at most eight Pawns'),
        );

        final forwardJson = valid.toJson();
        final enemyPieces = (forwardJson['enemyPieces']! as List<Object?>)
            .map((value) => Map<String, Object?>.from(value! as Map))
            .toList();
        enemyPieces[1]['square'] = 'd4';
        forwardJson['enemyPieces'] = enemyPieces;
        final forwardTarget = LivingV2BuilderDecision.fromJson(forwardJson);
        expect(
          validator.validateBuilder(
            builder: forwardTarget,
            director: director,
            run: run,
          ),
          isEmpty,
          reason: 'A locked d4-style target remains playable.',
        );
        expect(
          validator.builderWarnings(builder: forwardTarget).join(' '),
          contains('d4'),
        );
      },
    );
  });

  group('Living Campaign V2 backend pipeline', () {
    test(
      'runs Chronicler, Director, and Builder through production contracts',
      () async {
        final archive = _MemoryArchiveStore();
        final run = _fixedRun();
        final gateway = _QueueGateway(<Map<String, Object?>>[
          _memory(run.runId, 1),
          _director(run.runId, missionNumber: 2).toJson(),
          _builder(run.runId, missionNumber: 2, pawnCount: 3).toJson(),
        ]);
        final backend = LivingCampaignV2Backend(
          gateway: gateway,
          archive: archive,
          promptLibrary: const _FakePromptLibrary(),
          generatePortraits: false,
          clock: () => DateTime.utc(2026, 8, 9, 2),
          idFactory: (prefix) => '${prefix}_${gateway.calls.length}',
        );

        final result = await backend.generateNextChapter(
          run: run,
          outcome: _m01Outcome(pressureTier: 'pressured'),
        );

        expect(result.completed, isTrue, reason: result.message);
        expect(result.run.activeChapterNumber, 2);
        expect(result.run.chapterPackages, hasLength(2));
        expect(result.run.missionMemories.single.runId, run.runId);
        expect(result.run.missionMemories.single.missionId, 'living_m01');
        expect(result.run.v2GenerationCheckpoint, isNull);
        expect(result.run.generationRecords, hasLength(3));
        expect(gateway.calls.map((call) => call.schemaName), <String>[
          'living_campaign_chronicler_aftermath_v3',
          'living_campaign_director_v2',
          'living_campaign_builder_v2',
        ]);
        expect(
          gateway.calls,
          everyElement(
            isA<_GatewayCall>().having(
              (call) => call.maxTokens,
              'maxTokens',
              greaterThan(200000),
            ),
          ),
        );
        expect(
          result.run.chapterPackages.last.pieces
              .where(
                (piece) =>
                    piece.color == PieceColor.black &&
                    piece.pieceType == PieceType.pawn,
              )
              .length,
          3,
        );
        expect(archive.runs[run.runId]!.activeChapterNumber, 2);
      },
    );

    test(
      'generates at most one Director-requested portrait after Builder',
      () async {
        final archive = _MemoryArchiveStore();
        final run = _fixedRun();
        final director = _director(run.runId, missionNumber: 2).toJson()
          ..['enemyNamedCharacterIds'] = <String>['char_bell_warden']
          ..['newCharacter'] = <String, Object?>{
            'name': 'The Bell Warden',
            'characterId': 'char_bell_warden',
            'pieceId': 'piece_bell_warden',
            'pieceType': 'rook',
            'status': 'enemy',
            'recruitable': false,
            'description':
                'A nameless watch commander bound to the drowned bell.',
            'loyalty': 70,
            'portraitPrompt':
                'Dark fantasy portrait of the armored Bell Warden.',
          };
        final builder = _builder(
          run.runId,
          missionNumber: 2,
          pawnCount: 1,
        ).toJson();
        final enemyPieces = (builder['enemyPieces']! as List<Object?>)
            .map((piece) => Map<String, Object?>.from(piece! as Map))
            .toList();
        enemyPieces[1]
          ..['pieceId'] = 'piece_bell_warden'
          ..['characterId'] = 'char_bell_warden';
        builder['enemyPieces'] = enemyPieces;
        final gateway = _QueueGateway(<Map<String, Object?>>[
          _memory(run.runId, 1),
          director,
          builder,
        ]);

        final result = await LivingCampaignV2Backend(
          gateway: gateway,
          archive: archive,
          promptLibrary: const _FakePromptLibrary(),
        ).generateNextChapter(run: run, outcome: _m01Outcome());

        expect(result.completed, isTrue, reason: result.message);
        expect(
          result.run.generationRecords.where(
            (record) => record.stage == LivingGenerationStage.portrait,
          ),
          hasLength(1),
        );
        final portrait = result.run.namedPiecesByName['The Bell Warden']!;
        expect(portrait.portraitPath, startsWith('memory://'));
        expect(
          result.run.canon.charactersById['char_bell_warden']!.portraitPath,
          portrait.portraitPath,
        );
        expect(archive.binaries, hasLength(2));
        final checkpoint =
            result.run.portraitCheckpointsByCharacterId['char_bell_warden']!;
        expect(checkpoint.status, LivingPortraitStatus.ready);
        expect(checkpoint.promptAsset, LivingCampaignPrompt.portrait.assetPath);
        expect(checkpoint.referenceHashes, hasLength(1));
        expect(checkpoint.sourceReference, startsWith('memory://'));
        expect(checkpoint.processedReference, portrait.portraitPath);
        expect(gateway.portraitCalls, 1);
        expect(
          gateway.lastPortraitPrompt,
          contains('System prompt for portrait'),
        );
        expect(gateway.lastPortraitPrompt, contains('Bell Warden'));
        expect(gateway.lastPortraitReferences, hasLength(1));
      },
    );

    test(
      'holds the mission until its optional portrait reaches a terminal state',
      () async {
        final archive = _MemoryArchiveStore();
        final run = _fixedRun();
        final director = _portraitDirector(run.runId);
        final builder = _portraitBuilder(run.runId);
        final portrait = Completer<DoubaoPortraitResult>();
        final gateway = _QueueGateway(
          <Map<String, Object?>>[_memory(run.runId, 1), director, builder],
          portraitResponses: <Object>[portrait],
        );
        final backend = LivingCampaignV2Backend(
          gateway: gateway,
          archive: archive,
          promptLibrary: const _FakePromptLibrary(),
        );

        final generation = backend.generateNextChapter(
          run: run,
          outcome: _m01Outcome(),
        );
        while (gateway.portraitCalls == 0) {
          await Future<void>.delayed(Duration.zero);
        }

        final exposed = archive.runs[run.runId]!;
        expect(exposed.activeChapterNumber, 1);
        expect(exposed.chapterPackages, hasLength(1));
        expect(exposed.generationJob!.stage, LivingGenerationStage.portrait);
        expect(
          exposed.portraitCheckpointsByCharacterId['char_bell_warden']!.status,
          LivingPortraitStatus.generating,
        );

        portrait.complete(_fakePortraitResult());
        final result = await generation;
        expect(result.completed, isTrue);
        expect(result.run.activeChapterNumber, 2);
        expect(result.run.chapterPackages.last.chapterNumber, 2);
        expect(result.run.generationJob, isNull);
      },
    );

    test(
      'portrait failure keeps the mission ready for explicit retry',
      () async {
        final archive = _MemoryArchiveStore();
        final run = _fixedRun();
        final gateway = _QueueGateway(
          <Map<String, Object?>>[
            _memory(run.runId, 1),
            _portraitDirector(run.runId),
            _portraitBuilder(run.runId),
          ],
          portraitResponses: const <Object>[
            LivingProviderException(
              code: 'portrait_timeout',
              safeMessage: 'Portrait timed out.',
            ),
          ],
        );
        final backend = LivingCampaignV2Backend(
          gateway: gateway,
          archive: archive,
          promptLibrary: const _FakePromptLibrary(),
        );

        final failed = await backend.generateNextChapter(
          run: run,
          outcome: _m01Outcome(),
        );

        expect(failed.completed, isTrue);
        expect(failed.run.activeChapterNumber, 2);
        expect(failed.run.generationJob, isNull);
        expect(gateway.portraitCalls, 1);
        expect(
          failed
              .run
              .portraitCheckpointsByCharacterId['char_bell_warden']!
              .status,
          LivingPortraitStatus.awaitingRetry,
        );
        expect(
          failed.run.namedPiecesByName['The Bell Warden']!.portraitPath,
          isNull,
        );

        final retried = await backend.retryPortrait(
          run: failed.run,
          characterId: 'char_bell_warden',
        );
        expect(retried.completed, isTrue);
        expect(gateway.portraitCalls, 2);
        expect(
          retried
              .run
              .portraitCheckpointsByCharacterId['char_bell_warden']!
              .status,
          LivingPortraitStatus.ready,
        );
        expect(
          retried.run.namedPiecesByName['The Bell Warden']!.portraitPath,
          startsWith('memory://'),
        );
      },
    );

    test('chapter art archives one deterministic illustrated result', () async {
      final archive = _MemoryArchiveStore();
      final outcome = _m01Outcome();
      final committed = const LivingCampaignOutcomeReducer().apply(
        run: _fixedRun('run_chapter_art'),
        outcome: outcome,
        now: DateTime.utc(2026, 8, 11),
      );
      final gateway = _QueueGateway(const <Object>[]);
      final backend = LivingCampaignV2Backend(
        gateway: gateway,
        archive: archive,
        promptLibrary: const _FakePromptLibrary(),
      );

      final result = await backend.generateChapterEndingArt(
        run: committed,
        outcome: outcome,
      );

      expect(result.completed, isTrue, reason: result.message);
      expect(gateway.chapterArtCalls, 1);
      expect(
        gateway.lastChapterArtPrompt,
        contains('Authoritative Chapter Facts'),
      );
      expect(gateway.lastChapterArtPrompt, contains('The Ashen Divide'));
      expect(gateway.lastChapterArtReferences, hasLength(1));
      expect(
        gateway.lastChapterArtSeed,
        LivingChapterArtSeed.derive(
          runId: committed.runId,
          chapterId: outcome.chapterId,
          attempt: 1,
        ),
      );
      final checkpoint =
          result.run.chapterArtCheckpointsByChapterId[outcome.chapterId]!;
      expect(checkpoint.status, LivingChapterArtStatus.ready);
      expect(checkpoint.sourceReference, startsWith('memory://'));
      expect(checkpoint.processedReference, startsWith('memory://'));
      expect(checkpoint.referenceHashes, hasLength(1));
      expect(archive.binaries, hasLength(2));
      expect(
        result.run.generationRecords.last.stage,
        LivingGenerationStage.chapterArt,
      );

      final duplicate = await backend.generateChapterEndingArt(
        run: result.run,
        outcome: outcome,
      );
      expect(duplicate.completed, isTrue);
      expect(gateway.chapterArtCalls, 1);
    });

    test(
      'chapter art failure falls back and only explicit retry pays again',
      () async {
        final archive = _MemoryArchiveStore();
        final outcome = _m01Outcome();
        final committed = const LivingCampaignOutcomeReducer().apply(
          run: _fixedRun('run_chapter_art_retry'),
          outcome: outcome,
          now: DateTime.utc(2026, 8, 11),
        );
        final gateway = _QueueGateway(
          const <Object>[],
          chapterArtResponses: <Object>[
            const LivingProviderException(
              code: 'chapter_art_generation_timeout',
              safeMessage: 'The final scene took too long to paint.',
            ),
            _fakeChapterArtResult(),
          ],
        );
        final backend = LivingCampaignV2Backend(
          gateway: gateway,
          archive: archive,
          promptLibrary: const _FakePromptLibrary(),
        );

        final failed = await backend.generateChapterEndingArt(
          run: committed,
          outcome: outcome,
        );

        expect(failed.completed, isFalse);
        expect(gateway.chapterArtCalls, 1);
        expect(
          failed
              .run
              .chapterArtCheckpointsByChapterId[outcome.chapterId]!
              .status,
          LivingChapterArtStatus.awaitingRetry,
        );
        expect(
          failed.run.generationRecords.last.errorCode,
          'chapter_art_generation_timeout',
        );

        final retried = await backend.retryChapterEndingArt(
          run: failed.run,
          chapterId: outcome.chapterId,
        );
        expect(retried.completed, isTrue, reason: retried.message);
        expect(gateway.chapterArtCalls, 2);
        expect(
          retried
              .run
              .chapterArtCheckpointsByChapterId[outcome.chapterId]!
              .attempt,
          2,
        );
        expect(
          retried
              .run
              .chapterArtCheckpointsByChapterId[outcome.chapterId]!
              .status,
          LivingChapterArtStatus.ready,
        );
      },
    );

    test('a complete-invalid stage receives exactly one repair', () async {
      final archive = _MemoryArchiveStore();
      final run = _fixedRun();
      final invalidMemory = _memory(run.runId, 1)
        ..['setupSummary'] = 'One. Two. Three.';
      final gateway = _QueueGateway(<Map<String, Object?>>[
        invalidMemory,
        _memory(run.runId, 1),
        _director(run.runId, missionNumber: 2).toJson(),
        _builder(run.runId, missionNumber: 2, pawnCount: 1).toJson(),
      ]);
      final backend = LivingCampaignV2Backend(
        gateway: gateway,
        archive: archive,
        promptLibrary: const _FakePromptLibrary(),
        generatePortraits: false,
      );

      final result = await backend.generateNextChapter(
        run: run,
        outcome: _m01Outcome(),
      );

      expect(result.completed, isTrue, reason: result.message);
      expect(gateway.calls, hasLength(4));
      expect(
        result.run.generationRecords.first.status,
        LivingGenerationStatus.failed,
      );
      expect(
        result.run.generationRecords[1].repairsRecordId,
        result.run.generationRecords.first.recordId,
      );
    });

    test(
      'transport failure preserves accepted checkpoint for explicit retry',
      () async {
        final archive = _MemoryArchiveStore();
        final run = _fixedRun();
        final failingGateway = _QueueGateway(<Object>[
          _memory(run.runId, 1),
          const LivingProviderException(
            code: 'network_error',
            safeMessage: 'Network interrupted.',
          ),
        ]);
        final first = await LivingCampaignV2Backend(
          gateway: failingGateway,
          archive: archive,
          promptLibrary: const _FakePromptLibrary(),
          generatePortraits: false,
        ).generateNextChapter(run: run, outcome: _m01Outcome());

        expect(first.completed, isFalse);
        expect(first.run.v2GenerationCheckpoint!.missionMemory, isNotNull);
        expect(first.run.v2GenerationCheckpoint!.directorDecision, isNull);
        expect(
          first.run.generationJob!.status,
          LivingGenerationStatus.awaitingResume,
        );

        final retryGateway = _QueueGateway(<Map<String, Object?>>[
          _director(run.runId, missionNumber: 2).toJson(),
          _builder(run.runId, missionNumber: 2, pawnCount: 2).toJson(),
        ]);
        final retried = await LivingCampaignV2Backend(
          gateway: retryGateway,
          archive: archive,
          promptLibrary: const _FakePromptLibrary(),
          generatePortraits: false,
        ).generateNextChapter(run: first.run, outcome: _m01Outcome());

        expect(retried.completed, isTrue, reason: retried.message);
        expect(retryGateway.calls.map((call) => call.schemaName), <String>[
          'living_campaign_director_v2',
          'living_campaign_builder_v2',
        ]);
      },
    );

    test(
      'compresses older history at 55% while preserving latest memory',
      () async {
        final archive = _MemoryArchiveStore();
        final base = _fixedRun();
        final run = base.copyWith(
          missionMemories: <LivingMissionMemory>[
            const LivingMissionMemory(
              runId: 'run_v2_test',
              missionNumber: 0,
              missionId: 'living_m00',
              setupSummary: 'The Ashen Court burned before naming its heir.',
              battleSummary: 'The survivors fled toward the Ruined Causeway.',
              characterIds: <String>['char_orsain'],
              keyEventIds: <String>['event_run_v2_test_prologue'],
            ),
            LivingMissionMemory.fromJson(_memory(base.runId, 1)),
          ],
        );
        final gateway = _QueueGateway(
          <Map<String, Object?>>[
            _memory(run.runId, 1),
            <String, Object?>{
              'schemaVersion': 2,
              'runId': run.runId,
              'digestId': 'digest_m00',
              'sourceMissionIds': <String>['living_m00'],
              'narrative': 'Compressed history.',
            },
            _director(run.runId, missionNumber: 2).toJson(),
            _builder(run.runId, missionNumber: 2, pawnCount: 2).toJson(),
          ],
          tokenCounter: (values) =>
              values.join().contains('Compressed history') ? 10 : 100,
        );
        final backend = LivingCampaignV2Backend(
          gateway: gateway,
          archive: archive,
          promptLibrary: const _FakePromptLibrary(),
          generatePortraits: false,
          capability: const LivingModelCapabilityProfile(
            contextTokens: 2000,
            compressionThreshold: .04,
          ),
        );

        final result = await backend.generateNextChapter(
          run: run,
          outcome: _m01Outcome(),
        );

        expect(result.completed, isTrue, reason: result.message);
        expect(result.run.historyDigests, hasLength(1));
        expect(result.run.missionMemories, hasLength(2));
        expect(gateway.calls.map((call) => call.schemaName), <String>[
          'living_campaign_chronicler_aftermath_v3',
          'living_campaign_history_digest_v2',
          'living_campaign_director_v2',
          'living_campaign_builder_v2',
        ]);
        final previousStories =
            gateway.calls[2].userPayload['previousStories']! as List<Object?>;
        expect(previousStories, hasLength(2));
        expect(
          Map<String, Object?>.from(previousStories.first! as Map),
          contains('historyDigest'),
        );
        expect(
          Map<String, Object?>.from(previousStories.last! as Map)['missionId'],
          'living_m01',
        );
      },
    );
  });
}

LivingCampaignRun _fixedRun([String runId = 'run_v2_test']) =>
    LivingCampaignFixedOpener.create(
      runId: runId,
      now: DateTime.utc(2026, 8, 9),
    );

LivingBattleOutcomeSnapshot _m01Outcome({
  LivingBattleResult result = LivingBattleResult.victory,
  GameEndReason endReason = GameEndReason.checkmate,
  bool objectiveCompleted = true,
  String pressureTier = 'even',
  String? kingTrapfallPieceId,
  List<String>? survivingPieceIds,
}) => LivingBattleOutcomeSnapshot(
  chapterNumber: 1,
  chapterId: 'living_m01',
  result: result,
  endReason: endReason,
  objectiveType: LivingObjectiveType.checkmate,
  pressureTier: pressureTier,
  objectiveCompleted: objectiveCompleted,
  completedTurns: 18,
  goldBefore: 10,
  goldAfterBattle: 13,
  survivingPieceIds:
      survivingPieceIds ??
      const <String>[
        'ashen_king_orsain',
        'ashen_rook_ysra',
        'ashen_bishop_veyl',
        'ashen_knight_cael',
        'living_m01_white_pawn_a2',
        'living_m01_white_pawn_c2',
        'living_m01_white_pawn_e2',
        'living_m01_white_pawn_g2',
      ],
  capturedPieces: const <LivingCapturedPieceOutcome>[],
  purchasedPieceIds: const <String>[],
  missionRoleChanges: const <String, PieceType>{},
  matchLog: const <String>[
    'Turn 1: Ysra secured the western causeway.',
    'Turn 18: Orsain forced the rival King to yield.',
  ],
  kingTrapfallPieceId: kingTrapfallPieceId,
);

Map<String, Object?> _memory(
  String runId,
  int missionNumber,
) => <String, Object?>{
  'schemaVersion': 3,
  'runId': runId,
  'missionNumber': missionNumber,
  'missionId': 'living_m${missionNumber.toString().padLeft(2, '0')}',
  'setupSummary':
      'The divided Ashen Court faced its rivals on the Ruined Causeway and chose to clear the road without slaughter.',
  'battleSummary':
      'Orsain won the crossing with the advanced court intact and carried the unfinished crown onward.',
  'characterIds': <String>[
    'char_orsain',
    'char_ysra',
    'char_veyl',
    'char_cael',
  ],
  'keyEventIds': <String>['living_m01_result'],
  'identityAssignments': const <Object?>[],
  'aftermath': <Object?>[
    <String, Object?>{
      'lineId': 'living_m01_aftermath_01',
      'speakerId': 'char_orsain',
      'side': 'left',
      'text': 'The causeway is ours, but every stone remembers its price.',
    },
  ],
};

LivingV2DirectorDecision _director(
  String runId, {
  required int missionNumber,
}) => LivingV2DirectorDecision(
  schemaVersion: 2,
  runId: runId,
  basedOnMissionNumber: missionNumber - 1,
  nextMissionNumber: missionNumber,
  title: 'The Bell Beyond the Causeway',
  subtitle: 'A warning tolls where no bell should remain.',
  background:
      'Beyond the broken road, the Ashen survivors find a watchtower signaling to an unseen army.',
  dialogue: const <LivingDialogueLine>[
    LivingDialogueLine(
      lineId: 'm02_line_01',
      speakerId: 'char_ysra',
      side: 'left',
      text: 'That bell is calling soldiers to our trail.',
    ),
    LivingDialogueLine(
      lineId: 'm02_line_02',
      speakerId: 'char_orsain',
      side: 'right',
      text: 'Then hold the tower until its warning dies.',
    ),
  ],
  objectiveType: LivingObjectiveType.surviveRounds,
  objectiveLabel: 'Hold the watchtower for 20 full rounds',
  surviveRounds: 20,
  participantCharacterIds: const <String>[
    'char_orsain',
    'char_ysra',
    'char_veyl',
    'char_cael',
  ],
  enemyNamedCharacterIds: const <String>[],
  statusChanges: const <LivingDirectorStatusChange>[],
  pressureTier: 'pressured',
  rewardTier: 20,
  finaleKind: LivingFinaleKind.none,
  campaignComplete: false,
);

LivingV2BuilderDecision _builder(
  String runId, {
  required int missionNumber,
  required int pawnCount,
}) => LivingV2BuilderDecision(
  schemaVersion: 2,
  runId: runId,
  missionNumber: missionNumber,
  blackCountryId: 'iron',
  startingTurn: PieceColor.white,
  battlefieldId: BattlefieldId.ruinedCauseway,
  seed: 2200 + missionNumber,
  blackGold: 16,
  merchantSpeed: 4,
  enemyPieces: <LivingMissionPiece>[
    LivingMissionPiece(
      pieceId: 'm${missionNumber}_enemy_king',
      pieceType: PieceType.king,
      color: PieceColor.black,
      square: const Square(0, 4),
      countryId: 'iron',
      loyalty: null,
      fairPrice: null,
    ),
    const LivingMissionPiece(
      pieceId: 'm_enemy_rook',
      pieceType: PieceType.rook,
      color: PieceColor.black,
      square: Square(1, 0),
      countryId: 'iron',
      loyalty: 70,
      fairPrice: 22,
    ),
    for (var index = 0; index < pawnCount; index += 1)
      LivingMissionPiece(
        pieceId: 'm${missionNumber}_enemy_pawn_$index',
        pieceType: PieceType.pawn,
        color: PieceColor.black,
        square: Square(2 + (index ~/ 8), index % 8),
        countryId: 'iron',
        loyalty: 60,
        fairPrice: 6,
      ),
  ],
);

Map<String, Object?> _portraitDirector(String runId) {
  final director = _director(runId, missionNumber: 2).toJson()
    ..['enemyNamedCharacterIds'] = <String>['char_bell_warden']
    ..['newCharacter'] = <String, Object?>{
      'name': 'The Bell Warden',
      'characterId': 'char_bell_warden',
      'pieceId': 'piece_bell_warden',
      'pieceType': 'rook',
      'status': 'enemy',
      'recruitable': false,
      'description': 'A nameless watch commander bound to the drowned bell.',
      'loyalty': 70,
      'portraitPrompt': 'Dark fantasy portrait of the armored Bell Warden.',
    };
  return director;
}

Map<String, Object?> _portraitBuilder(String runId) {
  final builder = _builder(runId, missionNumber: 2, pawnCount: 1).toJson();
  final enemyPieces = (builder['enemyPieces']! as List<Object?>)
      .map((piece) => Map<String, Object?>.from(piece! as Map))
      .toList();
  enemyPieces[1]
    ..['pieceId'] = 'piece_bell_warden'
    ..['characterId'] = 'char_bell_warden';
  builder['enemyPieces'] = enemyPieces;
  return builder;
}

DoubaoPortraitResult _fakePortraitResult({String prompt = 'portrait prompt'}) {
  return DoubaoPortraitResult(
    pngBytes: Uint8List.fromList(const <int>[137, 80, 78, 71]),
    width: 1,
    height: 1,
    finalPrompt: prompt,
    requestId: 'portrait-request',
    redactedRawResponse: '{}',
  );
}

DoubaoChapterArtResult _fakeChapterArtResult({
  String prompt = 'chapter prompt',
}) {
  return DoubaoChapterArtResult(
    imageBytes: Uint8List.fromList(const <int>[137, 80, 78, 71]),
    width: 2560,
    height: 1440,
    finalPrompt: prompt,
    requestId: 'chapter-art-request',
    redactedRawResponse: '{}',
  );
}

class _GatewayCall {
  const _GatewayCall({
    required this.schemaName,
    required this.maxTokens,
    required this.userPayload,
  });

  final String schemaName;
  final int maxTokens;
  final Map<String, Object?> userPayload;
}

class _QueueGateway implements LivingCampaignV2Gateway {
  _QueueGateway(
    List<Object> responses, {
    int Function(Iterable<String> values)? tokenCounter,
    List<Object> portraitResponses = const <Object>[],
    List<Object> chapterArtResponses = const <Object>[],
  }) : _responses = List.of(responses),
       _portraitResponses = List.of(portraitResponses),
       _chapterArtResponses = List.of(chapterArtResponses),
       _tokenCounter = tokenCounter;

  final List<Object> _responses;
  final List<Object> _portraitResponses;
  final List<Object> _chapterArtResponses;
  final int Function(Iterable<String> values)? _tokenCounter;
  final List<_GatewayCall> calls = <_GatewayCall>[];
  int portraitCalls = 0;
  int chapterArtCalls = 0;
  String? lastPortraitPrompt;
  List<Uint8List> lastPortraitReferences = const <Uint8List>[];
  String? lastChapterArtPrompt;
  int? lastChapterArtSeed;
  List<Uint8List> lastChapterArtReferences = const <Uint8List>[];

  @override
  String get textModel => 'doubao-seed-2-1-turbo-260628';

  @override
  String get imageModel => 'fake-image-model';

  @override
  Future<DoubaoTokenizationResult> countTextTokens(
    Iterable<String> values,
  ) async => DoubaoTokenizationResult(
    totalTokens: _tokenCounter?.call(values) ?? 100,
    requestId: 'token-request',
    model: 'doubao-seed-2-1-turbo-260628',
  );

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    required Map<String, Object?> jsonSchema,
    required String jsonSchemaName,
    required int maxTokens,
    required double temperature,
    DoubaoStreamProgressCallback? onProgress,
  }) async {
    calls.add(
      _GatewayCall(
        schemaName: jsonSchemaName,
        maxTokens: maxTokens,
        userPayload: userPayload,
      ),
    );
    final response = _responses.removeAt(0);
    if (response is LivingProviderException) throw response;
    final value = Map<String, Object?>.from(response as Map);
    onProgress?.call(
      DoubaoStreamProgress(
        phase: DoubaoStreamPhase.receiving,
        occurredAt: DateTime.utc(2026, 8, 9),
        requestId: 'request-${calls.length}',
        receivedContentCharacters: 100,
      ),
    );
    return DoubaoJsonResponse(
      value: value,
      requestId: 'request-${calls.length}',
      model: textModel,
      usage: const <String, Object?>{
        'prompt_tokens': 100,
        'completion_tokens': 80,
      },
      redactedRawResponse: 'data: redacted\n\ndata: [DONE]\n',
      rawContent: value.toString(),
      finishReason: 'stop',
      timeToFirstEvent: const Duration(milliseconds: 25),
      duration: const Duration(milliseconds: 80),
    );
  }

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) async {
    portraitCalls++;
    lastPortraitPrompt = prompt;
    lastPortraitReferences = List<Uint8List>.unmodifiable(referenceImages);
    if (_portraitResponses.isNotEmpty) {
      final response = _portraitResponses.removeAt(0);
      if (response is LivingProviderException) throw response;
      if (response is Completer<DoubaoPortraitResult>) {
        final result = await response.future;
        if (onSourceDownloaded != null) {
          await onSourceDownloaded(result.pngBytes);
        }
        return result;
      }
      if (response is DoubaoPortraitResult) {
        if (onSourceDownloaded != null) {
          await onSourceDownloaded(response.pngBytes);
        }
        return response;
      }
    }
    final result = _fakePortraitResult(prompt: prompt);
    if (onSourceDownloaded != null) {
      await onSourceDownloaded(result.pngBytes);
    }
    return result;
  }

  @override
  Future<DoubaoChapterArtResult> generateChapterEndingArt({
    required String prompt,
    required int seed,
    List<Uint8List> referenceImages = const <Uint8List>[],
    FutureOr<void> Function(Uint8List sourceBytes)? onSourceDownloaded,
  }) async {
    chapterArtCalls++;
    lastChapterArtPrompt = prompt;
    lastChapterArtSeed = seed;
    lastChapterArtReferences = List<Uint8List>.unmodifiable(referenceImages);
    if (_chapterArtResponses.isNotEmpty) {
      final response = _chapterArtResponses.removeAt(0);
      if (response is LivingProviderException) throw response;
      if (response is Completer<DoubaoChapterArtResult>) {
        final result = await response.future;
        await onSourceDownloaded?.call(result.imageBytes);
        return result;
      }
      if (response is DoubaoChapterArtResult) {
        await onSourceDownloaded?.call(response.imageBytes);
        return response;
      }
    }
    final bytes = Uint8List.fromList(const <int>[137, 80, 78, 71]);
    await onSourceDownloaded?.call(bytes);
    return DoubaoChapterArtResult(
      imageBytes: bytes,
      width: 2560,
      height: 1440,
      finalPrompt: prompt,
      requestId: 'chapter-art-$chapterArtCalls',
      redactedRawResponse: '{}',
    );
  }

  @override
  Future<List<Uint8List>> loadPortraitStyleReferences() async => <Uint8List>[
    Uint8List.fromList(const <int>[1, 2, 3, 4]),
  ];
}

class _FakePromptLibrary implements LivingCampaignPromptLibrary {
  const _FakePromptLibrary();

  @override
  Future<String> load(LivingCampaignPrompt prompt) async =>
      'System prompt for ${prompt.name}.';
}

class _MemoryArchiveStore implements LivingCampaignArchiveStore {
  final Map<String, LivingCampaignRun> runs = <String, LivingCampaignRun>{};
  final Map<String, LivingCampaignRunTimingMetrics> metrics =
      <String, LivingCampaignRunTimingMetrics>{};
  final Map<String, Uint8List> binaries = <String, Uint8List>{};

  @override
  Future<void> initialize() async {}

  @override
  Future<void> writeRun(LivingCampaignRun run) async {
    runs[run.runId] = run;
  }

  @override
  Future<LivingCampaignRun?> readRun(String runId) async => runs[runId];

  @override
  Future<void> writeTimingMetrics(LivingCampaignRunTimingMetrics value) async {
    metrics[value.runId] = value;
  }

  @override
  Future<LivingCampaignRunTimingMetrics?> readTimingMetrics(
    String runId,
  ) async => metrics[runId];

  @override
  Future<List<LivingRunArchiveSummary>> listRuns() async => const [];

  @override
  Future<void> deleteRun(String runId) async {
    runs.remove(runId);
    metrics.remove(runId);
  }

  @override
  Future<int> storageBytes() async => 0;

  @override
  Future<String> writeBinary({
    required String runId,
    required String fileName,
    required Uint8List bytes,
  }) async {
    final reference = 'memory://$runId/$fileName';
    binaries[reference] = bytes;
    return reference;
  }

  @override
  Future<Uint8List?> readBinary(String reference) async => binaries[reference];
}
