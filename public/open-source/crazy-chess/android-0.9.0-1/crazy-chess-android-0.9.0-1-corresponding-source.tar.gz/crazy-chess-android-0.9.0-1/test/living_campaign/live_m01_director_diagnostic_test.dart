@Tags(<String>['live'])
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:crazy_chess/living_campaign/living_campaign_context.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_prompt_library.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:crazy_chess/living_campaign/living_campaign_validator.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;

const _runLive = bool.fromEnvironment(
  'RUN_LIVING_CAMPAIGN_M01_DIRECTOR_LIVE_TEST',
);
const _apiKey = String.fromEnvironment('ARK_API_KEY');
const _baseUrl = String.fromEnvironment(
  'ARK_BASE_URL',
  defaultValue: LivingCampaignSettings.defaultBaseUrl,
);
const _textModel = String.fromEnvironment(
  'LIVING_CAMPAIGN_TEXT_MODEL',
  defaultValue: LivingCampaignSettings.defaultTextModel,
);
const _sourcePath = String.fromEnvironment(
  'LIVING_CAMPAIGN_M01_DIRECTOR_SOURCE',
  defaultValue: 'test/fixtures/living_campaign/m01_live_director_source.json',
);
const _outputRoot = String.fromEnvironment(
  'LIVING_CAMPAIGN_M01_DIRECTOR_OUTPUT',
  defaultValue: 'test_result/20260806-232323_living-campaign-live-m01-director',
);

const _firstEventTimeout = Duration(seconds: 120);
const _idleTimeout = Duration(seconds: 60);
const _absoluteTimeout = Duration(minutes: 10);
const _jsonEncoder = JsonEncoder.withIndent('  ');

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'current M01 state produces one reviewable Director response',
    () async {
      expect(_apiKey, isNotEmpty, reason: 'ARK_API_KEY was not injected.');

      final sourceFile = File(_sourcePath);
      expect(
        await sourceFile.exists(),
        isTrue,
        reason: 'The current M01 source fixture is missing: $_sourcePath',
      );
      final sourceJson = _asObject(jsonDecode(await sourceFile.readAsString()));
      final sourceRun = LivingCampaignRun.fromJson(sourceJson);
      expect(
        sourceRun.battleOutcomes,
        isNotEmpty,
        reason: 'The source run has no verified M01 outcome.',
      );
      final outcome = sourceRun.battleOutcomes.last;
      expect(outcome.chapterId, 'living_m01');

      final outputDirectory = Directory(_outputRoot);
      await outputDirectory.create(recursive: true);
      final attemptMarker = File(
        '${outputDirectory.path}/attempt-started.json',
      );
      expect(
        await attemptMarker.exists(),
        isFalse,
        reason:
            'This one-shot paid diagnostic directory has already been used. '
            'Review its files or select a new output directory explicitly.',
      );

      final startedAt = DateTime.now().toUtc();
      await _writeJson(attemptMarker, <String, Object?>{
        'kind': 'living-campaign-live-m01-director-diagnostic',
        'authorized': true,
        'maximumPaidChatRequests': 1,
        'automaticRetry': false,
        'automaticRepair': false,
        'builderEnabled': false,
        'portraitEnabled': false,
        'model': _textModel,
        'thinking': const <String, Object?>{'type': 'disabled'},
        'sourcePath': _sourcePath,
        'sourceRunId': sourceRun.runId,
        'sourceChapterId': outcome.chapterId,
        'startedAt': startedAt.toIso8601String(),
      });

      final projection = const LivingCanonContextBuilder().complete(
        canon: sourceRun.canon,
        outcome: outcome,
      );
      final systemPrompt = await AssetLivingCampaignPromptLibrary().load(
        LivingCampaignPrompt.director,
      );
      final requestBody = <String, Object?>{
        'model': _textModel,
        'messages': <Map<String, Object?>>[
          <String, Object?>{'role': 'system', 'content': systemPrompt},
          <String, Object?>{
            'role': 'user',
            'content': jsonEncode(projection.payload),
          },
        ],
        'stream': true,
        'stream_options': const <String, Object?>{'include_usage': true},
        'max_tokens': 8192,
        'temperature': .2,
        'thinking': const <String, Object?>{'type': 'disabled'},
      };
      await _writeJson(
        File('${outputDirectory.path}/request.json'),
        <String, Object?>{
          'kind': 'redacted-provider-request',
          'sourcePath': _sourcePath,
          'sourceRunId': sourceRun.runId,
          'sourceOutcome': outcome.toJson(),
          'projectionCompacted': projection.compacted,
          'endpoint': '${_normalizedBaseUrl(_baseUrl)}/chat/completions',
          'headers': const <String, String>{
            'Content-Type': 'application/json',
            'Authorization': 'Bearer [REDACTED]',
          },
          'body': requestBody,
        },
      );

      final diagnostics = _SseDiagnostics();
      final stopwatch = Stopwatch()..start();
      final client = http.Client();
      http.StreamedResponse? response;
      Object? terminalError;
      StackTrace? terminalStackTrace;
      Map<String, Object?>? parsedJson;
      Map<String, Object?> validation = const <String, Object?>{
        'attempted': false,
      };
      var paidRequestCount = 0;

      try {
        final request =
            http.Request(
                'POST',
                Uri.parse('${_normalizedBaseUrl(_baseUrl)}/chat/completions'),
              )
              ..headers.addAll(<String, String>{
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $_apiKey',
              })
              ..body = jsonEncode(requestBody);

        paidRequestCount++;
        response = await client.send(request).timeout(_firstEventTimeout);
        diagnostics.providerRequestId = _requestIdFromHeaders(response.headers);

        final iterator = StreamIterator<String>(
          response.stream.transform(utf8.decoder),
        );
        var waitingForFirstBodyChunk = true;
        try {
          while (true) {
            final remaining = _absoluteTimeout - stopwatch.elapsed;
            if (remaining <= Duration.zero) {
              throw TimeoutException(
                'The 10-minute absolute diagnostic limit elapsed.',
                _absoluteTimeout,
              );
            }
            final activityLimit = waitingForFirstBodyChunk
                ? _firstEventTimeout
                : _idleTimeout;
            final waitLimit = Duration(
              milliseconds: math.min(
                remaining.inMilliseconds,
                activityLimit.inMilliseconds,
              ),
            );
            final hasNext = await iterator.moveNext().timeout(waitLimit);
            if (!hasNext) break;
            waitingForFirstBodyChunk = false;
            diagnostics.addChunk(iterator.current, stopwatch.elapsed);
          }
        } finally {
          await iterator.cancel();
        }
        diagnostics.close(stopwatch.elapsed);

        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw HttpException(
            'Ark returned HTTP ${response.statusCode}.',
            uri: request.url,
          );
        }
        if (diagnostics.providerError != null) {
          throw StateError('Ark provider error: ${diagnostics.providerError}');
        }
        if (!diagnostics.sawDone) {
          throw StateError(
            'Ark closed the stream without a [DONE] completion event.',
          );
        }
        if (diagnostics.answer.isEmpty) {
          throw StateError('Ark completed without final answer content.');
        }

        parsedJson = _asObject(jsonDecode(_stripJsonFence(diagnostics.answer)));
        await _writeJson(
          File('${outputDirectory.path}/parsed-json.json'),
          parsedJson,
        );

        try {
          final patch = LivingDirectorPatch.fromJson(parsedJson);
          final nextCanon = const LivingCampaignValidator().applyDirectorPatch(
            canon: projection.canon,
            outcome: outcome,
            patch: patch,
          );
          validation = <String, Object?>{
            'attempted': true,
            'valid': true,
            'parsedAs': 'LivingDirectorPatch',
            'nextCanonRevision': nextCanon.revision,
          };
        } on LivingCampaignValidationException catch (error) {
          validation = <String, Object?>{
            'attempted': true,
            'valid': false,
            'parsedAs': 'LivingDirectorPatch',
            'issues': error.issues,
          };
        } on Object catch (error) {
          validation = <String, Object?>{
            'attempted': true,
            'valid': false,
            'parsedAs': 'Map<String, Object?> only',
            'error': '$error',
          };
        }
      } on Object catch (error, stackTrace) {
        terminalError = error;
        terminalStackTrace = stackTrace;
      } finally {
        stopwatch.stop();
        client.close();
        await File(
          '${outputDirectory.path}/raw-provider-stream.txt',
        ).writeAsString(diagnostics.rawStream, flush: true);
        await File(
          '${outputDirectory.path}/raw-reasoning.txt',
        ).writeAsString(diagnostics.reasoning, flush: true);
        await File(
          '${outputDirectory.path}/raw-model-response.txt',
        ).writeAsString(diagnostics.answer, flush: true);
        await _writeJson(
          File('${outputDirectory.path}/validation.json'),
          validation,
        );
        if (parsedJson == null && diagnostics.answer.isNotEmpty) {
          await _writeJson(
            File('${outputDirectory.path}/parse-error.json'),
            <String, Object?>{
              'parsed': false,
              'error':
                  terminalError?.toString() ??
                  'The response was not parsed before the test ended.',
            },
          );
        }
        await _writeJson(
          File('${outputDirectory.path}/metadata.json'),
          <String, Object?>{
            'kind': 'living-campaign-live-m01-director-diagnostic-result',
            'paidRequestCount': paidRequestCount,
            'model': diagnostics.model ?? _textModel,
            'thinking': const <String, Object?>{'type': 'disabled'},
            'httpStatus': response?.statusCode,
            'providerRequestId': diagnostics.providerRequestId,
            'startedAt': startedAt.toIso8601String(),
            'finishedAt': DateTime.now().toUtc().toIso8601String(),
            'durationMs': stopwatch.elapsedMilliseconds,
            'timeToFirstBodyChunkMs': diagnostics.timeToFirstChunkMs,
            'timeToFirstSseEventMs': diagnostics.timeToFirstEventMs,
            'bodyChunkCount': diagnostics.chunkCount,
            'sseEventCount': diagnostics.eventCount,
            'sawDone': diagnostics.sawDone,
            'finishReason': diagnostics.finishReason,
            'usage': diagnostics.usage,
            'reasoningCharacters': diagnostics.reasoning.length,
            'answerCharacters': diagnostics.answer.length,
            'jsonParsed': parsedJson != null,
            'productionValidation': validation,
            if (diagnostics.providerError != null)
              'providerError': diagnostics.providerError,
            if (terminalError != null) 'terminalError': '$terminalError',
            if (terminalStackTrace != null)
              'terminalStackTrace': '$terminalStackTrace',
          },
        );
      }

      expect(paidRequestCount, 1);
      if (terminalError != null) {
        fail(
          'The single live request ended with $terminalError. '
          'Partial evidence was preserved in $_outputRoot.',
        );
      }
      expect(parsedJson, isNotNull);
    },
    skip: !_runLive,
    timeout: const Timeout(Duration(minutes: 12)),
  );
}

class _SseDiagnostics {
  final StringBuffer _rawStream = StringBuffer();
  final StringBuffer _reasoning = StringBuffer();
  final StringBuffer _answer = StringBuffer();
  final List<String> _eventDataLines = <String>[];
  String _lineBuffer = '';

  String? providerRequestId;
  String? model;
  String? finishReason;
  String? providerError;
  Map<String, Object?> usage = const <String, Object?>{};
  int? timeToFirstChunkMs;
  int? timeToFirstEventMs;
  int chunkCount = 0;
  int eventCount = 0;
  bool sawDone = false;

  String get rawStream => _rawStream.toString();
  String get reasoning => _reasoning.toString();
  String get answer => _answer.toString();

  void addChunk(String chunk, Duration elapsed) {
    chunkCount++;
    timeToFirstChunkMs ??= elapsed.inMilliseconds;
    _rawStream.write(chunk);
    _lineBuffer += chunk;
    while (true) {
      final lineEnd = _lineBuffer.indexOf('\n');
      if (lineEnd < 0) return;
      var line = _lineBuffer.substring(0, lineEnd);
      _lineBuffer = _lineBuffer.substring(lineEnd + 1);
      if (line.endsWith('\r')) line = line.substring(0, line.length - 1);
      _acceptLine(line, elapsed);
    }
  }

  void close(Duration elapsed) {
    if (_lineBuffer.isNotEmpty) {
      var line = _lineBuffer;
      _lineBuffer = '';
      if (line.endsWith('\r')) line = line.substring(0, line.length - 1);
      _acceptLine(line, elapsed);
    }
    _dispatchEvent(elapsed);
  }

  void _acceptLine(String line, Duration elapsed) {
    if (line.isEmpty) {
      _dispatchEvent(elapsed);
      return;
    }
    if (line.startsWith('data:')) {
      var data = line.substring('data:'.length);
      if (data.startsWith(' ')) data = data.substring(1);
      _eventDataLines.add(data);
    }
  }

  void _dispatchEvent(Duration elapsed) {
    if (_eventDataLines.isEmpty) return;
    final data = _eventDataLines.join('\n');
    _eventDataLines.clear();
    eventCount++;
    timeToFirstEventMs ??= elapsed.inMilliseconds;
    if (data.trim() == '[DONE]') {
      sawDone = true;
      return;
    }

    try {
      final event = _asObject(jsonDecode(data));
      providerRequestId ??= event['id'] as String?;
      model ??= event['model'] as String?;
      final rawUsage = event['usage'];
      if (rawUsage is Map) usage = Map<String, Object?>.from(rawUsage);
      if (event['error'] != null) providerError = '${event['error']}';

      final choices = event['choices'];
      if (choices is! List) return;
      for (final rawChoice in choices) {
        if (rawChoice is! Map) continue;
        final choice = Map<String, Object?>.from(rawChoice);
        final rawFinishReason = choice['finish_reason'];
        if (rawFinishReason is String && rawFinishReason.isNotEmpty) {
          finishReason = rawFinishReason;
        }
        final rawDelta = choice['delta'];
        if (rawDelta is! Map) continue;
        final delta = Map<String, Object?>.from(rawDelta);
        _appendText(
          _reasoning,
          delta['reasoning_content'] ?? delta['reasoningContent'],
        );
        _appendText(_answer, delta['content']);
      }
    } on Object catch (error) {
      providerError = 'Invalid SSE JSON event: $error';
    }
  }
}

void _appendText(StringBuffer target, Object? value) {
  if (value is String) {
    target.write(value);
    return;
  }
  if (value is List) {
    for (final item in value) {
      if (item is String) {
        target.write(item);
      } else if (item is Map && item['text'] is String) {
        target.write(item['text']);
      }
    }
  }
}

Map<String, Object?> _asObject(Object? value) {
  if (value is! Map) {
    throw const FormatException('Expected a JSON object.');
  }
  return Map<String, Object?>.from(value);
}

String _normalizedBaseUrl(String value) {
  final trimmed = value.trim();
  return trimmed.endsWith('/')
      ? trimmed.substring(0, trimmed.length - 1)
      : trimmed;
}

String? _requestIdFromHeaders(Map<String, String> headers) {
  for (final key in const <String>[
    'x-request-id',
    'x-ark-request-id',
    'x-tt-logid',
  ]) {
    final value = headers[key];
    if (value != null && value.trim().isNotEmpty) return value.trim();
  }
  return null;
}

String _stripJsonFence(String value) {
  var trimmed = value.trim();
  if (trimmed.startsWith('```json')) {
    trimmed = trimmed.substring('```json'.length).trimLeft();
  } else if (trimmed.startsWith('```')) {
    trimmed = trimmed.substring(3).trimLeft();
  }
  if (trimmed.endsWith('```')) {
    trimmed = trimmed.substring(0, trimmed.length - 3).trimRight();
  }
  return trimmed;
}

Future<void> _writeJson(File file, Map<String, Object?> value) async {
  await file.writeAsString('${_jsonEncoder.convert(value)}\n', flush: true);
}
