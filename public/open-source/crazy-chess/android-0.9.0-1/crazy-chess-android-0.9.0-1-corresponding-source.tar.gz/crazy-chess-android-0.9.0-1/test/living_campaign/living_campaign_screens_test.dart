import 'dart:async';
import 'dart:typed_data';

import 'package:crazy_chess/app/responsive_game_viewport.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/game/game_controller.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store.dart';
import 'package:crazy_chess/living_campaign/living_campaign_controller.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_generation_service.dart';
import 'package:crazy_chess/living_campaign/living_campaign_metrics.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:crazy_chess/living_campaign/living_campaign_v2_backend.dart';
import 'package:crazy_chess/ui/living_campaign/living_campaign_screens.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Future<void> setSurface(WidgetTester tester) async {
    await tester.binding.setSurfaceSize(const Size(1600, 900));
    addTearDown(() => tester.binding.setSurfaceSize(null));
  }

  testWidgets('chapter dialogue exposes backlog before the briefing', (
    tester,
  ) async {
    await setSurface(tester);
    final fixture = _fixture('dialogue');
    addTearDown(fixture.dispose);
    fixture.controller.activeRun = fixture.run;
    fixture.controller.phase = LivingCampaignPhase.dialogue;

    await tester.pumpWidget(
      MaterialApp(
        home: AnimatedBuilder(
          animation: fixture.controller,
          builder: (_, _) =>
              fixture.controller.phase == LivingCampaignPhase.dialogue
              ? LivingCampaignDialogueScreen(
                  controller: fixture.controller,
                  onHub: fixture.controller.returnToHub,
                )
              : const ColoredBox(
                  key: ValueKey('dialogue-test-briefing-reached'),
                  color: Colors.black,
                ),
        ),
      ),
    );
    await tester.pump();

    expect(find.textContaining('causeway remembers every army'), findsNothing);
    expect(find.textContaining('Those are Ashen shields'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('living-dialogue-backlog')));
    await tester.pump(const Duration(milliseconds: 350));
    expect(
      find.byKey(const ValueKey('living-dialogue-backlog-dialog')),
      findsOneWidget,
    );
    expect(find.text('Dame Ysra Stonehand'), findsWidgets);
    await tester.tap(find.text('Return'));
    await tester.pump(const Duration(milliseconds: 350));

    for (var index = 0; index < 12; index++) {
      await tester.tap(find.byKey(const ValueKey('living-dialogue-next')));
      await tester.pump();
    }
    expect(fixture.controller.phase, LivingCampaignPhase.briefing);
    expect(
      find.byKey(const ValueKey('dialogue-test-briefing-reached')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('history exposes durable characters and unfinished tales', (
    tester,
  ) async {
    await setSurface(tester);
    final fixture = _fixture('history');
    addTearDown(fixture.dispose);
    fixture.controller.inspectedRun = fixture.run;
    fixture.controller.phase = LivingCampaignPhase.history;
    fixture.controller.storageBytes = 1234;

    await tester.pumpWidget(
      MaterialApp(
        home: LivingCampaignHistoryScreen(controller: fixture.controller),
      ),
    );
    await tester.pump(const Duration(milliseconds: 350));

    expect(
      find.byKey(const ValueKey('living-campaign-history')),
      findsOneWidget,
    );
    expect(
      find.text('No completed chapter has entered canon yet.'),
      findsOneWidget,
    );
    await tester.tap(
      find.descendant(
        of: find.byType(TabBar),
        matching: find.text('CHARACTERS'),
      ),
    );
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));
    final tabs = DefaultTabController.of(tester.element(find.byType(TabBar)));
    expect(tabs.index, 1);
    await tester.scrollUntilVisible(
      find.byKey(const ValueKey('living-history-character-char_orsain')),
      240,
      scrollable: find.byType(Scrollable).last,
    );
    expect(find.text('King Orsain Ashcrown'), findsOneWidget);
    expect(
      find.byKey(const ValueKey('living-history-character-char_orsain')),
      findsOneWidget,
    );

    final firstThread = fixture.run.canon.storyThreadsById.values.first;
    await tester.tap(find.text('UNFINISHED TALES'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 350));
    expect(find.text(firstThread.title), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('failed portrait checkpoint is labeled as Retry Portrait', (
    tester,
  ) async {
    await setSurface(tester);
    final fixture = _fixture('retry-label');
    addTearDown(fixture.dispose);
    final now = DateTime.utc(2026, 8, 6);
    final chapterJson =
        Map<String, Object?>.from(fixture.run.chapterPackages.first.toJson())
          ..['portraitCharacterId'] = 'char_orsain'
          ..['portraitPrompt'] = 'The Ashen King.';
    fixture.controller.activeRun = fixture.run.copyWith(
      chapterPackages: <LivingChapterPackage>[
        LivingChapterPackage.fromJson(chapterJson),
      ],
      portraitCheckpointsByCharacterId: <String, LivingPortraitCheckpoint>{
        'char_orsain': LivingPortraitCheckpoint(
          runId: fixture.run.runId,
          missionId: 'living_m01',
          missionNumber: 1,
          characterId: 'char_orsain',
          attempt: 1,
          seed: 42,
          status: LivingPortraitStatus.awaitingRetry,
          appearanceBrief: 'The Ashen King.',
          promptAsset: 'assets/prompts/living_campaign/portrait.md',
          createdAt: now,
          updatedAt: now,
          errorCode: 'portrait_timeout',
          errorMessage: 'The portrait request timed out.',
        ),
      },
    );
    fixture.controller.phase = LivingCampaignPhase.hub;

    await tester.pumpWidget(
      MaterialApp(
        home: LivingCampaignHubScreen(
          controller: fixture.controller,
          settings: EffectiveLivingCampaignSettings.resolve(
            saved: const LivingCampaignSettings(apiKey: 'local-test-key'),
            developer: const LivingDeveloperEnvironment(),
          ),
          onBack: () {},
          onPlayAnotherMode: () {},
          onSettings: () {},
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Seek Their Likeness Again'), findsOneWidget);
    expect(find.text('A FACE YET UNSEEN'), findsOneWidget);
    expect(find.text('Continue Story'), findsOneWidget);
    expect(find.byKey(const ValueKey('living-open-history')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  for (final size in <Size>[const Size(1600, 900), const Size(1280, 720)]) {
    testWidgets(
      'background generation hub remains usable at ${size.width.toInt()}x${size.height.toInt()}',
      (tester) async {
        await tester.binding.setSurfaceSize(size);
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final archive = _MemoryArchiveStore();
        final game = GameController();
        final generation = Completer<LivingGenerationResult>();
        final controller = LivingCampaignController(
          gameController: game,
          archive: archive,
          generatePrologue: (run) async =>
              LivingGenerationResult(run: run, completed: false),
          generateNextChapter: (run, outcome) => generation.future,
        );
        addTearDown(() {
          controller.dispose();
          game.dispose();
        });
        await controller.initialize();
        await controller.startNewRun();
        final outcome = _fixedOutcome(controller.activeRun!);
        final ready = _readyForNextGeneration(controller.activeRun!, outcome);
        await archive.writeRun(ready);
        controller
          ..activeRun = ready
          ..pendingOutcome = outcome;
        await controller.generateFollowingChapter();
        var leftForAnotherMode = false;

        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: ResponsiveGameViewport(
                child: LivingCampaignHubScreen(
                  controller: controller,
                  settings: EffectiveLivingCampaignSettings.resolve(
                    saved: const LivingCampaignSettings(
                      apiKey: 'local-test-key',
                    ),
                    developer: const LivingDeveloperEnvironment(),
                  ),
                  onBack: () {},
                  onPlayAnotherMode: () => leftForAnotherMode = true,
                  onSettings: () {},
                ),
              ),
            ),
          ),
        );
        await tester.pump();

        expect(
          find.byKey(const ValueKey('living-generation-progress-card')),
          findsOneWidget,
        );
        expect(
          find.byKey(const ValueKey('living-play-another-mode')),
          findsOneWidget,
        );
        final continueButton = tester.widget<FilledButton>(
          find.byKey(const ValueKey('living-continue-run')),
        );
        expect(continueButton.onPressed, isNull);
        await tester.tap(
          find.byKey(const ValueKey('living-play-another-mode')),
        );
        expect(leftForAnotherMode, isTrue);
        final completion = controller.activeGenerationCompletion!;
        generation.complete(
          LivingGenerationResult(
            run: _completeWithGeneratedMission(controller.activeRun!),
            completed: true,
          ),
        );
        await completion;
        await tester.pump();
        expect(controller.directorStatus, LivingDirectorStatus.ready);
        expect(tester.takeException(), isNull);
      },
    );
  }

  for (final size in <Size>[const Size(1600, 900), const Size(1280, 720)]) {
    testWidgets(
      'aftermath dialogue, backlog, and Skip remain readable at ${size.width.toInt()}x${size.height.toInt()}',
      (tester) async {
        await tester.binding.setSurfaceSize(size);
        addTearDown(() => tester.binding.setSurfaceSize(null));
        final fixture = _fixture('aftermath-${size.width.toInt()}');
        addTearDown(fixture.dispose);
        final outcome = _fixedOutcome(fixture.run);
        final scene = LivingAftermathScene(
          runId: fixture.run.runId,
          missionNumber: 1,
          missionId: outcome.chapterId,
          lines: const <LivingAftermathLine>[
            LivingAftermathLine(
              lineId: 'after_01',
              speakerId: 'char_ysra',
              side: 'left',
              text: 'The causeway is quiet, but it has not forgiven us.',
            ),
            LivingAftermathLine(
              lineId: 'after_02',
              speakerId: 'char_orsain',
              side: 'right',
              text: 'Then we carry its memory beyond the broken banners.',
            ),
          ],
        );
        fixture.controller
          ..activeRun = fixture.run.copyWith(
            aftermathScenesByChapterId: <String, LivingAftermathScene>{
              outcome.chapterId: scene,
            },
            chapterClosureCheckpointsByChapterId:
                <String, LivingChapterClosureCheckpoint>{
                  outcome.chapterId: LivingChapterClosureCheckpoint(
                    runId: fixture.run.runId,
                    chapterId: outcome.chapterId,
                    chapterNumber: 1,
                    closureId: 'closure-screen',
                    textTaskId: 'text-screen',
                    imageTaskId: 'image-screen',
                    textAttempt: 1,
                    imageAttempt: 1,
                    textStatus: LivingClosureTaskStatus.ready,
                    imageStatus: LivingClosureTaskStatus.ready,
                    createdAt: DateTime.utc(2026, 8, 11),
                    updatedAt: DateTime.utc(2026, 8, 11),
                  ),
                },
          )
          ..pendingOutcome = outcome
          ..phase = LivingCampaignPhase.aftermathDialogue;

        await tester.pumpWidget(
          MaterialApp(
            home: ResponsiveGameViewport(
              child: LivingCampaignAftermathScreen(
                controller: fixture.controller,
              ),
            ),
          ),
        );
        await tester.pump();

        expect(
          find.byKey(const ValueKey('living-campaign-aftermath')),
          findsOneWidget,
        );
        expect(find.text('DAME YSRA STONEHAND'), findsOneWidget);
        expect(find.text('Backlog'), findsOneWidget);
        expect(find.text('Skip'), findsOneWidget);
        expect(find.textContaining('Chronicler'), findsNothing);
        expect(find.textContaining('Builder'), findsNothing);
        expect(find.textContaining('validation'), findsNothing);

        await tester.tap(
          find.byKey(const ValueKey('living-aftermath-backlog')),
        );
        await tester.pumpAndSettle();
        expect(
          find.byKey(const ValueKey('living-aftermath-backlog-dialog')),
          findsOneWidget,
        );
        await tester.tap(find.text('Return'));
        await tester.pumpAndSettle();
        await tester.tap(find.text('Skip'));
        await tester.pump();
        expect(fixture.controller.phase, LivingCampaignPhase.chapterEnding);
        expect(tester.takeException(), isNull);
      },
    );
  }
}

LivingBattleOutcomeSnapshot _fixedOutcome(LivingCampaignRun run) =>
    LivingBattleOutcomeSnapshot(
      chapterNumber: 1,
      chapterId: 'living_m01',
      result: LivingBattleResult.victory,
      endReason: GameEndReason.checkmate,
      objectiveType: run.chapterPackages.first.objective.type,
      objectiveCompleted: true,
      completedTurns: 10,
      goldBefore: 10,
      goldAfterBattle: 12,
      survivingPieceIds: const <String>[
        'ashen_rook_ysra',
        'ashen_bishop_veyl',
        'ashen_king_orsain',
        'ashen_knight_cael',
      ],
      capturedPieces: const <LivingCapturedPieceOutcome>[],
      purchasedPieceIds: const <String>[],
      missionRoleChanges: const <String, PieceType>{},
      matchLog: const <String>['The Ashen Court secured the causeway.'],
    );

LivingCampaignRun _completeWithGeneratedMission(LivingCampaignRun run) {
  final json = Map<String, Object?>.from(run.chapterPackages.first.toJson())
    ..['basedOnRevision'] = run.canon.revision
    ..['chapterNumber'] = 2
    ..['chapterId'] = 'living_m02'
    ..['title'] = 'The Responsive Crown'
    ..['subtitle'] = 'The next mission is ready.'
    ..['briefing'] = 'Secure the crossing that remembers every army.';
  return run.copyWith(
    activeChapterNumber: 2,
    chapterPackages: <LivingChapterPackage>[
      ...run.chapterPackages,
      LivingChapterPackage.fromJson(json),
    ],
    clearGenerationJob: true,
    clearV2GenerationCheckpoint: true,
  );
}

LivingCampaignRun _readyForNextGeneration(
  LivingCampaignRun source,
  LivingBattleOutcomeSnapshot outcome,
) {
  final now = DateTime.utc(2026, 8, 11);
  final run = const LivingCampaignOutcomeReducer().apply(
    run: source,
    outcome: outcome,
    now: now,
  );
  final memory = LivingMissionMemory(
    runId: run.runId,
    missionNumber: outcome.chapterNumber,
    missionId: outcome.chapterId,
    setupSummary: 'The Ashen Court crossed a road that remembered its claim.',
    battleSummary: 'The court survived the causeway and counted every cost.',
  );
  return run.copyWith(
    missionMemories: <LivingMissionMemory>[...run.missionMemories, memory],
    v2GenerationCheckpoint: run.v2GenerationCheckpoint!.copyWith(
      missionMemory: memory,
    ),
    chapterClosureCheckpointsByChapterId:
        <String, LivingChapterClosureCheckpoint>{
          outcome.chapterId: LivingChapterClosureCheckpoint(
            runId: run.runId,
            chapterId: outcome.chapterId,
            chapterNumber: outcome.chapterNumber,
            closureId: 'closure_${outcome.chapterId}',
            textTaskId: 'text_${outcome.chapterId}',
            imageTaskId: 'image_${outcome.chapterId}',
            textAttempt: 1,
            imageAttempt: 1,
            textStatus: LivingClosureTaskStatus.ready,
            imageStatus: LivingClosureTaskStatus.ready,
            createdAt: now,
            updatedAt: now,
          ),
        },
  );
}

class _LivingScreenFixture {
  const _LivingScreenFixture({
    required this.controller,
    required this.game,
    required this.run,
  });

  final LivingCampaignController controller;
  final GameController game;
  final LivingCampaignRun run;

  void dispose() {
    controller.dispose();
    game.dispose();
  }
}

_LivingScreenFixture _fixture(String suffix) {
  final archive = _MemoryArchiveStore();
  final game = GameController();
  final controller = LivingCampaignController(
    gameController: game,
    archive: archive,
    generatePrologue: (run) async =>
        LivingGenerationResult(run: run, completed: true),
    generateNextChapter: (run, outcome) async =>
        LivingGenerationResult(run: run, completed: false),
  );
  final sourceRun =
      LivingCampaignFixedOpener.create(
        runId: 'run-screen-$suffix',
        now: DateTime.utc(2026, 8, 6),
      ).copyWith(
        campaignTitle: 'The Ashen Test Chronicle',
        storyPromise: 'A test chronicle remembers every verified choice.',
      );
  final runJson = sourceRun.toJson();
  final canonJson = Map<String, Object?>.from(runJson['canon']! as Map);
  final characters = Map<String, Object?>.from(
    canonJson['charactersById']! as Map,
  );
  for (final entry in characters.entries) {
    final character = Map<String, Object?>.from(entry.value! as Map)
      ..remove('portraitPath');
    characters[entry.key] = character;
  }
  canonJson['charactersById'] = characters;
  runJson['canon'] = canonJson;
  final run = LivingCampaignRun.fromJson(runJson);
  return _LivingScreenFixture(controller: controller, game: game, run: run);
}

class _MemoryArchiveStore implements LivingCampaignArchiveStore {
  final Map<String, LivingCampaignRun> runs = <String, LivingCampaignRun>{};
  final Map<String, LivingCampaignRunTimingMetrics> metrics =
      <String, LivingCampaignRunTimingMetrics>{};
  final Map<String, Uint8List> binaries = <String, Uint8List>{};

  @override
  Future<void> initialize() async {}

  @override
  Future<void> writeRun(LivingCampaignRun run) async {
    runs[run.runId] = run;
  }

  @override
  Future<LivingCampaignRun?> readRun(String runId) async => runs[runId];

  @override
  Future<void> writeTimingMetrics(LivingCampaignRunTimingMetrics value) async {
    metrics[value.runId] = value;
  }

  @override
  Future<LivingCampaignRunTimingMetrics?> readTimingMetrics(
    String runId,
  ) async => metrics[runId];

  @override
  Future<List<LivingRunArchiveSummary>> listRuns() async => const [];

  @override
  Future<void> deleteRun(String runId) async {
    runs.remove(runId);
    metrics.remove(runId);
  }

  @override
  Future<int> storageBytes() async =>
      binaries.values.fold<int>(0, (sum, bytes) => sum + bytes.length);

  @override
  Future<String> writeBinary({
    required String runId,
    required String fileName,
    required Uint8List bytes,
  }) async {
    final reference = 'memory://$runId/$fileName';
    binaries[reference] = bytes;
    return reference;
  }

  @override
  Future<Uint8List?> readBinary(String reference) async => binaries[reference];
}
