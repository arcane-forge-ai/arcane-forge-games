import 'dart:io';

import 'package:crazy_chess/living_campaign/living_campaign_developer_env_loader_io.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;

void main() {
  test(
    'workspace loader finds the nearest Crazy Chess env from a build path',
    () async {
      final root = await Directory.systemTemp.createTemp(
        'crazy-chess-env-loader-',
      );
      addTearDown(() async {
        if (await root.exists()) {
          await root.delete(recursive: true);
        }
      });
      await File(
        p.join(root.path, 'pubspec.yaml'),
      ).writeAsString('name: crazy_chess\n');
      await File(
        p.join(root.path, '.env'),
      ).writeAsString('ARK_API_KEY=test-key\n');
      final nested = Directory(
        p.join(root.path, 'build', 'macos', 'Build', 'Products', 'Debug'),
      );
      await nested.create(recursive: true);

      final source = await readLivingCampaignDeveloperEnvironmentFromRoots(
        <String>[nested.path],
      );

      expect(source, 'ARK_API_KEY=test-key\n');
    },
  );

  test(
    'workspace loader ignores env files without the project marker',
    () async {
      final root = await Directory.systemTemp.createTemp(
        'other-project-env-loader-',
      );
      addTearDown(() async {
        if (await root.exists()) {
          await root.delete(recursive: true);
        }
      });
      await File(
        p.join(root.path, 'pubspec.yaml'),
      ).writeAsString('name: another_game\n');
      await File(
        p.join(root.path, '.env'),
      ).writeAsString('ARK_API_KEY=wrong-key\n');

      final source = await readLivingCampaignDeveloperEnvironmentFromRoots(
        <String>[root.path],
      );

      expect(source, isNull);
    },
  );
}
