import 'package:crazy_chess/audio/audio_settings.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:crazy_chess/playtest/playtest_data_exporter.dart';
import 'package:crazy_chess/ui/menu/remaining_flow_screens.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemorySettingsStore implements LivingCampaignSettingsStore {
  String? value;

  @override
  Future<void> clear() async => value = null;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async => this.value = value;
}

void main() {
  testWidgets(
    'Living AI panel displays env overrides without saving them as player data',
    (tester) async {
      await tester.binding.setSurfaceSize(const Size(1600, 900));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      final store = _MemorySettingsStore();
      final repository = LivingCampaignSettingsRepository(store: store);
      await repository.save(
        const LivingCampaignSettings(
          apiKey: 'player-key',
          textModel: 'player-text',
        ),
      );
      final controller = LivingCampaignSettingsController(
        repository: repository,
        developerEnvironment: const LivingDeveloperEnvironment(
          apiKey: 'developer-key',
          textModel: 'developer-text',
        ),
      );
      addTearDown(controller.dispose);
      await controller.initialize();

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SettingsScreen(
              onLobby: () {},
              onCollection: () {},
              onCourt: () {},
              onLoadout: () {},
              onRecords: () {},
              onRules: () {},
              selectedCategory: SettingsCategory.livingAi,
              onCategoryChanged: (_) {},
              reducedEffects: false,
              onReducedEffectsChanged: (_) {},
              audioSettings: const GameAudioSettings(),
              onMasterVolumeChanged: (_) {},
              onMusicVolumeChanged: (_) {},
              onSfxVolumeChanged: (_) {},
              onMasterMutedChanged: (_) {},
              onMusicMutedChanged: (_) {},
              onSfxMutedChanged: (_) {},
              livingSettingsController: controller,
              onTestLivingAi: () async {},
              onExportPlaytestData: _unusedExport,
            ),
          ),
        ),
      );
      await tester.pump();

      final keyField = tester.widget<TextField>(
        find.byKey(const ValueKey('living-ai-api-key')),
      );
      final textModelField = tester.widget<TextField>(
        find.byKey(const ValueKey('living-ai-text-model')),
      );
      expect(keyField.controller!.text, 'developer-key');
      expect(keyField.readOnly, isTrue);
      expect(
        keyField.decoration!.helperText,
        'Effective source: developer .env',
      );
      expect(textModelField.controller!.text, 'developer-text');
      expect(textModelField.readOnly, isTrue);
      expect(
        textModelField.decoration!.helperText,
        'Effective source: developer .env',
      );
      expect(
        find.textContaining('not copied into saved player settings'),
        findsOneWidget,
      );

      await tester.ensureVisible(find.byKey(const ValueKey('living-ai-save')));
      await tester.tap(find.byKey(const ValueKey('living-ai-save')));
      await tester.pumpAndSettle();
      final persisted = await repository.load();
      expect(persisted.apiKey, 'player-key');
      expect(persisted.textModel, 'player-text');
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('preview panel hides bundled provider configuration', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(1600, 900));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final store = _MemorySettingsStore();
    final controller = LivingCampaignSettingsController(
      repository: LivingCampaignSettingsRepository(store: store),
      developerEnvironment: const LivingDeveloperEnvironment(
        apiKey: 'developer-secret',
      ),
      previewBuildConfig: const PreviewBuildConfig(
        enabled: true,
        label: 'Preview 1',
        apiKey: 'preview-secret',
      ),
    );
    addTearDown(controller.dispose);
    await controller.initialize();

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SettingsScreen(
            onLobby: () {},
            onCollection: () {},
            onCourt: () {},
            onLoadout: () {},
            onRecords: () {},
            onRules: () {},
            selectedCategory: SettingsCategory.livingAi,
            onCategoryChanged: (_) {},
            reducedEffects: false,
            onReducedEffectsChanged: (_) {},
            audioSettings: const GameAudioSettings(),
            onMasterVolumeChanged: (_) {},
            onMusicVolumeChanged: (_) {},
            onSfxVolumeChanged: (_) {},
            onMasterMutedChanged: (_) {},
            onMusicMutedChanged: (_) {},
            onSfxMutedChanged: (_) {},
            livingSettingsController: controller,
            onTestLivingAi: () async {},
            onExportPlaytestData: _unusedExport,
          ),
        ),
      ),
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey('living-ai-included-access')),
      findsOneWidget,
    );
    expect(find.text('Included AI access'), findsOneWidget);
    expect(find.textContaining('preview-secret'), findsNothing);
    expect(find.textContaining('developer-secret'), findsNothing);
    expect(find.byKey(const ValueKey('living-ai-api-key')), findsNothing);
    expect(find.byKey(const ValueKey('living-ai-base-url')), findsNothing);
    expect(find.byKey(const ValueKey('living-ai-save')), findsNothing);
    expect(find.byKey(const ValueKey('living-ai-delete-key')), findsNothing);
    expect(find.byKey(const ValueKey('living-ai-test')), findsOneWidget);
    expect(store.value, isNull);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Playtest Data panel exports and reports the saved ZIP', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(1600, 900));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final controller = LivingCampaignSettingsController(
      repository: LivingCampaignSettingsRepository(
        store: _MemorySettingsStore(),
      ),
      developerEnvironment: const LivingDeveloperEnvironment(),
    );
    addTearDown(controller.dispose);
    await controller.initialize();

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SettingsScreen(
            onLobby: () {},
            onCollection: () {},
            onCourt: () {},
            onLoadout: () {},
            onRecords: () {},
            onRules: () {},
            selectedCategory: SettingsCategory.playtestData,
            onCategoryChanged: (_) {},
            reducedEffects: false,
            onReducedEffectsChanged: (_) {},
            audioSettings: const GameAudioSettings(),
            onMasterVolumeChanged: (_) {},
            onMusicVolumeChanged: (_) {},
            onSfxVolumeChanged: (_) {},
            onMasterMutedChanged: (_) {},
            onMusicMutedChanged: (_) {},
            onSfxMutedChanged: (_) {},
            livingSettingsController: controller,
            onTestLivingAi: () async {},
            onExportPlaytestData: () async => const PlaytestDataExportResult(
              fileName: 'crazy-chess-playtest-data.zip',
              filePath: '/Downloads/crazy-chess-playtest-data.zip',
              byteSize: 2048,
              runCount: 2,
              metricsCount: 2,
              diagnosticFileCount: 1,
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Export Playtest Data'), findsOneWidget);
    expect(
      find.textContaining('Nothing uploads automatically'),
      findsOneWidget,
    );
    await tester.tap(find.byKey(const ValueKey('playtest-data-export')));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 1));

    expect(
      find.byKey(const ValueKey('playtest-data-export-success')),
      findsOneWidget,
    );
    expect(
      find.text('Exported 2 runs, 2 timing files, and 1 diagnostic logs.'),
      findsOneWidget,
    );
    expect(
      find.text('/Downloads/crazy-chess-playtest-data.zip'),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
}

Future<PlaytestDataExportResult> _unusedExport() async =>
    const PlaytestDataExportResult(
      fileName: 'unused.zip',
      filePath: '/Downloads/unused.zip',
      byteSize: 0,
      runCount: 0,
      metricsCount: 0,
      diagnosticFileCount: 0,
    );
