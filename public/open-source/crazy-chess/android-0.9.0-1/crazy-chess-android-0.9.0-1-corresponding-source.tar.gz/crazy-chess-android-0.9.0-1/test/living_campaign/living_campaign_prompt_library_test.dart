import 'dart:convert';
import 'dart:io';

import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store_io.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_generation_service.dart';
import 'package:crazy_chess/living_campaign/living_campaign_prompt_library.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('all packaged prompt assets load with their current wording', () async {
    final library = AssetLivingCampaignPromptLibrary();
    final prompts = <LivingCampaignPrompt, String>{
      for (final prompt in LivingCampaignPrompt.values)
        prompt: await library.load(prompt),
    };

    expect(prompts, hasLength(12));
    expect(prompts[LivingCampaignPrompt.prologue], startsWith('You write'));
    expect(
      prompts[LivingCampaignPrompt.prologueRepair],
      contains('every validation issue'),
    );
    expect(prompts[LivingCampaignPrompt.chronicler], contains('one or two'));
    expect(
      prompts[LivingCampaignPrompt.chroniclerRepair],
      contains('single allowed repair'),
    );
    expect(prompts[LivingCampaignPrompt.director], contains('previousStories'));
    expect(
      prompts[LivingCampaignPrompt.directorRepair],
      contains('single allowed repair'),
    );
    expect(
      prompts[LivingCampaignPrompt.builder],
      contains('Choose 0–8 black Pawns dynamically'),
    );
    expect(
      prompts[LivingCampaignPrompt.builderRepair],
      contains('Director story'),
    );
    expect(
      prompts[LivingCampaignPrompt.historyCompressor],
      contains('half the counted source'),
    );
    expect(
      prompts[LivingCampaignPrompt.historyCompressorRepair],
      contains('half-length token budget'),
    );
    expect(
      prompts[LivingCampaignPrompt.portrait],
      contains('perfectly flat, untextured chroma-key green background'),
    );
    expect(
      prompts[LivingCampaignPrompt.chapterEndingArt],
      contains('Widescreen 16:9'),
    );
  });

  test('prompt loads are cached per library instance', () async {
    final bundle = _MemoryAssetBundle(<String, String>{
      LivingCampaignPrompt.director.assetPath: 'Director prompt',
    });
    final library = AssetLivingCampaignPromptLibrary(bundle: bundle);

    expect(
      await library.load(LivingCampaignPrompt.director),
      'Director prompt',
    );
    expect(
      await library.load(LivingCampaignPrompt.director),
      'Director prompt',
    );
    expect(bundle.loadCount, 1);
  });

  test('blank prompt stops generation before any gateway call', () async {
    final temp = await Directory.systemTemp.createTemp('living-prompt-stop-');
    addTearDown(() => temp.delete(recursive: true));
    final gateway = _NoCallGateway();
    final service = LivingCampaignGenerationService(
      gateway: gateway,
      archive: IoLivingCampaignArchiveStore(rootProvider: () async => temp),
      promptLibrary: AssetLivingCampaignPromptLibrary(
        bundle: _MemoryAssetBundle(<String, String>{
          LivingCampaignPrompt.prologue.assetPath: '   \n',
        }),
      ),
      clock: () => DateTime.utc(2026, 8, 7),
      idFactory: (prefix) => '$prefix-prompt-test',
    );
    final run = LivingCampaignFixedOpener.create(
      runId: 'run-prompt-asset-failure',
      now: DateTime.utc(2026, 8, 7),
    );

    final result = await service.generatePrologue(run);

    expect(result.completed, isFalse);
    expect(result.message, contains('prompt could not be loaded'));
    expect(result.run.generationJob?.errorCode, 'prompt_asset_unavailable');
    expect(gateway.calls, 0);
  });
}

class _MemoryAssetBundle extends CachingAssetBundle {
  _MemoryAssetBundle(this.values);

  final Map<String, String> values;
  int loadCount = 0;

  @override
  Future<ByteData> load(String key) async {
    loadCount++;
    final value = values[key];
    if (value == null) throw StateError('Missing test asset: $key');
    final bytes = Uint8List.fromList(utf8.encode(value));
    return ByteData.sublistView(bytes);
  }
}

class _NoCallGateway implements LivingGenerationGateway {
  int calls = 0;

  @override
  String get imageModel => 'image-unused';

  @override
  String get textModel => 'text-unused';

  @override
  Future<DoubaoTokenizationResult> countTextTokens(Iterable<String> values) {
    calls++;
    throw StateError(
      'Gateway must not be called when a prompt is unavailable.',
    );
  }

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    int maxTokens = 8192,
    double temperature = .25,
    DoubaoStreamProgressCallback? onProgress,
  }) {
    calls++;
    throw StateError(
      'Gateway must not be called when a prompt is unavailable.',
    );
  }

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
  }) {
    calls++;
    throw StateError(
      'Gateway must not be called when a prompt is unavailable.',
    );
  }
}
