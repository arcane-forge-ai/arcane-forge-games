import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_portrait_resolver.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('maps five advanced classes to two accepted fallback assets each', () {
    for (final type in const <PieceType>[
      PieceType.king,
      PieceType.queen,
      PieceType.rook,
      PieceType.bishop,
      PieceType.knight,
    ]) {
      final assets = LivingPortraitFallbackResolver.neutralAssets(type);
      expect(assets, hasLength(2));
      expect(assets[0], endsWith('unknown_${type.name}_a.webp'));
      expect(assets[1], endsWith('unknown_${type.name}_b.webp'));
    }
    expect(
      LivingPortraitFallbackResolver.neutralAssets(PieceType.pawn),
      isEmpty,
    );
    expect(
      LivingPortraitFallbackResolver.neutralAsset(
        PieceType.pawn,
        stableKey: 'run:character',
      ),
      isNull,
    );
  });

  test(
    'stable fallback pooling uses both accepted variants without flicker',
    () {
      const type = PieceType.knight;
      final first = LivingPortraitFallbackResolver.neutralAsset(
        type,
        stableKey: 'run-1:char-grey',
      );
      expect(
        LivingPortraitFallbackResolver.neutralAsset(
          type,
          stableKey: 'run-1:char-grey',
        ),
        first,
      );
      final observed = <String?>{
        for (var index = 0; index < 100; index++)
          LivingPortraitFallbackResolver.neutralAsset(
            type,
            stableKey: 'run-1:character-$index',
          ),
      };
      expect(
        observed,
        LivingPortraitFallbackResolver.neutralAssets(type).toSet(),
      );
    },
  );

  test('registers the four owner-selected fixed recruit portraits', () {
    expect(
      LivingPortraitFallbackResolver.fixedAsset('char_maelin_cinderveil'),
      endsWith('maelin_half_body.webp'),
    );
    expect(
      LivingPortraitFallbackResolver.fixedAsset('char_hadrik_emberwall'),
      endsWith('hadrik_half_body.webp'),
    );
    expect(
      LivingPortraitFallbackResolver.fixedAsset('char_neris_last_bell'),
      endsWith('neris_half_body.webp'),
    );
    expect(
      LivingPortraitFallbackResolver.fixedAsset('char_tavian_greyspur'),
      endsWith('tavian_half_body.webp'),
    );
  });

  test('packages all four fixed and ten pooled fallback assets', () async {
    final paths = <String>{
      LivingPortraitFallbackResolver.maelinAsset,
      LivingPortraitFallbackResolver.hadrikAsset,
      LivingPortraitFallbackResolver.nerisAsset,
      LivingPortraitFallbackResolver.tavianAsset,
      for (final type in const <PieceType>[
        PieceType.king,
        PieceType.queen,
        PieceType.rook,
        PieceType.bishop,
        PieceType.knight,
      ])
        ...LivingPortraitFallbackResolver.neutralAssets(type),
    };
    expect(paths, hasLength(14));
    for (final path in paths) {
      final data = await rootBundle.load(path);
      expect(data.lengthInBytes, greaterThan(0), reason: path);
    }
  });

  test('backfills authored paths but preserves run-local generated art', () {
    final run = LivingCampaignFixedOpener.create(
      runId: 'portrait-backfill',
      now: DateTime.utc(2026, 8, 10),
    );
    final named = <String, LivingNamedPieceRecord>{
      for (final entry in run.namedPiecesByName.entries)
        entry.key: _withoutPortrait(entry.value),
    };
    final hadrik = named['Warden Hadrik Emberwall']!;
    named['Warden Hadrik Emberwall'] = hadrik.copyWith(
      portraitPath: 'living_portraits/portrait-backfill/hadrik.webp',
    );
    final oldRun = run.copyWith(
      namedPiecesByName: named,
      canon: run.canon.copyWith(
        charactersById: <String, LivingCharacter>{
          ...run.canon.charactersById,
          'char_maelin_cinderveil': const LivingCharacter(
            characterId: 'char_maelin_cinderveil',
            originalName: 'Lady Maelin Cinderveil',
            originalIdentity: 'An Ashen claimant.',
            basePieceType: PieceType.queen,
            lifeState: LivingLifeState.alive,
            whereabouts: LivingWhereabouts.withCourt,
            allegiance: LivingAllegiance.player,
            firstChapter: 2,
            lastChapter: 2,
          ),
        },
      ),
    );

    final migrated = LivingPortraitFallbackResolver.backfillAuthoredPortraits(
      oldRun,
    );
    expect(
      migrated.namedPiecesByName['Lady Maelin Cinderveil']!.portraitPath,
      LivingPortraitFallbackResolver.maelinAsset,
    );
    expect(
      migrated.canon.charactersById['char_maelin_cinderveil']!.portraitPath,
      LivingPortraitFallbackResolver.maelinAsset,
    );
    expect(
      migrated.namedPiecesByName['Warden Hadrik Emberwall']!.portraitPath,
      'living_portraits/portrait-backfill/hadrik.webp',
    );
    expect(
      LivingPortraitFallbackResolver.backfillAuthoredPortraits(migrated),
      same(migrated),
    );
  });
}

LivingNamedPieceRecord _withoutPortrait(LivingNamedPieceRecord value) =>
    LivingNamedPieceRecord(
      name: value.name,
      characterId: value.characterId,
      pieceId: value.pieceId,
      pieceType: value.pieceType,
      status: value.status,
      recruitable: value.recruitable,
      description: value.description,
      loyalty: value.loyalty,
      discoveredMission: value.discoveredMission,
      lastKnownMission: value.lastKnownMission,
    );
