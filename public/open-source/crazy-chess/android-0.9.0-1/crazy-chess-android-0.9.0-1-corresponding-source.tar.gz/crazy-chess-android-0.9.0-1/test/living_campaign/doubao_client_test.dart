import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:image/image.dart' as img;

void main() {
  test('client defaults match the approved independent safety limits', () {
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(apiKey: 'secret-key'),
    );
    addTearDown(client.close);

    expect(client.tokenizationTimeout, const Duration(seconds: 10));
    expect(client.firstEventTimeout, const Duration(seconds: 120));
    expect(client.streamIdleTimeout, const Duration(seconds: 60));
    expect(client.streamAbsoluteTimeout, const Duration(minutes: 10));
    expect(client.portraitGenerationTimeout, const Duration(seconds: 120));
    expect(client.portraitDownloadTimeout, const Duration(seconds: 60));
    expect(client.chapterArtGenerationTimeout, const Duration(seconds: 120));
    expect(client.chapterArtDownloadTimeout, const Duration(seconds: 60));
  });

  test('tokenization uses the official text array contract', () async {
    late http.Request captured;
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'secret-key',
        baseUrl: 'https://ark.example/api/v3',
        textModel: 'text-model',
      ),
      httpClient: MockClient((request) async {
        captured = request;
        return http.Response(
          jsonEncode(<String, Object?>{
            'id': 'token-request',
            'model': 'text-model',
            'data': <Object?>[
              <String, Object?>{'total_tokens': 4},
              <String, Object?>{'total_tokens': 7},
            ],
          }),
          200,
        );
      }),
    );

    final result = await client.countTextTokens(const <String>['one', 'two']);

    expect(captured.url.path, '/api/v3/tokenization');
    expect(jsonDecode(captured.body)['text'], <Object?>['one', 'two']);
    expect(result.totalTokens, 11);
  });

  test('chat uses bearer auth and parses fenced JSON content', () async {
    late http.Request captured;
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'secret-key',
        baseUrl: 'https://ark.example/api/v3',
        textModel: 'text-model',
      ),
      httpClient: MockClient((request) async {
        captured = request;
        return http.Response(
          jsonEncode(<String, Object?>{
            'id': 'request-1',
            'model': 'text-model',
            'choices': <Object?>[
              <String, Object?>{
                'message': <String, Object?>{
                  'content': '```json\n{"ok":true}\n```',
                },
              },
            ],
            'usage': <String, Object?>{'total_tokens': 12},
          }),
          200,
        );
      }),
    );

    final response = await client.chatJson(
      systemPrompt: 'Return JSON.',
      userPayload: const <String, Object?>{'chapter': 1},
    );

    expect(
      captured.url.toString(),
      'https://ark.example/api/v3/chat/completions',
    );
    expect(captured.headers['Authorization'], 'Bearer secret-key');
    final requestBody = Map<String, Object?>.from(
      jsonDecode(captured.body) as Map,
    );
    expect(requestBody['stream'], isTrue);
    expect(requestBody['stream_options'], <String, Object?>{
      'include_usage': true,
    });
    expect(response.value, <String, Object?>{'ok': true});
    expect(response.requestId, 'request-1');
  });

  test('V2 chat sends strict JSON Schema and disables thinking', () async {
    late http.Request captured;
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'secret-key',
        baseUrl: 'https://ark.example/api/v3',
        textModel: 'text-model',
      ),
      httpClient: MockClient((request) async {
        captured = request;
        return http.Response(
          jsonEncode(<String, Object?>{
            'id': 'strict-request',
            'model': 'text-model',
            'choices': <Object?>[
              <String, Object?>{
                'message': <String, Object?>{'content': '{"ok":true}'},
                'finish_reason': 'stop',
              },
            ],
            'usage': <String, Object?>{'total_tokens': 12},
          }),
          200,
        );
      }),
    );
    addTearDown(client.close);
    const schema = <String, Object?>{
      'type': 'object',
      'additionalProperties': false,
      'properties': <String, Object?>{
        'ok': <String, Object?>{'type': 'boolean'},
      },
      'required': <String>['ok'],
    };

    final response = await client.chatJson(
      systemPrompt: 'Return JSON.',
      userPayload: const <String, Object?>{'chapter': 2},
      jsonSchema: schema,
      jsonSchemaName: 'strict_test',
      strictJsonSchema: true,
      disableThinking: true,
      maxTokens: 250000,
    );

    final body = Map<String, Object?>.from(jsonDecode(captured.body) as Map);
    expect(body['thinking'], <String, Object?>{'type': 'disabled'});
    expect(body['max_tokens'], 250000);
    expect(body['response_format'], <String, Object?>{
      'type': 'json_schema',
      'json_schema': <String, Object?>{
        'name': 'strict_test',
        'strict': true,
        'schema': schema,
      },
    });
    expect(response.value, <String, Object?>{'ok': true});
    expect(response.rawContent, '{"ok":true}');
  });

  test(
    'fragmented SSE preserves UTF-8, reasoning activity, usage, and request id',
    () async {
      late http.Request captured;
      final progress = <DoubaoStreamProgress>[];
      final payload = <String>[
        'data: {"id":"ark-stream-1","model":"text-model","choices":'
            '[{"delta":{"reasoning_content":"planning"}}]}\n\n',
        'data: {"id":"ark-stream-1","model":"text-model","choices":'
            '[{"delta":{"content":"{\\"hero\\":\\"骑"}}]}\n\n',
        'data: {"id":"ark-stream-1","model":"text-model","choices":'
            '[{"delta":{"content":"士\\"}"},"finish_reason":"stop"}]}\n\n',
        'data: {"id":"ark-stream-1","model":"text-model","choices":[],"usage":'
            '{"prompt_tokens":11,"completion_tokens":4,"total_tokens":15}}\n\n',
        'data: [DONE]\n\n',
      ].join();
      final bytes = utf8.encode(payload);
      final chunks = <List<int>>[];
      for (var index = 0; index < bytes.length; index += 7) {
        chunks.add(bytes.sublist(index, (index + 7).clamp(0, bytes.length)));
      }
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: 'secret-key',
          baseUrl: 'https://ark.example/api/v3',
          textModel: 'text-model',
        ),
        httpClient: _StreamClient((request) async {
          captured = request as http.Request;
          return http.StreamedResponse(
            Stream<List<int>>.fromIterable(chunks),
            200,
            headers: const <String, String>{
              'content-type': 'text/event-stream; charset=utf-8',
              'x-request-id': 'ark-header-1',
            },
          );
        }),
      );

      final response = await client.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{'chapter': 2},
        onProgress: progress.add,
      );

      expect(jsonDecode(captured.body)['stream'], isTrue);
      expect(response.value, <String, Object?>{'hero': '骑士'});
      expect(response.requestId, 'ark-stream-1');
      expect(response.transport, 'sse');
      expect(response.finishReason, 'stop');
      expect(response.usage['total_tokens'], 15);
      expect(response.timeToFirstEvent, isNotNull);
      expect(
        progress.map((event) => event.reasoningDelta),
        contains('planning'),
      );
      expect(
        progress.map((event) => event.contentDelta).join(),
        contains('{"hero":"骑士"}'),
      );
      expect(
        progress.map((event) => event.phase),
        containsAll(<DoubaoStreamPhase>[
          DoubaoStreamPhase.providerWorking,
          DoubaoStreamPhase.receiving,
          DoubaoStreamPhase.completed,
        ]),
      );
    },
  );

  test(
    'debug logger prints the safe request and reasoning/content stream',
    () async {
      final logs = <String>[];
      final payload = <String>[
        'data: {"id":"debug-stream","model":"text-model","choices":'
            '[{"delta":{"reasoning_content":"planning the chapter"}}]}\n\n',
        'data: {"id":"debug-stream","model":"text-model","choices":'
            '[{"delta":{"content":"{\\"ok\\":"}}]}\n\n',
        'data: {"id":"debug-stream","model":"text-model","choices":'
            '[{"delta":{"content":"true}"},"finish_reason":"stop"}]}\n\n',
        'data: {"id":"debug-stream","choices":[],"usage":'
            '{"prompt_tokens":20,"completion_tokens":5,"total_tokens":25}}\n\n',
        'data: [DONE]\n\n',
      ].join();
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: 'secret-key',
          baseUrl: 'https://ark.example/api/v3',
          textModel: 'text-model',
        ),
        httpClient: _StreamClient(
          (_) async => http.StreamedResponse(
            Stream<List<int>>.value(utf8.encode(payload)),
            200,
            headers: const <String, String>{
              'content-type': 'text/event-stream',
            },
          ),
        ),
        debugLogger: logs.add,
      );
      addTearDown(client.close);

      final response = await client.chatJson(
        systemPrompt: 'Return the exact Director JSON without secret-key.',
        userPayload: const <String, Object?>{
          'chapter': 2,
          'debugSecret': 'secret-key',
        },
        maxTokens: 2048,
        temperature: .2,
      );

      final joined = logs.join('\n');
      expect(response.value, <String, Object?>{'ok': true});
      expect(joined, contains('[LivingAI][1][request]'));
      expect(joined, contains('--- SYSTEM PROMPT ---'));
      expect(joined, contains('--- USER PAYLOAD ---'));
      expect(joined, contains('"chapter": 2'));
      expect(joined, contains('max_tokens=2048'));
      expect(joined, contains('[LivingAI][1][reasoning] planning the chapter'));
      expect(joined, contains('[LivingAI][1][content]'));
      expect(joined, contains('[LivingAI][1][finish] stop'));
      expect(joined, contains('[LivingAI][1][usage]'));
      expect(joined, contains('[LivingAI][1][done] [DONE]'));
      expect(joined, contains('[LivingAI][1][completed]'));
      expect(joined, isNot(contains('secret-key')));
      expect(joined, contains('[REDACTED]'));
    },
  );

  test(
    'debug logger batches token-sized deltas into readable blocks',
    () async {
      final logs = <String>[];
      final reasoning = List<String>.filled(150, 'analysis ').join();
      final content = '{"story":"${List<String>.filled(1200, 'x').join()}"}';
      final payload = StringBuffer();
      for (final character in reasoning.split('')) {
        payload
          ..write('data: ')
          ..write(
            jsonEncode(<String, Object?>{
              'id': 'token-stream',
              'choices': <Object?>[
                <String, Object?>{
                  'delta': <String, Object?>{'reasoning_content': character},
                },
              ],
            }),
          )
          ..write('\n\n');
      }
      for (final character in content.split('')) {
        payload
          ..write('data: ')
          ..write(
            jsonEncode(<String, Object?>{
              'id': 'token-stream',
              'choices': <Object?>[
                <String, Object?>{
                  'delta': <String, Object?>{'content': character},
                },
              ],
            }),
          )
          ..write('\n\n');
      }
      payload
        ..write(
          'data: {"id":"token-stream","choices":'
          '[{"delta":{},"finish_reason":"stop"}]}\n\n',
        )
        ..write('data: [DONE]\n\n');

      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: 'secret-key',
          baseUrl: 'https://ark.example/api/v3',
        ),
        httpClient: _StreamClient(
          (_) async => http.StreamedResponse(
            Stream<List<int>>.value(utf8.encode(payload.toString())),
            200,
            headers: const <String, String>{
              'content-type': 'text/event-stream',
            },
          ),
        ),
        debugLogger: logs.add,
      );
      addTearDown(client.close);

      final response = await client.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{},
      );

      expect(response.value['story'], List<String>.filled(1200, 'x').join());
      final reasoningPrefix = '[LivingAI][1][reasoning] ';
      final contentPrefix = '[LivingAI][1][content] ';
      final reasoningLogs = logs
          .where((line) => line.startsWith(reasoningPrefix))
          .toList();
      final contentLogs = logs
          .where((line) => line.startsWith(contentPrefix))
          .toList();
      expect(reasoningLogs, hasLength(2));
      expect(contentLogs, hasLength(2));
      expect(
        reasoningLogs
            .map((line) => line.substring(reasoningPrefix.length))
            .join(),
        reasoning,
      );
      expect(
        contentLogs.map((line) => line.substring(contentPrefix.length)).join(),
        content,
      );
      expect(
        logs.where((line) => line.contains('[stream-summary]')).single,
        allOf(
          contains('reasoning_characters=${reasoning.length}'),
          contains('content_characters=${content.length}'),
          contains('blocks=4'),
        ),
      );
      expect(logs.length, lessThan(15));
    },
  );

  test('summary diagnostics hide prompts and obey the stage filter', () async {
    const sse =
        'data: {"id":"summary-log","choices":[{"delta":{"content":"{\\"ok\\":true}"},"finish_reason":"stop"}],"usage":{"total_tokens":12}}\n\n'
        'data: [DONE]\n\n';
    final summaryLogs = <String>[];
    final summaryClient = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'diagnostic-secret',
        baseUrl: 'https://ark.example/api/v3',
      ),
      httpClient: _StreamClient(
        (_) async => http.StreamedResponse(
          Stream<List<int>>.value(utf8.encode(sse)),
          200,
          headers: const <String, String>{'content-type': 'text/event-stream'},
        ),
      ),
      debugLogger: summaryLogs.add,
      textLogLevel: LivingLogLevel.summary,
      enabledLogStages: const <String>{'director'},
    );
    addTearDown(summaryClient.close);

    await summaryClient.chatJson(
      systemPrompt: 'TOP SECRET DIRECTOR PROMPT',
      userPayload: const <String, Object?>{'private': 'payload'},
      jsonSchemaName: 'living_campaign_director_v2',
    );

    final joined = summaryLogs.join('\n');
    expect(joined, contains('stage=director'));
    expect(joined, contains('[LivingAI][1][usage]'));
    expect(joined, isNot(contains('TOP SECRET DIRECTOR PROMPT')));
    expect(joined, isNot(contains('"private"')));
    expect(joined, isNot(contains('diagnostic-secret')));
    expect(joined, isNot(contains('[LivingAI][1][content]')));

    final filteredLogs = <String>[];
    final filteredClient = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'diagnostic-secret',
        baseUrl: 'https://ark.example/api/v3',
      ),
      httpClient: _StreamClient(
        (_) async => http.StreamedResponse(
          Stream<List<int>>.value(utf8.encode(sse)),
          200,
          headers: const <String, String>{'content-type': 'text/event-stream'},
        ),
      ),
      debugLogger: filteredLogs.add,
      textLogLevel: LivingLogLevel.full,
      enabledLogStages: const <String>{'builder'},
    );
    addTearDown(filteredClient.close);

    await filteredClient.chatJson(
      systemPrompt: 'Director prompt.',
      userPayload: const <String, Object?>{},
      jsonSchemaName: 'living_campaign_director_v2',
    );
    expect(filteredLogs, isEmpty);
  });

  test(
    'SSE comments count as activity but never enter final content',
    () async {
      final progress = <DoubaoStreamProgress>[];
      final payload = <String>[
        ': provider keepalive\n\n',
        'data: {"id":"comment-stream","choices":'
            '[{"delta":{"reasoning_content":"working"}}]}\n\n',
        'data: {"id":"comment-stream","choices":'
            '[{"delta":{"content":"{\\"ok\\":true}"},'
            '"finish_reason":"stop"}]}\n\n',
        'data: [DONE]\n\n',
      ].join();
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: 'secret-key',
          baseUrl: 'https://ark.example/api/v3',
        ),
        httpClient: _StreamClient(
          (_) async => http.StreamedResponse(
            Stream<List<int>>.value(utf8.encode(payload)),
            200,
            headers: const <String, String>{
              'content-type': 'text/event-stream',
            },
          ),
        ),
      );

      final response = await client.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{},
        onProgress: progress.add,
      );

      expect(response.value, <String, Object?>{'ok': true});
      expect(response.redactedRawResponse, contains(': provider keepalive'));
      expect(
        progress.where(
          (event) => event.phase == DoubaoStreamPhase.providerWorking,
        ),
        isNotEmpty,
      );
    },
  );

  test('SSE ending without DONE is an interrupted billable request', () async {
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'secret-key',
        baseUrl: 'https://ark.example/api/v3',
      ),
      httpClient: _StreamClient(
        (_) async => http.StreamedResponse(
          Stream<List<int>>.value(
            utf8.encode(
              'data: {"id":"partial-1","choices":'
              '[{"delta":{"content":"{\\"partial\\":true}"}}]}\n\n',
            ),
          ),
          200,
          headers: const <String, String>{'content-type': 'text/event-stream'},
        ),
      ),
    );

    await expectLater(
      client.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{},
      ),
      throwsA(
        isA<LivingProviderException>()
            .having((error) => error.code, 'code', 'stream_incomplete')
            .having((error) => error.requestId, 'request id', 'partial-1'),
      ),
    );
  });

  test(
    'SSE provider error preserves its safe category and request id',
    () async {
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: 'secret-key',
          baseUrl: 'https://ark.example/api/v3',
        ),
        httpClient: _StreamClient(
          (_) async => http.StreamedResponse(
            Stream<List<int>>.value(
              utf8.encode(
                'data: {"id":"stream-error-1","error":'
                '{"code":"RateLimitExceeded","message":"secret-key"}}\n\n',
              ),
            ),
            200,
            headers: const <String, String>{
              'content-type': 'text/event-stream',
            },
          ),
        ),
      );

      await expectLater(
        client.chatJson(
          systemPrompt: 'Return JSON.',
          userPayload: const <String, Object?>{},
        ),
        throwsA(
          isA<LivingProviderException>()
              .having((error) => error.code, 'code', 'RateLimitExceeded')
              .having(
                (error) => error.requestId,
                'request id',
                'stream-error-1',
              )
              .having(
                (error) => error.safeMessage,
                'redaction',
                isNot(contains('secret-key')),
              ),
        ),
      );
    },
  );

  test('SSE first-event and idle deadlines use distinct failures', () async {
    final firstController = StreamController<List<int>>();
    addTearDown(firstController.close);
    final firstClient = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'secret-key',
        baseUrl: 'https://ark.example/api/v3',
      ),
      firstEventTimeout: const Duration(milliseconds: 20),
      httpClient: _StreamClient(
        (_) async => http.StreamedResponse(
          firstController.stream,
          200,
          headers: const <String, String>{'content-type': 'text/event-stream'},
        ),
      ),
    );
    await expectLater(
      firstClient.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{},
      ),
      throwsA(
        isA<LivingProviderException>().having(
          (error) => error.code,
          'code',
          'first_event_timeout',
        ),
      ),
    );

    final idleController = StreamController<List<int>>();
    addTearDown(idleController.close);
    final idleClient = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'secret-key',
        baseUrl: 'https://ark.example/api/v3',
      ),
      firstEventTimeout: const Duration(seconds: 1),
      streamIdleTimeout: const Duration(milliseconds: 20),
      httpClient: _StreamClient((_) async {
        scheduleMicrotask(
          () => idleController.add(
            utf8.encode(
              'data: {"id":"idle-1","choices":'
              '[{"delta":{"reasoning_content":"working"}}]}\n\n',
            ),
          ),
        );
        return http.StreamedResponse(
          idleController.stream,
          200,
          headers: const <String, String>{'content-type': 'text/event-stream'},
        );
      }),
    );
    await expectLater(
      idleClient.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{},
      ),
      throwsA(
        isA<LivingProviderException>().having(
          (error) => error.code,
          'code',
          'stream_idle_timeout',
        ),
      ),
    );
  });

  test(
    'idle timeout absorbs a late HTTP cancellation error before client close',
    () async {
      late StreamController<List<int>> controller;
      controller = StreamController<List<int>>(
        onListen: () => controller.add(
          utf8.encode(
            'data: {"id":"cancel-race","choices":'
            '[{"delta":{"reasoning_content":"working"}}]}\n\n',
          ),
        ),
        onCancel: () => Future<void>.error(
          http.ClientException('Connection closed while receiving data'),
        ),
      );
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: 'secret-key',
          baseUrl: 'https://ark.example/api/v3',
        ),
        firstEventTimeout: const Duration(seconds: 1),
        streamIdleTimeout: const Duration(milliseconds: 20),
        httpClient: _StreamClient(
          (_) async => http.StreamedResponse(
            controller.stream,
            200,
            headers: const <String, String>{
              'content-type': 'text/event-stream',
            },
          ),
        ),
      );

      await expectLater(
        client.chatJson(
          systemPrompt: 'Return JSON.',
          userPayload: const <String, Object?>{},
        ),
        throwsA(
          isA<LivingProviderException>().having(
            (error) => error.code,
            'code',
            'stream_idle_timeout',
          ),
        ),
      );
      client.close();
      await Future<void>.delayed(const Duration(milliseconds: 20));
    },
  );

  test('raw byte drips do not satisfy the first SSE event deadline', () async {
    final rawController = StreamController<List<int>>();
    addTearDown(rawController.close);
    Timer? drip;
    addTearDown(() => drip?.cancel());
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'secret-key',
        baseUrl: 'https://ark.example/api/v3',
      ),
      firstEventTimeout: const Duration(milliseconds: 30),
      streamAbsoluteTimeout: const Duration(milliseconds: 120),
      httpClient: _StreamClient((_) async {
        drip = Timer.periodic(
          const Duration(milliseconds: 4),
          (_) => rawController.add(utf8.encode('not-an-sse-event')),
        );
        return http.StreamedResponse(
          rawController.stream,
          200,
          headers: const <String, String>{'content-type': 'text/event-stream'},
        );
      }),
    );

    await expectLater(
      client.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{},
      ),
      throwsA(
        isA<LivingProviderException>().having(
          (error) => error.code,
          'code',
          'first_event_timeout',
        ),
      ),
    );
  });

  test(
    'first-event deadline includes time spent waiting for headers',
    () async {
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: 'secret-key',
          baseUrl: 'https://ark.example/api/v3',
        ),
        firstEventTimeout: const Duration(milliseconds: 35),
        streamAbsoluteTimeout: const Duration(milliseconds: 150),
        httpClient: _StreamClient((_) async {
          await Future<void>.delayed(const Duration(milliseconds: 25));
          return http.StreamedResponse(
            Stream<List<int>>.fromFuture(
              Future<List<int>>.delayed(
                const Duration(milliseconds: 20),
                () => utf8.encode('data: [DONE]\n\n'),
              ),
            ),
            200,
            headers: const <String, String>{
              'content-type': 'text/event-stream',
            },
          );
        }),
      );

      await expectLater(
        client.chatJson(
          systemPrompt: 'Return JSON.',
          userPayload: const <String, Object?>{},
        ),
        throwsA(
          isA<LivingProviderException>().having(
            (error) => error.code,
            'code',
            'first_event_timeout',
          ),
        ),
      );
    },
  );

  test('SSE absolute deadline ends an otherwise active stream', () async {
    final activeStream = Stream<List<int>>.periodic(
      const Duration(milliseconds: 5),
      (index) => utf8.encode(
        'data: {"id":"absolute-1","choices":'
        '[{"delta":{"reasoning_content":"working-$index"}}]}\n\n',
      ),
    );
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(
        apiKey: 'secret-key',
        baseUrl: 'https://ark.example/api/v3',
      ),
      firstEventTimeout: const Duration(seconds: 1),
      streamIdleTimeout: const Duration(seconds: 1),
      streamAbsoluteTimeout: const Duration(milliseconds: 35),
      httpClient: _StreamClient(
        (_) async => http.StreamedResponse(
          activeStream,
          200,
          headers: const <String, String>{'content-type': 'text/event-stream'},
        ),
      ),
    );

    await expectLater(
      client.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{},
      ),
      throwsA(
        isA<LivingProviderException>().having(
          (error) => error.code,
          'code',
          'stream_absolute_timeout',
        ),
      ),
    );
  });

  test('provider errors never expose the API key', () async {
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(apiKey: 'never-log-this-key'),
      httpClient: MockClient(
        (_) async => http.Response(
          '{"error":{"code":"Unauthorized","message":"never-log-this-key"}}',
          401,
        ),
      ),
    );

    await expectLater(
      client.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{},
      ),
      throwsA(
        isA<LivingProviderException>()
            .having(
              (error) => error.safeMessage,
              'message',
              isNot(contains('never-log')),
            )
            .having((error) => error.code, 'code', 'Unauthorized'),
      ),
    );
  });

  test('provider errors retain redacted diagnostics', () async {
    const secret = 'diagnostic-secret-key';
    final logs = <String>[];
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(apiKey: secret),
      debugLogger: logs.add,
      httpClient: MockClient(
        (_) async => http.Response(
          '{"error":{"code":"BadRequest","message":"max_tokens is invalid for diagnostic-secret-key"}}',
          400,
        ),
      ),
    );

    LivingProviderException? captured;
    try {
      await client.chatJson(
        systemPrompt: 'Return JSON.',
        userPayload: const <String, Object?>{},
      );
    } on LivingProviderException catch (error) {
      captured = error;
    }

    expect(captured, isNotNull);
    expect(captured!.providerMessage, contains('max_tokens is invalid'));
    expect(captured.providerMessage, isNot(contains(secret)));
    expect(captured.redactedResponseBody, contains('BadRequest'));
    expect(captured.redactedResponseBody, isNot(contains(secret)));
    expect(logs.join('\n'), contains('provider-error'));
    expect(logs.join('\n'), isNot(contains(secret)));
  });

  test('operating-system network denial has a specific safe message', () async {
    final client = DoubaoClient(
      settings: const LivingCampaignSettings(apiKey: 'secret-key'),
      httpClient: MockClient(
        (_) async => throw http.ClientException('Operation not permitted'),
      ),
    );

    await expectLater(
      client.testCapability(),
      throwsA(
        isA<LivingProviderException>()
            .having((error) => error.code, 'code', 'network_permission_denied')
            .having(
              (error) => error.safeMessage,
              'message',
              contains('operating system'),
            )
            .having(
              (error) => error.safeMessage,
              'redaction',
              isNot(contains('secret-key')),
            ),
      ),
    );
  });

  test(
    'portrait generation uses URL output and processes the download',
    () async {
      late http.Request generationRequest;
      final source = img.Image(width: 640, height: 960, numChannels: 4);
      img.fill(source, color: img.ColorRgba8(0, 255, 0, 255));
      img.fillRect(
        source,
        x1: 180,
        y1: 120,
        x2: 460,
        y2: 850,
        color: img.ColorRgba8(120, 70, 50, 255),
      );
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: 'secret-key',
          baseUrl: 'https://ark.example/api/v3',
          imageModel: 'image-model',
        ),
        httpClient: MockClient((request) async {
          if (request.method == 'POST') {
            generationRequest = request;
            return http.Response(
              jsonEncode(<String, Object?>{
                'id': 'portrait-request',
                'data': <Object?>[
                  <String, Object?>{
                    'url': 'https://images.example/portrait.png',
                  },
                ],
              }),
              200,
            );
          }
          return http.Response.bytes(img.encodePng(source), 200);
        }),
      );

      final result = await client.generatePortrait(
        prompt: 'An original ash-court herald, half-body portrait.',
        seed: 12345,
        referenceImages: <Uint8List>[
          Uint8List.fromList(const <int>[82, 73, 70, 70]),
        ],
      );
      final requestBody = Map<String, Object?>.from(
        jsonDecode(generationRequest.body) as Map,
      );

      expect(generationRequest.url.path, '/api/v3/images/generations');
      expect(requestBody['model'], 'image-model');
      expect(requestBody['response_format'], 'url');
      expect(requestBody['size'], '2K');
      expect(requestBody['seed'], 12345);
      expect(requestBody['image'], <String>['data:image/webp;base64,UklGRg==']);
      expect(
        requestBody['prompt'],
        'An original ash-court herald, half-body portrait.',
      );
      expect(result.requestId, 'portrait-request');
      expect(result.width, 1024);
      expect(result.height, 1024);
    },
  );

  test('portrait processor removes a flat green edge background', () {
    final source = img.Image(width: 640, height: 960, numChannels: 4);
    img.fill(source, color: img.ColorRgba8(0, 255, 0, 255));
    img.fillRect(
      source,
      x1: 180,
      y1: 120,
      x2: 460,
      y2: 850,
      color: img.ColorRgba8(120, 70, 50, 255),
    );

    final result = LivingPortraitProcessor().process(img.encodePng(source));
    final decoded = img.decodePng(result.bytes)!;

    expect(decoded.getPixel(0, 0).a, 0);
    expect(decoded.getPixel(512, 512).a, 255);
    expect(result.width, 1024);
    expect(result.height, 1024);
  });

  test('portrait processor removes a neutral flat edge background', () {
    final source = img.Image(width: 640, height: 960, numChannels: 4);
    img.fill(source, color: img.ColorRgba8(224, 218, 206, 255));
    img.fillRect(
      source,
      x1: 180,
      y1: 120,
      x2: 460,
      y2: 850,
      color: img.ColorRgba8(55, 45, 42, 255),
    );

    final result = LivingPortraitProcessor().process(img.encodePng(source));
    final decoded = img.decodePng(result.bytes)!;

    expect(decoded.getPixel(0, 0).a, 0);
    expect(decoded.getPixel(512, 512).a, 255);
  });

  test('portrait processor removes and despills a flat magenta background', () {
    final source = img.Image(width: 640, height: 960, numChannels: 4);
    img.fill(source, color: img.ColorRgba8(255, 0, 255, 255));
    img.fillRect(
      source,
      x1: 180,
      y1: 120,
      x2: 460,
      y2: 850,
      color: img.ColorRgba8(70, 58, 52, 255),
    );
    source.setPixelRgba(180, 400, 220, 55, 215, 255);

    final result = LivingPortraitProcessor().process(img.encodePng(source));
    final decoded = img.decodePng(result.bytes)!;

    expect(decoded.getPixel(0, 0).a, 0);
    expect(decoded.getPixel(512, 512).a, 255);
    final edge = decoded.getPixel(350, 512);
    expect(edge.r, lessThanOrEqualTo(edge.g + 10));
    expect(edge.b, lessThanOrEqualTo(edge.g + 10));
  });

  test('portrait processor adds alpha before removing a JPEG green screen', () {
    final source = img.Image(width: 640, height: 960, numChannels: 3);
    img.fill(source, color: img.ColorRgb8(0, 255, 0));
    img.fillRect(
      source,
      x1: 180,
      y1: 120,
      x2: 460,
      y2: 850,
      color: img.ColorRgb8(120, 70, 50),
    );
    img.fillRect(
      source,
      x1: 280,
      y1: 300,
      x2: 360,
      y2: 380,
      color: img.ColorRgb8(0, 250, 0),
    );

    final result = LivingPortraitProcessor().process(
      img.encodeJpg(source, quality: 92),
    );
    final decoded = img.decodePng(result.bytes)!;

    expect(decoded.numChannels, 4);
    expect(decoded.getPixel(0, 0).a, 0);
    expect(decoded.getPixel(512, 402).a, 0);
    expect(decoded.getPixel(512, 512).a, 255);
  });

  test(
    'portrait processor keys a green screen when subject fills a bottom corner',
    () {
      final source = img.Image(width: 640, height: 960, numChannels: 3);
      img.fill(source, color: img.ColorRgb8(0, 248, 8));
      img.fillRect(
        source,
        x1: 130,
        y1: 180,
        x2: 510,
        y2: 959,
        color: img.ColorRgb8(38, 38, 42),
      );
      img.fillRect(
        source,
        x1: 400,
        y1: 710,
        x2: 639,
        y2: 959,
        color: img.ColorRgb8(58, 46, 40),
      );

      final result = LivingPortraitProcessor().process(
        img.encodeJpg(source, quality: 92),
      );
      final decoded = img.decodePng(result.bytes)!;

      expect(decoded.getPixel(10, 10).a, 0);
      expect(decoded.getPixel(512, 680).a, 255);
      expect(decoded.getPixel(760, 900).a, 255);
    },
  );

  test(
    'chapter art uses one seeded widescreen request and normalizes to 16:9',
    () async {
      late http.Request generationRequest;
      final logs = <String>[];
      final source = img.Image(width: 1200, height: 1200, numChannels: 3);
      img.fill(source, color: img.ColorRgb8(16, 22, 30));
      img.fillRect(
        source,
        x1: 250,
        y1: 150,
        x2: 950,
        y2: 1050,
        color: img.ColorRgb8(180, 95, 45),
      );
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: 'chapter-secret',
          baseUrl: 'https://ark.example/api/v3',
          imageModel: 'image-model',
        ),
        imageLogLevel: LivingLogLevel.summary,
        enabledLogStages: const <String>{'chapter_art'},
        debugLogger: logs.add,
        httpClient: MockClient((request) async {
          if (request.method == 'POST') {
            generationRequest = request;
            return http.Response(
              jsonEncode(<String, Object?>{
                'id': 'chapter-art-request',
                'data': <Object?>[
                  <String, Object?>{
                    'url': 'https://images.example/chapter.png',
                  },
                ],
              }),
              200,
            );
          }
          return http.Response.bytes(img.encodePng(source), 200);
        }),
      );
      addTearDown(client.close);

      final result = await client.generateChapterEndingArt(
        prompt: 'The Ashen Court stands after the ruined causeway battle.',
        seed: 24680,
        referenceImages: <Uint8List>[
          Uint8List.fromList(const <int>[82, 73, 70, 70]),
        ],
      );
      final body = Map<String, Object?>.from(
        jsonDecode(generationRequest.body) as Map,
      );

      expect(body['model'], 'image-model');
      expect(body['size'], '2560x1440');
      expect(body['seed'], 24680);
      expect(body['watermark'], isFalse);
      expect(body['sequential_image_generation'], 'disabled');
      expect(result.requestId, 'chapter-art-request');
      expect(result.width, 2560);
      expect(result.height, 1440);
      final decoded = img.decodePng(result.imageBytes)!;
      expect(decoded.width / decoded.height, closeTo(16 / 9, .001));
      expect(logs.join('\n'), contains('[LivingImage][chapter_art][request]'));
      expect(logs.join('\n'), isNot(contains('UklGRg==')));
      expect(logs.join('\n'), isNot(contains('chapter-secret')));
    },
  );

  test('chapter scene processor rejects unusable images', () {
    final tiny = img.Image(width: 120, height: 80);
    expect(
      () => LivingChapterSceneProcessor().process(img.encodePng(tiny)),
      throwsA(
        isA<LivingProviderException>().having(
          (error) => error.code,
          'code',
          'chapter_art_decode_failed',
        ),
      ),
    );
  });

  test('redactor removes exact keys and bearer tokens', () {
    final output = const LivingSecretRedactor().redact(
      'Authorization: Bearer abc123 ARK_API_KEY="abc123"',
      secrets: const <String>['abc123'],
    );

    expect(output, isNot(contains('abc123')));
    expect(output, contains('[REDACTED]'));
  });
}

class _StreamClient extends http.BaseClient {
  _StreamClient(this.handler);

  final Future<http.StreamedResponse> Function(http.BaseRequest request)
  handler;

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) =>
      handler(request);
}
