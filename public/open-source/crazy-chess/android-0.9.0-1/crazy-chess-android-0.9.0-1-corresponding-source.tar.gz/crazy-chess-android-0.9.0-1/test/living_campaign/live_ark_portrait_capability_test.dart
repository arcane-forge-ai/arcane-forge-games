@Tags(<String>['live'])
library;

import 'dart:convert';
import 'dart:io';

import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';

const _runLive = bool.fromEnvironment(
  'RUN_LIVING_CAMPAIGN_LIVE_PORTRAIT_TESTS',
);
const _apiKey = String.fromEnvironment('ARK_API_KEY');
const _baseUrl = String.fromEnvironment(
  'ARK_BASE_URL',
  defaultValue: LivingCampaignSettings.defaultBaseUrl,
);
const _imageModel = String.fromEnvironment(
  'LIVING_CAMPAIGN_IMAGE_MODEL',
  defaultValue: LivingCampaignSettings.defaultImageModel,
);
const _prompt =
    'An original Ashen Court bell keeper newly joining the campaign: an older '
    'woman with soot-gray robes, a small bronze handbell, and a calm watchful '
    'expression. Half-body portrait from mid-thigh upward.';
const _outputRoot =
    'test_result/20260806-001802_living-campaign-v1/live-ark-portrait';

void main() {
  test(
    'configured Ark image model returns one validated portrait',
    () async {
      expect(_apiKey, isNotEmpty, reason: 'ARK_API_KEY was not injected.');
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: _apiKey,
          baseUrl: _baseUrl,
          imageModel: _imageModel,
        ),
      );
      addTearDown(client.close);

      final directory = Directory(_outputRoot);
      await directory.create(recursive: true);
      const sourcePath = '$_outputRoot/provider-source';
      late List<int> sourceBytes;
      final portrait = await client.generatePortrait(
        prompt: _prompt,
        onSourceDownloaded: (bytes) async {
          sourceBytes = bytes;
          await File(sourcePath).writeAsBytes(bytes, flush: true);
        },
      );
      expect(portrait.pngBytes, isNotEmpty);
      expect(portrait.width, greaterThanOrEqualTo(512));
      expect(portrait.height, greaterThanOrEqualTo(512));

      const imagePath = '$_outputRoot/capability-portrait.png';
      await File(imagePath).writeAsBytes(portrait.pngBytes, flush: true);
      await File('$_outputRoot/generation-record.json').writeAsString(
        const JsonEncoder.withIndent('  ').convert(<String, Object?>{
          'kind': 'living-campaign-live-portrait-capability',
          'provider': 'Ark',
          'model': _imageModel,
          'prompt': _prompt,
          'finalPrompt': portrait.finalPrompt,
          'requestId': portrait.requestId,
          'width': portrait.width,
          'height': portrait.height,
          'sourceSha256': sha256.convert(sourceBytes).toString(),
          'sourcePath': sourcePath,
          'sha256': sha256.convert(portrait.pngBytes).toString(),
          'outputPath': imagePath,
          'promotionStatus': 'capability_evidence_only_not_runtime_art',
        }),
        flush: true,
      );
    },
    skip: !_runLive,
    timeout: const Timeout(Duration(minutes: 5)),
  );
}
