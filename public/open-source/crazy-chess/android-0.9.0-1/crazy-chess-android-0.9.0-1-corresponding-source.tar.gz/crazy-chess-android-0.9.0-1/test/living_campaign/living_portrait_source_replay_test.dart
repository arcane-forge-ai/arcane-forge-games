@Tags(<String>['live'])
library;

import 'dart:convert';
import 'dart:io';

import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;

const _sourcePath = String.fromEnvironment('LIVING_PORTRAIT_REPLAY_SOURCE');
const _outputPath = String.fromEnvironment('LIVING_PORTRAIT_REPLAY_OUTPUT');
const _json = JsonEncoder.withIndent('  ');

void main() {
  test(
    'an archived provider source passes the production portrait processor',
    () async {
      final source = File(p.absolute(_sourcePath));
      final output = Directory(p.absolute(_outputPath));
      expect(await source.exists(), isTrue);
      expect(await output.exists(), isFalse);
      expect(
        p.isWithin(p.absolute('test_result'), output.path),
        isTrue,
        reason: 'Replay evidence must stay under test_result/.',
      );
      await output.create(recursive: true);

      final sourceBytes = await source.readAsBytes();
      final processed = LivingPortraitProcessor().process(sourceBytes);
      final decoded = img.decodePng(processed.bytes)!;
      var transparent = 0;
      for (final pixel in decoded) {
        if (pixel.a < 32) transparent++;
      }
      final transparentRatio = transparent / (decoded.width * decoded.height);
      final processedFile = File(p.join(output.path, 'processed.png'));
      await processedFile.writeAsBytes(processed.bytes, flush: true);

      final report = <String, Object?>{
        'kind': 'living-portrait-archived-source-replay',
        'passed': transparentRatio >= .05,
        'providerCalls': 0,
        'source': source.path,
        'sourceSha256': sha256.convert(sourceBytes).toString(),
        'processed': processedFile.path,
        'processedSha256': sha256.convert(processed.bytes).toString(),
        'width': processed.width,
        'height': processed.height,
        'transparentRatio': transparentRatio,
      };
      await File(
        p.join(output.path, 'report.json'),
      ).writeAsString('${_json.convert(report)}\n', flush: true);
      final markdown =
          '''# Living Portrait Archived Source Replay

Status: **${report['passed'] == true ? 'PASS' : 'FAIL'}**

- Provider calls: 0
- Source SHA-256: `${report['sourceSha256']}`
- Processed SHA-256: `${report['processedSha256']}`
- Dimensions: ${processed.width} × ${processed.height}
- Transparent ratio: ${(transparentRatio * 100).toStringAsFixed(2)}%
''';
      await File(
        p.join(output.path, 'report.md'),
      ).writeAsString(markdown, flush: true);
      final escaped = const HtmlEscape().convert(markdown);
      await File(p.join(output.path, 'report.html')).writeAsString(
        '<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>Living Portrait Replay</title><style>:root{color-scheme:dark}'
        'body{margin:0;background:#090b0f;color:#eadfc8;font:16px/1.6 system-ui}'
        'main{max-width:980px;margin:auto;padding:48px}pre{white-space:pre-wrap;'
        'background:#111820;border:1px solid #4e3b22;border-radius:14px;'
        'padding:24px}img{max-width:420px;background:#26313b}</style></head>'
        '<body><main><pre>$escaped</pre><img src="processed.png" '
        'alt="Recovered transparent portrait"></main></body></html>',
        flush: true,
      );

      expect(transparentRatio, greaterThanOrEqualTo(.05));
    },
    skip: _sourcePath.isEmpty || _outputPath.isEmpty,
  );
}
