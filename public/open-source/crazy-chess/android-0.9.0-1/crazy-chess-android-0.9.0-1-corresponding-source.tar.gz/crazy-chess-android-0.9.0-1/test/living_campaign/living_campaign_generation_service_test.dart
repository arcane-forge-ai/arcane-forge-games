import 'dart:io';
import 'dart:typed_data';

import 'package:crazy_chess/battlefield/battlefield_models.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store_io.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_generation_service.dart';
import 'package:crazy_chess/living_campaign/living_campaign_demo_gateway.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'debug demo chapter painter supports fallback then explicit success',
    () async {
      final failing = LivingCampaignDemoGateway();
      await expectLater(
        failing.generateChapterEndingArt(prompt: 'Ashen victory', seed: 7),
        throwsA(
          isA<LivingProviderException>().having(
            (error) => error.code,
            'code',
            'demo_chapter_art_unavailable',
          ),
        ),
      );

      final fixture = Uint8List.fromList(const <int>[1, 2, 3, 4]);
      Uint8List? archivedSource;
      final succeeding = LivingCampaignDemoGateway(
        chapterArtSucceeds: true,
        chapterArtFixtureLoader: () async => fixture,
      );
      final result = await succeeding.generateChapterEndingArt(
        prompt: 'Ashen victory',
        seed: 7,
        onSourceDownloaded: (bytes) => archivedSource = bytes,
      );

      expect(result.imageBytes, fixture);
      expect(archivedSource, fixture);
      expect(result.requestId, 'living-demo-chapter-art-success');
      expect(result.width / result.height, closeTo(16 / 9, .002));
    },
  );

  test(
    'debug demo gateway passes the real Director and Builder validators',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-demo-gateway-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final service = LivingCampaignGenerationService(
        gateway: LivingCampaignDemoGateway(),
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5),
        idFactory: (prefix) => '$prefix-demo',
      );
      final fixed = LivingCampaignFixedOpener.create(
        runId: 'run-demo-gateway',
        now: DateTime.utc(2026, 8, 5),
      );

      final prologue = await service.generatePrologue(fixed);
      final chapter = await service.generateNextChapter(
        run: prologue.run,
        outcome: _outcome(),
      );

      expect(prologue.completed, isTrue);
      expect(chapter.completed, isTrue, reason: chapter.message);
      expect(chapter.run.activeChapterNumber, 2);
      expect(chapter.run.chapterPackages.last.title, 'The Ash Bells');
    },
  );

  test(
    'generated prologue tells this run story before the fixed opener',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-prologue-');
      addTearDown(() => temp.delete(recursive: true));
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-prologue',
        now: DateTime.utc(2026, 8, 5),
      );
      final gateway = _FakeGateway(<Map<String, Object?>>[
        <String, Object?>{
          'campaignTitle': 'The Crows of Ash',
          'storyPromise':
              'A broken court will decide whether loyalty can survive when every '
              'victory gives old accusations a sharper edge.',
          'prologue': List<String>.filled(
            4,
            'At the edge of the Ruined Causeway, Orsain raised the unfinished '
            'crown while Ysra counted the crows and Cael refused to kneel. ',
          ).join(),
        },
      ]);
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final service = LivingCampaignGenerationService(
        gateway: gateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 0, 30),
        idFactory: (prefix) => '$prefix-test',
      );

      final result = await service.generatePrologue(run);

      expect(result.completed, isTrue);
      expect(result.run.campaignTitle, 'The Crows of Ash');
      expect(result.run.storyPromise, contains('broken court'));
      expect(result.run.prologue, contains('Ruined Causeway'));
      expect(result.run.chapterPackages.single.chapterId, 'living_m01');
      expect(
        result.run.generationRecords.single.stage,
        LivingGenerationStage.prologue,
      );
    },
  );

  test(
    'a complete invalid opening receives the single allowed repair',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-prologue-repair-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-prologue-repair',
        now: DateTime.utc(2026, 8, 5),
      );
      final gateway = _FakeGateway(<Map<String, Object?>>[
        const <String, Object?>{'_invalidRawContent': 'unfinished prose'},
        <String, Object?>{
          'campaignTitle': 'The Repaired Crown',
          'storyPromise':
              'A repaired promise keeps the first mission locked until valid.',
          'prologue': List<String>.filled(
            4,
            'Orsain and the Ashen Court crossed the Ruined Causeway while the '
            'unfinished crown gathered rain and accusation. ',
          ).join(),
        },
      ]);
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final service = LivingCampaignGenerationService(
        gateway: gateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 0, 45),
        idFactory: (prefix) => '$prefix-repair',
      );

      final result = await service.generatePrologue(run);

      expect(result.completed, isTrue);
      expect(result.run.campaignTitle, 'The Repaired Crown');
      expect(
        result.run.generationRecords.map((record) => record.stage),
        <LivingGenerationStage>[
          LivingGenerationStage.prologue,
          LivingGenerationStage.prologueRepair,
        ],
      );
    },
  );

  test(
    'retrying prologue repair reuses the completed opening response',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-prologue-repair-resume-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-prologue-repair-resume',
        now: DateTime.utc(2026, 8, 5),
      );
      final firstGateway = _SequencedGateway(<Object>[
        const <String, Object?>{'_invalidRawContent': 'unfinished prose'},
        const LivingProviderException(
          code: 'stream_idle_timeout',
          safeMessage: 'The repair stream stopped.',
        ),
      ]);
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final firstService = LivingCampaignGenerationService(
        gateway: firstGateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 0, 50),
        idFactory: (prefix) => '$prefix-first',
      );

      final interrupted = await firstService.generatePrologue(run);

      expect(interrupted.completed, isFalse);
      expect(
        interrupted.run.generationJob?.stage,
        LivingGenerationStage.prologueRepair,
      );
      expect(firstGateway.calls, 2);

      final resumedGateway = _SequencedGateway(<Object>[
        <String, Object?>{
          'campaignTitle': 'The Repaired Ashen Crown',
          'storyPromise':
              'The archived opening is repaired without paying to generate '
              'the accepted first response again.',
          'prologue': List<String>.filled(
            4,
            'Orsain and the Ashen Court crossed the Ruined Causeway while the '
            'unfinished crown gathered rain and accusation. ',
          ).join(),
        },
      ]);
      final resumedService = LivingCampaignGenerationService(
        gateway: resumedGateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 0, 51),
        idFactory: (prefix) => '$prefix-resumed',
      );

      final result = await resumedService.generatePrologue(interrupted.run);

      expect(result.completed, isTrue);
      expect(resumedGateway.calls, 1);
      expect(
        resumedGateway.payloads.single['invalidPrologue'],
        const <String, Object?>{'_invalidRawContent': 'unfinished prose'},
      );
      expect(
        result.run.generationRecords
            .where((record) => record.stage == LivingGenerationStage.prologue)
            .length,
        1,
      );
      expect(
        result.run.generationRecords.last.stage,
        LivingGenerationStage.prologueRepair,
      );
    },
  );

  test(
    'a completed invalid prologue repair is never billed a third time',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-prologue-repair-exhausted-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-prologue-repair-exhausted',
        now: DateTime.utc(2026, 8, 5),
      );
      final firstGateway = _SequencedGateway(<Object>[
        const <String, Object?>{'_invalidRawContent': 'unfinished opening'},
        const <String, Object?>{'_invalidRawContent': 'unfinished repair'},
      ]);
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final firstService = LivingCampaignGenerationService(
        gateway: firstGateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 0, 52),
        idFactory: (prefix) => '$prefix-first',
      );
      final exhausted = await firstService.generatePrologue(run);
      expect(exhausted.completed, isFalse);
      expect(firstGateway.calls, 2);

      final resumedGateway = _SequencedGateway(const <Object>[]);
      final resumedService = LivingCampaignGenerationService(
        gateway: resumedGateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 0, 53),
        idFactory: (prefix) => '$prefix-resumed',
      );

      final result = await resumedService.generatePrologue(exhausted.run);

      expect(result.completed, isFalse);
      expect(resumedGateway.calls, 0);
      expect(
        result.run.generationJob?.errorCode,
        'validation_failed_after_repair',
      );
    },
  );

  test(
    'valid two-stage generation commits canon and mission together',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-generation-');
      addTearDown(() => temp.delete(recursive: true));
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-generate',
        now: DateTime.utc(2026, 8, 5),
      );
      final gateway = _FakeGateway(<Map<String, Object?>>[
        _directorPatch(run.runId).toJson(),
        _chapter(run.runId).toJson(),
      ]);
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      var id = 0;
      final progressStages = <LivingGenerationStage>[];
      final service = LivingCampaignGenerationService(
        gateway: gateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 1, 0, id++),
        idFactory: (prefix) => '$prefix-${id++}',
        onProgress: (run) {
          final stage = run.generationJob?.stage;
          if (stage != null) progressStages.add(stage);
        },
      );

      final result = await service.generateNextChapter(
        run: run,
        outcome: _outcome(),
      );

      expect(result.completed, isTrue);
      expect(result.run.canon.revision, 1);
      expect(result.run.canon.gold, 22);
      expect(result.run.activeChapterNumber, 2);
      expect(result.run.chapterPackages, hasLength(2));
      expect(result.run.generationJob, isNull);
      expect(
        result.run.generationRecords.map((record) => record.stage),
        <LivingGenerationStage>[
          LivingGenerationStage.director,
          LivingGenerationStage.builder,
        ],
      );
      expect(result.run.generationRecords.first.inputTokens, 137);
      expect(result.run.generationRecords.first.transportType, 'sse');
      expect(result.run.generationRecords.first.durationMs, 750);
      expect(result.run.generationRecords.first.usage['total_tokens'], 29);
      expect(progressStages, contains(LivingGenerationStage.director));
      expect(progressStages, contains(LivingGenerationStage.builder));
      expect((await archive.readRun(run.runId))!.toJson(), result.run.toJson());
    },
  );

  test(
    'portrait retry resumes the accepted checkpoint without rerunning Director or Builder',
    () async {
      final temp = await Directory.systemTemp.createTemp(
        'living-portrait-resume-',
      );
      addTearDown(() => temp.delete(recursive: true));
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-portrait-resume',
        now: DateTime.utc(2026, 8, 5),
      );
      final gateway = _PortraitRetryGateway(<Map<String, Object?>>[
        _portraitDirectorPatch(run.runId).toJson(),
        _portraitChapter(run.runId).toJson(),
      ]);
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      var id = 0;
      final service = LivingCampaignGenerationService(
        gateway: gateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 1, 30, id++),
        idFactory: (prefix) => '$prefix-${id++}',
      );

      final paused = await service.generateNextChapter(
        run: run,
        outcome: _outcome(),
      );

      expect(paused.completed, isFalse);
      expect(paused.run.canon.revision, 1);
      expect(paused.run.chapterPackages, hasLength(1));
      expect(paused.run.generationCheckpoint, isNotNull);
      expect(paused.run.generationCheckpoint!.chapterPackage!.chapterNumber, 2);
      expect(paused.run.generationJob!.stage, LivingGenerationStage.portrait);
      expect(gateway.chatCalls, 2);
      expect(gateway.portraitCalls, 1);
      expect(
        (await archive.readRun(run.runId))!.generationCheckpoint,
        isNotNull,
      );

      final resumed = await service.generateNextChapter(
        run: paused.run,
        outcome: _outcome(),
      );

      expect(resumed.completed, isTrue);
      expect(resumed.run.activeChapterNumber, 2);
      expect(resumed.run.chapterPackages, hasLength(2));
      expect(resumed.run.generationCheckpoint, isNull);
      expect(resumed.run.generationJob, isNull);
      expect(
        resumed.run.canon.charactersById['char_bell_keeper']!.portraitPath,
        isNotNull,
      );
      expect(gateway.chatCalls, 2);
      expect(gateway.portraitCalls, 2);
    },
  );

  test(
    'a played locked finale commits the epilogue without a Builder call',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-finale-');
      addTearDown(() => temp.delete(recursive: true));
      final opener = LivingCampaignFixedOpener.create(
        runId: 'run-service-finale',
        now: DateTime.utc(2026, 8, 5),
      );
      final run = opener.copyWith(
        activeChapterNumber: 3,
        canon: opener.canon.copyWith(
          chapterLedger: const <LivingChapterRecord>[
            LivingChapterRecord(
              chapterNumber: 1,
              chapterId: 'living_m01',
              title: 'The Ashen Divide',
              oneLineSummary: 'The court crossed the first ruined causeway.',
              objectiveType: LivingObjectiveType.checkmate,
              result: LivingBattleResult.victory,
              eventIds: <String>[],
              finaleKind: LivingFinaleKind.none,
            ),
            LivingChapterRecord(
              chapterNumber: 2,
              chapterId: 'living_m02',
              title: 'The Last Road Opens',
              oneLineSummary:
                  'The court chose its final road beneath the bells.',
              objectiveType: LivingObjectiveType.surviveRounds,
              result: LivingBattleResult.victory,
              eventIds: <String>[],
              finaleKind: LivingFinaleKind.hopeful,
            ),
          ],
        ),
      );
      final gateway = _FakeGateway(<Map<String, Object?>>[
        _terminalDirectorPatch(run.runId).toJson(),
      ]);
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      final service = LivingCampaignGenerationService(
        gateway: gateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 3),
        idFactory: (prefix) => '$prefix-finale',
      );

      final result = await service.generateNextChapter(
        run: run,
        outcome: _finaleOutcome(),
      );

      expect(result.completed, isTrue);
      expect(result.run.status, LivingRunStatus.completed);
      expect(result.run.epilogue, contains('unfinished crown'));
      expect(result.run.chapterPackages, hasLength(1));
      expect(gateway.responses, isEmpty);
      expect(
        result.run.generationRecords.map((record) => record.stage),
        <LivingGenerationStage>[LivingGenerationStage.director],
      );
    },
  );

  test(
    'a provider context rejection triggers only lossless compaction',
    () async {
      final temp = await Directory.systemTemp.createTemp('living-compaction-');
      addTearDown(() => temp.delete(recursive: true));
      final run = LivingCampaignFixedOpener.create(
        runId: 'run-compact',
        now: DateTime.utc(2026, 8, 5),
      );
      final gateway = _FakeGateway(<Map<String, Object?>>[
        _directorPatch(run.runId).toJson(),
        _chapter(run.runId).toJson(),
      ], rejectFirstForContext: true);
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => temp,
      );
      var id = 0;
      final service = LivingCampaignGenerationService(
        gateway: gateway,
        archive: archive,
        clock: () => DateTime.utc(2026, 8, 5, 2, 0, id++),
        idFactory: (prefix) => '$prefix-${id++}',
      );

      final result = await service.generateNextChapter(
        run: run,
        outcome: _outcome(),
      );

      expect(result.completed, isTrue);
      expect(result.run.canon.memoryEpochs, hasLength(1));
      expect(
        result.run.generationRecords.map((record) => record.stage),
        contains(LivingGenerationStage.compaction),
      );
      expect(
        result.run.generationRecords
            .where((record) => record.stage == LivingGenerationStage.compaction)
            .single
            .responsePayload['semanticFieldsRemoved'],
        isFalse,
      );
    },
  );
}

class _FakeGateway implements LivingGenerationGateway {
  _FakeGateway(this.responses, {this.rejectFirstForContext = false});

  final List<Map<String, Object?>> responses;
  final bool rejectFirstForContext;
  var calls = 0;

  @override
  String get imageModel => 'image-test';

  @override
  String get textModel => 'text-test';

  @override
  Future<DoubaoTokenizationResult> countTextTokens(
    Iterable<String> values,
  ) async => const DoubaoTokenizationResult(
    totalTokens: 137,
    requestId: 'tokenize-1',
    model: 'text-test',
  );

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    int maxTokens = 8192,
    double temperature = .25,
    DoubaoStreamProgressCallback? onProgress,
  }) async {
    if (rejectFirstForContext && calls++ == 0) {
      throw const LivingProviderException(
        code: 'context_length_exceeded',
        safeMessage: 'Context is too long.',
      );
    }
    if (responses.isEmpty) {
      throw StateError('Unexpected repair call: $userPayload');
    }
    final response = responses.removeAt(0);
    onProgress?.call(
      DoubaoStreamProgress(
        phase: DoubaoStreamPhase.providerWorking,
        occurredAt: DateTime.utc(2026, 8, 5, 0, 0, calls),
        requestId: 'request-$calls',
      ),
    );
    onProgress?.call(
      DoubaoStreamProgress(
        phase: DoubaoStreamPhase.receiving,
        occurredAt: DateTime.utc(2026, 8, 5, 0, 0, calls),
        requestId: 'request-$calls',
        receivedContentCharacters: response.toString().length,
      ),
    );
    return DoubaoJsonResponse(
      value: response,
      requestId: 'request-$calls',
      model: textModel,
      usage: const <String, Object?>{'total_tokens': 29},
      redactedRawResponse: '{}',
      timeToFirstEvent: const Duration(milliseconds: 120),
      duration: const Duration(milliseconds: 750),
      finishReason: 'stop',
    );
  }

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
  }) => throw UnimplementedError();
}

class _SequencedGateway implements LivingGenerationGateway {
  _SequencedGateway(this.responses);

  final List<Object> responses;
  final List<Map<String, Object?>> payloads = <Map<String, Object?>>[];
  int calls = 0;

  @override
  String get imageModel => 'image-sequenced';

  @override
  String get textModel => 'text-sequenced';

  @override
  Future<DoubaoTokenizationResult> countTextTokens(
    Iterable<String> values,
  ) async => const DoubaoTokenizationResult(
    totalTokens: 137,
    requestId: 'tokenize-sequenced',
    model: 'text-sequenced',
  );

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    int maxTokens = 8192,
    double temperature = .25,
    DoubaoStreamProgressCallback? onProgress,
  }) async {
    calls++;
    payloads.add(userPayload);
    final response = responses.removeAt(0);
    if (response is LivingProviderException) throw response;
    final value = Map<String, Object?>.from(response as Map);
    onProgress?.call(
      DoubaoStreamProgress(
        phase: DoubaoStreamPhase.receiving,
        occurredAt: DateTime.utc(2026, 8, 5, 0, 0, calls),
        requestId: 'request-sequenced-$calls',
        receivedContentCharacters: value.toString().length,
      ),
    );
    return DoubaoJsonResponse(
      value: value,
      requestId: 'request-sequenced-$calls',
      model: textModel,
      usage: const <String, Object?>{'total_tokens': 29},
      redactedRawResponse: '{}',
      timeToFirstEvent: const Duration(milliseconds: 120),
      duration: const Duration(milliseconds: 750),
      finishReason: 'stop',
    );
  }

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
  }) => throw UnimplementedError();
}

class _PortraitRetryGateway implements LivingGenerationGateway {
  _PortraitRetryGateway(this.responses);

  final List<Map<String, Object?>> responses;
  var chatCalls = 0;
  var portraitCalls = 0;

  @override
  String get imageModel => 'image-test';

  @override
  String get textModel => 'text-test';

  @override
  Future<DoubaoTokenizationResult> countTextTokens(
    Iterable<String> values,
  ) async => const DoubaoTokenizationResult(
    totalTokens: 137,
    requestId: 'tokenize-portrait',
    model: 'text-test',
  );

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    int maxTokens = 8192,
    double temperature = .25,
    DoubaoStreamProgressCallback? onProgress,
  }) async {
    chatCalls++;
    if (responses.isEmpty) {
      throw StateError('Unexpected portrait-flow repair call: $userPayload');
    }
    return DoubaoJsonResponse(
      value: responses.removeAt(0),
      requestId: 'request-$chatCalls',
      model: textModel,
      usage: const <String, Object?>{},
      redactedRawResponse: '{}',
    );
  }

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
  }) async {
    portraitCalls++;
    if (portraitCalls == 1) {
      throw const LivingProviderException(
        code: 'portrait_timeout',
        safeMessage: 'The portrait request timed out.',
      );
    }
    final image = img.Image(width: 64, height: 96, numChannels: 4);
    img.fill(image, color: img.ColorRgba8(90, 60, 45, 255));
    return DoubaoPortraitResult(
      pngBytes: img.encodePng(image),
      width: 64,
      height: 96,
      finalPrompt: prompt,
      requestId: 'portrait-2',
      redactedRawResponse: '{}',
    );
  }
}

LivingBattleOutcomeSnapshot _outcome() => const LivingBattleOutcomeSnapshot(
  chapterNumber: 1,
  chapterId: 'living_m01',
  result: LivingBattleResult.victory,
  endReason: GameEndReason.checkmate,
  objectiveType: LivingObjectiveType.checkmate,
  objectiveCompleted: true,
  completedTurns: 18,
  goldBefore: 10,
  goldAfterBattle: 12,
  survivingPieceIds: <String>[
    'ashen_king_orsain',
    'ashen_rook_ysra',
    'ashen_bishop_veyl',
    'ashen_knight_cael',
    'ashen_pawn_d',
    'ashen_pawn_e',
    'ashen_pawn_f',
  ],
  capturedPieces: <LivingCapturedPieceOutcome>[],
  purchasedPieceIds: <String>[],
  missionRoleChanges: <String, PieceType>{},
);

LivingBattleOutcomeSnapshot _finaleOutcome() =>
    const LivingBattleOutcomeSnapshot(
      chapterNumber: 3,
      chapterId: 'living_m03',
      result: LivingBattleResult.victory,
      endReason: GameEndReason.checkmate,
      objectiveType: LivingObjectiveType.neutralizeTarget,
      pressureTier: 'severe',
      objectiveCompleted: true,
      completedTurns: 24,
      goldBefore: 10,
      goldAfterBattle: 20,
      survivingPieceIds: <String>['ashen_king_orsain'],
      capturedPieces: <LivingCapturedPieceOutcome>[],
      purchasedPieceIds: <String>[],
      missionRoleChanges: <String, PieceType>{},
    );

LivingDirectorPatch _terminalDirectorPatch(String runId) => LivingDirectorPatch(
  schemaVersion: 1,
  runId: runId,
  basedOnRevision: 0,
  campaignComplete: true,
  epilogue: List<String>.filled(
    3,
    'Orsain set down the unfinished crown as the ash bells fell quiet. '
    'The surviving court carried its names into a difficult dawn, '
    'knowing that victory had changed every oath they still kept. ',
  ).join(),
  completedChapter: const LivingCompletedChapterPatch(
    chapterNumber: 3,
    chapterId: 'living_m03',
    title: 'The Crown Set Down',
    oneLineSummary: 'The hopeful finale ended with a crown set down.',
  ),
  addCharacters: const <LivingCharacter>[],
  addEvents: const <LivingCanonEvent>[
    LivingCanonEvent(
      eventId: 'event_finale_service',
      chapterNumber: 3,
      type: LivingEventType.epilogue,
      subjectIds: <String>['char_orsain'],
      description: 'Orsain set down the unfinished crown.',
    ),
  ],
  addCanonFacts: const <LivingCanonFact>[],
  openStoryThreads: const <LivingStoryThread>[],
  characterTransitions: const <LivingCharacterTransition>[],
  advanceStoryThreads: const <LivingThreadChange>[],
  resolveStoryThreads: const <LivingThreadChange>[],
  relationshipChanges: const <LivingRelationshipChange>[],
  nextChapterIntent: const LivingNextChapterIntent(
    chapterNumber: 4,
    conflict: 'Terminal intent is ignored after a sealed finale.',
    objectiveType: LivingObjectiveType.surviveRounds,
    pressureTier: 'pressured',
    rewardTier: 20,
    finaleKind: LivingFinaleKind.none,
    essentialBeats: <String>[],
  ),
);

LivingDirectorPatch _directorPatch(String runId) => LivingDirectorPatch(
  schemaVersion: 1,
  runId: runId,
  basedOnRevision: 0,
  completedChapter: const LivingCompletedChapterPatch(
    chapterNumber: 1,
    chapterId: 'living_m01',
    title: 'The Ashen Divide',
    oneLineSummary: 'The Ashen Court held the causeway and followed the crows.',
  ),
  addCharacters: const <LivingCharacter>[],
  addEvents: const <LivingCanonEvent>[
    LivingCanonEvent(
      eventId: 'event_ch1_won',
      chapterNumber: 1,
      type: LivingEventType.battleWon,
      subjectIds: <String>['char_orsain'],
      description: 'Orsain held the ruined causeway.',
    ),
  ],
  addCanonFacts: const <LivingCanonFact>[],
  openStoryThreads: const <LivingStoryThread>[],
  characterTransitions: const <LivingCharacterTransition>[],
  advanceStoryThreads: const <LivingThreadChange>[],
  resolveStoryThreads: const <LivingThreadChange>[],
  relationshipChanges: const <LivingRelationshipChange>[],
  nextChapterIntent: const LivingNextChapterIntent(
    chapterNumber: 2,
    conflict: 'Hold until the ash bells stop.',
    objectiveType: LivingObjectiveType.surviveRounds,
    pressureTier: 'pressured',
    rewardTier: 20,
    finaleKind: LivingFinaleKind.none,
    essentialBeats: <String>['The enemy crosses under cover of ash.'],
  ),
);

LivingDirectorPatch _portraitDirectorPatch(String runId) {
  final json = _directorPatch(runId).toJson();
  json['addCharacters'] = <Object?>[
    const LivingCharacter(
      characterId: 'char_bell_keeper',
      originalName: 'The Bell Keeper',
      originalIdentity: 'A neutral keeper of the valley bells.',
      basePieceType: PieceType.bishop,
      lifeState: LivingLifeState.alive,
      whereabouts: LivingWhereabouts.withCourt,
      allegiance: LivingAllegiance.neutral,
      firstChapter: 1,
      lastChapter: 1,
    ).toJson(),
  ];
  json['addEvents'] = <Object?>[
    ...(json['addEvents']! as List<Object?>),
    const LivingCanonEvent(
      eventId: 'event_bell_keeper_joined',
      chapterNumber: 1,
      type: LivingEventType.joined,
      subjectIds: <String>['char_bell_keeper'],
      description: 'The Bell Keeper joined the court at the valley gate.',
    ).toJson(),
  ];
  json['nextChapterIntent'] = <String, Object?>{
    ...Map<String, Object?>.from(json['nextChapterIntent']! as Map),
    'newCharacterId': 'char_bell_keeper',
  };
  return LivingDirectorPatch.fromJson(json);
}

LivingChapterPackage _chapter(String runId) => LivingChapterPackage(
  schemaVersion: 1,
  runId: runId,
  basedOnRevision: 1,
  chapterNumber: 2,
  chapterId: 'living_m02',
  title: 'The Ash Bells',
  subtitle: 'Stand until the last bell',
  briefing: 'The court must survive twenty full rounds while the valley burns.',
  pressureTier: 'pressured',
  objective: const LivingMissionObjective(
    type: LivingObjectiveType.surviveRounds,
    label: 'Survive 20 full rounds or checkmate the enemy.',
    surviveRounds: 20,
  ),
  whiteCountryId: 'ashen',
  blackCountryId: 'iron',
  startingTurn: PieceColor.white,
  battlefieldId: BattlefieldId.ruinedCauseway,
  seed: 2201,
  economyEnabled: true,
  merchantEnabled: true,
  specialTilesEnabled: true,
  whiteGold: 22,
  blackGold: 20,
  merchantSpeed: 4,
  pieces: <LivingMissionPiece>[
    _piece('ashen_king_orsain', PieceType.king, PieceColor.white, 'e1', null),
    _piece(
      'ashen_rook_ysra',
      PieceType.rook,
      PieceColor.white,
      'a1',
      'char_ysra',
    ),
    _piece(
      'ashen_bishop_veyl',
      PieceType.bishop,
      PieceColor.white,
      'c1',
      'char_veyl',
    ),
    _piece(
      'ashen_knight_cael',
      PieceType.knight,
      PieceColor.white,
      'g1',
      'char_cael',
    ),
    _piece('ashen_pawn_d', PieceType.pawn, PieceColor.white, 'd2', null),
    _piece('ashen_pawn_e', PieceType.pawn, PieceColor.white, 'e2', null),
    _piece('ashen_pawn_f', PieceType.pawn, PieceColor.white, 'f2', null),
    _piece('enemy_king_2', PieceType.king, PieceColor.black, 'e8', null),
    _piece('enemy_rook_2', PieceType.rook, PieceColor.black, 'a8', null),
    _piece('enemy_bishop_2', PieceType.bishop, PieceColor.black, 'c8', null),
    _piece('enemy_knight_2', PieceType.knight, PieceColor.black, 'g8', null),
    _piece('enemy_pawn_d_2', PieceType.pawn, PieceColor.black, 'd7', null),
    _piece('enemy_pawn_e_2', PieceType.pawn, PieceColor.black, 'e7', null),
    _piece('enemy_pawn_f_2', PieceType.pawn, PieceColor.black, 'f7', null),
  ],
  reservePieceIds: const <String>[],
  dialogue: const <LivingDialogueLine>[
    LivingDialogueLine(
      lineId: 'living_m02_line_1',
      speakerId: 'char_ysra',
      side: 'left',
      text: 'The bells have started. Hold until the last one falls silent.',
    ),
    LivingDialogueLine(
      lineId: 'living_m02_line_2',
      speakerId: 'char_veyl',
      side: 'right',
      text: 'They are counting more than time.',
    ),
  ],
  aiAggression: .5,
  aiDefense: .5,
  aiObjectivePressure: .6,
  aiTileAppetite: .4,
);

LivingChapterPackage _portraitChapter(String runId) {
  final json = _chapter(runId).toJson();
  json['portraitCharacterId'] = 'char_bell_keeper';
  json['portraitPrompt'] =
      'A weathered bell keeper in ash-gray robes, half-body portrait.';
  return LivingChapterPackage.fromJson(json);
}

LivingMissionPiece _piece(
  String id,
  PieceType type,
  PieceColor color,
  String square,
  String? characterId,
) => LivingMissionPiece(
  pieceId: id,
  pieceType: type,
  color: color,
  square: livingSquareFromName(square),
  countryId: color == PieceColor.white ? 'ashen' : 'iron',
  loyalty: type == PieceType.king ? null : 60,
  fairPrice: type == PieceType.king ? null : 8,
  characterId: type == PieceType.king ? 'char_orsain' : characterId,
);
