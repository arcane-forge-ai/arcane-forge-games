import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_narrative_copy.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('generation copy stays stable until stage or attempt changes', () {
    final now = DateTime.utc(2026, 8, 11);
    final run =
        LivingCampaignFixedOpener.create(
          runId: 'run-copy-stability',
          now: now,
        ).copyWith(
          generationJob: LivingGenerationJob(
            jobId: 'job-copy-stability',
            stage: LivingGenerationStage.director,
            status: LivingGenerationStatus.running,
            attempt: 1,
            createdAt: now,
            updatedAt: now,
          ),
        );

    final first = LivingCampaignNarrativeCopy.forJob(
      run: run,
      stage: LivingGenerationStage.director,
      attempt: 1,
    );
    expect(
      LivingCampaignNarrativeCopy.forJob(
        run: run,
        stage: LivingGenerationStage.director,
        attempt: 1,
      ),
      first,
    );
    expect(LivingCampaignNarrativeCopy.director, contains(first));
    expect(
      LivingCampaignNarrativeCopy.forJob(
        run: run,
        stage: LivingGenerationStage.builder,
        attempt: 1,
      ),
      isIn(LivingCampaignNarrativeCopy.builder),
    );
    expect(
      LivingCampaignNarrativeCopy.forJob(
        run: run,
        stage: LivingGenerationStage.chapterArt,
        attempt: 1,
      ),
      isIn(LivingCampaignNarrativeCopy.endingArt),
    );
  });

  test('result explanation is one approved sentence and chapter-stable', () {
    final first = LivingCampaignNarrativeCopy.resultExplanation(
      runId: 'run-result-copy',
      chapterNumber: 2,
    );
    expect(first, isIn(LivingCampaignNarrativeCopy.resultExplanations));
    expect(first.endsWith('.'), isTrue);
    expect(
      LivingCampaignNarrativeCopy.resultExplanation(
        runId: 'run-result-copy',
        chapterNumber: 2,
      ),
      first,
    );
  });
}
