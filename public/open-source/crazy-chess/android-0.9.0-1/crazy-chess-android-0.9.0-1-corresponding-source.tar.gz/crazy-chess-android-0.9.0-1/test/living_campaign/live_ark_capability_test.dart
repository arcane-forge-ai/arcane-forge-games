@Tags(<String>['live'])
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crazy_chess/living_campaign/doubao_client.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store_io.dart';
import 'package:crazy_chess/living_campaign/living_campaign_controller.dart';
import 'package:crazy_chess/living_campaign/living_campaign_generation_service.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:crazy_chess/game/game_controller.dart';
import 'package:flutter_test/flutter_test.dart';

const _runLive = bool.fromEnvironment('RUN_LIVING_CAMPAIGN_LIVE_TESTS');
const _apiKey = String.fromEnvironment('ARK_API_KEY');
const _baseUrl = String.fromEnvironment(
  'ARK_BASE_URL',
  defaultValue: LivingCampaignSettings.defaultBaseUrl,
);
const _textModel = String.fromEnvironment(
  'LIVING_CAMPAIGN_TEXT_MODEL',
  defaultValue: LivingCampaignSettings.defaultTextModel,
);
const _liveEvidenceRoot = String.fromEnvironment(
  'LIVING_CAMPAIGN_LIVE_EVIDENCE_ROOT',
  defaultValue:
      'test_result/20260806-001802_living-campaign-v1/live-ark-prologue',
);
const _liveRepairSource = String.fromEnvironment(
  'LIVING_CAMPAIGN_LIVE_REPAIR_SOURCE',
  defaultValue:
      'test_result/20260806-185013_living-campaign-async-generation/'
      'live-ark-opening/archive/runs/living-1786021776866463.json',
);
const _liveRepairEvidenceRoot = String.fromEnvironment(
  'LIVING_CAMPAIGN_LIVE_REPAIR_EVIDENCE_ROOT',
  defaultValue:
      'test_result/20260806-185013_living-campaign-async-generation/'
      'live-ark-repair',
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'configured Ark key can tokenize and return validated JSON',
    () async {
      expect(_apiKey, isNotEmpty, reason: 'ARK_API_KEY was not injected.');
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: _apiKey,
          baseUrl: _baseUrl,
          textModel: _textModel,
        ),
      );
      addTearDown(client.close);

      final tokens = await client.countTextTokens(const <String>[
        'Crazy Chess Living Campaign capability test',
      ]);
      expect(tokens.totalTokens, greaterThan(0));
      await client.testCapability();
    },
    skip: !_runLive,
    timeout: const Timeout(Duration(minutes: 2)),
  );

  test(
    'configured Ark text model generates a validated unique prologue',
    () async {
      expect(_apiKey, isNotEmpty, reason: 'ARK_API_KEY was not injected.');
      final directory = Directory(_liveEvidenceRoot);
      await directory.create(recursive: true);
      final attemptMarker = File('${directory.path}/attempt-started.json');
      expect(
        await attemptMarker.exists(),
        isFalse,
        reason:
            'This one-shot paid acceptance directory has already been used. '
            'Inspect its evidence instead of issuing another request.',
      );
      final startedAt = DateTime.now().toUtc();
      await attemptMarker.writeAsString(
        const JsonEncoder.withIndent('  ').convert(<String, Object?>{
          'kind': 'living-campaign-live-ark-opening-attempt',
          'authorized': true,
          'model': _textModel,
          'startedAt': startedAt.toIso8601String(),
          'maximumPaidChatRequests': 1,
        }),
        flush: true,
      );
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: _apiKey,
          baseUrl: _baseUrl,
          textModel: _textModel,
        ),
      );
      addTearDown(client.close);
      final gateway = _OneShotLiveGateway(
        DoubaoLivingGenerationGateway(client),
        minimumTaskDuration: const Duration(seconds: 95),
      );
      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => Directory('${directory.path}/archive'),
      );
      final gameController = GameController();
      addTearDown(gameController.dispose);
      late final LivingCampaignController controller;
      Future<LivingGenerationResult> generatePrologue(LivingCampaignRun run) =>
          LivingCampaignGenerationService(
            gateway: gateway,
            archive: archive,
            onProgress: controller.acceptGenerationProgress,
          ).generatePrologue(run);
      controller = LivingCampaignController(
        gameController: gameController,
        archive: archive,
        generatePrologue: generatePrologue,
        generateNextChapter: (run, outcome) async => LivingGenerationResult(
          run: run,
          completed: false,
          message: 'The one-shot acceptance covers only the opening.',
        ),
        generationSettingsSnapshot: () => const <String, Object?>{
          'baseUrl': _baseUrl,
          'textModel': _textModel,
          'apiKeyConfigured': true,
          'apiKeySource': 'developerEnv',
        },
      );
      addTearDown(controller.dispose);
      await controller.initialize();

      final stopwatch = Stopwatch()..start();
      final statusTimeline = <Map<String, Object?>>[];
      String? previousStatusKey;
      void captureStatus() {
        final run = controller.activeRun;
        final job = run?.generationJob;
        final key = <Object?>[
          controller.directorStatus.name,
          job?.stage.name,
          job?.status.name,
          job?.receivedContentCharacters,
        ].join('|');
        if (key == previousStatusKey) return;
        previousStatusKey = key;
        statusTimeline.add(<String, Object?>{
          'elapsedMs': stopwatch.elapsedMilliseconds,
          'directorStatus': controller.directorStatus.name,
          'directorStatusLabel': controller.directorStatusLabel,
          'phase': controller.phase.name,
          'stage': job?.stage.name,
          'jobStatus': job?.status.name,
          'receivedContentCharacters': job?.receivedContentCharacters ?? 0,
          'providerRequestId': _redactRequestId(job?.providerRequestId),
        });
      }

      controller.addListener(captureStatus);
      addTearDown(() => controller.removeListener(captureStatus));
      final handle = await controller.startNewRun();
      expect(handle, isNotNull);
      captureStatus();
      final archivedAtReturn = await archive.readRun(handle!.runId);
      expect(
        archivedAtReturn?.generationJob?.status,
        LivingGenerationStatus.running,
      );
      expect(controller.phase, LivingCampaignPhase.hub);
      expect(controller.openingReady, isFalse);

      final progressTimeline = <Map<String, Object?>>[];
      final progressSubscription = handle.onProgress((run) {
        final job = run.generationJob;
        progressTimeline.add(<String, Object?>{
          'elapsedMs': stopwatch.elapsedMilliseconds,
          'stage': job?.stage.name,
          'status': job?.status.name,
          'receivedContentCharacters': job?.receivedContentCharacters ?? 0,
          'providerRequestId': _redactRequestId(job?.providerRequestId),
        });
      });
      addTearDown(progressSubscription.cancel);

      final oldBoundary = Completer<Map<String, Object?>>();
      final oldBoundaryTimer = Timer(const Duration(seconds: 91), () {
        oldBoundary.complete(<String, Object?>{
          'reached': true,
          'elapsedMs': stopwatch.elapsedMilliseconds,
          'taskRunning': controller.isGenerationRunning,
          'status': controller.directorStatus.name,
          'statusLabel': controller.directorStatusLabel,
          'phase': controller.phase.name,
          'm01Locked': !controller.openingReady,
        });
      });
      await handle.completion;
      if (!oldBoundary.isCompleted) {
        oldBoundaryTimer.cancel();
        oldBoundary.complete(<String, Object?>{
          'reached': false,
          'elapsedMs': stopwatch.elapsedMilliseconds,
          'taskRunning': controller.isGenerationRunning,
          'status': controller.directorStatus.name,
          'statusLabel': controller.directorStatusLabel,
          'phase': controller.phase.name,
          'm01Locked': !controller.openingReady,
        });
      }
      final oldBoundaryState = await oldBoundary.future;
      stopwatch.stop();
      captureStatus();

      final resultRun = controller.activeRun!;
      final textRecords = resultRun.generationRecords
          .where(
            (record) =>
                record.stage == LivingGenerationStage.prologue ||
                record.stage == LivingGenerationStage.prologueRepair,
          )
          .toList(growable: false);
      final finalRecord = textRecords.lastOrNull;
      await File('${directory.path}/result.json').writeAsString(
        const JsonEncoder.withIndent('  ').convert(<String, Object?>{
          'kind': 'living-campaign-async-live-ark-opening-acceptance',
          'model': _textModel,
          'completed': controller.openingReady,
          'paidChatRequests': gateway.paidChatRequests,
          'blockedAdditionalChatRequests':
              gateway.blockedAdditionalChatRequests,
          'providerDurationMs': gateway.providerDuration?.inMilliseconds,
          'taskDurationMs': stopwatch.elapsedMilliseconds,
          'oldNinetySecondBoundary': oldBoundaryState,
          'task': <String, Object?>{
            'runId': handle.runId,
            'jobId': handle.jobId,
            'initialStage': handle.initialStage.name,
            'initialAttempt': handle.initialAttempt,
            'settingsSnapshot': handle.settingsSnapshot,
          },
          'transport': <String, Object?>{
            'type': finalRecord?.transportType,
            'requestId': _redactRequestId(finalRecord?.providerRequestId),
            'timeToFirstEventMs': finalRecord?.timeToFirstEventMs,
            'durationMs': finalRecord?.durationMs,
            'usage': finalRecord?.usage,
            'finishReason': finalRecord?.finishReason,
            'failureCategory': finalRecord?.errorCode,
          },
          'statusTimeline': statusTimeline,
          'progressTimeline': progressTimeline,
          'run': resultRun.toJson(),
        }),
        flush: true,
      );
      expect(gateway.paidChatRequests, 1);
      expect(gateway.blockedAdditionalChatRequests, 0);
      expect(oldBoundaryState['reached'], isTrue);
      expect(oldBoundaryState['taskRunning'], isTrue);
      expect(oldBoundaryState['statusLabel'], 'SCRIPTING');
      expect(oldBoundaryState['phase'], LivingCampaignPhase.hub.name);
      expect(oldBoundaryState['m01Locked'], isTrue);
      expect(controller.openingReady, isTrue, reason: controller.message);
      expect(resultRun.campaignTitle.trim(), isNotEmpty);
      expect(resultRun.storyPromise.length, greaterThanOrEqualTo(40));
      expect(resultRun.prologue.length, greaterThanOrEqualTo(240));
      expect(finalRecord, isNotNull);
      expect(finalRecord!.model, _textModel);
      expect(finalRecord.transportType, 'sse');
      expect(finalRecord.providerRequestId, isNotEmpty);
      expect(finalRecord.timeToFirstEventMs, isNotNull);
      expect(finalRecord.durationMs, isNotNull);
      expect(finalRecord.finishReason, isNotEmpty);
    },
    skip: !_runLive,
    timeout: const Timeout(Duration(minutes: 12)),
  );

  test(
    'configured Ark text model repairs the archived prologue once',
    () async {
      expect(_apiKey, isNotEmpty, reason: 'ARK_API_KEY was not injected.');
      final sourceFile = File(_liveRepairSource);
      expect(
        await sourceFile.exists(),
        isTrue,
        reason: 'The authorized repair source archive is missing.',
      );
      final directory = Directory(_liveRepairEvidenceRoot);
      await directory.create(recursive: true);
      final attemptMarker = File('${directory.path}/attempt-started.json');
      expect(
        await attemptMarker.exists(),
        isFalse,
        reason:
            'This one-shot paid repair directory has already been used. '
            'Inspect its evidence instead of issuing another request.',
      );
      final startedAt = DateTime.now().toUtc();
      await attemptMarker.writeAsString(
        const JsonEncoder.withIndent('  ').convert(<String, Object?>{
          'kind': 'living-campaign-live-ark-prologue-repair-attempt',
          'authorized': true,
          'model': _textModel,
          'sourceArchive': _liveRepairSource,
          'startedAt': startedAt.toIso8601String(),
          'maximumPaidChatRequests': 1,
        }),
        flush: true,
      );

      final sourcePayload = jsonDecode(await sourceFile.readAsString());
      expect(sourcePayload, isA<Map<Object?, Object?>>());
      final sourceRun = LivingCampaignRun.fromJson(
        Map<String, Object?>.from(sourcePayload as Map<Object?, Object?>),
      );
      final sourcePrologueRecords = sourceRun.generationRecords
          .where(
            (record) =>
                record.stage == LivingGenerationStage.prologue &&
                record.status == LivingGenerationStatus.completed,
          )
          .toList(growable: false);
      final sourceCompletedRepairs = sourceRun.generationRecords
          .where(
            (record) =>
                record.stage == LivingGenerationStage.prologueRepair &&
                record.status == LivingGenerationStatus.completed,
          )
          .toList(growable: false);
      expect(sourcePrologueRecords, hasLength(1));
      expect(sourceCompletedRepairs, isEmpty);
      expect(
        sourceRun.generationJob?.stage,
        LivingGenerationStage.prologueRepair,
      );
      expect(
        sourceRun.generationJob?.status,
        LivingGenerationStatus.awaitingResume,
      );
      final invalidPrologue =
          sourcePrologueRecords.single.responsePayload['prologue']! as String;
      expect(invalidPrologue.length, greaterThan(2400));

      final archive = IoLivingCampaignArchiveStore(
        rootProvider: () async => Directory('${directory.path}/archive'),
      );
      await archive.initialize();
      await archive.writeRun(sourceRun);
      final client = DoubaoClient(
        settings: const LivingCampaignSettings(
          apiKey: _apiKey,
          baseUrl: _baseUrl,
          textModel: _textModel,
        ),
      );
      addTearDown(client.close);
      final gateway = _OneShotLiveGateway(
        DoubaoLivingGenerationGateway(client),
        minimumTaskDuration: Duration.zero,
      );
      final progressTimeline = <Map<String, Object?>>[];
      final stopwatch = Stopwatch()..start();
      final service = LivingCampaignGenerationService(
        gateway: gateway,
        archive: archive,
        onProgress: (run) {
          final job = run.generationJob;
          progressTimeline.add(<String, Object?>{
            'elapsedMs': stopwatch.elapsedMilliseconds,
            'stage': job?.stage.name,
            'status': job?.status.name,
            'receivedContentCharacters': job?.receivedContentCharacters ?? 0,
            'providerRequestId': _redactRequestId(job?.providerRequestId),
          });
        },
      );

      final result = await service.generatePrologue(sourceRun);
      stopwatch.stop();
      final repairedRun = result.run;
      final completedPrologues = repairedRun.generationRecords
          .where(
            (record) =>
                record.stage == LivingGenerationStage.prologue &&
                record.status == LivingGenerationStatus.completed,
          )
          .toList(growable: false);
      final completedRepairs = repairedRun.generationRecords
          .where(
            (record) =>
                record.stage == LivingGenerationStage.prologueRepair &&
                record.status == LivingGenerationStatus.completed,
          )
          .toList(growable: false);
      final finalRepair = completedRepairs.lastOrNull;
      await File('${directory.path}/result.json').writeAsString(
        const JsonEncoder.withIndent('  ').convert(<String, Object?>{
          'kind': 'living-campaign-live-ark-prologue-repair-acceptance',
          'model': _textModel,
          'completed': result.completed,
          'message': result.message,
          'paidChatRequests': gateway.paidChatRequests,
          'blockedAdditionalChatRequests':
              gateway.blockedAdditionalChatRequests,
          'providerDurationMs': gateway.providerDuration?.inMilliseconds,
          'taskDurationMs': stopwatch.elapsedMilliseconds,
          'source': <String, Object?>{
            'runId': sourceRun.runId,
            'completedPrologueRecords': sourcePrologueRecords.length,
            'completedRepairRecords': sourceCompletedRepairs.length,
            'invalidPrologueCharacters': invalidPrologue.length,
            'providerRequestId': _redactRequestId(
              sourcePrologueRecords.single.providerRequestId,
            ),
          },
          'result': <String, Object?>{
            'runId': repairedRun.runId,
            'openingReady': repairedRun.prologue.isNotEmpty,
            'completedPrologueRecords': completedPrologues.length,
            'completedRepairRecords': completedRepairs.length,
            'campaignTitle': repairedRun.campaignTitle,
            'storyPromiseCharacters': repairedRun.storyPromise.length,
            'prologueCharacters': repairedRun.prologue.length,
          },
          'transport': <String, Object?>{
            'type': finalRepair?.transportType,
            'requestId': _redactRequestId(finalRepair?.providerRequestId),
            'timeToFirstEventMs': finalRepair?.timeToFirstEventMs,
            'durationMs': finalRepair?.durationMs,
            'usage': finalRepair?.usage,
            'finishReason': finalRepair?.finishReason,
            'failureCategory': finalRepair?.errorCode,
          },
          'progressTimeline': progressTimeline,
        }),
        flush: true,
      );

      expect(gateway.paidChatRequests, 1);
      expect(gateway.blockedAdditionalChatRequests, 0);
      expect(completedPrologues, hasLength(1));
      expect(completedRepairs, hasLength(1));
      expect(result.completed, isTrue, reason: result.message);
      expect(repairedRun.generationJob, isNull);
      expect(repairedRun.campaignTitle.trim().length, inInclusiveRange(4, 80));
      expect(repairedRun.storyPromise.trim().length, inInclusiveRange(40, 500));
      expect(repairedRun.prologue.trim().length, inInclusiveRange(240, 2400));
      expect(finalRepair, isNotNull);
      expect(finalRepair!.model, _textModel);
      expect(finalRepair.transportType, 'sse');
      expect(finalRepair.providerRequestId, isNotEmpty);
      expect(finalRepair.timeToFirstEventMs, isNotNull);
      expect(finalRepair.durationMs, isNotNull);
      expect(finalRepair.finishReason, isNotEmpty);
    },
    skip: !_runLive,
    timeout: const Timeout(Duration(minutes: 12)),
  );
}

class _OneShotLiveGateway implements LivingGenerationGateway {
  _OneShotLiveGateway(this.delegate, {required this.minimumTaskDuration});

  final LivingGenerationGateway delegate;
  final Duration minimumTaskDuration;
  int paidChatRequests = 0;
  int blockedAdditionalChatRequests = 0;
  Duration? providerDuration;

  @override
  String get textModel => delegate.textModel;

  @override
  String get imageModel => delegate.imageModel;

  @override
  Future<DoubaoTokenizationResult> countTextTokens(Iterable<String> values) =>
      delegate.countTextTokens(values);

  @override
  Future<DoubaoJsonResponse> chatJson({
    required String systemPrompt,
    required Map<String, Object?> userPayload,
    int maxTokens = 8192,
    double temperature = .25,
    DoubaoStreamProgressCallback? onProgress,
  }) async {
    if (paidChatRequests >= 1) {
      blockedAdditionalChatRequests++;
      throw const LivingProviderException(
        code: 'additional_paid_request_not_authorized',
        safeMessage:
            'The one-shot live acceptance did not issue an automatic repair.',
      );
    }
    paidChatRequests++;
    final stopwatch = Stopwatch()..start();
    final response = await delegate.chatJson(
      systemPrompt: systemPrompt,
      userPayload: userPayload,
      maxTokens: maxTokens,
      temperature: temperature,
      onProgress: onProgress,
    );
    providerDuration = stopwatch.elapsed;
    final remaining = minimumTaskDuration - stopwatch.elapsed;
    if (remaining > Duration.zero) await Future<void>.delayed(remaining);
    return response;
  }

  @override
  Future<DoubaoPortraitResult> generatePortrait({
    required String prompt,
    int? seed,
  }) => delegate.generatePortrait(prompt: prompt, seed: seed);
}

String? _redactRequestId(String? value) {
  if (value == null || value.isEmpty) return value;
  if (value.length <= 8) return '[REDACTED]';
  return '${value.substring(0, 4)}…${value.substring(value.length - 4)}';
}
