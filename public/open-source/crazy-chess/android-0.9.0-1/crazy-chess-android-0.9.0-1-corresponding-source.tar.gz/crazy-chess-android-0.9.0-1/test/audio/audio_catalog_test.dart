import 'dart:io';

import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('catalog preserves all planned music and SFX roots', () {
    expect(GameAudioCatalog.music, hasLength(20));
    expect(GameAudioCatalog.sfx, hasLength(32));
    expect(
      GameAudioCatalog.sfx.values.where((cue) => cue.isAvailable),
      hasLength(31),
    );
    expect(
      GameAudioCatalog.sfx['dialogue_advance']?.pendingReason,
      contains('Arcane Forge'),
    );
    expect(
      GameAudioCatalog.music.keys,
      containsAll(<String>[
        'living_entry_hub',
        'living_story_briefing',
        'living_battle',
        'living_victory_result',
        'living_defeat_result',
      ]),
    );
  });

  test('every promoted catalog path exists locally', () {
    final paths = GameAudioCatalog.music.values
        .expand((cue) => cue.assetPaths)
        .followedBy(
          GameAudioCatalog.sfx.values
              .map((cue) => cue.assetPath)
              .whereType<String>(),
        );

    for (final path in paths) {
      expect(File('assets/$path').existsSync(), isTrue, reason: path);
    }
  });

  test('selected dual playlists and battle revision are runtime choices', () {
    expect(GameAudioCatalog.music['main_theme']!.assetPaths, [
      'runtime/audio/music/main_theme_a.mp3',
      'runtime/audio/music/main_theme_b.mp3',
    ]);
    expect(GameAudioCatalog.music['mercantile_court']!.assetPaths, [
      'runtime/audio/music/mercantile_court_a.mp3',
      'runtime/audio/music/mercantile_court_b.mp3',
    ]);
    expect(GameAudioCatalog.music['mercantile_battle']!.assetPaths, [
      'runtime/audio/music/mercantile_battle.mp3',
    ]);
  });

  test('Living Campaign owner-approved playlists preserve review labels', () {
    final expected = <String, (List<String>, List<String>, int)>{
      'living_entry_hub': (
        ['entry_hub_a.mp3', 'entry_hub_b.mp3', 'entry_hub_c.mp3'],
        ['A', 'B', 'C'],
        1200,
      ),
      'living_story_briefing': (
        ['story_briefing_b.mp3', 'story_briefing_c.mp3'],
        ['B', 'C'],
        1200,
      ),
      'living_battle': (
        ['battle_a.mp3', 'battle_b.mp3', 'battle_c.mp3'],
        ['A', 'B', 'C'],
        1200,
      ),
      'living_victory_result': (
        [
          'victory_result_a.mp3',
          'victory_result_b.mp3',
          'victory_result_c.mp3',
        ],
        ['A', 'B', 'C'],
        2400,
      ),
      'living_defeat_result': (
        ['defeat_result_a.mp3', 'defeat_result_c.mp3'],
        ['A', 'C'],
        1200,
      ),
    };

    for (final MapEntry(key: cue, value: contract) in expected.entries) {
      final definition = GameAudioCatalog.music[cue]!;
      expect(
        definition.assetPaths.map((path) => path.split('/').last),
        contract.$1,
        reason: cue,
      );
      expect(definition.candidateLabels, contract.$2, reason: cue);
      expect(
        definition.crossfadeDuration.inMilliseconds,
        contract.$3,
        reason: cue,
      );
    }

    final livingPaths = GameAudioCatalog.music.entries
        .where((entry) => entry.key.startsWith('living_'))
        .expand((entry) => entry.value.assetPaths);
    expect(livingPaths, isNot(contains(contains('story_briefing_a.mp3'))));
    expect(livingPaths, isNot(contains(contains('defeat_result_b.mp3'))));
  });

  test('Familiarity gates country court and battle music independently', () {
    expect(
      GameAudioCatalog.cueForContext(
        GameMusicContext.court,
        countryId: 'mercantile',
        familiarity: 24,
      ),
      'court_neutral',
    );
    expect(
      GameAudioCatalog.cueForContext(
        GameMusicContext.court,
        countryId: 'mercantile',
        familiarity: 25,
      ),
      'mercantile_court',
    );
    expect(
      GameAudioCatalog.cueForContext(
        GameMusicContext.battle,
        countryId: 'mercantile',
        familiarity: 99,
      ),
      'battle_neutral',
    );
    expect(
      GameAudioCatalog.cueForContext(
        GameMusicContext.battle,
        countryId: 'mercantile',
        familiarity: 100,
      ),
      'mercantile_battle',
    );
  });
}
