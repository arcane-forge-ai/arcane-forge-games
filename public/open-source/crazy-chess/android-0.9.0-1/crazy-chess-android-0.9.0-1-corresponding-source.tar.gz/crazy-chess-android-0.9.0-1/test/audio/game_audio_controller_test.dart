import 'dart:async';

import 'package:crazy_chess/audio/game_audio_controller.dart';
import 'package:flutter_test/flutter_test.dart';

class _FakeMusicPlayer implements GameMusicPlayerPort {
  final _completed = StreamController<void>.broadcast();
  final playedAssets = <String>[];
  final volumes = <double>[];
  var stopCount = 0;

  void complete() => _completed.add(null);

  @override
  Stream<void> get onPlayerComplete => _completed.stream;

  @override
  Future<void> dispose() => _completed.close();

  @override
  Future<void> playAsset(String assetPath, {required double volume}) async {
    playedAssets.add(assetPath);
    volumes.add(volume);
  }

  @override
  Future<void> setStopReleaseMode() async {}

  @override
  Future<void> setVolume(double volume) async => volumes.add(volume);

  @override
  Future<void> stop() async => stopCount++;
}

void main() {
  test(
    'cue revisits rotate candidates and log each successful start',
    () async {
      final players = [_FakeMusicPlayer(), _FakeMusicPlayer()];
      final logs = <String>[];
      final controller = GameAudioController(
        musicPlayerPorts: players,
        sfxPlayers: const [],
        musicPlaybackLogger: logs.add,
        transitionDelay: (_) async {},
      );
      addTearDown(controller.dispose);

      controller.playMusic('living_entry_hub');
      await _waitForLogs(logs, 1);
      controller.playMusic('main_theme');
      await _waitForLogs(logs, 2);
      controller.playMusic('living_entry_hub');
      await _waitForLogs(logs, 3);

      expect(
        logs[0],
        allOf(contains('cue=living_entry_hub'), contains('candidate=A')),
      );
      expect(logs[1], contains('cue=main_theme'));
      expect(
        logs[2],
        allOf(contains('cue=living_entry_hub'), contains('candidate=B')),
      );
      expect(logs[0], contains('reason=cueChange'));
      expect(logs[0], contains('fade_ms=1200'));
    },
  );

  test(
    'natural completion advances playlist and logs the original label',
    () async {
      final players = [_FakeMusicPlayer(), _FakeMusicPlayer()];
      final logs = <String>[];
      final controller = GameAudioController(
        musicPlayerPorts: players,
        sfxPlayers: const [],
        musicPlaybackLogger: logs.add,
        transitionDelay: (_) async {},
      );
      addTearDown(controller.dispose);

      controller.playMusic('living_defeat_result');
      await _waitForLogs(logs, 1);
      players[0].complete();
      await _waitForLogs(logs, 2);

      expect(logs[0], contains('candidate=A'));
      expect(
        logs[1],
        allOf(contains('candidate=C'), contains('reason=playlistAdvance')),
      );
    },
  );

  test(
    'redundant active cue request does not replay or duplicate its log',
    () async {
      final players = [_FakeMusicPlayer(), _FakeMusicPlayer()];
      final logs = <String>[];
      final fadeSteps = <Duration>[];
      final controller = GameAudioController(
        musicPlayerPorts: players,
        sfxPlayers: const [],
        musicPlaybackLogger: logs.add,
        transitionDelay: (duration) async => fadeSteps.add(duration),
      );
      addTearDown(controller.dispose);

      controller.playMusic('living_victory_result');
      await _waitForLogs(logs, 1);
      await _waitUntil(() => fadeSteps.length == 8);
      controller.playMusic('living_victory_result');
      await Future<void>.delayed(Duration.zero);

      expect(logs, hasLength(1));
      expect(
        logs.single,
        allOf(contains('candidate=A'), contains('fade_ms=2400')),
      );
      expect(fadeSteps, everyElement(const Duration(milliseconds: 300)));
      expect(players[0].volumes.first, 0);
      expect(players[0].volumes.last, closeTo(.384, .0001));
    },
  );
}

Future<void> _waitForLogs(List<String> logs, int count) async {
  for (var attempt = 0; attempt < 50 && logs.length < count; attempt++) {
    await Future<void>.delayed(Duration.zero);
  }
  expect(logs, hasLength(greaterThanOrEqualTo(count)));
}

Future<void> _waitUntil(bool Function() condition) async {
  for (var attempt = 0; attempt < 50 && !condition(); attempt++) {
    await Future<void>.delayed(Duration.zero);
  }
  expect(condition(), isTrue);
}
