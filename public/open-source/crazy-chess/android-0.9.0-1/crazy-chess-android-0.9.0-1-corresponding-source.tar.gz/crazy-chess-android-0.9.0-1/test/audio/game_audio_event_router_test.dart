import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

class _RecordingAudio implements StoryAudioPort {
  final List<String> sfx = <String>[];

  @override
  Future<void> dispose() async {}

  @override
  void playMusic(String cue) {}

  @override
  void playSfx(String cue) => sfx.add(cue);
}

void main() {
  test('semantic router distinguishes normal and knight movement', () {
    final audio = _RecordingAudio();
    final game = GameController();
    final lastPiece = LastPieceSessionController();
    final router = GameAudioEventRouter(
      audio: audio,
      gameController: game,
      lastPieceController: lastPiece,
    );
    addTearDown(() {
      router.dispose();
      game.dispose();
      lastPiece.dispose();
    });

    game.startNewGame();
    audio.sfx.clear();
    game.makeMove(const ChessMove(from: Square(6, 4), to: Square(4, 4)));
    game.makeMove(const ChessMove(from: Square(1, 0), to: Square(2, 0)));
    game.makeMove(const ChessMove(from: Square(7, 6), to: Square(5, 5)));

    expect(audio.sfx, containsAllInOrder(['piece_move', 'knight_leap']));
  });

  test('Last Piece presentation routes transformations and spawns', () async {
    final audio = _RecordingAudio();
    final game = GameController();
    final lastPiece = LastPieceSessionController();
    final router = GameAudioEventRouter(
      audio: audio,
      gameController: game,
      lastPieceController: lastPiece,
    );
    addTearDown(() {
      router.dispose();
      game.dispose();
      lastPiece.dispose();
    });

    lastPiece.startRun(runSeed: 17);
    audio.sfx.clear();
    await lastPiece.debugRunEnemyPhase();

    if (lastPiece.presentationSteps.any(
      (step) => step.kind == LastPiecePresentationKind.spawn,
    )) {
      expect(audio.sfx, contains('enemy_spawn'));
    } else {
      expect(audio.sfx, isNotEmpty);
    }
  });
}
