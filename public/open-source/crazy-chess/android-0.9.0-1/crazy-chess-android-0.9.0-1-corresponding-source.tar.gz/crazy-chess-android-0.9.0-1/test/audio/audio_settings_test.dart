import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemoryAudioSettingsStore implements GameAudioSettingsStore {
  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}

void main() {
  test('mixer settings persist every volume and mute channel', () async {
    final store = _MemoryAudioSettingsStore();
    final repository = GameAudioSettingsRepository(store: store);
    const settings = GameAudioSettings(
      masterVolume: .72,
      musicVolume: .43,
      sfxVolume: .91,
      masterMuted: false,
      musicMuted: true,
      sfxMuted: false,
    );

    await repository.save(settings);
    final reloaded = await repository.load();

    expect(reloaded.masterVolume, .72);
    expect(reloaded.musicVolume, .43);
    expect(reloaded.sfxVolume, .91);
    expect(reloaded.masterMuted, isFalse);
    expect(reloaded.musicMuted, isTrue);
    expect(reloaded.sfxMuted, isFalse);
  });

  test('corrupt mixer settings fall back to production defaults', () async {
    final store = _MemoryAudioSettingsStore()..value = '{broken';
    final settings = await GameAudioSettingsRepository(store: store).load();

    expect(settings.masterVolume, 1);
    expect(settings.musicVolume, .8);
    expect(settings.sfxVolume, .9);
    expect(settings.masterMuted, isFalse);
  });
}
