import 'dart:io';
import 'dart:math' as math;

import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/game/game_controller.dart';
import 'package:crazy_chess/story/campaign_ai.dart';
import 'package:crazy_chess/story/story_campaign_controller.dart';
import 'package:crazy_chess/story/story_catalog.dart';
import 'package:crazy_chess/story/story_models.dart';
import 'package:crazy_chess/story/story_profile.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  late StoryCatalog catalog;

  setUpAll(() {
    catalog = StoryCatalog.fromJsonString(
      File(StoryCatalog.assetPath).readAsStringSync(),
    );
  });

  test('scenario start reconstructs deterministic authored partial army', () {
    final game = GameController();
    final mission = catalog.campaign.missionById('m01');
    game.startScenario(mission.toScenarioSetup());
    final pieces = game.board.expand((row) => row).whereType<ChessPiece>();
    expect(pieces, hasLength(mission.pieces.length));
    expect(game.activeScenarioId, 'm01');
    expect(game.economyEnabled, isFalse);
    expect(game.merchantEnabled, isFalse);
    expect(game.kingSquare(PieceColor.white), const Square(7, 4));
  });

  test('escape success unlocks m02 only after post-battle scene', () async {
    final game = GameController();
    final store = _MemoryCampaignProfileStore(null);
    final story = StoryCampaignController(
      gameController: game,
      catalog: catalog,
      profileRepository: CampaignProfileRepository(store: store),
    );
    await story.initialize();
    story.startSelectedMission();
    _finishDialogue(story);
    expect(story.phase, StoryCampaignPhase.battle);

    final kingSquare = game.kingSquare(PieceColor.white)!;
    final king = game.pieceAt(kingSquare)!;
    game.board[kingSquare.row][kingSquare.col] = null;
    final target = story.activeMission.objective.targetSquare!;
    game.board[target.row][target.col] = king;
    story.evaluateAfterPresentation();
    expect(story.phase, StoryCampaignPhase.dialogue);
    expect(story.profile.unlockedMissionIds, isNot(contains('m02')));

    _finishDialogue(story);
    expect(story.phase, StoryCampaignPhase.results);
    expect(story.profile.completedMissionIds, contains('m01'));
    expect(story.profile.unlockedMissionIds, contains('m02'));
    expect(story.profile.recruitedCharacterIds, contains('captain_mara'));
    story.dispose();
    game.dispose();
  });

  test(
    'named captures are battle-local and retry rebuilds the roster',
    () async {
      final game = GameController();
      final story = StoryCampaignController(
        gameController: game,
        catalog: catalog,
        profileRepository: CampaignProfileRepository(
          store: _MemoryCampaignProfileStore(null),
        ),
      );
      await story.initialize();
      story.startSelectedMission();
      _finishDialogue(story);
      final maraSquare = const Square(6, 3);
      expect(game.pieceAt(maraSquare)?.characterId, 'captain_mara');
      game.board[maraSquare.row][maraSquare.col] = null;
      expect(
        game.board
            .expand((row) => row)
            .whereType<ChessPiece>()
            .any((piece) => piece.characterId == 'captain_mara'),
        isFalse,
      );
      story.retryMission();
      expect(
        game.board
            .expand((row) => row)
            .whereType<ChessPiece>()
            .any((piece) => piece.characterId == 'captain_mara'),
        isTrue,
      );
      story.dispose();
      game.dispose();
    },
  );

  test('campaign AI returns a legal move from the authored position', () {
    final game = GameController();
    final mission = catalog.campaign.missionById('m07');
    game.startScenario(mission.toScenarioSetup());
    game.turn = PieceColor.black;
    final ai = CampaignAi(seed: mission.seed);
    final move = ai.chooseMove(controller: game, mission: mission);
    expect(move, isNotNull);
    final mover = game.pieceAt(move!.from);
    expect(mover?.color, PieceColor.black);
    expect(
      game.legalMovesFrom(move.from),
      contains(predicate<ChessMove>((candidate) => candidate.to == move.to)),
    );
  });

  test(
    'campaign AI offer choice is independent of hidden loyalty and price',
    () {
      final game = GameController();
      addTearDown(game.dispose);
      game.startNewGame();
      game.turn = PieceColor.black;
      game.completedActionCount = 3;
      game.gold[PieceColor.black] = 20;
      const profile = CampaignAiProfile(
        aggression: 1,
        defense: .5,
        objectivePressure: 1,
        tileAppetite: .5,
      );

      final first = CampaignAi(
        seed: 0,
      ).chooseConfiguredOffer(controller: game, aiProfile: profile);
      expect(first, isNotNull);

      for (var row = 0; row < 8; row++) {
        for (var col = 0; col < 8; col++) {
          final piece = game.board[row][col];
          if (piece == null || piece.color != PieceColor.white) continue;
          game.board[row][col] = ChessPiece(
            id: piece.id,
            type: piece.type,
            color: piece.color,
            countryId: piece.countryId,
            loyalty: piece.type == PieceType.king ? null : 0,
            fairPrice: piece.type == PieceType.king ? null : 999,
            hasMoved: piece.hasMoved,
            personalityId: piece.personalityId,
            characterId: piece.characterId,
            newlyPurchased: piece.newlyPurchased,
          );
        }
      }
      final second = CampaignAi(
        seed: 0,
      ).chooseConfiguredOffer(controller: game, aiProfile: profile);

      expect(second?.target, first?.target);
      expect(second?.gold, first?.gold);
    },
  );

  test('Living offer rolls only after a public valid plan exists', () {
    final game = GameController();
    addTearDown(game.dispose);
    game.startNewGame();
    game.turn = PieceColor.black;
    game.gold[PieceColor.black] = 20;
    const profile = CampaignAiProfile(
      aggression: 1,
      defense: .5,
      objectivePressure: 1,
      tileAppetite: .5,
    );
    final hitRandom = _FakeRandom(<double>[.099]);
    final hit = CampaignAi(seed: 1, random: hitRandom).chooseLivingOffer(
      controller: game,
      aiProfile: profile,
      attemptChance: .10,
    );
    expect(hit, isNotNull);
    expect(hitRandom.nextDoubleCalls, 1);

    final missRandom = _FakeRandom(<double>[.10]);
    final miss = CampaignAi(seed: 1, random: missRandom).chooseLivingOffer(
      controller: game,
      aiProfile: profile,
      attemptChance: .10,
    );
    expect(miss, isNull);
    expect(missRandom.nextDoubleCalls, 1);

    final consecutiveRandom = _FakeRandom(<double>[.01, .02]);
    final consecutiveAi = CampaignAi(seed: 1, random: consecutiveRandom);
    expect(
      consecutiveAi.chooseLivingOffer(
        controller: game,
        aiProfile: profile,
        attemptChance: .10,
      ),
      isNotNull,
    );
    expect(
      consecutiveAi.chooseLivingOffer(
        controller: game,
        aiProfile: profile,
        attemptChance: .10,
      ),
      isNotNull,
    );
    expect(consecutiveRandom.nextDoubleCalls, 2);

    final disabledRandom = _FakeRandom(<double>[.01]);
    game.economyEnabled = false;
    expect(
      CampaignAi(seed: 1, random: disabledRandom).chooseLivingOffer(
        controller: game,
        aiProfile: profile,
        attemptChance: .10,
      ),
      isNull,
    );
    expect(disabledRandom.nextDoubleCalls, 0);
    game.economyEnabled = true;

    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final piece = game.board[row][col];
        if (piece?.color == PieceColor.white && piece?.type != PieceType.king) {
          game.board[row][col] = null;
        }
      }
    }
    final noPlanRandom = _FakeRandom(<double>[.01]);
    final noPlan = CampaignAi(seed: 1, random: noPlanRandom).chooseLivingOffer(
      controller: game,
      aiProfile: profile,
      attemptChance: .10,
    );
    expect(noPlan, isNull);
    expect(noPlanRandom.nextDoubleCalls, 0);
  });

  test('campaign AI chooses only a legal purchased-piece redeployment', () {
    final game = GameController();
    addTearDown(game.dispose);
    game.startNewGame();
    game.turn = PieceColor.black;
    game.completedActionCount = 3;
    game.gold[PieceColor.black] = 20;
    const profile = CampaignAiProfile(
      aggression: 1,
      defense: .5,
      objectivePressure: 1,
      tileAppetite: .5,
    );
    final ai = CampaignAi(seed: 0);
    final offer = ai.chooseConfiguredOffer(
      controller: game,
      aiProfile: profile,
    )!;
    game.pieceAt(offer.target)!.loyalty = 0;
    game.selectedSquare = offer.target;
    game.openOfferForSelected();
    game.setOfferGold(offer.gold);
    game.confirmOffer();
    game.dismissLastOfferResult();

    final destination = ai.chooseConfiguredRedeploy(
      controller: game,
      aiProfile: profile,
    );

    expect(game.phase, GamePhase.redeploy);
    expect(destination, isNotNull);
    expect(game.isLegalRedeploy(destination!), isTrue);
  });

  test(
    'player checkmate takes priority over the M04 check dialogue trigger',
    () async {
      final game = GameController();
      final story = StoryCampaignController(
        gameController: game,
        catalog: catalog,
        profileRepository: CampaignProfileRepository(
          store: _MemoryCampaignProfileStore(null),
        ),
      );
      await story.initialize();
      _unlockAndStart(story, 'm04');
      _prepareWhiteMateInOne(game);

      final move = game
          .legalMovesFrom(const Square(2, 1))
          .singleWhere((candidate) => candidate.to == const Square(1, 1));
      game.makeMove(move);
      expect(game.gameEndReason, GameEndReason.checkmate);
      expect(game.winner, PieceColor.white);

      story.evaluateAfterPresentation();

      expect(story.phase, StoryCampaignPhase.dialogue);
      expect(story.activeScene?.id, 'm04_victory');
      expect(story.missionSucceeded, isTrue);
      story.dispose();
      game.dispose();
    },
  );

  test('story stalemate skips the blocked side instead of failing', () async {
    final game = GameController();
    final story = StoryCampaignController(
      gameController: game,
      catalog: catalog,
      profileRepository: CampaignProfileRepository(
        store: _MemoryCampaignProfileStore(null),
      ),
    );
    await story.initialize();
    _unlockAndStart(story, 'm02');
    _prepareBlackStalemate(game);

    story.evaluateAfterPresentation();

    expect(story.phase, StoryCampaignPhase.battle);
    expect(story.missionSucceeded, isFalse);
    expect(game.phase, GamePhase.playing);
    expect(game.gameEndReason, GameEndReason.none);
    expect(game.stalemate, isFalse);
    expect(game.turn, PieceColor.white);
    expect(story.lastSkippedTurnColor, PieceColor.black);
    expect(story.turnSkipNotice, 'Iron Duchy has no legal move. Turn skipped.');
    expect(game.eventLog.first, contains('Black has no legal move'));
    story.dispose();
    game.dispose();
  });

  test('enemy checkmate still opens the authored defeat scene', () async {
    final game = GameController();
    final story = StoryCampaignController(
      gameController: game,
      catalog: catalog,
      profileRepository: CampaignProfileRepository(
        store: _MemoryCampaignProfileStore(null),
      ),
    );
    await story.initialize();
    _unlockAndStart(story, 'm02');
    game
      ..phase = GamePhase.gameOver
      ..turn = PieceColor.white
      ..winner = PieceColor.black
      ..stalemate = false
      ..gameEndReason = GameEndReason.checkmate;

    story.evaluateAfterPresentation();

    expect(story.activeScene?.id, 'm02_defeat');
    expect(story.missionSucceeded, isFalse);
    story.dispose();
    game.dispose();
  });

  for (final missionId in const <String>[
    'm01',
    'm02',
    'm03',
    'm04',
    'm05',
    'm06',
    'm07',
  ]) {
    test('$missionId player checkmate opens its victory scene', () async {
      final game = GameController();
      final story = StoryCampaignController(
        gameController: game,
        catalog: catalog,
        profileRepository: CampaignProfileRepository(
          store: _MemoryCampaignProfileStore(null),
        ),
      );
      await story.initialize();
      _unlockAndStart(story, missionId);
      game
        ..phase = GamePhase.gameOver
        ..turn = PieceColor.black
        ..winner = PieceColor.white
        ..stalemate = false
        ..gameEndReason = GameEndReason.checkmate;

      story.evaluateAfterPresentation();

      expect(story.activeScene?.id, '${missionId}_victory');
      expect(story.missionSucceeded, isTrue);
      story.dispose();
      game.dispose();
    });
  }

  test('campaign AI no-move state is passed before AI selection', () async {
    final game = GameController();
    final story = StoryCampaignController(
      gameController: game,
      catalog: catalog,
      profileRepository: CampaignProfileRepository(
        store: _MemoryCampaignProfileStore(null),
      ),
    );
    await story.initialize();
    _unlockAndStart(story, 'm02');
    _prepareBlackStalemate(game);
    game
      ..phase = GamePhase.playing
      ..stalemate = false
      ..gameEndReason = GameEndReason.none;

    story.evaluateAfterPresentation();

    expect(game.turn, PieceColor.white);
    expect(game.phase, GamePhase.playing);
    expect(story.lastSkippedTurnColor, PieceColor.black);
    expect(story.isAiThinking, isFalse);
    story.dispose();
    game.dispose();
  });

  test(
    'two fully blocked courts stop safely instead of pass-looping',
    () async {
      final game = GameController();
      final story = StoryCampaignController(
        gameController: game,
        catalog: catalog,
        profileRepository: CampaignProfileRepository(
          store: _MemoryCampaignProfileStore(null),
        ),
        turnSkipNoticeDuration: Duration.zero,
      );
      await story.initialize();
      _unlockAndStart(story, 'm02');
      _clearBoard(game);
      game
        ..turn = PieceColor.black
        ..phase = GamePhase.playing
        ..winner = null
        ..stalemate = false
        ..gameEndReason = GameEndReason.none;

      story.evaluateAfterPresentation();
      await Future<void>.delayed(Duration.zero);
      story.evaluateAfterPresentation();
      await Future<void>.delayed(Duration.zero);
      story.evaluateAfterPresentation();

      expect(story.noMovePositionLocked, isTrue);
      expect(
        story.turnSkipNotice,
        'Both courts have no legal move. Return to the Campaign Map and retry.',
      );
      expect(story.phase, StoryCampaignPhase.battle);
      story.dispose();
      game.dispose();
    },
  );
}

void _finishDialogue(StoryCampaignController controller) {
  final count = controller.activeScene!.lines.length;
  for (var index = 0; index < count; index++) {
    controller.advanceDialogue();
  }
}

void _unlockAndStart(StoryCampaignController controller, String missionId) {
  controller.profile.unlockedMissionIds.add(missionId);
  controller.selectMission(missionId);
  controller.startSelectedMission();
  _finishDialogue(controller);
}

void _prepareWhiteMateInOne(GameController controller) {
  _clearBoard(controller);
  controller
    ..turn = PieceColor.white
    ..turnCount = 1
    ..phase = GamePhase.playing
    ..winner = null
    ..stalemate = false
    ..gameEndReason = GameEndReason.none;
  controller.board[2][2] = _piece(
    id: 'white-king',
    type: PieceType.king,
    color: PieceColor.white,
  ); // c6
  controller.board[2][1] = _piece(
    id: 'white-queen',
    type: PieceType.queen,
    color: PieceColor.white,
  ); // b6
  controller.board[0][0] = _piece(
    id: 'black-king',
    type: PieceType.king,
    color: PieceColor.black,
  ); // a8
}

void _prepareBlackStalemate(GameController controller) {
  _clearBoard(controller);
  controller
    ..turn = PieceColor.black
    ..turnCount = 2
    ..phase = GamePhase.gameOver
    ..winner = null
    ..stalemate = true
    ..gameEndReason = GameEndReason.stalemate;
  controller.board[0][0] = _piece(
    id: 'black-king',
    type: PieceType.king,
    color: PieceColor.black,
  ); // a8
  controller.board[2][2] = _piece(
    id: 'white-king',
    type: PieceType.king,
    color: PieceColor.white,
  ); // c6
  controller.board[1][2] = _piece(
    id: 'white-queen',
    type: PieceType.queen,
    color: PieceColor.white,
  ); // c7
}

void _clearBoard(GameController controller) {
  for (var row = 0; row < 8; row++) {
    for (var col = 0; col < 8; col++) {
      controller.board[row][col] = null;
    }
  }
}

ChessPiece _piece({
  required String id,
  required PieceType type,
  required PieceColor color,
}) {
  return ChessPiece(
    id: id,
    type: type,
    color: color,
    countryId: color == PieceColor.white ? 'mercantile' : 'iron',
    loyalty: 100,
    fairPrice: type == PieceType.king ? null : 20,
  );
}

class _MemoryCampaignProfileStore implements CampaignProfileStore {
  _MemoryCampaignProfileStore(this.value);

  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}

class _FakeRandom implements math.Random {
  _FakeRandom(Iterable<double> doubles) : _doubles = doubles.toList();

  final List<double> _doubles;
  int nextDoubleCalls = 0;

  @override
  bool nextBool() => false;

  @override
  double nextDouble() {
    final value = _doubles[nextDoubleCalls];
    nextDoubleCalls++;
    return value;
  }

  @override
  int nextInt(int max) => 0;
}
