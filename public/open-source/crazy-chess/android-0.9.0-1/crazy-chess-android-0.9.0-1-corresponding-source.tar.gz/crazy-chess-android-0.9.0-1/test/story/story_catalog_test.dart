import 'dart:convert';
import 'dart:io';

import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/story/story_catalog.dart';
import 'package:crazy_chess/story/story_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  late String source;
  late StoryCatalog catalog;

  setUpAll(() {
    source = File(StoryCatalog.assetPath).readAsStringSync();
    catalog = StoryCatalog.fromJsonString(source);
  });

  test('loads the complete seven-mission authored campaign', () {
    expect(catalog.campaign.schemaVersion, 1);
    expect(catalog.campaign.missions.map((mission) => mission.id), <String>[
      'm01',
      'm02',
      'm03',
      'm04',
      'm05',
      'm06',
      'm07',
    ]);
    expect(
      catalog.campaign.scenes
          .expand((scene) => scene.lines)
          .map((line) => line.id)
          .toSet()
          .length,
      196,
    );
    expect(catalog.validate(), isEmpty);
  });

  test('keeps Rowan as the single player King in every mission', () {
    for (final mission in catalog.campaign.missions) {
      final kings = mission.pieces.where(
        (piece) =>
            piece.color == PieceColor.white && piece.type == PieceType.king,
      );
      expect(kings, hasLength(1), reason: mission.id);
      expect(kings.single.characterId, 'king_rowan', reason: mission.id);
    }
  });

  test('uses the escape objective once and checkmate six times', () {
    expect(
      catalog.campaign.missions
          .where(
            (mission) =>
                mission.objective.type == StoryObjectiveType.reachSquare,
          )
          .length,
      1,
    );
    expect(
      catalog.campaign.missions
          .where(
            (mission) => mission.objective.type == StoryObjectiveType.checkmate,
          )
          .length,
      6,
    );
  });

  test('publishes explicit primary and alternate victory conditions', () {
    final m01 = catalog.campaign.missionById('m01');
    final m02 = catalog.campaign.missionById('m02');

    expect(m01.primaryVictoryCondition, 'Reach a4 with King Rowan');
    expect(m01.alternateVictoryCondition, 'Checkmate the enemy King');
    expect(m01.victoryConditions, <String>[
      'Reach a4 with King Rowan',
      'Checkmate the enemy King',
    ]);
    expect(m02.primaryVictoryCondition, 'Checkmate the enemy King');
    expect(m02.alternateVictoryCondition, isNull);
    expect(m02.victoryConditions, <String>['Checkmate the enemy King']);
  });

  test('rejects duplicate stable IDs', () {
    final decoded = jsonDecode(source) as Map<String, Object?>;
    final missions = decoded['missions']! as List<Object?>;
    final second = missions[1]! as Map<String, Object?>;
    second['id'] = 'm01';
    expect(
      () => StoryCatalog.fromJsonString(jsonEncode(decoded)),
      throwsA(isA<StoryCatalogException>()),
    );
  });
}
