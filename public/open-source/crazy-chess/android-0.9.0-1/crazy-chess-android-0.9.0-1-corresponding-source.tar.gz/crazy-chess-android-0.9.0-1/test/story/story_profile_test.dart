import 'package:crazy_chess/story/story_profile.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('fresh profile unlocks only m01 and always recruits Rowan', () {
    final profile = CampaignProfile.fresh();
    expect(profile.unlockedMissionIds, <String>{'m01'});
    expect(profile.completedMissionIds, isEmpty);
    expect(profile.recruitedCharacterIds, contains('king_rowan'));
  });

  test('repository falls back safely when persisted JSON is corrupt', () async {
    final store = _MemoryCampaignProfileStore('{bad json');
    final repository = CampaignProfileRepository(store: store);
    final profile = await repository.load();
    expect(profile.unlockedMissionIds, <String>{'m01'});
    expect(profile.lastSelectedNode, 'm01');
  });

  test('profile round trips mission and seen-scene progress', () async {
    final store = _MemoryCampaignProfileStore(null);
    final repository = CampaignProfileRepository(store: store);
    final profile = CampaignProfile.fresh()
      ..unlockedMissionIds.add('m02')
      ..completedMissionIds.add('m01')
      ..recruitedCharacterIds.add('captain_mara')
      ..seenSceneIds.add('m01_pre')
      ..lastSelectedNode = 'm02';
    await repository.save(profile);
    final restored = await repository.load();
    expect(restored.unlockedMissionIds, containsAll(<String>['m01', 'm02']));
    expect(restored.completedMissionIds, contains('m01'));
    expect(restored.recruitedCharacterIds, contains('captain_mara'));
    expect(restored.seenSceneIds, contains('m01_pre'));
    expect(restored.lastSelectedNode, 'm02');
  });
}

class _MemoryCampaignProfileStore implements CampaignProfileStore {
  _MemoryCampaignProfileStore(this.value);

  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}
