import 'dart:async';

import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter/foundation.dart';

class FakeChessEngine implements ChessEngine {
  FakeChessEngine({this.defaultMove = 'e7e5'});

  final String defaultMove;
  final ValueNotifier<EngineStatus> _status = ValueNotifier(
    EngineStatus.unavailable,
  );
  final StreamController<String> _logs = StreamController<String>.broadcast();
  final List<EngineMoveRequest> requests = <EngineMoveRequest>[];

  Future<EngineMove> Function(EngineMoveRequest request)? onBestMove;
  Future<void> Function()? onInitialize;
  Object? initializeError;
  int initializeCalls = 0;
  int newGameCalls = 0;
  int stopCalls = 0;
  int shutdownCalls = 0;
  bool disposed = false;

  @override
  String? get lastError => initializeError?.toString();

  @override
  Stream<String> get logs => _logs.stream;

  @override
  ValueListenable<EngineStatus> get status => _status;

  @override
  Future<void> initialize() async {
    initializeCalls++;
    _status.value = EngineStatus.starting;
    try {
      await onInitialize?.call();
      final error = initializeError;
      if (error != null) {
        throw error;
      }
      _status.value = EngineStatus.ready;
    } catch (_) {
      _status.value = EngineStatus.failed;
      rethrow;
    }
  }

  @override
  Future<void> newGame() async {
    newGameCalls++;
    await initialize();
  }

  @override
  Future<EngineMove> bestMove(EngineMoveRequest request) async {
    requests.add(request);
    _status.value = EngineStatus.thinking;
    try {
      final responder = onBestMove;
      final move = responder == null
          ? EngineMove(uci: defaultMove)
          : await responder(request);
      _status.value = EngineStatus.ready;
      return move;
    } catch (_) {
      _status.value = EngineStatus.failed;
      rethrow;
    }
  }

  @override
  Future<void> stop() async {
    stopCalls++;
  }

  @override
  Future<void> shutdown() async {
    shutdownCalls++;
    _status.value = EngineStatus.unavailable;
  }

  @override
  Future<void> dispose() async {
    if (disposed) {
      return;
    }
    disposed = true;
    await _logs.close();
    _status.dispose();
  }
}
