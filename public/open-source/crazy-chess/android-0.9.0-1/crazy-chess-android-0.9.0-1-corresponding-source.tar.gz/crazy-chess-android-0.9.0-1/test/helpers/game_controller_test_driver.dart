import 'package:crazy_chess/crazy_chess.dart';

class GameControllerTestDriver {
  GameControllerTestDriver(this.controller);

  final GameController controller;

  void startGame({
    String? whiteCountry,
    String? blackCountry,
    int? merchantSpeed,
  }) {
    if (whiteCountry != null) {
      controller.setupWhiteCountryId = whiteCountry;
    }
    if (blackCountry != null) {
      controller.setupBlackCountryId = blackCountry;
    }
    if (merchantSpeed != null) {
      controller.setupMerchantSpeed = merchantSpeed;
    }
    controller.startNewGame();
  }

  void move(String from, String to) {
    final fromSquare = controller.parseSquare(from);
    final toSquare = controller.parseSquare(to);
    if (fromSquare == null || toSquare == null) {
      throw ArgumentError('Invalid move coordinates: $from to $to');
    }
    controller.selectedSquare = fromSquare;
    final move = controller.selectedLegalMoves.firstWhere(
      (candidate) => candidate.to == toSquare,
      orElse: () => throw StateError('No legal move from $from to $to'),
    );
    controller.makeMove(move);
  }

  void promoteToQueen() {
    controller.choosePromotion(PieceType.queen);
  }

  void redeployFirst() {
    final squares = controller.legalRedeploySquares();
    if (squares.isNotEmpty) {
      controller.placeRedeploy(squares.first);
    }
  }

  void foolsMate() {
    startGame();
    move('f2', 'f3');
    move('e7', 'e5');
    move('g2', 'g4');
    move('d8', 'h4');
  }

  Map<String, Object?> snapshot() {
    final pieces = <Map<String, Object?>>[];
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final piece = controller.board[row][col];
        if (piece != null) {
          pieces.add({
            'square': controller.squareName(Square(row, col)),
            'type': piece.type.name,
            'color': piece.color.name,
            'country': piece.countryId,
            'personality': piece.personalityId,
            'revealed': controller.isPieceRevealed(piece),
          });
        }
      }
    }
    return {
      'phase': controller.phase.name,
      'turn': controller.turn.name,
      'gold': {
        'white': controller.gold[PieceColor.white],
        'black': controller.gold[PieceColor.black],
      },
      'merchant': {
        'position': controller.merchantPosition,
        'direction': controller.merchantDirection,
        'speed': controller.merchantSpeed,
      },
      'inCheck': controller.phase == GamePhase.playing
          ? controller.isKingInCheck(controller.turn)
          : false,
      'winner': controller.winner?.name,
      'stalemate': controller.stalemate,
      'gameEndReason': controller.resolvedGameEndReason.name,
      'purchaseSuccesses': controller.purchaseSuccesses,
      'purchaseFailures': controller.purchaseFailures,
      'pieces': pieces,
      'events': controller.eventLog.take(8).toList(),
    };
  }
}
