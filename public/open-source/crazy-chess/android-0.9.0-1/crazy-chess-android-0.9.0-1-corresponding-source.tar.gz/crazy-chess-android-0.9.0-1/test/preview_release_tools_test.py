from __future__ import annotations

from pathlib import Path
import platform
import tempfile
import unittest
import zipfile

from utils.preview_release_common import (
    PreviewReleaseError,
    assert_archive_has_no_forbidden_files,
    init_config,
    require_platform,
    require_single_file,
    validate_preview_config,
)


class PreviewReleaseToolsTest(unittest.TestCase):
    def test_blank_preview_key_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            config = Path(temporary) / ".env.preview"
            config.write_text(
                "CRAZY_CHESS_PREVIEW_BUILD=true\n"
                "CRAZY_CHESS_PREVIEW_LABEL=Preview 1\n"
                "ARK_API_KEY=\n"
                "ARK_BASE_URL=https://ark.example/api/v3\n"
                "LIVING_CAMPAIGN_TEXT_MODEL=text-model\n"
                "LIVING_CAMPAIGN_IMAGE_MODEL=image-model\n",
                encoding="utf-8",
            )

            with self.assertRaisesRegex(PreviewReleaseError, "ARK_API_KEY is empty"):
                validate_preview_config(config)

    def test_init_never_overwrites_existing_preview_key(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            example = root / ".env.preview.example"
            destination = root / ".env.preview"
            example.write_text("ARK_API_KEY=\n", encoding="utf-8")
            destination.write_text("ARK_API_KEY=keep-this-key\n", encoding="utf-8")

            init_config(example, destination)

            self.assertEqual(
                destination.read_text(encoding="utf-8"),
                "ARK_API_KEY=keep-this-key\n",
            )

    def test_forbidden_files_inside_zip_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            archive = Path(temporary) / "app.apk"
            with zipfile.ZipFile(archive, "w") as packaged:
                packaged.writestr("lib/arm64-v8a/libapp.so", b"ok")
                packaged.writestr(".env.preview", "ARK_API_KEY=secret\n")

            with self.assertRaisesRegex(PreviewReleaseError, "Forbidden files"):
                assert_archive_has_no_forbidden_files(archive)

    def test_require_single_file_finds_only_one_match(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            (directory / "Runner.ipa").write_bytes(b"ipa")
            (directory / "notes.txt").write_text("ignore", encoding="utf-8")

            self.assertEqual(
                require_single_file(directory, "*.ipa", "release IPA").name,
                "Runner.ipa",
            )

            (directory / "Extra.ipa").write_bytes(b"ipa")
            with self.assertRaisesRegex(PreviewReleaseError, "Expected one"):
                require_single_file(directory, "*.ipa", "release IPA")

    def test_windows_runner_disables_impeller_for_release_packages(self) -> None:
        source = (
            Path(__file__).resolve().parents[1] / "windows" / "runner" / "main.cpp"
        )
        text = source.read_text(encoding="utf-8")
        self.assertIn("set_impeller_switch", text)
        self.assertIn("ImpellerSwitch::Disabled", text)

    def test_mobile_platform_checks_accept_this_host(self) -> None:
        require_platform("android")
        if platform.system().lower() == "darwin":
            require_platform("ios")


if __name__ == "__main__":
    unittest.main()
