import 'package:crazy_chess/domain/board_presentation.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/domain/countries.dart';
import 'package:crazy_chess/ui/board/board_presentation_layers.dart';
import 'package:crazy_chess/ui/board/piece_token.dart';
import 'package:crazy_chess/ui/shared/piece_art.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

ChessPiece _piece({
  required String id,
  required PieceType type,
  required PieceColor color,
  String countryId = 'mercantile',
}) {
  return ChessPiece(
    id: id,
    type: type,
    color: color,
    countryId: countryId,
    loyalty: 50,
    fairPrice: 100,
  );
}

PresentedPiece _presented({
  required String id,
  required PieceType type,
  required PieceColor color,
  String countryId = 'mercantile',
}) {
  return PresentedPiece.fromPiece(
    _piece(id: id, type: type, color: color, countryId: countryId),
  );
}

Widget _tokens(Widget child) {
  return MaterialApp(
    home: Scaffold(
      body: Center(child: SizedBox(width: 640, height: 640, child: child)),
    ),
  );
}

void main() {
  test(
    'all Mercantile roles resolve by PieceColor with original fallbacks',
    () {
      for (final type in PieceType.values) {
        final white = PieceArtResolver.resolve(
          countryId: 'mercantile',
          type: type,
          color: PieceColor.white,
        );
        final black = PieceArtResolver.resolve(
          countryId: 'mercantile',
          type: type,
          color: PieceColor.black,
        );

        expect(
          white.boardTokenAsset,
          '$mercantileSideLiveryRoot/white/mercantile_${type.name}_token.webp',
        );
        expect(
          black.boardTokenAsset,
          '$mercantileSideLiveryRoot/black/mercantile_${type.name}_token.webp',
        );
        expect(white.boardTokenAsset, isNot(black.boardTokenAsset));
        expect(white.boardTokenFallbackAsset, isNotNull);
        expect(black.boardTokenFallbackAsset, white.boardTokenFallbackAsset);
        expect(white.portraitAsset, black.portraitAsset);
      }
    },
  );

  test('all Ashen roles resolve by PieceColor with original fallbacks', () {
    for (final type in PieceType.values) {
      final white = PieceArtResolver.resolve(
        countryId: 'ashen',
        type: type,
        color: PieceColor.white,
      );
      final black = PieceArtResolver.resolve(
        countryId: 'ashen',
        type: type,
        color: PieceColor.black,
      );

      expect(
        white.boardTokenAsset,
        '$ashenSideLiveryRoot/white/ashen_${type.name}_token.webp',
      );
      expect(
        black.boardTokenAsset,
        '$ashenSideLiveryRoot/black/ashen_${type.name}_token.webp',
      );
      expect(white.boardTokenAsset, isNot(black.boardTokenAsset));
      expect(white.boardTokenFallbackAsset, isNotNull);
      expect(black.boardTokenFallbackAsset, white.boardTokenFallbackAsset);
      expect(white.portraitAsset, black.portraitAsset);
    }
  });

  test('other countries retain side-neutral board art', () {
    for (final countryId in const [
      'iron',
      'horse',
      'spy',
      'corsair',
      'sunlit',
    ]) {
      for (final type in PieceType.values) {
        final white = PieceArtResolver.resolve(
          countryId: countryId,
          type: type,
          color: PieceColor.white,
        );
        final black = PieceArtResolver.resolve(
          countryId: countryId,
          type: type,
          color: PieceColor.black,
        );
        expect(white.boardTokenAsset, black.boardTokenAsset);
        expect(white.boardTokenFallbackAsset, isNull);
        expect(black.boardTokenFallbackAsset, isNull);
      }
    }
  });

  testWidgets(
    'shared board token keeps universal side medallions for every country and role',
    (tester) async {
      for (final countryId in countries.keys) {
        for (final type in PieceType.values) {
          await tester.pumpWidget(
            _tokens(
              Row(
                children: [
                  Expanded(
                    child: PieceToken(
                      piece: _piece(
                        id: '$countryId-${type.name}-white',
                        type: type,
                        color: PieceColor.white,
                        countryId: countryId,
                      ),
                      checked: false,
                    ),
                  ),
                  Expanded(
                    child: PieceToken(
                      piece: _piece(
                        id: '$countryId-${type.name}-black',
                        type: type,
                        color: PieceColor.black,
                        countryId: countryId,
                      ),
                      checked: false,
                    ),
                  ),
                ],
              ),
            ),
          );
          await tester.pump();

          expect(
            find.byKey(ValueKey('piece-role-badge-white-${type.name}')),
            findsOneWidget,
            reason: '$countryId ${type.name} White',
          );
          expect(
            find.byKey(ValueKey('piece-role-badge-black-${type.name}')),
            findsOneWidget,
            reason: '$countryId ${type.name} Black',
          );
          expect(
            tester
                .widget<Text>(
                  find.byKey(ValueKey('piece-role-glyph-white-${type.name}')),
                )
                .data,
            isNot(
              tester
                  .widget<Text>(
                    find.byKey(ValueKey('piece-role-glyph-black-${type.name}')),
                  )
                  .data,
            ),
            reason: '$countryId ${type.name} side glyphs',
          );
        }
      }
    },
  );

  testWidgets('token keys, medallions, glyphs, and semantics expose side', (
    tester,
  ) async {
    final semantics = tester.ensureSemantics();
    await tester.pumpWidget(
      _tokens(
        Row(
          children: [
            Expanded(
              child: PieceToken(
                piece: _piece(
                  id: 'white-pawn',
                  type: PieceType.pawn,
                  color: PieceColor.white,
                ),
                checked: false,
              ),
            ),
            Expanded(
              child: PieceToken(
                piece: _piece(
                  id: 'black-pawn',
                  type: PieceType.pawn,
                  color: PieceColor.black,
                ),
                checked: false,
              ),
            ),
          ],
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('piece-art-token-mercantile_pawn-white')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('piece-art-token-mercantile_pawn-black')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('piece-role-badge-white-pawn')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('piece-role-badge-black-pawn')),
      findsOneWidget,
    );
    expect(
      tester
          .widget<Text>(
            find.byKey(const ValueKey('piece-role-glyph-white-pawn')),
          )
          .data,
      '♙',
    );
    expect(
      tester
          .widget<Text>(
            find.byKey(const ValueKey('piece-role-glyph-black-pawn')),
          )
          .data,
      '♟',
    );
    expect(
      find.bySemanticsLabel(RegExp('^White pawn role medallion')),
      findsOneWidget,
    );
    expect(
      find.bySemanticsLabel(RegExp('^Black pawn role medallion')),
      findsOneWidget,
    );
    expect(find.bySemanticsLabel('White Mercantile pawn'), findsOneWidget);
    expect(find.bySemanticsLabel('Black Mercantile pawn'), findsOneWidget);
    semantics.dispose();
  });

  testWidgets('move and redeploy layers keep the moving piece side key', (
    tester,
  ) async {
    for (final kind in [BoardMotionKind.chessMove, BoardMotionKind.redeploy]) {
      await tester.pumpWidget(
        _tokens(
          Stack(
            children: [
              BoardMotionLayer(
                event: BoardMotionEvent(
                  serial: kind.index + 1,
                  kind: kind,
                  motions: [
                    PieceMotion(
                      piece: _presented(
                        id: 'moving-${kind.name}',
                        type: PieceType.rook,
                        color: PieceColor.black,
                      ),
                      from: const Square(7, 0),
                      to: const Square(4, 0),
                    ),
                  ],
                ),
                boardSize: const Size.square(640),
                duration: Duration.zero,
              ),
            ],
          ),
        ),
      );
      await tester.pump();
      expect(
        find.byKey(const ValueKey('piece-art-token-mercantile_rook-black')),
        findsOneWidget,
        reason: kind.name,
      );
    }
  });

  testWidgets('promotion keeps White side while changing the role key', (
    tester,
  ) async {
    await tester.pumpWidget(
      _tokens(
        Stack(
          children: [
            BoardPieceTransformLayer(
              serial: 1,
              square: const Square(0, 0),
              before: _presented(
                id: 'promoting',
                type: PieceType.pawn,
                color: PieceColor.white,
              ),
              after: _presented(
                id: 'promoting',
                type: PieceType.queen,
                color: PieceColor.white,
              ),
              boardSize: const Size.square(640),
              duration: Duration.zero,
              accent: Colors.amber,
              semanticLabel: 'White Mercantile promotion',
            ),
          ],
        ),
      ),
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey('piece-art-token-mercantile_pawn-white')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('piece-art-token-mercantile_queen-white')),
      findsOneWidget,
    );
  });

  testWidgets('Mercantile betrayal crossfades Black to White livery keys', (
    tester,
  ) async {
    await tester.pumpWidget(
      _tokens(
        Stack(
          children: [
            BoardPieceTransformLayer(
              serial: 2,
              square: const Square(3, 3),
              before: _presented(
                id: 'betrayer',
                type: PieceType.bishop,
                color: PieceColor.black,
              ),
              after: _presented(
                id: 'betrayer',
                type: PieceType.bishop,
                color: PieceColor.white,
              ),
              boardSize: const Size.square(640),
              duration: const Duration(milliseconds: 240),
              accent: Colors.teal,
              semanticLabel: 'Mercantile betrayal changes Black to White',
            ),
          ],
        ),
      ),
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey('piece-art-token-mercantile_bishop-black')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('piece-art-token-mercantile_bishop-white')),
      findsOneWidget,
    );
  });

  testWidgets('Ashen betrayal crossfades Black to White livery keys', (
    tester,
  ) async {
    await tester.pumpWidget(
      _tokens(
        Stack(
          children: [
            BoardPieceTransformLayer(
              serial: 3,
              square: const Square(3, 3),
              before: _presented(
                id: 'ashen-betrayer',
                type: PieceType.bishop,
                color: PieceColor.black,
                countryId: 'ashen',
              ),
              after: _presented(
                id: 'ashen-betrayer',
                type: PieceType.bishop,
                color: PieceColor.white,
                countryId: 'ashen',
              ),
              boardSize: const Size.square(640),
              duration: const Duration(milliseconds: 240),
              accent: Colors.deepOrange,
              semanticLabel: 'Ashen betrayal changes Black to White',
            ),
          ],
        ),
      ),
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey('piece-art-token-shared_bishop-black')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('piece-art-token-shared_bishop-white')),
      findsOneWidget,
    );
  });
}
