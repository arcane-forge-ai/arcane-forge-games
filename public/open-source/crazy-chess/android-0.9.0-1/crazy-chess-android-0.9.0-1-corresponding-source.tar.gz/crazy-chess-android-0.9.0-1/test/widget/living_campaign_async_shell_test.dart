import 'dart:async';
import 'dart:typed_data';

import 'package:crazy_chess/app/crazy_chess_shell.dart';
import 'package:crazy_chess/app/responsive_game_viewport.dart';
import 'package:crazy_chess/app/theme.dart';
import 'package:crazy_chess/ai/chess_engine.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/game/game_controller.dart';
import 'package:crazy_chess/living_campaign/living_campaign_archive_store.dart';
import 'package:crazy_chess/living_campaign/living_campaign_controller.dart';
import 'package:crazy_chess/living_campaign/living_campaign_fixed_opener.dart';
import 'package:crazy_chess/living_campaign/living_campaign_generation_service.dart';
import 'package:crazy_chess/living_campaign/living_campaign_metrics.dart';
import 'package:crazy_chess/living_campaign/living_campaign_models.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:crazy_chess/living_campaign/living_campaign_v2_backend.dart';
import 'package:crazy_chess/ui/living_campaign/living_campaign_screens.dart';
import 'package:crazy_chess/ui/match/match_screen.dart';
import 'package:crazy_chess/ui/menu/menu_flow_screens.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../helpers/game_controller_test_driver.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('Living Campaign music routes every presentation phase', () {
    expect(
      livingCampaignMusicCueForPhase(LivingCampaignPhase.hub),
      'living_entry_hub',
    );
    expect(
      livingCampaignMusicCueForPhase(LivingCampaignPhase.dialogue),
      'living_story_briefing',
    );
    expect(
      livingCampaignMusicCueForPhase(LivingCampaignPhase.battle),
      'living_battle',
    );
    for (final phase in <LivingCampaignPhase>[
      LivingCampaignPhase.outcomeAcknowledgement,
      LivingCampaignPhase.chapterArtLoading,
      LivingCampaignPhase.chapterEnding,
    ]) {
      expect(
        livingCampaignMusicCueForPhase(
          phase,
          result: LivingBattleResult.victory,
        ),
        'living_victory_result',
      );
      expect(
        livingCampaignMusicCueForPhase(
          phase,
          result: LivingBattleResult.defeat,
        ),
        'living_defeat_result',
      );
    }
  });

  for (final size in <Size>[const Size(1600, 900), const Size(1280, 720)]) {
    testWidgets('global status, mode badge, and deferred notice work at '
        '${size.width.toInt()}x${size.height.toInt()}', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      await tester.binding.setSurfaceSize(size);
      addTearDown(() => tester.binding.setSurfaceSize(null));
      final archive = _MemoryArchiveStore();
      final generation = Completer<LivingGenerationResult>();
      LivingCampaignRun? requestedRun;
      final now = DateTime.utc(2026, 8, 9, 3);
      final committed = _committedRun(runId: 'async-shell', now: now);
      archive.runs[committed.runId] = committed.copyWith(
        generationJob: LivingGenerationJob(
          jobId: 'interrupted-chronicler',
          stage: LivingGenerationStage.chronicler,
          status: LivingGenerationStatus.awaitingResume,
          attempt: 1,
          createdAt: now,
          updatedAt: now,
        ),
      );
      expect(archive.runs, hasLength(1));

      await tester.pumpWidget(
        MaterialApp(
          theme: buildCrazyChessTheme(),
          home: CrazyChessShell(
            titleBackgroundAsset:
                'assets/runtime/ui/title/screen_s01_title_hall_bg_a.webp',
            livingCampaignArchive: archive,
            livingCampaignSettingsController: LivingCampaignSettingsController(
              developerEnvironment: const LivingDeveloperEnvironment(
                apiKey: 'widget-test-key',
              ),
            ),
            livingDemoEnabledOverride: true,
            livingPrologueGenerator: (run) async =>
                LivingGenerationResult(run: run, completed: false),
            livingNextChapterGenerator: (run, outcome) {
              requestedRun = run;
              return generation.future;
            },
          ),
        ),
      );
      await tester.pump();
      await tester.runAsync(
        () => archive.firstList.future.timeout(const Duration(seconds: 3)),
      );
      await tester.pump();

      await tester.tap(find.text('Press Start'));
      await tester.pumpAndSettle();
      expect(archive.runs, hasLength(1));
      await tester.tap(find.byKey(const ValueKey('s02-play')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('s03-living-campaign')));
      await tester.pump();
      await tester.tap(find.byKey(const ValueKey('s03-confirm')));
      await tester.pumpAndSettle();
      expect(find.text('ACTIVE RUN'), findsOneWidget);
      expect(find.text('Recall the Battle Again'), findsOneWidget);
      await tester.tap(find.byKey(const ValueKey('living-resume-generation')));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 50));

      expect(requestedRun, isNotNull);
      expect(
        find.byKey(const ValueKey('living-generation-progress-card')),
        findsOneWidget,
      );
      await tester.tap(find.byKey(const ValueKey('living-play-another-mode')));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 350));

      expect(find.byKey(const ValueKey('s03-confirm')), findsOneWidget);
      expect(
        find.byKey(const ValueKey('living-global-status-pill')),
        findsOneWidget,
      );
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('living-mode-status-badge')),
          matching: find.text('SCRIPTING'),
        ),
        findsOneWidget,
      );

      generation.complete(
        LivingGenerationResult(
          run: _completeWithGeneratedMission(requestedRun!),
          completed: true,
        ),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 350));

      expect(find.byKey(const ValueKey('s03-confirm')), findsOneWidget);
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('living-mode-status-badge')),
          matching: find.text('READY'),
        ),
        findsOneWidget,
      );
      expect(find.text('The next chapter is ready.'), findsOneWidget);
      expect(find.text('OPEN'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }

  testWidgets('active match header contains the minimal Story Director icon', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(1280, 720));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final archive = _MemoryArchiveStore();
    final game = GameController();
    final living = LivingCampaignController(
      gameController: game,
      archive: archive,
      generatePrologue: (run) async =>
          LivingGenerationResult(run: run, completed: false),
      generateNextChapter: (run, outcome) async =>
          LivingGenerationResult(run: run, completed: false),
    );
    await living.initialize();
    await living.startNewRun();
    GameControllerTestDriver(game).startGame();

    await tester.pumpWidget(
      MaterialApp(
        theme: buildCrazyChessTheme(),
        home: Scaffold(
          body: ResponsiveGameViewport(
            child: MatchScreen(
              controller: game,
              storyDirectorStatus: LivingCampaignStatusPill(
                controller: living,
                onPressed: () {},
                iconOnly: true,
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey('living-match-status-icon')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('s20-tilted-board')), findsOneWidget);
    final statusRect = tester.getRect(
      find.byKey(const ValueKey('living-match-status-icon')),
    );
    final boardRect = tester.getRect(
      find.byKey(const ValueKey('s20-tilted-board')),
    );
    expect(statusRect.overlaps(boardRect), isFalse);
    expect(tester.takeException(), isNull);

    await tester.pumpWidget(const SizedBox.shrink());
    living.dispose();
    game.dispose();
  });

  testWidgets('mode card renders the needs-attention state', (tester) async {
    await tester.binding.setSurfaceSize(const Size(1280, 720));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await tester.pumpWidget(
      MaterialApp(
        theme: buildCrazyChessTheme(),
        home: Scaffold(
          body: ResponsiveGameViewport(
            child: ModeSelectScreen(
              selectedMode: PlayMode.livingCampaign,
              aiAvailable: true,
              engineStatus: EngineStatus.ready,
              onModeChanged: (_) {},
              onBack: () {},
              onContinue: () {},
              livingCampaignStatus: 'NEEDS ATTENTION',
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(
      find.descendant(
        of: find.byKey(const ValueKey('living-mode-status-badge')),
        matching: find.text('NEEDS ATTENTION'),
      ),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
}

LivingCampaignRun _committedRun({
  required String runId,
  required DateTime now,
}) {
  final run = LivingCampaignFixedOpener.create(runId: runId, now: now);
  return const LivingCampaignOutcomeReducer().apply(
    run: run,
    outcome: LivingBattleOutcomeSnapshot(
      chapterNumber: 1,
      chapterId: 'living_m01',
      result: LivingBattleResult.victory,
      endReason: GameEndReason.checkmate,
      objectiveType: run.chapterPackages.first.objective.type,
      objectiveCompleted: true,
      completedTurns: 10,
      goldBefore: 10,
      goldAfterBattle: 12,
      survivingPieceIds: const <String>[
        'ashen_rook_ysra',
        'ashen_bishop_veyl',
        'ashen_king_orsain',
        'ashen_knight_cael',
      ],
      capturedPieces: const <LivingCapturedPieceOutcome>[],
      purchasedPieceIds: const <String>[],
      missionRoleChanges: const <String, PieceType>{},
      matchLog: const <String>['The Ashen Court secured the causeway.'],
    ),
    now: now,
  );
}

LivingCampaignRun _completeWithGeneratedMission(LivingCampaignRun run) {
  final json = Map<String, Object?>.from(run.chapterPackages.first.toJson())
    ..['basedOnRevision'] = run.canon.revision
    ..['chapterNumber'] = 2
    ..['chapterId'] = 'living_m02'
    ..['title'] = 'The Background Crown'
    ..['subtitle'] = 'The next mission is ready.'
    ..['briefing'] = 'Secure the crossing that remembers every army.';
  return run.copyWith(
    activeChapterNumber: 2,
    chapterPackages: <LivingChapterPackage>[
      ...run.chapterPackages,
      LivingChapterPackage.fromJson(json),
    ],
    clearGenerationJob: true,
    clearV2GenerationCheckpoint: true,
  );
}

class _MemoryArchiveStore implements LivingCampaignArchiveStore {
  final Map<String, LivingCampaignRun> runs = <String, LivingCampaignRun>{};
  final Map<String, LivingCampaignRunTimingMetrics> metrics =
      <String, LivingCampaignRunTimingMetrics>{};
  final Map<String, Uint8List> binaries = <String, Uint8List>{};
  final Completer<void> firstList = Completer<void>();

  @override
  Future<void> initialize() async {}

  @override
  Future<void> writeRun(LivingCampaignRun run) async {
    runs[run.runId] = run;
  }

  @override
  Future<LivingCampaignRun?> readRun(String runId) async => runs[runId];

  @override
  Future<void> writeTimingMetrics(LivingCampaignRunTimingMetrics value) async {
    metrics[value.runId] = value;
  }

  @override
  Future<LivingCampaignRunTimingMetrics?> readTimingMetrics(
    String runId,
  ) async => metrics[runId];

  @override
  Future<List<LivingRunArchiveSummary>> listRuns() async {
    if (!firstList.isCompleted) firstList.complete();
    return runs.values
        .map(
          (run) => LivingRunArchiveSummary(
            runId: run.runId,
            status: run.status,
            createdAt: run.createdAt,
            updatedAt: run.updatedAt,
            activeChapterNumber: run.activeChapterNumber,
            chapterCount: run.chapterPackages.length,
            byteSize: 1,
          ),
        )
        .toList(growable: false);
  }

  @override
  Future<void> deleteRun(String runId) async {
    runs.remove(runId);
    metrics.remove(runId);
  }

  @override
  Future<int> storageBytes() async => runs.length;

  @override
  Future<String> writeBinary({
    required String runId,
    required String fileName,
    required Uint8List bytes,
  }) async {
    final reference = 'memory://$runId/$fileName';
    binaries[reference] = bytes;
    return reference;
  }

  @override
  Future<Uint8List?> readBinary(String reference) async => binaries[reference];
}
