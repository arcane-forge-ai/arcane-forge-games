import 'package:crazy_chess/app/theme.dart';
import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/ui/match/match_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/game_controller_test_driver.dart';

Future<void> _setSurface(Size size) async {
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  await binding.setSurfaceSize(size);
  addTearDown(() => binding.setSurfaceSize(null));
}

Widget _match(
  GameController controller,
  BoardPresentationCoordinator presentation,
) {
  return MaterialApp(
    theme: buildCrazyChessTheme(),
    home: Scaffold(
      body: ResponsiveGameViewport(
        child: AnimatedBuilder(
          animation: Listenable.merge([controller, presentation]),
          builder: (context, _) => MatchScreen(
            controller: controller,
            presentationCoordinator: presentation,
          ),
        ),
      ),
    ),
  );
}

void main() {
  testWidgets('capture travels while target remains until impact', (
    tester,
  ) async {
    await _setSurface(const Size(1280, 720));
    final controller = GameController();
    final driver = GameControllerTestDriver(controller)..startGame();
    driver.move('e2', 'e4');
    driver.move('d7', 'd5');
    final capturedId = controller.pieceAt(const Square(3, 3))!.id;
    final presentation = BoardPresentationCoordinator(controller: controller);
    addTearDown(presentation.dispose);
    addTearDown(controller.dispose);

    await tester.pumpWidget(_match(controller, presentation));
    await tester.pump();

    driver.move('e4', 'd5');
    await tester.pump();
    final serial = controller.lastBoardMotionEvent!.serial;

    expect(find.byKey(ValueKey('board-motion-$serial')), findsOneWidget);
    expect(find.byKey(ValueKey('capture-impact-$capturedId')), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) => widget is AbsorbPointer && widget.absorbing,
      ),
      findsNWidgets(2),
    );

    await tester.pump(const Duration(milliseconds: 399));
    expect(find.byKey(ValueKey('board-motion-$serial')), findsOneWidget);
    await tester.pump(const Duration(milliseconds: 1));
    await tester.pump();

    expect(find.byKey(ValueKey('board-motion-$serial')), findsNothing);
    expect(find.byKey(ValueKey('capture-impact-$capturedId')), findsNothing);
    expect(controller.pieceAt(const Square(3, 3))?.color, PieceColor.white);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'betrayal crossfades at origin before redeploy becomes interactive',
    (tester) async {
      await _setSurface(const Size(1280, 720));
      final controller = GameController()..startNewGame();
      final presentation = BoardPresentationCoordinator(controller: controller);
      addTearDown(presentation.dispose);
      addTearDown(controller.dispose);
      const target = Square(1, 0);
      controller.pieceAt(target)!.loyalty = 0;
      controller.tapSquare(target);
      controller.openOfferForSelected();
      controller.setOfferGold(1);
      controller.confirmOffer();

      await tester.pumpWidget(_match(controller, presentation));
      await tester.pump();
      controller.dismissLastOfferResult();
      await tester.pump();

      final transform = controller.lastBetrayalTransformEvent!;
      expect(
        find.byKey(ValueKey('betrayal-transform-${transform.serial}')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('betrayal-before-iron')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('betrayal-after-mercantile')),
        findsOneWidget,
      );
      expect(find.textContaining('Redeploy: choose'), findsNothing);

      await tester.pump(const Duration(milliseconds: 480));
      await tester.pump();

      expect(
        find.byKey(ValueKey('betrayal-transform-${transform.serial}')),
        findsNothing,
      );
      expect(find.textContaining('Redeploy: choose'), findsOneWidget);

      final destination = controller.legalRedeploySquares().first;
      controller.previewRedeploy(destination);
      controller.confirmRedeploy();
      await tester.pump();

      final motion = controller.lastBoardMotionEvent!;
      expect(motion.kind, BoardMotionKind.redeploy);
      expect(
        find.byKey(ValueKey('board-motion-${motion.serial}')),
        findsOneWidget,
      );
      await tester.pump(const Duration(milliseconds: 400));
      expect(tester.takeException(), isNull);
    },
  );
}
