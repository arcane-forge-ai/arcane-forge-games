import 'dart:io';

import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/story/story_campaign_controller.dart';
import 'package:crazy_chess/story/story_catalog.dart';
import 'package:crazy_chess/story/story_profile.dart';
import 'package:crazy_chess/ui/story/story_flow_screens.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

Future<void> _setSurface(WidgetTester tester, Size size) async {
  await tester.binding.setSurfaceSize(size);
  addTearDown(() => tester.binding.setSurfaceSize(null));
}

Future<void> _pumpUntilFound(WidgetTester tester, Finder finder) async {
  await tester.runAsync(
    () => Future<void>.delayed(const Duration(milliseconds: 100)),
  );
  await tester.pump();
  for (var attempt = 0; attempt < 30 && finder.evaluate().isEmpty; attempt++) {
    await tester.pump(const Duration(milliseconds: 100));
  }
}

void main() {
  testWidgets('S03 opens seven-node campaign and M01 briefing', (tester) async {
    await _setSurface(tester, const Size(1600, 900));
    await tester.pumpWidget(const CrazyChessApp());

    await tester.tap(find.text('Press Start'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s02-play')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('s03-story-campaign')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('s03-story-campaign')));
    await tester.pump();
    expect(find.text('THE CROWN WE EARN'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('s03-confirm')));
    await _pumpUntilFound(tester, find.byKey(const ValueKey('story-node-m01')));
    expect(find.byKey(const ValueKey('story-map-screen')), findsOneWidget);
    expect(find.byKey(const ValueKey('story-map-title')), findsOneWidget);
    expect(find.byKey(const ValueKey('story-node-m01')), findsOneWidget);
    expect(find.byKey(const ValueKey('story-node-m07')), findsOneWidget);
    expect(find.text('Ashes at Dawn'), findsOneWidget);
    expect(find.text('Mission Locked'), findsNothing);
    expect(
      find.byKey(const ValueKey('story-map-victory-conditions')),
      findsOneWidget,
    );
    expect(find.text('VICTORY CONDITIONS'), findsOneWidget);
    expect(find.textContaining('Reach a4 with King Rowan'), findsOneWidget);
    expect(find.textContaining('Checkmate the enemy King'), findsOneWidget);
    await tester.binding.setSurfaceSize(const Size(1280, 720));
    await tester.pump();
    expect(find.byKey(const ValueKey('story-map-screen')), findsOneWidget);
    expect(find.byKey(const ValueKey('story-start-mission')), findsOneWidget);
    expect(tester.takeException(), isNull);

    await tester.tap(find.byKey(const ValueKey('story-start-mission')));
    await tester.pump();
    expect(find.byKey(const ValueKey('story-dialogue-screen')), findsOneWidget);
    expect(find.text('M01 · Ashes at Dawn'), findsOneWidget);
    expect(find.text('Skip Seen'), findsNothing);
    expect(
      find.byKey(const ValueKey('story-dialogue-victory-conditions')),
      findsOneWidget,
    );
    expect(find.textContaining('Reach a4 with King Rowan'), findsOneWidget);
    expect(find.textContaining('Checkmate the enemy King'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.binding.setSurfaceSize(const Size(1600, 900));
    await tester.pump();

    await tester.sendKeyEvent(LogicalKeyboardKey.escape);
    await tester.pump();
    expect(find.text('DIALOGUE BACKLOG'), findsOneWidget);
    await tester.sendKeyEvent(LogicalKeyboardKey.escape);
    await tester.pump();
    expect(find.text('DIALOGUE BACKLOG'), findsNothing);

    for (var index = 0; index < 12; index++) {
      await tester.sendKeyEvent(LogicalKeyboardKey.enter);
      await tester.pump();
    }
    expect(
      find.byKey(const ValueKey('story-objective-banner')),
      findsOneWidget,
    );
    expect(find.textContaining('VICTORY CONDITIONS'), findsOneWidget);
    expect(find.textContaining('Reach a4 with King Rowan'), findsOneWidget);
    expect(find.textContaining('Checkmate the enemy King'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.binding.setSurfaceSize(const Size(1280, 720));
    await tester.pump();
    expect(
      find.byKey(const ValueKey('story-objective-banner')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('campaign stalemate displays the skipped-court notice', (
    tester,
  ) async {
    await _setSurface(tester, const Size(1600, 900));
    final catalog = StoryCatalog.fromJsonString(
      File(StoryCatalog.assetPath).readAsStringSync(),
    );
    final game = GameController();
    final story = StoryCampaignController(
      gameController: game,
      catalog: catalog,
      profileRepository: CampaignProfileRepository(
        store: _MemoryCampaignProfileStore(),
      ),
      turnSkipNoticeDuration: const Duration(seconds: 30),
    );
    final presentation = BoardPresentationCoordinator(controller: game);
    await story.initialize();
    story.profile.unlockedMissionIds.add('m02');
    story.selectMission('m02');
    story.startSelectedMission();
    while (story.activeScene != null) {
      story.advanceDialogue();
    }
    _prepareBlackStalemate(game);
    story.evaluateAfterPresentation();

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ResponsiveGameViewport(
            child: StoryBattleScreen(
              controller: story,
              presentationCoordinator: presentation,
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey('story-turn-skip-notice')),
      findsOneWidget,
    );
    expect(
      find.text('Iron Duchy has no legal move. Turn skipped.'),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('story-objective-banner')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
    presentation.dispose();
    story.dispose();
    game.dispose();
  });
}

void _prepareBlackStalemate(GameController controller) {
  for (var row = 0; row < 8; row++) {
    for (var col = 0; col < 8; col++) {
      controller.board[row][col] = null;
    }
  }
  controller
    ..turn = PieceColor.black
    ..turnCount = 2
    ..phase = GamePhase.gameOver
    ..winner = null
    ..stalemate = true
    ..gameEndReason = GameEndReason.stalemate;
  controller.board[0][0] = _piece(
    id: 'black-king',
    type: PieceType.king,
    color: PieceColor.black,
  );
  controller.board[2][2] = _piece(
    id: 'white-king',
    type: PieceType.king,
    color: PieceColor.white,
  );
  controller.board[1][2] = _piece(
    id: 'white-queen',
    type: PieceType.queen,
    color: PieceColor.white,
  );
}

ChessPiece _piece({
  required String id,
  required PieceType type,
  required PieceColor color,
}) {
  return ChessPiece(
    id: id,
    type: type,
    color: color,
    countryId: color == PieceColor.white ? 'mercantile' : 'iron',
    loyalty: 100,
    fairPrice: type == PieceType.king ? null : 20,
  );
}

class _MemoryCampaignProfileStore implements CampaignProfileStore {
  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}
