import 'package:crazy_chess/ui/menu/s01_gold_motes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('gold motes use a static frame when animations are disabled', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: MediaQuery(
          data: MediaQueryData(disableAnimations: true),
          child: S01GoldMotes(),
        ),
      ),
    );
    await tester.pump();

    expect(S01GoldMotes.moteCount, 36);
    expect(find.byKey(const ValueKey('s01-gold-motes-static')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('gold motes animate and never intercept pointer input', (
    tester,
  ) async {
    var presses = 0;
    await tester.pumpWidget(
      MaterialApp(
        home: Stack(
          fit: StackFit.expand,
          children: [
            Center(
              child: FilledButton(
                onPressed: () => presses += 1,
                child: const Text('Underlying action'),
              ),
            ),
            const S01GoldMotes(),
          ],
        ),
      ),
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey('s01-gold-motes-animated')),
      findsOneWidget,
    );
    await tester.tap(find.text('Underlying action'));
    await tester.pump(const Duration(milliseconds: 250));

    expect(presses, 1);
    expect(tester.takeException(), isNull);
  });
}
