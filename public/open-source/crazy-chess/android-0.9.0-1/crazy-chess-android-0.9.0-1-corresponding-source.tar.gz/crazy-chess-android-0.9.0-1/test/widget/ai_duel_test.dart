import 'dart:async';

import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/ui/match/match_screen.dart';
import 'package:crazy_chess/ui/menu/menu_flow_screens.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/fake_chess_engine.dart';
import '../helpers/game_controller_test_driver.dart';

Future<void> _setSurface(Size size) async {
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  await binding.setSurfaceSize(size);
  addTearDown(() => binding.setSurfaceSize(null));
}

void main() {
  testWidgets('S03 and S04 select AI Duel and reset to Local', (tester) async {
    await _setSurface(const Size(1600, 900));
    final engine = FakeChessEngine();
    addTearDown(engine.dispose);

    await tester.pumpWidget(CrazyChessApp(chessEngine: engine));
    await tester.tap(find.text('Press Start'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s02-play')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('s03-ai-duel')));
    await tester.pump();
    expect(find.byKey(const ValueKey('s03-ai-engine-status')), findsOneWidget);
    expect(find.text('STOCKFISH 18  ·  BLACK'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('s03-confirm')));
    await tester.pumpAndSettle();
    expect(engine.initializeCalls, 1);
    expect(find.text('AI DUEL'), findsWidgets);

    await tester.tap(find.byKey(const ValueKey('s04-match-local')));
    await tester.pump();
    expect(find.text('LOCAL DUEL'), findsWidgets);

    await tester.tap(find.byKey(const ValueKey('s04-match-ai')));
    await tester.tap(find.byKey(const ValueKey('s04-merchant-1')));
    await tester.pump();
    expect(find.text('AI DUEL'), findsWidgets);

    await tester.tap(find.byKey(const ValueKey('s04-reset')));
    await tester.pump();
    expect(find.text('LOCAL DUEL'), findsWidgets);
    expect(find.byKey(const ValueKey('s04-merchant-4')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('unavailable environments keep the AI card visibly locked', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    var selected = PlayMode.localDuel;

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ResponsiveGameViewport(
            child: StatefulBuilder(
              builder: (context, setState) => ModeSelectScreen(
                selectedMode: selected,
                aiAvailable: false,
                engineStatus: EngineStatus.unavailable,
                onModeChanged: (mode) => setState(() => selected = mode),
                onBack: () {},
                onContinue: () {},
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('UNAVAILABLE'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('s03-ai-duel')));
    await tester.pump();
    expect(selected, PlayMode.localDuel);
  });

  testWidgets('AI preflight exposes a blocking Stockfish loading state', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    final initialization = Completer<void>();
    final engine = FakeChessEngine()
      ..onInitialize = () => initialization.future;
    addTearDown(engine.dispose);

    await tester.pumpWidget(CrazyChessApp(chessEngine: engine));
    await tester.tap(find.text('Press Start'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s02-play')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s03-ai-duel')));
    await tester.tap(find.byKey(const ValueKey('s03-confirm')));
    await tester.pump();

    expect(find.byKey(const ValueKey('stockfish-loading')), findsOneWidget);
    expect(find.text('Loading Stockfish…'), findsOneWidget);

    initialization.complete();
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('stockfish-loading')), findsNothing);
    expect(find.text('AI DUEL'), findsWidgets);
  });

  testWidgets('Black AI turn locks match input and shows thinking state', (
    tester,
  ) async {
    await _setSurface(const Size(1280, 720));
    final pending = Completer<EngineMove>();
    final controller = GameController()
      ..setOpponentMode(OpponentMode.stockfish);
    final engine = FakeChessEngine()..onBestMove = (_) => pending.future;
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
    );
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);
    final driver = GameControllerTestDriver(controller)..startGame();

    await tester.pumpWidget(_matchApp(controller, coordinator));
    driver.move('e2', 'e4');
    await tester.pump();
    await tester.pump();

    expect(find.byKey(const ValueKey('stockfish-thinking')), findsOneWidget);
    expect(find.byKey(const ValueKey('stockfish-black-badge')), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) => widget is AbsorbPointer && widget.absorbing,
      ),
      findsNWidgets(2),
    );

    pending.complete(const EngineMove(uci: 'e7e5'));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('stockfish-thinking')), findsNothing);
    expect(controller.turn, PieceColor.white);
  });

  testWidgets('engine failure pauses with Retry and Return to Lobby', (
    tester,
  ) async {
    await _setSurface(const Size(1280, 720));
    final controller = GameController()
      ..setOpponentMode(OpponentMode.stockfish);
    final engine = FakeChessEngine(defaultMove: 'e7e4');
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
    );
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);
    final driver = GameControllerTestDriver(controller)..startGame();

    await tester.pumpWidget(_matchApp(controller, coordinator));
    driver.move('e2', 'e4');
    await tester.pump();
    await tester.pump();
    await tester.pump();

    expect(find.byKey(const ValueKey('stockfish-failure')), findsOneWidget);
    expect(find.byKey(const ValueKey('stockfish-retry')), findsOneWidget);
    expect(
      find.byKey(const ValueKey('stockfish-return-lobby')),
      findsOneWidget,
    );
  });
}

Widget _matchApp(GameController controller, AiTurnCoordinator coordinator) {
  return MaterialApp(
    home: Scaffold(
      body: ResponsiveGameViewport(
        child: AnimatedBuilder(
          animation: Listenable.merge([controller, coordinator]),
          builder: (context, _) => MatchScreen(
            controller: controller,
            aiThinking: coordinator.isThinking,
            aiInputLocked: coordinator.inputLocked,
            aiFailureMessage: coordinator.failureMessage,
            onRetryAi: coordinator.retry,
            onLobby: controller.returnToSetup,
          ),
        ),
      ),
    ),
  );
}
