import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/ui/menu/hifi_menu_widgets.dart';
import 'package:crazy_chess/ui/menu/reference_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets(
    'Settings warns before switching to Chinese and persists confirm',
    (tester) async {
      final binding = TestWidgetsFlutterBinding.ensureInitialized();
      await binding.setSurfaceSize(const Size(1600, 900));
      addTearDown(() => binding.setSurfaceSize(null));

      final store = MemoryAppLanguagePreferenceStore('en');
      final firstController = AppLocaleController(store: store);
      await firstController.load();

      await tester.pumpWidget(CrazyChessApp(localeController: firstController));
      await tester.pump();
      expect(find.text('Press Start'), findsOneWidget);

      await tester.tap(find.byKey(const ValueKey('title-settings')));
      await tester.pump(const Duration(milliseconds: 600));
      await tester.tap(
        find.widgetWithText(HifiPrimaryButton, 'Language').first,
      );
      await tester.pump(const Duration(milliseconds: 300));
      await tester.tap(find.byKey(const ValueKey('language-zh-Hans')));
      await tester.pump(const Duration(milliseconds: 300));

      expect(
        find.byKey(const ValueKey('chinese-readiness-warning')),
        findsOneWidget,
      );
      expect(find.text('简体中文尚未完成'), findsOneWidget);
      expect(find.textContaining('画面品质下降'), findsOneWidget);
      expect(find.text('取消'), findsOneWidget);
      expect(find.text('仍然使用简体中文'), findsOneWidget);
      expect(store.value, 'en');
      expect(find.text('Settings'), findsWidgets);

      await tester.tap(find.byKey(const ValueKey('chinese-readiness-cancel')));
      await tester.pump(const Duration(milliseconds: 300));
      expect(
        find.byKey(const ValueKey('chinese-readiness-warning')),
        findsNothing,
      );
      expect(store.value, 'en');
      expect(find.text('Settings'), findsWidgets);

      await tester.tap(find.byKey(const ValueKey('language-zh-Hans')));
      await tester.pump(const Duration(milliseconds: 300));
      await tester.tap(find.byKey(const ValueKey('chinese-readiness-confirm')));
      await tester.pump(const Duration(milliseconds: 300));

      expect(store.value, 'zh-Hans');
      expect(find.text('设置'), findsWidgets);
      expect(find.text('语言'), findsWidgets);
      expect(find.text('已有演化战役会保留创建时的剧情语言。'), findsOneWidget);
      expect(tester.takeException(), isNull);

      await tester.pumpWidget(const SizedBox.shrink());
      firstController.dispose();

      final reloadedController = AppLocaleController(store: store);
      addTearDown(reloadedController.dispose);
      await reloadedController.load();
      await tester.pumpWidget(
        CrazyChessApp(localeController: reloadedController),
      );
      await tester.pump();

      expect(find.text('开始游戏'), findsOneWidget);
      expect(find.text('Press Start'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('Chinese lobby and mode select expose all localized modes', (
    tester,
  ) async {
    final binding = TestWidgetsFlutterBinding.ensureInitialized();
    await binding.setSurfaceSize(const Size(1600, 900));
    addTearDown(() => binding.setSurfaceSize(null));
    final controller = AppLocaleController(
      store: MemoryAppLanguagePreferenceStore('zh-Hans'),
    );
    addTearDown(controller.dispose);
    await controller.load();

    await tester.pumpWidget(CrazyChessApp(localeController: controller));
    await tester.pump();
    await tester.tap(find.text('开始游戏'));
    await tester.pump(const Duration(milliseconds: 600));
    expect(find.bySemanticsLabel('开始游玩'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('s02-play')));
    await tester.pump(const Duration(milliseconds: 600));

    expect(find.bySemanticsLabel('本地对战'), findsOneWidget);
    expect(find.bySemanticsLabel(RegExp('^人机对战')), findsOneWidget);
    expect(find.text('剧情战役'), findsWidgets);
    expect(find.text('残子求生'), findsWidgets);
    expect(find.text('演化战役'), findsWidgets);
    expect(find.text('Story Campaign'), findsNothing);
    expect(find.text('Last Piece Standing'), findsNothing);
    expect(find.text('Living Campaign'), findsNothing);
    expect(find.text('七关史诗'), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is ReferenceLayer &&
            widget.asset.endsWith('s03_local_duel_detail.webp'),
      ),
      findsOneWidget,
    );

    await tester.tap(find.byKey(const ValueKey('s03-confirm')));
    await tester.pump(const Duration(milliseconds: 600));

    expect(find.text('创建对局'), findsOneWidget);
    expect(find.text('对局类型'), findsOneWidget);
    expect(find.text('选择你的对手'), findsOneWidget);
    expect(find.text('本地双人'), findsOneWidget);
    expect(find.text('人机'), findsOneWidget);
    expect(find.text('恢复默认'), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiAssetSurface &&
            widget.asset.endsWith('setting_row_9slice.webp'),
      ),
      findsNWidgets(7),
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName.endsWith('back_button.webp'),
      ),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
}
