import 'package:crazy_chess/audio/audio_settings.dart';
import 'package:crazy_chess/living_campaign/living_campaign_settings.dart';
import 'package:crazy_chess/playtest/playtest_data_exporter.dart';
import 'package:crazy_chess/ui/legal/open_source_licenses_screen.dart';
import 'package:crazy_chess/ui/menu/remaining_flow_screens.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemorySettingsStore implements LivingCampaignSettingsStore {
  @override
  Future<void> clear() async {}

  @override
  Future<String?> read() async => null;

  @override
  Future<void> write(String value) async {}
}

void main() {
  testWidgets('Settings exposes the offline open-source license page', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(1600, 900));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final controller = LivingCampaignSettingsController(
      repository: LivingCampaignSettingsRepository(
        store: _MemorySettingsStore(),
      ),
      developerEnvironment: const LivingDeveloperEnvironment(),
    );
    addTearDown(controller.dispose);

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SettingsScreen(
            onLobby: () {},
            onCollection: () {},
            onCourt: () {},
            onLoadout: () {},
            onRecords: () {},
            onRules: () {},
            selectedCategory: SettingsCategory.openSourceLicenses,
            onCategoryChanged: (_) {},
            reducedEffects: false,
            onReducedEffectsChanged: (_) {},
            audioSettings: const GameAudioSettings(),
            onMasterVolumeChanged: (_) {},
            onMusicVolumeChanged: (_) {},
            onSfxVolumeChanged: (_) {},
            onMasterMutedChanged: (_) {},
            onMusicMutedChanged: (_) {},
            onSfxMutedChanged: (_) {},
            livingSettingsController: controller,
            onTestLivingAi: () async {},
            onExportPlaytestData: _unusedExport,
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.byType(OpenSourceLicensesScreen), findsOneWidget);
    expect(find.text('Stockfish 18'), findsOneWidget);
    expect(find.textContaining('GPL-3.0-only'), findsOneWidget);
    expect(
      find.textContaining(
        'games.arcaneforge.ai/open-source/crazy-chess/android-0.9.0-1/',
      ),
      findsOneWidget,
    );

    final allLicensesButton = find.byKey(
      const ValueKey('open-source-all-licenses'),
    );
    await tester.ensureVisible(allLicensesButton);
    await tester.tap(allLicensesButton);
    await tester.pumpAndSettle();
    expect(find.text('Licenses'), findsOneWidget);
  });
}

Future<PlaytestDataExportResult> _unusedExport() async =>
    const PlaytestDataExportResult(
      fileName: 'unused.zip',
      filePath: '/Downloads/unused.zip',
      byteSize: 0,
      runCount: 0,
      metricsCount: 0,
      diagnosticFileCount: 0,
    );
