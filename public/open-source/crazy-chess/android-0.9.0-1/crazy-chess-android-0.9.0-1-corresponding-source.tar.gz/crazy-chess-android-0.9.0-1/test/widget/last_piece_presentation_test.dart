import 'dart:math' as math;

import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemoryProfileStore implements LastPieceProfileStore {
  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}

LastPieceSessionController _controller() {
  return LastPieceSessionController(
    random: math.Random(31),
    profileRepository: LastPieceProfileRepository(store: _MemoryProfileStore()),
  )..startRun(runSeed: 31);
}

Widget _boardStage(
  LastPieceSessionController controller,
  LastPiecePresentationCoordinator presentation, {
  ValueChanged<Square>? onMove,
}) {
  return MaterialApp(
    home: Scaffold(
      body: Center(
        child: SizedBox.square(
          dimension: 640,
          child: AnimatedBuilder(
            animation: Listenable.merge([controller, presentation]),
            builder: (context, _) => LastPieceSurvivalBoard(
              controller: controller,
              presentationCoordinator: presentation,
              onMove: onMove ?? (_) {},
            ),
          ),
        ),
      ),
    ),
  );
}

void main() {
  testWidgets('enemy token leaves its legal capture square tappable', (
    tester,
  ) async {
    final controller = _controller();
    final presentation = LastPiecePresentationCoordinator(
      controller: controller,
    );
    addTearDown(presentation.dispose);
    addTearDown(controller.dispose);
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: const [
        LastPieceUnit(
          id: 'capture-target',
          type: PieceType.pawn,
          square: Square(3, 3),
        ),
      ],
    );
    Square? tappedSquare;
    await tester.pumpWidget(
      _boardStage(
        controller,
        presentation,
        onMove: (square) => tappedSquare = square,
      ),
    );

    final captureSquare = find.byKey(const ValueKey('last-piece-square-3-3'));
    expect(captureSquare, findsOneWidget);
    expect(
      find.byKey(const ValueKey('last-piece-enemy-capture-target')),
      findsOneWidget,
    );

    await tester.tapAt(tester.getCenter(captureSquare));
    await tester.pump();

    expect(tappedSquare, const Square(3, 3));
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'player travel, transformation, and enemy hunt play in authored order',
    (tester) async {
      final controller = _controller();
      final presentation = LastPiecePresentationCoordinator(
        controller: controller,
      );
      addTearDown(presentation.dispose);
      addTearDown(controller.dispose);
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'hunter',
            type: PieceType.pawn,
            square: Square(0, 0),
          ),
        ],
      );
      controller.debugAddRewardTile(
        const LastPieceRewardTile.transformation(
          id: 'knight-tile',
          square: Square(3, 3),
          targetRole: PieceType.knight,
        ),
      );
      await tester.pumpWidget(_boardStage(controller, presentation));

      await controller.movePlayer(const Square(3, 3));
      await tester.pump();

      expect(find.byKey(const ValueKey('last-piece-motion-1')), findsOneWidget);
      expect(
        find.byKey(const ValueKey('last-piece-moving-1-player')),
        findsOneWidget,
      );
      expect(presentation.isBusy, isTrue);

      await tester.pump(const Duration(milliseconds: 400));
      expect(
        find.byKey(const ValueKey('last-piece-transform-2')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('last-piece-transform-before-2')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('last-piece-transform-after-2')),
        findsOneWidget,
      );

      await tester.pump(const Duration(milliseconds: 480));
      expect(find.byKey(const ValueKey('last-piece-motion-3')), findsOneWidget);
      expect(
        find.byKey(const ValueKey('last-piece-moving-3-hunter')),
        findsOneWidget,
      );

      await tester.pump(const Duration(milliseconds: 400));
      expect(presentation.isBusy, isFalse);
      expect(controller.player.type, PieceType.knight);
      expect(
        find.byKey(const ValueKey('last-piece-player-player')),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('enemy capture remains visible until the travel impact', (
    tester,
  ) async {
    final controller = _controller();
    final presentation = LastPiecePresentationCoordinator(
      controller: controller,
    );
    addTearDown(presentation.dispose);
    addTearDown(controller.dispose);
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: const [
        LastPieceUnit(
          id: 'capturing-rook',
          type: PieceType.rook,
          square: Square(0, 3),
        ),
      ],
    );
    await tester.pumpWidget(_boardStage(controller, presentation));

    await controller.debugRunEnemyPhase();
    await tester.pump();

    expect(controller.phase, LastPieceRunPhase.gameOver);
    expect(presentation.isBusy, isTrue);
    expect(find.byKey(const ValueKey('last-piece-motion-1')), findsOneWidget);
    expect(
      find.byKey(const ValueKey('last-piece-capture-impact-player')),
      findsOneWidget,
    );

    await tester.pump(const Duration(milliseconds: 400));
    expect(presentation.isBusy, isFalse);
    expect(tester.takeException(), isNull);
  });

  testWidgets('spawn batch queues distinct production presentation steps', (
    tester,
  ) async {
    final controller = _controller();
    final presentation = LastPiecePresentationCoordinator(
      controller: controller,
    );
    addTearDown(presentation.dispose);
    addTearDown(controller.dispose);
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: const [
        LastPieceUnit(
          id: 'opening-pawn',
          type: PieceType.pawn,
          square: Square(0, 0),
        ),
      ],
      phasesSinceSpawn: 2,
      forcedScore: 300,
    );
    await tester.pumpWidget(_boardStage(controller, presentation));

    await controller.debugRunEnemyPhase();
    await tester.pump();

    expect(controller.lastEnemyAction, LastPieceEnemyAction.spawn);
    expect(controller.presentationSteps, hasLength(2));
    expect(presentation.activeStep?.kind, LastPiecePresentationKind.spawn);
    expect(find.byKey(const ValueKey('last-piece-spawn-1')), findsOneWidget);

    await tester.pump(const Duration(milliseconds: 320));
    expect(presentation.isBusy, isTrue);
    expect(find.byKey(const ValueKey('last-piece-spawn-2')), findsOneWidget);

    await tester.pump(const Duration(milliseconds: 320));
    expect(presentation.isBusy, isFalse);
    expect(tester.takeException(), isNull);
  });

  test(
    'reduced motion drains an active presentation sequence immediately',
    () async {
      final controller = _controller();
      final presentation = LastPiecePresentationCoordinator(
        controller: controller,
      );
      addTearDown(presentation.dispose);
      addTearDown(controller.dispose);
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(
            id: 'hunter',
            type: PieceType.pawn,
            square: Square(0, 0),
          ),
        ],
      );

      await controller.movePlayer(const Square(3, 3));
      presentation.setReducedMotion(true);

      expect(presentation.isBusy, isFalse);
      expect(presentation.reducedMotion, isTrue);
    },
  );
}
