import 'package:crazy_chess/app/theme.dart';
import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/ui/board/piece_token.dart';
import 'package:crazy_chess/ui/match/match_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Future<void> _setSurface(Size size) async {
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  await binding.setSurfaceSize(size);
  addTearDown(() => binding.setSurfaceSize(null));
}

Widget _matchApp(GameController controller) {
  return MaterialApp(
    theme: buildCrazyChessTheme(),
    home: AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return Scaffold(
          body: ResponsiveGameViewport(
            child: MatchScreen(controller: controller),
          ),
        );
      },
    ),
  );
}

Finder _loyaltyBars() {
  return find.byWidgetPredicate((widget) {
    final key = widget.key;
    return key is ValueKey<String> &&
        key.value.startsWith('piece-loyalty-bar-');
  });
}

void main() {
  testWidgets('non-Spy turns render no loyalty bars or loyalty semantics', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    final controller = GameController()
      ..setupWhiteCountryId = 'mercantile'
      ..setupBlackCountryId = 'spy'
      ..startNewGame();
    addTearDown(controller.dispose);
    final semantics = tester.ensureSemantics();

    await tester.pumpWidget(_matchApp(controller));
    await tester.pumpAndSettle();

    expect(_loyaltyBars(), findsNothing);
    expect(
      find.byKey(const ValueKey('piece-role-badge-white-pawn')),
      findsNWidgets(8),
    );
    expect(
      find.byKey(const ValueKey('piece-role-badge-black-pawn')),
      findsNWidgets(8),
    );
    expect(
      find.bySemanticsLabel(RegExp('loyalty', caseSensitive: false)),
      findsNothing,
    );
    for (final token in tester.widgetList<PieceToken>(
      find.byType(PieceToken),
    )) {
      expect(token.loyaltyBand, isNull);
    }
    semantics.dispose();
  });

  testWidgets('Spy turns render one coarse bar for every non-King', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    final controller = GameController()
      ..setupWhiteCountryId = 'spy'
      ..setupBlackCountryId = 'iron'
      ..startNewGame();
    addTearDown(controller.dispose);

    await tester.pumpWidget(_matchApp(controller));
    await tester.pumpAndSettle();

    expect(_loyaltyBars(), findsNWidgets(30));
    final tokens = tester.widgetList<PieceToken>(find.byType(PieceToken));
    expect(
      tokens.where((token) => token.piece.type == PieceType.king),
      hasLength(2),
    );
    expect(
      tokens
          .where((token) => token.piece.type == PieceType.king)
          .every((token) => token.loyaltyBand == null),
      isTrue,
    );
    expect(
      tokens
          .where((token) => token.piece.type != PieceType.king)
          .every((token) => token.loyaltyBand != null),
      isTrue,
    );
  });

  testWidgets('Reveal exposes exact loyalty only for the current offer', (
    tester,
  ) async {
    await _setSurface(const Size(1280, 720));
    final controller = GameController()
      ..setupWhiteCountryId = 'spy'
      ..setupBlackCountryId = 'mercantile'
      ..startNewGame();
    addTearDown(controller.dispose);
    controller.tapSquare(const Square(1, 0));
    controller.openOfferForSelected();

    await tester.pumpWidget(_matchApp(controller));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s22-coarse-loyalty')), findsOneWidget);
    expect(find.byKey(const ValueKey('s22-exact-loyalty')), findsNothing);
    expect(find.byKey(const ValueKey('s22-exact-chance')), findsNothing);

    await tester.tap(find.byKey(const ValueKey('s22-reveal-chance')));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s22-exact-loyalty')), findsOneWidget);
    expect(find.byKey(const ValueKey('s22-exact-chance')), findsOneWidget);

    controller.cancelOffer();
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s22-exact-loyalty')), findsNothing);
    expect(
      controller.visibleExactLoyaltyForActiveCourt(
        controller.pieceAt(const Square(1, 0))!,
      ),
      isNull,
    );
  });

  testWidgets('automatic and humiliating outcomes skip the dice overlay', (
    tester,
  ) async {
    await _setSurface(const Size(1280, 720));
    final cases = <OfferResult>[
      const OfferResult(
        success: true,
        roll: null,
        chance: 100,
        paid: 1,
        refund: 0,
        targetName: 'Black Queen',
        resolutionKind: OfferResolutionKind.automatic,
        publicReaction: OfferReaction.accepted,
        loyaltyBefore: 0,
        loyaltyAfter: 55,
      ),
      const OfferResult(
        success: false,
        roll: null,
        chance: 23,
        paid: 3,
        refund: 0,
        targetName: 'Black Rook',
        resolutionKind: OfferResolutionKind.humiliated,
        publicReaction: OfferReaction.humiliated,
        loyaltyBefore: 82,
        loyaltyAfter: 94,
      ),
    ];

    for (final result in cases) {
      final controller = GameController()..startNewGame();
      addTearDown(controller.dispose);
      controller
        ..lastOfferResult = result
        ..phase = result.success ? GamePhase.redeploy : GamePhase.playing;

      await tester.pumpWidget(
        KeyedSubtree(
          key: ValueKey(result.targetName),
          child: _matchApp(controller),
        ),
      );
      await tester.pump();

      expect(find.byKey(const ValueKey('s24-roll-modal')), findsNothing);
      expect(find.byKey(const ValueKey('s25-result-panel')), findsOneWidget);
    }
  });

  testWidgets('public reactions do not expose hidden numeric intelligence', (
    tester,
  ) async {
    await _setSurface(const Size(1280, 720));
    final controller = GameController()..startNewGame();
    addTearDown(controller.dispose);
    controller
      ..lastOfferResult = const OfferResult(
        success: false,
        roll: null,
        chance: 23,
        paid: 3,
        refund: 0,
        targetName: 'Black Rook',
        resolutionKind: OfferResolutionKind.humiliated,
        publicReaction: OfferReaction.humiliated,
        loyaltyBefore: 82,
        loyaltyAfter: 94,
      )
      ..phase = GamePhase.playing;

    await tester.pumpWidget(_matchApp(controller));
    await tester.pump();

    expect(find.text('Humiliated — loyalty strengthened.'), findsOneWidget);
    expect(find.text('23%'), findsNothing);
    expect(find.text('82'), findsNothing);
    expect(find.text('94'), findsNothing);
    expect(find.text('HIDDEN'), findsNothing);
  });

  testWidgets('revealed Spy result may show exact before and after values', (
    tester,
  ) async {
    await _setSurface(const Size(1280, 720));
    final controller = GameController()..startNewGame();
    addTearDown(controller.dispose);
    controller
      ..lastOfferResult = const OfferResult(
        success: false,
        roll: null,
        chance: 23,
        paid: 3,
        refund: 0,
        targetName: 'Black Rook',
        resolutionKind: OfferResolutionKind.humiliated,
        publicReaction: OfferReaction.humiliated,
        loyaltyBefore: 82,
        loyaltyAfter: 94,
        buyerHadExactIntel: true,
      )
      ..phase = GamePhase.playing;

    await tester.pumpWidget(_matchApp(controller));
    await tester.pump();

    expect(find.text('82 → 94'), findsOneWidget);
  });
}
