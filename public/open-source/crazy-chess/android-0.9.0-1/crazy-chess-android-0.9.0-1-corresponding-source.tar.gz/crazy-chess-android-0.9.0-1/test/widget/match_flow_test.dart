import 'dart:math' as math;

import 'package:crazy_chess/app/theme.dart';
import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/l10n/app_localizations.dart';
import 'package:crazy_chess/l10n/runtime_game_locale.dart';
import 'package:crazy_chess/ui/board/game_board.dart';
import 'package:crazy_chess/ui/effects/production_board_effects.dart';
import 'package:crazy_chess/ui/match/match_screen.dart';
import 'package:crazy_chess/ui/menu/hifi_menu_widgets.dart';
import 'package:crazy_chess/ui/menu/remaining_flow_screens.dart';
import 'package:crazy_chess/ui/shared/piece_art.dart';
import 'package:crazy_chess/ui/shared/reference_first_match_art.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/game_controller_test_driver.dart';

Future<void> setSurface(Size size) async {
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  await binding.setSurfaceSize(size);
  addTearDown(() => binding.setSurfaceSize(null));
}

Widget testMatchApp(
  GameController controller, {
  Locale locale = const Locale('en'),
  PurchasePlacementPolicy purchasePlacementPolicy =
      PurchasePlacementPolicy.redeploy,
}) {
  RuntimeGameLocale.setLocale(locale);
  return MaterialApp(
    locale: locale,
    supportedLocales: AppLocalizations.supportedLocales,
    localizationsDelegates: AppLocalizations.localizationsDelegates,
    theme: buildCrazyChessTheme(locale: locale),
    home: AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return Scaffold(
          body: ResponsiveGameViewport(
            child: MatchScreen(
              controller: controller,
              purchasePlacementPolicy: purchasePlacementPolicy,
            ),
          ),
        );
      },
    ),
  );
}

void main() {
  const zhHans = Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hans');

  testWidgets('controller helper can drive game-over match state', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    final driver = GameControllerTestDriver(controller)..foolsMate();

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    expect(driver.snapshot()['phase'], GamePhase.gameOver.name);
    expect(find.byKey(const ValueKey('s28-checkmate-banner')), findsOneWidget);
    expect(find.text('SELECTED PIECE'), findsNothing);
    expect(
      find.byKey(const ValueKey('s28-inspector-content-cleared')),
      findsOneWidget,
    );
    expect(find.text('Black court victorious.'), findsOneWidget);
    expect(find.text('Postgame Summary'), findsNothing);
    expect(tester.getRect(find.byKey(StageMetrics.stageKey)).width, 1280);
    expect(tester.takeException(), isNull);
  });

  testWidgets('selected enemy opens offer contract and Spy reveal state', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    GameControllerTestDriver(controller).startGame(whiteCountry: 'spy');

    controller.tapSquare(const Square(1, 0));
    controller.openOfferForSelected();

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s22-target-portrait')), findsOneWidget);
    expect(
      find.byKey(const ValueKey('s22-contract-parchment')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('s22-chance-badge-hidden')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('s22-fair-price-visible')),
      findsOneWidget,
    );
    expect(find.text('UNKNOWN'), findsNothing);
    expect(find.byKey(const ValueKey('s22-gold-stepper')), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                matchOfferContractShellAsset,
      ),
      findsOneWidget,
    );
    for (final obsoleteLabel in const [
      'Before Offer',
      'After Offer',
      'Personality',
      'Trade',
    ]) {
      expect(find.text(obsoleteLabel), findsNothing);
    }
    expect(
      tester.getRect(find.byKey(const ValueKey('s22-submit-contract'))).height,
      greaterThanOrEqualTo(48),
    );
    expect(
      tester.getRect(find.byKey(const ValueKey('s22-close-contract'))).height,
      greaterThanOrEqualTo(48),
    );

    controller.revealOfferChance();
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s22-exact-chance')), findsOneWidget);
    expect(
      find.byKey(const ValueKey('s22-chance-badge-revealed')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('fair price stays hidden from a non-Spy active court', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController(random: math.Random(20260729));
    addTearDown(controller.dispose);
    GameControllerTestDriver(
      controller,
    ).startGame(whiteCountry: 'mercantile', blackCountry: 'spy');
    final target = controller.pieceAt(const Square(1, 0))!;

    controller.tapSquare(const Square(1, 0));
    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s21-spy-fair-price')), findsNothing);
    expect(target.fairPrice, isNotNull);

    controller.openOfferForSelected();
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s22-fair-price-hidden')), findsOneWidget);
    expect(find.text('UNKNOWN'), findsOneWidget);
    expect(controller.offerGold, fairPriceAnchors[PieceType.pawn]);
  });

  testWidgets('Chinese S22 keeps the production contract and chance badges', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    addTearDown(() => RuntimeGameLocale.setLocale(const Locale('en')));
    GameControllerTestDriver(
      controller,
    ).startGame(whiteCountry: 'spy', blackCountry: 'iron');
    controller.tapSquare(const Square(1, 0));
    controller.openOfferForSelected();

    await tester.pumpWidget(testMatchApp(controller, locale: zhHans));
    await tester.pumpAndSettle();

    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                matchOfferContractShellAsset,
      ),
      findsOneWidget,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiAssetSurface &&
            widget.asset.endsWith('chance_badge_hidden.webp'),
      ),
      findsOneWidget,
    );
    expect(find.text('价格 -25'), findsOneWidget);
    expect(find.text('PRICE -25'), findsNothing);

    controller.revealOfferChance();
    await tester.pumpAndSettle();
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiAssetSurface &&
            widget.asset.endsWith('chance_badge_revealed.webp'),
      ),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('Chinese S24 and S25 keep production shells and identity copy', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    addTearDown(() => RuntimeGameLocale.setLocale(const Locale('en')));
    controller.startNewGame();
    controller.lastOfferResult = const OfferResult(
      success: false,
      roll: 37,
      chance: 60,
      paid: 18,
      refund: 4,
      targetName: 'Black Pawn',
      targetType: PieceType.pawn,
      targetCountryId: 'iron',
      targetColor: PieceColor.black,
      buyerHadExactIntel: false,
      publicReaction: OfferReaction.tempted,
    );

    await tester.pumpWidget(testMatchApp(controller, locale: zhHans));
    await tester.pump();

    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                matchPurchaseRollShellAsset,
      ),
      findsOneWidget,
    );
    expect(find.text('黑方 兵 · 铁壁公国'), findsOneWidget);

    await tester.pump(const Duration(milliseconds: 621));
    await tester.pumpAndSettle();

    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName == matchResultShellAsset,
      ),
      findsOneWidget,
    );
    expect(find.text('黑方 兵'), findsOneWidget);
    expect(find.text('BLACK PAWN'), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('purchase result presentation can be dismissed', (tester) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    GameControllerTestDriver(controller).startGame();

    controller.tapSquare(const Square(1, 0));
    controller.openOfferForSelected();
    final offerTarget = controller.pieceAt(const Square(1, 0))!;
    offerTarget.loyalty = 60;
    controller.setOfferGold(offerTarget.fairPrice!);
    controller.confirmOffer();

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pump();

    expect(find.byKey(const ValueKey('s24-roll-modal')), findsOneWidget);
    expect(
      find.byKey(const ValueKey('s24-reference-first-shell')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('s24-animated-roll')), findsOneWidget);
    expect(find.byKey(const ValueKey('vfx-offer-coin-trail')), findsOneWidget);
    expect(find.byKey(const ValueKey('vfx-roll-flash')), findsOneWidget);
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s25-result-panel')), findsOneWidget);
    expect(
      find.byKey(const ValueKey('s25-reference-first-shell')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('s25-result-facts')), findsOneWidget);
    expect(find.byKey(const ValueKey('s25-outcome-icon')), findsOneWidget);
    expect(
      find.text(
        controller.lastOfferResult!.success
            ? 'CONTRACT ACCEPTED'
            : 'CONTRACT REJECTED',
      ),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('vfx-offer-coin-trail')), findsNothing);
    expect(find.byKey(const ValueKey('vfx-roll-flash')), findsNothing);
    expect(
      find.byKey(const ValueKey('vfx-failure-coin-scatter')),
      findsNothing,
    );

    await tester.tap(find.byKey(const ValueKey('purchase-result-dismiss')));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s25-result-panel')), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'Living Campaign Enter acknowledgement transforms enemy purchase in place',
    (tester) async {
      await setSurface(const Size(1600, 900));
      final controller = GameController();
      addTearDown(controller.dispose);
      GameControllerTestDriver(controller).startGame();
      controller.turn = PieceColor.black;
      controller.gold[PieceColor.black] = 20;

      const targetSquare = Square(6, 0);
      final target = controller.pieceAt(targetSquare)!;
      final targetId = target.id;
      target.loyalty = 0;
      controller.tapSquare(targetSquare);
      controller.openOfferForSelected();
      controller.setOfferGold(1);
      controller.confirmOffer();

      await tester.pumpWidget(
        testMatchApp(
          controller,
          purchasePlacementPolicy: PurchasePlacementPolicy.blackInPlace,
        ),
      );
      await tester.pumpAndSettle();

      expect(controller.phase, GamePhase.redeploy);
      expect(controller.turn, PieceColor.black);
      expect(controller.pieceAt(targetSquare), isNull);
      expect(find.text('Continue'), findsOneWidget);
      expect(find.byKey(const ValueKey('s26-redeploy-panel')), findsNothing);
      expect(
        find.text(
          'The piece will transform on its current tile after you continue.',
        ),
        findsOneWidget,
      );
      expect(find.textContaining('Choose its redeploy square'), findsNothing);
      expect(find.textContaining('Redeploy: choose'), findsNothing);

      await tester.sendKeyEvent(LogicalKeyboardKey.enter);
      await tester.pumpAndSettle();

      final converted = controller.pieceAt(targetSquare);
      expect(controller.lastOfferResult, isNull);
      expect(controller.lastAiRedeployResolution, AiRedeployResolution.inPlace);
      expect(controller.phase, GamePhase.playing);
      expect(controller.turn, PieceColor.white);
      expect(converted?.id, targetId);
      expect(converted?.color, PieceColor.black);
      expect(controller.lastBetrayalTransformEvent?.square, targetSquare);
      expect(controller.lastBoardMotionEvent, isNull);
      expect(find.byKey(const ValueKey('s25-result-panel')), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('S24 reduced motion renders the final d100 as a static value', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    controller.startNewGame();
    controller.lastOfferResult = const OfferResult(
      success: false,
      roll: 86,
      chance: 64,
      paid: 8,
      refund: 2,
      targetName: 'Black Bishop',
    );

    await tester.pumpWidget(
      MaterialApp(
        theme: buildCrazyChessTheme(),
        builder: (context, child) => MediaQuery(
          data: MediaQuery.of(context).copyWith(disableAnimations: true),
          child: child!,
        ),
        home: Scaffold(
          body: ResponsiveGameViewport(
            child: MatchScreen(controller: controller),
          ),
        ),
      ),
    );
    await tester.pump();

    expect(
      find.byKey(const ValueKey('s24-reduced-motion-roll')),
      findsOneWidget,
    );
    expect(find.text('86'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('S25 uses live accepted and rejected facts with one action', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final results = <OfferResult>[
      const OfferResult(
        success: true,
        roll: 24,
        chance: 64,
        paid: 8,
        refund: 0,
        targetName: 'Black Bishop',
        buyerHadExactIntel: true,
      ),
      const OfferResult(
        success: false,
        roll: 88,
        chance: 53,
        paid: 8,
        refund: 2,
        targetName: 'Black Knight',
        buyerHadExactIntel: true,
      ),
    ];

    for (final result in results) {
      final controller = GameController();
      addTearDown(controller.dispose);
      controller.startNewGame();
      controller.lastOfferResult = result;
      controller.phase = result.success
          ? GamePhase.redeploy
          : GamePhase.playing;

      await tester.pumpWidget(
        KeyedSubtree(
          key: ValueKey('result-${result.targetName}'),
          child: testMatchApp(controller),
        ),
      );
      await tester.pump();
      expect(find.byKey(const ValueKey('s24-roll-modal')), findsOneWidget);

      await tester.pump(const Duration(milliseconds: 621));
      await tester.pumpAndSettle();

      expect(find.byKey(const ValueKey('s25-result-panel')), findsOneWidget);
      expect(find.byKey(const ValueKey('s25-result-facts')), findsOneWidget);
      expect(find.text('${result.roll}'), findsOneWidget);
      expect(find.text('${result.chance}%'), findsOneWidget);
      expect(find.text('${result.paid} Gold'), findsOneWidget);
      expect(
        find.descendant(
          of: find.byKey(const ValueKey('s25-result-panel')),
          matching: find.byType(HifiPrimaryButton),
        ),
        findsOneWidget,
      );
      expect(
        find.text(result.success ? 'Choose Placement' : 'Return to Board'),
        findsOneWidget,
      );
      expect(find.text('Before Offer'), findsNothing);
      expect(find.text('After Offer'), findsNothing);
      expect(find.text('Continue'), findsNothing);
      expect(tester.takeException(), isNull);
    }
  });

  testWidgets('legal move and capture markers remain live board overlays', (
    tester,
  ) async {
    await setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);
    final driver = GameControllerTestDriver(controller)..startGame();
    driver.move('e2', 'e4');
    driver.move('d7', 'd5');
    controller.tapSquare(controller.parseSquare('e4')!);

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('board-legal-move-dot')), findsWidgets);
    expect(
      find.byKey(const ValueKey('board-legal-capture-marker')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('production board materials preserve square hitboxes', (
    tester,
  ) async {
    await setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);
    GameControllerTestDriver(
      controller,
    ).startGame(whiteCountry: 'mercantile', blackCountry: 'spy');

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        expect(
          find.byKey(ValueKey('board-square-$row-$col')),
          findsOneWidget,
          reason: 'Every transformed square keeps a direct target.',
        );
      }
    }
    for (final corner in const [
      Square(0, 0),
      Square(0, 7),
      Square(7, 0),
      Square(7, 7),
    ]) {
      await tester.tap(
        find.byKey(ValueKey('board-square-${corner.row}-${corner.col}')),
      );
      await tester.pumpAndSettle();
      expect(controller.selectedSquare, corner);
    }

    final board = tester.getRect(find.byType(GameBoard));
    Offset centerOf(Square square) => Offset(
      board.left + (square.col + .5) * board.width / 8,
      board.top + (square.row + .5) * board.height / 8,
    );
    const origin = Square(6, 0); // White a2 pawn.
    const target = Square(5, 0); // White a3 legal move.

    await tester.tapAt(centerOf(origin));
    await tester.pumpAndSettle();
    expect(controller.selectedSquare, origin);
    expect(find.byKey(const ValueKey('board-legal-move-dot')), findsWidgets);

    await tester.tapAt(centerOf(target));
    await tester.pumpAndSettle();
    expect(controller.board[target.row][target.col]?.type, PieceType.pawn);
    expect(controller.board[origin.row][origin.col], isNull);
    expect(tester.takeException(), isNull);
  });

  test('piece art resolver gives Mercantile and Spy all-role identities', () {
    for (final country in const [
      'mercantile',
      'iron',
      'horse',
      'spy',
      'corsair',
      'sunlit',
    ]) {
      for (final type in PieceType.values) {
        for (final color in PieceColor.values) {
          final spec = PieceArtResolver.resolve(
            countryId: country,
            type: type,
            color: color,
          );
          final expected = switch (country) {
            'mercantile' || 'spy' => '${country}_${type.name}',
            'iron' when type == PieceType.king || type == PieceType.queen =>
              'iron_${type.name}',
            'horse' when type == PieceType.king || type == PieceType.queen =>
              'neutral_${type.name}',
            'corsair' || 'sunlit'
                when type == PieceType.king || type == PieceType.queen =>
              'neutral_${type.name}',
            _ => 'shared_${type.name}',
          };
          expect(
            spec.identityKey,
            expected,
            reason: '$country ${type.name} ${color.name}',
          );
          expect(
            spec.boardTokenAsset,
            isNot(spec.portraitAsset),
            reason:
                '$country ${type.name} ${color.name} keeps token and portrait distinct',
          );
          if (country == 'mercantile') {
            expect(
              spec.boardTokenAsset,
              endsWith('/${color.name}/mercantile_${type.name}_token.webp'),
            );
            expect(spec.boardTokenFallbackAsset, isNotNull);
          } else {
            expect(spec.boardTokenFallbackAsset, isNull);
          }
        }
      }
    }
  });

  testWidgets('S20 uses measured board-first HUD without unsupported strips', (
    tester,
  ) async {
    await setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);
    controller.startNewGame();

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s20-match-hud')), findsOneWidget);
    expect(find.byKey(const ValueKey('s20-tilted-board')), findsOneWidget);
    expect(
      find.byKey(const ValueKey('s20-vertical-merchant-route')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('s20-merchant-caravan')), findsOneWidget);
    for (final type in PieceType.values) {
      expect(
        find.byKey(ValueKey('piece-role-badge-white-${type.name}')),
        findsWidgets,
      );
      expect(
        find.byKey(ValueKey('piece-role-badge-black-${type.name}')),
        findsWidgets,
      );
    }
    expect(find.byKey(const ValueKey('s20-versus')), findsOneWidget);
    expect(find.textContaining('Timer'), findsNothing);
    expect(find.textContaining('Personality'), findsNothing);
    expect(find.textContaining('legal moves'), findsNothing);
    expect(find.text('Postgame Summary'), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('selected Mercantile Queen uses the approved bust', (
    tester,
  ) async {
    await setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);
    controller.startNewGame();
    final queen = controller.board[7][3]!;

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();
    controller.tapSquare(const Square(7, 3));
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('piece-art-portrait-mercantile_queen')),
      findsOneWidget,
    );
    expect(
      tester
          .widget<AnimatedScale>(
            find.byKey(ValueKey('piece-token-${queen.id}')),
          )
          .scale,
      1.12,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('match uses the approved S20-S21 panel collection', (
    tester,
  ) async {
    await setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);
    GameControllerTestDriver(
      controller,
    ).startGame(whiteCountry: 'mercantile', blackCountry: 'spy');

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    for (final asset in [
      matchHudEventLogAsset,
      matchHudInspectorAsset,
      matchHudMerchantRailAsset,
      matchCourtPlateAsset('mercantile', blackSide: false),
      matchCourtPlateAsset('spy', blackSide: true),
    ]) {
      expect(
        find.byWidgetPredicate(
          (widget) => widget is HifiAssetSurface && widget.asset == asset,
        ),
        findsOneWidget,
      );
    }
    expect(
      find.byKey(const ValueKey('s20-country-crest-mercantile')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('s20-country-crest-spy')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('check alert renders without game over', (tester) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    controller.startNewGame();
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        controller.board[row][col] = null;
      }
    }
    controller.board[7][4] = ChessPiece(
      id: 'white-king-test',
      type: PieceType.king,
      color: PieceColor.white,
      countryId: 'mercantile',
      loyalty: 60,
      fairPrice: null,
    );
    controller.board[0][4] = ChessPiece(
      id: 'black-rook-test',
      type: PieceType.rook,
      color: PieceColor.black,
      countryId: 'iron',
      loyalty: 60,
      fairPrice: 22,
    );
    controller.board[0][0] = ChessPiece(
      id: 'black-king-test',
      type: PieceType.king,
      color: PieceColor.black,
      countryId: 'iron',
      loyalty: 60,
      fairPrice: null,
    );
    controller.turn = PieceColor.white;
    controller.phase = GamePhase.playing;

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    expect(find.text('Check Alert'), findsOneWidget);
    expect(find.text('Checkmate'), findsNothing);
    expect(
      find.byKey(const ValueKey('board-king-check-pulse')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('board-threat-line')), findsOneWidget);
    expect(find.byKey(const ValueKey('vfx-red-alert-flash')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('redeploy ghost marks the forbidden origin square', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    controller.startNewGame();
    const original = Square(1, 3);
    final piece = controller.board[original.row][original.col]!;
    controller.board[original.row][original.col] = null;
    piece
      ..color = PieceColor.white
      ..countryId = controller.setupWhiteCountryId
      ..newlyPurchased = true;
    controller.redeployPiece = piece;
    controller.redeployOriginalSquare = original;
    controller.phase = GamePhase.redeploy;

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('board-redeploy-ghost-token')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('s26-redeploy-panel')), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                matchRedeployInstructionShellAsset,
      ),
      findsOneWidget,
    );
    expect(find.text('Selected Piece'), findsNothing);
    expect(find.text('REDEPLOY DEFECTOR'), findsOneWidget);
    final redeployTitle = tester.widget<Text>(find.text('REDEPLOY DEFECTOR'));
    expect(redeployTitle.style?.color, hifiGold);
    expect(redeployTitle.textAlign, TextAlign.center);
    expect(find.text('WHITE PAWN'), findsOneWidget);
    expect(find.text('MERCANTILE LEAGUE'), findsOneWidget);
    expect(find.textContaining('Preview a highlighted square'), findsOneWidget);
    expect(find.text('16 LEGAL REDEPLOY SQUARES'), findsOneWidget);
    expect(find.byKey(const ValueKey('s26-legend-valid')), findsOneWidget);
    expect(find.byKey(const ValueKey('s26-legend-forbidden')), findsOneWidget);
    expect(find.byKey(const ValueKey('s26-legend-origin')), findsOneWidget);

    final confirm = tester.widget<InkWell>(
      find.byKey(const ValueKey('s26-confirm-placement')),
    );
    expect(confirm.onTap, isNull);
    final destination = controller.legalRedeploySquares().first;
    final destinationFinder = find.byKey(
      ValueKey('board-square-${destination.row}-${destination.col}'),
    );
    await tester.tap(destinationFinder);
    await tester.pumpAndSettle();

    expect(controller.pendingRedeploySquare, destination);
    expect(
      find.byKey(const ValueKey('board-redeploy-preview-token')),
      findsOneWidget,
    );
    expect(
      tester
          .widget<InkWell>(find.byKey(const ValueKey('s26-confirm-placement')))
          .onTap,
      isNotNull,
    );
    expect(find.text('Cancel'), findsNothing);

    await tester.tap(
      find.byKey(ValueKey('board-square-${original.row}-${original.col}')),
    );
    await tester.pumpAndSettle();
    expect(
      controller.pendingRedeploySquare,
      destination,
      reason: 'The forbidden origin must not clear a valid preview.',
    );

    const occupiedInvalid = Square(6, 0);
    await tester.tap(
      find.byKey(
        ValueKey('board-square-${occupiedInvalid.row}-${occupiedInvalid.col}'),
      ),
    );
    await tester.pumpAndSettle();
    expect(
      controller.pendingRedeploySquare,
      destination,
      reason: 'An invalid occupied square must not clear a valid preview.',
    );

    await tester.tap(find.byKey(const ValueKey('s26-confirm-placement')));
    await tester.pumpAndSettle();
    expect(controller.phase, GamePhase.playing);
    expect(controller.board[destination.row][destination.col], same(piece));
    expect(controller.pendingRedeploySquare, isNull);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Chinese S26 keeps the production redeploy shell', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    addTearDown(() => RuntimeGameLocale.setLocale(const Locale('en')));
    controller.startNewGame();
    const original = Square(1, 3);
    final piece = controller.board[original.row][original.col]!;
    controller.board[original.row][original.col] = null;
    piece
      ..color = PieceColor.white
      ..countryId = controller.setupWhiteCountryId
      ..newlyPurchased = true;
    controller
      ..redeployPiece = piece
      ..redeployOriginalSquare = original
      ..phase = GamePhase.redeploy;

    await tester.pumpWidget(testMatchApp(controller, locale: zhHans));
    await tester.pumpAndSettle();

    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                matchRedeployInstructionShellAsset,
      ),
      findsOneWidget,
    );
    expect(find.text('重新部署叛变棋子'), findsOneWidget);
    expect(find.text('重新部署：请选择己方半场内的高亮格。棋子不能返回原始格，也不能形成直接将军。'), findsOneWidget);
    expect(
      find.textContaining('Redeploy: choose a highlighted square'),
      findsNothing,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('merchant court payout emits the canonical coin burst', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    final driver = GameControllerTestDriver(controller)..startGame();
    controller.merchantPosition = 15;
    controller.merchantDirection = 1;
    driver.move('e2', 'e4');

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    expect(controller.lastMerchantPayoutReceiver, PieceColor.black);
    expect(controller.merchantPayoutPulseSerial, 1);
    expect(
      find.byKey(const ValueKey('vfx-merchant-payout-coin-burst')),
      findsOneWidget,
    );
    expect(
      tester
          .widget<ProductionMerchantPayoutCoinBurst>(
            find.byType(ProductionMerchantPayoutCoinBurst),
          )
          .toRight,
      isFalse,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('check pulse has a static reduced-motion state', (tester) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    controller.startNewGame();
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        controller.board[row][col] = null;
      }
    }
    controller.board[7][4] = ChessPiece(
      id: 'white-king-reduced-motion',
      type: PieceType.king,
      color: PieceColor.white,
      countryId: 'mercantile',
      loyalty: 60,
      fairPrice: null,
    );
    controller.board[0][4] = ChessPiece(
      id: 'black-rook-reduced-motion',
      type: PieceType.rook,
      color: PieceColor.black,
      countryId: 'iron',
      loyalty: 60,
      fairPrice: 22,
    );
    controller.board[0][0] = ChessPiece(
      id: 'black-king-reduced-motion',
      type: PieceType.king,
      color: PieceColor.black,
      countryId: 'iron',
      loyalty: 60,
      fairPrice: null,
    );
    controller.turn = PieceColor.white;
    controller.phase = GamePhase.playing;

    await tester.pumpWidget(
      MaterialApp(
        theme: buildCrazyChessTheme(),
        home: MediaQuery(
          data: const MediaQueryData(disableAnimations: true),
          child: Scaffold(
            body: ResponsiveGameViewport(
              child: MatchScreen(controller: controller),
            ),
          ),
        ),
      ),
    );
    await tester.pump(const Duration(seconds: 2));

    expect(
      find.byKey(const ValueKey('board-king-check-pulse')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('game over exposes only rematch and lobby actions', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    GameControllerTestDriver(controller).foolsMate();
    await tester.pumpWidget(
      MaterialApp(
        theme: buildCrazyChessTheme(),
        home: Scaffold(
          body: ResponsiveGameViewport(
            child: MatchScreen(controller: controller),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Play Again'), findsOneWidget);
    expect(find.text('Back to Lobby'), findsOneWidget);
    expect(find.byKey(const ValueKey('s28-play-again')), findsOneWidget);
    expect(find.byKey(const ValueKey('s28-back-to-lobby')), findsOneWidget);
    expect(find.byKey(const ValueKey('s28-winner-portrait')), findsOneWidget);
    expect(find.byKey(const ValueKey('s28-checkmate-banner')), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                matchCheckmateVictoryBannerAsset,
      ),
      findsOneWidget,
    );
    expect(find.text('Postgame Summary'), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Chinese S28 keeps the production checkmate banner', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    final controller = GameController();
    addTearDown(controller.dispose);
    addTearDown(() => RuntimeGameLocale.setLocale(const Locale('en')));
    GameControllerTestDriver(controller).foolsMate();

    await tester.pumpWidget(testMatchApp(controller, locale: zhHans));
    await tester.pumpAndSettle();

    expect(find.bySemanticsLabel('将死胜利'), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                matchCheckmateVictoryBannerAsset,
      ),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'S28 stalemate uses the neutral banner and the same two actions',
    (tester) async {
      await setSurface(const Size(1280, 720));
      final controller = GameController();
      addTearDown(controller.dispose);
      controller.startNewGame();
      controller
        ..winner = null
        ..stalemate = true
        ..phase = GamePhase.gameOver;

      await tester.pumpWidget(testMatchApp(controller));
      await tester.pumpAndSettle();

      expect(
        find.byKey(const ValueKey('s28-stalemate-banner')),
        findsOneWidget,
      );
      expect(find.byKey(const ValueKey('s28-checkmate-banner')), findsNothing);
      expect(find.byKey(const ValueKey('s28-winner-portrait')), findsNothing);
      expect(find.text('SELECTED PIECE'), findsNothing);
      expect(
        find.byWidgetPredicate(
          (widget) =>
              widget is Image &&
              widget.image is AssetImage &&
              (widget.image as AssetImage).assetName ==
                  matchStalemateBannerAsset,
        ),
        findsOneWidget,
      );
      expect(find.text('Play Again'), findsOneWidget);
      expect(find.text('Back to Lobby'), findsOneWidget);
      expect(find.text('Postgame Summary'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );

  for (final defeatedCourt in const <({String id, PieceColor color})>[
    (id: 'mercantile', color: PieceColor.white),
    (id: 'spy', color: PieceColor.black),
  ]) {
    testWidgets(
      'S28 King Trapfall uses ${defeatedCourt.id} defeat art and no checkmate banner',
      (tester) async {
        await setSurface(const Size(1280, 720));
        final controller = GameController()
          ..setupWhiteCountryId = defeatedCourt.color == PieceColor.white
              ? defeatedCourt.id
              : 'mercantile'
          ..setupBlackCountryId = defeatedCourt.color == PieceColor.black
              ? defeatedCourt.id
              : 'spy'
          ..startNewGame()
          ..winner = defeatedCourt.color == PieceColor.white
              ? PieceColor.black
              : PieceColor.white
          ..gameEndReason = GameEndReason.kingTrapfall
          ..phase = GamePhase.gameOver;
        addTearDown(controller.dispose);

        await tester.pumpWidget(testMatchApp(controller));
        await tester.pumpAndSettle();

        expect(
          find.byKey(const ValueKey('s28-trapfall-banner')),
          findsOneWidget,
        );
        expect(
          find.byKey(const ValueKey('s28-trapfall-portrait')),
          findsOneWidget,
        );
        expect(
          find.byKey(const ValueKey('s28-checkmate-banner')),
          findsNothing,
        );
        expect(find.text('KING TRAPFALL'), findsOneWidget);
        expect(find.text('Battlefield Trap'), findsOneWidget);
        expect(
          find.textContaining(
            '${defeatedCourt.color == PieceColor.white ? 'White' : 'Black'} King fell',
          ),
          findsOneWidget,
        );
        expect(tester.takeException(), isNull);
      },
    );
  }

  testWidgets('production board and result art keep match state live', (
    tester,
  ) async {
    await setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);
    GameControllerTestDriver(controller).foolsMate();

    await tester.pumpWidget(testMatchApp(controller));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s28-checkmate-banner')), findsOneWidget);
    expect(find.text('Turn Count'), findsOneWidget);
    expect(
      find.byKey(const ValueKey('final-board-dim-overlay')),
      findsOneWidget,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiPanel &&
            widget.backgroundAsset ==
                '$runtimeAssetRoot/ui/common/result_panel_9slice.webp' &&
            widget.backgroundCenterSlice ==
                const Rect.fromLTRB(104, 104, 920, 920) &&
            widget.padding == const EdgeInsets.fromLTRB(48, 52, 48, 84),
      ),
      findsOneWidget,
    );
    expect(find.text('Postgame Summary'), findsNothing);
    expect(
      tester.widget<Text>(find.text('Final Result')).style?.color,
      const Color(0xFF6A4B1F),
    );
    expect(
      tester
          .widget<Text>(
            find.text('The final board remains visible for review.'),
          )
          .style
          ?.color,
      const Color(0xFF5E4B2F),
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets(
    'S29 replays populated economy feedback without blocking controls',
    (tester) async {
      await setSurface(const Size(1600, 900));
      final controller = GameController();
      addTearDown(controller.dispose);
      GameControllerTestDriver(controller).foolsMate();
      controller.purchaseSuccesses = 2;
      controller.purchaseFailures = 1;
      controller.lastMerchantPayoutReceiver = PieceColor.black;

      await tester.pumpWidget(
        MaterialApp(
          theme: buildCrazyChessTheme(),
          home: Scaffold(
            body: ResponsiveGameViewport(
              child: PostgameSummaryScreen(
                controller: controller,
                onLobby: () {},
                onRematch: () {},
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      expect(find.textContaining('Postgame Summary'), findsOneWidget);
      expect(
        find.byKey(const ValueKey('vfx-offer-coin-trail')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('vfx-failure-coin-scatter')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('vfx-merchant-payout-coin-burst')),
        findsOneWidget,
      );
      expect(find.text('Lobby'), findsWidgets);
      expect(tester.takeException(), isNull);
    },
  );
}
