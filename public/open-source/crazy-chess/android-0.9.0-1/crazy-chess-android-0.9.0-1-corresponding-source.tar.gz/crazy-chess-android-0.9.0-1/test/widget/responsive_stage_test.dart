import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Future<void> setSurface(Size size) async {
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  await binding.setSurfaceSize(size);
  addTearDown(() => binding.setSurfaceSize(null));
}

void main() {
  for (final size in const <Size>[
    Size(1600, 900),
    Size(1280, 720),
    Size(1200, 900),
    Size(844, 390),
    Size(390, 844),
  ]) {
    testWidgets('fits setup stage inside ${size.width}x${size.height}', (
      tester,
    ) async {
      await setSurface(size);
      await tester.pumpWidget(const CrazyChessApp());
      await tester.pump();

      final stageRect = tester.getRect(find.byKey(StageMetrics.stageKey));
      expect(stageRect.left, greaterThanOrEqualTo(0));
      expect(stageRect.top, greaterThanOrEqualTo(0));
      expect(stageRect.right, lessThanOrEqualTo(size.width + 0.01));
      expect(stageRect.bottom, lessThanOrEqualTo(size.height + 0.01));
      expect(
        stageRect.width / stageRect.height,
        closeTo(StageMetrics.aspectRatio, 0.01),
      );
      expect(tester.takeException(), isNull);
    });
  }
}
