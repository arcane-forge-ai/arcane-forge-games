import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/ui/menu/hifi_menu_widgets.dart';
import 'package:crazy_chess/ui/menu/reference_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Future<void> setSurface(Size size) async {
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  await binding.setSurfaceSize(size);
  addTearDown(() => binding.setSurfaceSize(null));
}

void main() {
  test(
    'reference geometry preserves measured S02 plaque and S03 card ratios',
    () {
      const s02Plaques = [
        Rect.fromLTWH(924, 116, 642, 197),
        Rect.fromLTWH(925, 336, 638, 195),
        Rect.fromLTWH(925, 549, 638, 178),
      ];
      const s03Cards = [
        Rect.fromLTWH(119, 165, 516, 361),
        Rect.fromLTWH(678, 165, 492, 361),
        Rect.fromLTWH(51, 543, 344, 260),
        Rect.fromLTWH(422, 543, 371, 260),
        Rect.fromLTWH(810, 543, 388, 260),
      ];

      for (final sourceBounds in [...s02Plaques, ...s03Cards]) {
        final stageBounds = ReferenceGeometry.toStage(sourceBounds);
        final sourceAspect = sourceBounds.width / sourceBounds.height;
        final stageAspect = stageBounds.width / stageBounds.height;
        final aspectError = (stageAspect - sourceAspect).abs() / sourceAspect;
        expect(aspectError, lessThanOrEqualTo(.05));
        expect(
          stageBounds.left,
          closeTo(sourceBounds.left * 1600 / 1672, .001),
        );
        expect(stageBounds.top, closeTo(sourceBounds.top * 900 / 941, .001));
      }
    },
  );

  testWidgets('boots to S01 title screen', (tester) async {
    await setSurface(const Size(1280, 900));
    await tester.pumpWidget(const CrazyChessApp());
    await tester.pump();

    expect(find.text('Press Start'), findsOneWidget);
    expect(find.text('Plan. Trade. Dominate.'), findsOneWidget);
    expect(find.text('Latest News'), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                'assets/runtime/ui/title/screen_s01_title_hall_bg_a.webp',
      ),
      findsOneWidget,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                'assets/runtime/ui/title/ui_logo_crazy_chess_full.webp',
      ),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('s01-gold-motes')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('S01 asset composition fits desktop target viewports', (
    tester,
  ) async {
    final binding = TestWidgetsFlutterBinding.ensureInitialized();
    addTearDown(() => binding.setSurfaceSize(null));

    for (final size in const [Size(1600, 900), Size(1280, 720)]) {
      await binding.setSurfaceSize(size);
      await tester.pumpWidget(CrazyChessApp(key: ValueKey(size)));
      await tester.pump();

      expect(find.text('Press Start'), findsOneWidget);
      expect(find.text('Latest News'), findsOneWidget);
      expect(find.byKey(const ValueKey('s01-gold-motes')), findsOneWidget);
      final stageRect = tester.getRect(find.byKey(StageMetrics.stageKey));
      final exitRect = tester.getRect(find.byKey(const ValueKey('title-exit')));
      expect(stageRect.right - exitRect.right, lessThan(60));
      expect(stageRect.bottom - exitRect.bottom, lessThan(40));
      expect(tester.takeException(), isNull);
    }
  });

  testWidgets('title Settings opens S31', (tester) async {
    await setSurface(const Size(1280, 720));
    await tester.pumpWidget(const CrazyChessApp());
    await tester.pump();

    await tester.tap(find.byKey(const ValueKey('title-settings')));
    await tester.pumpAndSettle();

    expect(find.textContaining('S31  Settings'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('S31 Audio exposes persistent mixer controls', (tester) async {
    await setSurface(const Size(1280, 720));
    await tester.pumpWidget(const CrazyChessApp());
    await tester.pump();

    await tester.tap(find.byKey(const ValueKey('title-settings')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Audio'));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('audio-master-volume')), findsOneWidget);
    expect(find.byKey(const ValueKey('audio-music-volume')), findsOneWidget);
    expect(find.byKey(const ValueKey('audio-sfx-volume')), findsOneWidget);
    expect(find.byKey(const ValueKey('audio-master-mute')), findsOneWidget);
    expect(find.byKey(const ValueKey('audio-music-mute')), findsOneWidget);
    expect(find.byKey(const ValueKey('audio-sfx-mute')), findsOneWidget);
    expect(find.text('Saved on this device'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('title Exit opens confirmation without intercepting startup', (
    tester,
  ) async {
    await setSurface(const Size(1280, 720));
    await tester.pumpWidget(const CrazyChessApp());
    await tester.pump();

    await tester.tap(find.byKey(const ValueKey('title-exit')));
    await tester.pump(const Duration(milliseconds: 300));

    expect(find.text('Exit Crazy Chess?'), findsOneWidget);
    expect(find.text('Cancel'), findsOneWidget);
    expect(find.widgetWithText(FilledButton, 'Exit'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('navigates S01-S05 and starts a local match', (tester) async {
    await setSurface(const Size(1280, 900));
    await tester.pumpWidget(const CrazyChessApp());

    await tester.tap(find.text('Press Start'));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('s02-play')), findsOneWidget);
    expect(find.byKey(const ValueKey('s02-collection')), findsOneWidget);
    expect(find.byKey(const ValueKey('s02-court')), findsOneWidget);
    expect(find.byKey(const ValueKey('s02-settings')), findsOneWidget);
    expect(find.byKey(const ValueKey('s02-nav-country')), findsOneWidget);
    expect(find.text('S02  Main Lobby'), findsNothing);

    await tester.tap(find.byKey(const ValueKey('s02-play')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('s03-local-duel')), findsOneWidget);
    expect(find.byKey(const ValueKey('s03-ai-duel')), findsOneWidget);
    expect(find.byKey(const ValueKey('s03-story-campaign')), findsOneWidget);
    expect(
      find.byKey(const ValueKey('s03-last-piece-standing')),
      findsOneWidget,
    );
    expect(find.byKey(const ValueKey('s03-living-campaign')), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is ReferenceLayer &&
            widget.asset ==
                '$runtimeAssetRoot/scenes/setup/s03_local_duel_detail.webp',
      ),
      findsOneWidget,
    );

    await tester.tap(find.byKey(const ValueKey('s03-confirm')));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('s04-title')), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiPanel &&
            widget.backgroundAsset ==
                '$runtimeAssetRoot/ui/common/panel_parchment_9slice.webp',
      ),
      findsOneWidget,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiAssetSurface &&
            widget.asset ==
                '$runtimeAssetRoot/ui/common/setting_row_9slice.webp',
      ),
      findsNWidgets(7),
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiAssetSurface &&
            widget.asset ==
                '$runtimeAssetRoot/ui/common/segmented_default_9slice.webp',
      ),
      findsWidgets,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiAssetSurface &&
            widget.asset ==
                '$runtimeAssetRoot/ui/common/segmented_selected_9slice.webp',
      ),
      findsNWidgets(7),
    );

    await tester.tap(find.byKey(const ValueKey('s04-merchant-2')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('s04-continue')));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('battlefield-card-classic')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('battlefield-card-verdantPastures')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('battlefield-card-gildedBazaar')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('battlefield-card-ruinedCauseway')),
      findsOneWidget,
    );
    expect(find.text('CLASSIC COURT'), findsWidgets);

    await tester.tap(
      find.byKey(const ValueKey('battlefield-card-gildedBazaar')),
    );
    await tester.pumpAndSettle();
    expect(find.text('GILDED BAZAAR'), findsWidgets);
    await tester.tap(find.byKey(const ValueKey('battlefield-card-classic')));
    await tester.pumpAndSettle();
    expect(find.text('CLASSIC COURT'), findsWidgets);
    await tester.tap(find.byKey(const ValueKey('battlefield-continue')));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('s05-country-mercantile')),
      findsOneWidget,
    );
    expect(find.text('White Court'), findsOneWidget);
    expect(find.text('Black Court'), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiPanel &&
            widget.backgroundAsset ==
                '$runtimeAssetRoot/ui/common/panel_trait_parchment_9slice.webp',
      ),
      findsOneWidget,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiPrimaryButton &&
            widget.backgroundAsset ==
                '$runtimeAssetRoot/ui/common/button_start_match_9slice.webp',
      ),
      findsOneWidget,
    );

    await tester.tap(find.byKey(const ValueKey('s05-side-black')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s05-country-spy')));
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('representative-spy-full')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('representative-spy-placeholder')),
      findsNothing,
    );

    await tester.tap(find.byKey(const ValueKey('s05-confirm')));
    await tester.pump();
    expect(find.byKey(const ValueKey('s07-loading')), findsOneWidget);
    expect(find.byKey(const ValueKey('s07-enter-match')), findsNothing);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                '$runtimeAssetRoot/scenes/versus/battlefield_board.webp',
      ),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('representative-spy-full')),
      findsOneWidget,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiAssetSurface &&
            widget.asset ==
                '$runtimeAssetRoot/ui/common/loading_ribbon_9slice.webp',
      ),
      findsOneWidget,
    );

    await tester.pump(const Duration(milliseconds: 2500));
    expect(find.byKey(const ValueKey('s07-loading')), findsOneWidget);
    expect(find.byKey(const ValueKey('s07-enter-match')), findsNothing);

    await tester.pump(const Duration(milliseconds: 2600));
    expect(find.byKey(const ValueKey('s07-ready')), findsOneWidget);
    expect(find.byKey(const ValueKey('s07-enter-match')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('s07-enter-match')));
    await tester.pumpAndSettle();

    expect(find.textContaining('Merchant'), findsWidgets);
    expect(find.textContaining('Gold'), findsWidgets);
    expect(find.byKey(const ValueKey('s20-event-log-panel')), findsOneWidget);
    for (final asset in const [
      'assets/runtime/pieces/board/mercantile/square_light.webp',
      'assets/runtime/pieces/board/mercantile/square_dark.webp',
    ]) {
      expect(
        find.byWidgetPredicate(
          (widget) =>
              widget is Image &&
              widget.image is AssetImage &&
              (widget.image as AssetImage).assetName == asset,
        ),
        findsWidgets,
      );
    }
    expect(
      find.byKey(const ValueKey('piece-art-token-mercantile_queen-white')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('battlefield-board-classic')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('locked S03 modes do not leave mode select', (tester) async {
    await setSurface(const Size(1280, 900));
    await tester.pumpWidget(const CrazyChessApp());

    await tester.tap(find.text('Press Start'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s02-play')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('s03-ai-duel')));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('s03-local-duel')), findsOneWidget);
    expect(find.textContaining('Create Match'), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Living Campaign opens its local run hub', (tester) async {
    await setSurface(const Size(1280, 900));
    await tester.pumpWidget(const CrazyChessApp());

    await tester.tap(find.text('Press Start'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s02-play')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s03-living-campaign')));
    await tester.pump();
    await tester.tap(find.byKey(const ValueKey('s03-confirm')));
    await tester.pumpAndSettle();

    expect(find.byKey(const ValueKey('living-campaign-hub')), findsOneWidget);
    expect(find.text('THE STORY REMEMBERS'), findsWidgets);
    expect(find.byKey(const ValueKey('living-hub-settings')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('S05 details opens S06 country detail', (tester) async {
    await setSurface(const Size(1280, 900));
    await tester.pumpWidget(const CrazyChessApp());

    await tester.tap(find.text('Press Start'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s02-play')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s03-confirm')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s04-continue')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('battlefield-continue')));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Details'));
    await tester.pumpAndSettle();

    expect(find.textContaining('Country Detail'), findsOneWidget);
    expect(find.text('Mercantile League'), findsWidgets);
    expect(find.text('Inspect Piece'), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is HifiAssetSurface &&
            widget.asset ==
                '$runtimeAssetRoot/ui/common/role_preview_card_9slice.webp',
      ),
      findsNWidgets(6),
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('lobby routes to remaining product pages', (tester) async {
    await setSurface(const Size(1280, 900));
    await tester.pumpWidget(const CrazyChessApp());

    await tester.tap(find.text('Press Start'));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('s02-play')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('s02-court')));
    await tester.pumpAndSettle();
    expect(find.textContaining('Court Dorm'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('product-lobby')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s02-collection')));
    await tester.pumpAndSettle();
    expect(find.textContaining('Collection Matrix'), findsOneWidget);

    await tester.tap(find.text('View Profile'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Piece Profile'), findsOneWidget);

    await tester.tap(find.text('Visual Loadout'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Decoration Loadout'), findsOneWidget);

    await tester.tap(find.text('Rules').first);
    await tester.pumpAndSettle();
    expect(find.textContaining('Tutorial Rules'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('product-settings')));
    await tester.pumpAndSettle();
    expect(find.textContaining('S31  Settings'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('product-lobby')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s02-nav-records')));
    await tester.pumpAndSettle();
    expect(find.textContaining('Postgame Summary'), findsOneWidget);
    expect(find.text('No Record Yet'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('production assets back S02 and S31 at target viewports', (
    tester,
  ) async {
    final binding = TestWidgetsFlutterBinding.ensureInitialized();
    addTearDown(() => binding.setSurfaceSize(null));

    for (final size in const [Size(1600, 900), Size(1280, 720)]) {
      await binding.setSurfaceSize(size);
      await tester.pumpWidget(CrazyChessApp(key: ValueKey('production-$size')));
      await tester.tap(find.text('Press Start'));
      await tester.pumpAndSettle();

      expect(
        find.byWidgetPredicate(
          (widget) =>
              widget is Image &&
              widget.image is AssetImage &&
              (widget.image as AssetImage).assetName ==
                  '$runtimeAssetRoot/scenes/setup/s02_lobby_court_bg.webp',
        ),
        findsOneWidget,
      );
      expect(
        find.byWidgetPredicate(
          (widget) =>
              widget is Image &&
              widget.image is AssetImage &&
              (widget.image as AssetImage).assetName ==
                  '$runtimeAssetRoot/pieces/countries/mercantile/representative_full_neutral.webp',
        ),
        findsOneWidget,
      );

      await tester.tap(find.byKey(const ValueKey('s02-settings')));
      await tester.pumpAndSettle();
      expect(find.textContaining('S31  Settings'), findsOneWidget);
      expect(
        find.byWidgetPredicate(
          (widget) =>
              widget is Image &&
              widget.image is AssetImage &&
              (widget.image as AssetImage).assetName ==
                  '$productionAssetRoot/s31_settings_bg.webp',
        ),
        findsOneWidget,
      );
      final stageRect = tester.getRect(find.byKey(StageMetrics.stageKey));
      expect(stageRect.right, lessThanOrEqualTo(size.width + .01));
      expect(stageRect.bottom, lessThanOrEqualTo(size.height + .01));
      expect(tester.takeException(), isNull);
    }
  });
}
