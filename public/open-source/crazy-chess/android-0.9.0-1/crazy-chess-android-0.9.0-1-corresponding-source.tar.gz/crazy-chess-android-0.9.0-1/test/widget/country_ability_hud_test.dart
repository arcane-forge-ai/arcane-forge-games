import 'package:crazy_chess/app/theme.dart';
import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/l10n/app_localizations.dart';
import 'package:crazy_chess/l10n/runtime_game_locale.dart';
import 'package:crazy_chess/ui/match/match_screen.dart';
import 'package:crazy_chess/ui/shared/country_ability_copy.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/game_controller_test_driver.dart';

Future<void> _setSurface(Size size) async {
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  await binding.setSurfaceSize(size);
  addTearDown(() => binding.setSurfaceSize(null));
}

Widget _matchApp(
  GameController controller, {
  Locale locale = const Locale('en'),
}) {
  return MaterialApp(
    locale: locale,
    localizationsDelegates: AppLocalizations.localizationsDelegates,
    supportedLocales: AppLocalizations.supportedLocales,
    theme: buildCrazyChessTheme(),
    home: AnimatedBuilder(
      animation: controller,
      builder: (context, _) => Scaffold(
        body: ResponsiveGameViewport(
          child: MatchScreen(controller: controller),
        ),
      ),
    ),
  );
}

void main() {
  tearDown(() => RuntimeGameLocale.setLocale(const Locale('en')));

  test('every country has short and exact bilingual ability copy', () {
    RuntimeGameLocale.setLocale(const Locale('en'));
    final english = {
      for (final country in countries.values)
        country.id: (
          countrySignatureTrait(country),
          countryRuleDetails(country),
        ),
    };

    RuntimeGameLocale.setLocale(const Locale('zh'));
    for (final country in countries.values) {
      expect(countrySignatureTrait(country), isNotEmpty);
      expect(countryRuleDetails(country), isNotEmpty);
      expect(countrySignatureTrait(country), isNot(english[country.id]!.$1));
      expect(countryRuleDetails(country), isNot(english[country.id]!.$2));
    }
  });

  testWidgets('both live court plates open exact rules without mutating match', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    RuntimeGameLocale.setLocale(const Locale('en'));
    final controller = GameController();
    addTearDown(controller.dispose);
    final driver = GameControllerTestDriver(controller)
      ..startGame(whiteCountry: 'corsair', blackCountry: 'sunlit');

    await tester.pumpWidget(_matchApp(controller));
    await tester.pumpAndSettle();

    final whiteButton = find.byKey(const ValueKey('country-ability-white'));
    final blackButton = find.byKey(const ValueKey('country-ability-black'));
    expect(whiteButton, findsOneWidget);
    expect(blackButton, findsOneWidget);
    expect(tester.getRect(whiteButton).height, greaterThanOrEqualTo(28));
    expect(tester.getRect(blackButton).height, greaterThanOrEqualTo(28));

    final whiteTooltip = tester.widget<Tooltip>(
      find.ancestor(of: whiteButton, matching: find.byType(Tooltip)),
    );
    expect(whiteTooltip.message, 'Every capture steals up to 6 Gold.');

    final before = driver.snapshot();
    await tester.tap(whiteButton);
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('country-ability-dialog-corsair-white')),
      findsOneWidget,
    );
    expect(find.text('Corsair Freeholds'), findsOneWidget);
    expect(
      find.text(
        'While economy is enabled, every capture transfers up to 6 Gold from the opposing treasury.',
      ),
      findsOneWidget,
    );
    expect(find.text('Reference only — no action spent'), findsOneWidget);
    expect(find.textContaining('SUCCESS CHANCE'), findsNothing);
    expect(find.textContaining('FAIR COST'), findsNothing);

    await tester.tap(find.byKey(const ValueKey('country-ability-done')));
    await tester.pumpAndSettle();
    expect(driver.snapshot(), before);

    await tester.tap(blackButton);
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('country-ability-dialog-sunlit-black')),
      findsOneWidget,
    );
    expect(find.text('Sunlit Synod'), findsOneWidget);
    expect(
      find.textContaining('Losing the final Bishop halves allied Loyalty'),
      findsOneWidget,
    );

    await tester.tap(find.byKey(const ValueKey('country-ability-close')));
    await tester.pumpAndSettle();
    expect(driver.snapshot(), before);
    expect(tester.takeException(), isNull);
  });

  testWidgets('ability HUD and exact rule card are localized in Chinese', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    const locale = Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hans');
    RuntimeGameLocale.setLocale(locale);
    final controller = GameController();
    addTearDown(controller.dispose);
    GameControllerTestDriver(
      controller,
    ).startGame(whiteCountry: 'horse', blackCountry: 'spy');

    await tester.pumpWidget(_matchApp(controller, locale: locale));
    await tester.pumpAndSettle();

    final whiteButton = find.byKey(const ValueKey('country-ability-white'));
    final tooltip = tester.widget<Tooltip>(
      find.ancestor(of: whiteButton, matching: find.byType(Tooltip)),
    );
    expect(tooltip.message, '针对马的报价获得公允价修正；马吃子会冲击忠诚。');

    await tester.tap(whiteButton);
    await tester.pumpAndSettle();

    expect(find.text('阵营特性'), findsOneWidget);
    expect(find.text('骏马王国'), findsOneWidget);
    expect(find.text('公开修正'), findsOneWidget);
    expect(find.text('仅供参考 · 不消耗行动'), findsOneWidget);
    expect(find.textContaining('所有存活敌方非王棋子忠诚 -10'), findsOneWidget);
    expect(find.text('完成'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
