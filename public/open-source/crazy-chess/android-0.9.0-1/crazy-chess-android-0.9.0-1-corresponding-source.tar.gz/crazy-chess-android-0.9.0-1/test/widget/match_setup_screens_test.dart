import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/app/theme.dart';
import 'package:crazy_chess/l10n/app_localizations.dart';
import 'package:crazy_chess/l10n/runtime_game_locale.dart';
import 'package:crazy_chess/ui/menu/match_setup_screens.dart';
import 'package:crazy_chess/ui/menu/reference_layout.dart';
import 'package:crazy_chess/ui/menu/versus_loading_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Future<void> _setSurface(Size size) async {
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  await binding.setSurfaceSize(size);
  addTearDown(() => binding.setSurfaceSize(null));
}

Widget _stage(Widget child, {Locale locale = const Locale('en')}) {
  RuntimeGameLocale.setLocale(locale);
  return MaterialApp(
    locale: locale,
    supportedLocales: AppLocalizations.supportedLocales,
    localizationsDelegates: AppLocalizations.localizationsDelegates,
    theme: buildCrazyChessTheme(locale: locale),
    home: Scaffold(body: ResponsiveGameViewport(child: child)),
  );
}

void main() {
  test('S04 S05 and S07 measured zones preserve the reference transform', () {
    const zones = [
      MatchSettingsScreen.settingsBounds,
      MatchSettingsScreen.explanationBounds,
      MatchSettingsScreen.continueBounds,
      CountrySelectScreen.portraitBounds,
      CountrySelectScreen.gridBounds,
      CountrySelectScreen.traitBounds,
      VersusLoadingScreen.leftPortraitBounds,
      VersusLoadingScreen.boardBounds,
      VersusLoadingScreen.rightPortraitBounds,
      VersusLoadingScreen.loadingBounds,
    ];
    for (final source in zones) {
      final stage = ReferenceGeometry.toStage(source);
      expect(stage.left, closeTo(source.left * 1600 / 1672, .001));
      expect(stage.top, closeTo(source.top * 900 / 941, .001));
      expect(stage.width, closeTo(source.width * 1600 / 1672, .001));
      expect(stage.height, closeTo(source.height * 900 / 941, .001));
    }
  });

  testWidgets('S04 exposes economy settings and resets their defaults', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);
    var wentBack = false;
    var continued = false;

    await tester.pumpWidget(
      _stage(
        AnimatedBuilder(
          animation: controller,
          builder: (context, _) => MatchSettingsScreen(
            controller: controller,
            onBack: () => wentBack = true,
            onContinue: () => continued = true,
          ),
        ),
      ),
    );
    await tester.pump();

    expect(find.byKey(const ValueKey('s04-match-local')), findsOneWidget);
    expect(find.byKey(const ValueKey('s04-match-ai')), findsOneWidget);
    expect(find.byKey(const ValueKey('s04-match-custom')), findsOneWidget);
    expect(find.byKey(const ValueKey('s04-load-preset')), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('s04-merchant-1')));
    await tester.tap(find.byKey(const ValueKey('s04-starting-gold-14')));
    await tester.tap(find.byKey(const ValueKey('s04-merchant-payout-12')));
    await tester.pump();
    expect(controller.setupMerchantSpeed, 1);
    expect(controller.setupStartingGold, 14);
    expect(controller.setupMerchantPayout, 12);
    controller.setBattlefield(BattlefieldId.ruinedCauseway);

    await tester.tap(find.byKey(const ValueKey('s04-reset')));
    await tester.pump();
    expect(controller.setupMerchantSpeed, 4);
    expect(controller.setupStartingGold, 10);
    expect(controller.setupMerchantPayout, 8);
    expect(controller.setupBattlefieldId, BattlefieldId.classic);

    await tester.tap(find.byKey(const ValueKey('s04-continue')));
    await tester.tap(find.byKey(const ValueKey('s04-back')));
    expect(continued, isTrue);
    expect(wentBack, isTrue);
    expect(tester.takeException(), isNull);
  });

  testWidgets('S05 edits both courts and never reuses Mercantile art', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);
    var selectedSide = PieceColor.white;
    var openedDetails = false;
    var confirmed = false;

    await tester.pumpWidget(
      _stage(
        StatefulBuilder(
          builder: (context, setState) => AnimatedBuilder(
            animation: controller,
            builder: (context, _) => CountrySelectScreen(
              controller: controller,
              selectedSide: selectedSide,
              onSelectedSideChanged: (side) {
                setState(() => selectedSide = side);
              },
              onBack: () {},
              onDetails: () => openedDetails = true,
              onStart: () => confirmed = true,
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    for (final country in selectableCountries) {
      expect(find.byKey(ValueKey('s05-country-${country.id}')), findsOneWidget);
    }
    expect(
      find.byKey(const ValueKey('s05-country-ashen')),
      findsNothing,
      reason: 'The Ashen Court is exclusive to Living Campaign.',
    );
    for (var index = 1; index <= 6; index++) {
      expect(find.byKey(ValueKey('s05-future-$index')), findsOneWidget);
    }
    expect(
      find.byKey(const ValueKey('representative-mercantile-full')),
      findsOneWidget,
    );

    await tester.tap(find.byKey(const ValueKey('s05-side-black')));
    await tester.pump();
    await tester.tap(find.byKey(const ValueKey('s05-country-horse')));
    await tester.pump();
    expect(controller.setupBlackCountryId, 'horse');
    expect(
      find.byKey(const ValueKey('representative-horse-placeholder')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('representative-mercantile-full')),
      findsNothing,
    );

    await tester.tap(find.byKey(const ValueKey('s05-country-spy')));
    await tester.pump();
    expect(
      find.byKey(const ValueKey('representative-spy-full')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('representative-spy-placeholder')),
      findsNothing,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                'assets/runtime/pieces/characters/match/spy_king_portrait.webp',
      ),
      findsOneWidget,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                'assets/runtime/ui/match/mercantile_spy/spy_crest.webp',
      ),
      findsWidgets,
    );

    await tester.tap(find.byKey(const ValueKey('s05-details')));
    await tester.tap(find.byKey(const ValueKey('s05-confirm')));
    expect(openedDetails, isTrue);
    expect(confirmed, isTrue);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Chinese S06 keeps every authored production country card', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    const locale = Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hans');
    final controller = GameController();
    addTearDown(controller.dispose);
    addTearDown(() => RuntimeGameLocale.setLocale(const Locale('en')));

    await tester.pumpWidget(
      _stage(
        CountrySelectScreen(
          controller: controller,
          selectedSide: PieceColor.white,
          onSelectedSideChanged: (_) {},
          onBack: () {},
          onDetails: () {},
          onStart: () {},
        ),
        locale: locale,
      ),
    );
    await tester.pump();

    for (final id in const ['mercantile', 'iron', 'horse', 'spy']) {
      expect(
        find.byWidgetPredicate(
          (widget) =>
              widget is Image &&
              widget.image is AssetImage &&
              (widget.image as AssetImage).assetName ==
                  'assets/runtime/ui/country_select/${id}_card.webp',
        ),
        findsOneWidget,
        reason: '$id must not fall back to a generic Chinese card.',
      );
    }
    expect(find.bySemanticsLabel(RegExp('商贸联盟')), findsWidgets);
    expect(find.bySemanticsLabel(RegExp('铁壁公国')), findsWidgets);
    expect(find.bySemanticsLabel(RegExp('骏马王国')), findsWidgets);
    expect(find.bySemanticsLabel(RegExp('谍影王庭')), findsWidgets);
    expect(tester.takeException(), isNull);
  });

  testWidgets('S07 loads for five seconds and enters only after a click', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);
    controller.setupBlackCountryId = 'spy';
    var starts = 0;
    var wentBack = false;

    await tester.pumpWidget(
      _stage(
        VersusLoadingScreen(
          controller: controller,
          onBack: () => wentBack = true,
          onStartMatch: () => starts += 1,
        ),
      ),
    );
    await tester.pump();
    expect(find.byKey(const ValueKey('s07-loading')), findsOneWidget);
    expect(find.byKey(const ValueKey('s07-enter-match')), findsNothing);
    expect(
      find.byKey(const ValueKey('representative-spy-full')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('representative-spy-placeholder')),
      findsNothing,
    );
    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is Image &&
            widget.image is AssetImage &&
            (widget.image as AssetImage).assetName ==
                'assets/runtime/ui/match/mercantile_spy/spy_crest.webp',
      ),
      findsWidgets,
    );
    expect(starts, 0);

    await tester.pump(const Duration(milliseconds: 2500));
    expect(find.byKey(const ValueKey('s07-loading')), findsOneWidget);
    expect(find.byKey(const ValueKey('s07-enter-match')), findsNothing);
    expect(starts, 0);

    await tester.pump(const Duration(milliseconds: 2501));
    expect(find.byKey(const ValueKey('s07-ready')), findsOneWidget);
    expect(find.byKey(const ValueKey('s07-enter-match')), findsOneWidget);
    expect(starts, 0);

    await tester.tap(find.byKey(const ValueKey('s07-enter-match')));
    expect(starts, 1);
    await tester.tap(find.byKey(const ValueKey('s07-back')));
    expect(wentBack, isTrue);
    expect(tester.takeException(), isNull);
  });
}
