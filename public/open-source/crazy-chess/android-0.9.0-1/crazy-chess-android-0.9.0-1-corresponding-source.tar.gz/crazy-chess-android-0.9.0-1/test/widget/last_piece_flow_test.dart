import 'dart:async';
import 'dart:math' as math;

import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/ui/menu/remaining_flow_screens.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

class _MemoryProfileStore implements LastPieceProfileStore {
  String? value;

  @override
  Future<String?> read() async => value;

  @override
  Future<void> write(String value) async {
    this.value = value;
  }
}

LastPieceSessionController _controller({LastPieceLevelCatalog? catalog}) {
  return LastPieceSessionController(
    catalog: catalog,
    random: math.Random(8),
    profileRepository: LastPieceProfileRepository(store: _MemoryProfileStore()),
  );
}

Future<void> _setSurface(WidgetTester tester, Size size) async {
  await tester.binding.setSurfaceSize(size);
  addTearDown(() => tester.binding.setSurfaceSize(null));
}

Widget _stage(Widget child) {
  return MaterialApp(
    home: Scaffold(body: ResponsiveGameViewport(child: child)),
  );
}

void main() {
  testWidgets('full run screen captures through the occupied square hitbox', (
    tester,
  ) async {
    await _setSurface(tester, const Size(1600, 900));
    final controller = _controller()..startRun(runSeed: 80);
    addTearDown(controller.dispose);
    final presentationCoordinator = LastPiecePresentationCoordinator(
      controller: controller,
    )..setReducedMotion(true);
    addTearDown(presentationCoordinator.dispose);
    controller.debugReplaceBoard(
      playerUnit: const LastPieceUnit(
        id: 'player',
        type: PieceType.queen,
        square: Square(4, 3),
      ),
      enemyUnits: const [
        LastPieceUnit(
          id: 'capture-target',
          type: PieceType.pawn,
          square: Square(3, 3),
        ),
      ],
    );

    await tester.pumpWidget(
      _stage(
        AnimatedBuilder(
          animation: Listenable.merge([controller, presentationCoordinator]),
          builder: (context, _) => LastPieceRunScreen(
            controller: controller,
            presentationCoordinator: presentationCoordinator,
            onMove: (square) => unawaited(controller.movePlayer(square)),
            onPromotion: (_) {},
            onRetire: () {},
            onBackToLadder: () {},
          ),
        ),
      ),
    );

    final captureSquare = find.byKey(const ValueKey('last-piece-square-3-3'));
    expect(captureSquare, findsOneWidget);
    await tester.tapAt(tester.getCenter(captureSquare));
    await tester.pumpAndSettle();

    expect(controller.player.square, const Square(3, 3));
    expect(
      controller.enemies.any((unit) => unit.id == 'capture-target'),
      isFalse,
    );
    expect(controller.captureCounts[PieceType.pawn], 1);
    expect(tester.takeException(), isNull);
  });

  for (final size in const [Size(1600, 900), Size(1280, 720)]) {
    testWidgets('S03 routes into Last Piece run at ${size.width.toInt()}', (
      tester,
    ) async {
      await _setSurface(tester, size);
      await tester.pumpWidget(const CrazyChessApp());

      await tester.tap(find.text('Press Start'));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('s02-play')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('s03-last-piece-standing')));
      await tester.pump();

      expect(find.text('LAST PIECE STANDING'), findsWidgets);
      expect(find.text('3 LEVELS AT LAUNCH · 50+ READY'), findsOneWidget);
      expect(tester.takeException(), isNull);

      await tester.tap(find.byKey(const ValueKey('s03-confirm')));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('last-piece-country-grid')),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);

      await tester.tap(find.byKey(const ValueKey('last-piece-country-horse')));
      await tester.tap(
        find.byKey(const ValueKey('last-piece-country-continue')),
      );
      await tester.pumpAndSettle();

      expect(
        find.byKey(const ValueKey('last-piece-level-001')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('last-piece-level-002')),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
      await tester.tap(find.byKey(const ValueKey('last-piece-level-start')));
      await tester.pumpAndSettle();

      expect(find.text('SURVIVAL STATUS'), findsOneWidget);
      expect(find.text('SCORE'), findsOneWidget);
      expect(find.byKey(const ValueKey('last-piece-retire')), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }

  testWidgets('retirement reaches results with the complete action set', (
    tester,
  ) async {
    await _setSurface(tester, const Size(1600, 900));
    await tester.pumpWidget(const CrazyChessApp());
    await tester.tap(find.text('Press Start'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s02-play')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('s03-last-piece-standing')));
    await tester.tap(find.byKey(const ValueKey('s03-confirm')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('last-piece-country-continue')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('last-piece-level-start')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const ValueKey('last-piece-retire')));
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('last-piece-result-title')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('last-piece-result-retry')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('last-piece-result-next')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('last-piece-result-ladder')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('last-piece-result-court')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('last-piece-result-lobby')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('level ladder scrolls through a 50-entry locked catalog', (
    tester,
  ) async {
    await _setSurface(tester, const Size(1280, 720));
    final levels = <LastPieceLevelDefinition>[
      for (var index = 1; index <= 50; index++)
        LastPieceLevelDefinition(
          id: index.toString().padLeft(3, '0'),
          title: 'Endless Trial $index',
          prerequisiteId: index == 1
              ? null
              : (index - 1).toString().padLeft(3, '0'),
          startingPiece: PieceType.queen,
          startingSquare: const Square(4, 3),
          initialEnemies: 1,
          spawnInterval: 3,
          enemyWeights: const {PieceType.pawn: 100},
          scoreMilestones: const [300, 700, 1200],
          rewardTileInterval: 4,
          maxRewardTiles: 2,
          firstPassBonus: 20,
          presentationTag: 'test',
        ),
    ];
    final controller = _controller(
      catalog: LastPieceLevelCatalog(version: 1, levels: levels),
    );
    addTearDown(controller.dispose);
    await tester.pumpWidget(
      _stage(
        LastPieceLevelLadderScreen(
          controller: controller,
          onBack: () {},
          onStart: () {},
        ),
      ),
    );
    await tester.pump();

    expect(find.byKey(const ValueKey('last-piece-level-001')), findsOneWidget);
    await tester.scrollUntilVisible(
      find.byKey(const ValueKey('last-piece-level-050')),
      700,
      scrollable: find.descendant(
        of: find.byKey(const ValueKey('last-piece-level-list')),
        matching: find.byType(Scrollable),
      ),
    );

    expect(find.byKey(const ValueKey('last-piece-level-050')), findsOneWidget);
    expect(find.text('LOCKED'), findsWidgets);
    expect(tester.takeException(), isNull);
  });

  for (final size in const [Size(1600, 900), Size(1280, 720)]) {
    testWidgets('dense survival HUD fits at ${size.width.toInt()}', (
      tester,
    ) async {
      await _setSurface(tester, size);
      final controller = _controller()..startRun(runSeed: 81);
      addTearDown(controller.dispose);
      final presentationCoordinator = LastPiecePresentationCoordinator(
        controller: controller,
      )..setReducedMotion(true);
      addTearDown(presentationCoordinator.dispose);
      final enemies = <LastPieceUnit>[
        for (var col = 0; col < 8; col++)
          LastPieceUnit(
            id: 'top-$col',
            type: PieceType.pawn,
            square: Square(0, col),
          ),
        for (var col = 0; col < 6; col++)
          LastPieceUnit(
            id: 'second-$col',
            type: PieceType.knight,
            square: Square(1, col),
          ),
      ];
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: enemies,
        forcedScore: 845,
        forcedSurvivedPhases: 37,
      );

      await tester.pumpWidget(
        _stage(
          LastPieceRunScreen(
            controller: controller,
            presentationCoordinator: presentationCoordinator,
            onMove: (_) {},
            onPromotion: (_) {},
            onRetire: () {},
            onBackToLadder: () {},
          ),
        ),
      );
      await tester.pump();

      expect(find.text('14'), findsWidgets);
      expect(find.text('SURVIVAL STATUS'), findsOneWidget);
      expect(find.text('3 enemies every 3 phases'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }

  testWidgets(
    'milestone banner is non-blocking and Court rewards are visible',
    (tester) async {
      await _setSurface(tester, const Size(1600, 900));
      final controller = _controller()..startRun(runSeed: 82);
      addTearDown(controller.dispose);
      final presentationCoordinator = LastPiecePresentationCoordinator(
        controller: controller,
      )..setReducedMotion(true);
      addTearDown(presentationCoordinator.dispose);
      controller.debugReplaceBoard(
        playerUnit: const LastPieceUnit(
          id: 'player',
          type: PieceType.queen,
          square: Square(4, 3),
        ),
        enemyUnits: const [
          LastPieceUnit(id: 'pawn', type: PieceType.pawn, square: Square(0, 0)),
        ],
        forcedScore: 295,
      );
      await controller.debugRunEnemyPhase();

      await tester.pumpWidget(
        _stage(
          LastPieceRunScreen(
            controller: controller,
            presentationCoordinator: presentationCoordinator,
            onMove: (_) {},
            onPromotion: (_) {},
            onRetire: () {},
            onBackToLadder: () {},
          ),
        ),
      );
      await tester.pump();

      expect(
        find.byKey(const ValueKey('last-piece-milestone-banner')),
        findsOneWidget,
      );
      expect(find.textContaining('LEVEL PASSED'), findsOneWidget);

      controller.profile.countryFamiliarity['mercantile'] = 100;
      controller.profile.rewardUnlockIds.addAll({
        'mercantile:chronicle1',
        'mercantile:gallery1',
        'mercantile:music_court',
        'mercantile:music_battle',
      });
      await tester.pumpWidget(
        _stage(
          CourtDormScreen(
            lastPieceController: controller,
            countryId: 'mercantile',
            onCountryChanged: (_) {},
            onLobby: () {},
            onCollection: () {},
            onProfile: () {},
            onLoadout: () {},
            onRecords: () {},
            onRules: () {},
            onSettings: () {},
          ),
        ),
      );
      await tester.pump();

      expect(find.text('100 FAMILIARITY'), findsOneWidget);
      expect(find.text('Chronicle I'), findsOneWidget);
      expect(find.text('Court Theme'), findsOneWidget);
      expect(find.text('Battle Anthem'), findsOneWidget);
      expect(find.text('Gallery I'), findsOneWidget);
      expect(find.text('OPEN'), findsNWidgets(4));
      await tester.tap(find.byKey(const ValueKey('court-gallery-mercantile')));
      await tester.pumpAndSettle();
      expect(find.textContaining('Status: brief only'), findsOneWidget);
      expect(
        find.textContaining('No Gallery I image candidates'),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    },
  );
}
