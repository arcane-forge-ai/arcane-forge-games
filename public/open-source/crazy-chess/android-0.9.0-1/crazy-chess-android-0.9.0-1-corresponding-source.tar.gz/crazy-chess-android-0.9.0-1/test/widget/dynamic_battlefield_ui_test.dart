import 'dart:math' as math;

import 'package:crazy_chess/crazy_chess.dart';
import 'package:crazy_chess/ui/match/match_screen.dart';
import 'package:crazy_chess/ui/menu/battlefield_select_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Future<void> _setSurface(Size size) async {
  final binding = TestWidgetsFlutterBinding.ensureInitialized();
  await binding.setSurfaceSize(size);
  addTearDown(() => binding.setSurfaceSize(null));
}

Widget _match(GameController controller) {
  return MaterialApp(
    home: Scaffold(
      body: ResponsiveGameViewport(
        child: AnimatedBuilder(
          animation: controller,
          builder: (context, _) => MatchScreen(controller: controller),
        ),
      ),
    ),
  );
}

void main() {
  testWidgets('live board shows selected theme, tile decal, and charge', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    final controller =
        GameController(random: math.Random(20260730), battlefieldSeed: 411)
          ..setBattlefield(BattlefieldId.verdantPastures)
          ..startNewGame();
    addTearDown(controller.dispose);
    controller.replaceSpecialTilesForTesting(const <SpecialTileState>[
      SpecialTileState(
        square: Square(4, 0),
        type: SpecialTileType.knightShrine,
        pairId: 1,
        progress: 2,
        occupantPieceId: 'holding-piece',
      ),
      SpecialTileState(
        square: Square(4, 1),
        type: SpecialTileType.treasureChest,
        pairId: 2,
      ),
      SpecialTileState(
        square: Square(4, 2),
        type: SpecialTileType.diamondRing,
        pairId: 3,
        progress: 1,
      ),
      SpecialTileState(
        square: Square(4, 3),
        type: SpecialTileType.visibleTrap,
        pairId: 4,
        progress: 1,
      ),
      SpecialTileState(
        square: Square(4, 4),
        type: SpecialTileType.mystery,
        pairId: 5,
      ),
    ]);

    await tester.pumpWidget(_match(controller));
    await tester.pump();

    expect(
      find.byKey(const ValueKey('special-tile-4-0-knightShrine')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('special-tile-charge-4-0')),
      findsOneWidget,
    );
    expect(find.text('2/3'), findsOneWidget);
    for (final entry in const <(int, SpecialTileType)>[
      (0, SpecialTileType.knightShrine),
      (1, SpecialTileType.treasureChest),
      (2, SpecialTileType.diamondRing),
      (3, SpecialTileType.visibleTrap),
      (4, SpecialTileType.mystery),
    ]) {
      expect(
        find.byKey(ValueKey('special-tile-art-4-${entry.$1}-${entry.$2.name}')),
        findsOneWidget,
      );
    }
    expect(
      find.byKey(const ValueKey('battlefield-board-verdantPastures')),
      findsOneWidget,
    );
    expect(find.text('VERDANT PASTURES'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pump(const Duration(seconds: 3));
  });

  testWidgets(
    'Ring inventory and eligible offer are visible without Loyalty leak',
    (tester) async {
      await _setSurface(const Size(1600, 900));
      final controller =
          GameController(random: math.Random(20260730), battlefieldSeed: 812)
            ..setBattlefield(BattlefieldId.gildedBazaar)
            ..startNewGame();
      addTearDown(controller.dispose);
      controller
        ..gold[PieceColor.white] = 200
        ..diamondRingTokens[PieceColor.white] = 1;
      const target = Square(1, 0);
      controller.board[target.row][target.col] = ChessPiece(
        id: 'ui-ring-queen',
        type: PieceType.queen,
        color: PieceColor.black,
        countryId: 'iron',
        loyalty: 60,
        fairPrice: 40,
      );

      await tester.pumpWidget(_match(controller));
      await tester.pump();
      expect(find.byKey(const ValueKey('diamond-ring-white')), findsOneWidget);

      controller.tapSquare(target);
      controller.openOfferForSelected();
      controller.setOfferGold(40);
      await tester.pump();

      expect(
        find.byKey(const ValueKey('s22-diamond-ring-armed')),
        findsOneWidget,
      );
      expect(find.text('RING +50'), findsOneWidget);
      expect(find.textContaining('Loyalty 60'), findsNothing);
      expect(tester.takeException(), isNull);
      await tester.pump(const Duration(seconds: 3));
    },
  );

  testWidgets('battlefield event appears as a bounded live toast', (
    tester,
  ) async {
    await _setSurface(const Size(1280, 720));
    final controller =
        GameController(random: math.Random(20260730), battlefieldSeed: 140)
          ..setBattlefield(BattlefieldId.ruinedCauseway)
          ..startNewGame();
    addTearDown(controller.dispose);

    await tester.pumpWidget(_match(controller));
    await tester.pump();

    expect(
      find.byKey(const ValueKey('battlefield-event-toast')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('battlefield-event-message')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);

    await tester.pump(const Duration(seconds: 3));
    expect(find.byKey(const ValueKey('battlefield-event-toast')), findsNothing);
  });

  testWidgets('Chaos Crucible is selectable and explains exact cadence', (
    tester,
  ) async {
    await _setSurface(const Size(1600, 900));
    final controller = GameController();
    addTearDown(controller.dispose);

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ResponsiveGameViewport(
            child: AnimatedBuilder(
              animation: controller,
              builder: (context, _) => BattlefieldSelectScreen(
                controller: controller,
                onBack: () {},
                onContinue: () {},
              ),
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    final chaosCard = find.byKey(
      const ValueKey('battlefield-card-chaosCrucible'),
    );
    await tester.drag(find.byType(GridView), const Offset(0, -360));
    await tester.pumpAndSettle();
    await tester.tapAt(tester.getTopLeft(chaosCard) + const Offset(28, 28));
    await tester.pump();

    expect(controller.setupBattlefieldId, BattlefieldId.chaosCrucible);
    expect(find.text('CHAOS CRUCIBLE'), findsWidgets);
    expect(find.textContaining('every 3 completed actions'), findsOneWidget);
    for (final type in SpecialTileType.values) {
      expect(
        find.byKey(ValueKey('battlefield-effect-art-${type.name}')),
        findsOneWidget,
      );
    }
    expect(tester.takeException(), isNull);
  });
}
