import 'package:crazy_chess/ui/menu/hifi_menu_widgets.dart';
import 'package:crazy_chess/ui/shared/nine_slice_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('nine-slice destination caps follow source pixels divided by scale', () {
    final patches = nineSlicePatches(
      imageSize: const Size(512, 192),
      centerSlice: const Rect.fromLTRB(96, 64, 416, 128),
      destination: const Rect.fromLTWH(0, 0, 160, 40),
      scale: 4,
    );

    expect(patches, hasLength(9));
    expect(patches[0].src, const Rect.fromLTRB(0, 0, 96, 64));
    expect(patches[0].dst, const Rect.fromLTRB(0, 0, 24, 16));
    expect(patches[4].src, const Rect.fromLTRB(96, 64, 416, 128));
    expect(patches[4].dst, const Rect.fromLTRB(24, 16, 136, 24));
    expect(patches[8].src, const Rect.fromLTRB(416, 128, 512, 192));
    expect(patches[8].dst, const Rect.fromLTRB(136, 24, 160, 40));
  });

  test(
    'nine-slice shrinks caps when the destination is smaller than the borders',
    () {
      final patches = nineSlicePatches(
        imageSize: const Size(512, 192),
        centerSlice: const Rect.fromLTRB(96, 64, 416, 128),
        destination: const Rect.fromLTWH(0, 0, 20, 10),
        scale: 1,
      );

      expect(patches.any((patch) => patch.dst.left < patch.dst.right), isTrue);
      expect(
        patches.map((patch) => patch.dst).every((dst) {
          return dst.left >= -0.001 &&
              dst.top >= -0.001 &&
              dst.right <= 20.001 &&
              dst.bottom <= 10.001;
        }),
        isTrue,
      );
      expect(
        patches.where(
          (patch) => patch.src == const Rect.fromLTRB(96, 64, 416, 128),
        ),
        isEmpty,
      );
    },
  );

  testWidgets(
    'HifiAssetSurface paints sliced chrome without Image.centerSlice',
    (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: SizedBox(
              width: 200,
              height: 48,
              child: HifiAssetSurface(
                asset:
                    '$runtimeAssetRoot/ui/common/segmented_selected_9slice.webp',
                centerSlice: Rect.fromLTRB(96, 64, 416, 128),
                imageScale: 4,
                child: Center(child: Text('Starter')),
              ),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.byType(NineSliceAssetImage), findsOneWidget);
      expect(
        find.byWidgetPredicate(
          (widget) => widget is Image && widget.centerSlice != null,
        ),
        findsNothing,
      );
      expect(find.text('Starter'), findsOneWidget);
    },
  );
}
