import 'dart:async';
import 'dart:collection';

import 'package:crazy_chess/ai/mobile_stockfish_engine.dart';
import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('MobileStockfishEngine transport', () {
    test('completes UCI handshake with the mobile configuration', () async {
      final transport = _FakeMobileStockfishTransport();
      final engine = MobileStockfishEngine(
        transportStarter: () async => transport,
      );
      addTearDown(engine.dispose);

      await engine.initialize();

      expect(engine.status.value, EngineStatus.ready);
      expect(
        transport.commands,
        containsAllInOrder(<String>[
          'uci',
          'setoption name Threads value 1',
          'setoption name Hash value 32',
          'setoption name Skill Level value 20',
          'setoption name Ponder value false',
          'setoption name MultiPV value 1',
          'isready',
        ]),
      );
    });

    test('parses promotion and constrains search to legal moves', () async {
      final transport = _FakeMobileStockfishTransport()
        ..bestMoves.add('bestmove a7a8q ponder h8g7');
      final engine = MobileStockfishEngine(
        transportStarter: () async => transport,
      );
      addTearDown(engine.dispose);

      final move = await engine.bestMove(
        const EngineMoveRequest(
          fen: '7k/P7/8/8/8/8/8/7K w - - 0 1',
          legalMoves: <String>['a7a8q', 'a7a8r', 'a7a8b', 'a7a8n'],
        ),
      );

      expect(move.uci, 'a7a8q');
      expect(move.ponder, 'h8g7');
      expect(
        transport.commands,
        contains('go movetime 500 searchmoves a7a8q a7a8r a7a8b a7a8n'),
      );
    });

    test('applies Elo limiting and restores unrestricted strength', () async {
      final transport = _FakeMobileStockfishTransport();
      final engine = MobileStockfishEngine(
        transportStarter: () async => transport,
      );
      addTearDown(engine.dispose);

      await engine.bestMove(
        const EngineMoveRequest(
          fen: '8/8/8/8/8/8/4k3/4K3 b - - 0 1',
          targetElo: 3120,
        ),
      );
      await engine.bestMove(
        const EngineMoveRequest(fen: '8/8/8/8/8/8/4k3/4K3 b - - 0 1'),
      );

      expect(
        transport.commands,
        containsAllInOrder(<String>[
          'setoption name UCI_LimitStrength value true',
          'setoption name UCI_Elo value 3120',
          'setoption name UCI_LimitStrength value false',
        ]),
      );
    });

    test('projects excess material before searching', () async {
      final transport = _FakeMobileStockfishTransport()
        ..bestMoves.add('bestmove f6e4');
      final engine = MobileStockfishEngine(
        transportStarter: () async => transport,
      );
      addTearDown(engine.dispose);

      await engine.bestMove(
        const EngineMoveRequest(
          fen:
              'rnbqkb1r/pppp1ppp/5n2/8/4P3/8/PPPPPPPP/RNBQKBNR '
              'b KQkq - 0 3',
          legalMoves: <String>['f6e4', 'b8c6'],
        ),
      );

      expect(
        transport.commands,
        contains(
          'position fen '
          'rnbqkb1r/pppp1ppp/5n2/8/4P3/8/1PPPPPPP/RNBQKBNR '
          'b KQkq - 0 3',
        ),
      );
    });

    test('restarts once after a transport search failure', () async {
      var starts = 0;
      final transports = <_FakeMobileStockfishTransport>[];
      final engine = MobileStockfishEngine(
        transportStarter: () async {
          starts++;
          final transport = _FakeMobileStockfishTransport(failOnGo: starts == 1)
            ..bestMoves.add('bestmove e7e5');
          transports.add(transport);
          return transport;
        },
      );
      addTearDown(engine.dispose);

      final move = await engine.bestMove(
        const EngineMoveRequest(
          fen:
              'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR '
              'b KQkq e3 0 1',
        ),
      );

      expect(move.uci, 'e7e5');
      expect(transports, hasLength(2));
      expect(transports.first.closed, isTrue);
      expect(engine.status.value, EngineStatus.ready);
    });

    test('times out twice and leaves no active transport', () async {
      final transports = <_FakeMobileStockfishTransport>[];
      final engine = MobileStockfishEngine(
        requestTimeout: const Duration(milliseconds: 25),
        transportStarter: () async {
          final transport = _FakeMobileStockfishTransport(respondToGo: false);
          transports.add(transport);
          return transport;
        },
      );
      addTearDown(engine.dispose);

      await expectLater(
        engine.bestMove(
          const EngineMoveRequest(
            fen:
                'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR '
                'b KQkq e3 0 1',
          ),
        ),
        throwsA(isA<StateError>()),
      );

      expect(transports, hasLength(2));
      expect(transports.every((transport) => transport.closed), isTrue);
      expect(engine.status.value, EngineStatus.failed);
    });

    test('uses a separate timeout for the native handshake', () async {
      final engine = MobileStockfishEngine(
        initializationTimeout: const Duration(milliseconds: 25),
        transportStarter: () async =>
            _FakeMobileStockfishTransport(respondToHandshake: false),
      );
      addTearDown(engine.dispose);

      await expectLater(engine.initialize(), throwsA(isA<TimeoutException>()));
      expect(engine.status.value, EngineStatus.failed);
    });

    test('shutdown permits a clean second session', () async {
      final transports = <_FakeMobileStockfishTransport>[];
      final engine = MobileStockfishEngine(
        transportStarter: () async {
          final transport = _FakeMobileStockfishTransport();
          transports.add(transport);
          return transport;
        },
      );
      addTearDown(engine.dispose);

      await engine.initialize();
      await engine.shutdown();
      expect(transports.single.closed, isTrue);
      expect(engine.status.value, EngineStatus.unavailable);

      await engine.initialize();
      expect(transports, hasLength(2));
      expect(engine.status.value, EngineStatus.ready);
    });

    test('malformed no-move output fails after one restart', () async {
      var starts = 0;
      final engine = MobileStockfishEngine(
        transportStarter: () async {
          starts++;
          return _FakeMobileStockfishTransport()
            ..bestMoves.add('bestmove (none)');
        },
      );
      addTearDown(engine.dispose);

      await expectLater(
        engine.bestMove(
          const EngineMoveRequest(fen: '8/8/8/8/8/8/8/K6k w - - 0 1'),
        ),
        throwsA(isA<StateError>()),
      );
      expect(starts, 2);
    });
  });
}

class _FakeMobileStockfishTransport implements MobileStockfishTransport {
  _FakeMobileStockfishTransport({
    this.respondToHandshake = true,
    this.respondToGo = true,
    this.failOnGo = false,
  });

  final bool respondToHandshake;
  final bool respondToGo;
  final bool failOnGo;
  final List<String> commands = <String>[];
  final Queue<String> bestMoves = Queue<String>();
  final StreamController<String> _stdout = StreamController<String>.broadcast();
  final StreamController<Object> _errors = StreamController<Object>.broadcast();
  bool closed = false;

  @override
  Stream<Object> get errors => _errors.stream;

  @override
  Stream<String> get stdoutLines => _stdout.stream;

  @override
  void send(String command) {
    commands.add(command);
    if (command == 'uci' && respondToHandshake) {
      scheduleMicrotask(() {
        _stdout.add('id name Stockfish 18');
        _stdout.add('uciok');
      });
    } else if (command == 'isready' && respondToHandshake) {
      scheduleMicrotask(() => _stdout.add('readyok'));
    } else if (command.startsWith('go ') && failOnGo) {
      scheduleMicrotask(() => _errors.add(StateError('native engine failed')));
    } else if (command.startsWith('go ') && respondToGo) {
      final response = bestMoves.isEmpty
          ? 'bestmove e7e5'
          : bestMoves.removeFirst();
      scheduleMicrotask(() => _stdout.add(response));
    }
  }

  @override
  Future<void> close() async {
    if (closed) {
      return;
    }
    closed = true;
    await _stdout.close();
    await _errors.close();
  }
}
