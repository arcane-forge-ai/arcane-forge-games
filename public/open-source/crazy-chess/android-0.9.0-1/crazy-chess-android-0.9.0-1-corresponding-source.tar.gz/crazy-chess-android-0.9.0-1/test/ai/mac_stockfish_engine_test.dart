import 'dart:async';
import 'dart:collection';
import 'dart:io';

import 'package:crazy_chess/ai/mac_stockfish_engine.dart';
import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final bundledExecutable = File(
    '${Directory.current.path}/third_party/stockfish/macos-arm64/stockfish',
  );
  final bundledStockfishAvailable =
      Platform.isMacOS && bundledExecutable.existsSync();

  group('MacStockfishEngine transport', () {
    test(
      'completes UCI handshake and applies the pinned configuration',
      () async {
        final process = _FakeStockfishProcess();
        final engine = MacStockfishEngine(
          executablePath: '/fake/stockfish',
          processStarter: (_) async => process,
        );
        addTearDown(engine.dispose);

        await engine.initialize();

        expect(engine.status.value, EngineStatus.ready);
        expect(
          process.commands,
          containsAllInOrder(<String>[
            'uci',
            'setoption name Threads value 1',
            'setoption name Hash value 64',
            'setoption name Skill Level value 20',
            'setoption name Ponder value false',
            'setoption name MultiPV value 1',
            'isready',
          ]),
        );
      },
    );

    test('parses bestmove and ponder fields', () async {
      final process = _FakeStockfishProcess()
        ..bestMoves.add('bestmove e7e5 ponder g1f3');
      final engine = MacStockfishEngine(
        executablePath: '/fake/stockfish',
        processStarter: (_) async => process,
      );
      addTearDown(engine.dispose);

      final move = await engine.bestMove(
        const EngineMoveRequest(
          fen:
              'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR '
              'b KQkq e3 0 1',
        ),
      );

      expect(move.uci, 'e7e5');
      expect(move.ponder, 'g1f3');
      expect(process.commands, contains('go movetime 500'));
    });

    test('applies Elo limiting and restores unrestricted strength', () async {
      final process = _FakeStockfishProcess();
      final engine = MacStockfishEngine(
        executablePath: '/fake/stockfish',
        processStarter: (_) async => process,
      );
      addTearDown(engine.dispose);

      await engine.bestMove(
        const EngineMoveRequest(
          fen: '8/8/8/8/8/8/4k3/4K3 b - - 0 1',
          targetElo: 1320,
        ),
      );
      await engine.bestMove(
        const EngineMoveRequest(fen: '8/8/8/8/8/8/4k3/4K3 b - - 0 1'),
      );

      expect(
        process.commands,
        containsAllInOrder(<String>[
          'setoption name UCI_LimitStrength value true',
          'setoption name UCI_Elo value 1320',
          'setoption name UCI_LimitStrength value false',
        ]),
      );
    });

    test('times out, restarts once, and fails after the retry', () async {
      final processes = <_FakeStockfishProcess>[];
      final engine = MacStockfishEngine(
        executablePath: '/fake/stockfish',
        requestTimeout: const Duration(milliseconds: 25),
        processStarter: (_) async {
          final process = _FakeStockfishProcess(respondToGo: false);
          processes.add(process);
          return process;
        },
      );
      addTearDown(engine.dispose);

      await expectLater(
        engine.bestMove(
          const EngineMoveRequest(
            fen:
                'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR '
                'b KQkq e3 0 1',
          ),
        ),
        throwsA(isA<StateError>()),
      );

      expect(processes, hasLength(2));
      expect(engine.status.value, EngineStatus.failed);
    });

    test('unexpected process exit is surfaced as failed', () async {
      final process = _FakeStockfishProcess();
      final engine = MacStockfishEngine(
        executablePath: '/fake/stockfish',
        processStarter: (_) async => process,
      );
      addTearDown(engine.dispose);

      await engine.initialize();
      process.crash(17);
      await Future<void>.delayed(Duration.zero);

      expect(engine.status.value, EngineStatus.failed);
      expect(engine.lastError, contains('exited unexpectedly'));
    });

    test('malformed no-move output is rejected after one restart', () async {
      var starts = 0;
      final engine = MacStockfishEngine(
        executablePath: '/fake/stockfish',
        processStarter: (_) async {
          starts++;
          return _FakeStockfishProcess()..bestMoves.add('bestmove (none)');
        },
      );
      addTearDown(engine.dispose);

      await expectLater(
        engine.bestMove(
          const EngineMoveRequest(fen: '8/8/8/8/8/8/8/K6k w - - 0 1'),
        ),
        throwsA(isA<StateError>()),
      );
      expect(starts, 2);
    });
  });

  group('bundled Stockfish 18 quality smoke', () {
    MacStockfishEngine? engine;

    setUpAll(() async {
      if (!bundledStockfishAvailable) {
        return;
      }
      engine = MacStockfishEngine(executablePath: bundledExecutable.path);
      await engine!.initialize();
    });

    tearDownAll(() async {
      await engine?.dispose();
    });

    test('returns a legal reply after e2e4', () async {
      await engine!.newGame();
      final controller = GameController()..startNewGame();
      addTearDown(controller.dispose);
      controller.makeMove(UciMove.parse('e2e4').resolve(controller));

      final move = await engine!.bestMove(
        EngineMoveRequest(fen: FenCodec.encode(controller.positionSnapshot())),
      );
      expect(
        () => UciMove.parse(move.uci).resolve(controller),
        returnsNormally,
      );
    }, skip: !bundledStockfishAvailable);

    test('selects a legal check escape', () async {
      await engine!.newGame();
      final move = await engine!.bestMove(
        const EngineMoveRequest(fen: '4k3/8/8/8/8/8/4R3/4K3 b - - 0 1'),
      );
      expect(move.uci, isIn(<String>['e8d8', 'e8f8', 'e8d7', 'e8f7']));
    }, skip: !bundledStockfishAvailable);

    test('finds the Fool’s Mate finish', () async {
      await engine!.newGame();
      final move = await engine!.bestMove(
        const EngineMoveRequest(
          fen:
              'rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR '
              'b KQkq g3 0 2',
        ),
      );
      expect(move.uci, 'd8h4');
    }, skip: !bundledStockfishAvailable);

    test('requests a promotion piece automatically', () async {
      await engine!.newGame();
      final move = await engine!.bestMove(
        const EngineMoveRequest(fen: '6rk/P7/8/8/5b2/4n3/8/7K w - - 0 1'),
      );
      expect(move.uci, matches(RegExp(r'^a7a8[qrbn]$')));
    }, skip: !bundledStockfishAvailable);
  });
}

class _FakeStockfishProcess implements StockfishProcessTransport {
  _FakeStockfishProcess({this.respondToGo = true}) : pid = _nextPid++;

  static int _nextPid = 1000;

  @override
  final int pid;
  final bool respondToGo;
  final List<String> commands = <String>[];
  final Queue<String> bestMoves = Queue<String>();
  final StreamController<String> _stdout = StreamController<String>.broadcast();
  final StreamController<String> _stderr = StreamController<String>.broadcast();
  final Completer<int> _exit = Completer<int>();

  @override
  Future<int> get exitCode => _exit.future;

  @override
  Stream<String> get stderrLines => _stderr.stream;

  @override
  Stream<String> get stdoutLines => _stdout.stream;

  @override
  Future<void> flush() async {}

  @override
  bool kill() {
    _completeExit(-9);
    return true;
  }

  @override
  void writeLine(String line) {
    commands.add(line);
    if (line == 'uci') {
      scheduleMicrotask(() {
        _stdout.add('id name Stockfish 18');
        _stdout.add('uciok');
      });
    } else if (line == 'isready') {
      scheduleMicrotask(() => _stdout.add('readyok'));
    } else if (line.startsWith('go ') && respondToGo) {
      final response = bestMoves.isEmpty
          ? 'bestmove e7e5'
          : bestMoves.removeFirst();
      scheduleMicrotask(() => _stdout.add(response));
    } else if (line == 'quit') {
      scheduleMicrotask(() => _completeExit(0));
    }
  }

  void crash(int code) => _completeExit(code);

  void _completeExit(int code) {
    if (!_exit.isCompleted) {
      _exit.complete(code);
    }
  }
}
