import 'dart:async';

import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/fake_chess_engine.dart';
import '../helpers/game_controller_test_driver.dart';

void main() {
  test('Local Duel never requests an engine move', () async {
    final controller = GameController();
    final engine = FakeChessEngine();
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
    );
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);

    final driver = GameControllerTestDriver(controller)..startGame();
    driver.move('e2', 'e4');
    await Future<void>.delayed(Duration.zero);

    expect(engine.requests, isEmpty);
    expect(coordinator.inputLocked, isFalse);
  });

  test('AI triggers only for Black and returns control to White', () async {
    final controller = GameController()
      ..setOpponentMode(OpponentMode.stockfish);
    final engine = FakeChessEngine();
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
    );
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);

    final driver = GameControllerTestDriver(controller)..startGame();
    expect(engine.requests, isEmpty);
    driver.move('e2', 'e4');
    expect(coordinator.inputLocked, isTrue);

    await _flushCoordinator();

    expect(engine.requests, hasLength(1));
    expect(engine.requests.single.legalMoves, contains('e7e5'));
    expect(controller.pieceAt(const Square(3, 4))?.color, PieceColor.black);
    expect(controller.turn, PieceColor.white);
    expect(coordinator.inputLocked, isFalse);
  });

  test('AI waits until the board movement presentation releases', () async {
    final controller = GameController()
      ..setOpponentMode(OpponentMode.stockfish);
    final presentation = BoardPresentationCoordinator(
      controller: controller,
      moveDuration: const Duration(milliseconds: 20),
    );
    final engine = FakeChessEngine();
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
      presentationListenable: presentation,
      isPresentationBusy: () => presentation.isBusy,
    );
    addTearDown(coordinator.dispose);
    addTearDown(presentation.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);

    final driver = GameControllerTestDriver(controller)..startGame();
    driver.move('e2', 'e4');
    await Future<void>.delayed(Duration.zero);

    expect(presentation.isBusy, isTrue);
    expect(engine.requests, isEmpty);

    await Future<void>.delayed(const Duration(milliseconds: 25));
    await _flushCoordinator();

    expect(engine.requests, hasLength(1));
  });

  test('offer and redeployment phases delay the request', () async {
    final controller = GameController()
      ..setOpponentMode(OpponentMode.stockfish)
      ..startNewGame();
    controller.turn = PieceColor.black;
    controller.phase = GamePhase.offer;
    final engine = FakeChessEngine();
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
    );
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);

    controller.cancelOffer();
    await _flushCoordinator();
    expect(engine.requests, hasLength(1));

    controller.turn = PieceColor.black;
    controller.phase = GamePhase.redeploy;
    controller.tapSquare(const Square(1, 0));
    await Future<void>.delayed(Duration.zero);
    expect(engine.requests, hasLength(1));
  });

  test('stale engine response is discarded after lobby return', () async {
    final pending = Completer<EngineMove>();
    final controller = GameController()
      ..setOpponentMode(OpponentMode.stockfish);
    final engine = FakeChessEngine()..onBestMove = (_) => pending.future;
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
    );
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);

    final driver = GameControllerTestDriver(controller)..startGame();
    driver.move('e2', 'e4');
    await Future<void>.delayed(Duration.zero);
    expect(engine.requests, hasLength(1));

    controller.returnToSetup();
    pending.complete(const EngineMove(uci: 'e7e5'));
    await _flushCoordinator();

    expect(controller.phase, GamePhase.setup);
    expect(controller.pieceAt(const Square(1, 4))?.type, PieceType.pawn);
  });

  test(
    'stale response is discarded after rematch reaches the same FEN',
    () async {
      final firstRequest = Completer<EngineMove>();
      final secondRequest = Completer<EngineMove>();
      var requestCount = 0;
      final controller = GameController()
        ..setOpponentMode(OpponentMode.stockfish);
      final engine = FakeChessEngine()
        ..onBestMove = (_) {
          requestCount++;
          return requestCount == 1 ? firstRequest.future : secondRequest.future;
        };
      final coordinator = AiTurnCoordinator(
        controller: controller,
        engine: engine,
      );
      addTearDown(coordinator.dispose);
      addTearDown(controller.dispose);
      addTearDown(engine.dispose);

      final driver = GameControllerTestDriver(controller)..startGame();
      driver.move('e2', 'e4');
      await Future<void>.delayed(Duration.zero);
      expect(engine.requests, hasLength(1));

      controller.startNewGame();
      driver.move('e2', 'e4');
      expect(
        engine.requests.single.fen,
        FenCodec.encode(controller.positionSnapshot()),
      );

      firstRequest.complete(const EngineMove(uci: 'e7e5'));
      await _flushCoordinator();

      expect(engine.requests, hasLength(2));
      expect(controller.pieceAt(const Square(1, 4))?.type, PieceType.pawn);
      expect(controller.turn, PieceColor.black);

      secondRequest.complete(const EngineMove(uci: 'e7e5'));
      await _flushCoordinator();
      expect(controller.pieceAt(const Square(3, 4))?.color, PieceColor.black);
      expect(controller.turn, PieceColor.white);
    },
  );

  test('illegal bestmove pauses the match for recovery', () async {
    final controller = GameController()
      ..setOpponentMode(OpponentMode.stockfish);
    final engine = FakeChessEngine(defaultMove: 'e7e4');
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
    );
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);

    final driver = GameControllerTestDriver(controller)..startGame();
    driver.move('e2', 'e4');
    await _flushCoordinator();

    expect(coordinator.failureMessage, contains('illegal move'));
    expect(controller.turn, PieceColor.black);
    expect(coordinator.inputLocked, isTrue);
  });

  test('game over does not start another request', () async {
    final controller = GameController()
      ..setOpponentMode(OpponentMode.stockfish);
    final engine = FakeChessEngine();
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
    );
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);

    GameControllerTestDriver(controller).foolsMate();
    await _flushCoordinator();

    expect(controller.phase, GamePhase.gameOver);
    expect(engine.requests, isEmpty);
  });

  test(
    'AI receives the post-battlefield position after a shrine resolves',
    () async {
      final controller = GameController(battlefieldSeed: 77)
        ..setOpponentMode(OpponentMode.stockfish)
        ..setBattlefield(BattlefieldId.verdantPastures)
        ..startNewGame();
      final engine = FakeChessEngine();
      final coordinator = AiTurnCoordinator(
        controller: controller,
        engine: engine,
      );
      addTearDown(coordinator.dispose);
      addTearDown(controller.dispose);
      addTearDown(engine.dispose);
      const from = Square(6, 4);
      const to = Square(4, 4);
      final pawn = controller.pieceAt(from)!;
      controller.replaceSpecialTilesForTesting(<SpecialTileState>[
        SpecialTileState(
          square: to,
          type: SpecialTileType.knightShrine,
          pairId: 91,
          progress: 2,
          occupantPieceId: pawn.id,
        ),
      ]);

      controller.makeMove(
        controller
            .legalMovesFrom(from)
            .singleWhere((candidate) => candidate.to == to),
      );
      await _flushCoordinator();

      expect(engine.requests, hasLength(1));
      expect(engine.requests.single.fen, contains('/4N3/'));
      expect(controller.pieceAt(to)?.type, PieceType.knight);
    },
  );

  test('king trap ends the match before AI scheduling', () async {
    final controller = GameController(battlefieldSeed: 88)
      ..setOpponentMode(OpponentMode.stockfish)
      ..setBattlefield(BattlefieldId.ruinedCauseway)
      ..startNewGame();
    final engine = FakeChessEngine();
    final coordinator = AiTurnCoordinator(
      controller: controller,
      engine: engine,
    );
    addTearDown(coordinator.dispose);
    addTearDown(controller.dispose);
    addTearDown(engine.dispose);
    const from = Square(7, 4);
    const to = Square(6, 4);
    controller.board[to.row][to.col] = null;
    final king = controller.pieceAt(from)!;
    controller.replaceSpecialTilesForTesting(<SpecialTileState>[
      SpecialTileState(
        square: to,
        type: SpecialTileType.visibleTrap,
        pairId: 92,
        progress: 1,
        occupantPieceId: king.id,
        occupantTurnMask: 2,
      ),
    ]);

    controller.makeMove(
      controller
          .legalMovesFrom(from)
          .singleWhere((candidate) => candidate.to == to),
    );
    await _flushCoordinator();

    expect(controller.phase, GamePhase.gameOver);
    expect(controller.winner, PieceColor.black);
    expect(controller.gameEndReason, GameEndReason.kingTrapfall);
    expect(engine.requests, isEmpty);
  });
}

Future<void> _flushCoordinator() async {
  for (var i = 0; i < 8; i++) {
    await Future<void>.delayed(Duration.zero);
  }
}
