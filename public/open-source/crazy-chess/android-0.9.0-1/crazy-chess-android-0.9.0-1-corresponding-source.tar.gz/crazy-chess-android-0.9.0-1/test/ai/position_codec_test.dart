import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

import '../helpers/game_controller_test_driver.dart';

void main() {
  group('FenCodec', () {
    late GameController controller;
    late GameControllerTestDriver driver;

    setUp(() {
      controller = GameController();
      driver = GameControllerTestDriver(controller)..startGame();
    });

    tearDown(() {
      controller.dispose();
    });

    test('encodes the starting board exactly', () {
      expect(
        FenCodec.encode(controller.positionSnapshot()),
        'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR '
        'w KQkq - 0 1',
      );
    });

    test('tracks castling rights from king and rook movement state', () {
      controller.board[7][4]!.hasMoved = true;
      controller.board[0][7]!.hasMoved = true;

      expect(
        FenCodec.encode(controller.positionSnapshot()),
        endsWith('w q - 0 1'),
      );
    });

    test('tracks en passant and derives the fullmove number', () {
      driver.move('e2', 'e4');
      expect(
        FenCodec.encode(controller.positionSnapshot()),
        'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR '
        'b KQkq e3 0 1',
      );

      driver.move('e7', 'e5');
      expect(
        FenCodec.encode(controller.positionSnapshot()),
        endsWith('w KQkq e6 0 2'),
      );
    });

    test('reflects captures and color changes', () {
      driver.move('e2', 'e4');
      driver.move('d7', 'd5');
      driver.move('e4', 'd5');
      expect(
        FenCodec.encode(controller.positionSnapshot()),
        startsWith('rnbqkbnr/ppp1pppp/8/3P4/8/8/PPPP1PPP/RNBQKBNR b'),
      );

      controller.board[0][0]!.color = PieceColor.white;
      expect(
        FenCodec.encode(controller.positionSnapshot()),
        startsWith('Rnbqkbnr/'),
      );
    });

    test('encodes a promoted piece by its current role', () {
      for (final row in controller.board) {
        row.fillRange(0, 8, null);
      }
      controller.board[0][0] = ChessPiece(
        id: 'promoted',
        type: PieceType.queen,
        color: PieceColor.white,
        countryId: 'mercantile',
        loyalty: null,
        fairPrice: null,
      );
      controller.board[0][4] = ChessPiece(
        id: 'black-king',
        type: PieceType.king,
        color: PieceColor.black,
        countryId: 'iron',
        loyalty: null,
        fairPrice: null,
      );
      controller.board[7][4] = ChessPiece(
        id: 'white-king',
        type: PieceType.king,
        color: PieceColor.white,
        countryId: 'mercantile',
        loyalty: null,
        fairPrice: null,
      );

      expect(
        FenCodec.encode(controller.positionSnapshot()),
        'Q3k3/8/8/8/8/8/8/4K3 w - - 0 1',
      );
    });

    test('clears stale en passant after offer and redeployment', () {
      driver.move('e2', 'e4');
      expect(controller.enPassantSquare, isNotNull);

      final target = controller.pieceAt(const Square(6, 0))!;
      target.loyalty = 0;
      controller.tapSquare(const Square(6, 0));
      controller.openOfferForSelected();
      controller.setOfferGold(1);
      controller.confirmOffer();
      expect(controller.phase, GamePhase.redeploy);
      controller.placeRedeploy(controller.legalRedeploySquares().first);

      expect(controller.enPassantSquare, isNull);
      expect(FenCodec.encode(controller.positionSnapshot()).split(' ')[3], '-');
    });
  });

  group('UciMove', () {
    test('parses promotion suffixes and rejects malformed output', () {
      expect(UciMove.parse('a7a8q').promotion, PieceType.queen);
      expect(UciMove.parse('a7a8n').promotion, PieceType.knight);
      expect(() => UciMove.parse('a7a9'), throwsFormatException);
      expect(() => UciMove.parse('bestmove e2e4'), throwsFormatException);
      expect(() => UciMove.parse('a7a8k'), throwsFormatException);
    });

    test('resolves only a move in the controller legal list', () {
      final controller = GameController()..startNewGame();
      addTearDown(controller.dispose);

      final move = UciMove.parse('e2e4').resolve(controller);
      expect(move.from, const Square(6, 4));
      expect(move.to, const Square(4, 4));
      expect(() => UciMove.parse('e2e5').resolve(controller), throwsStateError);
    });
  });
}
