import 'dart:async';
import 'dart:collection';

import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('web Stockfish URL resolution', () {
    test('resolves from a root document base URI', () {
      expect(
        resolveStockfishWorkerUri('https://example.test/').toString(),
        'https://example.test/stockfish/stockfish-18-lite-single.js',
      );
    });

    test('preserves a deployed subpath', () {
      expect(
        resolveStockfishWorkerUri(
          'https://example.test/crazy-chess/',
        ).toString(),
        'https://example.test/crazy-chess/stockfish/'
        'stockfish-18-lite-single.js',
      );
    });
  });

  group('Stockfish Lite FEN projection', () {
    test('preserves ordinary standard positions exactly', () {
      const fen =
          'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR '
          'b KQkq e3 0 1';
      expect(StockfishLiteFenAdapter.project(fen), fen);
    });

    test('removes a home pawn from a nine-pawn betrayal position', () {
      const fen =
          'rnbqkb1r/pppp1ppp/5n2/8/4P3/8/PPPPPPPP/RNBQKBNR '
          'b KQkq - 0 3';
      expect(
        StockfishLiteFenAdapter.project(fen),
        'rnbqkb1r/pppp1ppp/5n2/8/4P3/8/1PPPPPPP/RNBQKBNR '
        'b KQkq - 0 3',
      );
    });
  });

  group('WebStockfishEngine transport', () {
    test('completes UCI handshake with the web configuration', () async {
      final worker = _FakeStockfishWorker();
      final engine = WebStockfishEngine(
        workerScriptUri: Uri.parse(
          'https://example.test/stockfish/stockfish-18-lite-single.js',
        ),
        workerStarter: (_) async => worker,
      );
      addTearDown(engine.dispose);

      await engine.initialize();

      expect(engine.status.value, EngineStatus.ready);
      expect(
        worker.commands,
        containsAllInOrder(<String>[
          'uci',
          'setoption name Hash value 32',
          'setoption name Skill Level value 20',
          'setoption name Ponder value false',
          'setoption name MultiPV value 1',
          'isready',
        ]),
      );
    });

    test('parses bestmove, ponder, and promotion suffixes', () async {
      final worker = _FakeStockfishWorker()
        ..bestMoves.add('bestmove a7a8q ponder h8g7');
      final engine = WebStockfishEngine(
        workerScriptUri: Uri.parse('https://example.test/stockfish.js'),
        workerStarter: (_) async => worker,
      );
      addTearDown(engine.dispose);

      final move = await engine.bestMove(
        const EngineMoveRequest(
          fen: '7k/P7/8/8/8/8/8/7K w - - 0 1',
          legalMoves: <String>['a7a8q', 'a7a8r', 'a7a8b', 'a7a8n'],
        ),
      );

      expect(move.uci, 'a7a8q');
      expect(move.ponder, 'h8g7');
      expect(
        worker.commands,
        contains('go movetime 500 searchmoves a7a8q a7a8r a7a8b a7a8n'),
      );
    });

    test('applies Elo limiting and restores unrestricted strength', () async {
      final worker = _FakeStockfishWorker();
      final engine = WebStockfishEngine(
        workerScriptUri: Uri.parse('https://example.test/stockfish.js'),
        workerStarter: (_) async => worker,
      );
      addTearDown(engine.dispose);

      await engine.bestMove(
        const EngineMoveRequest(
          fen: '8/8/8/8/8/8/4k3/4K3 b - - 0 1',
          targetElo: 2020,
        ),
      );
      await engine.bestMove(
        const EngineMoveRequest(fen: '8/8/8/8/8/8/4k3/4K3 b - - 0 1'),
      );

      expect(
        worker.commands,
        containsAllInOrder(<String>[
          'setoption name UCI_LimitStrength value true',
          'setoption name UCI_Elo value 2020',
          'setoption name UCI_LimitStrength value false',
        ]),
      );
    });

    test(
      'projects excess material and constrains search to legal moves',
      () async {
        final worker = _FakeStockfishWorker()..bestMoves.add('bestmove f6e4');
        final engine = WebStockfishEngine(
          workerScriptUri: Uri.parse('https://example.test/stockfish.js'),
          workerStarter: (_) async => worker,
        );
        addTearDown(engine.dispose);

        final move = await engine.bestMove(
          const EngineMoveRequest(
            fen:
                'rnbqkb1r/pppp1ppp/5n2/8/4P3/8/PPPPPPPP/RNBQKBNR '
                'b KQkq - 0 3',
            legalMoves: <String>['f6e4', 'b8c6', 'd7d6'],
          ),
        );

        expect(move.uci, 'f6e4');
        expect(
          worker.commands,
          contains(
            'position fen '
            'rnbqkb1r/pppp1ppp/5n2/8/4P3/8/1PPPPPPP/RNBQKBNR '
            'b KQkq - 0 3',
          ),
        );
        expect(
          worker.commands,
          contains('go movetime 500 searchmoves f6e4 b8c6 d7d6'),
        );
      },
    );

    test('times out, keeps one worker, restarts once, then fails', () async {
      final workers = <_FakeStockfishWorker>[];
      var activeWorkers = 0;
      var maxActiveWorkers = 0;
      final engine = WebStockfishEngine(
        workerScriptUri: Uri.parse('https://example.test/stockfish.js'),
        requestTimeout: const Duration(milliseconds: 25),
        workerStarter: (_) async {
          activeWorkers++;
          if (activeWorkers > maxActiveWorkers) {
            maxActiveWorkers = activeWorkers;
          }
          final worker = _FakeStockfishWorker(
            respondToGo: false,
            onTerminate: () => activeWorkers--,
          );
          workers.add(worker);
          return worker;
        },
      );
      addTearDown(engine.dispose);

      await expectLater(
        engine.bestMove(
          const EngineMoveRequest(
            fen:
                'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR '
                'b KQkq e3 0 1',
          ),
        ),
        throwsA(isA<StateError>()),
      );

      expect(workers, hasLength(2));
      expect(maxActiveWorkers, 1);
      expect(activeWorkers, 0);
      expect(engine.status.value, EngineStatus.failed);
    });

    test('worker failure restarts once and retries the request', () async {
      var starts = 0;
      final engine = WebStockfishEngine(
        workerScriptUri: Uri.parse('https://example.test/stockfish.js'),
        workerStarter: (_) async {
          starts++;
          return _FakeStockfishWorker(failOnGo: starts == 1)
            ..bestMoves.add('bestmove e7e5');
        },
      );
      addTearDown(engine.dispose);

      final move = await engine.bestMove(
        const EngineMoveRequest(
          fen:
              'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR '
              'b KQkq e3 0 1',
        ),
      );

      expect(starts, 2);
      expect(move.uci, 'e7e5');
      expect(engine.status.value, EngineStatus.ready);
    });

    test('initialization uses its separate cold-load timeout', () async {
      final engine = WebStockfishEngine(
        workerScriptUri: Uri.parse('https://example.test/stockfish.js'),
        initializationTimeout: const Duration(milliseconds: 25),
        workerStarter: (_) async =>
            _FakeStockfishWorker(respondToHandshake: false),
      );
      addTearDown(engine.dispose);

      await expectLater(engine.initialize(), throwsA(isA<TimeoutException>()));
      expect(engine.status.value, EngineStatus.failed);
    });

    test('malformed no-move output is rejected after one restart', () async {
      var starts = 0;
      final engine = WebStockfishEngine(
        workerScriptUri: Uri.parse('https://example.test/stockfish.js'),
        workerStarter: (_) async {
          starts++;
          return _FakeStockfishWorker()..bestMoves.add('bestmove (none)');
        },
      );
      addTearDown(engine.dispose);

      await expectLater(
        engine.bestMove(
          const EngineMoveRequest(fen: '8/8/8/8/8/8/8/K6k w - - 0 1'),
        ),
        throwsA(isA<StateError>()),
      );
      expect(starts, 2);
    });

    test('disposal sends quit and terminates the owned worker', () async {
      final worker = _FakeStockfishWorker();
      final engine = WebStockfishEngine(
        workerScriptUri: Uri.parse('https://example.test/stockfish.js'),
        workerStarter: (_) async => worker,
      );

      await engine.initialize();
      await engine.dispose();

      expect(worker.commands.last, 'quit');
      expect(worker.terminated, isTrue);
    });

    test('shutdown releases the worker and allows a later preflight', () async {
      final workers = <_FakeStockfishWorker>[];
      final engine = WebStockfishEngine(
        workerScriptUri: Uri.parse('https://example.test/stockfish.js'),
        workerStarter: (_) async {
          final worker = _FakeStockfishWorker();
          workers.add(worker);
          return worker;
        },
      );
      addTearDown(engine.dispose);

      await engine.initialize();
      await engine.shutdown();
      expect(workers.single.terminated, isTrue);
      expect(engine.status.value, EngineStatus.unavailable);

      await engine.initialize();
      expect(workers, hasLength(2));
      expect(engine.status.value, EngineStatus.ready);
    });
  });
}

class _FakeStockfishWorker implements StockfishWorkerTransport {
  _FakeStockfishWorker({
    this.respondToHandshake = true,
    this.respondToGo = true,
    this.failOnGo = false,
    this.onTerminate,
  });

  final bool respondToHandshake;
  final bool respondToGo;
  final bool failOnGo;
  final void Function()? onTerminate;
  final List<String> commands = <String>[];
  final Queue<String> bestMoves = Queue<String>();
  final StreamController<String> _messages =
      StreamController<String>.broadcast();
  final StreamController<Object> _errors = StreamController<Object>.broadcast();
  bool terminated = false;

  @override
  Stream<Object> get errors => _errors.stream;

  @override
  Stream<String> get messages => _messages.stream;

  @override
  void postMessage(String message) {
    commands.add(message);
    if (message == 'uci' && respondToHandshake) {
      scheduleMicrotask(() {
        _messages.add('id name Stockfish 18 Lite\nuciok');
      });
    } else if (message == 'isready' && respondToHandshake) {
      scheduleMicrotask(() => _messages.add('readyok'));
    } else if (message.startsWith('go ') && failOnGo) {
      scheduleMicrotask(() => _errors.add(StateError('worker crashed')));
    } else if (message.startsWith('go ') && respondToGo) {
      final response = bestMoves.isEmpty
          ? 'bestmove e7e5'
          : bestMoves.removeFirst();
      scheduleMicrotask(() => _messages.add(response));
    }
  }

  @override
  void terminate() {
    if (terminated) {
      return;
    }
    terminated = true;
    onTerminate?.call();
  }
}
