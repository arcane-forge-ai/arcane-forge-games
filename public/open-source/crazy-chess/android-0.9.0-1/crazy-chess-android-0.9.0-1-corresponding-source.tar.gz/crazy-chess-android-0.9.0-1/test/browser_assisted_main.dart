import 'dart:math' as math;

import 'package:crazy_chess/app/responsive_game_viewport.dart';
import 'package:crazy_chess/app/theme.dart';
import 'package:crazy_chess/battlefield/battlefield_models.dart';
import 'package:crazy_chess/domain/chess_models.dart';
import 'package:crazy_chess/domain/economy_config.dart';
import 'package:crazy_chess/game/game_controller.dart';
import 'package:crazy_chess/l10n/app_localizations.dart';
import 'package:crazy_chess/l10n/runtime_game_locale.dart';
import 'package:crazy_chess/ui/board/board_presentation_coordinator.dart';
import 'package:crazy_chess/ui/match/match_screen.dart';
import 'package:flutter/material.dart';

void main() {
  final locale = Uri.base.queryParameters['locale'] == 'zh-Hans'
      ? const Locale.fromSubtags(languageCode: 'zh', scriptCode: 'Hans')
      : const Locale('en');
  RuntimeGameLocale.setLocale(locale);
  final state = Uri.base.queryParameters['state'] ?? 'redeploy';
  final reducedMotion = Uri.base.queryParameters['reducedMotion'] == '1';
  final rollHoldMs = int.tryParse(Uri.base.queryParameters['rollHoldMs'] ?? '');
  final controller = GameController(random: math.Random(20260729));
  void Function()? delayedAction;
  var purchasePlacementPolicy = PurchasePlacementPolicy.redeploy;
  final whiteCountry = Uri.base.queryParameters['white'] ?? 'mercantile';
  final blackCountry = Uri.base.queryParameters['black'] ?? 'spy';
  switch (state) {
    case 'idle':
      _startConfigured(
        controller,
        whiteCountry: whiteCountry,
        blackCountry: blackCountry,
      );
      break;
    case 'selected':
      _prepareSelected(
        controller,
        role: Uri.base.queryParameters['role'] ?? 'queen',
        countryId: Uri.base.queryParameters['country'] ?? blackCountry,
        whiteCountry: whiteCountry,
        blackCountry: blackCountry,
      );
      break;
    case 'merchant':
      _startConfigured(
        controller,
        whiteCountry: whiteCountry,
        blackCountry: blackCountry,
      );
      controller.merchantPosition =
          int.tryParse(Uri.base.queryParameters['position'] ?? '') ?? 8;
      controller.merchantDirection =
          int.tryParse(Uri.base.queryParameters['direction'] ?? '') ?? 1;
      break;
    case 'longLog':
      _startConfigured(
        controller,
        whiteCountry: whiteCountry,
        blackCountry: blackCountry,
      );
      controller.eventLog
        ..clear()
        ..addAll(
          List.generate(
            18,
            (index) =>
                'Turn ${18 - index}: Merchant intelligence reports a long wrapped court record entry for safe-zone verification.',
          ),
        );
      break;
    case 'capture':
      _prepareCapture(controller);
      break;
    case 'movementCapture':
      _prepareCapture(controller);
      delayedAction = () => _move(controller, 'e4', 'd5');
      break;
    case 'check':
      _prepareCheck(controller);
      break;
    case 'checkmate':
      _prepareCheckmate(controller);
      break;
    case 'stalemate':
      _prepareStalemate(controller);
      break;
    case 'offerSuccess':
      _prepareOfferResult(controller, success: true);
      break;
    case 'offerFailure':
      _prepareOfferResult(controller, success: false);
      break;
    case 'offer':
      _prepareOffer(
        controller,
        whiteCountry: whiteCountry,
        blackCountry: blackCountry,
      );
      break;
    case 'offerRevealed':
      _prepareOffer(
        controller,
        whiteCountry: whiteCountry,
        blackCountry: blackCountry,
        revealed: true,
      );
      break;
    case 'humiliation':
      _prepareHumiliation(controller);
      break;
    case 'nearMiss':
      _prepareNearMissResult(controller);
      break;
    case 'automatic':
      _prepareAutomaticAcceptance(controller);
      break;
    case 'betrayalTransform':
      _prepareAutomaticAcceptance(controller);
      delayedAction = controller.dismissLastOfferResult;
      break;
    case 'livingInPlacePurchase':
      _prepareLivingInPlacePurchase(controller);
      purchasePlacementPolicy = PurchasePlacementPolicy.blackInPlace;
      break;
    case 'postReset':
      _prepareAutomaticAcceptance(controller);
      controller.dismissLastOfferResult();
      controller.previewRedeploy(controller.legalRedeploySquares().first);
      break;
    case 'redeployPending':
      _prepareRedeploy(controller);
      controller.previewRedeploy(controller.legalRedeploySquares().first);
      break;
    case 'redeployConfirmed':
      _prepareRedeploy(controller);
      controller.previewRedeploy(controller.legalRedeploySquares().first);
      controller.confirmRedeploy();
      break;
    case 'redeployTravel':
      _prepareRedeploy(controller);
      delayedAction = () {
        controller.previewRedeploy(controller.legalRedeploySquares().first);
        controller.confirmRedeploy();
      };
      break;
    case 'payout':
      _preparePayout(controller);
      break;
    case 'battlefieldArt':
      _prepareBattlefieldArt(controller);
      break;
    case 'chaosArt':
      _prepareChaosArt(controller);
      break;
    case 'trapfallMercantile':
      _prepareTrapfall(controller, defeatedCountryId: 'mercantile');
      break;
    case 'trapfallSpy':
      _prepareTrapfall(controller, defeatedCountryId: 'spy');
      break;
    default:
      _prepareRedeploy(controller);
      break;
  }
  final presentation = BoardPresentationCoordinator(controller: controller)
    ..setReducedMotion(reducedMotion);
  runApp(
    _AssistedMatchApp(
      controller: controller,
      presentation: presentation,
      assistedAction: delayedAction,
      reducedMotion: reducedMotion,
      purchaseResultDelay: rollHoldMs == null
          ? const Duration(milliseconds: 620)
          : Duration(milliseconds: rollHoldMs),
      purchasePlacementPolicy: purchasePlacementPolicy,
      locale: locale,
    ),
  );
}

void _prepareBattlefieldArt(GameController controller) {
  controller
    ..setBattlefield(BattlefieldId.ruinedCauseway)
    ..startNewGame();

  final blackPawn = controller.board[1][1]!;
  controller.board[1][1] = null;
  controller.board[2][1] = blackPawn..hasMoved = true;

  final whitePawn = controller.board[6][5]!;
  controller.board[6][5] = null;
  controller.board[4][5] = whitePawn..hasMoved = true;

  controller.replaceSpecialTilesForTesting(<SpecialTileState>[
    SpecialTileState(
      square: const Square(2, 1),
      type: SpecialTileType.knightShrine,
      pairId: 1,
      progress: 2,
      occupantPieceId: blackPawn.id,
    ),
    const SpecialTileState(
      square: Square(2, 3),
      type: SpecialTileType.treasureChest,
      pairId: 2,
    ),
    const SpecialTileState(
      square: Square(2, 5),
      type: SpecialTileType.diamondRing,
      pairId: 3,
      progress: 1,
    ),
    const SpecialTileState(
      square: Square(4, 1),
      type: SpecialTileType.visibleTrap,
      pairId: 4,
      progress: 1,
    ),
    const SpecialTileState(
      square: Square(4, 3),
      type: SpecialTileType.mystery,
      pairId: 5,
    ),
    SpecialTileState(
      square: const Square(4, 5),
      type: SpecialTileType.diamondRing,
      pairId: 6,
      progress: 2,
      occupantPieceId: whitePawn.id,
    ),
  ]);
  controller.diamondRingTokens[PieceColor.white] = 2;
}

void _prepareChaosArt(GameController controller) {
  controller
    ..setBattlefield(BattlefieldId.chaosCrucible)
    ..startNewGame()
    ..replaceSpecialTilesForTesting(const <SpecialTileState>[
      SpecialTileState(
        square: Square(2, 1),
        type: SpecialTileType.knightShrine,
        pairId: 1,
        progress: 2,
      ),
      SpecialTileState(
        square: Square(2, 3),
        type: SpecialTileType.treasureChest,
        pairId: 2,
      ),
      SpecialTileState(
        square: Square(2, 5),
        type: SpecialTileType.diamondRing,
        pairId: 3,
        progress: 1,
      ),
      SpecialTileState(
        square: Square(4, 1),
        type: SpecialTileType.visibleTrap,
        pairId: 4,
        progress: 1,
      ),
      SpecialTileState(
        square: Square(4, 3),
        type: SpecialTileType.mystery,
        pairId: 5,
      ),
    ]);
}

void _prepareTrapfall(
  GameController controller, {
  required String defeatedCountryId,
}) {
  final defeatedColor = defeatedCountryId == 'spy'
      ? PieceColor.black
      : PieceColor.white;
  controller
    ..setupWhiteCountryId = defeatedColor == PieceColor.white
        ? defeatedCountryId
        : 'mercantile'
    ..setupBlackCountryId = defeatedColor == PieceColor.black
        ? defeatedCountryId
        : 'spy'
    ..setBattlefield(BattlefieldId.chaosCrucible)
    ..startNewGame()
    ..winner = defeatedColor == PieceColor.white
        ? PieceColor.black
        : PieceColor.white
    ..gameEndReason = GameEndReason.kingTrapfall
    ..phase = GamePhase.gameOver;
}

void _prepareSelected(
  GameController controller, {
  required String role,
  required String countryId,
  required String whiteCountry,
  required String blackCountry,
}) {
  _startConfigured(
    controller,
    whiteCountry: whiteCountry,
    blackCountry: blackCountry,
  );
  final type = PieceType.values.firstWhere(
    (candidate) => candidate.name == role,
    orElse: () => PieceType.queen,
  );
  const square = Square(3, 4);
  controller.board[square.row][square.col] = ChessPiece(
    id: 'assisted-selected-$countryId-${type.name}',
    type: type,
    color: PieceColor.black,
    countryId: countryId,
    loyalty: 60,
    fairPrice: fairPriceAnchors[type],
  );
  controller.selectedSquare = square;
}

void _startConfigured(
  GameController controller, {
  required String whiteCountry,
  required String blackCountry,
}) {
  controller
    ..setupWhiteCountryId = whiteCountry
    ..setupBlackCountryId = blackCountry
    ..startNewGame();
}

class _AssistedMatchApp extends StatefulWidget {
  const _AssistedMatchApp({
    required this.controller,
    required this.presentation,
    required this.assistedAction,
    required this.reducedMotion,
    required this.purchaseResultDelay,
    required this.purchasePlacementPolicy,
    required this.locale,
  });

  final GameController controller;
  final BoardPresentationCoordinator presentation;
  final VoidCallback? assistedAction;
  final bool reducedMotion;
  final Duration purchaseResultDelay;
  final PurchasePlacementPolicy purchasePlacementPolicy;
  final Locale locale;

  @override
  State<_AssistedMatchApp> createState() => _AssistedMatchAppState();
}

class _AssistedMatchAppState extends State<_AssistedMatchApp> {
  var _actionTriggered = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      locale: widget.locale,
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: AppLocalizations.localizationsDelegates,
      theme: buildCrazyChessTheme(locale: widget.locale),
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(
          context,
        ).copyWith(disableAnimations: widget.reducedMotion),
        child: child!,
      ),
      home: Scaffold(
        body: Stack(
          children: [
            ResponsiveGameViewport(
              child: AnimatedBuilder(
                animation: Listenable.merge([
                  widget.controller,
                  widget.presentation,
                ]),
                builder: (context, _) => MatchScreen(
                  controller: widget.controller,
                  presentationCoordinator: widget.presentation,
                  purchaseResultDelay: widget.purchaseResultDelay,
                  purchasePlacementPolicy: widget.purchasePlacementPolicy,
                ),
              ),
            ),
            if (widget.assistedAction != null && !_actionTriggered)
              Positioned(
                top: 8,
                right: 8,
                width: 196,
                height: 44,
                child: FilledButton(
                  key: const ValueKey('assisted-action-trigger'),
                  onPressed: () {
                    setState(() => _actionTriggered = true);
                    widget.assistedAction!();
                  },
                  child: const Text('RUN ASSISTED ACTION'),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

void _prepareCapture(GameController controller) {
  controller.startNewGame();
  _move(controller, 'e2', 'e4');
  _move(controller, 'd7', 'd5');
  controller.tapSquare(controller.parseSquare('e4')!);
}

void _prepareRedeploy(GameController controller) {
  controller.startNewGame();
  final original = const Square(1, 3);
  final piece = controller.board[original.row][original.col]!;
  controller.board[original.row][original.col] = null;
  piece
    ..color = PieceColor.white
    ..countryId = controller.setupWhiteCountryId
    ..hasMoved = true
    ..newlyPurchased = true;
  controller.redeployPiece = piece;
  controller.redeployOriginalSquare = original;
  controller.selectedSquare = null;
  controller.phase = GamePhase.redeploy;
}

void _prepareCheck(GameController controller) {
  controller.startNewGame();
  for (var row = 0; row < 8; row++) {
    for (var col = 0; col < 8; col++) {
      controller.board[row][col] = null;
    }
  }
  controller.board[7][4] = ChessPiece(
    id: 'assisted-white-king',
    type: PieceType.king,
    color: PieceColor.white,
    countryId: 'mercantile',
    loyalty: null,
    fairPrice: null,
  );
  controller.board[0][4] = ChessPiece(
    id: 'assisted-black-rook',
    type: PieceType.rook,
    color: PieceColor.black,
    countryId: 'iron',
    loyalty: 60,
    fairPrice: 22,
  );
  controller.board[0][0] = ChessPiece(
    id: 'assisted-black-king',
    type: PieceType.king,
    color: PieceColor.black,
    countryId: 'iron',
    loyalty: null,
    fairPrice: null,
  );
  controller.turn = PieceColor.white;
  controller.phase = GamePhase.playing;
}

void _prepareCheckmate(GameController controller) {
  controller.startNewGame();
  _move(controller, 'f2', 'f3');
  _move(controller, 'e7', 'e5');
  _move(controller, 'g2', 'g4');
  _move(controller, 'd8', 'h4');
}

void _prepareOfferResult(GameController controller, {required bool success}) {
  controller.startNewGame();
  controller.lastOfferResult = OfferResult(
    success: success,
    roll: success ? 24 : 86,
    chance: 64,
    paid: 8,
    refund: success ? 0 : 2,
    targetName: 'Black Bishop',
    targetType: PieceType.bishop,
    targetCountryId: 'iron',
    targetColor: PieceColor.black,
  );
  controller.phase = success ? GamePhase.redeploy : GamePhase.playing;
}

void _prepareOffer(
  GameController controller, {
  required String whiteCountry,
  required String blackCountry,
  bool revealed = false,
}) {
  _startConfigured(
    controller,
    whiteCountry: revealed ? 'spy' : whiteCountry,
    blackCountry: blackCountry,
  );
  controller.tapSquare(controller.parseSquare('b7')!);
  controller.openOfferForSelected();
  if (revealed) {
    controller.revealOfferChance();
  }
}

void _prepareHumiliation(GameController controller) {
  _startConfigured(controller, whiteCountry: 'spy', blackCountry: 'iron');
  final target = controller.parseSquare('b7')!;
  controller.board[target.row][target.col] = ChessPiece(
    id: 'assisted-humiliation-target',
    type: PieceType.pawn,
    color: PieceColor.black,
    countryId: 'iron',
    loyalty: 80,
    fairPrice: 10,
  );
  controller.tapSquare(target);
  controller.openOfferForSelected();
  controller.revealOfferChance();
  controller.setOfferGold(9);
  controller.confirmOffer();
}

void _prepareNearMissResult(GameController controller) {
  _startConfigured(controller, whiteCountry: 'spy', blackCountry: 'mercantile');
  controller.lastOfferResult = const OfferResult(
    success: false,
    roll: 21,
    chance: 20,
    paid: 22,
    refund: 0,
    targetName: 'Black Rook',
    targetType: PieceType.rook,
    targetCountryId: 'mercantile',
    targetColor: PieceColor.black,
    resolutionKind: OfferResolutionKind.rolled,
    publicReaction: OfferReaction.tempted,
    loyaltyBefore: 60,
    loyaltyAfter: 36,
    buyerHadExactIntel: true,
  );
  controller.phase = GamePhase.playing;
}

void _prepareAutomaticAcceptance(GameController controller) {
  _startConfigured(controller, whiteCountry: 'spy', blackCountry: 'mercantile');
  final target = controller.parseSquare('b7')!;
  controller.board[target.row][target.col] = ChessPiece(
    id: 'assisted-broken-queen',
    type: PieceType.queen,
    color: PieceColor.black,
    countryId: 'mercantile',
    loyalty: 0,
    fairPrice: 40,
  );
  controller.tapSquare(target);
  controller.openOfferForSelected();
  controller.revealOfferChance();
  controller.setOfferGold(1);
  controller.confirmOffer();
}

void _prepareLivingInPlacePurchase(GameController controller) {
  _startConfigured(controller, whiteCountry: 'ashen', blackCountry: 'iron');
  controller.turn = PieceColor.black;
  controller.gold[PieceColor.black] = 50;
  final target = controller.parseSquare('a1')!;
  final piece = controller.pieceAt(target)!;
  piece.loyalty = 1;
  controller
    ..selectedSquare = target
    ..openOfferForSelected()
    ..setOfferGold(22)
    ..confirmOffer();
  assert(controller.lastOfferResult?.success == true);
  assert(
    controller.lastOfferResult?.resolutionKind == OfferResolutionKind.rolled,
  );
}

void _prepareStalemate(GameController controller) {
  controller.startNewGame();
  controller
    ..winner = null
    ..stalemate = true
    ..phase = GamePhase.gameOver;
}

void _preparePayout(GameController controller) {
  controller.startNewGame();
  controller.merchantPayoutPulseSerial = 1;
  controller.lastMerchantPayoutReceiver = PieceColor.black;
}

void _move(GameController controller, String from, String to) {
  final fromSquare = controller.parseSquare(from)!;
  final toSquare = controller.parseSquare(to)!;
  controller.selectedSquare = fromSquare;
  final move = controller.selectedLegalMoves.firstWhere(
    (candidate) => candidate.to == toSquare,
  );
  controller.makeMove(move);
}
