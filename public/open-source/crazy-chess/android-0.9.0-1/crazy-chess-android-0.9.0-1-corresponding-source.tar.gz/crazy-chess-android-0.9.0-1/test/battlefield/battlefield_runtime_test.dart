import 'package:crazy_chess/crazy_chess.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('BattlefieldRuntime', () {
    test('Classic Court never spawns special tiles', () {
      final runtime = BattlefieldRuntime(
        definition: battlefieldDefinitions[BattlefieldId.classic]!,
        seed: 17,
      );
      final board = _emptyBoard();

      expect(runtime.initialize(board), isEmpty);
      expect(runtime.advance(board).spawnedTiles, isEmpty);
      expect(runtime.tiles, isEmpty);
      expect(runtime.activeCap, 0);
    });

    test('same seed produces the same symmetric opening pair and cap', () {
      final definition = battlefieldDefinitions[BattlefieldId.gildedBazaar]!;
      final first = BattlefieldRuntime(definition: definition, seed: 221);
      final second = BattlefieldRuntime(definition: definition, seed: 221);
      final firstTiles = first.initialize(_emptyBoard());
      final secondTiles = second.initialize(_emptyBoard());

      expect(first.activeCap, second.activeCap);
      expect(firstTiles.length, 2);
      expect(
        firstTiles.map((tile) => tile.square),
        orderedEquals(secondTiles.map((tile) => tile.square)),
      );
      expect(firstTiles.first.type, SpecialTileType.treasureChest);
      expect(firstTiles.last.square, mirroredSquare(firstTiles.first.square));
      expect(firstTiles.first.pairId, firstTiles.last.pairId);
    });

    test('opening pair only uses empty mirrored squares', () {
      final board = _emptyBoard();
      board[2][3] = _piece('occupied-a');
      board[5][4] = _piece('occupied-b');
      final runtime = BattlefieldRuntime(
        definition: battlefieldDefinitions[BattlefieldId.ruinedCauseway]!,
        seed: 9,
      );

      final tiles = runtime.initialize(board);

      expect(tiles, hasLength(2));
      for (final tile in tiles) {
        expect(board[tile.square.row][tile.square.col], isNull);
      }
      expect(tiles.last.square, mirroredSquare(tiles.first.square));
    });

    test('charge resets when the occupying piece changes', () {
      final board = _emptyBoard();
      const square = Square(3, 3);
      final runtime = BattlefieldRuntime(
        definition: battlefieldDefinitions[BattlefieldId.verdantPastures]!,
        seed: 4,
      );
      runtime.initialize(board);
      runtime.replaceTiles(const <SpecialTileState>[
        SpecialTileState(
          square: square,
          type: SpecialTileType.knightShrine,
          pairId: 99,
        ),
      ]);
      board[square.row][square.col] = _piece('first');

      runtime.advance(board);
      expect(runtime.tileAt(square)!.progress, 1);
      board[square.row][square.col] = _piece('replacement');
      runtime.advance(board);

      expect(runtime.tileAt(square)!.progress, 1);
      expect(runtime.tileAt(square)!.occupantPieceId, 'replacement');
    });

    test('charged chest resolves once with seeded gold from 8 through 50', () {
      final board = _emptyBoard();
      const square = Square(4, 2);
      final runtime = BattlefieldRuntime(
        definition: battlefieldDefinitions[BattlefieldId.gildedBazaar]!,
        seed: 71,
      );
      runtime.initialize(board);
      runtime.replaceTiles(const <SpecialTileState>[
        SpecialTileState(
          square: square,
          type: SpecialTileType.treasureChest,
          pairId: 12,
        ),
      ]);
      board[square.row][square.col] = _piece('treasure-hunter');

      expect(runtime.advance(board).resolutions, isEmpty);
      final result = runtime.advance(board);

      expect(result.resolutions, hasLength(1));
      expect(
        result.resolutions.single.resolvedType,
        SpecialTileType.treasureChest,
      );
      expect(result.resolutions.single.goldAmount, inInclusiveRange(8, 50));
      expect(runtime.tileAt(square), isNull);
    });

    test('mystery resolves to exactly treasure or trap and is consumed', () {
      final board = _emptyBoard();
      const square = Square(2, 5);
      final runtime = BattlefieldRuntime(
        definition: battlefieldDefinitions[BattlefieldId.ruinedCauseway]!,
        seed: 108,
      );
      runtime.initialize(board);
      runtime.replaceTiles(const <SpecialTileState>[
        SpecialTileState(
          square: square,
          type: SpecialTileType.mystery,
          pairId: 42,
        ),
      ]);
      board[square.row][square.col] = _piece('mystery-guest');

      expect(
        runtime.advance(board, actingSide: PieceColor.white).resolutions,
        isEmpty,
      );
      expect(
        runtime.advance(board, actingSide: PieceColor.black).resolutions,
        isEmpty,
      );
      expect(
        runtime.advance(board, actingSide: PieceColor.white).resolutions,
        isEmpty,
      );
      final resolution = runtime
          .advance(board, actingSide: PieceColor.black)
          .resolutions
          .single;

      expect(resolution.sourceType, SpecialTileType.mystery);
      expect(
        resolution.resolvedType,
        anyOf(SpecialTileType.treasureChest, SpecialTileType.visibleTrap),
      );
      expect(runtime.tileAt(square), isNull);
    });

    test('visible trap resets its two-round timer when occupant leaves', () {
      final board = _emptyBoard();
      const square = Square(3, 4);
      final runtime = BattlefieldRuntime(
        definition: battlefieldDefinitions[BattlefieldId.ruinedCauseway]!,
        seed: 19,
      );
      runtime.initialize(board);
      runtime.replaceTiles(const <SpecialTileState>[
        SpecialTileState(
          square: square,
          type: SpecialTileType.visibleTrap,
          pairId: 81,
        ),
      ]);
      board[square.row][square.col] = _piece('first-occupant');

      runtime.advance(board, actingSide: PieceColor.white);
      runtime.advance(board, actingSide: PieceColor.black);
      expect(runtime.tileAt(square)!.progress, 1);

      board[square.row][square.col] = null;
      runtime.advance(board, actingSide: PieceColor.white);
      board[square.row][square.col] = _piece('second-occupant');
      runtime.advance(board, actingSide: PieceColor.black);
      expect(runtime.tileAt(square)!.progress, 0);

      runtime.advance(board, actingSide: PieceColor.white);
      runtime.advance(board, actingSide: PieceColor.black);
      expect(runtime.tileAt(square)!.progress, 1);
      final result = runtime.advance(board, actingSide: PieceColor.white);
      expect(result.resolutions.single.pieceId, 'second-occupant');
    });

    test(
      'Chaos Crucible starts empty and spawns exactly every three actions',
      () {
        final runtime = BattlefieldRuntime(
          definition: battlefieldDefinitions[BattlefieldId.chaosCrucible]!,
          seed: 20260730,
        );
        final board = _emptyBoard();

        expect(runtime.initialize(board), isEmpty);
        expect(runtime.activeCap, 8);
        expect(runtime.advance(board).spawnedTiles, isEmpty);
        expect(runtime.advance(board).spawnedTiles, isEmpty);

        final firstPair = runtime.advance(board).spawnedTiles;
        expect(firstPair, hasLength(2));
        expect(firstPair.last.square, mirroredSquare(firstPair.first.square));
        expect(firstPair.last.type, firstPair.first.type);

        expect(runtime.advance(board).spawnedTiles, isEmpty);
        expect(runtime.advance(board).spawnedTiles, isEmpty);
        expect(runtime.advance(board).spawnedTiles, hasLength(2));
      },
    );

    test('Chaos Crucible seeded randomness is reproducible', () {
      final definition = battlefieldDefinitions[BattlefieldId.chaosCrucible]!;
      final first = BattlefieldRuntime(definition: definition, seed: 441);
      final second = BattlefieldRuntime(definition: definition, seed: 441);
      final firstBoard = _emptyBoard();
      final secondBoard = _emptyBoard();
      first.initialize(firstBoard);
      second.initialize(secondBoard);

      final firstSequence = <String>[];
      final secondSequence = <String>[];
      for (var action = 0; action < 12; action++) {
        final firstSpawn = first.advance(firstBoard).spawnedTiles;
        final secondSpawn = second.advance(secondBoard).spawnedTiles;
        if (firstSpawn.isNotEmpty) {
          firstSequence.add(
            '${firstSpawn.first.type.name}:${firstSpawn.first.square.row},${firstSpawn.first.square.col}',
          );
        }
        if (secondSpawn.isNotEmpty) {
          secondSequence.add(
            '${secondSpawn.first.type.name}:${secondSpawn.first.square.row},${secondSpawn.first.square.col}',
          );
        }
      }

      expect(firstSequence, orderedEquals(secondSequence));
      expect(first.tiles, hasLength(8));
      expect(second.tiles, hasLength(8));
    });

    test('Chaos Crucible random pool includes every special tile family', () {
      final definition = battlefieldDefinitions[BattlefieldId.chaosCrucible]!;
      final observed = <SpecialTileType>{};

      for (var seed = 1; seed <= 120; seed++) {
        final runtime = BattlefieldRuntime(definition: definition, seed: seed);
        final board = _emptyBoard();
        runtime.initialize(board);
        runtime.advance(board);
        runtime.advance(board);
        observed.add(runtime.advance(board).spawnedTiles.first.type);
      }

      expect(observed, containsAll(SpecialTileType.values));
    });
  });
}

List<List<ChessPiece?>> _emptyBoard() {
  return List<List<ChessPiece?>>.generate(
    8,
    (_) => List<ChessPiece?>.filled(8, null),
  );
}

ChessPiece _piece(String id) {
  return ChessPiece(
    id: id,
    type: PieceType.pawn,
    color: PieceColor.white,
    countryId: 'mercantile',
    loyalty: 50,
    fairPrice: 8,
  );
}
