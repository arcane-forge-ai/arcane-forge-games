# Living Campaign — Chapter Ending Illustration

Create one original cinematic dark-fantasy illustration that closes the supplied
Crazy Chess chapter. The engine will append the authoritative chapter facts.

## Composition Contract

- Widescreen 16:9, designed as a full-screen result background.
- Show the decisive aftermath, not a generic character lineup or chess diagram.
- Preserve the named characters' supplied canonical appearances and allegiances.
- Emphasize one readable focal action, the battlefield environment, emotional
  consequence, cinematic depth, and dramatic Ashen lighting.
- Keep the central-lower result-control region calm enough for a dark UI scrim.
- Severe but non-graphic dark fantasy: no gore, sexual content, hate, or copied
  franchise designs.
- No letters, captions, logos, UI, watermarks, borders, or embedded typography.
- Painted realism with Ashen black, bone ivory, muted rust, tarnished bronze, and
  restrained cold blue-gray. Victory may be energetic and luminous; defeat must
  remain dark and defiant rather than funereal.

Return only the image.

