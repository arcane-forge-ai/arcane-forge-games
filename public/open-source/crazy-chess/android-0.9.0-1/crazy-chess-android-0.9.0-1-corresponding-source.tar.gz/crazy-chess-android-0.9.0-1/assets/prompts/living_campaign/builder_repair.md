# Living Campaign V2 — Board Builder Repair

Repair the supplied complete Board Builder object against the strict schema and
`validationIssues`. Return only the corrected JSON object. Preserve the locked
Director story, objective, named characters, mission identity, and every valid
board choice. Change only fields needed for legality or schema compliance. This
is the single allowed repair.

Enemy ranks 5–8 are a strong deployment preference, not a hard requirement.
Never move a Director-locked named target or objective piece merely to satisfy
that preference.
