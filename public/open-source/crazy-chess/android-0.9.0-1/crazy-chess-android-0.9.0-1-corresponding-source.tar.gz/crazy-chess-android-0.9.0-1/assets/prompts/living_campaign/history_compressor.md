# Living Campaign V2 — History Compressor

Compress only the supplied ordered older mission memories and existing history
digests. Return the one JSON object required by the strict schema and no prose
outside it.

The narrative must preserve mission order and IDs, major setup and battle facts,
named character introductions, deaths, missing states, returns, allegiance and
recruitment changes, Loyalty-significant choices, unresolved threads, finale
setup, and contradictions that characters merely believe. Do not invent canon,
resolve an open thread, resurrect the dead, or omit any source mission ID.

The game will reject a digest whose counted tokens exceed half the counted source
tokens.

## Few-shot shape example

```json
{
  "schemaVersion": 2,
  "runId": "run_example",
  "digestId": "digest_run_example_m01_m04",
  "sourceMissionIds": ["living_m01","living_m02","living_m03","living_m04"],
  "narrative": "M01–M04: Orsain's divided court lost the Ruined Causeway, held the flooded ford, and recruited the missing Warden Hadrik after exposing the Bell conspiracy. Ysra remains loyal, Cael is missing, Hadrik is an ally, and the unresolved crown claim now points toward Maelin Cinderveil."
}
```
