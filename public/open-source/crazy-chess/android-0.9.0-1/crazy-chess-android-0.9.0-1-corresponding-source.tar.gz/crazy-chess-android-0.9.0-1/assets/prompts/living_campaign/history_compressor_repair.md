# Living Campaign V2 — History Compressor Repair

Repair the supplied complete history digest against the strict schema,
`validationIssues`, required source mission IDs, and half-length token budget.
Return only the corrected JSON object. Preserve all source coverage and critical
canon while removing repetition. This is the single allowed repair.
