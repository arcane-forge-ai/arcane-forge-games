Repair the supplied Living Campaign prologue object. Return exactly one JSON
object with campaignTitle, storyPromise, and prologue and no outside prose. Fix
every validation issue while preserving the supplied initial canon and fixed
Chapter 1. Do not add or remove characters or predetermine future outcomes.
