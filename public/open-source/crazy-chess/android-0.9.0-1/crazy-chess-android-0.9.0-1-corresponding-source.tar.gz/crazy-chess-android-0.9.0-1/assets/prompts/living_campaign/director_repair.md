# Living Campaign V2 — Story Director Repair

Repair the supplied complete Story Director object against the strict schema and
`validationIssues`. Return only the corrected JSON object. Preserve every valid
story decision, participant, character identity, status, objective, finale, and
continuity fact. Do not introduce a different plot merely to make validation
easier. This is the single allowed repair.
