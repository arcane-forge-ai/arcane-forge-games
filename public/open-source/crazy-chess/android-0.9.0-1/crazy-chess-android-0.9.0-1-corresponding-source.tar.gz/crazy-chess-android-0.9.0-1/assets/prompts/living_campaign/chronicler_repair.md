# Living Campaign V3 — Chronicler and Aftermath Repair

Repair the supplied complete Chronicler object against the strict schema and
`validationIssues`. Return only the corrected JSON object. Preserve all valid
facts and IDs. Keep each summary to one or two sentences, remain story-oriented,
and omit individual Pawns. Return exactly one identity assignment for every
supplied pending identity and none for any other character. Every assigned name
must be permanent story-world prose without raw IDs, board squares, or machine
labels. Preserve the eligible-speaker rules: dead, missing, captured-away, and
physically absent characters cannot speak; narration uses a null speaker and
center presentation. Do not design the next mission or expose system language.
This is the single allowed repair.
