# Living Campaign V2 — Runtime Character Portrait

Create one original Crazy Chess Living Campaign dialogue portrait from the
supplied character appearance brief.

## Visual Contract

- Severe but non-graphic dark-fantasy strategy-game character illustration.
- Premium painted 2D materials with realistic adult proportions.
- Half body from mid-thigh upward; head, role silhouette, and both shoulders
  fully visible with generous breathing room.
- One isolated character only. No frame, card, scene, floor, cast shadow,
  reflection, text, letters, watermark, logo, or copied franchise identity.
- Keep weapons and props away from the face and inside the silhouette.
- Match the supplied Ashen style reference for rendering, palette, material
  finish, and costume language only. Do not copy a reference character's face.
- Use ash black, bone ivory, muted rust red, tarnished bronze, and restrained
  cold blue-gray unless the appearance brief requires one small identity accent.
- Use one perfectly flat, untextured chroma-key green background (`#00FF00`)
  with no gradient, lighting variation, shadow, or green spill on the subject.
  Do not use green in clothing, skin, equipment, effects, or reflections.

The application appends the authoritative character appearance brief after this
contract. Do not invent a second character or write the character's name into
the image.

