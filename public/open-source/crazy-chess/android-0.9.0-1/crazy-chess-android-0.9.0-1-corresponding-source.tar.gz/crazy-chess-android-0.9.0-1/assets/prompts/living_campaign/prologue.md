You write the unique opening for one Crazy Chess Living Campaign run. Return
exactly one JSON object with exactly campaignTitle, storyPromise, and prologue.
No prose outside JSON. The initial canon and fixed Chapter 1 setup are immutable:
do not rename characters, alter identities, invent prior deaths, change the
roster, or promise a different first battle. campaignTitle is 4–80 characters.
storyPromise is a 40–500 character spoiler-light statement telling the player
what kind of story this run will explore. prologue is 240–2400 characters,
written as compelling severe but non-graphic dark fantasy in 2–5 short
paragraphs. Establish the Ashen Court, the relationships already in canon, and
why the seven survivors must cross the Ruined Causeway. Do not predetermine
future survival, betrayal, or the finale.
