import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = process.argv[3] ?? 'http://127.0.0.1:8080';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_hifi_special_tiles_regression.mjs ' +
      '<run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const viewports = [
  { width: 1600, height: 900 },
  { width: 1280, height: 720 },
];
const results = [];

const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');

for (const viewport of viewports) {
  const label = `${viewport.width}x${viewport.height}`;
  const artifactDir = path.resolve(root, runDir, 'assisted-browser', label);
  const videoDir = path.join(artifactDir, 'videos');
  await fs.mkdir(videoDir, { recursive: true });

  const browser = await chromium.launch({
    headless: true,
    executablePath: chromeExecutable,
  });
  const context = await browser.newContext({
    viewport,
    recordVideo: { dir: videoDir, size: viewport },
  });
  const page = await context.newPage();
  const consoleMessages = [];
  const pageErrors = [];
  const failedResponses = [];

  page.on('console', (message) => {
    consoleMessages.push({ type: message.type(), text: message.text() });
  });
  page.on('pageerror', (error) => pageErrors.push(error.message));
  page.on('response', (response) => {
    if (response.status() >= 400) {
      failedResponses.push({
        status: response.status(),
        url: response.url(),
      });
    }
  });
  await page.emulateMedia({ reducedMotion: 'reduce' });

  await page.goto(`${baseUrl}/?state=battlefieldArt&reducedMotion=1`, {
    waitUntil: 'domcontentloaded',
  });
  await page.waitForTimeout(4500);
  const screenshotPath = path.join(
    artifactDir,
    'assisted-all-special-tiles.png',
  );
  const screenshotBytes = await page.screenshot({ path: screenshotPath });
  const video = page.video();
  await context.close();
  const videoPath = video ? await video.path() : null;
  await browser.close();

  const errors = consoleMessages.filter(({ type }) => type === 'error');
  const warnings = consoleMessages.filter(({ type }) => type === 'warning');
  const result = {
    viewport,
    assisted: true,
    screenshotPath,
    screenshotSha256: sha256(screenshotBytes),
    consoleErrors: errors,
    consoleWarnings: warnings,
    pageErrors,
    failedResponses,
    videoPath,
    passed:
      screenshotBytes.length > 50_000 &&
      errors.length === 0 &&
      warnings.length === 0 &&
      pageErrors.length === 0 &&
      failedResponses.length === 0 &&
      videoPath !== null,
  };
  await fs.writeFile(
    path.join(artifactDir, 'result.json'),
    `${JSON.stringify(result, null, 2)}\n`,
  );
  results.push(result);
}

const report = {
  kind: 'web-hifi-special-tiles-assisted-regression',
  baseUrl,
  results,
  passed: results.every(({ passed }) => passed),
};
await fs.mkdir(path.resolve(root, runDir, 'assisted-browser'), {
  recursive: true,
});
await fs.writeFile(
  path.resolve(root, runDir, 'assisted-browser', 'report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);

if (!report.passed) {
  process.exitCode = 1;
}
