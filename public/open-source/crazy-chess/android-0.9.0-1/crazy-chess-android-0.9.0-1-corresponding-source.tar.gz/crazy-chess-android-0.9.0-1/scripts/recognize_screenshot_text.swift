import AppKit
import Foundation
import Vision

guard CommandLine.arguments.count >= 2 else {
  FileHandle.standardError.write(Data("usage: recognize_screenshot_text.swift <png> [png...]\n".utf8))
  exit(64)
}

do {
  var images: [[String: Any]] = []
  for argument in CommandLine.arguments.dropFirst() {
    let url = URL(fileURLWithPath: argument)
    guard
      let image = NSImage(contentsOf: url),
      let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil)
    else {
      throw NSError(domain: "ScreenshotOCR", code: 65, userInfo: [
        NSLocalizedDescriptionKey: "could not decode \(argument)"
      ])
    }
    let request = VNRecognizeTextRequest()
    request.revision = VNRecognizeTextRequestRevision3
    request.recognitionLevel = .accurate
    request.usesLanguageCorrection = true
    request.recognitionLanguages = ["zh-Hans", "en-US"]
    try VNImageRequestHandler(cgImage: cgImage, options: [:]).perform([request])
    let rows = (request.results ?? []).compactMap { observation -> [String: Any]? in
      guard let candidate = observation.topCandidates(1).first else { return nil }
      let box = observation.boundingBox
      return [
        "text": candidate.string,
        "confidence": candidate.confidence,
        "x": box.origin.x,
        "y": box.origin.y,
        "width": box.width,
        "height": box.height,
      ]
    }
    images.append(["image": url.lastPathComponent, "path": argument, "rows": rows])
  }
  let output = try JSONSerialization.data(
    withJSONObject: ["images": images],
    options: [.prettyPrinted, .sortedKeys]
  )
  FileHandle.standardOutput.write(output)
  FileHandle.standardOutput.write(Data("\n".utf8))
} catch {
  FileHandle.standardError.write(Data("Vision OCR failed: \(error)\n".utf8))
  exit(70)
}
