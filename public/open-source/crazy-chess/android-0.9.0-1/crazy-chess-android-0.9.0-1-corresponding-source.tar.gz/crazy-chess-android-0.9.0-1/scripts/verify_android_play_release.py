#!/usr/bin/env python3
"""Verify the static release gates for the Crazy Chess Play AAB."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
import zlib


MAX_DEVICE_DOWNLOAD_BYTES = 200 * 1024 * 1024
REQUIRED_ABIS = ("arm64-v8a", "armeabi-v7a")
REQUIRED_NOTICE_ENTRY = "base/assets/flutter_assets/NOTICES.Z"


def _run(command: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )


def _read_notice(data: bytes) -> str:
    for wbits in (zlib.MAX_WBITS | 16, zlib.MAX_WBITS, -zlib.MAX_WBITS):
        try:
            return zlib.decompress(data, wbits).decode("utf-8", errors="replace")
        except zlib.error:
            continue
    return data.decode("utf-8", errors="replace")


def _bundletool_command(bundletool: str) -> list[str]:
    if bundletool.endswith(".jar"):
        java_candidates = []
        java_home = os.environ.get("JAVA_HOME")
        if java_home:
            java_candidates.append(str(Path(java_home) / "bin/java"))
        java_candidates.extend(
            [
                "/opt/homebrew/opt/openjdk@17/bin/java",
                shutil.which("java"),
            ]
        )
        java = next(
            (candidate for candidate in java_candidates if candidate and Path(candidate).exists()),
            "java",
        )
        return [java, "-jar", bundletool]
    return [bundletool]


def _parse_size(output: str) -> int | None:
    matches = re.findall(r"([0-9]+(?:\.[0-9]+)?)\s*(B|KB|MB|GB)", output, re.I)
    if matches:
        value, unit = matches[-1]
        multiplier = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3}[unit.upper()]
        return int(float(value) * multiplier)
    numeric = re.findall(r"^\s*(\d+)\s*,\s*(\d+)\s*$", output, re.M)
    if numeric:
        return max(int(value) for value in numeric[-1])
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--aab",
        type=Path,
        default=Path("build/app/outputs/bundle/release/app-release.aab"),
    )
    parser.add_argument(
        "--bundletool",
        help="bundletool executable or bundletool-all JAR; defaults to BUNDLETOOL or PATH",
    )
    parser.add_argument(
        "--device-spec",
        type=Path,
        default=Path("android/play_device_spec_arm64.json"),
    )
    parser.add_argument(
        "--skip-size",
        action="store_true",
        help="run static checks without the mandatory bundletool size check",
    )
    args = parser.parse_args()

    repo = Path(__file__).resolve().parents[1]
    aab = (repo / args.aab).resolve() if not args.aab.is_absolute() else args.aab
    device_spec = (
        (repo / args.device_spec).resolve()
        if not args.device_spec.is_absolute()
        else args.device_spec
    )
    errors: list[str] = []

    if not aab.is_file():
        errors.append(f"AAB does not exist: {aab}")
        print("\n".join(errors))
        return 1

    build_gradle = repo / "android/app/build.gradle.kts"
    build_text = build_gradle.read_text(encoding="utf-8")
    if "compileSdk = 36" not in build_text:
        errors.append("android/app/build.gradle.kts does not pin compileSdk to 36")
    if "targetSdk = 36" not in build_text:
        errors.append("android/app/build.gradle.kts does not pin targetSdk to 36")

    with zipfile.ZipFile(aab) as bundle:
        names = set(bundle.namelist())
        if any("/x86_64/" in name for name in names):
            errors.append("AAB still contains x86_64 native libraries")
        for abi in REQUIRED_ABIS:
            expected = f"base/lib/{abi}/libstockfish.so"
            if expected not in names:
                errors.append(f"AAB is missing {expected}")
        forbidden_fragments = (".env.preview", "key.properties", ".jks", ".keystore")
        for name in names:
            if any(fragment in name for fragment in forbidden_fragments):
                errors.append(f"AAB contains a forbidden release secret/config path: {name}")
        if REQUIRED_NOTICE_ENTRY not in names:
            errors.append(f"AAB is missing {REQUIRED_NOTICE_ENTRY}")
        else:
            notice = _read_notice(bundle.read(REQUIRED_NOTICE_ENTRY)).lower()
            if "stockfish" not in notice or "gpl" not in notice:
                errors.append("AAB notices do not contain Stockfish GPL attribution")

    tracked_files = _run(["git", "ls-files"], repo).stdout.splitlines()
    tracked_secrets = [
        path
        for path in tracked_files
        if path in {"android/key.properties"}
        or path.endswith((".jks", ".keystore"))
    ]
    if tracked_secrets:
        errors.append(
            "Signing properties or keystore files are tracked by Git: "
            + ", ".join(tracked_secrets)
        )

    jarsigner_candidates = [
        "/opt/homebrew/opt/openjdk@17/bin/jarsigner",
        shutil.which("jarsigner"),
    ]
    jarsigner = next(
        (candidate for candidate in jarsigner_candidates if candidate and Path(candidate).exists()),
        None,
    )
    if jarsigner is None:
        errors.append("jarsigner is not available to verify the AAB signature")
    else:
        signed = _run([jarsigner, "-verify", str(aab)], repo)
        if signed.returncode != 0 or "jar verified" not in signed.stdout.lower():
            errors.append("jarsigner did not verify the release AAB signature")
        else:
            print("\nAAB signature verification: jar verified")

        keytool_candidates = [
            "/opt/homebrew/opt/openjdk@17/bin/keytool",
            shutil.which("keytool"),
        ]
        keytool = next(
            (
                candidate
                for candidate in keytool_candidates
                if candidate and Path(candidate).exists()
            ),
            None,
        )
        if keytool is not None:
            certificate = _run(
                [keytool, "-printcert", "-jarfile", str(aab)],
                repo,
            )
            print("AAB signer certificate:")
            for line in certificate.stdout.splitlines():
                if line.startswith(("Owner:", "Issuer:", "Valid from:", "\tSHA256:")):
                    print(line)

    if args.skip_size:
        print("\nBundletool size check: SKIPPED by request")
    else:
        bundletool = args.bundletool or os.environ.get("BUNDLETOOL")
        if not bundletool:
            bundletool = shutil.which("bundletool")
        if not bundletool:
            errors.append(
                "bundletool is required for the arm64 per-device size gate; "
                "set BUNDLETOOL or pass --bundletool"
            )
        elif not device_spec.is_file():
            errors.append(f"Device specification does not exist: {device_spec}")
        else:
            manifest_result = _run(
                _bundletool_command(bundletool)
                + ["dump", "manifest", f"--bundle={aab}", "--module=base"],
                repo,
            )
            manifest = manifest_result.stdout
            if manifest_result.returncode != 0:
                errors.append("bundletool failed to dump the release manifest")
            else:
                package = re.search(r'\bpackage="([^"]+)"', manifest)
                version_name = re.search(r'android:versionName="([^"]+)"', manifest)
                version_code = re.search(r'android:versionCode="([^"]+)"', manifest)
                min_sdk = re.search(r'android:minSdkVersion="([^"]+)"', manifest)
                target_sdk = re.search(r'android:targetSdkVersion="([^"]+)"', manifest)
                compile_sdk = re.search(r'android:compileSdkVersion="([^"]+)"', manifest)
                expected_version = re.search(
                    r"^version:\s*([0-9.]+)\+(\d+)",
                    (repo / "pubspec.yaml").read_text(encoding="utf-8"),
                    re.MULTILINE,
                )
                expected_name = expected_version.group(1) if expected_version else None
                expected_code = expected_version.group(2) if expected_version else None
                if package is None or package.group(1) != "ai.arcaneforge.crazy_chess":
                    errors.append("AAB package name is not ai.arcaneforge.crazy_chess")
                if expected_name is None or version_name is None or version_name.group(1) != expected_name:
                    errors.append("AAB versionName does not match pubspec.yaml")
                if expected_code is None or version_code is None or version_code.group(1) != expected_code:
                    errors.append("AAB versionCode does not match pubspec.yaml")
                if compile_sdk is None or compile_sdk.group(1) != "36":
                    errors.append("AAB manifest compile SDK is not 36")
                if target_sdk is None or target_sdk.group(1) != "36":
                    errors.append("AAB manifest target SDK is not 36")
                if min_sdk is None or int(min_sdk.group(1)) < 21:
                    errors.append("AAB minimum SDK is lower than the supported API 21 floor")
                if "android.permission.INTERNET" not in manifest:
                    errors.append("AAB manifest is missing android.permission.INTERNET")
                if not errors:
                    print(
                        "Manifest: package=%s versionName=%s versionCode=%s "
                        "minSdk=%s targetSdk=%s compileSdk=%s"
                        % (
                            package.group(1),
                            version_name.group(1),
                            version_code.group(1),
                            min_sdk.group(1),
                            target_sdk.group(1),
                            compile_sdk.group(1),
                        )
                    )
            with tempfile.TemporaryDirectory(prefix="crazy_chess_bundletool_") as temp_dir:
                apks = Path(temp_dir) / "arm64.apks"
                build_apks = _run(
                    _bundletool_command(bundletool)
                    + [
                        "build-apks",
                        f"--bundle={aab}",
                        f"--output={apks}",
                        f"--device-spec={device_spec}",
                        "--overwrite",
                    ],
                    repo,
                )
                if build_apks.returncode != 0:
                    errors.append("bundletool failed to build the arm64 device APK set")
                else:
                    size_result = _run(
                        _bundletool_command(bundletool)
                        + ["get-size", "total", f"--apks={apks}"],
                        repo,
                    )
                    print("\nBundletool arm64 size estimate:")
                    print(size_result.stdout.strip())
                    if size_result.returncode != 0:
                        errors.append("bundletool failed to calculate the arm64 size estimate")
                    else:
                        size = _parse_size(size_result.stdout)
                        if size is None:
                            errors.append("Could not parse bundletool's arm64 size estimate")
                        elif size > MAX_DEVICE_DOWNLOAD_BYTES:
                            errors.append(
                                "arm64 device download estimate exceeds 200 MiB: "
                                f"{size / 1024 / 1024:.1f} MiB"
                            )

    if errors:
        print("\nAndroid Play release verification FAILED:")
        print("\n".join(f"- {error}" for error in errors))
        return 1

    print("\nAndroid Play release verification PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
