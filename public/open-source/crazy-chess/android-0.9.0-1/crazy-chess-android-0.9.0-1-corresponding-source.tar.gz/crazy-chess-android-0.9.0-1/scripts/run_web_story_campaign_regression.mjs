import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = process.argv[3] ?? 'http://127.0.0.1:8080';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_story_campaign_regression.mjs ' +
      '<run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const viewportFilter = process.env.VIEWPORT_FILTER;
const flowFilter = process.env.FLOW_FILTER;
const aggregateOnly = process.env.AGGREGATE_ONLY === '1';
const viewports = [
  { width: 1600, height: 900 },
  { width: 1280, height: 720 },
].filter(
  ({ width, height }) =>
    !viewportFilter || viewportFilter === `${width}x${height}`,
);

const flowDefinitions = [
  { label: 'm01-natural', missionId: 'm01', completedThrough: 0 },
  { label: 'm04-assisted', missionId: 'm04', completedThrough: 3 },
  { label: 'm07-assisted', missionId: 'm07', completedThrough: 6 },
].filter(({ label }) => !flowFilter || flowFilter === label);

const allMissions = ['m01', 'm02', 'm03', 'm04', 'm05', 'm06', 'm07'];
const allCharacters = [
  'king_rowan',
  'captain_mara',
  'knight_garran',
  'bishop_elowen',
  'rook_bram',
  'queen_sabine',
];
const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');

const profileFor = ({ missionId, completedThrough }) => ({
  schemaVersion: 1,
  unlockedMissionIds: allMissions.slice(0, completedThrough + 1),
  completedMissionIds: allMissions.slice(0, completedThrough),
  recruitedCharacterIds: allCharacters,
  seenSceneIds: [],
  lastSelectedNode: missionId,
});

const captureFlow = async ({ viewport, flow }) => {
  const artifactDir = path.resolve(
    root,
    runDir,
    'browser',
    `${viewport.width}x${viewport.height}`,
    flow.label,
  );
  const videoDir = path.join(artifactDir, 'videos');
  await fs.mkdir(videoDir, { recursive: true });
  const browser = await chromium.launch({
    headless: true,
    executablePath: chromeExecutable,
  });
  const context = await browser.newContext({
    viewport,
    recordVideo: { dir: videoDir, size: viewport },
  });
  if (flow.missionId !== 'm01') {
    const encodedProfile = JSON.stringify(JSON.stringify(profileFor(flow)));
    await context.addInitScript(
      ({ value }) => {
        window.localStorage.setItem('story_campaign.profile.v1', value);
      },
      { value: encodedProfile },
    );
  }
  const page = await context.newPage();
  const consoleMessages = [];
  const pageErrors = [];
  const failedResponses = [];
  page.on('console', (message) => {
    consoleMessages.push({ type: message.type(), text: message.text() });
  });
  page.on('pageerror', (error) =>
    pageErrors.push(error.stack ?? error.message),
  );
  page.on('response', (response) => {
    if (response.status() >= 400) {
      failedResponses.push({ status: response.status(), url: response.url() });
    }
  });
  await page.emulateMedia({ reducedMotion: 'no-preference' });

  const shots = [];
  const screenshot = async (name) => {
    const file = path.join(artifactDir, `${name}.png`);
    let bytes;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      bytes = await page.screenshot({ path: file });
      if (bytes.length > 50_000) break;
      await page.waitForTimeout(800);
    }
    shots.push({
      name,
      file: path.relative(path.resolve(root, runDir), file),
      bytes: bytes.length,
      sha256: sha256(bytes),
    });
  };
  const scaleX = viewport.width / 1600;
  const scaleY = viewport.height / 900;
  const clickStage = async (x, y, waitMs = 850) => {
    await page.mouse.click(x * scaleX, y * scaleY);
    await page.waitForTimeout(waitMs);
  };

  await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(3600);
  await clickStage(280, 670);
  await clickStage(1190, 205);
  await clickStage(220, 665);
  await screenshot('story-mode-selected');
  await clickStage(1400, 844, 2200);
  await screenshot(`${flow.missionId}-campaign-map`);
  await clickStage(1390, 810, 1200);
  await screenshot(`${flow.missionId}-briefing`);
  await page.keyboard.press('Enter');
  await page.waitForTimeout(240);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(350);
  await screenshot(`${flow.missionId}-backlog`);
  await page.keyboard.press('Escape');
  for (let index = 0; index < 11; index += 1) {
    await page.keyboard.press('Enter');
    await page.waitForTimeout(90);
  }
  await page.waitForTimeout(1200);
  await screenshot(`${flow.missionId}-battle-opening`);

  const video = page.video();
  await context.close();
  const absoluteVideoPath = video ? await video.path() : null;
  await browser.close();

  const consoleErrors = consoleMessages.filter(({ type }) => type === 'error');
  const consoleWarnings = consoleMessages.filter(
    ({ type }) => type === 'warning',
  );
  const result = {
    viewport,
    label: flow.label,
    missionId: flow.missionId,
    profileSeeded: flow.missionId !== 'm01',
    shots,
    consoleErrors,
    consoleWarnings,
    pageErrors,
    failedResponses,
    videoPath: absoluteVideoPath
      ? path.relative(path.resolve(root, runDir), absoluteVideoPath)
      : null,
  };
  result.passed =
    shots.length === 5 &&
    shots.every(({ bytes }) => bytes > 50_000) &&
    new Set(shots.map(({ sha256: hash }) => hash)).size === shots.length &&
    consoleErrors.length === 0 &&
    consoleWarnings.length === 0 &&
    pageErrors.length === 0 &&
    failedResponses.length === 0 &&
    result.videoPath !== null;
  await fs.writeFile(
    path.join(artifactDir, 'result.json'),
    `${JSON.stringify(result, null, 2)}\n`,
  );
  return result;
};

const results = [];
for (const viewport of viewports) {
  for (const flow of flowDefinitions) {
    if (aggregateOnly) {
      const resultPath = path.resolve(
        root,
        runDir,
        'browser',
        `${viewport.width}x${viewport.height}`,
        flow.label,
        'result.json',
      );
      results.push(JSON.parse(await fs.readFile(resultPath, 'utf8')));
    } else {
      results.push(await captureFlow({ viewport, flow }));
    }
  }
}

const report = {
  kind: 'web-story-campaign-regression',
  baseUrl,
  requiredCheckpoints: [
    'S03 Story Campaign selection',
    'seven-node campaign map',
    'blocking portrait briefing',
    'Esc dialogue backlog',
    'objective HUD and authored battle opening',
    'M01 natural fresh profile',
    'M04 seeded visual coverage',
    'M07 seeded visual coverage',
  ],
  limitations: [
    'M04 and M07 use a seeded between-mission profile for visual coverage; this is assisted coverage, not a claim of a natural full-campaign completion.',
    'Universal player-checkmate victory, including M01, and Story stalemate turn-skip are forced in deterministic Flutter tests; this browser flow verifies surrounding campaign presentation and does not claim natural terminal-state coverage.',
    'New character and map candidates remain owner-review sources; runtime screenshots intentionally retain existing production placeholders.',
  ],
  results,
  passed: results.length > 0 && results.every(({ passed }) => passed),
};
await fs.mkdir(path.resolve(root, runDir), { recursive: true });
await fs.writeFile(
  path.resolve(root, runDir, 'browser-report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);

const rows = results
  .map(
    (result) => `<tr><td>${result.viewport.width}×${result.viewport.height}</td><td>${result.label}</td><td>${result.profileSeeded ? 'assisted profile' : 'fresh profile'}</td><td class="${result.passed ? 'pass' : 'fail'}">${result.passed ? 'PASS' : 'FAIL'}</td><td>${result.shots.length}</td><td>${result.consoleErrors.length}/${result.consoleWarnings.length}/${result.pageErrors.length}/${result.failedResponses.length}</td><td><a href="${result.videoPath}">video</a></td></tr>`,
  )
  .join('\n');
const galleries = results
  .map(
    (result) => `<section><h2>${result.viewport.width}×${result.viewport.height} · ${result.label}</h2><div class="grid">${result.shots
      .map(
        (shot) => `<figure><a href="${shot.file}"><img src="${shot.file}" alt="${shot.name}"></a><figcaption>${shot.name}</figcaption></figure>`,
      )
      .join('')}</div></section>`,
  )
  .join('\n');
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Story Campaign Browser Review</title><style>body{margin:0;background:#090d10;color:#e9e1d2;font:15px/1.5 system-ui;padding:32px}main{max-width:1280px;margin:auto}h1,h2{font-family:Georgia,serif;color:#efca75}table{width:100%;border-collapse:collapse;background:#11181d}th,td{padding:10px;border:1px solid #334049;text-align:left}.pass{color:#7de0aa}.fail{color:#ff8f83}.note{background:#172028;border-left:4px solid #efca75;padding:14px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}figure{margin:0;background:#12191f;padding:10px;border:1px solid #2c3942}img{display:block;width:100%;height:auto}figcaption{padding-top:8px;color:#cbbd9f}a{color:#89c7ff}</style></head><body><main><h1>Story Campaign Browser Review</h1><p class="note"><strong>Victory clarity:</strong> M01 now labels both win routes—reach a4 with King Rowan or checkmate the enemy King—on the campaign map, throughout the briefing, and above the live board. Recorded screenshots verify the hierarchy and safe areas at both target viewports.</p><p class="note"><strong>Rule correction:</strong> Deterministic Flutter tests prove White checkmate completes every current Story mission, including M01, while a non-check no-legal-move court is announced and passed.</p><p class="note">M01 is a fresh-profile natural entry. M04 and M07 are explicitly assisted profile-seeded visual checks, not a completed seven-mission playthrough. New candidate art remains unselected.</p><table><thead><tr><th>Viewport</th><th>Flow</th><th>State</th><th>Result</th><th>Shots</th><th>Console/Warn/Page/HTTP</th><th>Video</th></tr></thead><tbody>${rows}</tbody></table>${galleries}</main></body></html>`;
await fs.writeFile(path.resolve(root, runDir, 'report.html'), html);
console.log(JSON.stringify(report, null, 2));
if (!report.passed) process.exitCode = 1;
