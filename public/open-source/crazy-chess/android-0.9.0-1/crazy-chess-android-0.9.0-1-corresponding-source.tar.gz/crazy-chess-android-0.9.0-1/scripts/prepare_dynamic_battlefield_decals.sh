#!/bin/sh
set -eu

candidate_root="assets/generated/dynamic_battlefields/candidates"
output_root="assets/generated/dynamic_battlefields/special_tiles"

mkdir -p "$output_root"

ffmpeg -loglevel error -y \
  -i "$candidate_root/beneficial_atlas_1.png" \
  -vf "crop=512:512:0:0,format=rgba" \
  -frames:v 1 -update 1 "$output_root/knight_shrine.png"

ffmpeg -loglevel error -y \
  -i "$candidate_root/beneficial_atlas_1.png" \
  -vf "crop=512:512:512:0,format=rgba" \
  -frames:v 1 -update 1 "$output_root/treasure_chest.png"

ffmpeg -loglevel error -y \
  -i "$candidate_root/beneficial_atlas_1.png" \
  -vf "crop=512:512:0:512,format=rgba" \
  -frames:v 1 -update 1 "$output_root/diamond_ring.png"

# The selected trap has a separable false checkerboard inside its open jaw.
# Removing only high neutral values keeps the authored metal/red silhouette and
# turns the opening into real transparency.
ffmpeg -loglevel error -y \
  -i "$candidate_root/hazard_atlas_2.png" \
  -filter_complex \
  "crop=512:512:0:256,split=3[base][origalpha][keysrc];[origalpha]alphaextract[oa];[keysrc]colorkey=0xffffff:0.18:0.03,alphaextract[ka];[oa][ka]blend=all_mode=multiply[mask];[base][mask]alphamerge,format=rgba[out]" \
  -map "[out]" \
  -frames:v 1 -update 1 "$output_root/visible_trap.png"

ffmpeg -loglevel error -y \
  -i "$candidate_root/hazard_atlas_2.png" \
  -vf "crop=512:512:512:256,format=rgba" \
  -frames:v 1 -update 1 "$output_root/mystery.png"
