import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = process.argv[3] ?? 'http://127.0.0.1:8089';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_living_campaign_regression.mjs ' +
      '<run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');
const configuredViewports = [
  { width: 1600, height: 900 },
  { width: 1280, height: 720 },
];
const viewportFilter = process.env.VIEWPORT_FILTER;
const viewports = viewportFilter
  ? configuredViewports.filter(
      ({ width, height }) => `${width}x${height}` === viewportFilter,
    )
  : configuredViewports;

if (viewports.length === 0) {
  throw new Error(
    `VIEWPORT_FILTER=${viewportFilter} does not match a configured viewport`,
  );
}

const captureFlow = async (viewport) => {
  const artifactDir = path.resolve(
    root,
    runDir,
    'browser',
    `${viewport.width}x${viewport.height}`,
    'living-campaign-assisted',
  );
  const videoDir = path.join(artifactDir, 'videos');
  await fs.mkdir(videoDir, { recursive: true });
  const browser = await chromium.launch({
    headless: true,
    executablePath: chromeExecutable,
  });
  const context = await browser.newContext({
    viewport,
    recordVideo: { dir: videoDir, size: viewport },
  });
  const tracePath = path.join(artifactDir, 'trace.zip');
  await context.tracing.start({
    screenshots: true,
    snapshots: true,
    sources: true,
  });
  const page = await context.newPage();
  const consoleMessages = [];
  const pageErrors = [];
  const failedResponses = [];
  page.on('console', (message) => {
    consoleMessages.push({ type: message.type(), text: message.text() });
  });
  page.on('pageerror', (error) => {
    pageErrors.push(error.stack ?? error.message);
  });
  page.on('response', (response) => {
    if (response.status() >= 400) {
      failedResponses.push({ status: response.status(), url: response.url() });
    }
  });
  await page.emulateMedia({ reducedMotion: 'no-preference' });

  const shots = [];
  const screenshot = async (name, { fullPage = false } = {}) => {
    const file = path.join(artifactDir, `${name}.png`);
    let bytes;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      bytes = await page.screenshot({ path: file, fullPage });
      if (bytes.length > 50_000) break;
      await page.waitForTimeout(700);
    }
    shots.push({
      name,
      file: path.relative(path.resolve(root, runDir), file),
      bytes: bytes.length,
      sha256: sha256(bytes),
    });
  };
  const pause = async (waitMs = 550) => page.waitForTimeout(waitMs);
  const scaleX = viewport.width / 1600;
  const scaleY = viewport.height / 900;
  const button = (name, exact = true) =>
    page.getByRole('button', { name, exact }).first();
  const clickButton = async (name, waitMs = 550, exact = true) => {
    const target = button(name, exact);
    await target.waitFor({ state: 'visible', timeout: 12_000 });
    await target.click();
    await page.waitForTimeout(waitMs);
  };
  const enableFlutterSemantics = async () => {
    await page.waitForSelector('flt-semantics-placeholder', {
      state: 'attached',
      timeout: 15_000,
    });
    await page.evaluate(() => {
      document.querySelector('flt-semantics-placeholder')?.click();
    });
    await button('Press Start').waitFor({ state: 'visible', timeout: 15_000 });
  };
  const navigateToLivingHub = async () => {
    await clickButton('Press Start', 750);
    await clickButton('Play', 750);
    await clickButton('Living Campaign', 250);
    await clickButton('Confirm Living Campaign', 900);
    await button('Begin New Living Campaign').waitFor({
      state: 'visible',
      timeout: 12_000,
    }).catch(async () => {
      await button('Continue Story').waitFor({
        state: 'visible',
        timeout: 12_000,
      });
    });
  };

  await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(3000);
  await enableFlutterSemantics();
  await navigateToLivingHub();
  await screenshot('01-new-run-hub');

  await clickButton('Begin New Living Campaign', 900);
  await screenshot('02-fixed-m01-ready-hub');
  await clickButton('Continue Story', 750);
  await screenshot('03-fixed-m01-prologue');
  await clickButton('Begin Chapter 1', 750);
  await screenshot('04-fixed-m01-dialogue');
  await clickButton('Backlog', 450);
  await screenshot('05-dialogue-backlog');
  await clickButton('Return', 350);
  await clickButton('Skip to Briefing', 650);
  await screenshot('06-fixed-m01-briefing');
  await clickButton('Enter Battle', 900);
  await screenshot('07-fixed-m01-battle');

  // Select Dame Ysra on a1 and verify the shared inspector resolves her
  // canonical name and portrait instead of the generic White Rook card.
  // Wait for the battlefield-awakening presentation lock to clear first.
  await pause(1800);
  await page.mouse.click(338 * scaleX, 793 * scaleY);
  await pause(450);
  await screenshot('08-named-piece-inspector');
  await page.getByText(/Dame Ysra Stonehand/).waitFor({
    state: 'visible',
    timeout: 8_000,
  });

  // Assisted terminal state: this button exists only in the explicit
  // LIVING_CAMPAIGN_DEMO acceptance build. Natural entry and presentation are
  // covered above; deterministic game-state transitions remain unit-tested.
  await clickButton('QA: Resolve Chapter', 650);
  await screenshot('09-immediate-outcome');

  // Continue durably seals the outcome, then starts one deterministic text
  // closure and one deterministic image closure at the same time. The first
  // image attempt deliberately fails so the aftermath can prove that reading
  // hides the art latency without making the fallback path invisible.
  await clickButton('Continue', 0);
  await page
    .getByText('AFTER THE LAST MOVE', { exact: true })
    .waitFor({ state: 'visible', timeout: 4_000 });
  await screenshot('10-concurrent-chapter-closure-loading');
  await page.getByText('CHAPTER 1 · AFTERMATH', { exact: true }).waitFor({
    state: 'visible',
    timeout: 8_000,
  });
  await screenshot('11-aftermath-first-line');
  await clickButton('Backlog', 250);
  await screenshot('12-aftermath-backlog');
  await clickButton('Return', 250);
  await clickButton('Continue', 350);
  await screenshot('13-aftermath-survivor-dialogue');
  await clickButton('Skip', 250);
  await button('Recall the Final Moment').waitFor({
    state: 'visible',
    timeout: 8_000,
  });
  await screenshot('13a-ending-art-fallback-after-aftermath');
  await clickButton('Recall the Final Moment', 0);
  await page
    .getByText('THE CHRONICLE REMEMBERS', { exact: true })
    .waitFor({ state: 'visible', timeout: 4_000 });
  await screenshot('13b-ending-art-retry-loading');
  await button('Continue the Chronicle').waitFor({
    state: 'visible',
    timeout: 8_000,
  });
  await screenshot('13c-illustrated-chapter-ending');

  // Starting the paid-shaped pipeline returns to the hub immediately. The
  // acceptance gateway deliberately pauses each production stage so this pass
  // can prove navigation remains usable while Chronicler, Director, and Board
  // Builder work in the background.
  await clickButton('Continue the Chronicle', 50);
  await button('Play Another Mode').waitFor({
    state: 'visible',
    timeout: 4_000,
  });
  await screenshot('14-chronicle-background-hub');
  await clickButton('Play Another Mode', 350);
  await button('SCRIPTING').waitFor({ state: 'visible', timeout: 4_000 });
  await screenshot('15-other-mode-scripting');
  await button('READY').waitFor({ state: 'visible', timeout: 12_000 });
  await screenshot('16-other-mode-ready');

  // The compact global Story Director pill is also the return path.
  await clickButton('READY', 750);
  await button('Continue Story').waitFor({ state: 'visible', timeout: 8_000 });
  await page.getByText('A FACE YET UNSEEN', { exact: true }).waitFor({
    state: 'visible',
    timeout: 8_000,
  });
  await button('Seek Their Likeness Again').waitFor({
    state: 'visible',
    timeout: 8_000,
  });
  await screenshot('17-generated-m02-ready-with-face-unseen');
  await clickButton('Continue Story', 650);
  await screenshot('18-generated-m02-dialogue');
  await clickButton('Continue', 550);
  await clickButton('Continue', 550);
  await page
    .getByText('You crossed one broken road. The bells will bury the next.', {
      exact: true,
    })
    .waitFor({
    state: 'visible',
    timeout: 8_000,
  });
  await screenshot('19-bell-warden-class-fallback-dialogue');
  await clickButton('Continue', 550);
  await page
    .getByText('Then the crown will answer with a bell of its own.', {
      exact: true,
    })
    .waitFor({
    state: 'visible',
    timeout: 8_000,
  });
  await screenshot('20-selected-maelin-a-dialogue');
  await clickButton('Run Archive', 650);
  await clickButton('Seek Their Likeness Again', 250);
  await button('Authorize Retry').waitFor({ state: 'visible', timeout: 8_000 });
  await screenshot('21-explicit-portrait-retry-authorization');
  await clickButton('Authorize Retry', 900);
  await button('Seek Their Likeness Again').waitFor({
    state: 'detached',
    timeout: 8_000,
  });
  await page.getByText('A FACE YET UNSEEN', { exact: true }).waitFor({
    state: 'detached',
    timeout: 8_000,
  });
  await screenshot('22-run-local-portrait-ready-without-locking-story');
  await clickButton('Continue Story', 500);
  await clickButton('Continue', 550);
  await clickButton('Continue', 550);
  await page
    .getByText('You crossed one broken road. The bells will bury the next.', {
      exact: true,
    })
    .waitFor({
    state: 'visible',
    timeout: 8_000,
  });
  await screenshot('23-bell-warden-run-local-portrait-dialogue');
  await clickButton('Skip to Briefing', 650);
  await screenshot('24-generated-m02-briefing');
  await clickButton('Run Archive', 650);
  await clickButton('History & Canon', 650);
  await screenshot('25-chronological-chapter-review');
  // ExpansionTile labels are painted inside one Flutter semantics node, so
  // activate the visible disclosure arrow at its responsive position.
  await page.mouse.click(1500 * scaleX, 350 * scaleY);
  await pause(450);
  await screenshot('26-expanded-prebattle-conversation');
  // Flutter currently exposes these tabs as labeled semantics rather than
  // actionable tab roles, so use their stable responsive tab-strip positions.
  await page.mouse.click(215 * scaleX, 141 * scaleY);
  await pause(500);
  await screenshot('27-canon-characters');
  await page.mouse.click(355 * scaleX, 141 * scaleY);
  await pause(500);
  await screenshot('28-unfinished-tales');
  await clickButton('Back to Living Campaign hub', 650);

  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2800);
  await enableFlutterSemantics();
  await navigateToLivingHub();
  await button('Continue Story').waitFor({ state: 'visible', timeout: 8_000 });
  await screenshot('29-indexeddb-restart');
  await clickButton('Living AI Settings', 650);
  await page.getByText('GENERATION DIAGNOSTICS', { exact: true }).waitFor({
    state: 'visible',
    timeout: 8_000,
  });
  await screenshot('30-living-ai-diagnostics-default-off');

  const selectionReview = path.resolve(
    root,
    'test_result/20260810-003229_living-campaign-v2-portrait-generation/selection.html',
  );
  await page.goto(pathToFileURL(selectionReview).href, {
    waitUntil: 'networkidle',
  });
  await screenshot('31-owner-selected-fixed-and-fallback-pools', {
    fullPage: true,
  });

  const video = page.video();
  await context.tracing.stop({ path: tracePath });
  await context.close();
  const absoluteVideoPath = video ? await video.path() : null;
  await browser.close();

  const consoleErrors = consoleMessages.filter(({ type }) => type === 'error');
  const consoleWarnings = consoleMessages.filter(
    ({ type }) => type === 'warning',
  );
  const knownConsoleWarnings = consoleWarnings.filter(({ text }) =>
    text.includes('The AudioContext was not allowed to start'),
  );
  const unexpectedConsoleWarnings = consoleWarnings.filter(
    ({ text }) => !text.includes('The AudioContext was not allowed to start'),
  );
  const musicPlaybackLogs = consoleMessages.filter(({ text }) =>
    text.includes('[GameAudio] music_started'),
  );
  const requiredLivingMusicCues = [
    'living_entry_hub',
    'living_story_briefing',
    'living_battle',
    'living_victory_result',
  ];
  const missingLivingMusicCues = requiredLivingMusicCues.filter(
    (cue) => !musicPlaybackLogs.some(({ text }) =>
      text.includes(`cue=${cue}`) &&
      text.includes('candidate=') &&
      text.includes('asset=runtime/audio/living_campaign/music/'),
    ),
  );
  const result = {
    viewport,
    label: 'living-campaign-assisted',
    fixture: 'LIVING_CAMPAIGN_DEMO=true',
    naturalCoverage: [
      'mode selection and local hub entry',
      'immediate fixed M01 opening, exact dialogue path, briefing, and board',
      'named-piece inspector resolves Dame Ysra canonical identity and portrait',
      'immediate result and concurrent chapter-closure loading',
      'post-battle aftermath dialogue with Backlog and Skip while ending art resolves independently',
      'ending-art fallback, explicit retry, and illustrated result',
      'asynchronous Director and Builder progress on the hub from the already accepted mission memory',
      'switching to another mode while scripting and observing READY in place',
      'global Story Director pill return to validated generated M02',
      'generated M02 dialogue and briefing',
      'mission-ready A FACE YET UNSEEN state and identity-stable class fallback',
      'selected Lady Maelin candidate A at dialogue scale',
      'explicit portrait retry authorization without relocking the mission',
      'run-local portrait replacement and IndexedDB reload persistence',
      'all four selected fixed portraits and both fallback options for five classes',
      'chronological chapter review with setup, collapsible conversation, battle summary, and ending art',
      'character review and Unfinished Tales without technical generation records by default',
      'IndexedDB active-run persistence across reload',
      'Living AI diagnostics default-off controls and source labels',
      'developer console identifies each Living music cue and original candidate label',
    ],
    assistedCoverage: [
      'Chapter 1 terminal victory uses the explicit QA resolve button',
      'the closure text, Director, and Builder use deterministic acceptance fixtures but pass production schemas and validators',
    ],
    shots,
    consoleErrors,
    knownConsoleWarnings,
    unexpectedConsoleWarnings,
    musicPlaybackLogs,
    requiredLivingMusicCues,
    missingLivingMusicCues,
    pageErrors,
    failedResponses,
    tracePath: path.relative(path.resolve(root, runDir), tracePath),
    videoPath: absoluteVideoPath
      ? path.relative(path.resolve(root, runDir), absoluteVideoPath)
      : null,
  };
  result.passed =
    shots.length === 34 &&
    shots.every(({ bytes }) => bytes > 50_000) &&
    new Set(shots.map(({ sha256: hash }) => hash)).size === shots.length &&
    consoleErrors.length === 0 &&
    unexpectedConsoleWarnings.length === 0 &&
    missingLivingMusicCues.length === 0 &&
    pageErrors.length === 0 &&
    failedResponses.length === 0 &&
    result.videoPath !== null &&
    result.tracePath !== null;
  await fs.writeFile(
    path.join(artifactDir, 'console.json'),
    `${JSON.stringify(consoleMessages, null, 2)}\n`,
  );
  await fs.writeFile(
    path.join(artifactDir, 'page-errors.json'),
    `${JSON.stringify(pageErrors, null, 2)}\n`,
  );
  await fs.writeFile(
    path.join(artifactDir, 'failed-responses.json'),
    `${JSON.stringify(failedResponses, null, 2)}\n`,
  );
  await fs.writeFile(
    path.join(artifactDir, 'result.json'),
    `${JSON.stringify(result, null, 2)}\n`,
  );
  return result;
};

const results = [];
for (const viewport of viewports) {
  results.push(await captureFlow(viewport));
}

const report = {
  kind: 'web-living-campaign-regression',
  baseUrl,
  acceptanceBuild: 'debug-mode local artifact with LIVING_CAMPAIGN_DEMO=true',
  requiredCheckpoints: [
    'separate Living Campaign mode entry',
    'one-active-run local hub',
    'immediate fixed M01 prologue, exact dialogue, briefing, and Ruined Causeway board',
    'named-piece inspector and immediate outcome',
    'concurrent closure loading, aftermath dialogue, Backlog, Skip, art fallback, retry, and illustrated result',
    'asynchronous Continue the Chronicle launch after illustrated results',
    'usable mode selection with SCRIPTING then READY status',
    'global status pill return to generated M02 dialogue and briefing',
    'A FACE YET UNSEEN fallback, selected fixed recruit, explicit retry, replacement, and reload persistence',
    'owner-selected fixed portrait and two-option fallback pool review gallery',
    'chronological chapter, character, Unfinished Tales, and event history with diagnostics hidden by default',
    'IndexedDB restart persistence and storage meter',
    'Living AI warning, model defaults, and effective-source labels',
  ],
  limitations: [
    'The browser terminal state uses the visible QA resolve action; natural chess terminal behavior is covered by deterministic Flutter tests.',
    'The acceptance provider is deterministic and local, but its outputs pass the same production closure-text, Director, and Board Builder schemas and semantic validators before commit.',
    'The portrait retry uses an archived deterministic fixture and makes no Seedream request; the separately authorized one-call Seedream evidence remains archived under its own test result.',
    'Live Ark behavior is evidenced separately by the accepted three-campaign V2 simulator gate: exactly 18 primary text calls and 3 allowed schema repairs, with no portrait calls.',
    'Owner-selected Ashen emblem B, Orsain B, Ysra C, Veyl C, and Cael A are promoted in these runtime screenshots; all non-selected candidates and prompts remain archived.',
  ],
  results,
  passed: results.every(({ passed }) => passed),
};
await fs.writeFile(
  path.resolve(root, runDir, 'browser', 'report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);
console.log(JSON.stringify(report, null, 2));
if (!report.passed) process.exitCode = 1;
