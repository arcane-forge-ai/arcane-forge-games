import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = process.argv[3] ?? 'http://127.0.0.1:8080';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_board_movement_regression.mjs ' +
      '<run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const viewports = [
  { width: 1600, height: 900 },
  { width: 1280, height: 720 },
];
const results = [];

const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');

for (const viewport of viewports) {
  const label = `${viewport.width}x${viewport.height}`;
  const artifactDir = path.resolve(root, runDir, 'browser', label);
  const videoDir = path.join(artifactDir, 'videos');
  await fs.mkdir(videoDir, { recursive: true });

  const browser = await chromium.launch({
    headless: true,
    executablePath: chromeExecutable,
  });
  const context = await browser.newContext({
    viewport,
    recordVideo: { dir: videoDir, size: viewport },
  });
  const page = await context.newPage();
  const consoleMessages = [];
  const pageErrors = [];
  const failedResponses = [];
  const captures = [];

  page.on('console', (message) => {
    consoleMessages.push({ type: message.type(), text: message.text() });
  });
  page.on('pageerror', (error) => pageErrors.push(error.message));
  page.on('response', (response) => {
    if (response.status() >= 400) {
      failedResponses.push({
        status: response.status(),
        url: response.url(),
      });
    }
  });
  await page.emulateMedia({ reducedMotion: 'no-preference' });

  const screenshot = async (name) => {
    const file = path.join(artifactDir, `${name}.png`);
    const bytes = await page.screenshot({ path: file });
    const capture = {
      name,
      file,
      bytes: bytes.length,
      sha256: sha256(bytes),
    };
    captures.push(capture);
    return capture;
  };

  const captureTimedState = async (state, prefix) => {
    await page.goto(`${baseUrl}/?state=${state}`, {
      waitUntil: 'domcontentloaded',
    });
    await page.waitForTimeout(2600);
    const before = await screenshot(`${prefix}-before`);
    await page.mouse.click(viewport.width - 102, 30);
    await page.waitForTimeout(190);
    const active = await screenshot(`${prefix}-active`);
    await page.waitForTimeout(560);
    const settled = await screenshot(`${prefix}-settled`);
    return {
      before,
      active,
      settled,
      framesDiffer:
        new Set([before.sha256, active.sha256, settled.sha256]).size === 3,
    };
  };

  const movement = await captureTimedState(
    'movementCapture',
    'capture-travel',
  );
  const betrayal = await captureTimedState(
    'betrayalTransform',
    'betrayal-transform',
  );
  const redeploy = await captureTimedState(
    'redeployTravel',
    'redeploy-travel',
  );

  await page.goto(
    `${baseUrl}/?state=movementCapture&reducedMotion=1`,
    { waitUntil: 'domcontentloaded' },
  );
  await page.waitForTimeout(2600);
  await page.mouse.click(viewport.width - 102, 30);
  await page.waitForTimeout(190);
  const reduced = await screenshot('reduced-motion-static-highlight');

  const video = page.video();
  await context.close();
  const videoPath = video ? await video.path() : null;
  await browser.close();

  const errors = consoleMessages.filter(({ type }) => type === 'error');
  const warnings = consoleMessages.filter(({ type }) => type === 'warning');
  const result = {
    viewport,
    movement,
    betrayal,
    redeploy,
    reduced,
    captures,
    consoleErrors: errors,
    consoleWarnings: warnings,
    pageErrors,
    failedResponses,
    videoPath,
    passed:
      movement.framesDiffer &&
      betrayal.framesDiffer &&
      redeploy.framesDiffer &&
      captures.every(({ bytes }) => bytes > 50_000) &&
      errors.length === 0 &&
      warnings.length === 0 &&
      pageErrors.length === 0 &&
      failedResponses.length === 0 &&
      videoPath !== null,
  };
  await fs.writeFile(
    path.join(artifactDir, 'result.json'),
    `${JSON.stringify(result, null, 2)}\n`,
  );
  results.push(result);
}

const report = {
  kind: 'web-board-movement-regression',
  baseUrl,
  results,
  passed: results.every(({ passed }) => passed),
};
await fs.mkdir(path.resolve(root, runDir, 'browser'), { recursive: true });
await fs.writeFile(
  path.resolve(root, runDir, 'browser', 'report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);

if (!report.passed) {
  process.exitCode = 1;
}
