import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = process.argv[3] ?? 'http://127.0.0.1:8080';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_ai_duel_regression.mjs <run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const requestedViewport = process.env.VIEWPORT;
const requireBothViewports =
  process.env.REQUIRE_BOTH_VIEWPORTS === undefined ||
  process.env.REQUIRE_BOTH_VIEWPORTS === '1';
const viewports = [
  { width: 1600, height: 900 },
  { width: 1280, height: 720 },
].filter(
  ({ width, height }) =>
    !requestedViewport || requestedViewport === `${width}x${height}`,
);
const results = [];

if (viewports.length === 0) {
  throw new Error(`Unsupported VIEWPORT value: ${requestedViewport}`);
}

const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');

const workerInstrumentation = () => {
  const OriginalWorker = window.Worker;
  const stats = {
    created: 0,
    terminated: 0,
    active: 0,
    maxActive: 0,
    commands: [],
    messages: [],
    urls: [],
  };
  window.__stockfishWorkerStats = stats;
  window.__longTasks = [];

  if ('PerformanceObserver' in window) {
    try {
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          window.__longTasks.push({
            name: entry.name,
            duration: entry.duration,
            startTime: entry.startTime,
          });
        }
      });
      observer.observe({ type: 'longtask', buffered: true });
    } catch (_) {
      // Long-task observation is optional browser telemetry.
    }
  }

  function InstrumentedWorker(url, options) {
    const worker = new OriginalWorker(url, options);
    let terminated = false;
    stats.created += 1;
    stats.active += 1;
    stats.maxActive = Math.max(stats.maxActive, stats.active);
    stats.urls.push(String(url));

    const originalPostMessage = worker.postMessage.bind(worker);
    worker.postMessage = (message, transfer) => {
      stats.commands.push(String(message));
      if (transfer === undefined) {
        return originalPostMessage(message);
      }
      return originalPostMessage(message, transfer);
    };

    const originalTerminate = worker.terminate.bind(worker);
    worker.terminate = () => {
      if (!terminated) {
        terminated = true;
        stats.terminated += 1;
        stats.active -= 1;
      }
      return originalTerminate();
    };
    worker.addEventListener('message', (event) => {
      stats.messages.push(String(event.data));
    });
    return worker;
  }

  InstrumentedWorker.prototype = OriginalWorker.prototype;
  Object.setPrototypeOf(InstrumentedWorker, OriginalWorker);
  window.Worker = InstrumentedWorker;
};

for (const viewport of viewports) {
  const label = `${viewport.width}x${viewport.height}`;
  const artifactDir = path.resolve(root, runDir, 'browser', label);
  const videoDir = path.join(artifactDir, 'videos');
  await fs.mkdir(videoDir, { recursive: true });

  const browser = await chromium.launch({
    headless: true,
    executablePath: chromeExecutable,
  });
  const context = await browser.newContext({
    viewport,
    recordVideo: { dir: videoDir, size: viewport },
  });
  await context.addInitScript(workerInstrumentation);
  const page = await context.newPage();
  const consoleMessages = [];
  const pageErrors = [];
  const failedResponses = [];
  const stockfishAssets = [];
  const captures = [];
  const offerAttempts = [];

  page.on('console', (message) => {
    consoleMessages.push({ type: message.type(), text: message.text() });
  });
  page.on('pageerror', (error) => pageErrors.push(error.message));
  page.on('response', async (response) => {
    const url = response.url();
    if (response.status() >= 400) {
      failedResponses.push({ status: response.status(), url });
    }
    if (
      url.includes('/stockfish/stockfish-18-lite-single.js') ||
      url.includes('/stockfish/stockfish-18-lite-single.wasm')
    ) {
      stockfishAssets.push({
        status: response.status(),
        url,
        contentType: (await response.allHeaders())['content-type'] ?? null,
      });
    }
  });
  await page.emulateMedia({ reducedMotion: 'no-preference' });

  const screenshot = async (name) => {
    const file = path.join(artifactDir, `${name}.png`);
    const bytes = await page.screenshot({ path: file });
    const capture = {
      name,
      file,
      bytes: bytes.length,
      sha256: sha256(bytes),
    };
    captures.push(capture);
    return capture;
  };

  const clickButton = async (name, options = {}) => {
    const button = page.getByRole('button', {
      name,
      exact: typeof name === 'string',
    });
    await button.first().waitFor({
      state: 'visible',
      timeout: options.timeout ?? 10_000,
    });
    await button.first().click();
  };

  const enableSemantics = async () => {
    await page.waitForFunction(
      () => document.querySelector('flt-semantics-placeholder') !== null,
      null,
      { timeout: 15_000 },
    );
    await page.evaluate(() => {
      document.querySelector('flt-semantics-placeholder')?.click();
    });
    await page.getByRole('button', { name: 'Press Start' }).waitFor({
      state: 'visible',
      timeout: 10_000,
    });
  };

  const tapSquare = async (square) => {
    await page.waitForFunction(
      (target) =>
        [...document.querySelectorAll('flt-semantics[role="button"]')].some(
          (node) => node.textContent?.trim() === target,
        ),
      square,
      { timeout: 10_000 },
    );
    const tapped = await page.evaluate((target) => {
      const node = [
        ...document.querySelectorAll('flt-semantics[role="button"]'),
      ].find((candidate) => candidate.textContent?.trim() === target);
      if (!(node instanceof HTMLElement)) {
        return false;
      }
      node.click();
      return true;
    }, square);
    if (!tapped) {
      throw new Error(`Could not tap board square ${square}.`);
    }
  };

  const workerStats = () =>
    page.evaluate(() => structuredClone(window.__stockfishWorkerStats));

  const bestMoves = async () => {
    const stats = await workerStats();
    return stats.messages
      .filter((message) => message.startsWith('bestmove '))
      .map((message) => message.split(/\s+/)[1]);
  };

  const waitForBestMoveCount = async (minimum) => {
    await page.waitForFunction(
      (count) =>
        window.__stockfishWorkerStats.messages.filter((message) =>
          message.startsWith('bestmove '),
        ).length >= count,
      minimum,
      { timeout: 12_000 },
    );
  };

  const waitForThinking = async () => {
    try {
      await page.waitForFunction(
        () => document.body.innerText.includes('Stockfish is thinking'),
        null,
        { timeout: 1_500 },
      );
      return true;
    } catch (_) {
      return false;
    }
  };

  const returnToLobby = async () => {
    await clickButton('Settings');
    await clickButton('Lobby');
    await page.getByRole('button', { name: 'Play', exact: true }).waitFor({
      state: 'visible',
      timeout: 10_000,
    });
    await page.waitForFunction(
      () => window.__stockfishWorkerStats.active === 0,
      null,
      { timeout: 5_000 },
    );
  };

  const enterAiMatch = async (attempt) => {
    await clickButton('Play');
    await clickButton('AI Duel with Stockfish');
    if (attempt === 1) {
      await screenshot('s03-web-ai-selected');
    }
    await clickButton('Confirm AI Duel');
    await page.getByText('Loading Stockfish…').waitFor({
      state: 'visible',
      timeout: 5_000,
    }).catch(() => {});
    await page.getByText('CREATE MATCH').waitFor({
      state: 'visible',
      timeout: 30_000,
    });
    if (attempt === 1) {
      await screenshot('s04-web-ai-settings');
    }
    await clickButton('Continue');
    await clickButton('Choose Courts');
    await clickButton(/^Black Court /);
    await clickButton('Mercantile League');
    await clickButton('Confirm');
    await clickButton('Enter Match', { timeout: 12_000 });
    await tapSquare('e2');
  };

  await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
  await enableSemantics();
  await screenshot('s01-title');
  await clickButton('Press Start');
  await page.getByRole('button', { name: 'Play', exact: true }).waitFor({
    state: 'visible',
    timeout: 10_000,
  });

  let accepted = false;
  let postRedeployBestMove = null;
  let thinkingObserved = false;
  let postRedeployThinkingObserved = false;
  let attemptsUsed = 0;

  for (let attempt = 1; attempt <= 6 && !accepted; attempt += 1) {
    attemptsUsed = attempt;
    await enterAiMatch(attempt);

    const beforeOpeningMoves = (await bestMoves()).length;
    await tapSquare('e4');
    const openingThinking = await waitForThinking();
    thinkingObserved ||= openingThinking;
    if (attempt === 1) {
      await screenshot('s20-stockfish-thinking');
    }
    await waitForBestMoveCount(beforeOpeningMoves + 1);
    await page.waitForFunction(
      () => !document.body.innerText.includes('Stockfish is thinking'),
      null,
      { timeout: 10_000 },
    );
    const openingBestMoves = await bestMoves();
    const openingMove = openingBestMoves.at(-1);
    if (!openingMove || openingMove === '(none)') {
      throw new Error(`Stockfish returned invalid opening move: ${openingMove}`);
    }

    const targetSquare = openingMove.slice(2, 4);
    await tapSquare(targetSquare);
    await clickButton('Offer Contract');
    for (let index = 0; index < 3; index += 1) {
      await clickButton('+');
    }
    if (attempt === 1) {
      await screenshot('s22-human-offer');
    }
    await clickButton('Submit Offer');
    await page.waitForFunction(
      () =>
        document.body.innerText.includes('CONTRACT ACCEPTED') ||
        document.body.innerText.includes('CONTRACT REJECTED') ||
        document.body.innerText.includes('HUMILIATED'),
      null,
      { timeout: 8_000 },
    );

    const bodyText = await page.locator('body').innerText();
    accepted = bodyText.includes('CONTRACT ACCEPTED');
    offerAttempts.push({
      attempt,
      openingMove,
      targetSquare,
      accepted,
    });

    if (!accepted) {
      await screenshot(`s25-offer-rejected-attempt-${attempt}`);
      await clickButton('Return to Board');
      await waitForBestMoveCount(beforeOpeningMoves + 2);
      await returnToLobby();
      continue;
    }

    await screenshot('s25-contract-accepted');
    await clickButton('Choose Placement');
    await page.waitForTimeout(700);
    await tapSquare('e2');
    await screenshot('s26-redeploy-selected');
    const redeploySemantics = await page.evaluate(() =>
      [...document.querySelectorAll('flt-semantics[role="button"]')]
        .map((node) => ({
          text: node.textContent?.trim() ?? '',
          ariaLabel: node.getAttribute('aria-label'),
          ariaDisabled: node.getAttribute('aria-disabled'),
        }))
        .filter(
          ({ text, ariaLabel }) =>
            text.includes('e2') ||
            text.includes('CONFIRM') ||
            ariaLabel?.includes('e2') ||
            ariaLabel?.includes('Confirm'),
        ),
    );
    await fs.writeFile(
      path.join(artifactDir, 'redeploy-semantics.json'),
      `${JSON.stringify(redeploySemantics, null, 2)}\n`,
    );
    const beforeRedeployMoves = (await bestMoves()).length;
    await clickButton(/^Confirm Placement/);
    postRedeployThinkingObserved = await waitForThinking();
    if (postRedeployThinkingObserved) {
      await screenshot('s26-post-redeploy-thinking');
    }
    await waitForBestMoveCount(beforeRedeployMoves + 1);
    await page.waitForFunction(
      () =>
        !document.body.innerText.includes('Stockfish is thinking') &&
        !document.body.innerText.includes('STOCKFISH PAUSED'),
      null,
      { timeout: 10_000 },
    );
    postRedeployBestMove = (await bestMoves()).at(-1);
    await screenshot('s20-post-redeploy-ai-response');
  }

  if (!accepted) {
    throw new Error('Contract was not accepted after six fresh AI matches.');
  }

  await returnToLobby();
  const afterAiWorkerStats = await workerStats();
  const workersBeforeLocal = afterAiWorkerStats.created;
  await clickButton('Play');
  await clickButton('Local Duel');
  await clickButton('Confirm Local Duel');
  await page.getByText('CREATE MATCH').waitFor({
    state: 'visible',
    timeout: 10_000,
  });
  await screenshot('s04-local-duel-regression');
  const afterLocalWorkerStats = await workerStats();

  const video = page.video();
  const finalBodyText = await page.locator('body').innerText();
  const longTasks = await page.evaluate(() =>
    structuredClone(window.__longTasks),
  );
  await context.close();
  const videoPath = video ? await video.path() : null;
  await browser.close();

  const errors = consoleMessages.filter(({ type }) => type === 'error');
  const warnings = consoleMessages.filter(({ type }) => type === 'warning');
  const assetKinds = new Set(
    stockfishAssets
      .filter(({ status }) => status === 200)
      .map(({ url }) => (url.endsWith('.wasm') ? 'wasm' : 'js')),
  );
  const wasmMimeCorrect = stockfishAssets.some(
    ({ url, status, contentType }) =>
      url.endsWith('.wasm') &&
      status === 200 &&
      contentType?.includes('application/wasm'),
  );
  const workerLifecycleComplete =
    afterAiWorkerStats.active === 0 &&
    afterAiWorkerStats.terminated === afterAiWorkerStats.created;
  const localDidNotCreateWorker =
    afterLocalWorkerStats.created === workersBeforeLocal;
  const result = {
    viewport,
    baseUrl,
    attemptsUsed,
    offerAttempts,
    accepted,
    thinkingObserved,
    postRedeployThinkingObserved,
    postRedeployBestMove,
    workerStats: afterLocalWorkerStats,
    workerLifecycleComplete,
    localDidNotCreateWorker,
    stockfishAssets,
    wasmMimeCorrect,
    longTasks,
    captures,
    consoleErrors: errors,
    consoleWarnings: warnings,
    pageErrors,
    failedResponses,
    videoPath,
    localSettingsVisible:
      finalBodyText.includes('CREATE MATCH') &&
      finalBodyText.includes('LOCAL DUEL'),
    passed:
      accepted &&
      postRedeployBestMove !== null &&
      postRedeployBestMove !== '(none)' &&
      afterLocalWorkerStats.maxActive === 1 &&
      workerLifecycleComplete &&
      localDidNotCreateWorker &&
      assetKinds.has('js') &&
      assetKinds.has('wasm') &&
      wasmMimeCorrect &&
      errors.length === 0 &&
      pageErrors.length === 0 &&
      failedResponses.length === 0 &&
      videoPath !== null &&
      captures.every(({ bytes }) => bytes > 50_000),
  };
  await fs.writeFile(
    path.join(artifactDir, 'result.json'),
    `${JSON.stringify(result, null, 2)}\n`,
  );
  results.push(result);
}

const combinedResults = [];
for (const viewport of [
  { width: 1600, height: 900 },
  { width: 1280, height: 720 },
]) {
  const resultPath = path.resolve(
    root,
    runDir,
    'browser',
    `${viewport.width}x${viewport.height}`,
    'result.json',
  );
  try {
    combinedResults.push(JSON.parse(await fs.readFile(resultPath, 'utf8')));
  } catch (_) {
    // A viewport can be intentionally omitted during a focused local rerun.
  }
}

const report = {
  kind: 'web-stockfish-ai-duel-regression',
  baseUrl,
  results: combinedResults,
  passed:
    (!requireBothViewports || combinedResults.length === 2) &&
    combinedResults.length > 0 &&
    combinedResults.every(({ passed }) => passed),
};
await fs.mkdir(path.resolve(root, runDir, 'browser'), { recursive: true });
await fs.writeFile(
  path.resolve(root, runDir, 'browser', 'report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);

if (!report.passed) {
  process.exitCode = 1;
}
