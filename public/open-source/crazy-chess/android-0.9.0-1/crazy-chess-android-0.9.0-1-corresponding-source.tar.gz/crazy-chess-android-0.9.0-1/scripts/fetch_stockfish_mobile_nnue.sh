#!/bin/sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REPOSITORY_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
DESTINATION_DIR="$REPOSITORY_DIR/third_party/stockfish/mobile_flutter/ios/Stockfish/src"
BASE_URL="https://tests.stockfishchess.org/api/nn"

checksum() {
  shasum -a 256 "$1" | awk '{print $1}'
}

fetch_network() {
  name=$1
  expected=$2
  destination="$DESTINATION_DIR/$name"

  if [ -f "$destination" ]; then
    if [ "$(checksum "$destination")" = "$expected" ]; then
      echo "$name is already installed and verified."
      return
    fi
    echo "Existing $name has the wrong checksum." >&2
    exit 1
  fi

  fetch_dir=$(mktemp -d "${TMPDIR:-/tmp}/crazy-chess-mobile-nnue.XXXXXX")
  trap 'rm -rf "$fetch_dir"' EXIT HUP INT TERM
  downloaded="$fetch_dir/$name"
  echo "Downloading $name..."
  curl -L --fail --show-error --silent \
    --retry 4 --retry-all-errors --retry-delay 2 \
    "$BASE_URL/$name" -o "$downloaded"
  if [ "$(checksum "$downloaded")" != "$expected" ]; then
    echo "Downloaded $name checksum does not match the pinned manifest." >&2
    exit 1
  fi
  install -m 644 "$downloaded" "$destination"
  rm -rf "$fetch_dir"
  trap - EXIT HUP INT TERM
  echo "Installed and verified $name."
}

mkdir -p "$DESTINATION_DIR"
fetch_network \
  "nn-c288c895ea92.nnue" \
  "c288c895ea924429ea9092e3f36b2b3c1f00f2a3a4c759ff7e57e79e3b43e4a7"
fetch_network \
  "nn-37f18f62d772.nnue" \
  "37f18f62d772f3107e1d6aaca3898c130c3c86f2ab63e6555fbbca20635a899d"
