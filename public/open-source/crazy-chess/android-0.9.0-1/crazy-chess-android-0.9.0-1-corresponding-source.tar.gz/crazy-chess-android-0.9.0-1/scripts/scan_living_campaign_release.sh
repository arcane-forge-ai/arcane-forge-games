#!/bin/zsh

set -u

workspace_root=${1:-.}
cd "$workspace_root"

if [[ ! -f .env ]]; then
  print 'FAIL: repository .env is missing; exact-key release scan was not run.'
  exit 1
fi

set -a
source .env
set +a

if [[ -z ${ARK_API_KEY:-} ]]; then
  print 'FAIL: ARK_API_KEY is empty; exact-key release scan was not run.'
  exit 1
fi

artifacts=(
  build/web
  build/macos/Build/Products/Release/crazy_chess.app
)

for artifact in $artifacts; do
  if [[ ! -e $artifact ]]; then
    print "FAIL: release artifact is missing: $artifact"
    exit 1
  fi
done

if rg -a -l -F -- "$ARK_API_KEY" $artifacts >/dev/null; then
  print 'FAIL: the configured ARK_API_KEY appears in a release artifact.'
  exit 1
fi

if find $artifacts -name .env -print -quit | grep -q .; then
  print 'FAIL: a .env file appears in a release artifact.'
  exit 1
fi

for acceptance_marker in 'QA: Resolve Chapter' 'living-demo-request'; do
  if rg -a -l -F -- "$acceptance_marker" $artifacts >/dev/null; then
    print "FAIL: acceptance-only marker appears in release artifacts: $acceptance_marker"
    exit 1
  fi
done

print 'PASS: normal release artifacts contain no configured key, .env file, or acceptance-only marker.'
