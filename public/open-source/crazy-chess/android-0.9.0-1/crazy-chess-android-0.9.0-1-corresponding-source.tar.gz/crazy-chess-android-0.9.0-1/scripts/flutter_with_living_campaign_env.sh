#!/bin/sh
set -eu

workspace_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
env_file="$workspace_dir/.env"

set -- "$@"
for arg in "$@"; do
  case "$arg" in
    --release|--profile)
      exec flutter "$@"
      ;;
  esac
done

if [ ! -f "$env_file" ]; then
  exec flutter "$@"
fi

defines=""
while IFS= read -r line || [ -n "$line" ]; do
  case "$line" in
    ''|'#'*) continue ;;
  esac
  key=${line%%=*}
  value=${line#*=}
  case "$key" in
    ARK_API_KEY|ARK_BASE_URL|LIVING_CAMPAIGN_TEXT_MODEL|LIVING_CAMPAIGN_IMAGE_MODEL)
      defines="$defines --dart-define=$key=$value"
      ;;
  esac
done < "$env_file"

# Values intentionally stay in process arguments only for debug/profile-free
# developer launches. Do not use this wrapper for release artifacts.
# shellcheck disable=SC2086
exec flutter "$@" $defines
