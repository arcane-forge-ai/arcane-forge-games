#!/bin/sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REPOSITORY_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
DESTINATION="$REPOSITORY_DIR/third_party/stockfish/macos-arm64/stockfish"
ARCHIVE_URL="https://github.com/official-stockfish/Stockfish/releases/download/sf_18/stockfish-macos-m1-apple-silicon.tar"
ARCHIVE_SHA256="4d77c4aa3ad9bd1ea8111f2ac5a4620fe7ebf998d6893bf828d49ccd579c8cb0"
EXECUTABLE_SHA256="bc0cac905ecdf2147fe22055c733bcd999b1e3f7c399fbaf7fb9055786563590"

checksum() {
  shasum -a 256 "$1" | awk '{print $1}'
}

if [ -f "$DESTINATION" ]; then
  if [ "$(checksum "$DESTINATION")" = "$EXECUTABLE_SHA256" ]; then
    echo "Stockfish 18 is already installed and verified."
    exit 0
  fi
  echo "Existing Stockfish executable has the wrong checksum." >&2
  exit 1
fi

FETCH_DIR=$(mktemp -d "${TMPDIR:-/tmp}/crazy-chess-stockfish.XXXXXX")
trap 'rm -rf "$FETCH_DIR"' EXIT HUP INT TERM
ARCHIVE="$FETCH_DIR/stockfish.tar"
EXTRACTED="$FETCH_DIR/extracted"
MATCH_FILE="$FETCH_DIR/match"

mkdir -p "$EXTRACTED"
echo "Downloading the pinned official Stockfish 18 release..."
curl -L --fail --show-error --silent \
  --retry 4 --retry-all-errors --retry-delay 2 --continue-at - \
  "$ARCHIVE_URL" -o "$ARCHIVE"

if [ "$(checksum "$ARCHIVE")" != "$ARCHIVE_SHA256" ]; then
  echo "Downloaded archive checksum does not match third_party/stockfish/manifest.json." >&2
  exit 1
fi

tar -xf "$ARCHIVE" -C "$EXTRACTED"
find "$EXTRACTED" -type f -print | while IFS= read -r candidate; do
  if [ "$(checksum "$candidate")" = "$EXECUTABLE_SHA256" ]; then
    printf '%s\n' "$candidate" > "$MATCH_FILE"
    break
  fi
done

if [ ! -s "$MATCH_FILE" ]; then
  echo "The verified Stockfish executable was not found in the release archive." >&2
  exit 1
fi

mkdir -p "$(dirname -- "$DESTINATION")"
install -m 755 "$(sed -n '1p' "$MATCH_FILE")" "$DESTINATION"

if [ "$(checksum "$DESTINATION")" != "$EXECUTABLE_SHA256" ]; then
  echo "Installed executable checksum verification failed." >&2
  exit 1
fi

echo "Installed and verified Stockfish 18 at $DESTINATION"
