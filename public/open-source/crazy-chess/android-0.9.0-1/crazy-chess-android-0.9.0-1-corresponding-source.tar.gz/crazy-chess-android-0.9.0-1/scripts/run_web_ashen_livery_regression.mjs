import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = process.argv[3] ?? 'http://127.0.0.1:8097';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_ashen_livery_regression.mjs <run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const viewport = { width: 1440, height: 900 };
const artifactDir = path.resolve(root, runDir, 'browser', '1440x900', 'ashen-liveries');
const videoDir = path.join(artifactDir, 'videos');
await fs.mkdir(videoDir, { recursive: true });

const browser = await chromium.launch({
  headless: true,
  executablePath:
    process.env.CHROME_EXECUTABLE ??
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
});
const context = await browser.newContext({
  viewport,
  recordVideo: { dir: videoDir, size: viewport },
});
await context.tracing.start({ screenshots: true, snapshots: true, sources: true });
const page = await context.newPage();
const consoleMessages = [];
const pageErrors = [];
const failedResponses = [];
page.on('console', (message) =>
  consoleMessages.push({ type: message.type(), text: message.text() }),
);
page.on('pageerror', (error) => pageErrors.push(error.stack ?? error.message));
page.on('response', (response) => {
  if (response.status() >= 400) {
    failedResponses.push({ status: response.status(), url: response.url() });
  }
});

const sha256 = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const shots = [];
const screenshot = async (name) => {
  const file = path.join(artifactDir, `${name}.png`);
  const bytes = await page.screenshot({ path: file });
  shots.push({
    name,
    file: path.relative(path.resolve(root, runDir), file),
    bytes: bytes.length,
    sha256: sha256(bytes),
  });
};
const button = (name) => page.getByRole('button', { name, exact: true }).first();
const clickButton = async (name, waitMs = 600) => {
  const target = button(name);
  await target.waitFor({ state: 'visible', timeout: 15_000 });
  await target.click();
  await page.waitForTimeout(waitMs);
};

await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(3000);
await page.waitForSelector('flt-semantics-placeholder', {
  state: 'attached',
  timeout: 15_000,
});
await page.evaluate(() => document.querySelector('flt-semantics-placeholder')?.click());
await clickButton('Press Start', 750);
await clickButton('Play', 750);
await clickButton('Living Campaign', 250);
await clickButton('Confirm Living Campaign', 900);
await button('Begin New Living Campaign').waitFor({ state: 'visible', timeout: 12_000 });
await clickButton('Begin New Living Campaign', 900);
await clickButton('Continue Story', 750);
await clickButton('Begin Chapter 1', 750);
await clickButton('Skip to Briefing', 650);
await clickButton('Enter Battle', 2200);
await screenshot('01-ashen-opening-board');

const expectedAssets = [];
for (const side of ['white', 'black']) {
  for (const role of ['pawn', 'knight', 'bishop', 'rook', 'queen', 'king']) {
    expectedAssets.push(`/ashen_liveries/${side}/ashen_${role}_token.webp`);
  }
}
const expectedBoardAssets = expectedAssets.filter(
  (asset) => !asset.includes('_queen_token.webp'),
);
const resourceUrls = await page.evaluate(() =>
  performance.getEntriesByType('resource').map((entry) => entry.name),
);
const missingAssets = expectedAssets.filter(
  (asset) => !resourceUrls.some((url) => url.includes(asset)),
);
const missingBoardAssets = expectedBoardAssets.filter(
  (asset) => !resourceUrls.some((url) => url.includes(asset)),
);

const medallionCounts = {
  whitePawn: await page.getByLabel('White pawn role medallion', { exact: true }).count(),
  blackPawn: await page.getByLabel('Black pawn role medallion', { exact: true }).count(),
  whiteKing: await page.getByLabel('White king role medallion', { exact: true }).count(),
  blackKing: await page.getByLabel('Black king role medallion', { exact: true }).count(),
};

// Natural move on the fixed 1440x900 Ruined Causeway board: a2 to a3.
await page.waitForTimeout(2200);
const moveClip = { x: 270, y: 555, width: 80, height: 160 };
const moveRegionBeforeSha256 = sha256(await page.screenshot({ clip: moveClip }));
await page.mouse.click(308, 684);
await page.waitForTimeout(600);
await screenshot('02-ashen-white-pawn-selected');
await page.mouse.click(308, 604);
await page.waitForTimeout(1600);
const moveRegionAfterSha256 = sha256(await page.screenshot({ clip: moveClip }));
const moveRegionChanged = moveRegionBeforeSha256 !== moveRegionAfterSha256;
await screenshot('03-ashen-after-white-pawn-a2-a3');

const tracePath = path.join(artifactDir, 'trace.zip');
const video = page.video();
await context.tracing.stop({ path: tracePath });
await context.close();
const videoPath = video ? await video.path() : null;
await browser.close();

const consoleErrors = consoleMessages.filter(({ type }) => type === 'error');
const unexpectedWarnings = consoleMessages.filter(
  ({ type, text }) =>
    type === 'warning' && !text.includes('The AudioContext was not allowed to start'),
);
const result = {
  kind: 'ashen-side-livery-regression',
  viewport,
  baseUrl,
  fixture: 'fixed Living Campaign M01; natural entry and natural a2-a3 move',
  expectedAssets,
  expectedBoardAssets,
  missingAssets,
  missingBoardAssets,
  fixedM01Omissions: expectedAssets.filter(
    (asset) => asset.includes('_queen_token.webp'),
  ),
  medallionCounts,
  medallionAutomationNote:
    'Flutter web compacts these noninteractive child semantics; universal side medallions are asserted in the all-country/all-role widget regression and reviewed in screenshots.',
  moveRegionBeforeSha256,
  moveRegionAfterSha256,
  moveRegionChanged,
  shots,
  consoleErrors,
  unexpectedWarnings,
  pageErrors,
  failedResponses,
  tracePath: path.relative(path.resolve(root, runDir), tracePath),
  videoPath: videoPath
    ? path.relative(path.resolve(root, runDir), videoPath)
    : null,
};
result.passed =
  missingBoardAssets.length === 0 &&
  moveRegionChanged &&
  shots.length === 3 &&
  shots.every(({ bytes }) => bytes > 50_000) &&
  new Set(shots.map(({ sha256: hash }) => hash)).size === shots.length &&
  consoleErrors.length === 0 &&
  unexpectedWarnings.length === 0 &&
  pageErrors.length === 0 &&
  failedResponses.length === 0 &&
  result.videoPath !== null;

await fs.writeFile(
  path.join(artifactDir, 'console.json'),
  `${JSON.stringify(consoleMessages, null, 2)}\n`,
);
await fs.writeFile(
  path.join(artifactDir, 'result.json'),
  `${JSON.stringify(result, null, 2)}\n`,
);
console.log(JSON.stringify(result, null, 2));
if (!result.passed) process.exitCode = 1;
