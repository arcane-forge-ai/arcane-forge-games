#!/usr/bin/env python3
"""Prepare alpha-safe S20 plate, crest, and caravan candidates."""

from __future__ import annotations

import argparse
from collections import deque
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


MAGENTA = (255, 0, 255)
BACKGROUNDS = ((14, 22, 27, 255), (231, 219, 191, 255), (55, 93, 84, 255))


def _distance(pixel: tuple[int, int, int]) -> int:
    return max(abs(pixel[index] - MAGENTA[index]) for index in range(3))


def extract_magenta(source: Image.Image) -> Image.Image:
    rgb = source.convert("RGB")
    width, height = rgb.size
    pixels = rgb.load()
    outside = bytearray(width * height)
    queue: deque[tuple[int, int]] = deque()

    def enqueue(x: int, y: int) -> None:
        index = y * width + x
        if outside[index] or _distance(pixels[x, y]) > 72:
            return
        outside[index] = 1
        queue.append((x, y))

    for x in range(width):
        enqueue(x, 0)
        enqueue(x, height - 1)
    for y in range(height):
        enqueue(0, y)
        enqueue(width - 1, y)

    while queue:
        x, y = queue.popleft()
        if x:
            enqueue(x - 1, y)
        if x + 1 < width:
            enqueue(x + 1, y)
        if y:
            enqueue(x, y - 1)
        if y + 1 < height:
            enqueue(x, y + 1)

    output = Image.new("RGBA", rgb.size)
    target = output.load()
    for y in range(height):
        for x in range(width):
            index = y * width + x
            color = pixels[x, y]
            if outside[index]:
                target[x, y] = (0, 0, 0, 0)
                continue
            distance = _distance(color)
            target[x, y] = (*color, 255 if distance >= 56 else round(255 * distance / 56))
    return output


def fit_trimmed(image: Image.Image, size: tuple[int, int], padding: int) -> Image.Image:
    bounds = image.getchannel("A").getbbox()
    if bounds is None:
        raise ValueError("Candidate contains no foreground")
    trimmed = image.crop(bounds)
    available = (size[0] - padding * 2, size[1] - padding * 2)
    trimmed.thumbnail(available, Image.Resampling.LANCZOS)
    output = Image.new("RGBA", size)
    output.alpha_composite(
        trimmed,
        ((size[0] - trimmed.width) // 2, (size[1] - trimmed.height) // 2),
    )
    return output


def contact_sheet(
    label: str,
    candidates: list[tuple[str, Image.Image]],
    output: Path,
    preview_size: tuple[int, int],
) -> None:
    font = ImageFont.load_default()
    cell_width = 520
    cell_height = 200
    sheet = Image.new(
        "RGB",
        (cell_width * len(candidates), 24 + cell_height * len(BACKGROUNDS)),
        (8, 12, 15),
    )
    draw = ImageDraw.Draw(sheet)
    for column, (candidate_name, image) in enumerate(candidates):
        x = column * cell_width
        draw.text((x + 8, 7), f"{label.upper()} · {candidate_name.upper()}", fill=(232, 197, 112), font=font)
        for row, background in enumerate(BACKGROUNDS):
            tile = Image.new("RGBA", (cell_width, cell_height), background)
            preview = image.copy()
            preview.thumbnail(preview_size, Image.Resampling.LANCZOS)
            tile.alpha_composite(
                preview,
                ((cell_width - preview.width) // 2, (cell_height - preview.height) // 2),
            )
            sheet.paste(tile.convert("RGB"), (x, 24 + cell_height * row))
    output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate-dir", type=Path, required=True)
    parser.add_argument("--evidence-dir", type=Path, required=True)
    parser.add_argument("--kind", choices=("court_plate", "crest", "caravan"), required=True)
    args = parser.parse_args()

    sources = sorted(args.candidate_dir.glob(f"*_{args.kind}_[abc].png"))
    if args.kind == "caravan":
        sources = sorted(args.candidate_dir.glob("caravan_[abc].png"))
    if not sources:
        raise SystemExit("No candidates matched")

    prepared_dir = args.evidence_dir / "prepared"
    contact_dir = args.evidence_dir / "contact"
    prepared_dir.mkdir(parents=True, exist_ok=True)
    grouped: dict[str, list[tuple[str, Image.Image]]] = {}
    output_size = {
        "court_plate": (1400, 180),
        "crest": (512, 512),
        "caravan": (224, 512),
    }[args.kind]
    padding = 12 if args.kind == "court_plate" else 28

    for source in sources:
        group, candidate = source.stem.rsplit("_", 1)
        prepared = fit_trimmed(extract_magenta(Image.open(source)), output_size, padding)
        prepared.save(prepared_dir / source.name)
        grouped.setdefault(group, []).append((candidate, prepared))

    preview_size = (500, 90) if args.kind == "court_plate" else (150, 150)
    for group, candidates in grouped.items():
        contact_sheet(
            group,
            sorted(candidates),
            contact_dir / f"{group}_contact.png",
            preview_size,
        )


if __name__ == "__main__":
    main()
