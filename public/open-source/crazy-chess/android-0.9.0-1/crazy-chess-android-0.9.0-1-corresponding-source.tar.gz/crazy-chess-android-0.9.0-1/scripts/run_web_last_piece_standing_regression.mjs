import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const naturalUrl = process.argv[3] ?? 'http://127.0.0.1:8080';
const assistedUrl = process.argv[4] ?? 'http://127.0.0.1:8081';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_last_piece_standing_regression.mjs ' +
      '<run-dir> [natural-url] [assisted-url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const viewportFilter = process.env.VIEWPORT_FILTER;
const flowFilter = process.env.FLOW_FILTER;
const assistedStateFilter = process.env.ASSISTED_STATE_FILTER;
const viewports = [
  { width: 1600, height: 900 },
  { width: 1280, height: 720 },
].filter(
  ({ width, height }) =>
    !viewportFilter || viewportFilter === `${width}x${height}`,
);
const results = [];

const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');

const captureSession = async ({ viewport, label, baseUrl, drive }) => {
  const artifactDir = path.resolve(
    root,
    runDir,
    'browser',
    `${viewport.width}x${viewport.height}`,
    label,
  );
  const videoDir = path.join(artifactDir, 'videos');
  await fs.mkdir(videoDir, { recursive: true });
  const browser = await chromium.launch({
    headless: true,
    executablePath: chromeExecutable,
  });
  const context = await browser.newContext({
    viewport,
    recordVideo: { dir: videoDir, size: viewport },
  });
  const page = await context.newPage();
  const consoleMessages = [];
  const pageErrors = [];
  const failedResponses = [];
  page.on('console', (message) => {
    consoleMessages.push({ type: message.type(), text: message.text() });
  });
  page.on('pageerror', (error) => pageErrors.push(error.message));
  page.on('response', (response) => {
    if (response.status() >= 400) {
      failedResponses.push({
        status: response.status(),
        url: response.url(),
      });
    }
  });
  await page.emulateMedia({ reducedMotion: 'no-preference' });

  const shots = [];
  const screenshot = async (name) => {
    const file = path.join(artifactDir, `${name}.png`);
    let bytes;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      bytes = await page.screenshot({ path: file });
      if (bytes.length > 50_000) {
        break;
      }
      await page.waitForTimeout(1000);
    }
    shots.push({
      name,
      file: path.relative(path.resolve(root, runDir), file),
      bytes: bytes.length,
      sha256: sha256(bytes),
    });
  };

  await drive({ page, screenshot, baseUrl, viewport });

  const video = page.video();
  await context.close();
  const absoluteVideoPath = video ? await video.path() : null;
  await browser.close();

  const errors = consoleMessages.filter(({ type }) => type === 'error');
  const warnings = consoleMessages.filter(({ type }) => type === 'warning');
  const allowedWarnings = warnings.filter(({ text }) =>
    text.includes('The AudioContext was not allowed to start.'),
  );
  const unexpectedWarnings = warnings.filter(
    (warning) => !allowedWarnings.includes(warning),
  );
  const videoPath = absoluteVideoPath
    ? path.relative(path.resolve(root, runDir), absoluteVideoPath)
    : null;
  const result = {
    viewport,
    label,
    shots,
    consoleErrors: errors,
    consoleWarnings: warnings,
    allowedWarnings,
    unexpectedWarnings,
    pageErrors,
    failedResponses,
    videoPath,
    passed:
      shots.length > 0 &&
      shots.every(({ bytes }) => bytes > 50_000) &&
      errors.length === 0 &&
      unexpectedWarnings.length === 0 &&
      pageErrors.length === 0 &&
      failedResponses.length === 0 &&
      videoPath !== null,
  };
  await fs.writeFile(
    path.join(artifactDir, 'result.json'),
    `${JSON.stringify(result, null, 2)}\n`,
  );
  return result;
};

for (const viewport of viewports) {
  const scaleX = viewport.width / 1600;
  const scaleY = viewport.height / 900;
  if (!flowFilter || flowFilter === 'natural') {
    results.push(
      await captureSession({
      viewport,
      label: 'natural',
      baseUrl: naturalUrl,
      drive: async ({ page, screenshot, baseUrl }) => {
        const clickStage = async (x, y, waitMs = 900) => {
          await page.mouse.click(x * scaleX, y * scaleY);
          await page.waitForTimeout(waitMs);
        };
        await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(3600);
        await clickStage(280, 670);
        await clickStage(1190, 205);
        await clickStage(580, 650);
        await screenshot('mode-entry');
        await clickStage(1400, 844);
        await screenshot('country-select');
        await clickStage(1400, 830);
        await screenshot('locked-level-ladder');
        await clickStage(1400, 830, 1800);
        await screenshot('run-opening');
        await clickStage(1410, 52, 1400);
        await screenshot('retirement-results');
      },
      }),
    );
  }

  if (!flowFilter || flowFilter === 'assisted') {
    results.push(
      await captureSession({
      viewport,
      label: 'assisted',
      baseUrl: assistedUrl,
      drive: async ({ page, screenshot, baseUrl }) => {
        const assistedStates = [
          'captureVisual',
          'captureInput',
          'playerTravel',
          'spawnMotion',
          'spawnTier1',
          'spawnTier2',
          'spawnTier3',
          'spawnTier4',
          'kingStart',
          'huntMotion',
          'captureMotion',
          'downgradeMid',
          'firstSpawn',
          'hunt',
          'scoreTile',
          'downgrade',
          'pass',
          'dense',
          'defeat',
          'passResults',
          'chronicle',
          'gallery',
        ].filter(
          (state) => !assistedStateFilter || state === assistedStateFilter,
        );
        for (const state of assistedStates) {
          await page.goto(`${baseUrl}/?state=${state}`, {
            waitUntil: 'domcontentloaded',
          });
          await page.waitForTimeout(3000);
          await screenshot(state);
          if (state === 'captureVisual') {
            await page.waitForTimeout(2300);
            await screenshot('captureVisualAfter');
          }
          if (state === 'captureInput') {
            await page.mouse.move(547 * scaleX, 441 * scaleY);
            await page.mouse.click(547 * scaleX, 441 * scaleY);
            await page.waitForTimeout(80);
            await page.mouse.click(547 * scaleX, 441 * scaleY);
            await page.waitForTimeout(120);
            await screenshot('captureInputTravel');
            await page.waitForTimeout(700);
            await screenshot('captureInputAfter');
          }
          if (state === 'gallery') {
            await page.mouse.click(1450 * scaleX, 730 * scaleY);
            await page.waitForTimeout(500);
            await screenshot('galleryStatus');
          }
        }
      },
      }),
    );
  }
}

const requiredAssistedStates = [
  'spawnTier1',
  'spawnTier2',
  'spawnTier3',
  'spawnTier4',
  'kingStart',
];
const assistedResult = results.find(({ label }) => label === 'assisted');
const assistedCoverage = requiredAssistedStates.every((state) =>
  assistedResult?.shots.some(({ name }) => name === state),
);
const tierHashes = assistedResult?.shots
  .filter(({ name }) => name.startsWith('spawnTier'))
  .map(({ sha256: hash }) => hash) ?? [];
const distinctSpawnTiers =
  tierHashes.length === 4 && new Set(tierHashes).size === tierHashes.length;
const report = {
  kind: 'web-last-piece-standing-regression',
  naturalUrl,
  assistedUrl,
  requiredCheckpoints: [
    'mode entry',
    'locked ladder',
    'first spawn',
    '1/2/3/4 score-scaled spawn batches',
    'level 003 natural King initialization through assisted access',
    'hunt',
    'player capture',
    'score tile',
    'downgrade transformation',
    'pass milestone without stopping',
    'dense no-cap state',
    'defeat',
    'next-level unlock',
    'Familiarity gain',
    'chronicle unlock',
    'gallery unlock',
  ],
  assistedCoverage,
  distinctSpawnTiers,
  results,
  passed:
    results.every(({ passed }) => passed) &&
    assistedCoverage &&
    distinctSpawnTiers,
};
const browserDir = path.resolve(root, runDir, 'browser');
await fs.mkdir(browserDir, { recursive: true });
await fs.writeFile(
  path.join(browserDir, 'report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);

const cards = results
  .flatMap((result) =>
    result.shots.map(
      (shot) => `
        <article>
          <img src="${shot.file.replace(/^browser\//, '')}" alt="${shot.name}">
          <h3>${shot.name}</h3>
          <p>${result.viewport.width}×${result.viewport.height} · ${result.label}</p>
        </article>`,
    ),
  )
  .join('');
const sessionRows = results
  .map(
    (result) => `
      <tr>
        <td>${result.viewport.width}×${result.viewport.height}</td>
        <td>${result.label}</td>
        <td>${result.shots.length}</td>
        <td>${result.videoPath ?? 'missing'}</td>
        <td>${result.consoleErrors.length}/${result.unexpectedWarnings.length}/${result.pageErrors.length}/${result.failedResponses.length}</td>
        <td>${result.passed ? 'PASS' : 'FAIL'}</td>
      </tr>`,
  )
  .join('');
await fs.writeFile(
  path.join(browserDir, 'report.html'),
  `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Last Piece Standing Browser Review</title>
<style>
:root{color-scheme:dark;--bg:#070908;--panel:#131813;--ink:#eee9dd;--gold:#e1ba68;--jade:#77d7a6;--line:#3f4b42}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 15% 3%,#17392b 0,transparent 28%),var(--bg);color:var(--ink);font:15px/1.5 Inter,system-ui,sans-serif}main{width:min(1500px,calc(100% - 28px));margin:28px auto 60px}header,section{background:#101510;border:1px solid var(--line);padding:24px;margin-bottom:16px}h1,h2,h3{font-family:Georgia,serif}h1{color:#f2d58a;font-size:42px;margin:0 0 8px}.pass{color:var(--jade);font-weight:900}table{width:100%;border-collapse:collapse}th,td{border:1px solid var(--line);padding:8px;text-align:left}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}article{background:var(--panel);border:1px solid var(--line);padding:10px}img{display:block;width:100%;height:auto}article h3{margin:9px 0 0;color:var(--gold)}article p{margin:3px 0;color:#b7b8ad}@media(max-width:800px){.grid{grid-template-columns:1fr}}
</style></head><body><main>
<header><h1>Last Piece Standing Browser Review</h1><p class="${report.passed ? 'pass' : ''}">${report.passed ? 'PASS' : 'FAIL'} · natural and seeded-assisted evidence at both target viewports.</p></header>
<section><h2>Sessions</h2><table><tr><th>Viewport</th><th>Flow</th><th>Shots</th><th>Video</th><th>Errors/Unexpected Warn/Page/HTTP</th><th>Result</th></tr>${sessionRows}</table></section>
<section><h2>Required checkpoints</h2><p>${report.requiredCheckpoints.join(' · ')}</p></section>
<section><h2>Screenshots</h2><div class="grid">${cards}</div></section>
</main></body></html>`,
);

if (!report.passed) {
  process.exitCode = 1;
}
