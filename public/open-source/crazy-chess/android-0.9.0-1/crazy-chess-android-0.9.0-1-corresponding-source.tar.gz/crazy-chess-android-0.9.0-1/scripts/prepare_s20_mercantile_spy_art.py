#!/usr/bin/env python3
"""Prepare S20 Mercantile/Spy image candidates and review sheets."""

from __future__ import annotations

import argparse
from collections import deque
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


MAGENTA = (255, 0, 255)
REVIEW_BACKGROUNDS = (
    (18, 27, 32, 255),
    (231, 219, 191, 255),
    (55, 93, 84, 255),
)


def _color_distance(pixel: tuple[int, int, int]) -> int:
    return max(
        abs(pixel[0] - MAGENTA[0]),
        abs(pixel[1] - MAGENTA[1]),
        abs(pixel[2] - MAGENTA[2]),
    )


def extract_magenta(source: Image.Image) -> Image.Image:
    rgb = source.convert("RGB")
    width, height = rgb.size
    pixels = rgb.load()
    background = bytearray(width * height)
    queue: deque[tuple[int, int]] = deque()

    def enqueue(x: int, y: int) -> None:
        index = y * width + x
        if background[index] or _color_distance(pixels[x, y]) > 72:
            return
        background[index] = 1
        queue.append((x, y))

    for x in range(width):
        enqueue(x, 0)
        enqueue(x, height - 1)
    for y in range(height):
        enqueue(0, y)
        enqueue(width - 1, y)

    while queue:
        x, y = queue.popleft()
        if x:
            enqueue(x - 1, y)
        if x + 1 < width:
            enqueue(x + 1, y)
        if y:
            enqueue(x, y - 1)
        if y + 1 < height:
            enqueue(x, y + 1)

    rgba = Image.new("RGBA", rgb.size)
    output = rgba.load()
    for y in range(height):
        for x in range(width):
            index = y * width + x
            color = pixels[x, y]
            if background[index]:
                output[x, y] = (0, 0, 0, 0)
                continue
            distance = _color_distance(color)
            alpha = 255 if distance >= 56 else round(255 * distance / 56)
            output[x, y] = (*color, alpha)
    return rgba


def alpha_trim_square(image: Image.Image, size: int) -> Image.Image:
    alpha = image.getchannel("A")
    bounds = alpha.getbbox()
    if bounds is None:
        raise ValueError("Candidate contains no foreground after alpha extraction")
    trimmed = image.crop(bounds)
    padding = max(16, round(max(trimmed.size) * 0.07))
    side = max(trimmed.size) + padding * 2
    square = Image.new("RGBA", (side, side))
    square.alpha_composite(
        trimmed,
        ((side - trimmed.width) // 2, (side - trimmed.height) // 2),
    )
    square.thumbnail((size, size), Image.Resampling.LANCZOS)
    output = Image.new("RGBA", (size, size))
    output.alpha_composite(
        square,
        ((size - square.width) // 2, (size - square.height) // 2),
    )
    return output


def composite(image: Image.Image, size: int, background: tuple[int, int, int, int]) -> Image.Image:
    resized = image.resize((size, size), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (size, size), background)
    canvas.alpha_composite(resized)
    return canvas.convert("RGB")


def make_contact_sheet(
    role: str,
    candidates: list[tuple[str, Image.Image]],
    output_path: Path,
) -> None:
    font = ImageFont.load_default()
    cell = 240
    label_height = 28
    rows = 1 + len(REVIEW_BACKGROUNDS)
    sheet = Image.new(
        "RGB",
        (cell * len(candidates), label_height + cell * rows),
        (9, 13, 16),
    )
    draw = ImageDraw.Draw(sheet)
    for column, (label, candidate) in enumerate(candidates):
        x = column * cell
        draw.text(
            (x + 10, 8),
            f"{role.upper()} · {label.upper()}",
            fill=(231, 196, 115),
            font=font,
        )
        source_review = composite(candidate, cell, (255, 0, 255, 255))
        sheet.paste(source_review, (x, label_height))
        for row, background in enumerate(REVIEW_BACKGROUNDS, start=1):
            board_tile = Image.new("RGBA", (cell, cell), background)
            for size, offset in ((92, 12), (74, 112), (64, 170)):
                preview = candidate.resize((size, size), Image.Resampling.LANCZOS)
                board_tile.alpha_composite(preview, (offset, (cell - size) // 2))
            sheet.paste(board_tile.convert("RGB"), (x, label_height + cell * row))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path)


def prepare(candidate_dir: Path, evidence_dir: Path, kind: str) -> None:
    pattern = f"*_{kind}_[abc].png"
    sources = sorted(candidate_dir.glob(pattern))
    if not sources:
        raise SystemExit(f"No files matched {candidate_dir / pattern}")

    prepared_dir = evidence_dir / "prepared"
    contact_dir = evidence_dir / "contact"
    prepared_dir.mkdir(parents=True, exist_ok=True)
    contact_dir.mkdir(parents=True, exist_ok=True)

    grouped: dict[str, list[tuple[str, Image.Image]]] = {}
    for source in sources:
        stem = source.stem
        role, candidate = stem.rsplit("_", 1)
        extracted = extract_magenta(Image.open(source))
        prepared = alpha_trim_square(extracted, 512 if kind == "token" else 1024)
        prepared.save(prepared_dir / f"{stem}.png")
        grouped.setdefault(role, []).append((candidate, prepared))

    for role, candidates in grouped.items():
        make_contact_sheet(
            role,
            sorted(candidates),
            contact_dir / f"{role}_contact.png",
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate-dir", type=Path, required=True)
    parser.add_argument("--evidence-dir", type=Path, required=True)
    parser.add_argument("--kind", choices=("token", "portrait"), required=True)
    args = parser.parse_args()
    prepare(args.candidate_dir, args.evidence_dir, args.kind)


if __name__ == "__main__":
    main()
