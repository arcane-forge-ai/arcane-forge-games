import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = process.argv[3] ?? 'http://127.0.0.1:8080';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_stockfish_quality.mjs <run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const browser = await chromium.launch({
  headless: true,
  executablePath:
    process.env.CHROME_EXECUTABLE ??
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
});
const page = await browser.newPage();
const consoleMessages = [];
const pageErrors = [];
const failedResponses = [];

page.on('console', (message) => {
  consoleMessages.push({ type: message.type(), text: message.text() });
});
page.on('pageerror', (error) => pageErrors.push(error.message));
page.on('response', (response) => {
  if (response.status() >= 400) {
    failedResponses.push({ status: response.status(), url: response.url() });
  }
});

await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
const quality = await page.evaluate(async () => {
  const workerUrl = new URL(
    'stockfish/stockfish-18-lite-single.js',
    document.baseURI,
  ).toString();
  const worker = new Worker(workerUrl);
  const transcript = [];
  const waiters = [];

  const waitFor = (predicate, description, timeoutMs = 20_000) =>
    new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        const index = waiters.findIndex((waiter) => waiter.resolve === resolve);
        if (index >= 0) {
          waiters.splice(index, 1);
        }
        reject(new Error(`Timed out waiting for ${description}.`));
      }, timeoutMs);
      waiters.push({
        predicate,
        resolve: (line) => {
          clearTimeout(timer);
          resolve(line);
        },
      });
    });

  worker.addEventListener('message', (event) => {
    const text = String(event.data);
    for (const line of text.split(/[\r\n]+/)) {
      const trimmed = line.trim();
      if (!trimmed) {
        continue;
      }
      transcript.push({ direction: 'in', line: trimmed });
      for (const waiter of [...waiters]) {
        if (waiter.predicate(trimmed)) {
          waiters.splice(waiters.indexOf(waiter), 1);
          waiter.resolve(trimmed);
        }
      }
    }
  });

  const send = (command) => {
    transcript.push({ direction: 'out', line: command });
    worker.postMessage(command);
  };
  const sendAndWait = (command, predicate, description) => {
    const response = waitFor(predicate, description);
    send(command);
    return response;
  };
  const search = async (fen) => {
    send('ucinewgame');
    await sendAndWait('isready', (line) => line === 'readyok', 'readyok');
    send(`position fen ${fen}`);
    return sendAndWait(
      'go movetime 500',
      (line) => line.startsWith('bestmove '),
      'bestmove',
    );
  };

  try {
    await sendAndWait('uci', (line) => line === 'uciok', 'uciok');
    send('setoption name Hash value 32');
    send('setoption name Skill Level value 20');
    send('setoption name Ponder value false');
    send('setoption name MultiPV value 1');
    await sendAndWait('isready', (line) => line === 'readyok', 'readyok');

    const cases = [
      {
        id: 'reply-after-e2e4',
        fen:
          'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR ' +
          'b KQkq e3 0 1',
        validate: 'opening',
      },
      {
        id: 'legal-check-escape',
        fen: '4k3/8/8/8/8/8/4R3/4K3 b - - 0 1',
        validate: 'check',
      },
      {
        id: 'fools-mate-finish',
        fen:
          'rnbqkbnr/pppp1ppp/8/4p3/6P1/5P2/PPPPP2P/RNBQKBNR ' +
          'b KQkq g3 0 2',
        validate: 'mate',
      },
      {
        id: 'automatic-promotion-piece',
        fen: '6rk/P7/8/8/5b2/4n3/8/7K w - - 0 1',
        validate: 'promotion',
      },
    ];
    const results = [];
    for (const testCase of cases) {
      const response = await search(testCase.fen);
      const move = response.split(/\s+/)[1];
      const passed =
        testCase.validate === 'opening'
          ? /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move) && move !== '(none)'
          : testCase.validate === 'check'
            ? ['e8d8', 'e8f8', 'e8d7', 'e8f7'].includes(move)
            : testCase.validate === 'mate'
              ? move === 'd8h4'
              : /^a7a8[qrbn]$/.test(move);
      results.push({ id: testCase.id, response, move, passed });
    }
    send('quit');
    return {
      workerUrl,
      results,
      transcript,
      passed: results.every((result) => result.passed),
    };
  } finally {
    worker.terminate();
  }
});

await browser.close();
const errors = consoleMessages.filter(({ type }) => type === 'error');
const report = {
  kind: 'web-stockfish-quality-smoke',
  baseUrl,
  quality,
  consoleErrors: errors,
  consoleWarnings: consoleMessages.filter(({ type }) => type === 'warning'),
  pageErrors,
  failedResponses,
  passed:
    quality.passed &&
    errors.length === 0 &&
    pageErrors.length === 0 &&
    failedResponses.length === 0,
};
const outputDir = path.resolve(root, runDir, 'browser-engine-quality');
await fs.mkdir(outputDir, { recursive: true });
await fs.writeFile(
  path.join(outputDir, 'report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);

if (!report.passed) {
  process.exitCode = 1;
}
