import crypto from 'node:crypto';
import { execFile as execFileCallback } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import { promisify } from 'node:util';
import { pathToFileURL } from 'node:url';

const execFile = promisify(execFileCallback);
const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = process.argv[3] ?? 'http://127.0.0.1:8089';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const viewport = { width: 1600, height: 900 };

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_simplified_chinese_i18n_regression.mjs ' +
      '<run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href,
);
const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');
const results = [];
const ocrTargets = [];
const flowFilter = process.env.FLOW_FILTER;

const captureSession = async ({ label, drive }) => {
  const artifactDir = path.resolve(root, runDir, 'browser', '1600x900', label);
  const videoDir = path.join(artifactDir, 'videos');
  await fs.mkdir(videoDir, { recursive: true });
  const browser = await chromium.launch({
    headless: true,
    executablePath: chromeExecutable,
  });
  const context = await browser.newContext({
    viewport,
    recordVideo: { dir: videoDir, size: viewport },
  });
  await context.addInitScript(() => {
    window.localStorage.setItem(
      'app.language_preference.v1',
      JSON.stringify('zh-Hans'),
    );
  });
  const tracePath = path.join(artifactDir, 'trace.zip');
  await context.tracing.start({
    screenshots: true,
    snapshots: true,
    sources: true,
  });
  const page = await context.newPage();
  const consoleMessages = [];
  const pageErrors = [];
  const failedResponses = [];
  page.on('console', (message) => {
    consoleMessages.push({ type: message.type(), text: message.text() });
  });
  page.on('pageerror', (error) => pageErrors.push(error.stack ?? error.message));
  page.on('response', (response) => {
    if (response.status() >= 400) {
      failedResponses.push({ status: response.status(), url: response.url() });
    }
  });
  await page.emulateMedia({ reducedMotion: 'reduce' });

  const shots = [];
  const screenshot = async (name, { ocr = false } = {}) => {
    const file = path.join(artifactDir, `${name}.png`);
    const bytes = await page.screenshot({ path: file });
    const geometry = await page.evaluate(() => {
      const view = document.querySelector('flutter-view');
      const canvas = document.querySelector('canvas');
      const rect = (view ?? canvas)?.getBoundingClientRect();
      return {
        innerWidth: window.innerWidth,
        innerHeight: window.innerHeight,
        scrollWidth: document.documentElement.scrollWidth,
        scrollHeight: document.documentElement.scrollHeight,
        stage: rect
          ? {
              x: rect.x,
              y: rect.y,
              width: rect.width,
              height: rect.height,
            }
          : null,
      };
    });
    const shot = {
      name,
      file: path.relative(path.resolve(root, runDir), file),
      bytes: bytes.length,
      sha256: sha256(bytes),
      geometry,
      geometryPassed:
        geometry.innerWidth === 1600 &&
        geometry.innerHeight === 900 &&
        geometry.scrollWidth <= 1600 &&
        geometry.scrollHeight <= 900,
    };
    shots.push(shot);
    if (ocr) ocrTargets.push(file);
  };
  const button = (name) => page.getByRole('button', { name }).first();
  const clickButton = async (name, waitMs = 450) => {
    const target = button(name);
    await target.waitFor({ state: 'visible', timeout: 20_000 });
    await target.click({ timeout: 20_000 });
    await page.waitForTimeout(waitMs);
  };
  const waitButton = async (name, timeout = 20_000) =>
    button(name).waitFor({ state: 'visible', timeout });
  let startsInLobby = false;
  const enableFlutterSemantics = async () => {
    await page.waitForSelector('flt-semantics-placeholder', {
      state: 'attached',
      timeout: 20_000,
    });
    await page.evaluate(() => {
      document.querySelector('flt-semantics-placeholder')?.click();
    });
    await button(/Press Start|开始游戏/).waitFor({
      state: 'visible',
      timeout: 20_000,
    });
    if (await button(/开始游戏/).count() === 0) {
      await clickButton(/Settings/, 650);
      await clickButton(/Language/, 350);
      const chineseRadio = page
        .getByRole('radio', { name: /Simplified Chinese/ })
        .first();
      await chineseRadio.waitFor({ state: 'visible', timeout: 12_000 });
      await chineseRadio.click();
      await page.waitForTimeout(500);
      await clickButton(/大厅/, 600);
      startsInLobby = true;
    }
    if (!startsInLobby) await waitButton(/开始游戏/);
  };
  const openMode = async (modeName) => {
    if (!startsInLobby) await clickButton(/开始游戏/, 650);
    await clickButton(/开始游玩/, 650);
    await clickButton(modeName, 300);
    await screenshot('mode-selected');
    await clickButton(/^确认$/, 700);
  };

  let flowError = null;
  try {
    await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(3000);
    await enableFlutterSemantics();
    await drive({
      page,
      screenshot,
      clickButton,
      waitButton,
      openMode,
      button,
    });
  } catch (error) {
    flowError = error.stack ?? error.message;
    await screenshot('failure-state').catch(() => {});
  }

  await context.tracing.stop({ path: tracePath }).catch(() => {});
  const video = page.video();
  await context.close();
  const videoPath = video ? await video.path() : null;
  await browser.close();

  const consoleErrors = consoleMessages.filter(({ type }) => type === 'error');
  const consoleWarnings = consoleMessages.filter(
    ({ type }) => type === 'warning',
  );
  const result = {
    label,
    viewport,
    shots,
    tracePath: path.relative(path.resolve(root, runDir), tracePath),
    videoPath: videoPath
      ? path.relative(path.resolve(root, runDir), videoPath)
      : null,
    consoleErrors,
    consoleWarnings,
    pageErrors,
    failedResponses,
    flowError,
  };
  result.passed =
    flowError === null &&
    shots.length > 0 &&
    shots.every(({ bytes, geometryPassed }) => bytes > 50_000 && geometryPassed) &&
    new Set(shots.map(({ sha256: hash }) => hash)).size === shots.length &&
    consoleErrors.length === 0 &&
    pageErrors.length === 0 &&
    failedResponses.length === 0 &&
    result.videoPath !== null;
  await fs.writeFile(
    path.join(artifactDir, 'result.json'),
    `${JSON.stringify(result, null, 2)}\n`,
  );
  results.push(result);
};

const driveMatchSetup = async ({
  screenshot,
  clickButton,
  waitButton,
}) => {
  await screenshot('match-settings', { ocr: true });
  await clickButton(/^继续$/, 650);
  await screenshot('battlefield-select');
  await clickButton(/选择棋庭/, 650);
  await screenshot('country-select', { ocr: true });
  await clickButton(/^确认$/, 700);
  await screenshot('versus-loading');
  await waitButton(/进入对局/, 12_000);
  await clickButton(/进入对局/, 900);
};

if (!flowFilter || flowFilter === 'local-duel') await captureSession({
  label: 'local-duel',
  drive: async (tools) => {
    await tools.screenshot('title', { ocr: true });
    await tools.openMode(/本地对战/);
    await driveMatchSetup(tools);
    await tools.screenshot('local-match', { ocr: true });
  },
});

if (!flowFilter || flowFilter === 'ai-duel') await captureSession({
  label: 'ai-duel',
  drive: async (tools) => {
    await tools.openMode(/人机对战/);
    await driveMatchSetup(tools);
    await tools.screenshot('ai-match', { ocr: true });
  },
});

if (!flowFilter || flowFilter === 'story-campaign') await captureSession({
  label: 'story-campaign',
  drive: async ({ page, screenshot, clickButton, openMode }) => {
    await openMode(/剧情战役/);
    await screenshot('campaign-map', { ocr: true });
    await clickButton(/开始任务|重玩任务/, 700);
    await screenshot('opening-dialogue');
    for (let index = 0; index < 18; index += 1) {
      await page.keyboard.press('Enter');
      await page.waitForTimeout(100);
    }
    await page.waitForTimeout(900);
    await screenshot('story-battle', { ocr: true });
  },
});

if (!flowFilter || flowFilter === 'last-piece') await captureSession({
  label: 'last-piece',
  drive: async ({ screenshot, clickButton, openMode }) => {
    await openMode(/残子求生/);
    await screenshot('country-select');
    await clickButton(/选择关卡/, 600);
    await screenshot('level-ladder', { ocr: true });
    await clickButton(/开始第 001 关/, 1100);
    await screenshot('survival-run', { ocr: true });
    await clickButton(/结束本局/, 600);
    await screenshot('survival-result');
  },
});

if (!flowFilter || flowFilter === 'living-campaign') await captureSession({
  label: 'living-campaign',
  drive: async ({ page, screenshot, clickButton, waitButton, openMode }) => {
    await openMode(/演化战役/);
    await screenshot('new-run-hub');
    await clickButton(/开始新的演化战役/, 800);
    await screenshot('fixed-chinese-hub', { ocr: true });
    await clickButton(/继续故事/, 650);
    await screenshot('fixed-chinese-prologue');
    await clickButton(/开始第一章/, 650);
    await screenshot('fixed-chinese-dialogue');
    await clickButton(/跳至任务简报/, 650);
    await screenshot('fixed-chinese-briefing', { ocr: true });
    await clickButton(/进入战斗/, 1200);
    await screenshot('fixed-chinese-battle');
    await page.waitForTimeout(1800);
    await clickButton(/QA：结算章节/, 700);
    await screenshot('deterministic-outcome');
    await clickButton(/^继续$/, 500);
    await waitButton(/跳过/, 30_000);
    await screenshot('chinese-aftermath');
    await clickButton(/跳过/, 500);
    await waitButton(/重现终局一刻/, 30_000);
    await clickButton(/重现终局一刻/, 300);
    await waitButton(/续写编年史/, 30_000);
    await clickButton(/续写编年史/, 300);
    await waitButton(/继续故事/, 30_000);
    await screenshot('generated-chinese-hub', { ocr: true });
    await clickButton(/继续故事/, 650);
    await screenshot('assisted-generated-chinese-chapter', { ocr: true });
    await clickButton(/跳至任务简报/, 650);
    await screenshot('assisted-generated-chinese-briefing', { ocr: true });
  },
});

let ocr = { images: [], error: null };
try {
  const { stdout } = await execFile(
    '/usr/bin/xcrun',
    [
      'swift',
      path.resolve(root, 'scripts/recognize_screenshot_text.swift'),
      ...ocrTargets,
    ],
    {
      maxBuffer: 16 * 1024 * 1024,
      env: {
        ...process.env,
        CLANG_MODULE_CACHE_PATH: '/tmp/crazy-chess-swift-module-cache',
        SWIFT_MODULECACHE_PATH: '/tmp/crazy-chess-swift-module-cache',
      },
    },
  );
  ocr = JSON.parse(stdout);
  ocr.error = null;
  for (const image of ocr.images) {
    const text = image.rows.map((row) => row.text).join('\n');
    image.hasChinese = /[\u3400-\u9fff]/.test(text);
    image.forbiddenEnglish = [
      'Story Campaign',
      'Last Piece Standing',
      'Living Campaign',
      'Match Settings',
      'Choose Your Court',
      'Retire Run',
      'WHITE',
      'BLACK',
    ].filter((phrase) => text.includes(phrase));
    image.passed = image.hasChinese && image.forbiddenEnglish.length === 0;
  }
} catch (error) {
  ocr = { images: [], error: error.stack ?? error.message };
}

const report = {
  kind: 'simplified-chinese-i18n-web-regression',
  baseUrl,
  viewport,
  paidProviderCalls: 0,
  fixture: 'LIVING_CAMPAIGN_DEMO deterministic local gateway',
  results,
  ocr,
};
report.passed =
  results.length === (flowFilter ? 1 : 5) &&
  results.every(({ passed }) => passed) &&
  ocr.error === null &&
  ocr.images.length === ocrTargets.length &&
  ocr.images.every(({ passed }) => passed);
await fs.mkdir(path.resolve(root, runDir), { recursive: true });
await fs.writeFile(
  path.resolve(root, runDir, 'browser-report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);

console.log(JSON.stringify({ passed: report.passed, results, ocr }, null, 2));
if (!report.passed) process.exitCode = 1;
