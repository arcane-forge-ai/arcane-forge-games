import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = (process.argv[3] ?? 'http://127.0.0.1:8080').replace(/\/$/, '');
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_app_icon_regression.mjs <run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const viewport = { width: 1600, height: 900 };
const artifactDir = path.resolve(root, runDir, 'browser');
const videoDir = path.join(artifactDir, 'videos');
await fs.mkdir(videoDir, { recursive: true });

const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');
const relativeToRun = (file) => path.relative(path.resolve(root, runDir), file);

const browser = await chromium.launch({
  headless: true,
  executablePath: chromeExecutable,
});
const context = await browser.newContext({
  viewport,
  recordVideo: { dir: videoDir, size: viewport },
});
const page = await context.newPage();
const consoleMessages = [];
const pageErrors = [];
const failedResponses = [];
const shots = [];

page.on('console', (message) => {
  consoleMessages.push({ type: message.type(), text: message.text() });
});
page.on('pageerror', (error) => {
  pageErrors.push(error.stack ?? error.message);
});
page.on('response', (response) => {
  if (response.status() >= 400) {
    failedResponses.push({ status: response.status(), url: response.url() });
  }
});

const screenshot = async (name) => {
  const file = path.join(artifactDir, `${name}.png`);
  let bytes;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    bytes = await page.screenshot({ path: file });
    if (bytes.length > 50_000) break;
    await page.waitForTimeout(800);
  }
  const shot = {
    name,
    file: relativeToRun(file),
    bytes: bytes.length,
    sha256: sha256(bytes),
  };
  shots.push(shot);
  return shot;
};

await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(3600);
const titleShot = await screenshot('01-title-screen');
const documentMetadata = await page.evaluate(() => ({
  title: document.title,
  icons: Array.from(document.querySelectorAll('link[rel~="icon"]')).map(
    (link) => link.href,
  ),
  manifest: document.querySelector('link[rel="manifest"]')?.href ?? null,
}));

const assetPaths = [
  '/favicon.png',
  '/manifest.json',
  '/icons/Icon-192.png',
  '/icons/Icon-512.png',
  '/icons/Icon-maskable-192.png',
  '/icons/Icon-maskable-512.png',
];
const assetChecks = [];
for (const assetPath of assetPaths) {
  const response = await context.request.get(`${baseUrl}${assetPath}`);
  const body = await response.body();
  assetChecks.push({
    path: assetPath,
    status: response.status(),
    contentType: response.headers()['content-type'] ?? null,
    bytes: body.length,
    sha256: sha256(body),
  });
}

await page.mouse.click(280, 670);
await page.waitForTimeout(1400);
const lobbyShot = await screenshot('02-main-lobby');

const video = page.video();
await context.close();
const absoluteVideoPath = video ? await video.path() : null;
await browser.close();

const consoleErrors = consoleMessages.filter(({ type }) => type === 'error');
const consoleWarnings = consoleMessages.filter(({ type }) => type === 'warning');
const knownConsoleWarnings = consoleWarnings.filter(({ text }) =>
  text.includes('The AudioContext was not allowed to start'),
);
const unexpectedConsoleWarnings = consoleWarnings.filter(
  ({ text }) => !text.includes('The AudioContext was not allowed to start'),
);
const videoPath = absoluteVideoPath
  ? relativeToRun(absoluteVideoPath)
  : null;
const result = {
  kind: 'web-app-icon-and-boot-regression',
  baseUrl,
  viewport,
  documentMetadata,
  assetChecks,
  shots,
  consoleErrors,
  knownConsoleWarnings,
  unexpectedConsoleWarnings,
  pageErrors,
  failedResponses,
  videoPath,
  passed:
    documentMetadata.title === 'Crazy Chess' &&
    documentMetadata.icons.some((href) => href.endsWith('/favicon.png')) &&
    documentMetadata.manifest?.endsWith('/manifest.json') === true &&
    assetChecks.every(({ status, bytes }) => status === 200 && bytes > 0) &&
    titleShot.bytes > 50_000 &&
    lobbyShot.bytes > 50_000 &&
    titleShot.sha256 !== lobbyShot.sha256 &&
    consoleErrors.length === 0 &&
    unexpectedConsoleWarnings.length === 0 &&
    pageErrors.length === 0 &&
    failedResponses.length === 0 &&
    videoPath !== null,
};

await fs.writeFile(
  path.join(artifactDir, 'result.json'),
  `${JSON.stringify(result, null, 2)}\n`,
);
console.log(JSON.stringify(result, null, 2));
if (!result.passed) process.exitCode = 1;
