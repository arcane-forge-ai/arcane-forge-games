#!/usr/bin/env bash

set -euo pipefail

release_ref="${1:-HEAD}"
release_id="${2:-android-0.9.0-1}"
output_dir="${3:-build/corresponding-source/${release_id}}"
archive_name="crazy-chess-${release_id}-corresponding-source.tar.gz"

mkdir -p "${output_dir}"

# This package contains the preferred form for modifying the Android program,
# the complete vendored Stockfish/wrapper source, and all scripts and metadata
# used to generate the mobile engine. Runtime art, music, generated binaries,
# private signing material, and provider credentials are intentionally absent.
git archive \
  --format=tar.gz \
  --prefix="crazy-chess-${release_id}/" \
  --output="${output_dir}/${archive_name}" \
  "${release_ref}" \
  .gitignore \
  Makefile \
  analysis_options.yaml \
  l10n.yaml \
  pubspec.yaml \
  pubspec.lock \
  android \
  lib \
  test \
  scripts \
  assets/data \
  assets/prompts \
  third_party/stockfish/COPYING.txt \
  third_party/stockfish/SOURCE.md \
  third_party/stockfish/SOURCE.html \
  third_party/stockfish/manifest.json \
  third_party/stockfish/mobile_flutter

shasum -a 256 "${output_dir}/${archive_name}"
