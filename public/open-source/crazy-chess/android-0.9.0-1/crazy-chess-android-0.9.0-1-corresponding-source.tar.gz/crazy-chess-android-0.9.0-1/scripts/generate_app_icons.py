#!/usr/bin/env python3
"""Normalize and derive Crazy Chess platform icons from one opaque master."""

from __future__ import annotations

import argparse
import hashlib
import json
from decimal import Decimal
from pathlib import Path

from PIL import Image, ImageDraw


WINDOWS_ICON_SIZES = [16, 20, 24, 32, 40, 48, 64, 96, 128, 256]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resized(master: Image.Image, size: int) -> Image.Image:
    return master.resize((size, size), Image.Resampling.LANCZOS)


def rounded_resized(master: Image.Image, size: int) -> Image.Image:
    image = resized(master, size).convert("RGBA")
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    radius = max(1, round(size * 0.22))
    draw.rounded_rectangle((0, 0, size - 1, size - 1), radius=radius, fill=255)
    image.putalpha(mask)
    return image


def save_png(
    master: Image.Image,
    size: int,
    output: Path,
    *,
    rounded: bool = False,
) -> dict[str, object]:
    output.parent.mkdir(parents=True, exist_ok=True)
    image = rounded_resized(master, size) if rounded else resized(master, size)
    image.save(output, format="PNG", optimize=True)
    return {
        "path": output.as_posix(),
        "size": f"{size}x{size}",
        "mode": "RGBA" if rounded else "RGB",
        "sha256": sha256(output),
    }


def catalog_pixel_size(item: dict[str, str]) -> int:
    logical_size = Decimal(item["size"].split("x", maxsplit=1)[0])
    scale = Decimal(item["scale"].removesuffix("x"))
    pixels = logical_size * scale
    if pixels != pixels.to_integral_value():
        raise ValueError(f"Non-integral catalog size: {item}")
    return int(pixels)


def derive_catalog(
    master: Image.Image,
    catalog_dir: Path,
    *,
    rounded: bool = False,
) -> list[dict[str, object]]:
    contents_path = catalog_dir / "Contents.json"
    data = json.loads(contents_path.read_text(encoding="utf-8"))
    outputs: list[dict[str, object]] = []
    seen_filenames: set[str] = set()
    for item in data["images"]:
        filename = item.get("filename")
        if not filename or filename in seen_filenames:
            continue
        seen_filenames.add(filename)
        outputs.append(
            save_png(
                master,
                catalog_pixel_size(item),
                catalog_dir / filename,
                rounded=rounded,
            )
        )
    return outputs


def relative_outputs(workspace: Path, outputs: list[dict[str, object]]) -> None:
    for output in outputs:
        output["path"] = Path(str(output["path"])).relative_to(workspace).as_posix()


def validate_outputs(
    workspace: Path,
    outputs: list[dict[str, object]],
) -> dict[str, object]:
    checked_pngs = 0
    checked_ico_sizes: list[int] = []
    for output in outputs:
        path = workspace / str(output["path"])
        if path.suffix.lower() == ".png":
            expected_size = int(str(output["size"]).split("x", maxsplit=1)[0])
            with Image.open(path) as image:
                if image.size != (expected_size, expected_size):
                    raise ValueError(
                        f"Unexpected PNG size for {path}: {image.size}, expected {expected_size}"
                    )
                if image.mode != output["mode"]:
                    raise ValueError(
                        f"Unexpected PNG mode for {path}: {image.mode}, expected {output['mode']}"
                    )
            checked_pngs += 1
        elif path.suffix.lower() == ".ico":
            with Image.open(path) as image:
                checked_ico_sizes = sorted(size[0] for size in image.ico.sizes())
            if checked_ico_sizes != WINDOWS_ICON_SIZES:
                raise ValueError(
                    f"Unexpected ICO sizes: {checked_ico_sizes}, expected {WINDOWS_ICON_SIZES}"
                )
    return {
        "status": "passed",
        "checked_png_files": checked_pngs,
        "checked_ico_sizes": checked_ico_sizes,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, default=Path.cwd())
    parser.add_argument(
        "--master",
        type=Path,
        default=Path("assets/generated/app_icon/v1/app-icon-master.png"),
    )
    args = parser.parse_args()

    workspace = args.workspace.resolve()
    master_path = args.master
    if not master_path.is_absolute():
        master_path = workspace / master_path
    master_path = master_path.resolve()

    with Image.open(master_path) as opened:
        master = opened.convert("RGB")
    if master.width != master.height:
        raise ValueError(f"Master must be square, got {master.size}")
    if master.size != (1024, 1024):
        master = resized(master, 1024)
        master.save(master_path, format="PNG", optimize=True)

    outputs: list[dict[str, object]] = []
    outputs.extend(
        derive_catalog(
            master,
            workspace / "ios/Runner/Assets.xcassets/AppIcon.appiconset",
        )
    )
    outputs.extend(
        derive_catalog(
            master,
            workspace / "macos/Runner/Assets.xcassets/AppIcon.appiconset",
            rounded=True,
        )
    )

    web_sizes = {
        "web/favicon.png": 16,
        "web/icons/Icon-192.png": 192,
        "web/icons/Icon-512.png": 512,
        "web/icons/Icon-maskable-192.png": 192,
        "web/icons/Icon-maskable-512.png": 512,
    }
    for relative_path, size in web_sizes.items():
        outputs.append(save_png(master, size, workspace / relative_path))

    windows_path = workspace / "windows/runner/resources/app_icon.ico"
    windows_path.parent.mkdir(parents=True, exist_ok=True)
    windows_master = rounded_resized(master, 1024)
    windows_master.save(
        windows_path,
        format="ICO",
        sizes=[(size, size) for size in WINDOWS_ICON_SIZES],
        bitmap_format="png",
    )
    outputs.append(
        {
            "path": windows_path.as_posix(),
            "size": "multi-resolution",
            "mode": "RGBA rounded-square container from RGB master",
            "embedded_sizes": WINDOWS_ICON_SIZES,
            "sha256": sha256(windows_path),
        }
    )

    relative_outputs(workspace, outputs)
    validation = validate_outputs(workspace, outputs)
    manifest = {
        "version": 1,
        "master": {
            "path": master_path.relative_to(workspace).as_posix(),
            "size": "1024x1024",
            "mode": "RGB",
            "sha256": sha256(master_path),
        },
        "windows_icon_sizes": WINDOWS_ICON_SIZES,
        "outputs": outputs,
        "validation": validation,
    }
    manifest_path = workspace / "assets/generated/app_icon/v1/derived-platform-icons.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(
        f"Wrote {len(outputs)} icon files and {manifest_path}; "
        f"validated {validation['checked_png_files']} PNGs and "
        f"ICO sizes {validation['checked_ico_sizes']}"
    )


if __name__ == "__main__":
    main()
