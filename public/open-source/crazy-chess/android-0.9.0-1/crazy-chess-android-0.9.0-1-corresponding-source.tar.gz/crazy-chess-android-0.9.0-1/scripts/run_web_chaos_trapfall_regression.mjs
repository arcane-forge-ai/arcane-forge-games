import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const naturalUrl = process.argv[3] ?? 'http://127.0.0.1:8080';
const assistedUrl = process.argv[4] ?? 'http://127.0.0.1:8081';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_chaos_trapfall_regression.mjs ' +
      '<run-dir> [natural-url] [assisted-url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const viewports = [
  { width: 1600, height: 900 },
  { width: 1280, height: 720 },
];
const results = [];

const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');

const captureSession = async ({
  viewport,
  label,
  baseUrl,
  drive,
}) => {
  const artifactDir = path.resolve(
    root,
    runDir,
    'browser',
    `${viewport.width}x${viewport.height}`,
    label,
  );
  const videoDir = path.join(artifactDir, 'videos');
  await fs.mkdir(videoDir, { recursive: true });
  const browser = await chromium.launch({
    headless: true,
    executablePath: chromeExecutable,
  });
  const context = await browser.newContext({
    viewport,
    recordVideo: { dir: videoDir, size: viewport },
  });
  const page = await context.newPage();
  const consoleMessages = [];
  const pageErrors = [];
  const failedResponses = [];
  page.on('console', (message) => {
    consoleMessages.push({ type: message.type(), text: message.text() });
  });
  page.on('pageerror', (error) => pageErrors.push(error.message));
  page.on('response', (response) => {
    if (response.status() >= 400) {
      failedResponses.push({
        status: response.status(),
        url: response.url(),
      });
    }
  });
  await page.emulateMedia({ reducedMotion: 'reduce' });

  const shots = [];
  const screenshot = async (name) => {
    const file = path.join(artifactDir, `${name}.png`);
    const bytes = await page.screenshot({ path: file });
    shots.push({
      name,
      file,
      bytes: bytes.length,
      sha256: sha256(bytes),
    });
  };
  await drive({ page, screenshot, baseUrl, viewport });

  const video = page.video();
  await context.close();
  const videoPath = video ? await video.path() : null;
  await browser.close();

  const errors = consoleMessages.filter(({ type }) => type === 'error');
  const warnings = consoleMessages.filter(({ type }) => type === 'warning');
  const result = {
    viewport,
    label,
    shots,
    consoleErrors: errors,
    consoleWarnings: warnings,
    pageErrors,
    failedResponses,
    videoPath,
    passed:
      shots.length > 0 &&
      shots.every(({ bytes }) => bytes > 50_000) &&
      new Set(shots.map(({ sha256: hash }) => hash)).size === shots.length &&
      errors.length === 0 &&
      warnings.length === 0 &&
      pageErrors.length === 0 &&
      failedResponses.length === 0 &&
      videoPath !== null,
  };
  await fs.writeFile(
    path.join(artifactDir, 'result.json'),
    `${JSON.stringify(result, null, 2)}\n`,
  );
  return result;
};

for (const viewport of viewports) {
  const scaleX = viewport.width / 1600;
  const scaleY = viewport.height / 900;
  results.push(
    await captureSession({
      viewport,
      label: 'natural',
      baseUrl: naturalUrl,
      drive: async ({ page, screenshot, baseUrl }) => {
        const clickStage = async (x, y, waitMs = 850) => {
          await page.mouse.click(x * scaleX, y * scaleY);
          await page.waitForTimeout(waitMs);
        };
        await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(3500);
        await clickStage(280, 690);
        await clickStage(1190, 205);
        await clickStage(360, 330);
        await clickStage(1407, 844);
        await clickStage(790, 820);
        await screenshot('battlefield-classic');

        await page.mouse.move(560 * scaleX, 620 * scaleY);
        await page.mouse.wheel(0, 720 * scaleY);
        await page.waitForTimeout(900);
        await screenshot('battlefield-chaos-card');
        await clickStage(315, 650);
        await screenshot('battlefield-chaos-selected');

        await clickStage(1385, 835);
        await clickStage(1129, 794);
        await page.waitForTimeout(5600);
        await clickStage(800, 778, 2400);
        await screenshot('chaos-crucible-live-opening');
      },
    }),
  );

  results.push(
    await captureSession({
      viewport,
      label: 'assisted',
      baseUrl: assistedUrl,
      drive: async ({ page, screenshot, baseUrl }) => {
        for (const state of [
          'chaosArt',
          'trapfallMercantile',
          'trapfallSpy',
          'checkmate',
          'stalemate',
        ]) {
          await page.goto(`${baseUrl}/?state=${state}&reducedMotion=1`, {
            waitUntil: 'domcontentloaded',
          });
          await page.waitForTimeout(4200);
          await screenshot(state);
        }
      },
    }),
  );
}

const report = {
  kind: 'web-chaos-crucible-trapfall-regression',
  naturalUrl,
  assistedUrl,
  results,
  passed: results.every(({ passed }) => passed),
};
await fs.mkdir(path.resolve(root, runDir, 'browser'), { recursive: true });
await fs.writeFile(
  path.resolve(root, runDir, 'browser', 'report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);

if (!report.passed) {
  process.exitCode = 1;
}
