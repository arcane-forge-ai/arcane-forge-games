import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = process.cwd();
const runDir = process.argv[2];
const baseUrl = process.argv[3] ?? 'http://127.0.0.1:8080';
const playwrightModule = process.env.PLAYWRIGHT_MODULE;

if (!runDir || !playwrightModule) {
  throw new Error(
    'Usage: PLAYWRIGHT_MODULE=/absolute/path/to/playwright/index.mjs ' +
      'node scripts/run_web_dynamic_battlefields_regression.mjs ' +
      '<run-dir> [url]',
  );
}

const { chromium } = await import(
  pathToFileURL(path.resolve(playwrightModule)).href
);
const chromeExecutable =
  process.env.CHROME_EXECUTABLE ??
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const viewports = [
  { width: 1600, height: 900 },
  { width: 1280, height: 720 },
];
const results = [];

const sha256 = (bytes) =>
  crypto.createHash('sha256').update(bytes).digest('hex');

for (const viewport of viewports) {
  const label = `${viewport.width}x${viewport.height}`;
  const artifactDir = path.resolve(root, runDir, 'browser', label);
  const videoDir = path.join(artifactDir, 'videos');
  await fs.mkdir(videoDir, { recursive: true });

  const browser = await chromium.launch({
    headless: true,
    executablePath: chromeExecutable,
  });
  const context = await browser.newContext({
    viewport,
    recordVideo: { dir: videoDir, size: viewport },
  });
  const page = await context.newPage();
  const consoleMessages = [];
  const pageErrors = [];

  page.on('console', (message) => {
    consoleMessages.push({
      type: message.type(),
      text: message.text(),
    });
  });
  page.on('pageerror', (error) => pageErrors.push(error.message));
  await page.emulateMedia({ reducedMotion: 'reduce' });

  const scaleX = viewport.width / 1600;
  const scaleY = viewport.height / 900;
  const clickStage = async (x, y, waitMs = 850) => {
    await page.mouse.click(x * scaleX, y * scaleY);
    await page.waitForTimeout(waitMs);
  };
  const screenshot = async (name) => {
    const file = path.join(artifactDir, `${name}.png`);
    const bytes = await page.screenshot({ path: file });
    return { file, hash: sha256(bytes) };
  };

  await page.goto(baseUrl, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(3500);
  await screenshot('s01-title');

  await clickStage(280, 690);
  await clickStage(1190, 205);
  await clickStage(360, 330);
  await clickStage(1407, 844);
  await screenshot('s04-local-settings');

  await clickStage(790, 820);
  const classic = await screenshot('battlefield-classic');

  await clickStage(810, 295);
  const verdant = await screenshot('battlefield-verdant');

  await clickStage(315, 560);
  const gilded = await screenshot('battlefield-gilded');

  await clickStage(810, 560);
  const ruined = await screenshot('battlefield-ruined');

  await clickStage(810, 295);
  await clickStage(1385, 835);
  await screenshot('s05-country-select-after-verdant');

  await clickStage(1129, 794);
  await screenshot('s07-loading');
  await page.waitForTimeout(5600);
  await screenshot('s07-ready');

  await clickStage(800, 778, 2400);
  await screenshot('s20-verdant-match');

  const video = page.video();
  await context.close();
  const videoPath = video ? await video.path() : null;
  await browser.close();

  const errors = consoleMessages.filter(({ type }) => type === 'error');
  const warnings = consoleMessages.filter(({ type }) => type === 'warning');
  const battlefieldStatesDiffer =
    new Set([classic.hash, verdant.hash, gilded.hash, ruined.hash]).size === 4;
  const result = {
    viewport,
    battlefieldStatesDiffer,
    consoleErrors: errors,
    consoleWarnings: warnings,
    pageErrors,
    videoPath,
    passed:
      battlefieldStatesDiffer &&
      errors.length === 0 &&
      warnings.length === 0 &&
      pageErrors.length === 0 &&
      videoPath !== null,
  };
  await fs.writeFile(
    path.join(artifactDir, 'result.json'),
    `${JSON.stringify(result, null, 2)}\n`,
  );
  results.push(result);
}

const report = {
  kind: 'web-dynamic-battlefields-regression',
  baseUrl,
  results,
  passed: results.every(({ passed }) => passed),
};
await fs.mkdir(path.resolve(root, runDir, 'browser'), { recursive: true });
await fs.writeFile(
  path.resolve(root, runDir, 'browser', 'report.json'),
  `${JSON.stringify(report, null, 2)}\n`,
);

if (!report.passed) {
  process.exitCode = 1;
}
